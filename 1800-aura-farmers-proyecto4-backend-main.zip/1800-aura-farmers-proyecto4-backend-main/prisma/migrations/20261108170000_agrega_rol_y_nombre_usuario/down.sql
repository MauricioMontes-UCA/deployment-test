-- Reversión de agrega_rol_y_nombre_usuario. Prisma no ejecuta este archivo:
-- se aplica a mano y luego se puede volver a migrar con `npm run prisma:deploy`.
--
--   npx prisma db execute --file prisma/migrations/20261108170000_agrega_rol_y_nombre_usuario/down.sql
--
-- Pierde los valores de rol y nombre_usuario.

BEGIN;

ALTER TABLE "Usuarios"
    DROP CONSTRAINT "Usuarios_nombre_usuario_largo_check",
    DROP CONSTRAINT "Usuarios_nombre_usuario_formato_check";
DROP INDEX "Usuarios_nombre_usuario_key";
ALTER TABLE "Usuarios" DROP COLUMN "nombre_usuario";
ALTER TABLE "Usuarios" DROP COLUMN "rol";

ALTER TABLE "Usuarios"
    ALTER COLUMN "creado_en" TYPE TIMESTAMP(3) USING "creado_en" AT TIME ZONE 'UTC',
    ALTER COLUMN "actualizado_en" TYPE TIMESTAMP(3) USING "actualizado_en" AT TIME ZONE 'UTC';
ALTER TABLE "Usuarios" RENAME COLUMN "creado_en" TO "created_at";
ALTER TABLE "Usuarios" RENAME COLUMN "actualizado_en" TO "updated_at";

ALTER INDEX "Usuarios_email_key" RENAME TO "users_email_key";
ALTER TABLE "Usuarios" RENAME CONSTRAINT "Usuarios_pkey" TO "users_pkey";
ALTER TABLE "Usuarios" RENAME TO "users";

DROP TYPE "Rol";

-- Permite que `prisma migrate deploy` vuelva a aplicar la migración.
DELETE FROM "_prisma_migrations"
WHERE "migration_name" = '20261108170000_agrega_rol_y_nombre_usuario';

COMMIT;
