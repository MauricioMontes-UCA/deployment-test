-- DB-0.1: agrega el rol y el nombre de usuario, y alinea la tabla con el modelo
-- relacional. Se escribe a mano porque Prisma generaría DROP + ADD COLUMN para
-- los renombres, y eso perdería los datos existentes.
--
-- Reversión: down.sql, en esta misma carpeta.

-- CreateEnum
CREATE TYPE "Rol" AS ENUM ('ARRENDADOR', 'ARRENDATARIO');

-- La tabla y sus objetos toman los nombres que Prisma espera, o la siguiente
-- migración los detectaría como un cambio pendiente.
ALTER TABLE "users" RENAME TO "Usuarios";
ALTER TABLE "Usuarios" RENAME CONSTRAINT "users_pkey" TO "Usuarios_pkey";
ALTER INDEX "users_email_key" RENAME TO "Usuarios_email_key";

-- Las marcas de tiempo existentes se guardaron en UTC sin zona.
ALTER TABLE "Usuarios" RENAME COLUMN "created_at" TO "creado_en";
ALTER TABLE "Usuarios" RENAME COLUMN "updated_at" TO "actualizado_en";
ALTER TABLE "Usuarios"
    ALTER COLUMN "creado_en" TYPE TIMESTAMPTZ(6) USING "creado_en" AT TIME ZONE 'UTC',
    ALTER COLUMN "actualizado_en" TYPE TIMESTAMPTZ(6) USING "actualizado_en" AT TIME ZONE 'UTC';

-- Los usuarios existentes quedan como ARRENDATARIO.
ALTER TABLE "Usuarios" ADD COLUMN "rol" "Rol" NOT NULL DEFAULT 'ARRENDATARIO';

-- Se agrega nullable para poder rellenar las filas existentes antes del NOT NULL.
ALTER TABLE "Usuarios" ADD COLUMN "nombre_usuario" VARCHAR(30);
UPDATE "Usuarios" SET "nombre_usuario" = 'usuario_' || left("id"::text, 8);
ALTER TABLE "Usuarios" ALTER COLUMN "nombre_usuario" SET NOT NULL;

-- CreateIndex
CREATE UNIQUE INDEX "Usuarios_nombre_usuario_key" ON "Usuarios"("nombre_usuario");

-- Como el formato solo admite minúsculas, el índice único de arriba también
-- impide repetidos sin distinguir mayúsculas.
ALTER TABLE "Usuarios"
    ADD CONSTRAINT "Usuarios_nombre_usuario_largo_check"
        CHECK (char_length("nombre_usuario") BETWEEN 3 AND 30),
    ADD CONSTRAINT "Usuarios_nombre_usuario_formato_check"
        CHECK ("nombre_usuario" ~ '^[a-z0-9._-]+$');
