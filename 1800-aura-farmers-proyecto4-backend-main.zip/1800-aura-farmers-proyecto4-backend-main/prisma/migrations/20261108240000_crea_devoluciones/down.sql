-- Reversión de crea_devoluciones. Prisma no ejecuta este archivo: se aplica a
-- mano y luego se puede volver a migrar con `npm run prisma:deploy`.
--
--   npx prisma db execute --file prisma/migrations/20261108240000_crea_devoluciones/down.sql
--
-- Borra todas las devoluciones y los valores de finalizada_en y
-- cierre_automatico de las reservas.

BEGIN;

DROP TABLE "Devoluciones";
DROP TYPE "EstadoFinalBien";

ALTER TABLE "Reservas" DROP COLUMN "cierre_automatico";
ALTER TABLE "Reservas" DROP COLUMN "finalizada_en";

-- Permite que `prisma migrate deploy` vuelva a aplicar la migración.
DELETE FROM "_prisma_migrations"
WHERE "migration_name" = '20261108240000_crea_devoluciones';

COMMIT;
