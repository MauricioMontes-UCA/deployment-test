-- CreateEnum
CREATE TYPE "EstadoFinalBien" AS ENUM ('BUEN_ESTADO', 'DANADO', 'INCOMPLETO');

-- AlterTable
ALTER TABLE "Reservas" ADD COLUMN     "cierre_automatico" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "finalizada_en" TIMESTAMPTZ(6);

-- CreateTable
CREATE TABLE "Devoluciones" (
    "id" UUID NOT NULL,
    "reserva_id" UUID NOT NULL,
    "registrado_por" UUID NOT NULL,
    "fecha_devolucion" TIMESTAMPTZ(6) NOT NULL,
    "estado_final_bien" "EstadoFinalBien" NOT NULL,
    "observaciones" VARCHAR(500),
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMPTZ(6) NOT NULL,

    CONSTRAINT "Devoluciones_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "Devoluciones_reserva_id_key" ON "Devoluciones"("reserva_id");

-- AddForeignKey
ALTER TABLE "Devoluciones" ADD CONSTRAINT "Devoluciones_reserva_id_fkey" FOREIGN KEY ("reserva_id") REFERENCES "Reservas"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Devoluciones" ADD CONSTRAINT "Devoluciones_registrado_por_fkey" FOREIGN KEY ("registrado_por") REFERENCES "Usuarios"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

