-- Reversión de indices_reservas_bloqueos. Prisma no ejecuta este archivo: se aplica
-- a mano y luego se puede volver a migrar con `npm run prisma:deploy`.
--
--   npx prisma db execute --file prisma/migrations/20261109080000_indices_reservas_bloqueos/down.sql
--
-- Solo borra los dos índices; no afecta a los datos. Los datos de prueba que carga
-- `npm run db:seed` no se revierten aquí.

BEGIN;

DROP INDEX "Reservas_bien_id_estado_fecha_inicio_fecha_fin_idx";
DROP INDEX "BloqueosFecha_bien_id_fecha_inicio_fecha_fin_idx";

-- Permite que `prisma migrate deploy` vuelva a aplicar la migración.
DELETE FROM "_prisma_migrations"
WHERE "migration_name" = '20261109080000_indices_reservas_bloqueos';

COMMIT;
