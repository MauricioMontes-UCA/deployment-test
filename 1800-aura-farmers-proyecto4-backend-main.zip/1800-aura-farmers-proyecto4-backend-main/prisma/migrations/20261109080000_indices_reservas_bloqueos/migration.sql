-- DB-24.1: índices que respaldan el cálculo de la tasa de ocupación (H24). No se
-- crean tablas ni columnas.

-- CreateIndex
CREATE INDEX "BloqueosFecha_bien_id_fecha_inicio_fecha_fin_idx" ON "BloqueosFecha"("bien_id", "fecha_inicio", "fecha_fin");

-- CreateIndex
CREATE INDEX "Reservas_bien_id_estado_fecha_inicio_fecha_fin_idx" ON "Reservas"("bien_id", "estado", "fecha_inicio", "fecha_fin");

