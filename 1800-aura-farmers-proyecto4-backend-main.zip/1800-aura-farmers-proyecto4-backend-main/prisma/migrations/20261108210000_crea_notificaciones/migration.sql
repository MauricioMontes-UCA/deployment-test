-- DB-20.1: crea los avisos con control de duplicados.
--
-- Reversión: down.sql, en esta misma carpeta.

-- CreateEnum
CREATE TYPE "ModuloOrigen" AS ENUM ('RESERVAS', 'PAGOS', 'MENSAJERIA', 'RESENAS', 'VERIFICACION');

-- CreateEnum
CREATE TYPE "EstadoNotificacion" AS ENUM ('NO_LEIDA', 'LEIDA');

-- CreateTable
CREATE TABLE "Notificaciones" (
    "id" UUID NOT NULL,
    "destinatario_id" UUID NOT NULL,
    "modulo_origen" "ModuloOrigen" NOT NULL,
    "titulo" VARCHAR(100) NOT NULL,
    "mensaje" VARCHAR(300) NOT NULL,
    "tipo_referencia" VARCHAR(40),
    "referencia_id" VARCHAR(36),
    "estado" "EstadoNotificacion" NOT NULL DEFAULT 'NO_LEIDA',
    "creada_en" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "leida_en" TIMESTAMPTZ(6),
    "updated_at" TIMESTAMPTZ(6) NOT NULL,

    CONSTRAINT "Notificaciones_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "Notificaciones_destinatario_id_estado_creada_en_idx" ON "Notificaciones"("destinatario_id", "estado", "creada_en" DESC);

-- PostgreSQL trata los NULL como distintos, así que este índice solo impide
-- duplicados cuando el aviso tiene referencia.
-- CreateIndex
CREATE UNIQUE INDEX "Notificaciones_referencia_key" ON "Notificaciones"("destinatario_id", "tipo_referencia", "referencia_id");

-- Decisión técnica: DB-20.1 no define qué pasa al borrar un usuario. Se usa
-- RESTRICT porque los avisos no se eliminan en esta entrega.
-- AddForeignKey
ALTER TABLE "Notificaciones" ADD CONSTRAINT "Notificaciones_destinatario_id_fkey" FOREIGN KEY ("destinatario_id") REFERENCES "Usuarios"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- DB-20.1: restricción que Prisma no genera.
ALTER TABLE "Notificaciones"
    ADD CONSTRAINT "Notificaciones_referencia_completa_check"
        CHECK (("tipo_referencia" IS NULL) = ("referencia_id" IS NULL));
