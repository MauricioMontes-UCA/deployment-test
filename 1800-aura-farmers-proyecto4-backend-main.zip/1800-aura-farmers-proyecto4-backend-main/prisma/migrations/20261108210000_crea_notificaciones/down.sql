-- Reversión de crea_notificaciones. Prisma no ejecuta este archivo:
-- se aplica a mano y luego se puede volver a migrar con `npm run prisma:deploy`.
--
--   npx prisma db execute --file prisma/migrations/20261108210000_crea_notificaciones/down.sql
--
-- Borra todos los avisos.

BEGIN;

DROP TABLE "Notificaciones";

DROP TYPE "EstadoNotificacion";
DROP TYPE "ModuloOrigen";

-- Permite que `prisma migrate deploy` vuelva a aplicar la migración.
DELETE FROM "_prisma_migrations"
WHERE "migration_name" = '20261108210000_crea_notificaciones';

COMMIT;
