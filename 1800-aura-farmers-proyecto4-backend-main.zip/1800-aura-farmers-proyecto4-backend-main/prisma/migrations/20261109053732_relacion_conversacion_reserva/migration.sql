CREATE UNIQUE INDEX "Conversaciones_reserva_id_key"
ON "Conversaciones" ("reserva_id");

CREATE OR REPLACE FUNCTION validar_conversacion_reserva()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
    v_bien_id UUID;
    v_arrendatario_id UUID;
    v_arrendador_id UUID;
BEGIN
    IF NEW.reserva_id IS NULL THEN
        RETURN NEW;
    END IF;

    SELECT r.bien_id, r.arrendatario_id, b.arrendador_id
    INTO v_bien_id, v_arrendatario_id, v_arrendador_id
    FROM "Reservas" r
    JOIN "Bienes" b ON b.id = r.bien_id
    WHERE r.id = NEW.reserva_id
    FOR SHARE OF r, b;

    IF NOT FOUND THEN
        RAISE EXCEPTION
            'La reserva asociada no existe'
            USING ERRCODE = '23503';
    END IF;

    IF NEW.bien_id IS DISTINCT FROM v_bien_id
       OR NEW.arrendatario_id IS DISTINCT FROM v_arrendatario_id
       OR NEW.arrendador_id IS DISTINCT FROM v_arrendador_id
    THEN
        RAISE EXCEPTION
            'La conversacion no coincide con el bien o participantes de la reserva'
            USING ERRCODE = '23514';
    END IF;

    RETURN NEW;
END;
$$;

CREATE TRIGGER "trg_validar_conversacion_reserva"
BEFORE INSERT OR UPDATE OF
    reserva_id,
    bien_id,
    arrendador_id,
    arrendatario_id
ON "Conversaciones"
FOR EACH ROW
EXECUTE FUNCTION validar_conversacion_reserva();

CREATE OR REPLACE FUNCTION validar_reserva_conversacion()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
    IF EXISTS (
        SELECT 1
        FROM "Conversaciones" c
        JOIN "Bienes" b ON b.id = NEW.bien_id
        WHERE c.reserva_id = NEW.id
          AND (
              c.bien_id IS DISTINCT FROM NEW.bien_id
              OR c.arrendatario_id IS DISTINCT FROM NEW.arrendatario_id
              OR c.arrendador_id IS DISTINCT FROM b.arrendador_id
          )
    ) THEN
        RAISE EXCEPTION
            'La actualizacion de reserva contradice su conversacion'
            USING ERRCODE = '23514';
    END IF;

    RETURN NEW;
END;
$$;

CREATE TRIGGER "trg_validar_reserva_conversacion"
BEFORE UPDATE OF bien_id, arrendatario_id
ON "Reservas"
FOR EACH ROW
EXECUTE FUNCTION validar_reserva_conversacion();

CREATE OR REPLACE FUNCTION validar_bien_conversaciones()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
    IF EXISTS (
        SELECT 1
        FROM "Conversaciones" c
        WHERE c.bien_id = NEW.id
          AND c.reserva_id IS NOT NULL
          AND c.arrendador_id IS DISTINCT FROM NEW.arrendador_id
    ) THEN
        RAISE EXCEPTION
            'El cambio de propietario contradice conversaciones de reservas'
            USING ERRCODE = '23514';
    END IF;

    RETURN NEW;
END;
$$;

CREATE TRIGGER "trg_validar_bien_conversaciones"
BEFORE UPDATE OF arrendador_id
ON "Bienes"
FOR EACH ROW
EXECUTE FUNCTION validar_bien_conversaciones();