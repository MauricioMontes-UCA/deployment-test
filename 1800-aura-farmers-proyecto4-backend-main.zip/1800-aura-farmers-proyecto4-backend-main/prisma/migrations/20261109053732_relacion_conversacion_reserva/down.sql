BEGIN;

DROP TRIGGER IF EXISTS "trg_validar_bien_conversaciones"
ON "Bienes";

DROP FUNCTION IF EXISTS validar_bien_conversaciones();

DROP TRIGGER IF EXISTS "trg_validar_reserva_conversacion"
ON "Reservas";

DROP FUNCTION IF EXISTS validar_reserva_conversacion();

DROP TRIGGER IF EXISTS "trg_validar_conversacion_reserva"
ON "Conversaciones";

DROP FUNCTION IF EXISTS validar_conversacion_reserva();

DROP INDEX IF EXISTS "Conversaciones_reserva_id_key";

DELETE FROM "_prisma_migrations"
WHERE "migration_name" = '20261109053732_relacion_conversacion_reserva';

COMMIT;