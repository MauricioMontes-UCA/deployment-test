-- CreateTable
CREATE TABLE "PoliticasVerificacionBien" (
    "bien_id" UUID NOT NULL,
    "solo_verificados" BOOLEAN NOT NULL DEFAULT false,
    "actualizado_en" TIMESTAMPTZ(6) NOT NULL,

    CONSTRAINT "PoliticasVerificacionBien_pkey" PRIMARY KEY ("bien_id")
);

-- AddForeignKey
ALTER TABLE "PoliticasVerificacionBien" ADD CONSTRAINT "PoliticasVerificacionBien_bien_id_fkey" FOREIGN KEY ("bien_id") REFERENCES "Bienes"("id") ON DELETE CASCADE ON UPDATE CASCADE;
