-- Reversión de crea_politicas_verificacion_bien. Prisma no ejecuta este archivo:
-- se aplica a mano y luego se puede volver a migrar con `npm run prisma:deploy`.
--
--   npx prisma db execute --file prisma/migrations/20261108220000_crea_politicas_verificacion_bien/down.sql
--
-- Borra todas las políticas de verificación. Los bienes se conservan.

BEGIN;

DROP TABLE "PoliticasVerificacionBien";

-- Permite que `prisma migrate deploy` vuelva a aplicar la migración.
DELETE FROM "_prisma_migrations"
WHERE "migration_name" = '20261108220000_crea_politicas_verificacion_bien';

COMMIT;
