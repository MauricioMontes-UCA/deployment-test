-- Reversión de indices_filtros_bienes. Prisma no ejecuta este archivo:
-- se aplica a mano y luego se puede volver a migrar con `npm run prisma:deploy`.
--
--   npx prisma db execute --file prisma/migrations/20261108200000_indices_filtros_bienes/down.sql

BEGIN;

DROP INDEX "idx_bienes_capacidad";
DROP INDEX "idx_bienes_filtros";

-- Permite que `prisma migrate deploy` vuelva a aplicar la migración.
DELETE FROM "_prisma_migrations"
WHERE "migration_name" = '20261108200000_indices_filtros_bienes';

COMMIT;
