-- DB-4.1: índices para combinar los filtros de búsqueda de bienes.
-- Prisma no modela índices parciales, así que se escriben a mano.
-- Reversión: down.sql, en esta misma carpeta.

CREATE INDEX "idx_bienes_filtros" ON "Bienes" ("tipo", "categoria", "precio")
    WHERE "estado" = 'ACTIVA';

CREATE INDEX "idx_bienes_capacidad" ON "Bienes" ("capacidad")
    WHERE "capacidad" IS NOT NULL;
