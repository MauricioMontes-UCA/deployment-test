-- Reversión de busqueda_bienes. Prisma no ejecuta este archivo:
-- se aplica a mano y luego se puede volver a migrar con `npm run prisma:deploy`.
--
--   npx prisma db execute --file prisma/migrations/20261108190000_busqueda_bienes/down.sql

BEGIN;

DROP INDEX "idx_bienes_ubicacion";
DROP INDEX "idx_bienes_busqueda";
ALTER TABLE "Bienes" DROP COLUMN "busqueda";
DROP FUNCTION f_unaccent(text);
DROP EXTENSION unaccent;

-- Permite que `prisma migrate deploy` vuelva a aplicar la migración.
DELETE FROM "_prisma_migrations"
WHERE "migration_name" = '20261108190000_busqueda_bienes';

COMMIT;
