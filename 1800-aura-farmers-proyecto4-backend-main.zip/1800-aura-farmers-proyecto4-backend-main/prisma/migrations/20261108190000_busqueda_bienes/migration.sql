-- DB-3.1: búsqueda de texto completo en español sobre los bienes.
-- Prisma no modela extensiones, columnas generadas ni estos índices, así que
-- esta migración se escribe a mano. Reversión: down.sql, en esta misma carpeta.

CREATE EXTENSION IF NOT EXISTS unaccent;

-- `unaccent` es STABLE y una columna generada solo admite funciones IMMUTABLE.
-- Fijar el diccionario y el esquema hace que el resultado no dependa de la sesión.
CREATE FUNCTION f_unaccent(text) RETURNS text AS $$
    SELECT public.unaccent('public.unaccent'::regdictionary, $1)
$$ LANGUAGE sql IMMUTABLE PARALLEL SAFE STRICT;

-- El título pesa más que la descripción (A sobre B) para ordenar por relevancia.
ALTER TABLE "Bienes" ADD COLUMN "busqueda" tsvector GENERATED ALWAYS AS (
    setweight(to_tsvector('spanish', f_unaccent("titulo")), 'A') ||
    setweight(to_tsvector('spanish', f_unaccent("descripcion")), 'B')
) STORED;

CREATE INDEX "idx_bienes_busqueda" ON "Bienes" USING GIN ("busqueda");

CREATE INDEX "idx_bienes_ubicacion" ON "Bienes" ("departamento", "municipio")
    WHERE "estado" = 'ACTIVA';
