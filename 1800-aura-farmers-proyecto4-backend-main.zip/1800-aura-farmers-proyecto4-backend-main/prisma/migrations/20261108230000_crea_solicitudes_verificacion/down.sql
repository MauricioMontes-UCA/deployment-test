-- Reversión de crea_solicitudes_verificacion. Prisma no ejecuta este archivo:
-- se aplica a mano y luego se puede volver a migrar con `npm run prisma:deploy`.
--
--   npx prisma db execute --file prisma/migrations/20261108230000_crea_solicitudes_verificacion/down.sql
--
-- Borra todas las solicitudes de verificación y sus documentos.

BEGIN;

-- Al borrar las tablas también se borran sus índices (incluido el único parcial
-- solicitud_una_en_revision) y el CHECK del tamaño.
DROP TABLE "DocumentosVerificacion";
DROP TABLE "SolicitudesVerificacion";

DROP TYPE "EstadoSolicitudVerificacion";

-- Permite que `prisma migrate deploy` vuelva a aplicar la migración.
DELETE FROM "_prisma_migrations"
WHERE "migration_name" = '20261108230000_crea_solicitudes_verificacion';

COMMIT;
