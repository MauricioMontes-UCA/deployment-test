-- CreateEnum
CREATE TYPE "EstadoSolicitudVerificacion" AS ENUM ('EN_REVISION', 'APROBADA', 'RECHAZADA');

-- CreateTable
CREATE TABLE "SolicitudesVerificacion" (
    "id" UUID NOT NULL,
    "usuario_id" UUID NOT NULL,
    "estado" "EstadoSolicitudVerificacion" NOT NULL DEFAULT 'EN_REVISION',
    "motivo" VARCHAR(200),
    "revisado_en" TIMESTAMPTZ(6),
    "creada_en" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "SolicitudesVerificacion_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "DocumentosVerificacion" (
    "id" UUID NOT NULL,
    "solicitud_id" UUID NOT NULL,
    "nombre_archivo" VARCHAR(255) NOT NULL,
    "contenido" BYTEA NOT NULL,
    "mime_type" VARCHAR(100) NOT NULL,
    "tamano_bytes" INTEGER NOT NULL,

    CONSTRAINT "DocumentosVerificacion_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "SolicitudesVerificacion_usuario_id_creada_en_idx" ON "SolicitudesVerificacion"("usuario_id", "creada_en" DESC);

-- CreateIndex
CREATE UNIQUE INDEX "DocumentosVerificacion_solicitud_id_key" ON "DocumentosVerificacion"("solicitud_id");

-- AddForeignKey
ALTER TABLE "SolicitudesVerificacion" ADD CONSTRAINT "SolicitudesVerificacion_usuario_id_fkey" FOREIGN KEY ("usuario_id") REFERENCES "Usuarios"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "DocumentosVerificacion" ADD CONSTRAINT "DocumentosVerificacion_solicitud_id_fkey" FOREIGN KEY ("solicitud_id") REFERENCES "SolicitudesVerificacion"("id") ON DELETE CASCADE ON UPDATE CASCADE;



-- DB-17.1: restricciones que Prisma no genera.

-- Un usuario no puede tener más de una solicitud EN_REVISION a la vez. Las
-- solicitudes APROBADA y RECHAZADA no cuentan, así que puede haber varias.
CREATE UNIQUE INDEX "solicitud_una_en_revision"
    ON "SolicitudesVerificacion" ("usuario_id")
    WHERE "estado" = 'EN_REVISION';

-- El documento no puede superar 5 MB (5 * 1024 * 1024 bytes).
ALTER TABLE "DocumentosVerificacion"
    ADD CONSTRAINT "DocumentosVerificacion_tamano_check" CHECK ("tamano_bytes" <= 5242880);
