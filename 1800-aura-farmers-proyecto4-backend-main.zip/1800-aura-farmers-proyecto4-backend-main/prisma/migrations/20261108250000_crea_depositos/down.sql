-- Reversión de crea_depositos. Prisma no ejecuta este archivo: se aplica a mano y
-- luego se puede volver a migrar con `npm run prisma:deploy`.
--
--   npx prisma db execute --file prisma/migrations/20261108250000_crea_depositos/down.sql
--
-- Borra todos los depósitos.

BEGIN;

-- Al borrar la tabla también se borran sus CHECK e índices.
DROP TABLE "Depositos";

DROP TYPE "EstadoDeposito";

-- Permite que `prisma migrate deploy` vuelva a aplicar la migración.
DELETE FROM "_prisma_migrations"
WHERE "migration_name" = '20261108250000_crea_depositos';

COMMIT;
