-- CreateEnum
CREATE TYPE "EstadoDeposito" AS ENUM ('PENDIENTE', 'LIBERADO', 'RETENIDO', 'PARCIALMENTE_RETENIDO');

-- CreateTable
CREATE TABLE "Depositos" (
    "id" UUID NOT NULL,
    "reserva_id" UUID NOT NULL,
    "resuelto_por" UUID,
    "importe_original" DECIMAL(12,2) NOT NULL,
    "importe_retenido" DECIMAL(12,2) NOT NULL DEFAULT 0,
    "importe_liberado" DECIMAL(12,2) NOT NULL DEFAULT 0,
    "estado" "EstadoDeposito" NOT NULL DEFAULT 'PENDIENTE',
    "justificacion" VARCHAR(500),
    "fecha_resolucion" TIMESTAMPTZ(6),
    "resolucion_automatica" BOOLEAN NOT NULL DEFAULT false,
    "plazo_resolucion" TIMESTAMPTZ(6),
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMPTZ(6) NOT NULL,

    CONSTRAINT "Depositos_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "Depositos_reserva_id_key" ON "Depositos"("reserva_id");

-- AddForeignKey
ALTER TABLE "Depositos" ADD CONSTRAINT "Depositos_reserva_id_fkey" FOREIGN KEY ("reserva_id") REFERENCES "Reservas"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Depositos" ADD CONSTRAINT "Depositos_resuelto_por_fkey" FOREIGN KEY ("resuelto_por") REFERENCES "Usuarios"("id") ON DELETE RESTRICT ON UPDATE CASCADE;




-- DB-11.1: restricciones que Prisma no genera.

ALTER TABLE "Depositos"
    ADD CONSTRAINT "Depositos_importes_check" CHECK (
        "importe_original" >= 0 AND "importe_retenido" >= 0 AND "importe_liberado" >= 0
    );

-- Lo retenido más lo liberado nunca puede superar el importe original. Un
-- depósito PENDIENTE tiene ambos en 0.
ALTER TABLE "Depositos"
    ADD CONSTRAINT "Depositos_suma_check" CHECK (
        "importe_retenido" + "importe_liberado" <= "importe_original"
    );
