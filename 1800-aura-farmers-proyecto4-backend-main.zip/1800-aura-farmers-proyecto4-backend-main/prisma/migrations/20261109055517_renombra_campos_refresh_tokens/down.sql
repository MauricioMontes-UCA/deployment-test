-- Reversión de renombra_campos_refresh_tokens. Prisma no ejecuta este archivo:
-- se aplica a mano y luego se puede volver a migrar con `npm run prisma:deploy`.
--
--   npx prisma db execute --file prisma/migrations/20261109055517_renombra_campos_refresh_tokens/down.sql
--
-- Devuelve las columnas a sus nombres anteriores. Los tokens se conservan.

BEGIN;

ALTER TABLE "refresh_tokens" RENAME COLUMN "expira_en" TO "expires_at";
ALTER TABLE "refresh_tokens" RENAME COLUMN "revocado_en" TO "revoked_at";
ALTER TABLE "refresh_tokens" RENAME COLUMN "creado_en" TO "created_at";

-- Permite que `prisma migrate deploy` vuelva a aplicar la migración.
DELETE FROM "_prisma_migrations"
WHERE "migration_name" = '20261109055517_renombra_campos_refresh_tokens';

COMMIT;
