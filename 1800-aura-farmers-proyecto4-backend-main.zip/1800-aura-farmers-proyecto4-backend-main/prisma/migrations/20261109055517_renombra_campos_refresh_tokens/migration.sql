-- Pasa a español las columnas de fecha de refresh_tokens. Son renombres: los
-- tokens existentes se conservan.
ALTER TABLE "refresh_tokens" RENAME COLUMN "expires_at" TO "expira_en";
ALTER TABLE "refresh_tokens" RENAME COLUMN "revoked_at" TO "revocado_en";
ALTER TABLE "refresh_tokens" RENAME COLUMN "created_at" TO "creado_en";
