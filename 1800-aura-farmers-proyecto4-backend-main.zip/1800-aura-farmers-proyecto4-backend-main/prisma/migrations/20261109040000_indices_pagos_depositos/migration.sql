-- DB-23.1: índices que respaldan el reporte de ingresos (H23 a H26). No se crean
-- tablas ni columnas. Son parciales, así que Prisma no puede expresarlos en el
-- schema y solo existen en esta migración.

-- Ingresos: suma de importe_alquiler de los pagos aprobados dentro de un periodo.
CREATE INDEX "idx_pago_exitoso_fecha"
    ON "Pagos" ("fecha_hora")
    WHERE "estado" = 'SIMULADO_EXITOSO';

-- Depósito retenido: suma de importe_retenido de los depósitos resueltos como
-- RETENIDO o PARCIALMENTE_RETENIDO dentro de un periodo.
CREATE INDEX "idx_deposito_retenido_fecha"
    ON "Depositos" ("fecha_resolucion")
    WHERE "estado" IN ('RETENIDO', 'PARCIALMENTE_RETENIDO');
