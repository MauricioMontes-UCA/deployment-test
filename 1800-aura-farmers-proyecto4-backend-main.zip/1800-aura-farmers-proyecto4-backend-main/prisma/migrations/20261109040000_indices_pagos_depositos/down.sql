-- Reversión de indices_pagos_depositos. Prisma no ejecuta este archivo: se aplica
-- a mano y luego se puede volver a migrar con `npm run prisma:deploy`.
--
--   npx prisma db execute --file prisma/migrations/20261109040000_indices_pagos_depositos/down.sql
--
-- Solo borra los dos índices; no afecta a los datos. Los datos de prueba que carga
-- `npm run db:seed` no se revierten aquí.

BEGIN;

DROP INDEX "idx_deposito_retenido_fecha";
DROP INDEX "idx_pago_exitoso_fecha";

-- Permite que `prisma migrate deploy` vuelva a aplicar la migración.
DELETE FROM "_prisma_migrations"
WHERE "migration_name" = '20261109040000_indices_pagos_depositos';

COMMIT;
