CREATE TABLE "Conversaciones" (
    "id" UUID NOT NULL,
    "bien_id" UUID NOT NULL,
    "reserva_id" UUID,
    "arrendador_id" UUID NOT NULL,
    "arrendatario_id" UUID NOT NULL,
    "creada_en" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMPTZ(6) NOT NULL,

    CONSTRAINT "Conversaciones_pkey" PRIMARY KEY ("id"),

    CONSTRAINT "Conversaciones_participantes_distintos_chk"
        CHECK ("arrendador_id" <> "arrendatario_id")
);

CREATE TABLE "Mensajes" (
    "id" UUID NOT NULL,
    "conversacion_id" UUID NOT NULL,
    "remitente_id" UUID NOT NULL,
    "contenido" VARCHAR(1000) NOT NULL,
    "creado_en" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "Mensajes_pkey" PRIMARY KEY ("id"),

    CONSTRAINT "Mensajes_contenido_valido_chk"
        CHECK (
            char_length(btrim("contenido")) BETWEEN 1 AND 1000
        )
);

CREATE UNIQUE INDEX "Conversaciones_previa_unica_idx"
ON "Conversaciones" ("bien_id", "arrendatario_id")
WHERE "reserva_id" IS NULL;

CREATE INDEX "Conversaciones_bien_id_idx"
ON "Conversaciones" ("bien_id");

CREATE INDEX "Conversaciones_arrendador_id_idx"
ON "Conversaciones" ("arrendador_id");

CREATE INDEX "Conversaciones_arrendatario_id_idx"
ON "Conversaciones" ("arrendatario_id");

CREATE INDEX "Mensajes_conversacion_id_creado_en_id_idx"
ON "Mensajes" ("conversacion_id", "creado_en", "id");

CREATE INDEX "Mensajes_remitente_id_idx"
ON "Mensajes" ("remitente_id");

ALTER TABLE "Conversaciones"
ADD CONSTRAINT "Conversaciones_bien_id_fkey"
FOREIGN KEY ("bien_id")
REFERENCES "Bienes" ("id")
ON DELETE RESTRICT
ON UPDATE CASCADE;

ALTER TABLE "Conversaciones"
ADD CONSTRAINT "Conversaciones_arrendador_id_fkey"
FOREIGN KEY ("arrendador_id")
REFERENCES "Usuarios" ("id")
ON DELETE RESTRICT
ON UPDATE CASCADE;

ALTER TABLE "Conversaciones"
ADD CONSTRAINT "Conversaciones_arrendatario_id_fkey"
FOREIGN KEY ("arrendatario_id")
REFERENCES "Usuarios" ("id")
ON DELETE RESTRICT
ON UPDATE CASCADE;

ALTER TABLE "Mensajes"
ADD CONSTRAINT "Mensajes_conversacion_id_fkey"
FOREIGN KEY ("conversacion_id")
REFERENCES "Conversaciones" ("id")
ON DELETE RESTRICT
ON UPDATE CASCADE;

ALTER TABLE "Mensajes"
ADD CONSTRAINT "Mensajes_remitente_id_fkey"
FOREIGN KEY ("remitente_id")
REFERENCES "Usuarios" ("id")
ON DELETE RESTRICT
ON UPDATE CASCADE;

ALTER TABLE "Conversaciones"
ADD CONSTRAINT "Conversaciones_reserva_id_fkey"
FOREIGN KEY ("reserva_id")
REFERENCES "Reservas" ("id")
ON DELETE RESTRICT
ON UPDATE CASCADE;