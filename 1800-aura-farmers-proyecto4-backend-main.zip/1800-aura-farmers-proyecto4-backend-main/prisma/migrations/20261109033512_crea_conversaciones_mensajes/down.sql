DROP TABLE IF EXISTS "Mensajes";

DROP TABLE IF EXISTS "Conversaciones";