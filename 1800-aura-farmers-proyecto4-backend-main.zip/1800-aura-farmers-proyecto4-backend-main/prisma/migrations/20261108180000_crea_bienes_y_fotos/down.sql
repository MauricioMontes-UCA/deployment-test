-- Reversión de crea_bienes_y_fotos. Prisma no ejecuta este archivo:
-- se aplica a mano y luego se puede volver a migrar con `npm run prisma:deploy`.
--
--   npx prisma db execute --file prisma/migrations/20261108180000_crea_bienes_y_fotos/down.sql
--
-- Borra todos los bienes y sus fotos.

BEGIN;

DROP TABLE "FotosBien";
DROP TABLE "Bienes";

DROP TYPE "EstadoBien";
DROP TYPE "UnidadCobro";
DROP TYPE "TipoBien";

-- Permite que `prisma migrate deploy` vuelva a aplicar la migración.
DELETE FROM "_prisma_migrations"
WHERE "migration_name" = '20261108180000_crea_bienes_y_fotos';

COMMIT;
