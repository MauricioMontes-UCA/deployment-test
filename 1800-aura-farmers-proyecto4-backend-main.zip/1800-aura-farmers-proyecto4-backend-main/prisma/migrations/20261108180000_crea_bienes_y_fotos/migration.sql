-- CreateEnum
CREATE TYPE "TipoBien" AS ENUM ('PROPIEDAD', 'EQUIPO');

-- CreateEnum
CREATE TYPE "UnidadCobro" AS ENUM ('HORA', 'DIA', 'NOCHE', 'SEMANA');

-- CreateEnum
CREATE TYPE "EstadoBien" AS ENUM ('ACTIVA', 'INACTIVA');

-- CreateTable
CREATE TABLE "Bienes" (
    "id" UUID NOT NULL,
    "arrendador_id" UUID NOT NULL,
    "tipo" "TipoBien" NOT NULL,
    "categoria" VARCHAR(50) NOT NULL,
    "titulo" VARCHAR(100) NOT NULL,
    "descripcion" VARCHAR(2000) NOT NULL,
    "precio" DECIMAL(12,2) NOT NULL,
    "unidad_cobro" "UnidadCobro" NOT NULL,
    "deposito" DECIMAL(12,2) NOT NULL DEFAULT 0,
    "capacidad" INTEGER,
    "condiciones" VARCHAR(1000),
    "departamento" VARCHAR(50) NOT NULL,
    "municipio" VARCHAR(80) NOT NULL,
    "direccion_referencia" VARCHAR(200),
    "estado" "EstadoBien" NOT NULL DEFAULT 'ACTIVA',
    "creado_en" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "actualizado_en" TIMESTAMPTZ(6) NOT NULL,

    CONSTRAINT "Bienes_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "FotosBien" (
    "id" UUID NOT NULL,
    "bien_id" UUID NOT NULL,
    "url" VARCHAR(500) NOT NULL,
    "orden" SMALLINT NOT NULL,
    "es_principal" BOOLEAN NOT NULL DEFAULT false,
    "creado_en" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "FotosBien_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "FotosBien_bien_id_orden_key" ON "FotosBien"("bien_id", "orden");

-- AddForeignKey
ALTER TABLE "Bienes" ADD CONSTRAINT "Bienes_arrendador_id_fkey" FOREIGN KEY ("arrendador_id") REFERENCES "Usuarios"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "FotosBien" ADD CONSTRAINT "FotosBien_bien_id_fkey" FOREIGN KEY ("bien_id") REFERENCES "Bienes"("id") ON DELETE CASCADE ON UPDATE CASCADE;



-- DB-1.1: restricciones que Prisma no genera.
ALTER TABLE "Bienes"
    ADD CONSTRAINT "Bienes_precio_check" CHECK ("precio" > 0),
    ADD CONSTRAINT "Bienes_deposito_check" CHECK ("deposito" >= 0),
    ADD CONSTRAINT "Bienes_capacidad_check" CHECK ("capacidad" IS NULL OR "capacidad" > 0),
    ADD CONSTRAINT "Bienes_titulo_check" CHECK (char_length("titulo") BETWEEN 5 AND 100);

-- Una sola foto principal por bien.
CREATE UNIQUE INDEX "FotosBien_una_principal_key" ON "FotosBien"("bien_id") WHERE "es_principal";
