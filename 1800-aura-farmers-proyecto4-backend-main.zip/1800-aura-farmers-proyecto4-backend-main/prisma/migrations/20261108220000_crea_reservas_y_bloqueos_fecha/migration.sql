-- CreateEnum
CREATE TYPE "EstadoReserva" AS ENUM ('EN_COLA', 'CONFIRMADA', 'RECHAZADA', 'EN_CURSO', 'FINALIZADA', 'CANCELADA');

-- CreateTable
CREATE TABLE "Reservas" (
    "id" UUID NOT NULL,
    "bien_id" UUID NOT NULL,
    "arrendatario_id" UUID NOT NULL,
    "fecha_inicio" DATE NOT NULL,
    "fecha_fin" DATE NOT NULL,
    "estado" "EstadoReserva" NOT NULL DEFAULT 'EN_COLA',
    "motivo_resolucion" VARCHAR(200),
    "creada_en" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "procesada_en" TIMESTAMPTZ(6),

    CONSTRAINT "Reservas_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "BloqueosFecha" (
    "id" UUID NOT NULL,
    "bien_id" UUID NOT NULL,
    "fecha_inicio" DATE NOT NULL,
    "fecha_fin" DATE NOT NULL,
    "creado_en" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "BloqueosFecha_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "Reservas_bien_id_fecha_inicio_idx" ON "Reservas"("bien_id", "fecha_inicio");

-- CreateIndex
CREATE INDEX "BloqueosFecha_bien_id_fecha_inicio_idx" ON "BloqueosFecha"("bien_id", "fecha_inicio");

-- AddForeignKey
ALTER TABLE "Reservas" ADD CONSTRAINT "Reservas_bien_id_fkey" FOREIGN KEY ("bien_id") REFERENCES "Bienes"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Reservas" ADD CONSTRAINT "Reservas_arrendatario_id_fkey" FOREIGN KEY ("arrendatario_id") REFERENCES "Usuarios"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "BloqueosFecha" ADD CONSTRAINT "BloqueosFecha_bien_id_fkey" FOREIGN KEY ("bien_id") REFERENCES "Bienes"("id") ON DELETE CASCADE ON UPDATE CASCADE;



-- DB-5.1: restricciones que Prisma no genera.

-- Los rangos son de días completos e inclusivos: fecha_fin es el último día ocupado.
ALTER TABLE "Reservas"
    ADD CONSTRAINT "Reservas_fechas_check" CHECK ("fecha_fin" >= "fecha_inicio");

ALTER TABLE "BloqueosFecha"
    ADD CONSTRAINT "BloqueosFecha_fechas_check" CHECK ("fecha_fin" >= "fecha_inicio");

-- btree_gist permite combinar la igualdad de bien_id (uuid) con el solape de
-- rangos dentro de un mismo índice GiST.
CREATE EXTENSION IF NOT EXISTS btree_gist;

-- Impide que un bien tenga dos reservas CONFIRMADA, EN_CURSO o FINALIZADA con
-- días en común, en cualquier combinación de esos estados. Las reservas EN_COLA,
-- RECHAZADA y CANCELADA no entran en la restricción y pueden solaparse.
-- El nombre reserva_sin_solape es el que BE-6.2 espera al capturar el error.
ALTER TABLE "Reservas"
    ADD CONSTRAINT "reserva_sin_solape" EXCLUDE USING gist (
        "bien_id" WITH =,
        daterange("fecha_inicio", "fecha_fin", '[]') WITH &&
    )
    WHERE ("estado" IN ('CONFIRMADA', 'EN_CURSO', 'FINALIZADA'));
