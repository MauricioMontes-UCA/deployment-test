-- Reversión de crea_reservas_y_bloqueos_fecha. Prisma no ejecuta este archivo:
-- se aplica a mano y luego se puede volver a migrar con `npm run prisma:deploy`.
--
--   npx prisma db execute --file prisma/migrations/20261108220000_crea_reservas_y_bloqueos_fecha/down.sql
--
-- Borra todas las reservas y los bloqueos de fechas.

BEGIN;

-- Al borrar la tabla también se borran sus CHECK, índices y la restricción de
-- exclusión.
DROP TABLE "BloqueosFecha";
DROP TABLE "Reservas";

DROP TYPE "EstadoReserva";
DROP EXTENSION btree_gist;

-- Permite que `prisma migrate deploy` vuelva a aplicar la migración.
DELETE FROM "_prisma_migrations"
WHERE "migration_name" = '20261108220000_crea_reservas_y_bloqueos_fecha';

COMMIT;
