-- CreateEnum
CREATE TYPE "TipoResena" AS ENUM ('BIEN', 'ARRENDADOR', 'ARRENDATARIO');

-- CreateTable
CREATE TABLE "Resenas" (
    "id" UUID NOT NULL,
    "reserva_id" UUID NOT NULL,
    "autor_id" UUID NOT NULL,
    "tipo" "TipoResena" NOT NULL,
    "puntuacion" INTEGER NOT NULL,
    "comentario" VARCHAR(500),
    "creada_en" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "Resenas_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "Resenas_reserva_id_idx" ON "Resenas"("reserva_id");

-- CreateIndex
CREATE UNIQUE INDEX "Resenas_reserva_id_tipo_key" ON "Resenas"("reserva_id", "tipo");

-- AddForeignKey
ALTER TABLE "Resenas" ADD CONSTRAINT "Resenas_reserva_id_fkey" FOREIGN KEY ("reserva_id") REFERENCES "Reservas"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Resenas" ADD CONSTRAINT "Resenas_autor_id_fkey" FOREIGN KEY ("autor_id") REFERENCES "Usuarios"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- DB-15.1: restricción que Prisma no genera.
ALTER TABLE "Resenas"
    ADD CONSTRAINT "Resenas_puntuacion_check" CHECK ("puntuacion" BETWEEN 1 AND 5);
