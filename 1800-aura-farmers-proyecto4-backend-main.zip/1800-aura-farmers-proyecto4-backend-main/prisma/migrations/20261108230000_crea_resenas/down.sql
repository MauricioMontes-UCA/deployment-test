-- Reversión de crea_resenas. Prisma no ejecuta este archivo:
-- se aplica a mano y luego se puede volver a migrar con `npm run prisma:deploy`.
--
--   npx prisma db execute --file prisma/migrations/20261108230000_crea_resenas/down.sql
--
-- Borra todas las reseñas. Las reservas y los usuarios se conservan.

BEGIN;

DROP TABLE "Resenas";

DROP TYPE "TipoResena";

-- Permite que `prisma migrate deploy` vuelva a aplicar la migración.
DELETE FROM "_prisma_migrations"
WHERE "migration_name" = '20261108230000_crea_resenas';

COMMIT;
