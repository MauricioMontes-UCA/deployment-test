-- La migración crea_conversaciones_mensajes creó dos columnas de fecha de
-- creación en Conversaciones: creada_en y created_at. Se conserva creada_en, que
-- es la que usa el schema. created_at se elimina; tenía el mismo valor por defecto
-- (CURRENT_TIMESTAMP), así que no se pierde información.
ALTER TABLE "Conversaciones" DROP COLUMN "created_at";
