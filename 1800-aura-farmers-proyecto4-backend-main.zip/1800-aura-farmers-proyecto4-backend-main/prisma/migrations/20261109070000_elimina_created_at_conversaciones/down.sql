-- Reversión de elimina_created_at_conversaciones. Prisma no ejecuta este archivo:
-- se aplica a mano y luego se puede volver a migrar con `npm run prisma:deploy`.
--
--   npx prisma db execute --file prisma/migrations/20261109070000_elimina_created_at_conversaciones/down.sql
--
-- Vuelve a crear created_at y la rellena con el valor de creada_en.

BEGIN;

ALTER TABLE "Conversaciones"
    ADD COLUMN "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP;
UPDATE "Conversaciones" SET "created_at" = "creada_en";

-- Permite que `prisma migrate deploy` vuelva a aplicar la migración.
DELETE FROM "_prisma_migrations"
WHERE "migration_name" = '20261109070000_elimina_created_at_conversaciones';

COMMIT;
