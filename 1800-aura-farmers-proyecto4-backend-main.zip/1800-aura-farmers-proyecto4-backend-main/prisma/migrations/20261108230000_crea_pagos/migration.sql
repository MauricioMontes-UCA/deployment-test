-- CreateEnum
CREATE TYPE "ModalidadPago" AS ENUM ('TARJETA', 'TRANSFERENCIA_BANCARIA');

-- CreateEnum
CREATE TYPE "EstadoPago" AS ENUM ('PENDIENTE', 'SIMULADO_EXITOSO', 'SIMULADO_RECHAZADO');

-- CreateTable
CREATE TABLE "Pagos" (
    "id" UUID NOT NULL,
    "reserva_id" UUID NOT NULL,
    "modalidad" "ModalidadPago" NOT NULL,
    "importe_alquiler" DECIMAL(12,2) NOT NULL,
    "importe_deposito" DECIMAL(12,2) NOT NULL,
    "total" DECIMAL(12,2) NOT NULL,
    "estado" "EstadoPago" NOT NULL DEFAULT 'PENDIENTE',
    "fecha_hora" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "comprobante_id" UUID,
    "referencia_simulada" VARCHAR(20),
    "ultimos_cuatro" CHAR(4),
    "motivo_rechazo" VARCHAR(200),
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMPTZ(6) NOT NULL,

    CONSTRAINT "Pagos_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "Pagos_comprobante_id_key" ON "Pagos"("comprobante_id");

-- CreateIndex
CREATE INDEX "Pagos_reserva_id_idx" ON "Pagos"("reserva_id");

-- AddForeignKey
ALTER TABLE "Pagos" ADD CONSTRAINT "Pagos_reserva_id_fkey" FOREIGN KEY ("reserva_id") REFERENCES "Reservas"("id") ON DELETE RESTRICT ON UPDATE CASCADE;



-- DB-8.1: restricciones que Prisma no genera.

ALTER TABLE "Pagos"
    ADD CONSTRAINT "Pagos_importes_check" CHECK (
        "importe_alquiler" >= 0 AND "importe_deposito" >= 0 AND "total" >= 0
    );

-- Impide dos pagos SIMULADO_EXITOSO para la misma reserva, también bajo
-- concurrencia: el segundo INSERT falla con el código 23505 y el nombre
-- Pagos_un_exitoso_por_reserva_key, que BE-8.1 traduce a 409. Los pagos
-- PENDIENTE y SIMULADO_RECHAZADO no entran en el índice y pueden repetirse.
CREATE UNIQUE INDEX "Pagos_un_exitoso_por_reserva_key"
    ON "Pagos"("reserva_id")
    WHERE "estado" = 'SIMULADO_EXITOSO';
