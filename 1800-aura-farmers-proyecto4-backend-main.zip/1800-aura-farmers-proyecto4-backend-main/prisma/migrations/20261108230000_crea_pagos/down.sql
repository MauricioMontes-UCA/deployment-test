-- Reversión de crea_pagos. Prisma no ejecuta este archivo: se aplica a mano y
-- luego se puede volver a migrar con `npm run prisma:deploy`.
--
--   npx prisma db execute --file prisma/migrations/20261108230000_crea_pagos/down.sql
--
-- Borra todos los pagos.

BEGIN;

-- Al borrar la tabla también se borran sus CHECK e índices.
DROP TABLE "Pagos";

DROP TYPE "EstadoPago";
DROP TYPE "ModalidadPago";

-- Permite que `prisma migrate deploy` vuelva a aplicar la migración.
DELETE FROM "_prisma_migrations"
WHERE "migration_name" = '20261108230000_crea_pagos';

COMMIT;
