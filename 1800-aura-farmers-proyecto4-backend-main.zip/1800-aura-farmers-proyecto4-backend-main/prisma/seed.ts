import 'dotenv/config';
import bcrypt from 'bcrypt';
import { PrismaPg } from '@prisma/adapter-pg';
import {
  EstadoDeposito,
  EstadoNotificacion,
  EstadoPago,
  EstadoReserva,
  ModalidadPago,
  ModuloOrigen,
  PrismaClient,
  Rol,
  TipoBien,
  TipoResena,
  UnidadCobro,
} from '../src/generated/prisma/client.js';
import { hoyEn, ZONA_HORARIA } from '../src/bienes/utils/fechas.js';

const DEMO_PASSWORD = 'Demo1234!';

const USUARIOS = [
  { email: 'demo@example.com', nombreUsuario: 'demo', rol: Rol.ARRENDATARIO },
  { email: 'arrendador@example.com', nombreUsuario: 'arrendador', rol: Rol.ARRENDADOR },
  { email: 'arrendador2@example.com', nombreUsuario: 'arrendador2', rol: Rol.ARRENDADOR },
];

// Ids fijos para que el upsert encuentre los mismos bienes en cada corrida.
const BIENES = [
  {
    id: '10000000-0000-4000-8000-000000000001',
    tipo: TipoBien.PROPIEDAD,
    categoria: 'Salón de eventos',
    titulo: 'Salón de eventos Las Palmas',
    descripcion: 'Salón climatizado con cocina, mobiliario y parqueo para eventos sociales.',
    precio: '80.00',
    unidadCobro: UnidadCobro.DIA,
    deposito: '0.00',
    capacidad: 150,
    condiciones: 'Entregar limpio y sin daños al finalizar el evento.',
    departamento: 'San Salvador',
    municipio: 'San Salvador',
    direccionReferencia: 'Frente al parque central',
    fotos: [
      '/uploads/bienes/salon-las-palmas-1.jpg',
      '/uploads/bienes/salon-las-palmas-2.jpg',
      '/uploads/bienes/salon-las-palmas-3.jpg',
    ],
  },
  {
    id: '10000000-0000-4000-8000-000000000002',
    tipo: TipoBien.EQUIPO,
    categoria: 'Herramientas',
    titulo: 'Taladro industrial',
    descripcion: 'Taladro percutor de uso industrial con juego de brocas.',
    precio: '12.00',
    unidadCobro: UnidadCobro.DIA,
    deposito: '25.00',
    capacidad: null,
    condiciones: 'Devolver con todas sus brocas.',
    departamento: 'La Libertad',
    municipio: 'Santa Tecla',
    direccionReferencia: null,
    fotos: ['/uploads/bienes/taladro-industrial-1.jpg'],
  },
];

// 30 bienes con títulos variados para probar la búsqueda y su paginación (DB-3.1).
const BIENES_BUSQUEDA = (
  [
    // tipo, categoría, título, descripción, precio, departamento, municipio, capacidad
    [TipoBien.PROPIEDAD, 'Casa', 'Casa de playa en El Tunco', 'Casa frente al mar con piscina y terraza amplia.', '120.00', 'La Libertad', 'Tamanique', 8],
    [TipoBien.PROPIEDAD, 'Casa', 'Casa de campo con jardín', 'Casa tranquila rodeada de árboles y con jardín privado.', '75.00', 'Santa Ana', 'Metapán', 6],
    [TipoBien.PROPIEDAD, 'Apartamento', 'Apartamento amueblado en Escalón', 'Apartamento céntrico con balcón, aire acondicionado y wifi.', '55.00', 'San Salvador', 'San Salvador', 4],
    [TipoBien.PROPIEDAD, 'Apartamento', 'Apartamento económico cerca de la universidad', 'Ideal para estudiantes, a pocos minutos del campus.', '30.00', 'La Libertad', 'Antiguo Cuscatlán', 2],
    [TipoBien.PROPIEDAD, 'Habitación', 'Habitación privada con baño', 'Habitación independiente en casa familiar y segura.', '18.00', 'San Salvador', 'Mejicanos', 1],
    [TipoBien.PROPIEDAD, 'Habitación', 'Habitación doble para viajeros', 'Cómoda habitación con dos camas y desayuno opcional.', '25.00', 'Sonsonate', 'Juayúa', 2],
    [TipoBien.PROPIEDAD, 'Salón de eventos', 'Salón para bodas Jardines del Lago', 'Salón con vista al lago, cocina y parqueo privado.', '250.00', 'Cuscatlán', 'Suchitoto', 200],
    [TipoBien.PROPIEDAD, 'Salón de eventos', 'Salón infantil Arcoíris', 'Espacio con juegos y decoración para cumpleaños.', '60.00', 'San Miguel', 'San Miguel', 40],
    [TipoBien.PROPIEDAD, 'Oficina', 'Oficina compartida en el centro', 'Puesto de trabajo con internet y sala de reuniones.', '15.00', 'San Salvador', 'San Salvador', 1],
    [TipoBien.PROPIEDAD, 'Oficina', 'Oficina ejecutiva con recepción', 'Oficina privada amueblada con servicio de recepción.', '45.00', 'La Libertad', 'Santa Tecla', 5],
    [TipoBien.PROPIEDAD, 'Local comercial', 'Local comercial sobre avenida principal', 'Local con vitrina amplia y alto tráfico peatonal.', '90.00', 'Santa Ana', 'Santa Ana', null],
    [TipoBien.PROPIEDAD, 'Bodega', 'Bodega industrial con rampa de carga', 'Bodega techada con rampa y seguridad las 24 horas.', '110.00', 'La Paz', 'Zacatecoluca', null],
    [TipoBien.PROPIEDAD, 'Bodega', 'Bodega pequeña para almacenaje', 'Espacio seco y seguro para guardar mercadería.', '20.00', 'Usulután', 'Usulután', null],
    [TipoBien.PROPIEDAD, 'Terreno', 'Terreno para ferias y eventos', 'Terreno plano con acceso vehicular y electricidad.', '70.00', 'Ahuachapán', 'Ahuachapán', null],
    [TipoBien.PROPIEDAD, 'Terreno', 'Terreno agrícola con riego', 'Parcela fértil con sistema de riego por goteo.', '35.00', 'Chalatenango', 'Chalatenango', null],
    [TipoBien.EQUIPO, 'Herramientas', 'Sierra circular profesional', 'Sierra eléctrica para madera con disco de repuesto.', '10.00', 'San Salvador', 'Soyapango', null],
    [TipoBien.EQUIPO, 'Herramientas', 'Juego de llaves y dados', 'Juego completo de herramientas para mecánica.', '6.00', 'La Libertad', 'Colón', null],
    [TipoBien.EQUIPO, 'Maquinaria de construcción', 'Mezcladora de concreto', 'Mezcladora eléctrica para obras medianas.', '40.00', 'San Salvador', 'Apopa', null],
    [TipoBien.EQUIPO, 'Maquinaria de construcción', 'Andamio metálico modular', 'Andamio resistente para trabajos en altura.', '22.00', 'Sonsonate', 'Sonsonate', null],
    [TipoBien.EQUIPO, 'Audio y sonido', 'Bocinas profesionales para eventos', 'Par de bocinas con consola y micrófonos inalámbricos.', '50.00', 'San Miguel', 'San Miguel', null],
    [TipoBien.EQUIPO, 'Audio y sonido', 'Micrófono inalámbrico de solapa', 'Micrófono para conferencias con batería recargable.', '8.00', 'San Salvador', 'Ayutuxtepeque', null],
    [TipoBien.EQUIPO, 'Video y fotografía', 'Cámara réflex con dos lentes', 'Cámara para sesiones de fotografía y video.', '35.00', 'Santa Ana', 'Santa Ana', null],
    [TipoBien.EQUIPO, 'Video y fotografía', 'Dron con cámara 4K', 'Dron estable para tomas aéreas de alta resolución.', '65.00', 'La Libertad', 'Zaragoza', null],
    [TipoBien.EQUIPO, 'Cómputo', 'Laptop para diseño gráfico', 'Computadora portátil con tarjeta gráfica dedicada.', '28.00', 'San Salvador', 'San Marcos', null],
    [TipoBien.EQUIPO, 'Cómputo', 'Proyector para presentaciones', 'Proyector portátil con cable HDMI y pantalla.', '14.00', 'Cuscatlán', 'Cojutepeque', null],
    [TipoBien.EQUIPO, 'Mobiliario para eventos', 'Sillas plegables para eventos', 'Lote de cincuenta sillas plegables de resina.', '30.00', 'San Vicente', 'San Vicente', null],
    [TipoBien.EQUIPO, 'Mobiliario para eventos', 'Mesas redondas con mantel', 'Mesas para banquetes con mantelería incluida.', '32.00', 'La Paz', 'Olocuilta', null],
    [TipoBien.EQUIPO, 'Deportes y recreación', 'Bicicletas de montaña', 'Par de bicicletas con casco para rutas de montaña.', '16.00', 'Morazán', 'Perquín', null],
    [TipoBien.EQUIPO, 'Deportes y recreación', 'Equipo de camping familiar', 'Carpa, sacos de dormir y linterna para acampar.', '20.00', 'Santa Ana', 'Metapán', null],
    [TipoBien.EQUIPO, 'Jardinería', 'Podadora de césped a gasolina', 'Podadora con bolsa recolectora para jardines grandes.', '18.00', 'La Libertad', 'Nuevo Cuscatlán', null],
  ] as const
).map(([tipo, categoria, titulo, descripcion, precio, departamento, municipio, capacidad], indice) => {
  const numero = String(indice + 1).padStart(2, '0');
  return {
    id: `20000000-0000-4000-8000-0000000000${numero}`,
    tipo,
    categoria,
    titulo,
    descripcion,
    precio,
    unidadCobro: UnidadCobro.DIA,
    deposito: '0.00',
    capacidad,
    condiciones: null,
    departamento,
    municipio,
    direccionReferencia: null,
    fotos: [`/uploads/bienes/busqueda-${numero}.jpg`],
  };
});

// Datos de prueba de H5: el primer bien tiene una reserva confirmada del
// usuario demo y un bloqueo del arrendador, sin días en común. Las fechas son
// días completos (columnas DATE) y el rango incluye el último día.
const RESERVA_CONFIRMADA = {
  id: '30000000-0000-4000-8000-000000000001',
  bienId: BIENES[0].id,
  fechaInicio: new Date('2026-12-10'),
  fechaFin: new Date('2026-12-12'),
  estado: EstadoReserva.CONFIRMADA,
};

const BLOQUEO_FECHA = {
  id: '40000000-0000-4000-8000-000000000001',
  bienId: BIENES[0].id,
  fechaInicio: new Date('2026-12-20'),
  fechaFin: new Date('2026-12-22'),
};

// Datos de prueba de H15: dos reservas finalizadas del usuario demo. Las fechas
// no tienen días en común porque reserva_sin_solape no permite solaparlas.
const RESERVA_CON_RESENA = {
  id: '50000000-0000-4000-8000-000000000001',
  bienId: BIENES[1].id,
  fechaInicio: new Date('2026-10-05'),
  fechaFin: new Date('2026-10-07'),
  estado: EstadoReserva.FINALIZADA,
};

const RESERVA_SIN_RESENA = {
  id: '50000000-0000-4000-8000-000000000002',
  bienId: BIENES[1].id,
  fechaInicio: new Date('2026-10-12'),
  fechaFin: new Date('2026-10-14'),
  estado: EstadoReserva.FINALIZADA,
};

const RESENA_BIEN = {
  reservaId: RESERVA_CON_RESENA.id,
  tipo: TipoResena.BIEN,
  puntuacion: 4,
  comentario: 'Funcionó bien y lo entregaron a tiempo.',
};

// Datos de prueba del panel de reportes (DB-23.1, H23 a H26). Las fechas son
// relativas al día de carga para que los periodos de 30, 90 y 365 días den
// siempre los mismos totales; cada corrida del seed las actualiza.
const MS_POR_DIA = 24 * 60 * 60 * 1000;

// Instante de hace n días, para fecha_hora de pagos y fecha_resolucion.
const haceDias = (n: number) => new Date(Date.now() - n * MS_POR_DIA);

// Día calendario de hoy menos n días, a medianoche UTC, para columnas DATE.
// "Hoy" es el día de El Salvador, el mismo que usan los reportes (BE-23.1): con
// el día de UTC, un seed cargado entre las 18:00 y la medianoche quedaba corrido
// un día y los criterios de H24 y H25 no se cumplían.
const diaHace = (n: number) => {
  const hoy = hoyEn(ZONA_HORARIA);
  return new Date(Date.UTC(hoy.getUTCFullYear(), hoy.getUTCMonth(), hoy.getUTCDate() - n));
};

const idIngresos = (prefijo: string, n: number) =>
  `${prefijo}-0000-4000-8000-${String(n).padStart(12, '0')}`;

// Bien n: 00000000-0000-4000-8000-00000000000n. Los bienes 1 a 4 son del
// arrendador A y el 5 del arrendador B. Todos nacen ACTIVA (el default).
const BIENES_INGRESOS = (
  [
    // arrendador, tipo, categoría, título, descripción, precio, depósito
    ['arrendador@example.com', TipoBien.PROPIEDAD, 'Salón de eventos', 'Salón de eventos', 'Salón amplio para eventos sociales y corporativos.', '25.00', '50.00'],
    ['arrendador@example.com', TipoBien.EQUIPO, 'Herramientas', 'Taladro industrial', 'Taladro percutor de uso industrial con juego de brocas.', '16.00', '25.00'],
    ['arrendador@example.com', TipoBien.EQUIPO, 'Cómputo', 'Proyector 4K', 'Proyector 4K con cable HDMI y pantalla portátil.', '20.00', '0.00'],
    ['arrendador@example.com', TipoBien.EQUIPO, 'Audio y sonido', 'Mesa de sonido', 'Mesa de sonido de ocho canales con cables.', '30.00', '0.00'],
    ['arrendador2@example.com', TipoBien.EQUIPO, 'Video y fotografía', 'Cámara 360', 'Cámara 360 con trípode y estuche.', '40.00', '0.00'],
  ] as const
).map(([email, tipo, categoria, titulo, descripcion, precio, deposito], indice) => ({
  email,
  id: idIngresos('00000000', indice + 1),
  tipo,
  categoria,
  titulo,
  descripcion,
  precio,
  unidadCobro: UnidadCobro.DIA,
  deposito,
  capacidad: null,
  condiciones: null,
  departamento: 'San Salvador',
  municipio: 'San Salvador',
  direccionReferencia: null,
}));

// Reserva Rn: 10000000-0000-4000-8000-00000000000n, siempre del usuario demo.
// El pago y el depósito siguen el mismo patrón con los prefijos 60000000,
// 70000000 y 80000000 (comprobante). Importes de depósito que la spec no fija:
// R4 usa 25.00 (el depósito del Taladro) y R3 y R5 no tienen depósito.
const RESERVAS_INGRESOS = [
  {
    n: 1,
    bien: 1,
    estado: EstadoReserva.FINALIZADA,
    inicio: 29,
    fin: 25,
    pago: { estado: EstadoPago.SIMULADO_EXITOSO, alquiler: '100.00', deposito: '50.00', hace: 29 },
    depositoResuelto: { estado: EstadoDeposito.RETENIDO, retenido: '50.00', hace: 24, justificacion: 'Daños en el mobiliario.' },
  },
  {
    n: 2,
    bien: 1,
    estado: EstadoReserva.FINALIZADA,
    inicio: 19,
    fin: 15,
    pago: { estado: EstadoPago.SIMULADO_EXITOSO, alquiler: '150.00', deposito: '60.00', hace: 20 },
    depositoResuelto: { estado: EstadoDeposito.LIBERADO, retenido: '0.00', hace: 14, justificacion: null },
  },
  {
    n: 3,
    bien: 1,
    estado: EstadoReserva.CANCELADA,
    inicio: 9,
    fin: 0,
    pago: { estado: EstadoPago.SIMULADO_RECHAZADO, alquiler: '200.00', deposito: '0.00', hace: 5 },
    depositoResuelto: null,
  },
  {
    n: 4,
    bien: 2,
    estado: EstadoReserva.FINALIZADA,
    inicio: 104,
    fin: 100,
    pago: { estado: EstadoPago.SIMULADO_EXITOSO, alquiler: '80.00', deposito: '25.00', hace: 105 },
    depositoResuelto: { estado: EstadoDeposito.PARCIALMENTE_RETENIDO, retenido: '15.00', hace: 99, justificacion: 'Faltaron dos brocas.' },
  },
  {
    n: 5,
    bien: 5,
    estado: EstadoReserva.CONFIRMADA,
    inicio: 29,
    fin: 0,
    pago: { estado: EstadoPago.SIMULADO_EXITOSO, alquiler: '500.00', deposito: '0.00', hace: 10 },
    depositoResuelto: null,
  },
];

// Datos de prueba de ocupación (DB-24.1, H24), sobre los bienes de arriba. Con el
// periodo ULTIMO_MES (de hoy-29 a hoy) la tasa esperada es:
//   Bien 1: 10 días ocupados (R1 y R2) de 20 disponibles (30 menos 10 bloqueados) = 50.0 %
//   Bien 2: bloqueado todo el periodo, 0 disponibles: "Sin días disponibles"
//   Bien 3: sin reservas ni bloqueos, 0 de 30 = 0.0 %
//   Bien 4: 30 de 30 = 100.0 %
//   Bien 5: pertenece al arrendador B y no aparece para el A
// Reserva Rn: 10000000-0000-4000-8000-00000000000n (R1 a R5 son las de arriba).
// Las EN_COLA, RECHAZADA y CANCELADA no cuentan como ocupadas y pueden solaparse.
const RESERVAS_OCUPACION = [
  { n: 6, bien: 1, estado: EstadoReserva.EN_COLA, inicio: 9, fin: 6 },
  { n: 7, bien: 1, estado: EstadoReserva.RECHAZADA, inicio: 5, fin: 2 },
  { n: 8, bien: 4, estado: EstadoReserva.FINALIZADA, inicio: 29, fin: 12 },
  { n: 9, bien: 4, estado: EstadoReserva.EN_CURSO, inicio: 11, fin: 0 },
  // Reserva terminada del Bien 5 para su reseña (DB-25.1). R5 es CONFIRMADA de
  // hoy-29 a hoy, y reserva_sin_solape no deja solapar una FINALIZADA, así que R10
  // va antes. Este bloque corre después del de R5, que es el que mueve sus fechas.
  { n: 10, bien: 5, estado: EstadoReserva.FINALIZADA, inicio: 64, fin: 60 },
];

// Bloqueo n: 41000000-0000-4000-8000-00000000000n (el 40000000 es el de H5).
const BLOQUEOS_OCUPACION = [
  { n: 1, bien: 1, inicio: 9, fin: 0 },
  { n: 2, bien: 2, inicio: 29, fin: 0 },
];

// Reseñas de prueba (DB-25.1, H25), todas del usuario demo sobre reservas
// FINALIZADA. Promedio de las reseñas tipo BIEN, por periodo (fecha de fin de la
// reserva dentro del periodo):
//   ULTIMO_MES:  Bien 1 = 4.5 con 2 reseñas (R1 y R2); Bien 4 = 3.0 con 1 (R8);
//                Bien 2 y Bien 3 sin calificaciones
//   ULTIMO_ANIO: además Bien 2 = 5.0 con 1 reseña (R4)
//   Bien 5 (arrendador B) = 2.0 con 1 reseña (R10); no aparece para el A
// La reseña tipo ARRENDADOR de 1 sobre R1 no entra en ningún promedio de bienes.
// Una reserva puede tener una reseña por tipo, y las reseñas no se editan.
const RESENAS_PANEL = [
  { reserva: 1, tipo: TipoResena.BIEN, puntuacion: 5, comentario: 'Excelente salón, tal como se describe.' },
  { reserva: 1, tipo: TipoResena.ARRENDADOR, puntuacion: 1, comentario: 'La atención del arrendador fue mala.' },
  { reserva: 2, tipo: TipoResena.BIEN, puntuacion: 4, comentario: 'Muy bueno, con detalles menores.' },
  { reserva: 8, tipo: TipoResena.BIEN, puntuacion: 3, comentario: 'Cumple, pero le falta mantenimiento.' },
  { reserva: 4, tipo: TipoResena.BIEN, puntuacion: 5, comentario: 'Funcionó perfecto.' },
  { reserva: 10, tipo: TipoResena.BIEN, puntuacion: 2, comentario: 'No era lo que esperaba.' },
];

const SOLICITUD = {
  moduloOrigen: ModuloOrigen.RESERVAS,
  titulo: 'Nueva solicitud de reserva',
  tipoReferencia: 'RESERVA_SOLICITADA',
};

const PAGO = {
  moduloOrigen: ModuloOrigen.PAGOS,
  titulo: 'Pago recibido',
  tipoReferencia: 'PAGO_APROBADO',
};

// Todos llevan referencia fija para que el índice único permita repetir el seed.
const AVISOS = [
  {
    ...SOLICITUD,
    email: 'arrendador@example.com',
    mensaje: 'demo solicitó Casa de playa del 10/12/2026 al 12/12/2026.',
    referenciaId: '00000000-0000-4000-8000-000000000001',
    estado: EstadoNotificacion.NO_LEIDA,
  },
  {
    ...SOLICITUD,
    email: 'arrendador@example.com',
    mensaje: 'demo solicitó Taladro percutor del 15/12/2026 al 16/12/2026.',
    referenciaId: '00000000-0000-4000-8000-000000000002',
    estado: EstadoNotificacion.NO_LEIDA,
  },
  {
    ...PAGO,
    email: 'arrendador@example.com',
    mensaje: 'Se aprobó el pago de $125.00 de demo por Casa de playa.',
    referenciaId: '00000000-0000-4000-8000-000000000003',
    estado: EstadoNotificacion.NO_LEIDA,
  },
  {
    ...SOLICITUD,
    email: 'arrendador@example.com',
    mensaje: 'demo solicitó Cámara réflex del 01/11/2026 al 03/11/2026.',
    referenciaId: '00000000-0000-4000-8000-000000000004',
    estado: EstadoNotificacion.LEIDA,
  },
  {
    ...PAGO,
    email: 'arrendador@example.com',
    mensaje: 'Se aprobó el pago de $40.00 de demo por Cámara réflex.',
    referenciaId: '00000000-0000-4000-8000-000000000005',
    estado: EstadoNotificacion.LEIDA,
  },
  {
    email: 'demo@example.com',
    moduloOrigen: ModuloOrigen.PAGOS,
    titulo: 'Depósito resuelto',
    mensaje: 'Tu depósito de $20.00 por Cámara réflex fue liberado ($20.00).',
    tipoReferencia: 'DEPOSITO_RESUELTO',
    referenciaId: '00000000-0000-4000-8000-000000000006',
    estado: EstadoNotificacion.NO_LEIDA,
  },
];

const adapter = new PrismaPg({ connectionString: process.env.DATABASE_URL });
const prisma = new PrismaClient({ adapter });

async function main() {
  const passwordHash = await bcrypt.hash(DEMO_PASSWORD, 12);

  // `upsert` hace el seed idempotente: se puede correr las veces que haga falta.
  // El `update` también fija nombre y rol para corregir a un usuario demo que
  // ya existía y recibió valores por defecto en la migración.
  for (const { email, nombreUsuario, rol } of USUARIOS) {
    const usuario = await prisma.usuario.upsert({
      where: { email },
      update: { nombreUsuario, rol },
      create: { email, nombreUsuario, rol, passwordHash },
    });

    console.log(`Usuario listo: ${usuario.email} (${usuario.rol}) / ${DEMO_PASSWORD}`);
  }

  const arrendador = await prisma.usuario.findUniqueOrThrow({
    where: { email: 'arrendador@example.com' },
  });

  for (const { fotos, ...bien } of [...BIENES, ...BIENES_BUSQUEDA]) {
    const datos = { ...bien, arrendadorId: arrendador.id };
    await prisma.bien.upsert({ where: { id: bien.id }, update: datos, create: datos });

    for (const [indice, url] of fotos.entries()) {
      const orden = indice + 1;
      const foto = { url, esPrincipal: orden === 1 };
      await prisma.fotoBien.upsert({
        where: { bienId_orden: { bienId: bien.id, orden } },
        update: foto,
        create: { ...foto, bienId: bien.id, orden },
      });
    }

    console.log(`Bien listo: ${bien.titulo} (${fotos.length} fotos)`);
  }

  const arrendatario = await prisma.usuario.findUniqueOrThrow({
    where: { email: 'demo@example.com' },
  });

  // El update de la reserva no toca procesadaEn: se fija solo al crearla.
  await prisma.reserva.upsert({
    where: { id: RESERVA_CONFIRMADA.id },
    update: { ...RESERVA_CONFIRMADA, arrendatarioId: arrendatario.id },
    create: {
      ...RESERVA_CONFIRMADA,
      arrendatarioId: arrendatario.id,
      procesadaEn: new Date(),
    },
  });

  await prisma.bloqueoFecha.upsert({
    where: { id: BLOQUEO_FECHA.id },
    update: BLOQUEO_FECHA,
    create: BLOQUEO_FECHA,
  });

  console.log('Reserva confirmada y bloqueo de fechas listos');

  for (const reserva of [RESERVA_CON_RESENA, RESERVA_SIN_RESENA]) {
    const datos = { ...reserva, arrendatarioId: arrendatario.id };
    await prisma.reserva.upsert({
      where: { id: reserva.id },
      update: datos,
      create: { ...datos, procesadaEn: new Date() },
    });
  }

  // El update va vacío porque una reseña no se edita.
  await prisma.resena.upsert({
    where: {
      reservaId_tipo: {
        reservaId: RESENA_BIEN.reservaId,
        tipo: RESENA_BIEN.tipo,
      },
    },
    update: {},
    create: { ...RESENA_BIEN, autorId: arrendatario.id },
  });

  console.log('Reservas finalizadas y reseña listas');

  // Datos de prueba del panel de reportes (DB-23.1).
  const arrendadores = new Map<string, string>();
  for (const email of ['arrendador@example.com', 'arrendador2@example.com']) {
    const { id } = await prisma.usuario.findUniqueOrThrow({ where: { email } });
    arrendadores.set(email, id);
  }

  for (const { email, ...bien } of BIENES_INGRESOS) {
    const datos = { ...bien, arrendadorId: arrendadores.get(email)! };
    await prisma.bien.upsert({ where: { id: bien.id }, update: datos, create: datos });
  }

  // Al repetir el seed, las fechas de cada reserva se mueven. Si R1 se moviera
  // primero, podría caer sobre las fechas aún sin actualizar de R2 (mismo bien) y
  // reserva_sin_solape fallaría con 23P01. Por eso se mueven primero las que van
  // por delante en la dirección del movimiento:
  // - Normalmente las fechas avanzan (otro día): de la más reciente a la más
  //   antigua, así el rango viejo de R2 queda libre para R1.
  // - Pueden retroceder un día una sola vez, en una base sembrada entre las
  //   18:00 y la medianoche con el seed anterior, que contaba "hoy" en UTC: ahí
  //   va de la más antigua a la más reciente.
  // La dirección se mira en cada bloque, en su primera reserva ya guardada (un
  // seed que falló a medias puede haber movido un bloque y otro no). En una base
  // vacía no hay nada que mover y el orden da igual.
  const enOrdenSeguro = async <T extends { n: number; fin: number }>(
    reservas: readonly T[],
  ): Promise<T[]> => {
    const guardada = await prisma.reserva.findUnique({
      where: { id: idIngresos('10000000', reservas[0].n) },
      select: { fechaFin: true },
    });
    const retrocede = guardada !== null && guardada.fechaFin > diaHace(reservas[0].fin);
    return retrocede ? [...reservas] : [...reservas].reverse();
  };

  for (const r of await enOrdenSeguro(RESERVAS_INGRESOS)) {
    const finalizada = r.estado === EstadoReserva.FINALIZADA;
    const reserva = {
      bienId: idIngresos('00000000', r.bien),
      arrendatarioId: arrendatario.id,
      fechaInicio: diaHace(r.inicio),
      fechaFin: diaHace(r.fin),
      estado: r.estado,
      finalizadaEn: finalizada ? diaHace(r.fin) : null,
    };
    const reservaId = idIngresos('10000000', r.n);
    await prisma.reserva.upsert({
      where: { id: reservaId },
      update: reserva,
      create: { ...reserva, id: reservaId, procesadaEn: new Date() },
    });

    const exitoso = r.pago.estado === EstadoPago.SIMULADO_EXITOSO;
    const total = (Number(r.pago.alquiler) + Number(r.pago.deposito)).toFixed(2);
    const pago = {
      reservaId,
      modalidad: ModalidadPago.TARJETA,
      importeAlquiler: r.pago.alquiler,
      importeDeposito: r.pago.deposito,
      total,
      estado: r.pago.estado,
      fechaHora: haceDias(r.pago.hace),
      comprobanteId: exitoso ? idIngresos('80000000', r.n) : null,
      ultimosCuatro: exitoso ? '4242' : '0002',
      motivoRechazo: exitoso ? null : 'Tarjeta rechazada por la pasarela simulada.',
    };
    const pagoId = idIngresos('60000000', r.n);
    await prisma.pago.upsert({ where: { id: pagoId }, update: pago, create: { ...pago, id: pagoId } });

    if (r.depositoResuelto) {
      const original = Number(r.pago.deposito);
      const retenido = Number(r.depositoResuelto.retenido);
      const deposito = {
        reservaId,
        resueltoPorId: arrendadores.get('arrendador@example.com')!,
        importeOriginal: r.pago.deposito,
        importeRetenido: r.depositoResuelto.retenido,
        importeLiberado: (original - retenido).toFixed(2),
        estado: r.depositoResuelto.estado,
        justificacion: r.depositoResuelto.justificacion,
        fechaResolucion: haceDias(r.depositoResuelto.hace),
      };
      const depositoId = idIngresos('70000000', r.n);
      await prisma.deposito.upsert({
        where: { id: depositoId },
        update: deposito,
        create: { ...deposito, id: depositoId },
      });
    }
  }

  // Reservas y bloqueos de ocupación (DB-24.1). Mismo cuidado que arriba: si las
  // fechas avanzan y la FINALIZADA del Bien 4 se moviera antes que su EN_CURSO,
  // caería sobre el rango aún sin actualizar de la EN_CURSO (23P01); si
  // retroceden, pasa al revés.
  for (const r of await enOrdenSeguro(RESERVAS_OCUPACION)) {
    const reserva = {
      bienId: idIngresos('00000000', r.bien),
      arrendatarioId: arrendatario.id,
      fechaInicio: diaHace(r.inicio),
      fechaFin: diaHace(r.fin),
      estado: r.estado,
      motivoResolucion: r.estado === EstadoReserva.RECHAZADA ? 'FECHAS_NO_DISPONIBLES' : null,
      finalizadaEn: r.estado === EstadoReserva.FINALIZADA ? diaHace(r.fin) : null,
    };
    const reservaId = idIngresos('10000000', r.n);
    await prisma.reserva.upsert({
      where: { id: reservaId },
      update: reserva,
      create: {
        ...reserva,
        id: reservaId,
        // Una solicitud EN_COLA todavía no fue procesada.
        procesadaEn: r.estado === EstadoReserva.EN_COLA ? null : new Date(),
      },
    });
  }

  for (const b of BLOQUEOS_OCUPACION) {
    const bloqueo = {
      bienId: idIngresos('00000000', b.bien),
      fechaInicio: diaHace(b.inicio),
      fechaFin: diaHace(b.fin),
    };
    const bloqueoId = idIngresos('41000000', b.n);
    await prisma.bloqueoFecha.upsert({
      where: { id: bloqueoId },
      update: bloqueo,
      create: { ...bloqueo, id: bloqueoId },
    });
  }

  console.log(
    `Ocupación lista: ${RESERVAS_OCUPACION.length} reservas y ${BLOQUEOS_OCUPACION.length} bloqueos`,
  );

  // Reseñas del panel (DB-25.1). El update va vacío porque una reseña no se edita;
  // la reserva ya existe porque las reservas se cargan arriba.
  for (const r of RESENAS_PANEL) {
    const { reserva, ...resena } = r;
    await prisma.resena.upsert({
      where: { reservaId_tipo: { reservaId: idIngresos('10000000', reserva), tipo: r.tipo } },
      update: {},
      create: { ...resena, reservaId: idIngresos('10000000', reserva), autorId: arrendatario.id },
    });
  }

  console.log(`Reseñas del panel listas: ${RESENAS_PANEL.length}`);

  console.log(
    `Panel de reportes listo: ${BIENES_INGRESOS.length} bienes, ${RESERVAS_INGRESOS.length} reservas con sus pagos y depósitos`,
  );

  for (const { email, ...aviso } of AVISOS) {
    const { id: destinatarioId } = await prisma.usuario.findUniqueOrThrow({
      where: { email },
    });

    await prisma.notificacion.upsert({
      where: {
        destinatarioId_tipoReferencia_referenciaId: {
          destinatarioId,
          tipoReferencia: aviso.tipoReferencia,
          referenciaId: aviso.referenciaId,
        },
      },
      update: {},
      create: {
        ...aviso,
        destinatarioId,
        leidaEn: aviso.estado === EstadoNotificacion.LEIDA ? new Date() : null,
      },
    });
  }

  console.log(`Avisos listos: ${AVISOS.length}`);
}

try {
  await main();
} finally {
  await prisma.$disconnect();
}
