# Arre 1800 Aura Farmers

**Arre** es una plataforma web de alquiler de **propiedades, espacios y equipos** que conecta a quienes publican bienes (arrendadores) con quienes desean alquilarlos (arrendatarios). Permite descubrir ofertas, consultar disponibilidad, reservar, realizar pagos simulados y gestionar el alquiler hasta su devolución y calificación.

**Proyecto asignado:** Plataforma de renta/alquiler de equipo o espacios; equipo **1800 Aura Farmers**.  
**Curso:** Ingeniería de Software, Sección 02, Universidad Centroamericana "José Simeón Cañas" (UCA), ciclo 02/2026.  
**Versión objetivo de entrega:** `v1.0.0`.

Este repositorio contiene **la API y la documentación oficial del proyecto completo**, incluido el frontend. El código de la interfaz se mantiene en un repositorio independiente.

> Los usuarios de prueba se entregan en Moodle, no en este repositorio.

## Ambiente desplegado

| Componente | URL |
|---|---|
| Frontend | (aplicación web) https://arre.live:3001 |
| Documentación de la API | https://arre.live:3000/api/docs |
| Repositorio frontend | [1800-aura-farmers-proyecto4-frontend](https://github.com/ErickGomezUCA/1800-aura-farmers-proyecto4-frontend) |
| Repositorio backend y documentación principal | [1800-aura-farmers-proyecto4-backend](https://github.com/ErickGomezUCA/1800-aura-farmers-proyecto4-backend) |

## Qué ofrece el sistema

La plataforma diferencia dos roles. El **arrendador** publica bienes con fotografías, precios y condiciones; administra bloqueos de calendario, reservas recibidas, devoluciones, depósitos, conversaciones y reportes de desempeño. El **arrendatario** busca y filtra bienes, consulta fechas disponibles, solicita reservas, realiza pagos de prueba, consulta comprobantes y depósitos, conversa con el arrendador y deja reseñas. Ambos roles pueden gestionar su verificación de identidad y consultar notificaciones.

El recorrido principal es: **publicación → búsqueda y disponibilidad → solicitud y confirmación automática → pago simulado → coordinación → devolución y resolución del depósito → calificaciones**. Las reservas, los documentos de verificación y ciertos plazos del depósito cuentan con procesos automáticos del backend.

Los pagos son **simulados**: no se procesa dinero real ni se almacenan datos completos de tarjetas. La revisión de documentos también es simulada, de acuerdo con las reglas definidas en las historias del proyecto.

## Tecnologías y organización

| Capa | Tecnologías principales | Responsabilidad |
|---|---|---|
| Frontend | Next.js 16, React 19, TypeScript, Tailwind CSS 4 | Interfaz adaptable, navegación, formularios y consumo seguro de la API |
| Backend | NestJS 12, TypeScript 6, Prisma 7 | API REST, reglas de negocio, validaciones, seguridad y procesos programados |
| Persistencia | PostgreSQL 18 | Usuarios, publicaciones, reservas, pagos, depósitos, conversaciones, reseñas y notificaciones |
| Seguridad | JWT, cookies `httpOnly`, guards y roles | Autenticación, renovación de sesión y autorización por usuario y propiedad |
| Calidad | Vitest, React Testing Library, ESLint (frontend), oxlint (backend) | Pruebas automatizadas y análisis estático |
| Ejecución local | Docker Compose (API y PostgreSQL) | Servicios reproducibles y migraciones |

El backend organiza los módulos en `src/` (por ejemplo `bienes`, `reservas`, `pagos`, `depositos`, `conversaciones`, `reportes`), con controladores, servicios y repositorios. Prisma mantiene el esquema y las migraciones en `prisma/`. El frontend usa App Router (`app/`), componentes reutilizables (`components/`), utilidades (`lib/`) y rutas servidoras `app/api/` para mediar solicitudes autenticadas.

### Puesta en marcha rápida

**Backend** (Node.js compatible con Prisma 7 y Docker Compose):

```bash
cp .env.example .env
# Configurar DATABASE_URL y JWT_SECRET antes de iniciar
# Arranca PostgreSQL y la API; aplica migraciones al levantar

docker compose up --build
# En otra terminal, para datos de ejemplo:
docker compose exec api npx prisma db seed
```

API local: `http://localhost:3000/api/v1`. Swagger: `http://localhost:3000/api/docs`.

**Frontend** (en el [otro repositorio](https://github.com/ErickGomezUCA/1800-aura-farmers-proyecto4-frontend)):

```bash
cp .env.example .env
# API_URL=http://localhost:3000/api/v1
npm ci
npm run dev
```

Aplicación local: `http://localhost:3001`. Las variables de entorno se documentan mediante los archivos `.env.example`; nunca se deben subir secretos reales.

## Integrantes

| Nombre | Carnet | Usuario de GitHub | Historias principales |
|---|---|---|---|
| Erick Bladimir Gómez Hernández | 00300723 | ErickGomezUCA | H0–H4 |
| Diego Benjamín García Alfaro | 00088023 | DiegoGarcia271004 | H5–H7, H17, H19 |
| Gabriel Ernesto Iraheta Guardado | 00021223 | GaboIraheta | H8–H14 |
| Míriam Rocío Doñas López | 00022423 | rociodlz | H15, H16, H18, H20–H22 |
| Mauricio Alejandro Montes Varela | 00042823 | MauricioMontes-UCA | H23–H26 |

## Documentación

La documentación oficial se mantiene **únicamente en `docs/` de este repositorio** y cubre conjuntamente frontend y backend:

1. [Guía de uso](docs/01-guia-de-uso.md)
2. [Arquitectura](docs/02-arquitectura.md)
3. [Modelo de datos](docs/03-modelo-de-datos.md)
4. [API](docs/04-api.md)
5. [Instalación local](docs/05-instalacion-local.md)
6. [Despliegue](docs/06-despliegue.md)
7. [Forma de trabajo](docs/07-forma-de-trabajo.md)
8. [Historias por módulo](docs/08-historias.md)
9. [Problemas conocidos](docs/09-problemas-conocidos.md)

## Repositorios y versión

- **Backend y documentación oficial:** [GitHub — backend](https://github.com/ErickGomezUCA/1800-aura-farmers-proyecto4-backend).
- **Interfaz web:** [GitHub — frontend](https://github.com/ErickGomezUCA/1800-aura-farmers-proyecto4-frontend).
- **Rama de integración:** `develop`; **publicación:** `release/1.0.0` → `main`, con PR revisado y etiqueta `v1.0.0` en ambos repositorios.
- **Trazabilidad:** tareas en Jira y PR por tarea, descritos en [Forma de trabajo](docs/07-forma-de-trabajo.md) y [Historias por módulo](docs/08-historias.md).

El README del frontend conserva su guía técnica abreviada y enlaza a esta documentación central; no es una segunda fuente de documentación oficial.
