import type { INestApplication } from '@nestjs/common';
import request from 'supertest';
import { PrismaService } from '@Prisma/services';
import { crearApp } from './helpers/crear-app.js';

/**
 * GET /bienes/mios (BE-1.3) contra el Postgres de docker-compose
 * (`DATABASE_URL`): autorización, solo bienes propios (ACTIVA e INACTIVA),
 * foto principal, «Solo usuarios verificados», orden, paginación y que la ruta
 * no se confunda con `GET /bienes/:bienId`.
 *
 * Cada escenario usa su propio arrendador, con sufijo único, para que los
 * conteos no dependan de otras pruebas:
 * - `lleno`: 25 bienes, para las tres páginas (20, 5 y vacía).
 * - `mixto`: bienes ACTIVA e INACTIVA, con y sin foto principal y política.
 * - `vacio`: sin bienes.
 * - `otro`: bienes de otro arrendador, que nunca deben aparecer.
 * - `empate`: 22 bienes con el mismo instante de creación.
 * Al terminar se borra todo lo creado.
 */
describe('GET /bienes/mios (e2e)', () => {
  let app: INestApplication;
  let prisma: PrismaService;

  const sufijo = `${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`;
  const nuevoUsuario = (
    prefijo: string,
    rol: 'ARRENDADOR' | 'ARRENDATARIO',
  ) => ({
    nombreUsuario: `${prefijo}_${sufijo}`,
    email: `${prefijo}_${sufijo}@example.com`,
    password: 'Str0ngPass',
    rol,
  });
  const datos = {
    lleno: nuevoUsuario('mios_lleno', 'ARRENDADOR'),
    mixto: nuevoUsuario('mios_mixto', 'ARRENDADOR'),
    vacio: nuevoUsuario('mios_vacio', 'ARRENDADOR'),
    otro: nuevoUsuario('mios_otro', 'ARRENDADOR'),
    empate: nuevoUsuario('mios_empate', 'ARRENDADOR'),
    inquilino: nuevoUsuario('mios_inq', 'ARRENDATARIO'),
  };
  type Clave = keyof typeof datos;
  const tokens = {} as Record<Clave, string>;
  const ids = {} as Record<Clave, string>;
  const bienes: string[] = [];
  /** Ids de los 25 bienes de `lleno`, del más reciente al más antiguo. */
  const recientesPrimero: string[] = [];
  const idsMixto = {} as Record<
    'activaConFoto' | 'inactiva' | 'activaSinFoto' | 'conPolitica',
    string
  >;

  const http = () => request(app.getHttpServer());
  const mios = (token: string | null, query = '') => {
    const peticion = http().get(`/api/v1/bienes/mios${query}`);
    return token ? peticion.set('Authorization', `Bearer ${token}`) : peticion;
  };
  const idsDe = (body: { items: { id: string }[] }) =>
    body.items.map((item) => item.id);

  const crearBien = async (
    arrendadorId: string,
    titulo: string,
    extra: {
      estado?: 'ACTIVA' | 'INACTIVA';
      creadoEn?: Date;
      precio?: number;
      deposito?: number;
    } = {},
  ) => {
    const bien = await prisma.bien.create({
      data: {
        arrendadorId,
        tipo: 'PROPIEDAD',
        categoria: 'Casa',
        titulo: `${titulo} ${sufijo}`,
        descripcion: 'Bien de prueba e2e',
        precio: extra.precio ?? 50,
        deposito: extra.deposito ?? 0,
        unidadCobro: 'NOCHE',
        departamento: 'San Salvador',
        municipio: 'San Salvador',
        estado: extra.estado ?? 'ACTIVA',
        ...(extra.creadoEn ? { creadoEn: extra.creadoEn } : {}),
      },
    });
    bienes.push(bien.id);
    return bien.id;
  };

  beforeAll(async () => {
    app = await crearApp();
    prisma = app.get(PrismaService);

    for (const clave of Object.keys(datos) as Clave[]) {
      await http().post('/api/v1/users').send(datos[clave]).expect(201);
      const login = await http()
        .post('/api/v1/auth/login')
        .send({ email: datos[clave].email, password: datos[clave].password })
        .expect(200);
      tokens[clave] = login.body.accessToken as string;
      ids[clave] = login.body.user.id as string;
    }

    // lleno: 25 bienes con fechas de creación distintas y controladas.
    for (let i = 0; i < 25; i += 1) {
      const id = await crearBien(ids.lleno, `Lleno ${i}`, {
        creadoEn: new Date(Date.UTC(2026, 0, 1, 0, i)),
      });
      recientesPrimero.unshift(id);
    }

    // mixto
    idsMixto.activaConFoto = await crearBien(ids.mixto, 'Con foto', {
      creadoEn: new Date('2026-03-01T00:00:00.000Z'),
      precio: 80.5,
      deposito: 25,
    });
    await prisma.fotoBien.createMany({
      data: [
        {
          bienId: idsMixto.activaConFoto,
          url: '/otra.jpg',
          orden: 0,
          esPrincipal: false,
        },
        {
          bienId: idsMixto.activaConFoto,
          url: '/principal.jpg',
          orden: 1,
          esPrincipal: true,
        },
      ],
    });
    idsMixto.inactiva = await crearBien(ids.mixto, 'Inactiva', {
      estado: 'INACTIVA',
      creadoEn: new Date('2026-02-01T00:00:00.000Z'),
    });
    idsMixto.activaSinFoto = await crearBien(ids.mixto, 'Sin foto', {
      creadoEn: new Date('2026-01-01T00:00:00.000Z'),
    });
    idsMixto.conPolitica = await crearBien(ids.mixto, 'Con política', {
      creadoEn: new Date('2026-04-01T00:00:00.000Z'),
    });
    await prisma.politicaVerificacionBien.create({
      data: { bienId: idsMixto.conPolitica, soloVerificados: true },
    });
    // Una política explícita en false, distinta de «sin registro».
    await prisma.politicaVerificacionBien.create({
      data: { bienId: idsMixto.activaSinFoto, soloVerificados: false },
    });

    // otro: nunca debe aparecer en los listados de los demás.
    await crearBien(ids.otro, 'Ajeno 1');
    await crearBien(ids.otro, 'Ajeno 2', { estado: 'INACTIVA' });
  }, 120000);

  afterAll(async () => {
    await prisma.politicaVerificacionBien.deleteMany({
      where: { bienId: { in: bienes } },
    });
    await prisma.fotoBien.deleteMany({ where: { bienId: { in: bienes } } });
    await prisma.bien.deleteMany({ where: { id: { in: bienes } } });
    await prisma.usuario.deleteMany({
      where: { email: { in: Object.values(datos).map((u) => u.email) } },
    });
    await app.close();
  });

  describe('autorización', () => {
    it('sin token responde 401', async () => {
      await mios(null).expect(401);
    });

    it('un arrendatario recibe 403', async () => {
      await mios(tokens.inquilino).expect(403);
    });

    it('«mios» no se interpreta como el id de GET /bienes/:bienId (no es 400 de UUID ni 404)', async () => {
      const respuesta = await mios(tokens.mixto).expect(200);

      expect(respuesta.body).toHaveProperty('items');
    });

    it('GET /bienes/:bienId público sigue funcionando para un bien ACTIVA', async () => {
      await http().get(`/api/v1/bienes/${idsMixto.activaConFoto}`).expect(200);
    });
  });

  describe('contenido', () => {
    it('un arrendador sin bienes recibe items vacío con total 0', async () => {
      const respuesta = await mios(tokens.vacio).expect(200);

      expect(respuesta.body).toEqual({
        items: [],
        pagina: 1,
        total: 0,
        hayMas: false,
      });
    });

    it('devuelve solo sus bienes, ACTIVA e INACTIVA, y nunca los de otro arrendador', async () => {
      const respuesta = await mios(tokens.mixto).expect(200);

      expect(respuesta.body.total).toBe(4);
      expect(new Set(idsDe(respuesta.body))).toEqual(
        new Set(Object.values(idsMixto)),
      );
      const estados = respuesta.body.items.map(
        (item: { estado: string }) => item.estado,
      );
      expect(estados).toContain('INACTIVA');
      expect(estados).toContain('ACTIVA');

      const delOtro = await mios(tokens.otro).expect(200);
      expect(delOtro.body.total).toBe(2);
      expect(
        delOtro.body.items.map((i: { titulo: string }) => i.titulo),
      ).toEqual(
        expect.arrayContaining([`Ajeno 1 ${sufijo}`, `Ajeno 2 ${sufijo}`]),
      );
    });

    it('cada elemento trae los campos acordados, y nada más', async () => {
      const respuesta = await mios(tokens.mixto).expect(200);
      const bien = respuesta.body.items.find(
        (i: { id: string }) => i.id === idsMixto.activaConFoto,
      );

      expect(Object.keys(bien).sort()).toEqual(
        [
          'categoria',
          'creadoEn',
          'departamento',
          'deposito',
          'estado',
          'fotoPrincipalUrl',
          'id',
          'municipio',
          'precio',
          'soloVerificados',
          'tipo',
          'titulo',
          'unidadCobro',
        ].sort(),
      );
      expect(bien).toMatchObject({
        titulo: `Con foto ${sufijo}`,
        tipo: 'PROPIEDAD',
        categoria: 'Casa',
        estado: 'ACTIVA',
        precio: 80.5,
        unidadCobro: 'NOCHE',
        deposito: 25,
        departamento: 'San Salvador',
        municipio: 'San Salvador',
      });
      expect(new Date(bien.creadoEn).toISOString()).toBe(bien.creadoEn);
    });

    it('incluye la foto principal (no la primera por orden) o null si no hay fotos', async () => {
      const respuesta = await mios(tokens.mixto).expect(200);
      const por = (id: string) =>
        respuesta.body.items.find((i: { id: string }) => i.id === id);

      expect(por(idsMixto.activaConFoto).fotoPrincipalUrl).toBe(
        '/principal.jpg',
      );
      expect(por(idsMixto.activaSinFoto).fotoPrincipalUrl).toBeNull();
      expect(por(idsMixto.inactiva).fotoPrincipalUrl).toBeNull();
    });

    it('soloVerificados refleja la política y es false sin registro o con false explícito', async () => {
      const respuesta = await mios(tokens.mixto).expect(200);
      const por = (id: string) =>
        respuesta.body.items.find((i: { id: string }) => i.id === id);

      expect(por(idsMixto.conPolitica).soloVerificados).toBe(true);
      expect(por(idsMixto.activaConFoto).soloVerificados).toBe(false); // sin registro
      expect(por(idsMixto.activaSinFoto).soloVerificados).toBe(false); // false explícito
    });

    it('cambiar la política se refleja en el listado', async () => {
      await prisma.politicaVerificacionBien.update({
        where: { bienId: idsMixto.conPolitica },
        data: { soloVerificados: false },
      });
      const apagada = await mios(tokens.mixto).expect(200);
      expect(
        apagada.body.items.find(
          (i: { id: string }) => i.id === idsMixto.conPolitica,
        ).soloVerificados,
      ).toBe(false);
      await prisma.politicaVerificacionBien.update({
        where: { bienId: idsMixto.conPolitica },
        data: { soloVerificados: true },
      });
    });

    it('no expone la descripción ni datos del arrendador', async () => {
      const respuesta = await mios(tokens.mixto).expect(200);
      const texto = JSON.stringify(respuesta.body);

      expect(texto).not.toContain('Bien de prueba e2e');
      expect(texto).not.toContain(datos.mixto.email);
      expect(texto).not.toContain('arrendadorId');
    });
  });

  describe('orden y paginación', () => {
    it('ordena del más reciente al más antiguo', async () => {
      const respuesta = await mios(tokens.mixto).expect(200);

      expect(idsDe(respuesta.body)).toEqual([
        idsMixto.conPolitica, // abril
        idsMixto.activaConFoto, // marzo
        idsMixto.inactiva, // febrero
        idsMixto.activaSinFoto, // enero
      ]);
    });

    it('pagina 20 + 5 + vacía, con total y hayMas correctos', async () => {
      const p1 = await mios(tokens.lleno, '?pagina=1').expect(200);
      const p2 = await mios(tokens.lleno, '?pagina=2').expect(200);
      const p3 = await mios(tokens.lleno, '?pagina=3').expect(200);

      expect(p1.body).toMatchObject({ pagina: 1, total: 25, hayMas: true });
      expect(p2.body).toMatchObject({ pagina: 2, total: 25, hayMas: false });
      expect(p3.body).toEqual({
        items: [],
        pagina: 3,
        total: 25,
        hayMas: false,
      });
      expect(p1.body.items).toHaveLength(20);
      expect(p2.body.items).toHaveLength(5);
      expect([...idsDe(p1.body), ...idsDe(p2.body)]).toEqual(recientesPrimero);
    });

    it('sin pagina usa la página 1', async () => {
      const respuesta = await mios(tokens.lleno).expect(200);

      expect(respuesta.body.pagina).toBe(1);
      expect(idsDe(respuesta.body)).toEqual(recientesPrimero.slice(0, 20));
    });

    it('con empate de creadoEn desempata por id, sin duplicar ni perder bienes entre páginas', async () => {
      const mismoInstante = new Date('2026-06-06T06:00:00.000Z');
      const creados: string[] = [];
      // 22 bienes del mismo arrendador con el mismo instante de creación.
      for (let i = 0; i < 22; i += 1) {
        creados.push(
          await crearBien(ids.empate, `Empate ${i}`, {
            creadoEn: mismoInstante,
          }),
        );
      }

      const p1 = await mios(tokens.empate, '?pagina=1').expect(200);
      const p2 = await mios(tokens.empate, '?pagina=2').expect(200);

      const todos = [...idsDe(p1.body), ...idsDe(p2.body)];
      expect(todos).toHaveLength(22);
      expect(new Set(todos).size).toBe(22);
      expect(new Set(todos)).toEqual(new Set(creados));
      // orden estable: id descendente
      expect(todos).toEqual([...creados].sort().reverse());
    });
  });

  describe('página inválida (400)', () => {
    it.each([
      '?pagina=0',
      '?pagina=-1',
      '?pagina=1.5',
      '?pagina=abc',
      '?pagina=',
      '?pagina=01',
      '?pagina=1e2',
      '?pagina=0x10',
      '?pagina=%2B1',
      '?pagina=%201',
      '?pagina=10001',
      '?pagina=9007199254740993',
      '?pagina=1&pagina=2',
    ])('%s', async (query) => {
      await mios(tokens.mixto, query).expect(400);
    });

    it('PAGINA_MAXIMA (10000) es válida y devuelve la página vacía', async () => {
      const respuesta = await mios(tokens.mixto, '?pagina=10000').expect(200);

      expect(respuesta.body).toEqual({
        items: [],
        pagina: 10000,
        total: 4,
        hayMas: false,
      });
    });

    it('un parámetro desconocido, como arrendadorId, responde 400', async () => {
      await mios(tokens.mixto, `?arrendadorId=${ids.otro}`).expect(400);
    });
  });
});
