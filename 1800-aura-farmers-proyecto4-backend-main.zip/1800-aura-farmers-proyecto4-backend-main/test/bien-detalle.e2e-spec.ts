import type { INestApplication } from '@nestjs/common';
import request from 'supertest';
import { crearApp } from './helpers/crear-app.js';
import { PrismaService } from '@Prisma/services';

/**
 * Detalle público de un bien contra la base real (DATABASE_URL).
 *
 * Crea un arrendador y tres bienes con sufijo único, y lo borra todo al final;
 * las fotos se van con su bien por el onDelete: Cascade.
 */
describe('GET /bienes/:bienId (e2e)', () => {
  let app: INestApplication;
  let prisma: PrismaService;

  const sufijo = Date.now().toString(36);
  const arrendador = {
    nombreUsuario: `det_${sufijo}`,
    email: `det_${sufijo}@example.com`,
    passwordHash: `hash-privado-${sufijo}`,
    rol: 'ARRENDADOR' as const,
  };

  // Arrendador desactivado con un bien que sigue ACTIVA.
  const arrendadorInactivo = {
    nombreUsuario: `deti_${sufijo}`,
    email: `deti_${sufijo}@example.com`,
    passwordHash: `hash-privado-i-${sufijo}`,
    rol: 'ARRENDADOR' as const,
    isActive: false,
  };

  let arrendadorId = '';
  let bienId = '';
  let bienSinOpcionalesId = '';
  let bienInactivoId = '';
  let bienDeArrendadorInactivoId = '';

  const datosBien = (titulo: string) => ({
    arrendadorId,
    tipo: 'PROPIEDAD' as const,
    categoria: 'Salón de eventos',
    titulo,
    descripcion: 'Salón climatizado con cocina y parqueo.',
    precio: '80.50',
    unidadCobro: 'DIA' as const,
    deposito: '25.00',
    capacidad: 120,
    condiciones: 'No se permite pirotecnia',
    departamento: 'San Salvador',
    municipio: 'Antiguo Cuscatlán',
    direccionReferencia: 'Frente al parque central',
  });

  const consultar = (id: string) =>
    request(app.getHttpServer()).get(`/api/v1/bienes/${id}`);

  beforeAll(async () => {
    app = await crearApp();
    prisma = app.get(PrismaService);

    arrendadorId = (await prisma.usuario.create({ data: arrendador })).id;

    // La principal tiene el orden 3: la respuesta debe ponerla primero.
    bienId = (
      await prisma.bien.create({
        data: {
          ...datosBien(`Detalle ${sufijo}`),
          fotos: {
            createMany: {
              data: [
                {
                  url: `/uploads/bienes/${sufijo}/2.webp`,
                  orden: 2,
                  esPrincipal: false,
                },
                {
                  url: `/uploads/bienes/${sufijo}/3.webp`,
                  orden: 3,
                  esPrincipal: true,
                },
                {
                  url: `/uploads/bienes/${sufijo}/1.webp`,
                  orden: 1,
                  esPrincipal: false,
                },
              ],
            },
          },
        },
      })
    ).id;

    bienSinOpcionalesId = (
      await prisma.bien.create({
        data: {
          ...datosBien(`Sin opcionales ${sufijo}`),
          tipo: 'EQUIPO',
          categoria: 'Herramientas',
          deposito: '0',
          capacidad: null,
          condiciones: null,
          direccionReferencia: null,
          fotos: {
            create: {
              url: `/uploads/bienes/${sufijo}/s.webp`,
              orden: 1,
              esPrincipal: true,
            },
          },
        },
      })
    ).id;

    bienInactivoId = (
      await prisma.bien.create({
        data: { ...datosBien(`Inactivo ${sufijo}`), estado: 'INACTIVA' },
      })
    ).id;

    const arrendadorInactivoId = (
      await prisma.usuario.create({ data: arrendadorInactivo })
    ).id;
    bienDeArrendadorInactivoId = (
      await prisma.bien.create({
        data: {
          ...datosBien(`De arrendador inactivo ${sufijo}`),
          arrendadorId: arrendadorInactivoId,
        },
      })
    ).id;
  });

  afterAll(async () => {
    // Si beforeAll falló antes de crear los bienes, los ids siguen vacíos y
    // filtrar una columna UUID con '' taparía el error original.
    const ids = [
      bienId,
      bienSinOpcionalesId,
      bienInactivoId,
      bienDeArrendadorInactivoId,
    ].filter(Boolean);
    if (ids.length > 0) {
      await prisma.bien.deleteMany({ where: { id: { in: ids } } });
    }
    await prisma.usuario.deleteMany({
      where: { email: { in: [arrendador.email, arrendadorInactivo.email] } },
    });
    await app.close();
  });

  it('devuelve 200 con todos los campos públicos, sin token de sesión', async () => {
    const res = await consultar(bienId).expect(200);

    expect(res.body).toEqual({
      id: bienId,
      tipo: 'PROPIEDAD',
      categoria: 'Salón de eventos',
      titulo: `Detalle ${sufijo}`,
      descripcion: 'Salón climatizado con cocina y parqueo.',
      precio: 80.5,
      unidadCobro: 'DIA',
      deposito: 25,
      capacidad: 120,
      condiciones: 'No se permite pirotecnia',
      departamento: 'San Salvador',
      municipio: 'Antiguo Cuscatlán',
      direccionReferencia: 'Frente al parque central',
      arrendador: { id: arrendadorId, nombreUsuario: arrendador.nombreUsuario },
      fotos: expect.any(Array),
      calificacion: { promedio: null, totalResenas: 0 },
      creadoEn: expect.stringMatching(
        /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/,
      ),
    });
  });

  it('también responde con un token presente, aunque no lo necesita', async () => {
    await consultar(bienId)
      .set('Authorization', 'Bearer token-que-no-se-valida')
      .expect(200);
  });

  it('ordena las fotos con la principal primero y luego por orden', async () => {
    const res = await consultar(bienId).expect(200);

    expect(res.body.fotos).toEqual([
      { url: `/uploads/bienes/${sufijo}/3.webp`, orden: 3, esPrincipal: true },
      { url: `/uploads/bienes/${sufijo}/1.webp`, orden: 1, esPrincipal: false },
      { url: `/uploads/bienes/${sufijo}/2.webp`, orden: 2, esPrincipal: false },
    ]);
  });

  it('no expone email, hash ni datos internos', async () => {
    const res = await consultar(bienId).expect(200);
    const cuerpo = JSON.stringify(res.body);

    expect(Object.keys(res.body.arrendador).sort()).toEqual([
      'id',
      'nombreUsuario',
    ]);
    expect(cuerpo).not.toContain(arrendador.email);
    expect(cuerpo).not.toContain(arrendador.passwordHash);
    for (const interno of [
      'email',
      'passwordHash',
      'rol',
      'isActive',
      'arrendadorId',
      'estado',
      'actualizadoEn',
      'busqueda',
    ]) {
      expect(cuerpo).not.toContain(`"${interno}"`);
    }
  });

  it('devuelve números y null en los opcionales vacíos', async () => {
    const res = await consultar(bienSinOpcionalesId).expect(200);

    expect(res.body.deposito).toBe(0);
    expect(typeof res.body.precio).toBe('number');
    expect(res.body.capacidad).toBeNull();
    expect(res.body.condiciones).toBeNull();
    expect(res.body.direccionReferencia).toBeNull();
  });

  it('responde 404 si el bien está inactivo', async () => {
    const res = await consultar(bienInactivoId).expect(404);

    expect(res.body).toEqual({
      message: 'La publicación ya no está disponible.',
      error: 'Not Found',
      statusCode: 404,
    });
  });

  it('responde 404 si el bien está ACTIVA pero su arrendador está desactivado', async () => {
    const res = await consultar(bienDeArrendadorInactivoId).expect(404);

    expect(res.body).toEqual({
      message: 'La publicación ya no está disponible.',
      error: 'Not Found',
      statusCode: 404,
    });
  });

  it('responde 404 con el mismo mensaje si el bien no existe', async () => {
    const res = await consultar('00000000-0000-4000-8000-000000000000').expect(
      404,
    );

    expect(res.body.message).toBe('La publicación ya no está disponible.');
  });

  it('responde 400 si el id no es un UUID', async () => {
    const res = await consultar('no-es-uuid').expect(400);

    expect(res.body).toMatchObject({ error: 'Bad Request', statusCode: 400 });
  });

  it('responde en menos de 1 segundo', async () => {
    // La primera llamada ya calentó conexiones en las pruebas anteriores.
    const inicio = performance.now();
    await consultar(bienId).expect(200);
    const duracion = performance.now() - inicio;

    expect(duracion).toBeLessThan(1000);
  });
});
