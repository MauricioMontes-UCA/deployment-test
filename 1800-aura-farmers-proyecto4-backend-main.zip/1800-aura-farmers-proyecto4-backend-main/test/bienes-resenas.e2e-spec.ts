import type { INestApplication } from '@nestjs/common';
import request from 'supertest';
import { crearApp } from './helpers/crear-app.js';
import { PrismaService } from '@Prisma/services';

/**
 * Reseñas y calificación de un bien (BE-15.2) contra la base real.
 * Crea sus propios datos con sufijo único y los borra al final.
 */
describe('Reseñas públicas de un bien (e2e)', () => {
  let app: INestApplication;
  let prisma: PrismaService;

  const sufijo = Date.now().toString(36);
  const usuario = (prefijo: string, rol: 'ARRENDADOR' | 'ARRENDATARIO') => ({
    nombreUsuario: `${prefijo}_${sufijo}`,
    email: `${prefijo}_${sufijo}@example.com`,
    passwordHash: `hash-privado-${prefijo}-${sufijo}`,
    rol,
  });

  let arrendadorId = '';
  let arrendatarioId = '';
  let bienId = '';
  let bienSinResenasId = '';
  let bienInactivoId = '';
  let arrendadorInactivoId = '';
  let bienDeArrendadorInactivoId = '';
  const idsResenasBien: string[] = [];

  const dia = (n: number) => new Date(Date.UTC(2026, 0, 1 + n * 3));

  const nuevoBien = (titulo: string, extra: Record<string, unknown> = {}) =>
    prisma.bien.create({
      data: {
        arrendadorId,
        tipo: 'PROPIEDAD',
        categoria: 'Casa',
        titulo: `${titulo} ${sufijo}`,
        descripcion: 'Bien de prueba e2e',
        precio: 50,
        unidadCobro: 'DIA',
        departamento: 'San Salvador',
        municipio: 'San Salvador',
        ...extra,
      },
    });

  /** Una reserva finalizada con sus reseñas; devuelve los ids de las BIEN. */
  let contador = 0;
  const reservaConResenas = async (
    bien: string,
    resenas: {
      tipo: 'BIEN' | 'ARRENDADOR' | 'ARRENDATARIO';
      puntuacion: number;
      comentario?: string;
      creadaEn: Date;
    }[],
  ) => {
    contador += 1;
    const reserva = await prisma.reserva.create({
      data: {
        bienId: bien,
        arrendatarioId,
        fechaInicio: dia(contador),
        fechaFin: dia(contador),
        estado: 'FINALIZADA',
        finalizadaEn: new Date(),
      },
    });
    for (const r of resenas) {
      const creada = await prisma.resena.create({
        data: { reservaId: reserva.id, autorId: arrendatarioId, ...r },
      });
      if (r.tipo === 'BIEN') idsResenasBien.push(creada.id);
    }
  };

  const detalle = (id: string) =>
    request(app.getHttpServer()).get(`/api/v1/bienes/${id}`);
  const listado = (id: string, query = '') =>
    request(app.getHttpServer()).get(`/api/v1/bienes/${id}/resenas${query}`);

  beforeAll(async () => {
    app = await crearApp();
    prisma = app.get(PrismaService);

    arrendadorId = (
      await prisma.usuario.create({ data: usuario('rbd', 'ARRENDADOR') })
    ).id;
    arrendatarioId = (
      await prisma.usuario.create({ data: usuario('rbi', 'ARRENDATARIO') })
    ).id;
    bienId = (await nuevoBien('Con reseñas')).id;
    bienSinResenasId = (await nuevoBien('Sin reseñas')).id;
    bienInactivoId = (await nuevoBien('Inactivo', { estado: 'INACTIVA' })).id;
    arrendadorInactivoId = (
      await prisma.usuario.create({
        data: { ...usuario('rbx', 'ARRENDADOR'), isActive: false },
      })
    ).id;
    bienDeArrendadorInactivoId = (
      await nuevoBien('De arrendador inactivo', {
        arrendadorId: arrendadorInactivoId,
      })
    ).id;

    // 13 reseñas BIEN (puntuaciones 5,4,5,4,...) para probar la paginación; las
    // más antiguas con puntuación 1 y 2 para distinguirlas. Cada reserva trae
    // además una reseña ARRENDADOR de 1 estrella que no debe contar ni salir.
    const base = Date.UTC(2026, 5, 1, 12);
    for (let i = 0; i < 13; i += 1) {
      await reservaConResenas(bienId, [
        {
          tipo: 'BIEN',
          puntuacion: i === 0 ? 1 : i === 1 ? 2 : i % 2 === 0 ? 5 : 4,
          comentario: i === 3 ? undefined : `Comentario ${i}`,
          creadaEn: new Date(base + i * 60_000),
        },
        {
          tipo: 'ARRENDADOR',
          puntuacion: 1,
          comentario: 'Reseña sobre el arrendador',
          creadaEn: new Date(base + i * 60_000),
        },
      ]);
    }
    // Reservas de otros bienes no cuentan.
    await reservaConResenas(bienInactivoId, [
      { tipo: 'BIEN', puntuacion: 3, creadaEn: new Date(base) },
    ]);
  });

  afterAll(async () => {
    const bienes = [
      bienId,
      bienSinResenasId,
      bienInactivoId,
      bienDeArrendadorInactivoId,
    ].filter(Boolean);
    if (bienes.length > 0) {
      await prisma.resena.deleteMany({
        where: { reserva: { bienId: { in: bienes } } },
      });
      await prisma.reserva.deleteMany({ where: { bienId: { in: bienes } } });
      await prisma.bien.deleteMany({ where: { id: { in: bienes } } });
    }
    const usuarios = [
      arrendadorId,
      arrendatarioId,
      arrendadorInactivoId,
    ].filter(Boolean);
    if (usuarios.length > 0) {
      await prisma.usuario.deleteMany({ where: { id: { in: usuarios } } });
    }
    await app.close();
  });

  describe('calificación en el detalle', () => {
    it('promedio con un decimal y total, solo con reseñas BIEN', async () => {
      const respuesta = await detalle(bienId).expect(200);

      // 1 + 2 + (i=2..12: 6 pares de 5 y 5 impares de 4) = 3 + 30 + 20 = 53 → 53/13
      expect(respuesta.body.calificacion).toEqual({
        promedio: 4.1,
        totalResenas: 13,
      });
    });

    it('sin reseñas: promedio null y total 0', async () => {
      const respuesta = await detalle(bienSinResenasId).expect(200);

      expect(respuesta.body.calificacion).toEqual({
        promedio: null,
        totalResenas: 0,
      });
    });

    it('una reseña nueva aparece en la siguiente consulta', async () => {
      await reservaConResenas(bienSinResenasId, [
        { tipo: 'BIEN', puntuacion: 4, creadaEn: new Date() },
      ]);

      const respuesta = await detalle(bienSinResenasId).expect(200);
      expect(respuesta.body.calificacion).toEqual({
        promedio: 4,
        totalResenas: 1,
      });
      const lista = await listado(bienSinResenasId).expect(200);
      expect(lista.body.total).toBe(1);
    });
  });

  describe('GET /bienes/:bienId/resenas', () => {
    it('es público y pagina de 10 en 10, de la más reciente a la más antigua', async () => {
      const primera = await listado(bienId).expect(200);

      expect(primera.body).toMatchObject({
        pagina: 1,
        total: 13,
        hayMas: true,
      });
      expect(primera.body.items).toHaveLength(10);
      // La más reciente es la i=12.
      expect(primera.body.items[0]).toMatchObject({
        puntuacion: 5,
        comentario: 'Comentario 12',
        autor: { nombreUsuario: `rbi_${sufijo}` },
        creadaEn: new Date(Date.UTC(2026, 5, 1, 12, 12)).toISOString(),
      });

      const segunda = await listado(bienId, '?pagina=2').expect(200);
      expect(segunda.body).toMatchObject({
        pagina: 2,
        total: 13,
        hayMas: false,
      });
      // Las tres más antiguas: i=2, i=1 e i=0.
      expect(
        segunda.body.items.map((r: { puntuacion: number }) => r.puntuacion),
      ).toEqual([5, 2, 1]);
    });

    it('solo reseñas BIEN: ninguna sobre el arrendador y sin datos privados', async () => {
      const todas = [
        ...(await listado(bienId).expect(200)).body.items,
        ...(await listado(bienId, '?pagina=2').expect(200)).body.items,
      ];

      expect(todas).toHaveLength(13);
      expect(JSON.stringify(todas)).not.toContain('sobre el arrendador');
      expect(JSON.stringify(todas)).not.toContain('example.com');
      expect(JSON.stringify(todas)).not.toContain('hash-privado');
      for (const item of todas) {
        expect(Object.keys(item).sort()).toEqual(
          item.comentario === undefined
            ? ['autor', 'creadaEn', 'id', 'puntuacion']
            : ['autor', 'comentario', 'creadaEn', 'id', 'puntuacion'],
        );
      }
      expect(
        todas.some((r: { comentario?: string }) => r.comentario === undefined),
      ).toBe(true);
    });

    it('una página sin resultados devuelve items vacío', async () => {
      const respuesta = await listado(bienId, '?pagina=3').expect(200);

      expect(respuesta.body).toEqual({
        items: [],
        pagina: 3,
        total: 13,
        hayMas: false,
      });
    });

    it('un bien sin reseñas devuelve la lista vacía', async () => {
      // bienDeArrendadorInactivo no sirve: se usa uno publicado sin reseñas.
      const sinResenas = await nuevoBien('Vacío');
      try {
        const respuesta = await listado(sinResenas.id).expect(200);
        expect(respuesta.body).toEqual({
          items: [],
          pagina: 1,
          total: 0,
          hayMas: false,
        });
      } finally {
        await prisma.bien.delete({ where: { id: sinResenas.id } });
      }
    });

    it.each(['0', '-1', 'abc', '1.5', '10001'])(
      'responde 400 con la página %s',
      async (pagina) => {
        const respuesta = await listado(bienId, `?pagina=${pagina}`).expect(
          400,
        );

        expect(respuesta.body.message).toEqual(
          expect.arrayContaining([expect.stringContaining('página')]),
        );
      },
    );

    it('responde 400 si el bienId no es un UUID', async () => {
      await listado('no-es-uuid').expect(400);
    });

    it('responde 404 si el bien no existe, está INACTIVA o su arrendador está desactivado', async () => {
      for (const id of [
        '00000000-0000-4000-8000-00000000dead',
        bienInactivoId,
        bienDeArrendadorInactivoId,
      ]) {
        const respuesta = await listado(id).expect(404);
        expect(respuesta.body.message).toBe(
          'La publicación ya no está disponible.',
        );
      }
    });
  });
});
