import type { INestApplication } from '@nestjs/common';
import request from 'supertest';
import { PrismaService } from '@Prisma/services';
import { crearApp } from './helpers/crear-app.js';

/**
 * Búsqueda paginada de bienes (H3, BE-3.1) contra la base real (DATABASE_URL).
 *
 * Crea un arrendador y sus bienes con un sufijo único: las palabras y los
 * departamentos de las pruebas llevan ese sufijo, así que los resultados no se
 * mezclan con otros datos de la base. Lo borra todo al final. La búsqueda es
 * pública, por eso las peticiones no llevan token.
 */
describe('GET /bienes (e2e)', () => {
  let app: INestApplication;
  let prisma: PrismaService;
  let arrendadorId = '';

  const sufijo = Date.now().toString(36);
  const usuario = {
    nombreUsuario: `bus_${sufijo}`,
    email: `bus_${sufijo}@example.com`,
    password: 'Str0ngPass',
    rol: 'ARRENDADOR',
  };

  // Palabra que solo existe en los bienes de cada grupo de pruebas.
  const palabra = `zq${sufijo}`;
  const palabraPaginas = `pg${sufijo}`;
  const palabraMasiva = `mx${sufijo}`;

  const depto1 = `Depto Uno ${sufijo}`;
  const depto2 = `Depto Dos ${sufijo}`;
  const deptoPaginas = `Depto Paginas ${sufijo}`;
  const deptoMasivo = `Depto Masivo ${sufijo}`;
  const muni1 = `Muni Uno ${sufijo}`;
  const muni2 = `Muni Dos ${sufijo}`;

  const dia = (n: number) => new Date(Date.UTC(2030, 0, n));

  const datosBien = (parcial: {
    titulo: string;
    descripcion?: string;
    departamento: string;
    municipio?: string;
    estado?: 'ACTIVA' | 'INACTIVA';
    creadoEn?: Date;
  }) => ({
    arrendadorId,
    tipo: 'PROPIEDAD' as const,
    categoria: 'Casa',
    descripcion: 'Bien de prueba e2e',
    precio: 50,
    unidadCobro: 'NOCHE' as const,
    municipio: 'Municipio',
    ...parcial,
  });

  const buscar = (query: Record<string, string | number> = {}) =>
    request(app.getHttpServer()).get('/api/v1/bienes').query(query);

  const ids = (res: request.Response) =>
    (res.body.resultados as { id: string }[]).map((r) => r.id);

  let salon: string; // título con la palabra y tilde, depto 1
  let casa: string; // palabra solo en la descripción, depto 1, el más nuevo
  let inactivo: string; // palabra en el título pero INACTIVA
  let otro: string; // título con la palabra, depto 2

  beforeAll(async () => {
    app = await crearApp();
    prisma = app.get(PrismaService);

    await request(app.getHttpServer())
      .post('/api/v1/users')
      .send(usuario)
      .expect(201);
    const login = await request(app.getHttpServer())
      .post('/api/v1/auth/login')
      .send({ email: usuario.email, password: usuario.password })
      .expect(200);
    arrendadorId = login.body.user.id as string;

    // Del más viejo al más nuevo: salon < otro < casa.
    salon = (
      await prisma.bien.create({
        data: {
          ...datosBien({
            titulo: `Salón ${palabra} elegante`,
            departamento: depto1,
            municipio: muni1,
            creadoEn: dia(1),
          }),
          fotos: {
            create: [
              { url: '/uploads/bienes/x/2.jpg', orden: 2, esPrincipal: false },
              { url: '/uploads/bienes/x/1.jpg', orden: 1, esPrincipal: true },
            ],
          },
        },
      })
    ).id;
    otro = (
      await prisma.bien.create({
        data: datosBien({
          titulo: `Terraza ${palabra}`,
          departamento: depto2,
          municipio: muni2,
          creadoEn: dia(2),
        }),
      })
    ).id;
    casa = (
      await prisma.bien.create({
        data: datosBien({
          titulo: 'Casa del lago',
          descripcion: `Casa amplia con ${palabra} y jardín`,
          departamento: depto1,
          municipio: muni2,
          creadoEn: dia(3),
        }),
      })
    ).id;
    inactivo = (
      await prisma.bien.create({
        data: datosBien({
          titulo: `Inactivo ${palabra}`,
          departamento: depto1,
          municipio: muni1,
          estado: 'INACTIVA',
          creadoEn: dia(4),
        }),
      })
    ).id;

    // 25 bienes con el mismo creado_en: el desempate por id es lo que mantiene
    // estable el orden entre una página y la siguiente.
    await prisma.bien.createMany({
      data: Array.from({ length: 25 }, (_, i) =>
        datosBien({
          titulo: `Bien ${palabraPaginas} ${i + 1}`,
          departamento: deptoPaginas,
          creadoEn: dia(5),
        }),
      ),
    });

    await prisma.bien.createMany({
      data: Array.from({ length: 1000 }, (_, i) =>
        datosBien({
          titulo: `Bien ${palabraMasiva} ${i + 1}`,
          descripcion: i % 2 === 0 ? 'Con jardín y parqueo' : 'Con piscina',
          departamento: deptoMasivo,
          creadoEn: new Date(Date.UTC(2031, 0, 1, 0, 0, i)),
        }),
      ),
    });
  });

  afterAll(async () => {
    // Si beforeAll falló antes de crear el usuario, el id sigue vacío y filtrar
    // por una columna UUID con '' lanzaría un segundo error que taparía el
    // original.
    if (arrendadorId) {
      await prisma.bien.deleteMany({ where: { arrendadorId } });
    }
    await prisma.usuario.deleteMany({ where: { email: usuario.email } });
    await app.close();
  });

  describe('con texto', () => {
    it('devuelve primero los bienes cuyo título coincide y luego los de la descripción', async () => {
      const res = await buscar({ q: palabra }).expect(200);

      // `casa` es el más nuevo, pero coincide solo en la descripción: va al
      // final. Los dos de título van del más reciente al más antiguo.
      expect(ids(res)).toEqual([otro, salon, casa]);
      expect(res.body).toMatchObject({
        pagina: 1,
        tamanoPagina: 20,
        total: 3,
        hayMas: false,
      });
    });

    it('nunca devuelve bienes INACTIVA', async () => {
      const res = await buscar({ q: palabra }).expect(200);

      expect(ids(res)).not.toContain(inactivo);
    });

    it('ignora mayúsculas y tildes', async () => {
      // "salon" sin tilde y en mayúsculas encuentra "Salón".
      const res = await buscar({ q: `SALON ${palabra}` }).expect(200);

      expect(ids(res)).toEqual([salon]);
    });

    it('devuelve la forma esperada de cada resultado', async () => {
      const res = await buscar({ q: `salon ${palabra}` }).expect(200);

      expect(res.body.resultados).toEqual([
        {
          id: salon,
          titulo: `Salón ${palabra} elegante`,
          fotoPrincipal: '/uploads/bienes/x/1.jpg',
          precio: 50,
          unidadCobro: 'NOCHE',
          departamento: depto1,
          municipio: muni1,
        },
      ]);
    });

    it('fotoPrincipal es null si el bien no tiene fotos', async () => {
      const res = await buscar({ q: `lago ${palabra}` }).expect(200);

      expect(res.body.resultados).toHaveLength(1);
      expect(res.body.resultados[0]).toMatchObject({
        id: casa,
        fotoPrincipal: null,
      });
    });

    it('combina el texto con la ubicación', async () => {
      const res = await buscar({
        q: palabra,
        departamento: depto1,
        municipio: muni2,
      }).expect(200);

      expect(ids(res)).toEqual([casa]);
    });

    it('sin coincidencias devuelve una lista vacía', async () => {
      const res = await buscar({ q: `inexistente${sufijo}` }).expect(200);

      expect(res.body).toEqual({
        pagina: 1,
        tamanoPagina: 20,
        total: 0,
        hayMas: false,
        resultados: [],
      });
    });

    it.each([
      ['comillas dobles', `"${palabra}`],
      ['comilla simple', `${palabra}'`],
      ['inyección de SQL', `'; DROP TABLE "Bienes"; --`],
      ['barra invertida', `${palabra}\\`],
      ['operadores de búsqueda', `${palabra} -casa OR (terraza & !salon):*`],
      ['solo símbolos', '"" ( ) & | ! : * <->'],
      ['palabras vacías', 'de la el'],
      ['emoji', `${palabra} 🏠`],
    ])('un q con %s no rompe la consulta', async (_caso, q) => {
      await buscar({ q }).expect(200);
    });

    it('la tabla de bienes sigue intacta tras un q con SQL', async () => {
      await buscar({ q: `'; DROP TABLE "Bienes"; --` }).expect(200);

      const res = await buscar({ q: palabra }).expect(200);
      expect(res.body.total).toBe(3);
    });
  });

  describe('sin texto', () => {
    it('ordena del más reciente al más antiguo', async () => {
      const res = await buscar({ departamento: depto1 }).expect(200);

      // El INACTIVA (el más nuevo) no aparece.
      expect(ids(res)).toEqual([casa, salon]);
      expect(res.body.total).toBe(2);
    });

    it('un q vacío o de solo espacios se trata como búsqueda sin texto', async () => {
      const sinTexto = await buscar({ departamento: depto1 }).expect(200);
      const vacio = await buscar({ q: '', departamento: depto1 }).expect(200);
      const espacios = await buscar({
        q: '   ',
        departamento: depto1,
      }).expect(200);

      expect(ids(vacio)).toEqual(ids(sinTexto));
      expect(ids(espacios)).toEqual(ids(sinTexto));
    });
  });

  describe('ubicación', () => {
    it('filtra por departamento', async () => {
      const res = await buscar({ departamento: depto2 }).expect(200);

      expect(ids(res)).toEqual([otro]);
    });

    it('filtra por municipio', async () => {
      const res = await buscar({ municipio: muni1 }).expect(200);

      // El INACTIVA también está en muni1 y no debe salir.
      expect(ids(res)).toEqual([salon]);
    });

    it('combina departamento y municipio', async () => {
      const res = await buscar({
        departamento: depto1,
        municipio: muni2,
      }).expect(200);

      expect(ids(res)).toEqual([casa]);
    });

    it('un departamento sin bienes devuelve una lista vacía', async () => {
      const res = await buscar({ departamento: `Nadie ${sufijo}` }).expect(200);

      expect(res.body).toMatchObject({ total: 0, hayMas: false });
      expect(res.body.resultados).toEqual([]);
    });
  });

  describe('paginación', () => {
    it('devuelve como máximo 20 resultados por página y hayMas', async () => {
      const res = await buscar({ departamento: deptoPaginas }).expect(200);

      expect(res.body.resultados).toHaveLength(20);
      expect(res.body).toMatchObject({
        pagina: 1,
        tamanoPagina: 20,
        total: 25,
        hayMas: true,
      });
    });

    it('las páginas consecutivas no repiten ni saltan resultados', async () => {
      const paginas = [];
      for (const pagina of [1, 2, 3]) {
        paginas.push(
          await buscar({
            departamento: deptoPaginas,
            tamano: 10,
            pagina,
          }).expect(200),
        );
      }

      expect(paginas.map((p) => p.body.resultados.length)).toEqual([10, 10, 5]);
      expect(paginas.map((p) => p.body.hayMas)).toEqual([true, true, false]);
      expect(paginas.every((p) => p.body.total === 25)).toBe(true);

      const todos = paginas.flatMap(ids);
      expect(new Set(todos).size).toBe(25);

      // Todos tienen el mismo creado_en: el orden es por id descendente.
      const enBase = await prisma.bien.findMany({
        where: { arrendadorId, departamento: deptoPaginas },
        select: { id: true },
      });
      expect(todos).toEqual(
        enBase
          .map((b) => b.id)
          .sort()
          .reverse(),
      );
    });

    it('un texto también se pagina sin repetir ni saltar', async () => {
      const paginas = [];
      for (const pagina of [1, 2, 3]) {
        paginas.push(
          await buscar({ q: palabraPaginas, tamano: 10, pagina }).expect(200),
        );
      }

      const todos = paginas.flatMap(ids);
      expect(todos).toHaveLength(25);
      expect(new Set(todos).size).toBe(25);
      expect(paginas.map((p) => p.body.hayMas)).toEqual([true, true, false]);
    });

    it('una página fuera de rango devuelve una lista vacía', async () => {
      const res = await buscar({
        departamento: deptoPaginas,
        pagina: 99,
      }).expect(200);

      expect(res.body).toMatchObject({
        pagina: 99,
        total: 25,
        hayMas: false,
        resultados: [],
      });
    });

    it('acepta tamano = 1 y tamano = 50', async () => {
      const uno = await buscar({
        departamento: deptoPaginas,
        tamano: 1,
      }).expect(200);
      const cincuenta = await buscar({
        departamento: deptoPaginas,
        tamano: 50,
      }).expect(200);

      expect(uno.body.resultados).toHaveLength(1);
      expect(uno.body.hayMas).toBe(true);
      expect(cincuenta.body.resultados).toHaveLength(25);
      expect(cincuenta.body.hayMas).toBe(false);
    });
  });

  describe('validación', () => {
    it.each([
      ['pagina menor que 1', { pagina: 0 }],
      ['pagina negativa', { pagina: -1 }],
      ['pagina que no es número', { pagina: 'abc' }],
      ['pagina decimal', { pagina: '1.5' }],
      ['pagina mayor que el máximo', { pagina: 10_001 }],
      ['pagina que desborda el OFFSET', { pagina: '9999999999999999999' }],
      ['tamano 0', { tamano: 0 }],
      ['tamano mayor que 50', { tamano: 51 }],
      ['tamano que no es número', { tamano: 'abc' }],
      ['q de más de 100 caracteres', { q: 'a'.repeat(101) }],
      ['q con carácter nulo', { q: 'sa\u0000lon' }],
      ['parámetro desconocido', { foo: 'bar' }],
    ])('responde 400 con %s', async (_caso, query) => {
      const res = await request(app.getHttpServer())
        .get('/api/v1/bienes')
        .query(query as Record<string, string | number>)
        .expect(400);

      expect(res.body).toMatchObject({
        error: 'Bad Request',
        statusCode: 400,
      });
    });

    it('acepta la página máxima y responde vacío si no hay tantos resultados', async () => {
      const res = await buscar({ pagina: 10_000, tamano: 50 }).expect(200);
      expect(res.body).toMatchObject({ pagina: 10_000, resultados: [] });
    });

    it('acepta un q de exactamente 100 caracteres', async () => {
      await buscar({ q: 'a'.repeat(100) }).expect(200);
    });
  });

  describe('acceso', () => {
    it('es público: responde 200 sin token', async () => {
      await request(app.getHttpServer())
        .get('/api/v1/bienes')
        .query({ departamento: depto1 })
        .expect(200);
    });
  });

  describe('rendimiento', () => {
    it('responde en menos de 2 segundos con 1,000 bienes', async () => {
      // Calienta la conexión: se mide la consulta, no la primera conexión.
      await buscar({ departamento: deptoMasivo, tamano: 1 }).expect(200);

      const inicio = performance.now();
      const res = await buscar({
        q: palabraMasiva,
        departamento: deptoMasivo,
      }).expect(200);
      const ms = performance.now() - inicio;

      expect(res.body.total).toBe(1000);
      expect(res.body.resultados).toHaveLength(20);
      expect(ms).toBeLessThan(2000);
    });
  });
});
