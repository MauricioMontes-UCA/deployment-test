import { mkdtemp, readdir, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import type { INestApplication } from '@nestjs/common';
import request from 'supertest';
import { FotoNoGuardadaError } from '@Bienes/errors';
import { FotoStorageService } from '@Bienes/services';
import { PrismaService } from '@Prisma/services';
import { crearApp } from './helpers/crear-app.js';

/**
 * Pruebas de integración de la publicación de bienes (H1, BE-1.2) sobre
 * `POST /bienes` (BE-1.1), contra la base real (DATABASE_URL).
 *
 * Crea un arrendador y un arrendatario con sufijo único y guarda las fotos en
 * una carpeta temporal, no en `uploads/`. Antes de cada prueba borra los bienes
 * de esos usuarios y vacía esa carpeta, así que cada caso parte limpio sin
 * tocar el resto de la base. Al final borra todo lo que creó.
 */
describe('POST /bienes (e2e)', () => {
  let app: INestApplication;
  let prisma: PrismaService;
  let almacenamiento: FotoStorageService;
  let carpetaFotos = '';
  let uploadsDirOriginal: string | undefined;

  const sufijo = Date.now().toString(36);
  const password = 'Str0ngPass';
  const arrendador = {
    nombreUsuario: `pub_arr_${sufijo}`,
    email: `pub_arr_${sufijo}@example.com`,
    password,
    rol: 'ARRENDADOR',
  };
  const arrendatario = {
    nombreUsuario: `pub_ten_${sufijo}`,
    email: `pub_ten_${sufijo}@example.com`,
    password,
    rol: 'ARRENDATARIO',
  };

  let tokenArrendador = '';
  let tokenArrendatario = '';
  let arrendadorId = '';
  let arrendatarioId = '';

  // Archivos con la firma real de cada formato: el servidor detecta el formato
  // por los primeros bytes, no por la extensión ni por el mimetype.
  const jpg = (bytes = 1024) =>
    Buffer.concat([
      Buffer.from([0xff, 0xd8, 0xff, 0xe0]),
      Buffer.alloc(bytes - 4),
    ]);
  const gif = () => Buffer.concat([Buffer.from('GIF89a'), Buffer.alloc(64)]);

  const MB = 1024 * 1024;

  const formularioValido = {
    tipo: 'PROPIEDAD',
    categoria: 'Salón de eventos',
    titulo: 'Salón de eventos Las Palmas',
    descripcion: 'Salón climatizado con cocina, parqueo y mobiliario.',
    precio: '80',
    unidadCobro: 'DIA',
    deposito: '50',
    capacidad: '120',
    condiciones: 'No se permite fumar.',
    departamento: 'San Salvador',
    municipio: 'San Salvador',
    direccionReferencia: 'Frente al parque central',
  };

  interface Archivo {
    contenido: Buffer;
    nombre: string;
    tipo: string;
  }

  const foto = (n: number): Archivo => ({
    contenido: jpg(),
    nombre: `foto${n}.jpg`,
    tipo: 'image/jpeg',
  });

  /** Envía el formulario de publicación con los campos y las fotos dados. */
  const publicar = ({
    campos = {},
    fotos = [foto(1)],
    token = tokenArrendador,
  }: {
    campos?: Record<string, string>;
    fotos?: Archivo[];
    token?: string | null;
  } = {}) => {
    const peticion = request(app.getHttpServer()).post('/api/v1/bienes');
    if (token) peticion.set('Authorization', `Bearer ${token}`);
    for (const [clave, valor] of Object.entries({
      ...formularioValido,
      ...campos,
    })) {
      peticion.field(clave, valor);
    }
    for (const { contenido, nombre, tipo } of fotos) {
      peticion.attach('fotos', contenido, {
        filename: nombre,
        contentType: tipo,
      });
    }
    return peticion;
  };

  const usuarios = () => [arrendadorId, arrendatarioId].filter(Boolean);

  /** Bienes de los usuarios de la prueba que quedaron en la base. */
  const contarBienes = () =>
    prisma.bien.count({ where: { arrendadorId: { in: usuarios() } } });
  const contarFotos = () =>
    prisma.fotoBien.count({
      where: { bien: { arrendadorId: { in: usuarios() } } },
    });

  /** Archivos que hay en la carpeta de fotos (una subcarpeta por bien). */
  const archivosEnDisco = async () => {
    const carpetaBienes = path.join(carpetaFotos, 'bienes');
    const bienes = await readdir(carpetaBienes).catch(() => [] as string[]);
    const archivos: string[] = [];
    for (const bien of bienes) {
      for (const archivo of await readdir(path.join(carpetaBienes, bien))) {
        archivos.push(`${bien}/${archivo}`);
      }
    }
    return archivos;
  };

  const registrarEIniciarSesion = async (usuario: typeof arrendador) => {
    await request(app.getHttpServer())
      .post('/api/v1/users')
      .send(usuario)
      .expect(201);
    const login = await request(app.getHttpServer())
      .post('/api/v1/auth/login')
      .send({ email: usuario.email, password: usuario.password })
      .expect(200);
    return {
      token: login.body.accessToken as string,
      id: login.body.user.id as string,
    };
  };

  beforeAll(async () => {
    // Las fotos van a una carpeta temporal. La variable se fija antes de crear
    // la aplicación porque ConfigModule la lee al importar AppModule, y se
    // restaura en afterAll para no afectar a otros archivos del mismo worker.
    uploadsDirOriginal = process.env.UPLOADS_DIR;
    carpetaFotos = await mkdtemp(path.join(tmpdir(), 'bienes-e2e-'));
    process.env.UPLOADS_DIR = carpetaFotos;

    app = await crearApp();
    prisma = app.get(PrismaService);
    almacenamiento = app.get(FotoStorageService);

    ({ token: tokenArrendador, id: arrendadorId } =
      await registrarEIniciarSesion(arrendador));
    ({ token: tokenArrendatario, id: arrendatarioId } =
      await registrarEIniciarSesion(arrendatario));
  });

  // Base limpia en cada prueba: sin bienes de los usuarios de la prueba y sin
  // archivos en la carpeta de fotos.
  beforeEach(async () => {
    vi.restoreAllMocks();
    await prisma.bien.deleteMany({
      where: { arrendadorId: { in: usuarios() } },
    });
    await rm(path.join(carpetaFotos, 'bienes'), {
      recursive: true,
      force: true,
    });
  });

  afterAll(async () => {
    vi.restoreAllMocks();
    // Si beforeAll falló a medias, `app`, `prisma` y los ids pueden no existir,
    // y si la base no responde la limpieza también falla. Cada paso va dentro
    // de un finally para que un fallo no impida los siguientes: la carpeta
    // temporal se borra y el entorno se restaura siempre, y el error que se
    // reporta sigue siendo el primero.
    try {
      if (prisma) {
        if (usuarios().length > 0) {
          await prisma.bien.deleteMany({
            where: { arrendadorId: { in: usuarios() } },
          });
        }
        await prisma.usuario.deleteMany({
          where: { email: { in: [arrendador.email, arrendatario.email] } },
        });
      }
    } finally {
      try {
        await app?.close();
      } finally {
        if (carpetaFotos) {
          await rm(carpetaFotos, { recursive: true, force: true });
        }
        if (uploadsDirOriginal === undefined) delete process.env.UPLOADS_DIR;
        else process.env.UPLOADS_DIR = uploadsDirOriginal;
      }
    }
  });

  it('1. publicación válida con 3 fotos responde 201 y guarda 1 bien y 3 fotos', async () => {
    const res = await publicar({
      fotos: [foto(1), foto(2), foto(3)],
    }).expect(201);

    expect(res.body).toMatchObject({
      titulo: formularioValido.titulo,
      precio: 80,
      unidadCobro: 'DIA',
      estado: 'ACTIVA',
    });
    expect(res.body.fotos).toHaveLength(3);
    // Sin indicePrincipal, la primera foto es la principal.
    expect(
      res.body.fotos.map((f: { orden: number; esPrincipal: boolean }) => [
        f.orden,
        f.esPrincipal,
      ]),
    ).toEqual([
      [1, true],
      [2, false],
      [3, false],
    ]);

    expect(await contarBienes()).toBe(1);
    expect(await contarFotos()).toBe(3);

    const guardado = await prisma.bien.findUniqueOrThrow({
      where: { id: res.body.id as string },
    });
    // El arrendador sale del token, no del formulario.
    expect(guardado.arrendadorId).toBe(arrendadorId);
    expect(await archivosEnDisco()).toHaveLength(3);
  });

  it('2. sin fotos responde 400', async () => {
    const res = await publicar({ fotos: [] }).expect(400);

    expect(JSON.stringify(res.body.message)).toContain(
      'Debes subir al menos una foto.',
    );
    expect(await contarBienes()).toBe(0);
  });

  it('3. precio 0 responde 400', async () => {
    const res = await publicar({ campos: { precio: '0' } }).expect(400);

    expect(JSON.stringify(res.body.message)).toContain(
      'El precio debe ser mayor que 0.',
    );
    expect(await contarBienes()).toBe(0);
  });

  it('4. título de 101 caracteres responde 400', async () => {
    const res = await publicar({
      campos: { titulo: 'a'.repeat(101) },
    }).expect(400);

    expect(JSON.stringify(res.body.message)).toContain(
      'El título no puede superar los 100 caracteres.',
    );
    expect(await contarBienes()).toBe(0);
  });

  it('5. archivo .gif responde 400', async () => {
    const res = await publicar({
      fotos: [{ contenido: gif(), nombre: 'animacion.gif', tipo: 'image/gif' }],
    }).expect(400);

    expect(JSON.stringify(res.body.message)).toContain(
      'debe ser JPG, PNG o WEBP',
    );
    expect(await contarBienes()).toBe(0);
    expect(await archivosEnDisco()).toEqual([]);
  });

  it('6. archivo de 6 MB responde 400', async () => {
    const res = await publicar({
      fotos: [
        {
          contenido: jpg(6 * MB),
          nombre: 'enorme.jpg',
          tipo: 'image/jpeg',
        },
      ],
    }).expect(400);

    // El texto del límite de lectura (multer). El pipe tiene otro mensaje, que
    // también menciona 5 MB; si este límite se quitara, el caso debe fallar.
    expect(JSON.stringify(res.body.message)).toContain(
      'Cada foto debe pesar como máximo 5 MB.',
    );
    expect(await contarBienes()).toBe(0);
    expect(await archivosEnDisco()).toEqual([]);
  });

  it('7. 11 fotos responde 400', async () => {
    const res = await publicar({
      fotos: Array.from({ length: 11 }, (_, i) => foto(i + 1)),
    }).expect(400);

    expect(JSON.stringify(res.body.message)).toContain('máximo 10 fotos');
    expect(await contarBienes()).toBe(0);
    expect(await archivosEnDisco()).toEqual([]);
  });

  it('8. usuario con rol ARRENDATARIO responde 403', async () => {
    await publicar({ token: tokenArrendatario }).expect(403);

    expect(await contarBienes()).toBe(0);
  });

  it('9. sin token responde 401', async () => {
    await publicar({ token: null }).expect(401);

    expect(await contarBienes()).toBe(0);
  });

  it('10. un fallo al guardar una foto no deja filas ni archivos', async () => {
    // La primera y la segunda foto se escriben de verdad; la tercera falla.
    // Así el caso comprueba que se borra lo que ya estaba en disco.
    const guardarReal = almacenamiento.guardar.bind(almacenamiento);
    let llamadas = 0;
    const espia = vi
      .spyOn(almacenamiento, 'guardar')
      .mockImplementation((bienId, orden, archivo) => {
        llamadas += 1;
        if (llamadas === 3) {
          return Promise.reject(new FotoNoGuardadaError(bienId, orden));
        }
        return guardarReal(bienId, orden, archivo);
      });

    const res = await publicar({
      fotos: [foto(1), foto(2), foto(3)],
    }).expect(500);

    // Es el error de almacenamiento y no otro 500 (por ejemplo, de la base).
    expect(res.body.message).toBe(
      'No se pudieron guardar las fotos. Intenta publicar de nuevo.',
    );
    expect(espia).toHaveBeenCalledTimes(3);
    expect(await contarBienes()).toBe(0);
    expect(await contarFotos()).toBe(0);
    expect(await archivosEnDisco()).toEqual([]);
  });
});
