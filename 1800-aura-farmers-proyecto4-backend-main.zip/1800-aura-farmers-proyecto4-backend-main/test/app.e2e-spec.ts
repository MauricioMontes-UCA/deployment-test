import type { INestApplication } from '@nestjs/common';
import request from 'supertest';
import { crearApp } from './helpers/crear-app.js';
import { PrismaService } from '@Prisma/services';

/**
 * Flujo de autenticación completo contra la base real (DATABASE_URL).
 *
 * Crea un usuario con sufijo único y lo borra al final; los refresh tokens se
 * van con él por el onDelete: Cascade.
 */
describe('Auth con rol (e2e)', () => {
  let app: INestApplication;
  let prisma: PrismaService;

  const sufijo = Date.now().toString(36);
  const usuario = {
    nombreUsuario: `e2e_${sufijo}`,
    email: `e2e_${sufijo}@example.com`,
    password: 'Str0ngPass',
    rol: 'ARRENDADOR',
  };

  let accessToken = '';
  let refreshToken = '';

  const decodificar = (token: string) =>
    JSON.parse(
      Buffer.from(token.split('.')[1]!, 'base64url').toString('utf8'),
    ) as {
      sub: string;
      email: string;
      rol: string;
    };

  beforeAll(async () => {
    app = await crearApp();
    prisma = app.get(PrismaService);
  });

  afterAll(async () => {
    await prisma.usuario.deleteMany({ where: { email: usuario.email } });
    await app.close();
  });

  it('POST /users registra y devuelve nombreUsuario y rol', async () => {
    const res = await request(app.getHttpServer())
      .post('/api/v1/users')
      .send(usuario)
      .expect(201);

    expect(res.body).toMatchObject({
      nombreUsuario: usuario.nombreUsuario,
      email: usuario.email,
      rol: 'ARRENDADOR',
    });
    expect(res.body).not.toHaveProperty('passwordHash');
  });

  it('POST /auth/login firma sub, email y rol en el access token', async () => {
    const res = await request(app.getHttpServer())
      .post('/api/v1/auth/login')
      .send({ email: usuario.email, password: usuario.password })
      .expect(200);

    accessToken = res.body.accessToken as string;
    refreshToken = res.body.refreshToken as string;

    expect(decodificar(accessToken)).toMatchObject({
      sub: res.body.user.id,
      email: usuario.email,
      rol: 'ARRENDADOR',
    });
    expect(res.body.user).toMatchObject({
      nombreUsuario: usuario.nombreUsuario,
      rol: 'ARRENDADOR',
    });
    expect(res.body.user).not.toHaveProperty('passwordHash');
  });

  it('GET /auth/me devuelve el usuario con nombreUsuario y rol', async () => {
    const res = await request(app.getHttpServer())
      .get('/api/v1/auth/me')
      .set('Authorization', `Bearer ${accessToken}`)
      .expect(200);

    expect(res.body).toMatchObject({
      nombreUsuario: usuario.nombreUsuario,
      email: usuario.email,
      rol: 'ARRENDADOR',
    });
    expect(res.body).not.toHaveProperty('passwordHash');
  });

  it('si el rol cambia en la base, la siguiente request ya usa el rol nuevo', async () => {
    await prisma.usuario.update({
      where: { email: usuario.email },
      data: { rol: 'ARRENDATARIO' },
    });

    // Mismo token (con el rol viejo): /auth/me ya refleja el rol de la base.
    const res = await request(app.getHttpServer())
      .get('/api/v1/auth/me')
      .set('Authorization', `Bearer ${accessToken}`)
      .expect(200);

    expect(res.body.rol).toBe('ARRENDATARIO');
  });

  it('POST /auth/refresh emite un access token con el rol vigente en la base', async () => {
    const res = await request(app.getHttpServer())
      .post('/api/v1/auth/refresh')
      .send({ refreshToken })
      .expect(200);

    expect(decodificar(res.body.accessToken as string).rol).toBe(
      'ARRENDATARIO',
    );
  });

  it('un token con el rol modificado a mano recibe 401', async () => {
    const [cabecera, , firma] = accessToken.split('.');
    const original = decodificar(accessToken);
    // Se cambia al rol contrario al que firmó el servidor. Si se pusiera el
    // mismo rol, el payload sería idéntico y la firma seguiría siendo válida.
    const rolFalso =
      original.rol === 'ARRENDADOR' ? 'ARRENDATARIO' : 'ARRENDADOR';
    const payloadFalso = Buffer.from(
      JSON.stringify({ ...original, rol: rolFalso }),
    ).toString('base64url');

    await request(app.getHttpServer())
      .get('/api/v1/auth/me')
      .set('Authorization', `Bearer ${cabecera}.${payloadFalso}.${firma}`)
      .expect(401);
  });
});
