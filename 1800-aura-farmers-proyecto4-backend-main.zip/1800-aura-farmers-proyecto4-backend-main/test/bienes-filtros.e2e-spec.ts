import type { INestApplication } from '@nestjs/common';
import request from 'supertest';
import { formatDia, hoyEn, ZONA_HORARIA } from '@Bienes/utils';
import { DisponibilidadRepository } from '@Bienes/repositories';
import { PrismaService } from '@Prisma/services';
import type { EstadoReserva, Prisma } from '@PrismaClient';
import { crearApp } from './helpers/crear-app.js';

/**
 * Filtros de la búsqueda de bienes (H4, BE-4.1) contra la base real
 * (DATABASE_URL).
 *
 * Cada grupo de pruebas usa su propio departamento con un sufijo único, así
 * los resultados no se mezclan entre grupos ni con otros datos de la base. Las
 * fechas se calculan desde hoy en El Salvador para que el periodo siempre sea
 * futuro. Todo se borra al final. La búsqueda es pública: no lleva token.
 */
describe('GET /bienes con filtros (e2e)', () => {
  let app: INestApplication;
  let prisma: PrismaService;
  let arrendadorId = '';
  let arrendatarioId = '';

  const sufijo = Date.now().toString(36);
  const password = 'Str0ngPass';
  const usuario = (prefijo: string, rol: string) => ({
    nombreUsuario: `${prefijo}_${sufijo}`,
    email: `${prefijo}_${sufijo}@example.com`,
    password,
    rol,
  });
  const dueno = usuario('filt_dueno', 'ARRENDADOR');
  const inquilino = usuario('filt_inq', 'ARRENDATARIO');

  const DEPTO_FILTROS = `Filtros ${sufijo}`;
  const DEPTO_FECHAS = `Fechas ${sufijo}`;
  const DEPTO_VOLUMEN = `Volumen ${sufijo}`;

  const MS_POR_DIA = 24 * 60 * 60 * 1000;
  const hoy = hoyEn(ZONA_HORARIA);
  /** Día `n` días después de hoy, como Date a medianoche UTC. */
  const enDias = (n: number) => new Date(hoy.getTime() + n * MS_POR_DIA);
  const dia = (n: number) => formatDia(enDias(n));
  // El periodo que se consulta: del día 30 al 32 desde hoy, inclusive.
  const INICIO = 30;
  const FIN = 32;
  const periodo = { fechaInicio: dia(INICIO), fechaFin: dia(FIN) };

  const ids: Record<string, string> = {};

  const registrarse = async (datos: ReturnType<typeof usuario>) => {
    await request(app.getHttpServer())
      .post('/api/v1/users')
      .send(datos)
      .expect(201);
    const login = await request(app.getHttpServer())
      .post('/api/v1/auth/login')
      .send({ email: datos.email, password: datos.password })
      .expect(200);
    return login.body.user.id as string;
  };

  const crearBien = async (
    nombre: string,
    datos: Partial<Prisma.BienUncheckedCreateInput> = {},
  ) => {
    const bien = await prisma.bien.create({
      data: {
        arrendadorId,
        tipo: 'PROPIEDAD',
        categoria: 'Salón de eventos',
        titulo: `${nombre} ${sufijo}`,
        descripcion: 'Bien de prueba e2e',
        precio: 50,
        unidadCobro: 'DIA',
        capacidad: 100,
        departamento: DEPTO_FILTROS,
        municipio: 'San Salvador',
        ...datos,
      },
    });
    ids[nombre] = bien.id;
    return bien.id;
  };

  const reservar = (
    bienId: string,
    desde: number,
    hasta: number,
    estado: EstadoReserva = 'CONFIRMADA',
  ) =>
    prisma.reserva.create({
      data: {
        bienId,
        arrendatarioId,
        fechaInicio: enDias(desde),
        fechaFin: enDias(hasta),
        estado,
      },
    });

  const bloquear = (bienId: string, desde: number, hasta: number) =>
    prisma.bloqueoFecha.create({
      data: { bienId, fechaInicio: enDias(desde), fechaFin: enDias(hasta) },
    });

  const buscar = (query: Record<string, string | number>) =>
    request(app.getHttpServer()).get('/api/v1/bienes').query(query);

  /** Nombres de los bienes encontrados, en el orden de la respuesta. */
  const nombres = (body: { resultados: { id: string }[] }) => {
    const porId = Object.fromEntries(
      Object.entries(ids).map(([nombre, id]) => [id, nombre]),
    );
    return body.resultados.map((r) => porId[r.id]).sort();
  };

  beforeAll(async () => {
    app = await crearApp();
    prisma = app.get(PrismaService);
    arrendadorId = await registrarse(dueno);
    arrendatarioId = await registrarse(inquilino);

    // Filtros de atributos.
    await crearBien('salonBarato', { precio: 50, capacidad: 100 });
    await crearBien('salonCaro', { precio: 150, capacidad: 30 });
    await crearBien('sonido', {
      tipo: 'EQUIPO',
      categoria: 'Audio y sonido',
      precio: 20,
      capacidad: null,
    });
    await crearBien('casa', { categoria: 'Casa', precio: 80, capacidad: 10 });
    await crearBien('inactivo', { estado: 'INACTIVA' });

    // Disponibilidad: un bien por caso, para no chocar con la restricción
    // que impide solapar reservas confirmadas del mismo bien.
    const enFechas = { departamento: DEPTO_FECHAS };
    await reservar(await crearBien('cruzaUnDia', enFechas), INICIO - 3, INICIO);
    await reservar(
      await crearBien('terminaAntes', enFechas),
      INICIO - 3,
      INICIO - 1,
    );
    await reservar(
      await crearBien('empiezaDespues', enFechas),
      FIN + 1,
      FIN + 4,
    );
    await reservar(await crearBien('cubreTodo', enFechas), INICIO - 1, FIN + 1);
    await reservar(
      await crearBien('adentro', enFechas),
      INICIO + 1,
      INICIO + 1,
    );
    await reservar(
      await crearBien('enCurso', enFechas),
      INICIO,
      FIN,
      'EN_CURSO',
    );
    await reservar(
      await crearBien('finalizada', enFechas),
      INICIO,
      FIN,
      'FINALIZADA',
    );
    await reservar(await crearBien('enCola', enFechas), INICIO, FIN, 'EN_COLA');
    await reservar(
      await crearBien('rechazada', enFechas),
      INICIO,
      FIN,
      'RECHAZADA',
    );
    await reservar(
      await crearBien('cancelada', enFechas),
      INICIO,
      FIN,
      'CANCELADA',
    );
    await bloquear(await crearBien('bloqueoUltimoDia', enFechas), FIN, FIN + 2);
    await bloquear(
      await crearBien('bloqueoDespues', enFechas),
      FIN + 1,
      FIN + 2,
    );
    await crearBien('libre', enFechas);
  });

  afterAll(async () => {
    // Si beforeAll falló a medias, `prisma` y los ids pueden no existir: no hay
    // que filtrar por una columna UUID con '' ni tapar el error original.
    try {
      if (prisma) {
        if (arrendadorId) {
          const deLosBienes = { bien: { arrendadorId } };
          await prisma.reserva.deleteMany({ where: deLosBienes });
          await prisma.bloqueoFecha.deleteMany({ where: deLosBienes });
          await prisma.bien.deleteMany({ where: { arrendadorId } });
        }
        await prisma.usuario.deleteMany({
          where: { email: { in: [dueno.email, inquilino.email] } },
        });
      }
    } finally {
      await app?.close();
    }
  });

  describe('precio, tipo, categoría y capacidad', () => {
    const filtrar = (query: Record<string, string | number>) =>
      buscar({ departamento: DEPTO_FILTROS, ...query }).expect(200);

    it('sin filtros trae todos los activos', async () => {
      const res = await filtrar({});
      expect(nombres(res.body)).toEqual([
        'casa',
        'salonBarato',
        'salonCaro',
        'sonido',
      ]);
      expect(res.body.total).toBe(4);
    });

    it('precioMin y precioMax son inclusivos', async () => {
      const res = await filtrar({ precioMin: 50, precioMax: 80 });
      expect(nombres(res.body)).toEqual(['casa', 'salonBarato']);
    });

    it('solo precioMin', async () => {
      const res = await filtrar({ precioMin: 81 });
      expect(nombres(res.body)).toEqual(['salonCaro']);
    });

    it('solo precioMax', async () => {
      const res = await filtrar({ precioMax: 20 });
      expect(nombres(res.body)).toEqual(['sonido']);
    });

    it('tipo', async () => {
      const res = await filtrar({ tipo: 'EQUIPO' });
      expect(nombres(res.body)).toEqual(['sonido']);
    });

    it('categoría exacta', async () => {
      const res = await filtrar({ categoria: 'Salón de eventos' });
      expect(nombres(res.body)).toEqual(['salonBarato', 'salonCaro']);
    });

    it.each(['salon de eventos', 'SALÓN DE EVENTOS', ' Salon De Eventos '])(
      'la categoría no distingue mayúsculas ni tildes: %j',
      async (categoria) => {
        const res = await filtrar({ categoria });
        expect(nombres(res.body)).toEqual(['salonBarato', 'salonCaro']);
      },
    );

    it('los límites de precio son exactos con centavos', async () => {
      const id = await crearBien('centavos', { precio: 19.99 });
      try {
        const igual = await filtrar({ precioMin: 19.99, precioMax: 19.99 });
        expect(nombres(igual.body)).toEqual(['centavos']);
        const desdeVeinte = await filtrar({ precioMin: 20 });
        expect(nombres(desdeVeinte.body)).not.toContain('centavos');
        const porDebajo = await filtrar({ precioMin: 19.98, precioMax: 19.98 });
        expect(nombres(porDebajo.body)).toEqual([]);
      } finally {
        await prisma.bien.delete({ where: { id } });
        delete ids.centavos;
      }
    });

    it('capacidadMin excluye a los que no tienen capacidad registrada', async () => {
      const res = await filtrar({ capacidadMin: 10 });
      expect(nombres(res.body)).toEqual(['casa', 'salonBarato', 'salonCaro']);
    });

    it('capacidadMin es inclusiva', async () => {
      const res = await filtrar({ capacidadMin: 30 });
      expect(nombres(res.body)).toEqual(['salonBarato', 'salonCaro']);
    });

    it('combina los filtros con AND y total cuenta solo los filtrados', async () => {
      const res = await filtrar({
        tipo: 'PROPIEDAD',
        categoria: 'Salón de eventos',
        precioMax: 100,
        capacidadMin: 50,
      });
      expect(nombres(res.body)).toEqual(['salonBarato']);
      expect(res.body).toMatchObject({ total: 1, hayMas: false });
    });

    it('nunca devuelve un bien INACTIVA aunque cumpla los filtros', async () => {
      const res = await filtrar({ precioMin: 50, precioMax: 50 });
      expect(nombres(res.body)).toEqual(['salonBarato']);
    });

    it('sin coincidencias responde vacío con total 0', async () => {
      const res = await filtrar({ tipo: 'EQUIPO', capacidadMin: 1 });
      expect(res.body).toMatchObject({ total: 0, resultados: [] });
    });

    it.each([
      ['precioMin', { precioMin: '' }],
      ['precioMax', { precioMax: '' }],
      ['capacidadMin', { capacidadMin: '' }],
      [
        'todos los numéricos',
        { precioMin: '', precioMax: ' ', capacidadMin: '' },
      ],
    ])('un %s vacío se ignora, como el texto vacío', async (_caso, query) => {
      const res = await filtrar(query);
      expect(res.body.total).toBe(4);
    });

    it('se combina con el texto de H3', async () => {
      const res = await filtrar({ q: 'salonCaro', precioMin: 100 });
      expect(nombres(res.body)).toEqual(['salonCaro']);
    });
  });

  describe('disponibilidad en el periodo', () => {
    it('excluye los bienes con reservas que ocupan días o bloqueos que se cruzan', async () => {
      const res = await buscar({
        departamento: DEPTO_FECHAS,
        ...periodo,
      }).expect(200);

      expect(nombres(res.body)).toEqual([
        'bloqueoDespues',
        'cancelada',
        'empiezaDespues',
        'enCola',
        'libre',
        'rechazada',
        'terminaAntes',
      ]);
      expect(res.body.total).toBe(7);
    });

    it.each([
      ['una reserva confirmada que se cruza un solo día', 'cruzaUnDia'],
      ['una reserva que cubre todo el periodo', 'cubreTodo'],
      ['una reserva dentro del periodo', 'adentro'],
      ['una renta EN_CURSO', 'enCurso'],
      ['una reserva FINALIZADA', 'finalizada'],
      ['un bloqueo en el último día', 'bloqueoUltimoDia'],
    ])('no aparece un bien con %s', async (_caso, nombre) => {
      const res = await buscar({
        departamento: DEPTO_FECHAS,
        ...periodo,
      }).expect(200);
      expect(nombres(res.body)).not.toContain(nombre);
    });

    it('coincide con el calendario: un bien sale de la búsqueda si y solo si el calendario lo muestra ocupado', async () => {
      const calendario = app.get(DisponibilidadRepository);
      const res = await buscar({
        departamento: DEPTO_FECHAS,
        tamano: 50,
        ...periodo,
      }).expect(200);
      const encontrados = new Set(
        res.body.resultados.map((r: { id: string }) => r.id),
      );
      const enFechas = await prisma.bien.findMany({
        where: { departamento: DEPTO_FECHAS },
        select: { id: true },
      });

      for (const { id } of enFechas) {
        const { reservados, bloqueados } = await calendario.findOcupados(
          id,
          enDias(INICIO),
          enDias(FIN),
        );
        const ocupado = reservados.length + bloqueados.length > 0;
        expect(encontrados.has(id)).toBe(!ocupado);
      }
    });

    it('sin fechas aparecen todos, ocupados o no', async () => {
      const res = await buscar({
        departamento: DEPTO_FECHAS,
        tamano: 50,
      }).expect(200);
      expect(res.body.total).toBe(13);
    });

    it('un periodo de un solo día que empieza hoy es válido', async () => {
      await buscar({
        departamento: DEPTO_FECHAS,
        fechaInicio: dia(0),
        fechaFin: dia(0),
      }).expect(200);
    });

    it('el bien con reserva en un solo día aparece si el periodo no lo toca', async () => {
      const res = await buscar({
        departamento: DEPTO_FECHAS,
        fechaInicio: dia(INICIO + 1),
        fechaFin: dia(FIN),
      }).expect(200);
      expect(nombres(res.body)).toContain('cruzaUnDia');
    });
  });

  describe('validación (400)', () => {
    it.each([
      [
        'precio negativo',
        { precioMin: -1 },
        'El precio mínimo no puede ser negativo.',
      ],
      [
        'precioMin mayor que precioMax',
        { precioMin: 100, precioMax: 20 },
        'El precio mínimo no puede ser mayor que el precio máximo.',
      ],
      [
        'tipo fuera del enum',
        { tipo: 'CASA' },
        'El tipo debe ser PROPIEDAD o EQUIPO.',
      ],
      [
        'una categoría que no es del catálogo',
        { categoria: 'Castillo' },
        'La categoría no existe.',
      ],
      [
        'capacidadMin menor que 1',
        { capacidadMin: 0 },
        'La capacidad mínima debe ser 1 o mayor.',
      ],
      [
        'capacidadMin que no cabe en INTEGER',
        { capacidadMin: '99999999999' },
        'La capacidad mínima es demasiado grande.',
      ],
      [
        'solo la fecha de inicio',
        { fechaInicio: '2099-01-01' },
        'Para filtrar por disponibilidad indica la fecha de inicio y la fecha de fin.',
      ],
      [
        'solo la fecha de fin',
        { fechaFin: '2099-01-01' },
        'Para filtrar por disponibilidad indica la fecha de inicio y la fecha de fin.',
      ],
      [
        'fechaFin anterior a fechaInicio',
        { fechaInicio: '2099-01-05', fechaFin: '2099-01-01' },
        'La fecha de fin no puede ser anterior a la fecha de inicio.',
      ],
      [
        'una fecha que no existe',
        { fechaInicio: '2099-02-30', fechaFin: '2099-03-01' },
        'La fecha de inicio no es un día válido.',
      ],
      [
        'una fecha con otro formato',
        { fechaInicio: '01/01/2099', fechaFin: '2099-01-05' },
        'La fecha de inicio debe tener el formato YYYY-MM-DD.',
      ],
    ])('%s', async (_caso, query, mensaje) => {
      const res = await buscar(query).expect(400);

      expect(res.body).toMatchObject({ error: 'Bad Request', statusCode: 400 });
      // Siempre una lista, venga el error del DTO o del servicio.
      expect(Array.isArray(res.body.message)).toBe(true);
      expect(res.body.message.some((m: string) => m.startsWith(mensaje))).toBe(
        true,
      );
    });

    it('fechaInicio anterior a hoy', async () => {
      const res = await buscar({
        fechaInicio: dia(-1),
        fechaFin: dia(2),
      }).expect(400);
      expect(res.body.message).toEqual([
        'La fecha de inicio no puede ser anterior a hoy.',
      ]);
    });
  });

  describe('rendimiento', () => {
    beforeAll(async () => {
      await prisma.bien.createMany({
        data: Array.from({ length: 1000 }, (_, i) => ({
          arrendadorId,
          tipo: 'PROPIEDAD' as const,
          categoria: 'Salón de eventos',
          titulo: `Salon volumen ${i} ${sufijo}`,
          descripcion: 'Salón amplio para eventos',
          precio: 20 + (i % 100),
          unidadCobro: 'DIA' as const,
          capacidad: 20 + (i % 200),
          departamento: DEPTO_VOLUMEN,
          municipio: 'San Salvador',
        })),
      });
      // Ocupa una parte de los bienes en el periodo, con reservas y bloqueos.
      const bienes = await prisma.bien.findMany({
        where: { departamento: DEPTO_VOLUMEN },
        select: { id: true },
        take: 200,
      });
      await prisma.reserva.createMany({
        data: bienes.slice(0, 100).map(({ id }) => ({
          bienId: id,
          arrendatarioId,
          fechaInicio: enDias(INICIO),
          fechaFin: enDias(FIN),
          estado: 'CONFIRMADA' as const,
        })),
      });
      await prisma.bloqueoFecha.createMany({
        data: bienes.slice(100).map(({ id }) => ({
          bienId: id,
          fechaInicio: enDias(FIN),
          fechaFin: enDias(FIN),
        })),
      });
    });

    it('responde en menos de 2 segundos con 1,000 bienes y todos los filtros', async () => {
      const inicio = performance.now();

      const res = await buscar({
        q: 'salon',
        departamento: DEPTO_VOLUMEN,
        municipio: 'San Salvador',
        precioMin: 30,
        precioMax: 90,
        tipo: 'PROPIEDAD',
        categoria: 'Salón de eventos',
        capacidadMin: 50,
        ...periodo,
      }).expect(200);

      expect(performance.now() - inicio).toBeLessThan(2000);
      expect(res.body.total).toBeGreaterThan(0);
      expect(res.body.resultados.length).toBeLessThanOrEqual(20);
    });

    it('el total coincide con lo que se cuenta en la base', async () => {
      const res = await buscar({
        departamento: DEPTO_VOLUMEN,
        precioMin: 30,
        precioMax: 90,
        capacidadMin: 50,
        ...periodo,
      }).expect(200);

      const ocupados = { some: {} };
      const esperado = await prisma.bien.count({
        where: {
          departamento: DEPTO_VOLUMEN,
          estado: 'ACTIVA',
          precio: { gte: 30, lte: 90 },
          capacidad: { gte: 50 },
          NOT: [{ reservas: ocupados }, { bloqueos: ocupados }],
        },
      });
      expect(res.body.total).toBe(esperado);
    });
  });
});
