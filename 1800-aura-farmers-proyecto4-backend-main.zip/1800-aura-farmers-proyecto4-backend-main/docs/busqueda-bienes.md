# Búsqueda de bienes

## Decisión

La búsqueda por texto usa la búsqueda nativa de PostgreSQL (`tsvector` e índice GIN), sin un motor externo como Elasticsearch.

- El catálogo es pequeño y PostgreSQL cubre lo que pide H3: ignorar tildes y mayúsculas, y ordenar por relevancia.
- No agrega otro servicio que desplegar ni otra copia de los datos que sincronizar.
- La columna es generada, así que siempre coincide con el título y la descripción.

## Cómo está construida

La migración `busqueda_bienes` agrega:

- La extensión `unaccent` y la función inmutable `f_unaccent(text)`, necesaria porque una columna generada solo admite funciones inmutables.
- La columna `busqueda`, con el título en peso A y la descripción en peso B.
- El índice GIN `idx_bienes_busqueda` y el índice parcial `idx_bienes_ubicacion`, por departamento y municipio de los bienes activos.

## Cómo consultar

La consulta debe aplicar `f_unaccent` al término, igual que se hizo al generar la columna:

```sql
SELECT id, titulo, ts_rank(busqueda, consulta) AS relevancia
FROM "Bienes", plainto_tsquery('spanish', f_unaccent('salon')) AS consulta
WHERE busqueda @@ consulta AND estado = 'ACTIVA'
ORDER BY relevancia DESC, creado_en DESC;
```

Prisma no consulta esta columna: `Unsupported` obliga a usar `$queryRaw`.

`GET /bienes` la usa desde `BienRepository.buscar()`. Convierte el texto con `websearch_to_tsquery('spanish', f_unaccent(q))`, que acepta comillas, `-` y `OR` como texto de búsqueda sin lanzar errores de sintaxis. Ordena primero los bienes cuyo título coincide, después los que coinciden solo en la descripción, y desempata por `creado_en` e `id` descendentes. Para saber si coincide el título usa `ts_filter(busqueda, '{a}') @@ consulta`: la parte de peso A de la columna es el título, así que equivale a `to_tsvector('spanish', f_unaccent(titulo)) @@ consulta` sin volver a analizar el título en cada fila.

El orden por grupo (título, luego descripción) y fecha es el que pide H3; no se usa `ts_rank`. `total` sale de un `COUNT(*)` que corre en paralelo con la página y usa los mismos índices. `pagina` tiene un tope de 10 000 para que el `OFFSET` no desborde. Los valores siempre entran como parámetros de la plantilla de `$queryRaw`.

## Si cambia la expresión

`schema.prisma` declara la expresión de la columna en `dbgenerated(...)`, con el texto exacto que devuelve PostgreSQL. Si una migración cambia la expresión, hay que actualizarla también en el schema. De lo contrario, `prisma migrate dev` generará SQL que falla sobre la columna.
