# Contrato del token de acceso (JWT)

Referencia para los demás módulos. Origen: AF-38 (BE-0.2), historia H0.

## Payload del access token

Firmado con HS256 (`JWT_SECRET`). Vigencia: `JWT_EXPIRES_IN` (15 min). Lo emiten `POST /auth/login` y `POST /auth/refresh`.

| Campo | Tipo | Descripción |
| --- | --- | --- |
| `sub` | `string` (UUID) | Id del usuario. |
| `email` | `string` | Email del usuario, en minúsculas. |
| `rol` | `'ARRENDADOR' \| 'ARRENDATARIO'` | Rol vigente al emitir el token. |
| `iat`, `exp` | `number` | Claims estándar de emisión y expiración. |

El tipo está en `src/auth/types/auth.types.ts` (`AccessTokenPayload`).

## Qué rol usar y dónde

- **El rol del token es informativo.** Lo usa el frontend para decidir qué mostrar. No se usa para autorizar: el token puede llevar un rol viejo hasta que expire.
- **Los permisos se evalúan con el rol leído de la base.** `JwtAuthGuard` relee al usuario en cada request y adjunta ese rol a `request.user`. Un cambio de rol aplica en la siguiente request, sin esperar a que el token expire.
- **En el refresh**, el rol del token nuevo sale del usuario en la base, nunca del token anterior.
- Un token cuyo payload fue modificado a mano (por ejemplo el `rol`) tiene la firma inválida y recibe 401.

## Usuario autenticado: `@CurrentUser()`

En rutas protegidas, `@CurrentUser()` devuelve un `AuthenticatedUser` (`src/auth/types/auth.types.ts`):

```ts
interface AuthenticatedUser {
  id: string;
  email: string;
  nombreUsuario: string;
  rol: Rol; // leído de la base en esta request
}
```

No incluye `passwordHash` ni el resto de la entidad `Usuario`. Si un handler necesita más datos (por ejemplo `isActive` o `createdAt`), debe releer al usuario por `id` con `UsersService.findById`, pero desde un servicio y no desde el controller. `GET /auth/me` lo hace así: el controller llama a `AuthService.getCurrentUser()`, que es quien usa `UsersService.findById()`.

`UsersService.findById()` devuelve la entidad `Usuario` completa (incluido `passwordHash`), por lo que solo debe usarse para obtener datos adicionales del usuario para una regla de negocio. Si el resultado va a salir en una respuesta, hay que pasarlo siempre por un DTO de respuesta (por ejemplo `UserResponseDto.fromEntity`) y nunca devolver la entidad directamente.

Ejemplo:

```ts
@Get('mis-bienes')
listar(@CurrentUser() user: AuthenticatedUser) {
  // user.rol es el rol vigente en la base
}
```

## Sin cambios

- Vigencia del access token (`JWT_EXPIRES_IN`, 15 min).
- Esquema de refresh tokens: opacos, guardados como SHA-256, con rotación y detección de reúso.
