# Despliegue

> **Estado:** la infraestructura está lista (un VPS con Docker Compose detrás de Nginx, en el dominio `arre.live`) y los dos repositorios tienen su workflow de CI/CD en `develop`. El primer despliegue ocurre al fusionar `release/1.0` en `main` en cada repositorio; mientras tanto, `https://arre.live` responde 502 porque Nginx todavía no tiene la aplicación detrás. Lo que aún no se puede confirmar queda marcado como **pendiente**. No se publican IP, puertos de SSH ni credenciales.

## Dónde está desplegado

| Componente | Plataforma | URL | Rama |
|---|---|---|---|
| Frontend | VPS, servicio `web` de Docker Compose detrás de Nginx | [https://arre.live](https://arre.live) | `main` |
| Backend | VPS, servicio `api` de Docker Compose | Interna (`http://api:3000/api/v1`, dentro de la red de Docker). URL pública de Swagger: pendiente de confirmar | `main` |
| Base de datos | VPS, servicio `postgres` de Docker Compose | (privada) | |

Las imágenes se publican en GitHub Container Registry: `ghcr.io/erickgomezuca/aura-farmers-backend` y `ghcr.io/erickgomezuca/aura-farmers-frontend`, cada una con los tags `latest` y el SHA del commit. En el VPS, el `docker-compose.yml` y el `.env` de producción viven en `/opt/arre` y no están en ningún repositorio.

El frontend llama a la API por la red interna de Docker, así que el navegador nunca habla con la API directamente. Cuando se confirme si Swagger queda expuesto en un dominio público, esa URL debe copiarse a [04-api.md](04-api.md), que hoy la marca como pendiente.

## Qué está listo para desplegar

### Backend

- **Imagen de Docker.** El [`Dockerfile`](../Dockerfile) es multi-stage (dependencias, compilación y ejecución) sobre `node:24-alpine`, corre con el usuario `node` sin privilegios, con `NODE_ENV=production`, y expone el puerto 3000.
- **Migraciones al arrancar.** En `docker-compose.yml` el comando de la API es `npx prisma migrate deploy && node dist/main.js`: aplica las migraciones pendientes y levanta el servidor. En una plataforma sin Compose hay que ejecutar `npm run prisma:deploy` (o `npx prisma migrate deploy`) antes de `node dist/main.js`, o usarlo como comando de inicio. Por eso `prisma`, `dotenv` y `tsx` están en `dependencies` y no en `devDependencies`.
- **Datos semilla.** `prisma db seed` (`npm run db:seed`) carga datos de prueba. En un entorno de demostración se corre una vez a mano; no forma parte del arranque.
- **Base de datos.** PostgreSQL 18. La conexión se entrega con `DATABASE_URL`.
- **Fotos de los bienes.** Se guardan en la carpeta `UPLOADS_DIR` (en la imagen, `/app/uploads`). La carpeta debe estar en un **volumen persistente**; si no, las fotos se pierden en cada despliegue. Con varias instancias no se comparten entre ellas.
- **CORS.** Con `NODE_ENV=production`, `CORS_ORIGINS` es obligatoria y debe llevar la URL del frontend desplegado (`https://arre.live`, sin ruta ni barra final). No acepta `*`. Si falta, la API no arranca.
- **Procesos de fondo.** La cola de reservas, la tarea diaria de reservas y depósitos, y la revisión simulada de identidad corren dentro del proceso de la API y se coordinan en PostgreSQL, así que pueden correr en varias instancias a la vez: la cola toma cada solicitud con `FOR UPDATE SKIP LOCKED` y un candado por bien, la revisión toma los documentos con `SKIP LOCKED` y la tarea diaria solo corre en la instancia que obtiene `pg_try_advisory_lock`. Lo que no escala a varias instancias es la carpeta de fotos (ver arriba). En el VPS hay una sola instancia.
- **Comprobar que responde.** La API contesta en `/api/v1` (ruta pública de salud) y publica Swagger en `/api/docs`.

### Frontend

- **Imagen de Docker.** El `Dockerfile` del frontend usa el servidor `standalone` de Next (`output: "standalone"`) sobre `node:24-alpine`. Corre como `node`, escucha en el puerto 3001 y trae un `HEALTHCHECK` que pide `/icon.svg`. En el VPS se publica en `127.0.0.1:3001` y Nginx lo sirve en `https://arre.live`.
- `API_URL` debe apuntar a la API, con el prefijo `/api/v1`. Se fija **al construir** la imagen (el reenvío de `/uploads/**` al origen de la API queda en el build) y se vuelve a leer al arrancar, así que el build arg del workflow y el `environment` del servicio `web` deben coincidir. En el VPS es `http://api:3000/api/v1`.
- La renovación compartida del token funciona dentro de un mismo proceso de Next; con varias instancias haría falta un almacén compartido (se explica en la sección «Sesión y autenticación» del README del frontend).
- En producción, el catálogo del Design System (`/design-system`) responde 404.

## Cómo se publica una nueva versión

El flujo definido por el equipo es Git Flow (ver la plantilla de pull request):

1. Las historias llegan a `develop` con PR desde `feature/*`.
2. Para publicar, se crea la rama `release/<versión>` desde `develop` (por ejemplo, `release/1.0`) y se abre un PR hacia `main`. La plantilla de PR del backend indica que `release/*` va hacia `main`.
3. Al fusionar a `main` se crea la etiqueta `vX.Y.Z` (por ejemplo, `v1.0.0`) sobre ese commit.
4. **El despliegue es automático.** Cada repositorio tiene el workflow `.github/workflows/ci-cd.yml`:
   - En cada PR a `develop` o `main` corre el job `test`: `npm ci`, lint, pruebas y build. En el backend, las pruebas corren contra un PostgreSQL desechable e incluyen las de integración (`RUN_DB_INTEGRATION=1`).
   - En cada push a `main` corren, además, `publish`, que construye la imagen y la sube a GHCR con los tags `latest` y el SHA, y `deploy`. Este último entra por SSH al VPS y ejecuta `docker compose pull` y `docker compose up -d` del servicio correspondiente (`api` o `web`) en `/opt/arre`.
   - Después, `deploy` verifica el resultado: el backend espera hasta 60 s a que `GET /api/v1` responda dentro del contenedor, y el frontend comprueba que `https://arre.live/login` responda.
   - El backend se despliega antes que el frontend, porque en el compose del VPS `web` depende de `api`.
5. **Volver a una versión anterior.** En `/opt/arre` del VPS, el frontend se fija a un SHA con `WEB_TAG=<sha> docker compose up -d web`. El equivalente del backend está pendiente de confirmar.

Los secrets que usa el workflow (`VPS_HOST`, `VPS_PORT`, `VPS_USER`, `VPS_SSH_KEY` y `VPS_KNOWN_HOSTS`) están configurados en cada repositorio de GitHub. La imagen se baja en el VPS con el `GITHUB_TOKEN` del job, que caduca al terminar, así que no se guarda ningún token personal en el servidor.

Estado actual de las ramas: en los dos repositorios existen `develop`, `main` y `release/1.0`. `main` sigue en el commit inicial hasta que se fusione el PR de `release/1.0` hacia `main`, y todavía no hay etiquetas de versión.

## Variables de entorno en producción

Solo los nombres, nunca los valores. Los valores se cargan en `/opt/arre` del VPS (el `.env` y el `docker-compose.yml` de producción), y los secretos no se suben al repositorio.

### Backend

| Variable | Notas |
|---|---|
| `NODE_ENV` | Debe ser `production` |
| `PORT` | Por defecto `3000` |
| `DATABASE_URL` | Cadena de conexión al servicio `postgres` del VPS. Secreto |
| `JWT_SECRET` | Secreto de al menos 32 caracteres, distinto al de desarrollo |
| `JWT_EXPIRES_IN` | Opcional, por defecto `15m` |
| `REFRESH_TOKEN_EXPIRES_IN_DAYS` | Opcional, por defecto `7`; igual al del frontend |
| `BCRYPT_SALT_ROUNDS` | Opcional, por defecto `12` |
| `CORS_ORIGINS` | **Obligatoria**: `https://arre.live` |
| `UPLOADS_DIR` | Ruta del volumen persistente. Por defecto `uploads` |
| `PAGO_SIMULADO_DEMORA_MS` | Opcional |
| `COLA_RESERVAS_ACTIVA` | Opcional, por defecto `true` |
| `COLA_RESERVAS_INTERVALO_MS` | Opcional |
| `PLAZO_DEVOLUCION_DIAS` | Opcional |
| `PLAZO_DEPOSITO_DIAS` | Opcional |
| `TAREA_RESERVAS_ACTIVA` | Opcional, por defecto `true` |
| `REVISION_VERIFICACION_ACTIVA` | Opcional, por defecto `true` |

`POSTGRES_USER`, `POSTGRES_PASSWORD` y `POSTGRES_DB` crean la base del servicio `postgres`, también en el `.env` de `/opt/arre`.

### Frontend

| Variable | Notas |
|---|---|
| `API_URL` | `http://api:3000/api/v1`. Se fija también como build arg en el workflow; los dos valores deben coincidir |
| `REFRESH_TOKEN_EXPIRES_IN_DAYS` | Debe coincidir con la del backend |
| `PORT` | `3001` |

Los significados y valores de desarrollo de todas estas variables están en [05-instalacion-local.md](05-instalacion-local.md).
