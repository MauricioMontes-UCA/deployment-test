# Modelo de datos

La base de datos es PostgreSQL. El esquema se define en [`prisma/schema.prisma`](../prisma/schema.prisma) y se aplica con las migraciones de [`prisma/migrations/`](../prisma/migrations/). Tiene **16 tablas**, una por cada modelo de Prisma.

Esta página resume el modelo: cómo se relacionan las tablas, qué guarda cada una y qué reglas aplica la base. Las notas técnicas completas de cada migración (decisiones de borrado, índices y datos semilla) están en [modelo-er.md](modelo-er.md).

**Convenciones**

- Todas las llaves primarias son `id` de tipo UUID, salvo `PoliticasVerificacionBien`, cuya llave primaria es `bien_id`.
- Los diagramas y las tablas usan los nombres de campo de Prisma (`camelCase`). En la base, las columnas están en `snake_case`: por ejemplo, `nombreUsuario` se guarda como `nombre_usuario`.
- Las fechas con hora se guardan como `timestamptz`. Las fechas de reservas y bloqueos son de tipo `date`.

## Diagrama entidad-relación

### Vista general

Las 16 entidades y sus relaciones, sin atributos. Los diagramas por módulo que siguen muestran los campos importantes.

```mermaid
erDiagram
    Usuario ||--o{ RefreshToken : "inicia sesiones"
    Usuario ||--o{ Notificacion : "recibe"
    Usuario ||--o{ SolicitudVerificacion : "envia"
    SolicitudVerificacion ||--o| DocumentoVerificacion : "adjunta"
    Usuario ||--o{ Bien : "publica"
    Bien ||--o{ FotoBien : "tiene"
    Bien ||--o| PoliticaVerificacionBien : "configura"
    Bien ||--o{ BloqueoFecha : "bloquea"
    Bien ||--o{ Reserva : "se reserva en"
    Usuario ||--o{ Reserva : "solicita"
    Reserva ||--o{ Pago : "se paga con"
    Reserva ||--o| Deposito : "genera"
    Usuario |o--o{ Deposito : "resuelve"
    Reserva ||--o| Devolucion : "se cierra con"
    Usuario ||--o{ Devolucion : "registra"
    Reserva ||--o{ Resena : "recibe"
    Usuario ||--o{ Resena : "escribe"
    Bien ||--o{ Conversacion : "recibe consultas"
    Reserva |o--o| Conversacion : "se coordina en"
    Usuario ||--o{ Conversacion : "participa como arrendador"
    Usuario ||--o{ Conversacion : "participa como arrendatario"
    Conversacion ||--o{ Mensaje : "contiene"
    Usuario ||--o{ Mensaje : "envia"
```

Los diagramas están divididos en cinco módulos:

| Módulo            | Entidades                                                                                   | Se conecta con otros módulos por                                           |
| ----------------- | ------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------- |
| Usuarios y acceso | `Usuario`, `RefreshToken`, `Notificacion`, `SolicitudVerificacion`, `DocumentoVerificacion` | `Usuario`, que participa en todos los demás                                |
| Bienes            | `Bien`, `FotoBien`, `PoliticaVerificacionBien`, `BloqueoFecha`                              | `Bien.arrendadorId` → `Usuario`                                            |
| Reservas y cierre | `Reserva`, `Devolucion`, `Resena`                                                           | `Reserva.bienId` → `Bien` y `Reserva.arrendatarioId` → `Usuario`           |
| Pagos y depósitos | `Pago`, `Deposito`                                                                          | `reservaId` → `Reserva`                                                    |
| Conversaciones    | `Conversacion`, `Mensaje`                                                                   | `bienId` → `Bien`, `reservaId` → `Reserva` y los participantes → `Usuario` |

En cada diagrama por módulo, las entidades de otros módulos aparecen sin atributos, solo para mostrar la relación.

### 1. Usuarios y acceso

```mermaid
erDiagram
    Usuario {
        uuid id PK
        string nombreUsuario UK "3 a 30, minusculas"
        string email UK
        string passwordHash "bcrypt"
        Rol rol "ARRENDADOR o ARRENDATARIO"
        boolean isActive
        datetime creadoEn
        datetime actualizadoEn
    }
    RefreshToken {
        uuid id PK
        string tokenHash UK "SHA-256 del token"
        uuid userId FK
        datetime expiraEn
        datetime revocadoEn "nullable"
        datetime creadoEn
    }
    Notificacion {
        uuid id PK
        uuid destinatarioId FK
        ModuloOrigen moduloOrigen
        string titulo "max 100"
        string mensaje "max 300"
        string tipoReferencia "nullable"
        string referenciaId "nullable"
        EstadoNotificacion estado "NO_LEIDA o LEIDA"
        datetime creadaEn
        datetime leidaEn "nullable"
    }
    SolicitudVerificacion {
        uuid id PK
        uuid usuarioId FK
        EstadoSolicitudVerificacion estado "EN_REVISION, APROBADA, RECHAZADA"
        string motivo "nullable, solo si RECHAZADA"
        datetime revisadoEn "nullable"
        datetime creadaEn
    }
    DocumentoVerificacion {
        uuid id PK
        uuid solicitudId FK,UK
        string nombreArchivo
        bytes contenido
        string mimeType
        int tamanoBytes "max 5 MB"
    }
    Usuario ||--o{ RefreshToken : "inicia sesiones"
    Usuario ||--o{ Notificacion : "recibe"
    Usuario ||--o{ SolicitudVerificacion : "envia"
    SolicitudVerificacion ||--o| DocumentoVerificacion : "adjunta"
```

### 2. Bienes

```mermaid
erDiagram
    Bien {
        uuid id PK
        uuid arrendadorId FK
        TipoBien tipo "PROPIEDAD o EQUIPO"
        string categoria "max 50"
        string titulo "5 a 100"
        string descripcion "max 2000"
        decimal precio "mayor a 0"
        UnidadCobro unidadCobro "HORA, DIA, NOCHE, SEMANA"
        decimal deposito "0 o mas"
        int capacidad "nullable, mayor a 0"
        string departamento
        string municipio
        EstadoBien estado "ACTIVA o INACTIVA"
        tsvector busqueda "columna generada"
        datetime creadoEn
    }
    FotoBien {
        uuid id PK
        uuid bienId FK
        string url
        smallint orden "unico por bien"
        boolean esPrincipal "una por bien"
    }
    PoliticaVerificacionBien {
        uuid bienId PK,FK
        boolean soloVerificados
        datetime actualizadoEn
    }
    BloqueoFecha {
        uuid id PK
        uuid bienId FK
        date fechaInicio
        date fechaFin "mayor o igual a fechaInicio"
    }
    Usuario ||--o{ Bien : "publica"
    Bien ||--o{ FotoBien : "tiene"
    Bien ||--o| PoliticaVerificacionBien : "configura"
    Bien ||--o{ BloqueoFecha : "bloquea"
```

### 3. Reservas y cierre

```mermaid
erDiagram
    Reserva {
        uuid id PK
        uuid bienId FK
        uuid arrendatarioId FK
        date fechaInicio
        date fechaFin "rango inclusivo"
        EstadoReserva estado
        string motivoResolucion "nullable"
        datetime creadaEn
        datetime procesadaEn "nullable"
        datetime finalizadaEn "nullable"
        boolean cierreAutomatico
    }
    Devolucion {
        uuid id PK
        uuid reservaId FK,UK
        uuid registradoPorId FK
        datetime fechaDevolucion
        EstadoFinalBien estadoFinalBien
        string observaciones "nullable"
    }
    Resena {
        uuid id PK
        uuid reservaId FK "UK con tipo"
        uuid autorId FK
        TipoResena tipo "BIEN, ARRENDADOR, ARRENDATARIO"
        int puntuacion "1 a 5"
        string comentario "nullable, max 500"
        datetime creadaEn
    }
    Bien ||--o{ Reserva : "se reserva en"
    Usuario ||--o{ Reserva : "solicita"
    Reserva ||--o| Devolucion : "se cierra con"
    Usuario ||--o{ Devolucion : "registra"
    Reserva ||--o{ Resena : "recibe"
    Usuario ||--o{ Resena : "escribe"
```

### 4. Pagos y depósitos

```mermaid
erDiagram
    Pago {
        uuid id PK
        uuid reservaId FK
        ModalidadPago modalidad "TARJETA o TRANSFERENCIA_BANCARIA"
        decimal importeAlquiler
        decimal importeDeposito
        decimal total
        EstadoPago estado
        datetime fechaHora
        uuid comprobanteId UK "nullable, solo si exitoso"
        string ultimosCuatro "nullable"
        string motivoRechazo "nullable"
    }
    Deposito {
        uuid id PK
        uuid reservaId FK,UK
        uuid resueltoPorId FK "nullable"
        decimal importeOriginal
        decimal importeRetenido
        decimal importeLiberado
        EstadoDeposito estado
        string justificacion "nullable"
        datetime fechaResolucion "nullable"
        boolean resolucionAutomatica
        datetime plazoResolucion "nullable"
    }
    Reserva ||--o{ Pago : "se paga con"
    Reserva ||--o| Deposito : "genera"
    Usuario |o--o{ Deposito : "resuelve"
```

### 5. Conversaciones

```mermaid
erDiagram
    Conversacion {
        uuid id PK
        uuid bienId FK
        uuid reservaId FK,UK "nullable"
        uuid arrendadorId FK
        uuid arrendatarioId FK
        datetime creadaEn
        datetime updatedAt
    }
    Mensaje {
        uuid id PK
        uuid conversacionId FK
        uuid remitenteId FK
        string contenido "1 a 1000, no vacio"
        datetime creadoEn
    }
    Bien ||--o{ Conversacion : "recibe consultas"
    Reserva |o--o| Conversacion : "se coordina en"
    Usuario ||--o{ Conversacion : "participa como arrendador"
    Usuario ||--o{ Conversacion : "participa como arrendatario"
    Conversacion ||--o{ Mensaje : "contiene"
    Usuario ||--o{ Mensaje : "envia"
```

## Tablas

| Tabla                                                           | Descripción                                                                                                                              | Campos importantes                                                                                                                                 |
| --------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------- |
| `Usuarios` (modelo `Usuario`)                                   | Cuenta de un arrendador o un arrendatario.                                                                                               | `email` y `nombreUsuario` (únicos), `passwordHash`, `rol`, `isActive`                                                                              |
| `refresh_tokens` (modelo `RefreshToken`)                        | Sesión renovable. Guarda el hash del token, nunca el token en claro.                                                                     | `tokenHash` (único), `userId`, `expiraEn`, `revocadoEn`                                                                                            |
| `Notificaciones` (modelo `Notificacion`)                        | Aviso interno para un usuario, generado por reservas, pagos, mensajería, reseñas o verificación.                                         | `destinatarioId`, `moduloOrigen`, `titulo`, `mensaje`, `tipoReferencia` y `referenciaId`, `estado`, `leidaEn`                                      |
| `SolicitudesVerificacion` (modelo `SolicitudVerificacion`)      | Cada envío de documento de identidad. El estado de verificación del usuario se deriva de su solicitud más reciente; no se guarda aparte. | `usuarioId`, `estado`, `motivo`, `revisadoEn`, `creadaEn`                                                                                          |
| `DocumentosVerificacion` (modelo `DocumentoVerificacion`)       | Archivo de la solicitud (JPG, PNG o PDF). Va en una tabla aparte para no cargar el binario al listar solicitudes.                        | `solicitudId` (único), `nombreArchivo`, `contenido`, `mimeType`, `tamanoBytes`                                                                     |
| `Bienes` (modelo `Bien`)                                        | Propiedad o equipo que un arrendador publica para alquilar.                                                                              | `arrendadorId`, `tipo`, `categoria`, `titulo`, `precio`, `unidadCobro`, `deposito`, `capacidad`, `departamento`, `municipio`, `estado`, `busqueda` |
| `FotosBien` (modelo `FotoBien`)                                 | Fotos de un bien, en orden, con una principal.                                                                                           | `bienId`, `url`, `orden`, `esPrincipal`                                                                                                            |
| `PoliticasVerificacionBien` (modelo `PoliticaVerificacionBien`) | Indica si un bien acepta solo usuarios verificados. Un bien sin registro se trata como `soloVerificados = false`.                        | `bienId` (llave primaria), `soloVerificados`                                                                                                       |
| `BloqueosFecha` (modelo `BloqueoFecha`)                         | Rango de días que el arrendador marca como no disponibles.                                                                               | `bienId`, `fechaInicio`, `fechaFin`                                                                                                                |
| `Reservas` (modelo `Reserva`)                                   | Solicitud y ciclo de vida de un alquiler. Una solicitud es una reserva en estado `EN_COLA`.                                              | `bienId`, `arrendatarioId`, `fechaInicio`, `fechaFin`, `estado`, `motivoResolucion`, `finalizadaEn`, `cierreAutomatico`                            |
| `Devoluciones` (modelo `Devolucion`)                            | Registro de la devolución del bien que finaliza la reserva. Es de auditoría: no se edita ni se borra.                                    | `reservaId` (único), `registradoPorId`, `fechaDevolucion`, `estadoFinalBien`, `observaciones`                                                      |
| `Resenas` (modelo `Resena`)                                     | Calificación del bien, del arrendador o del arrendatario de una reserva. No se edita ni se borra.                                        | `reservaId`, `autorId`, `tipo`, `puntuacion`, `comentario`                                                                                         |
| `Pagos` (modelo `Pago`)                                         | Intento de pago simulado de una reserva. Un rechazo deja el cobro pendiente y el reintento es un registro nuevo.                         | `reservaId`, `modalidad`, `importeAlquiler`, `importeDeposito`, `total`, `estado`, `comprobanteId`, `ultimosCuatro`                                |
| `Depositos` (modelo `Deposito`)                                 | Depósito de garantía de una reserva y su resolución (liberado o retenido total o parcialmente).                                          | `reservaId` (único), `importeOriginal`, `importeRetenido`, `importeLiberado`, `estado`, `resueltoPorId`, `resolucionAutomatica`, `plazoResolucion` |
| `Conversaciones` (modelo `Conversacion`)                        | Chat entre arrendatario y arrendador sobre un bien (consulta previa) o sobre una reserva (coordinación de la entrega).                   | `bienId`, `reservaId`, `arrendadorId`, `arrendatarioId`                                                                                            |
| `Mensajes` (modelo `Mensaje`)                                   | Mensaje de una conversación.                                                                                                             | `conversacionId`, `remitenteId`, `contenido`, `creadoEn`                                                                                           |

### Relaciones

Las 23 llaves foráneas del esquema, con la cardinalidad y el comportamiento al borrar que define la migración:

| Origen                              | Destino                 | Cardinalidad                                                       | Al borrar el destino |
| ----------------------------------- | ----------------------- | ------------------------------------------------------------------ | -------------------- |
| `RefreshToken.userId`               | `Usuario`               | Un usuario tiene 0 o más refresh tokens                            | `CASCADE`            |
| `Notificacion.destinatarioId`       | `Usuario`               | Un usuario recibe 0 o más notificaciones                           | `RESTRICT`           |
| `SolicitudVerificacion.usuarioId`   | `Usuario`               | Un usuario envía 0 o más solicitudes                               | `RESTRICT`           |
| `DocumentoVerificacion.solicitudId` | `SolicitudVerificacion` | Una solicitud tiene 0 o 1 documento (único)                        | `CASCADE`            |
| `Bien.arrendadorId`                 | `Usuario`               | Un arrendador publica 0 o más bienes                               | `RESTRICT`           |
| `FotoBien.bienId`                   | `Bien`                  | Un bien tiene 0 o más fotos                                        | `CASCADE`            |
| `PoliticaVerificacionBien.bienId`   | `Bien`                  | Un bien tiene 0 o 1 política                                       | `CASCADE`            |
| `BloqueoFecha.bienId`               | `Bien`                  | Un bien tiene 0 o más bloqueos                                     | `CASCADE`            |
| `Reserva.bienId`                    | `Bien`                  | Un bien tiene 0 o más reservas                                     | `RESTRICT`           |
| `Reserva.arrendatarioId`            | `Usuario`               | Un arrendatario solicita 0 o más reservas                          | `RESTRICT`           |
| `Devolucion.reservaId`              | `Reserva`               | Una reserva tiene 0 o 1 devolución (único)                         | `RESTRICT`           |
| `Devolucion.registradoPorId`        | `Usuario`               | Un usuario registra 0 o más devoluciones                           | `RESTRICT`           |
| `Resena.reservaId`                  | `Reserva`               | Una reserva tiene hasta 3 reseñas, una por tipo                    | `RESTRICT`           |
| `Resena.autorId`                    | `Usuario`               | Un usuario escribe 0 o más reseñas                                 | `RESTRICT`           |
| `Pago.reservaId`                    | `Reserva`               | Una reserva tiene 0 o más pagos, con un solo pago exitoso          | `RESTRICT`           |
| `Deposito.reservaId`                | `Reserva`               | Una reserva tiene 0 o 1 depósito (único)                           | `RESTRICT`           |
| `Deposito.resueltoPorId`            | `Usuario`               | Opcional: nulo mientras está pendiente o si lo resuelve el sistema | `RESTRICT`           |
| `Conversacion.bienId`               | `Bien`                  | Un bien tiene 0 o más conversaciones                               | `RESTRICT`           |
| `Conversacion.reservaId`            | `Reserva`               | Opcional; una reserva tiene 0 o 1 conversación (único)             | `RESTRICT`           |
| `Conversacion.arrendadorId`         | `Usuario`               | Un usuario participa en 0 o más conversaciones como arrendador     | `RESTRICT`           |
| `Conversacion.arrendatarioId`       | `Usuario`               | Un usuario participa en 0 o más conversaciones como arrendatario   | `RESTRICT`           |
| `Mensaje.conversacionId`            | `Conversacion`          | Una conversación tiene 0 o más mensajes                            | `RESTRICT`           |
| `Mensaje.remitenteId`               | `Usuario`               | Un usuario envía 0 o más mensajes                                  | `RESTRICT`           |

### Enumeraciones

| Enum                          | Valores                                                                     |
| ----------------------------- | --------------------------------------------------------------------------- |
| `Rol`                         | `ARRENDADOR`, `ARRENDATARIO`                                                |
| `TipoBien`                    | `PROPIEDAD`, `EQUIPO`                                                       |
| `UnidadCobro`                 | `HORA`, `DIA`, `NOCHE`, `SEMANA`                                            |
| `EstadoBien`                  | `ACTIVA`, `INACTIVA`                                                        |
| `EstadoReserva`               | `EN_COLA`, `CONFIRMADA`, `RECHAZADA`, `EN_CURSO`, `FINALIZADA`, `CANCELADA` |
| `ModalidadPago`               | `TARJETA`, `TRANSFERENCIA_BANCARIA`                                         |
| `EstadoPago`                  | `PENDIENTE`, `SIMULADO_EXITOSO`, `SIMULADO_RECHAZADO`                       |
| `TipoResena`                  | `BIEN`, `ARRENDADOR`, `ARRENDATARIO`                                        |
| `EstadoFinalBien`             | `BUEN_ESTADO`, `DANADO`, `INCOMPLETO`                                       |
| `EstadoDeposito`              | `PENDIENTE`, `LIBERADO`, `RETENIDO`, `PARCIALMENTE_RETENIDO`                |
| `ModuloOrigen`                | `RESERVAS`, `PAGOS`, `MENSAJERIA`, `RESENAS`, `VERIFICACION`                |
| `EstadoNotificacion`          | `NO_LEIDA`, `LEIDA`                                                         |
| `EstadoSolicitudVerificacion` | `EN_REVISION`, `APROBADA`, `RECHAZADA`                                      |

### Restricciones que solo existen en SQL

Prisma no puede expresar estas reglas en el schema, así que solo están en las migraciones. La base las aplica aunque el backend falle.

| Tabla                     | Restricción                                                                                                         | Regla                                                                                                                                                       |
| ------------------------- | ------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `Usuarios`                | `Usuarios_nombre_usuario_largo_check` y `Usuarios_nombre_usuario_formato_check`                                     | Entre 3 y 30 caracteres, solo `a-z`, `0-9`, `.`, `_` y `-`                                                                                                  |
| `Bienes`                  | `Bienes_precio_check`, `Bienes_deposito_check`, `Bienes_capacidad_check`, `Bienes_titulo_check`                     | Precio mayor a 0, depósito de 0 o más, capacidad nula o mayor a 0 y título de 5 a 100 caracteres                                                            |
| `Bienes`                  | Columna generada `busqueda`                                                                                         | Índice de texto completo en español sobre título y descripción. Detalle en [busqueda-bienes.md](busqueda-bienes.md)                                         |
| `FotosBien`               | `FotosBien_una_principal_key` (único parcial)                                                                       | Una sola foto principal por bien                                                                                                                            |
| `Reservas`                | `Reservas_fechas_check`                                                                                             | `fecha_fin >= fecha_inicio`                                                                                                                                 |
| `Reservas`                | `reserva_sin_solape` (exclusión GiST)                                                                               | Un bien no puede tener dos reservas `CONFIRMADA`, `EN_CURSO` o `FINALIZADA` con días en común. Las `EN_COLA`, `RECHAZADA` y `CANCELADA` sí pueden solaparse |
| `BloqueosFecha`           | `BloqueosFecha_fechas_check`                                                                                        | `fecha_fin >= fecha_inicio`                                                                                                                                 |
| `Pagos`                   | `Pagos_un_exitoso_por_reserva_key` (único parcial)                                                                  | Un solo pago `SIMULADO_EXITOSO` por reserva                                                                                                                 |
| `Pagos`                   | `Pagos_importes_check`                                                                                              | Importes no negativos                                                                                                                                       |
| `Resenas`                 | `Resenas_puntuacion_check`                                                                                          | Puntuación de 1 a 5                                                                                                                                         |
| `Depositos`               | `Depositos_importes_check` y `Depositos_suma_check`                                                                 | Importes no negativos, y lo retenido más lo liberado no supera el importe original                                                                          |
| `Notificaciones`          | `Notificaciones_referencia_completa_check`                                                                          | `tipo_referencia` y `referencia_id` van juntos o ambos vacíos                                                                                               |
| `Conversaciones`          | `Conversaciones_participantes_distintos_chk`                                                                        | El arrendador y el arrendatario son usuarios distintos                                                                                                      |
| `Conversaciones`          | `Conversaciones_previa_unica_idx` (único parcial)                                                                   | Una sola conversación previa (sin reserva) por bien y arrendatario                                                                                          |
| `Conversaciones`          | Triggers `trg_validar_conversacion_reserva`, `trg_validar_reserva_conversacion` y `trg_validar_bien_conversaciones` | Una conversación de reserva tiene el mismo bien, arrendatario y arrendador que su reserva, también si después cambia la reserva o el dueño del bien         |
| `Mensajes`                | `Mensajes_contenido_valido_chk`                                                                                     | Contenido de 1 a 1000 caracteres sin contar espacios de los extremos                                                                                        |
| `SolicitudesVerificacion` | `solicitud_una_en_revision` (único parcial)                                                                         | Un usuario no puede tener dos solicitudes `EN_REVISION` a la vez                                                                                            |
| `DocumentosVerificacion`  | `DocumentosVerificacion_tamano_check`                                                                               | Archivo de 5 MB como máximo                                                                                                                                 |

Además hay índices parciales de apoyo para búsqueda y reportes (`idx_bienes_ubicacion`, `idx_bienes_filtros`, `idx_bienes_capacidad`, `idx_pago_exitoso_fecha` e `idx_deposito_retenido_fecha`), descritos en [modelo-er.md](modelo-er.md).

### Observaciones del modelo

- **Reglas que aplica el backend, no la base.** El límite de 1 a 10 fotos por bien, el formato del documento de verificación (JPG, PNG o PDF) y que cada solicitud nazca con su documento los valida el backend. Por eso la base admite 0 fotos o una solicitud sin documento, y los diagramas muestran esa cardinalidad real.
- **`Reserva.conversaciones` es una lista en Prisma**, pero el índice único sobre `Conversaciones.reserva_id` limita a una conversación por reserva. En la práctica la relación es de 0 o 1.
- **Nombres mixtos heredados.** La tabla `refresh_tokens` y su columna `user_id` conservan el nombre en inglés del proyecto base. Las tablas `Pagos`, `Devoluciones` y `Depositos` usan `created_at` y `updated_at`, mientras que el resto usa `creado_en` o `creada_en`.
- **`Usuario.rol` tiene `ARRENDATARIO` por defecto** solo para los usuarios que ya existían al agregar la columna. El registro siempre exige el rol de forma explícita.
