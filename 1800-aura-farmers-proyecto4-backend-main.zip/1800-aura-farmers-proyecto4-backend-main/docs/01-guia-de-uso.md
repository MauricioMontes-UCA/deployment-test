# Guía de uso

## Roles

| Rol | Qué puede hacer |
|---|---|
| Visitante (sin sesión) | Ve la portada, busca bienes y abre el detalle de una publicación. Para todo lo demás debe crear una cuenta o iniciar sesión. |
| Arrendatario | Busca bienes, solicita reservas, las paga y ve su comprobante, consulta al arrendador antes de reservar, coordina la entrega, consulta su depósito, califica el bien y al arrendador, recibe notificaciones y verifica su identidad. Su menú: Explorar, Mis reservas y Mensajes. Se elige al registrarse con «Quiero rentar bienes». No puede publicar bienes, ver reservas recibidas ni reportes. |
| Arrendador | Publica bienes, gestiona Mis bienes, bloquea fechas, decide si un bien solo acepta usuarios verificados, atiende las reservas recibidas, responde consultas, coordina la entrega, registra la devolución, resuelve el depósito, califica al arrendatario, consulta reportes, recibe notificaciones y verifica su identidad. Su menú: Mis bienes, Reservas recibidas, Mensajes, Reportes y el botón Publicar un bien. Se elige al registrarse con «Quiero publicar mis bienes». No puede solicitar ni pagar reservas. |

## Flujos principales

### Módulo 1: Registro e inicio de sesión

#### Flujo: crear una cuenta

1. Sin sesión, haz clic en **Crear cuenta** en la barra superior (`/registro`).
2. Escribe un **Nombre de usuario** de 3 a 30 caracteres (letras, números, punto, guion y guion bajo) y tu **Correo electrónico**.
3. Escribe una **Contraseña** de al menos 8 caracteres, con una minúscula, una mayúscula y un número.
4. En **¿Cómo vas a usar la plataforma?** elige el rol: **Quiero rentar bienes** crea una cuenta de arrendatario y **Quiero publicar mis bienes**, una de arrendador. Ninguna opción viene marcada y el rol no se puede cambiar después.
5. Haz clic en **Crear cuenta**. El botón se habilita cuando todos los campos son válidos.
6. El sistema te lleva al inicio de sesión con el aviso «Cuenta creada». Si el correo o el nombre de usuario ya existen, aparece «Ese correo o nombre de usuario ya está registrado.».

![Formulario de registro con el rol de arrendatario elegido](img/visitante-registro.png)

#### Flujo: iniciar sesión

1. Haz clic en **Iniciar sesión** en la barra superior (`/login`).
2. Escribe tu **Correo electrónico** y tu **Contraseña**.
3. Haz clic en **Iniciar sesión**. Si los datos no coinciden, aparece «No pudimos iniciar sesión».
4. Al entrar, la portada muestra el menú de tu rol.

![Inicio de sesión después de crear la cuenta](img/visitante-inicio-de-sesion.png)

![Portada con el menú del arrendatario](img/arrendatario-inicio.png)

#### Flujo: cerrar sesión

1. Abre el menú con tu nombre, arriba a la derecha.
2. Elige **Cerrar sesión**. También está en la pantalla de perfil (`/perfil`).

#### Flujo: verificar la identidad de la cuenta

1. Como arrendatario o arrendador, entra a tu perfil (`/perfil`) con **Verificar mi cuenta** (cuando un bien exige usuarios verificados), con **Ir a verificación** en Mis bienes o escribiendo la ruta.
2. En **Verificación de identidad**, arrastra tu DUI o pasaporte o haz clic para elegirlo (JPG, PNG o PDF, máximo 5 MB).
3. Haz clic en **Enviar documento**. El estado pasa a **En revisión**.
4. La revisión es automática, tarda como máximo 30 segundos y la pantalla se actualiza sola.
5. Si se aprueba, aparece «Cuenta verificada»: el arrendatario puede solicitar bienes que exigen verificación y el arrendador puede activar «Solo usuarios verificados». Si se rechaza, se muestra el motivo y puedes subir otro con **Enviar documento nuevo**.

![Perfil sin verificar](img/arrendatario-perfil.png)

![Documento en revisión](img/arrendatario-verificacion-en-revision.png)

![Cuenta verificada](img/arrendatario-verificacion-aprobada.png)

### Módulo 2: Publicaciones

#### Flujo: publicar un bien

1. Como arrendador, haz clic en **Publicar un bien** en la barra superior (`/publicar`).
2. En **Datos del bien**, elige el **Tipo de bien** y la **Categoría**, y completa **Título**, **Descripción**, **Precio**, **Unidad de cobro** y **Depósito de garantía** (0 si no pides depósito). Para propiedades se pide la **Capacidad (personas)**; las **Condiciones de uso** son opcionales.
3. En **Ubicación**, elige **Departamento** y **Municipio**. La **Dirección de referencia** es opcional.
4. En **Fotos**, sube de 1 a 10 imágenes JPG o PNG de hasta 5 MB y ordénalas con las flechas; la primera es la portada.
5. Haz clic en **Publicar**. Se habilita con los campos obligatorios y al menos una foto.
6. El sistema abre el detalle del bien con el aviso «Tu publicación ya está visible».

![Portada con el menú del arrendador](img/arrendador-inicio.png)

![Formulario de publicación completo](img/arrendador-publicar-bien.png)

![Publicación recién creada](img/arrendador-publicacion-visible.png)

#### Flujo: gestionar mis bienes

1. Como arrendador, entra a **Mis bienes** (`/mis-bienes`).
2. Revisa el estado, el precio y la ubicación de cada bien.
3. Activa **Solo usuarios verificados** para que solo te soliciten arrendatarios verificados. Si tu cuenta no está verificada, el interruptor aparece deshabilitado con el enlace **Ir a verificación**.
4. Usa **Bloquear fechas** o **Ver publicación** según lo que necesites.

![Mis bienes](img/arrendador-mis-bienes.png)

#### Flujo: bloquear fechas

1. En Mis bienes, haz clic en **Bloquear fechas** del bien (`/mis-bienes/{id}/bloqueos`).
2. En el calendario, elige el primer y el último día del bloqueo. Los días pasados, reservados o ya bloqueados no se pueden elegir.
3. Revisa **Desde** y **Hasta** y haz clic en **Bloquear fechas**.
4. El bloqueo aparece en **Bloqueos activos**; para quitarlo, haz clic en **Eliminar** y confirma. Las reservas confirmadas se muestran solo como lectura.

![Rango elegido para bloquear](img/arrendador-bloquear-fechas.png)

![Bloqueo creado](img/arrendador-bloqueo-creado.png)

#### Flujo: consultar los reportes de tus bienes

1. Como arrendador, entra a **Reportes** (`/reportes`).
2. Elige el **Periodo**: último mes, últimos 3 meses, último año o un rango de fechas. Se mantiene al cambiar de pestaña.
3. En **Ingresos**, revisa el ingreso por alquiler de cada bien y, aparte, el depósito retenido.
4. En **Ocupación**, revisa los días disponibles, los ocupados y la tasa de cada bien; puedes ordenar por la tasa.
5. En **Calificaciones**, revisa el promedio de las reseñas de cada bien en el periodo.
6. En **Resumen**, compara los ingresos, la tasa de ocupación y la calificación promedio de cada bien. **Exportar CSV** descarga ese resumen.

![Reporte de ingresos](img/arrendador-reporte-ingresos.png)

![Reporte de ocupación](img/arrendador-reporte-ocupacion.png)

![Reporte de calificaciones](img/arrendador-reporte-calificaciones.png)

![Resumen comparativo](img/arrendador-reporte-resumen.png)

### Módulo 3: Búsquedas

#### Flujo: buscar y filtrar bienes

1. Con o sin sesión, escribe qué buscas en la barra de la portada (`/`) y, si quieres, elige **Departamento** y **Municipio**. Haz clic en **Buscar**. También puedes entrar por **Explora por categoría** o con **Ver todo**.
2. En `/buscar` aparecen los resultados; al bajar se cargan más, de 20 en 20.
3. En el panel **Filtros**, ajusta precio mínimo y máximo, tipo de bien, categoría, capacidad mínima y fechas disponibles. Haz clic en **Aplicar**.
4. Quita un filtro con la **×** de su etiqueta o todos con **Limpiar filtros**.
5. Haz clic en una tarjeta para abrir el detalle del bien.

![Portada para un visitante, con la barra de búsqueda](img/visitante-inicio.png)

![Resultados de buscar «taladro»](img/arrendatario-busqueda.png)

![Resultados filtrados por tipo Equipo](img/arrendatario-busqueda-filtros.png)

#### Flujo: ver el detalle de un bien

1. Abre un bien desde los resultados (`/bienes/{id}`).
2. Revisa las fotos, el precio por unidad, el depósito de garantía, la ubicación, el arrendador, la calificación, la descripción y las condiciones de uso.
3. Usa **Ver disponibilidad y reservar** para bajar al calendario o **Consultar al arrendador** para escribirle.
4. Sin sesión, en lugar del calendario aparece una invitación a iniciar sesión.

![Detalle de un bien con sesión de arrendatario](img/arrendatario-detalle-bien.png)

![Disponibilidad sin sesión](img/visitante-detalle-bien-sin-sesion.png)

### Módulo 4: Reservas

#### Flujo: solicitar una reserva

1. Como arrendatario, en el detalle del bien haz clic en **Ver disponibilidad y reservar**.
2. En el calendario, haz clic en la fecha de inicio y en la de fin (máximo 30 días, sin fechas pasadas).
3. Revisa **Tu selección**: fechas, duración, alquiler estimado y depósito.
4. Haz clic en **Solicitar reserva**. La solicitud queda en cola y la respuesta llega sola en unos segundos.
5. Si se confirma, aparece «¡Reserva confirmada!» con **Ir a pagar** y **Ver mis reservas**. Si se rechaza, se muestra el motivo y **Elegir otras fechas**. Si el bien exige usuarios verificados y tu cuenta no lo está, aparece **Verificar mi cuenta**.

![Rango elegido en el calendario](img/arrendatario-solicitar-reserva.png)

![Reserva confirmada](img/arrendatario-reserva-confirmada.png)

#### Flujo: consultar mis reservas

1. Como arrendatario, entra a **Mis reservas** (`/reservas`).
2. Filtra con las pestañas: Todas, En cola, Confirmadas, En curso, Finalizadas, Rechazadas y Canceladas.
3. Usa la acción de cada reserva: **Pagar ahora** (confirmada), **Calificar** y **Ver depósito** (finalizada) o **Ver detalle**.
4. En el detalle (`/reservas/{id}`) se ven las fechas, los participantes, el pago, el depósito, **Ver comprobante** y **Abrir conversación** para coordinar la entrega.

![Mis reservas](img/arrendatario-mis-reservas.png)

![Detalle de la reserva para el arrendatario, ya pagada](img/arrendatario-detalle-reserva.png)

#### Flujo: atender reservas recibidas

1. Como arrendador, entra a **Reservas recibidas** (`/reservas-recibidas`).
2. Filtra con las pestañas: Todas, En cola, Confirmadas, En curso, Finalizadas y Rechazadas.
3. Haz clic en **Gestionar** para abrir el detalle (`/reservas/{id}`).
4. En **Acciones del arrendador** aparecen **Registrar devolución** (en curso), **Resolver depósito** y **Calificar arrendatario** (finalizada). Las que todavía no aplican aparecen deshabilitadas.

![Reservas recibidas](img/arrendador-reservas-recibidas.png)

![Detalle de una reserva en curso para el arrendador](img/arrendador-detalle-reserva-en-curso.png)

#### Flujo: registrar la devolución

1. Como arrendador, con la reserva en curso, haz clic en **Registrar devolución** en su detalle (`/reservas/{id}/devolucion`).
2. Indica la **Fecha de devolución** (no puede ser futura) y el **Estado final del bien**: Buen estado, Dañado o Incompleto.
3. Si quieres, escribe **Observaciones** (hasta 500 caracteres).
4. Haz clic en **Registrar devolución** y confirma. La reserva queda Finalizada.

![Formulario de devolución](img/arrendador-registrar-devolucion.png)

![Devolución registrada](img/arrendador-devolucion-registrada.png)

#### Flujo: resolver el depósito

1. Como arrendador, con la reserva finalizada y el depósito pendiente, haz clic en **Resolver depósito** en su detalle (`/reservas/{id}/deposito/resolver`).
2. Elige **Liberar el depósito completo** o **Retener una parte o el total**; para retener, escribe el **Importe a retener (USD)** y la **Justificación**.
3. Haz clic en **Confirmar resolución** y confirma.
4. Aparece «Depósito resuelto» y el arrendatario recibe una notificación. Si el plazo vence sin resolverlo, el sistema libera el depósito automáticamente.

![Retención parcial del depósito](img/arrendador-resolver-deposito.png)

![Depósito resuelto](img/arrendador-deposito-resuelto.png)

![Detalle de la reserva finalizada para el arrendador](img/arrendador-detalle-reserva.png)

#### Flujo: consultar el depósito

1. Como arrendatario, haz clic en **Ver depósito** en una reserva en curso o finalizada de Mis reservas (`/reservas/{id}/deposito`).
2. Revisa el estado (Pendiente, Liberado, Retenido o Parcialmente retenido), los importes original, retenido y liberado, la fecha de resolución y la justificación.

![Depósito parcialmente retenido](img/arrendatario-consulta-deposito.png)

### Módulo 5: Pagos

#### Flujo: pagar una reserva

1. Como arrendatario, haz clic en **Ir a pagar** o **Pagar ahora** en una reserva confirmada (`/reservas/{id}/pago`).
2. Revisa el resumen: alquiler, depósito de garantía y total.
3. Elige **Tarjeta de prueba** (una tarjeta que termina en `4242` aprueba y una que termina en `0002` rechaza) o **Transferencia bancaria** (la referencia `SIM-APRUEBA` aprueba). Los pagos son simulados.
4. Haz clic en **Pagar $…**.
5. Si se aprueba, aparece «Pago aprobado» con el número de comprobante. Si se rechaza, aparece «Pago rechazado» con el motivo; revisa los datos e inténtalo de nuevo.

![Pago con tarjeta de prueba](img/arrendatario-pagar-reserva.png)

![Pago aprobado](img/arrendatario-pago-aprobado.png)

#### Flujo: ver el comprobante

1. Haz clic en **Ver comprobante**, desde el pago aprobado o desde el detalle de la reserva (`/pagos/{id}/comprobante`).
2. Revisa los identificadores del pago y del comprobante, la fecha, la modalidad y los importes.
3. Usa **Descargar o imprimir** para guardarlo.

![Comprobante de pago](img/arrendatario-comprobante.png)

### Módulo 6: Mensajería

#### Flujo: consultar al arrendador

1. Como arrendatario, en el detalle del bien haz clic en **Consultar al arrendador** (`/publicaciones/{id}/conversacion`).
2. Escribe tu pregunta (hasta 1000 caracteres) y haz clic en **Enviar mensaje**.
3. El arrendador recibe una notificación y responde desde **Mensajes**.

![Consulta del arrendatario](img/arrendatario-consulta-arrendador.png)

#### Flujo: responder desde la bandeja

1. Como arrendador o arrendatario, entra a **Mensajes** (`/mensajes`).
2. Filtra con **Todas**, **Consultas** o **Coordinación** y haz clic en una conversación.
3. Escribe en **Mensaje** y haz clic en **Enviar mensaje**.

![Bandeja del arrendador](img/arrendador-mensajes.png)

![El arrendador responde una consulta](img/arrendador-responder-consulta.png)

![Bandeja del arrendatario](img/arrendatario-mensajes.png)

#### Flujo: coordinar la entrega

1. Con la reserva confirmada o en curso, haz clic en **Abrir conversación** en su detalle (`/reservas/{id}/conversacion`). La usan el arrendatario y el arrendador de la reserva.
2. Acuerden la fecha y hora, el lugar y las condiciones de la entrega.

![Conversación de coordinación de entrega](img/arrendatario-coordinacion-entrega.png)

### Módulo 7: Reseñas

#### Flujo: calificar el bien y al arrendador

1. Como arrendatario, haz clic en **Calificar** en una reserva finalizada (`/reservas/{id}/calificar`). Se puede calificar dentro de los 14 días posteriores a la devolución.
2. En **El bien** y en **El arrendador**, elige de 1 a 5 estrellas y, si quieres, escribe un comentario.
3. Haz clic en **Enviar reseña** y confirma. La reseña no se puede editar.
4. Las reseñas del bien se ven al final de su detalle, con el promedio y la cantidad.

![Reseña del bien y del arrendador](img/arrendatario-calificar.png)

![Reseñas en el detalle del bien](img/arrendatario-resenas-bien.png)

#### Flujo: calificar al arrendatario

1. Como arrendador, haz clic en **Calificar arrendatario** en el detalle de una reserva finalizada (`/reservas/{id}/calificar-arrendatario`).
2. Elige de 1 a 5 estrellas y, si quieres, escribe un **Comentario**.
3. Haz clic en **Enviar calificación** y confirma con **Enviar**.
4. Aparece «Calificación enviada.» con el promedio actual del arrendatario. La calificación no se puede editar.

![Calificación del arrendatario](img/arrendador-calificar-arrendatario.png)

![Calificación enviada y promedio del arrendatario](img/arrendador-calificacion-enviada.png)

### Módulo 8: Notificaciones

#### Flujo: revisar las notificaciones

1. Como arrendatario o arrendador, haz clic en la campana de la barra superior (`/notificaciones`). El número rojo indica los avisos no leídos y se actualiza cada 30 segundos.
2. Revisa los avisos de reservas, pagos, depósitos, mensajes, reseñas y verificación.
3. Haz clic en un aviso «No leída» para marcarlo como leído.
4. Usa **Actualizar** para traer avisos nuevos sin recargar.

![Notificaciones del arrendatario](img/arrendatario-notificaciones.png)

![Notificaciones del arrendador](img/arrendador-notificaciones.png)
