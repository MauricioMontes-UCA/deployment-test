# API

API REST construida con NestJS. Todas las rutas llevan el prefijo **`/api/v1`**, que se configura en [`src/app.setup.ts`](../src/app.setup.ts).

**Documentación interactiva (Swagger):** URL pública de Swagger: pendiente de confirmar tras el despliegue. Ruta de documentación: `/api/docs`.

- **Local:** `http://localhost:3000/api/docs`. Se configura en [`src/main.ts`](../src/main.ts); el puerto por defecto es el `PORT=3000` de `.env.example`.

Swagger muestra cada endpoint con sus parámetros, cuerpos, respuestas y códigos de error. Para probar las rutas protegidas, inicien sesión con `POST /api/v1/auth/login`, copien el `accessToken` y péguenlo en el botón **Authorize**. Las rutas públicas aparecen sin candado.

## Autenticación

La API usa un **access token** (JWT) y un **refresh token**.

|                      | Access token                     | Refresh token                               |
| -------------------- | -------------------------------- | ------------------------------------------- |
| Formato              | JWT firmado con HS256            | Cadena opaca aleatoria de 32 bytes          |
| Vigencia             | 15 minutos (`JWT_EXPIRES_IN`)    | 7 días (`REFRESH_TOKEN_EXPIRES_IN_DAYS`)    |
| Uso                  | Acompaña cada petición protegida | Solo sirve para pedir un access token nuevo |
| Se guarda en la base | No                               | Sí, solo su hash SHA-256                    |

**Flujo**

1. **Iniciar sesión:** `POST /api/v1/auth/login` con `email` y `password`. Responde `accessToken`, `refreshToken`, `expiresIn` (en segundos) y los datos del usuario.
2. **Llamar a una ruta protegida:** enviar el encabezado `Authorization: Bearer <accessToken>`.
3. **Renovar:** cuando el access token expira, `POST /api/v1/auth/refresh` con el `refreshToken`. Cada renovación revoca el refresh token usado y entrega uno nuevo. Si se presenta un refresh token que ya se usó, se asume robo y se revocan todas las sesiones del usuario.
4. **Cerrar sesión:** `POST /api/v1/auth/logout` con el `refreshToken`. Responde `204`.

**Autorización**

- **Todo está protegido por defecto.** `JwtAuthGuard` y `RolesGuard` son guards globales. Una ruta solo es pública si lleva `@Public()`.
- **Los roles son `ARRENDADOR` y `ARRENDATARIO`.** Una ruta con `@Roles(...)` solo admite esos roles. Una ruta protegida sin `@Roles` admite a cualquier usuario autenticado. Como todo usuario tiene siempre uno de los dos roles, en las tablas esas rutas aparecen con `ARRENDADOR`, `ARRENDATARIO`. Si una ruta declara roles propios, reemplazan a los del controlador.
- **El rol se lee de la base en cada petición, no del token.** Un usuario desactivado deja de tener acceso de inmediato. El payload del token se describe en [contrato-token-jwt.md](contrato-token-jwt.md).
- **Errores comunes:** `401` sin token o con un token inválido o expirado; `403` con un rol no permitido. Muchas rutas sobre recursos de otro usuario responden `404`, igual que si no existieran, para no revelar que existen.

Las fotos de los bienes se sirven como archivos estáticos públicos en `/uploads/...`, fuera del prefijo `/api/v1` y sin autenticación.

## Endpoints por módulo

**Roles:** **Público** no requiere token. Las demás rutas requieren token y solo las pueden usar los roles indicados.

Hay 47 endpoints: 8 públicos, 15 para los dos roles, 17 solo para `ARRENDADOR` y 7 solo para `ARRENDATARIO`.

### Sistema

| Método | Ruta      | Descripción  | Roles   |
| ------ | --------- | ------------ | ------- |
| GET    | `/api/v1` | Health check | Público |

### Autenticación y usuarios

| Método | Ruta                   | Descripción                                      | Roles                        |
| ------ | ---------------------- | ------------------------------------------------ | ---------------------------- |
| POST   | `/api/v1/users`        | Registra un usuario nuevo con su rol             | Público                      |
| POST   | `/api/v1/auth/login`   | Inicia sesión con email y contraseña             | Público                      |
| POST   | `/api/v1/auth/refresh` | Renueva el access token rotando el refresh token | Público                      |
| POST   | `/api/v1/auth/logout`  | Cierra la sesión revocando el refresh token      | Público                      |
| GET    | `/api/v1/auth/me`      | Devuelve el usuario autenticado                  | `ARRENDADOR`, `ARRENDATARIO` |

### Bienes

| Método | Ruta                                     | Descripción                                                                                            | Roles                        |
| ------ | ---------------------------------------- | ------------------------------------------------------------------------------------------------------ | ---------------------------- |
| GET    | `/api/v1/bienes`                         | Busca bienes por texto, ubicación, precio, tipo, categoría, capacidad y disponibilidad, con paginación | Público                      |
| GET    | `/api/v1/bienes/{bienId}`                | Detalle público de un bien activo                                                                      | Público                      |
| GET    | `/api/v1/bienes/{bienId}/resenas`        | Reseñas de tipo `BIEN` de un bien, 10 por página                                                       | Público                      |
| GET    | `/api/v1/bienes/{bienId}/disponibilidad` | Rangos reservados y bloqueados de un bien                                                              | `ARRENDADOR`, `ARRENDATARIO` |
| GET    | `/api/v1/bienes/mios`                    | Bienes publicados por el arrendador, incluidos los inactivos                                           | `ARRENDADOR`                 |
| POST   | `/api/v1/bienes`                         | Publica un bien con sus fotos (`multipart/form-data`)                                                  | `ARRENDADOR`                 |

### Bloqueos de fechas

| Método | Ruta                                    | Descripción                                   | Roles        |
| ------ | --------------------------------------- | --------------------------------------------- | ------------ |
| GET    | `/api/v1/bienes/{bienId}/bloqueos`      | Bloqueos vigentes o futuros de un bien propio | `ARRENDADOR` |
| POST   | `/api/v1/bienes/{bienId}/bloqueos`      | Bloquea un rango de fechas de un bien propio  | `ARRENDADOR` |
| DELETE | `/api/v1/bienes/{bienId}/bloqueos/{id}` | Elimina un bloqueo de un bien propio          | `ARRENDADOR` |

### Verificación de identidad

| Método | Ruta                                            | Descripción                                                      | Roles                        |
| ------ | ----------------------------------------------- | ---------------------------------------------------------------- | ---------------------------- |
| GET    | `/api/v1/verificaciones/mi-estado`              | Estado de verificación del usuario                               | `ARRENDADOR`, `ARRENDATARIO` |
| POST   | `/api/v1/verificaciones`                        | Envía el documento de identidad (`multipart/form-data`)          | `ARRENDADOR`, `ARRENDATARIO` |
| GET    | `/api/v1/bienes/{bienId}/politica-verificacion` | Indica si un bien solo acepta usuarios verificados               | `ARRENDADOR`, `ARRENDATARIO` |
| PUT    | `/api/v1/bienes/{bienId}/politica-verificacion` | Activa o desactiva «Solo usuarios verificados» en un bien propio | `ARRENDADOR`                 |

### Reservas

| Método | Ruta                                      | Descripción                                                                              | Roles                        |
| ------ | ----------------------------------------- | ---------------------------------------------------------------------------------------- | ---------------------------- |
| POST   | `/api/v1/reservas`                        | Solicita una reserva. Responde `202` y la reserva queda `EN_COLA`                        | `ARRENDATARIO`               |
| GET    | `/api/v1/reservas/mias`                   | Reservas del arrendatario                                                                | `ARRENDATARIO`               |
| GET    | `/api/v1/reservas/recibidas`              | Reservas recibidas en los bienes del arrendador                                          | `ARRENDADOR`                 |
| GET    | `/api/v1/reservas/{id}`                   | Consulta una reserva propia: la del arrendatario que la solicitó o la del dueño del bien | `ARRENDADOR`, `ARRENDATARIO` |
| POST   | `/api/v1/reservas/{reservaId}/devolucion` | Registra la devolución del bien y finaliza la reserva                                    | `ARRENDADOR`                 |

### Pagos

| Método | Ruta                                        | Descripción                                                                          | Roles          |
| ------ | ------------------------------------------- | ------------------------------------------------------------------------------------ | -------------- |
| GET    | `/api/v1/reservas/{reservaId}/resumen-pago` | Alquiler, depósito y total de una reserva                                            | `ARRENDATARIO` |
| POST   | `/api/v1/reservas/{reservaId}/pagos`        | Simula el pago de una reserva. Responde `201` tanto si se aprueba como si se rechaza | `ARRENDATARIO` |
| GET    | `/api/v1/pagos/{pagoId}/comprobante`        | Comprobante de un pago exitoso                                                       | `ARRENDATARIO` |

### Depósitos

| Método | Ruta                                               | Descripción                                           | Roles                        |
| ------ | -------------------------------------------------- | ----------------------------------------------------- | ---------------------------- |
| GET    | `/api/v1/reservas/{reservaId}/deposito`            | Estado y detalle del depósito de una reserva          | `ARRENDADOR`, `ARRENDATARIO` |
| POST   | `/api/v1/reservas/{reservaId}/deposito/resolucion` | Libera el depósito o retiene una parte o su totalidad | `ARRENDADOR`                 |

### Reseñas

| Método | Ruta                                                | Descripción                                                               | Roles          |
| ------ | --------------------------------------------------- | ------------------------------------------------------------------------- | -------------- |
| POST   | `/api/v1/reservas/{reservaId}/resenas`              | Califica el bien y al arrendador de una reserva finalizada                | `ARRENDATARIO` |
| POST   | `/api/v1/reservas/{reservaId}/resenas/arrendatario` | Califica al arrendatario de una reserva finalizada y devuelve su promedio | `ARRENDADOR`   |
| GET    | `/api/v1/reservas/{reservaId}/resenas/arrendatario` | Consulta la calificación del arrendatario de una reserva y su promedio    | `ARRENDADOR`   |

Las reseñas públicas de un bien se consultan con `GET /api/v1/bienes/{bienId}/resenas`, en el módulo de bienes.

**Métodos no permitidos.** Una reseña no se edita ni se borra. `PUT` y `DELETE` sobre `/api/v1/reservas/{reservaId}/resenas` y `/api/v1/reservas/{reservaId}/resenas/arrendatario` responden `405 Method Not Allowed`, también sin token. La respuesta incluye el encabezado `Allow` con los métodos válidos: `POST` en la primera ruta y `GET, POST` en la segunda. No se cuentan entre los 47 endpoints.

### Conversaciones

| Método | Ruta                                                 | Descripción                                                                 | Roles                        |
| ------ | ---------------------------------------------------- | --------------------------------------------------------------------------- | ---------------------------- |
| GET    | `/api/v1/conversaciones`                             | Bandeja con las conversaciones del usuario                                  | `ARRENDADOR`, `ARRENDATARIO` |
| POST   | `/api/v1/bienes/{bienId}/conversacion`               | Abre o recupera la conversación previa con el arrendador de un bien         | `ARRENDATARIO`               |
| GET    | `/api/v1/conversaciones/{id}/mensajes`               | Historial de una conversación, solo para sus participantes                  | `ARRENDADOR`, `ARRENDATARIO` |
| POST   | `/api/v1/conversaciones/{id}/mensajes`               | Envía un mensaje en una conversación, solo para sus participantes           | `ARRENDADOR`, `ARRENDATARIO` |
| GET    | `/api/v1/reservas/{reservaId}/conversacion`          | Recupera o crea la conversación de coordinación de una reserva              | `ARRENDADOR`, `ARRENDATARIO` |
| GET    | `/api/v1/reservas/{reservaId}/conversacion/mensajes` | Historial de la coordinación de una reserva                                 | `ARRENDADOR`, `ARRENDATARIO` |
| POST   | `/api/v1/reservas/{reservaId}/conversacion/mensajes` | Envía un mensaje sobre la entrega, con la reserva `CONFIRMADA` o `EN_CURSO` | `ARRENDADOR`, `ARRENDATARIO` |

Las rutas de coordinación no declaran rol, pero el servicio solo admite al arrendatario de la reserva y al dueño del bien.

### Notificaciones

| Método | Ruta                                | Descripción                                                             | Roles                        |
| ------ | ----------------------------------- | ----------------------------------------------------------------------- | ---------------------------- |
| GET    | `/api/v1/notificaciones`            | Notificaciones del usuario, 20 por página, con el contador de no leídas | `ARRENDADOR`, `ARRENDATARIO` |
| PATCH  | `/api/v1/notificaciones/{id}/leida` | Marca una notificación propia como leída                                | `ARRENDADOR`, `ARRENDATARIO` |

### Reportes del arrendador

Todas las rutas aceptan el periodo como parámetro de consulta. Los reportes por bien solo incluyen los bienes activos del arrendador de la sesión.

| Método | Ruta                                | Descripción                                               | Roles        |
| ------ | ----------------------------------- | --------------------------------------------------------- | ------------ |
| GET    | `/api/v1/reportes/periodo`          | Convierte el periodo elegido en un rango de fechas        | `ARRENDADOR` |
| GET    | `/api/v1/reportes/ocupacion`        | Tasa de ocupación de cada bien                            | `ARRENDADOR` |
| GET    | `/api/v1/reportes/ingresos`         | Ingresos y depósito retenido de cada bien                 | `ARRENDADOR` |
| GET    | `/api/v1/reportes/calificaciones`   | Calificación promedio y número de reseñas de cada bien    | `ARRENDADOR` |
| GET    | `/api/v1/reportes/resumen`          | Resumen comparativo de ingresos, ocupación y calificación | `ARRENDADOR` |
| GET    | `/api/v1/reportes/resumen/exportar` | Exporta el resumen comparativo a CSV                      | `ARRENDADOR` |
