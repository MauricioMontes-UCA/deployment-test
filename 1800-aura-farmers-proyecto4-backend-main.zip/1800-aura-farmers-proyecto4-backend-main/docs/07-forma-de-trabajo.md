# Forma de trabajo

**Tablero de Jira:** [1800 Aura Farmers](https://1800-aura-farmers.atlassian.net/jira/software/projects/AF/boards/1?filter=&groupBy=none)

Como equipo, se decidió organizar el desarrollo en historias de usuario y **tasks** asignadas a integrantes. Cada tarea tenía su identificador funcional (por ejemplo, `FE-12.1`, `BE-11.1` o `DB-13.1`) y su clave de Jira (`AF-...`), con descripción, alcance, dependencias y criterios de aceptación. Jira fue el punto de seguimiento y GitHub el registro de cambios y revisiones. Los repositorios de frontend y backend trabajaron con el mismo flujo.

## Ramas (Git Flow)

| Rama | Uso |
|---|---|
| `main` | Código de la versión publicada; no se desarrolla directamente sobre ella. |
| `develop` | Integración de tareas aprobadas; base del desarrollo cotidiano. |
| `feature/<historia>/<descripcion>` | Implementación de una task o parte funcional de una historia, por ejemplo `feature/h12/consulta-deposito`. |
| `bugfix/<id>-<descripcion>` | Corrección de un defecto detectado antes de la publicación. |
| `release/1.0` | Preparación de la primera versión desde `develop`, limitada a ajustes de salida. |
| `hotfix/<descripcion>` | Corrección urgente desde `main` cuando ya hay una versión publicada. |

La nomenclatura usada en la práctica admite variantes según la tarea (`feature/h13/conversaciones-mensajes`, `feature/BE-03-roles-guard-global`), pero mantiene la intención: **una rama aislada y rastreable por trabajo**.

## Commits

Se siguió la convención `<tipo>(<historia>): <descripción breve>`, en español y describiendo el cambio realizado. Los tipos principales son `feat`, `fix`, `test`, `docs`, `refactor` y `chore`.

```text
feat(H12): implementa consulta de estado y detalle del depósito
fix(H12): corrige deteccion de liberacion automatica segun contrato backend
test(H13): agrega e2e y corrige observaciones
docs(H1): documenta el listado de mis bienes
```

La **historia** aparece en el ámbito del commit; la **task de Jira** puede añadirse en el mensaje o el PR para reforzar la trazabilidad. No se incluyen credenciales ni secretos en los commits.

## Pull requests y revisión

1. El responsable toma una task de Jira, revisa sus dependencias y crea una rama desde `develop`.
2. Implementa el código, añade o actualiza pruebas y ejecuta los chequeos correspondientes (`npm test`, `npm run lint`, compilación; en frontend también `npx tsc --noEmit`).
3. Abre un **PR de la rama hacia `develop`**, con título que identifica **la clave Jira, el ID de task y la descripción**; por ejemplo: `AF-77 FE-12.1 — Consultar depósito de una reserva`.
4. Completa la plantilla de PR: **Tarea de Jira**, **Cambios**, **Cómo se probó**, **Notas para la revisión** y comprobaciones previas. El PR enlaza la tarjeta para que Jira lo asocie automáticamente.
5. **Al menos otro integrante revisa y aprueba**. Si hay observaciones, el autor corrige en la misma rama y actualiza las pruebas; no se fusiona un PR rechazado.
6. Una vez aprobado, se fusiona a `develop` y se elimina la rama de trabajo. En el tablero, el PR lleva la task a **Code Review** y la aprobación/fusión permite continuar hacia **Control de calidad**; tras la verificación correspondiente, pasa a **Hecho**.

La evidencia de cada historia (tareas y PR) se recopila en [Historias por módulo](08-historias.md). El repositorio backend contiene la [plantilla de PR](../.github/pull_request_template.md).

## Preparación y mantenimiento de versiones

Para `v1.0.0`, el flujo indicado, es crear `release/1.0.0` desde `develop`, hacer un PR revisado hacia `main`, devolver los cambios de la release a `develop` y publicar la etiqueta **`v1.0.0`** sobre el commit desplegado **en cada repositorio**. La publicación debe reflejar exactamente el código de `main` y acompañarse de una breve descripción de la release.

Después de publicar, una corrección urgente se desarrolla en `hotfix/<descripcion>` desde `main`, se integra tanto a `main` como a `develop` y se publica con la siguiente versión de parche (por ejemplo `v1.0.1`).