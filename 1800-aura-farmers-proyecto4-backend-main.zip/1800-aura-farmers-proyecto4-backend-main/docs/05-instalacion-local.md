# Instalación local

Para correr el sistema completo se necesitan los dos repositorios: el backend (este) y el [frontend](https://github.com/ErickGomezUCA/1800-aura-farmers-proyecto4-frontend). El backend incluye el `docker-compose.yml` con PostgreSQL y la API; el frontend se corre con Node.

## Requisitos

- Git.
- Docker con Docker Compose v2 o superior.
- Node.js 24 recomendado (es el que usa la imagen de Docker). Mínimos: el backend necesita `^20.19`, `^22.12` o `>=24` (Prisma 7) y las pruebas del frontend necesitan 22.22 o superior (`jsdom` 31). Con Node 20, las pruebas del frontend no arrancan.
- npm (viene con Node.js).

Node.js solo hace falta fuera de Docker, es decir, para el frontend y para correr el backend en la máquina en lugar del contenedor.

## Pasos

Hay dos formas de levantar el backend. La **opción B** es la recomendada para desarrollar porque recarga el código al guardar. En las dos, el frontend se levanta igual (paso 2).

### 1. Backend y base de datos

**Opción A: todo con Docker.** Levanta PostgreSQL y la API; la API aplica las migraciones pendientes al arrancar.

1. Clonar el repositorio del backend y entrar a la carpeta.
2. Copiar el archivo de variables: `cp .env.example .env`. Completar `JWT_SECRET` con un secreto propio de al menos 32 caracteres (por ejemplo, el resultado de `openssl rand -base64 32`). `docker compose` no arranca si falta.
3. Levantar los servicios: `docker compose up --build`
4. Cargar los datos semilla: `docker compose exec api npx prisma db seed`
5. Comprobar que responde: la API queda en `http://localhost:3000/api/v1` y Swagger en `http://localhost:3000/api/docs`.

En esta opción, `docker-compose.yml` no carga el `.env` completo en la API: solo le pasa `JWT_SECRET`, `JWT_EXPIRES_IN`, `REFRESH_TOKEN_EXPIRES_IN_DAYS`, `BCRYPT_SALT_ROUNDS` y `CORS_ORIGINS`, arma `DATABASE_URL` con las variables `POSTGRES_*` y fija `PORT` en `3000` y `UPLOADS_DIR` en `/app/uploads` (el puerto publicado en la máquina sí se toma de `PORT` del `.env`). Las demás (`PAGO_SIMULADO_DEMORA_MS`, `COLA_*`, `PLAZO_*`, `TAREA_RESERVAS_ACTIVA` y `REVISION_VERIFICACION_ACTIVA`) toman su valor por defecto aunque estén en el `.env`. Además, la API corre con `NODE_ENV=production`. Para cambiar esas variables, usar la opción B.

**Opción B: PostgreSQL en Docker y la API en la máquina.**

1. Clonar el repositorio del backend y entrar a la carpeta.
2. Copiar el archivo de variables: `cp .env.example .env` y completar `JWT_SECRET`. Con la API fuera de Docker, `DATABASE_URL` debe apuntar a `localhost` (así viene en `.env.example`).
3. Levantar solo la base de datos: `docker compose up -d postgres`
4. Instalar las dependencias: `npm install`. El script `postinstall` genera el cliente de Prisma en `src/generated/prisma`.
5. Aplicar las migraciones: `npm run prisma:migrate`
6. Cargar los datos semilla: `npm run db:seed`
7. Arrancar la API en modo observación: `npm run start:dev`
8. Comprobar que responde en `http://localhost:3000/api/docs`.

### 2. Frontend

1. Clonar el repositorio del frontend y entrar a la carpeta.
2. Copiar el archivo de variables: `cp .env.example .env` y completar `API_URL` con `http://localhost:3000/api/v1`.
3. Instalar las dependencias: `npm install`
4. Arrancar en modo desarrollo: `npm run dev`
5. Abrir [http://localhost:3001](http://localhost:3001). El frontend usa el puerto 3001 por defecto porque el backend ocupa el 3000. Next no lee `PORT` desde `.env`, por eso `npm run dev` y `npm start` pasan por `scripts/next-con-puerto.mjs`, que carga el `.env` y le pasa el puerto a Next.

Para probar una versión compilada: `npm run build` y luego `npm start`.

El frontend también se puede levantar con Docker, con el backend de la opción A corriendo: `docker compose up -d --build` en la carpeta del frontend. Se une a la red del backend y queda en `http://localhost:3001`. Los detalles están en la sección «Correrlo con Docker» del README del frontend.

Los usuarios de prueba que crea el seed están definidos en `prisma/seed.ts` (un arrendatario y dos arrendadores, con la contraseña que declara el archivo). Las credenciales de entrega se publican en Moodle y no se repiten en esta documentación.

## Variables de entorno

Los archivos `.env` no se suben al repositorio. Cada repositorio trae un `.env.example` con todas las variables y sus valores de desarrollo.

### Backend

| Variable | Descripción | Ejemplo |
|---|---|---|
| `NODE_ENV` | Entorno de ejecución. Con `production`, `CORS_ORIGINS` es obligatoria | `development` |
| `PORT` | Puerto HTTP de la API (por defecto 3000) | `3000` |
| `DATABASE_URL` | **Obligatoria.** Cadena de conexión de Prisma. Con la API en la máquina, el host es `localhost`; dentro de Compose lo reemplaza `docker-compose.yml` por el servicio `postgres` | `postgresql://usuario:clave@localhost:5432/base?schema=public` |
| `POSTGRES_USER` | Usuario que crea el contenedor de PostgreSQL | `postgres` |
| `POSTGRES_PASSWORD` | Contraseña de ese usuario. El valor de desarrollo está en `.env.example` | `<contraseña local>` |
| `POSTGRES_DB` | Base que se crea al inicializar | `si_be_boilerplate` |
| `POSTGRES_PORT` | Puerto de PostgreSQL publicado en la máquina | `5432` |
| `JWT_SECRET` | **Obligatoria.** Secreto con el que se firman los access tokens; mínimo 32 caracteres | `<generar con openssl rand -base64 32>` |
| `JWT_EXPIRES_IN` | Vigencia del access token | `15m` |
| `REFRESH_TOKEN_EXPIRES_IN_DAYS` | Vigencia del refresh token, en días | `7` |
| `BCRYPT_SALT_ROUNDS` | Costo del hash de contraseñas | `12` |
| `CORS_ORIGINS` | Orígenes que pueden llamar a la API desde el navegador, separados por coma, sin ruta ni barra final. No acepta `*`. Fuera de producción, vacía usa `http://localhost:5173` | `http://localhost:5173` |
| `UPLOADS_DIR` | Carpeta donde se guardan las fotos de los bienes; se sirven en `/uploads` | `uploads` |
| `PAGO_SIMULADO_DEMORA_MS` | Milisegundos que tarda la pasarela de pago simulada. `0` la desactiva | `2000` |
| `COLA_RESERVAS_ACTIVA` | Si este proceso resuelve la cola de solicitudes de reserva (apagada con `NODE_ENV=test`) | `true` |
| `COLA_RESERVAS_INTERVALO_MS` | Cada cuántos milisegundos se revisa la cola | `30000` |
| `PLAZO_DEVOLUCION_DIAS` | Días de plazo para la devolución, para la automatización de reservas | `3` |
| `PLAZO_DEPOSITO_DIAS` | Días de plazo para resolver el depósito, para la automatización de reservas | `3` |
| `TAREA_RESERVAS_ACTIVA` | Si este proceso ejecuta la tarea diaria de reservas y depósitos (apagada con `NODE_ENV=test`) | `true` |
| `REVISION_VERIFICACION_ACTIVA` | Si este proceso ejecuta la revisión simulada de documentos de identidad (siempre apagada con `NODE_ENV=test`) | `true` |

La API valida el entorno al arrancar: si falta `DATABASE_URL` o `JWT_SECRET`, o si el secreto tiene menos de 32 caracteres, no levanta y muestra un mensaje claro.

### Frontend

| Variable | Descripción | Ejemplo |
|---|---|---|
| `API_URL` | URL base de la API, incluido el prefijo `/api/v1` | `http://localhost:3000/api/v1` |
| `REFRESH_TOKEN_EXPIRES_IN_DAYS` | Vigencia de la cookie del refresh token; debe coincidir con la del backend. Vacía usa 7 | `7` |
| `PORT` | Puerto del frontend. Vacío usa 3001 | `3001` |

El frontend valida `API_URL` y `REFRESH_TOKEN_EXPIRES_IN_DAYS` al arrancar (`instrumentation.ts`); si están mal, el servidor no levanta.

## Migraciones y datos semilla

Las migraciones están en `prisma/migrations/` y el schema en `prisma/schema.prisma`. Los comandos se corren desde la carpeta del backend:

| Comando | Qué hace |
|---|---|
| `npm run prisma:migrate` | Crea y aplica migraciones en desarrollo (`prisma migrate dev`). Para una migración nueva: `npm run prisma:migrate -- --name descripcion_del_cambio` |
| `npm run prisma:deploy` | Aplica las migraciones pendientes sin crear ninguna (`prisma migrate deploy`). Es el que corre el contenedor al arrancar |
| `npm run prisma:generate` | Regenera el cliente de Prisma después de tocar el schema |
| `npm run db:seed` | Carga los datos de prueba (`prisma/seed.ts`). Usa `upsert` e identificadores fijos, así que se puede correr varias veces |
| `npm run db:reset` | Borra la base, vuelve a aplicar todas las migraciones y corre el seed |
| `npm run prisma:studio` | Abre una interfaz web para explorar los datos |

Para empezar de cero con Docker (**borra los datos**):

```bash
docker compose down -v && docker compose up -d postgres
npm run prisma:migrate && npm run db:seed
```

El cliente generado (`src/generated/prisma`) no se sube al repositorio; se regenera con cada `npm install`.

## Pruebas automatizadas

### Backend

```bash
npm test            # pruebas unitarias (*.spec.ts, junto al código)
npm run build && env $(grep ^DATABASE_URL= .env) npm run test:e2e   # pruebas e2e (test/*.e2e-spec.ts), en bash
npm run test:cov    # unitarias con cobertura
npm run lint        # oxlint
```

El comando de las e2e usa la sintaxis de bash (Git Bash, macOS o Linux). En **PowerShell** exporta primero `DATABASE_URL` desde el `.env` y luego corre las pruebas:

```powershell
npm run build
$env:DATABASE_URL = (Select-String '^DATABASE_URL=' .env).Line.Split('=', 2)[1]
npm run test:e2e
```

- Las pruebas unitarias están junto al código y se llaman `*.spec.ts`. No necesitan base de datos.
- Las pruebas e2e están en `test/` y se llaman `*.e2e-spec.ts`. Usan Supertest contra PostgreSQL (`DATABASE_URL`), así que la base debe estar levantada con sus migraciones aplicadas (`docker compose up -d postgres`). Cada suite crea sus propios datos con un sufijo único y los borra al terminar, y corren una a una. Conviene correrlas contra una base de desarrollo, no contra datos que se quieran conservar.
- La suite `test/verificaciones-revision-cron.e2e-spec.ts` levanta la API **compilada** (`dist/`) y lee `DATABASE_URL` directamente del entorno, no del `.env`. Por eso el comando de arriba compila primero y exporta `DATABASE_URL` desde el `.env`. Sin eso, esa suite falla con «Falta la API compilada…» o con `SASL: … client password must be a string`.
- Para una sola suite: `npx vitest run --config ./vitest.config.e2e.ts test/bloqueos.e2e-spec.ts`
- Las pruebas de integración de los repositorios (`src/**/*.integration.spec.ts`) se saltan en `npm test` salvo que se active `RUN_DB_INTEGRATION=1`, por ejemplo: `env RUN_DB_INTEGRATION=1 $(grep ^DATABASE_URL= .env) npm test`. Algunas exigen una base desechable en UTC y no la del `docker-compose` de desarrollo; el README indica cuáles. En CI corren siempre, contra un PostgreSQL desechable.

### Frontend

```bash
npm test            # una corrida
npm run test:watch  # modo observación
npm run lint        # ESLint
npm run build       # compila y revisa los tipos
```

Las pruebas usan Vitest, React Testing Library y jsdom, viven junto al código en archivos `*.test.ts(x)` y simulan la API con `fetch` simulado, así que no necesitan el backend levantado. Las convenciones están en [docs/pruebas.md del frontend](https://github.com/ErickGomezUCA/1800-aura-farmers-proyecto4-frontend/blob/develop/docs/pruebas.md).

## Problemas frecuentes

| Síntoma | Causa y solución |
|---|---|
| `docker compose` falla con «JWT_SECRET es obligatorio» | Falta el archivo `.env` o la variable. Copiar `.env.example` y completar `JWT_SECRET` |
| La API no arranca y menciona `JWT_SECRET` o `DATABASE_URL` | Variable ausente o secreto de menos de 32 caracteres |
| El frontend no levanta | `API_URL` vacía o con formato inválido. Debe incluir el prefijo `/api/v1` |
| Las pruebas del frontend no arrancan | Versión de Node anterior a 22.22. Cambiar a Node 24 |
| Error de conexión a la base en la opción B | PostgreSQL no está arriba (`docker compose ps`) o `POSTGRES_PORT` y `DATABASE_URL` no coinciden |
| Una prueba e2e falla con «Falta la API compilada» o `client password must be a string` | Falta `npm run build` o `DATABASE_URL` no está en el entorno. Compilar y exportar `DATABASE_URL` desde el `.env`: en bash, `npm run build && env $(grep ^DATABASE_URL= .env) npm run test:e2e`; en PowerShell, la variante de la sección «Pruebas automatizadas» |
| Un cambio en `COLA_*`, `PLAZO_*` u otra variable del `.env` no tiene efecto con la opción A | `docker-compose.yml` solo pasa algunas variables a la API. Usar la opción B o agregar la variable al servicio `api` del compose |
| Las fotos de los bienes no se ven | El frontend reenvía `/uploads/**` al origen de `API_URL`. Comprobar que `API_URL` apunte a la API que guardó las fotos |
