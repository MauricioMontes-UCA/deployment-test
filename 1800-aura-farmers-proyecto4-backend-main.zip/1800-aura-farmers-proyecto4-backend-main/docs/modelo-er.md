# Modelo entidad-relación

Entidades implementadas hasta ahora en `prisma/schema.prisma`. Las demás se agregan con las tareas de cada módulo.

```mermaid
erDiagram
    Usuario {
        uuid id PK
        string nombreUsuario UK "3-30 minusculas, a-z 0-9 . _ -"
        string email UK
        string passwordHash
        Rol rol "ARRENDADOR, ARRENDATARIO"
        boolean isActive
        datetime creadoEn
        datetime actualizadoEn
    }
    RefreshToken {
        uuid id PK
        string tokenHash UK
        uuid userId FK
        datetime expiraEn
        datetime revocadoEn "nullable"
        datetime creadoEn
    }
    Bien {
        uuid id PK
        uuid arrendadorId FK
        TipoBien tipo "PROPIEDAD, EQUIPO"
        string categoria "max 50"
        string titulo "5-100"
        string descripcion "max 2000"
        decimal precio "12,2 mayor a 0"
        UnidadCobro unidadCobro "HORA, DIA, NOCHE, SEMANA"
        decimal deposito "12,2 default 0"
        int capacidad "nullable, mayor a 0"
        string condiciones "nullable max 1000"
        string departamento "max 50"
        string municipio "max 80"
        string direccionReferencia "nullable max 200"
        EstadoBien estado "ACTIVA, INACTIVA"
        tsvector busqueda "generada"
        datetime creadoEn
        datetime actualizadoEn
    }
    FotoBien {
        uuid id PK
        uuid bienId FK
        string url "max 500"
        smallint orden "UK con bienId"
        boolean esPrincipal "una por bien"
        datetime creadoEn
    }
    PoliticaVerificacionBien {
        uuid bienId PK,FK
        boolean soloVerificados "default false"
        datetime actualizadoEn
    }
    Reserva {
        uuid id PK
        uuid bienId FK
        uuid arrendatarioId FK
        date fechaInicio "rango inclusivo"
        date fechaFin "mayor o igual a fechaInicio"
        EstadoReserva estado "EN_COLA, CONFIRMADA, RECHAZADA, EN_CURSO, FINALIZADA, CANCELADA"
        string motivoResolucion "nullable max 200"
        datetime creadaEn
        datetime procesadaEn "nullable"
        datetime finalizadaEn "nullable"
        boolean cierreAutomatico "default false"
    }
    BloqueoFecha {
        uuid id PK
        uuid bienId FK
        date fechaInicio "rango inclusivo"
        date fechaFin "mayor o igual a fechaInicio"
        datetime creadoEn
    }
    Devolucion {
        uuid id PK
        uuid reservaId FK, UK
        uuid registradoPorId FK
        datetime fechaDevolucion
        EstadoFinalBien estadoFinalBien "BUEN_ESTADO, DANADO, INCOMPLETO"
        string observaciones "nullable max 500"
        datetime creadoEn
        datetime actualizadoEn
    }
    Pago {
        uuid id PK
        uuid reservaId FK
        ModalidadPago modalidad "TARJETA, TRANSFERENCIA_BANCARIA"
        decimal importeAlquiler "12,2 mayor o igual a 0"
        decimal importeDeposito "12,2 mayor o igual a 0"
        decimal total "12,2 mayor o igual a 0"
        EstadoPago estado "PENDIENTE, SIMULADO_EXITOSO, SIMULADO_RECHAZADO"
        datetime fechaHora
        uuid comprobanteId UK "nullable"
        string referenciaSimulada "nullable max 20"
        string ultimosCuatro "nullable char 4"
        string motivoRechazo "nullable max 200"
        datetime creadoEn
        datetime actualizadoEn
    }
    Deposito {
        uuid id PK
        uuid reservaId FK, UK
        uuid resueltoPorId FK "nullable"
        decimal importeOriginal "12,2 mayor o igual a 0"
        decimal importeRetenido "12,2 default 0"
        decimal importeLiberado "12,2 default 0"
        EstadoDeposito estado "PENDIENTE, LIBERADO, RETENIDO, PARCIALMENTE_RETENIDO"
        string justificacion "nullable max 500"
        datetime fechaResolucion "nullable"
        boolean resolucionAutomatica "default false"
        datetime plazoResolucion "nullable"
        datetime creadoEn
        datetime actualizadoEn
    }
    Resena {
        uuid id PK
        uuid reservaId FK "UK con tipo"
        uuid autorId FK
        TipoResena tipo "BIEN, ARRENDADOR, ARRENDATARIO"
        int puntuacion "1 a 5"
        string comentario "nullable max 500"
        datetime creadaEn
    }
    SolicitudVerificacion {
        uuid id PK
        uuid usuarioId FK
        EstadoSolicitudVerificacion estado "EN_REVISION, APROBADA, RECHAZADA"
        string motivo "nullable max 200"
        datetime revisadoEn "nullable"
        datetime creadaEn
    }
    DocumentoVerificacion {
        uuid id PK
        uuid solicitudId FK, UK
        string nombreArchivo "max 255"
        bytes contenido
        string mimeType "max 100"
        int tamanoBytes "max 5242880"
    }
    Notificacion {
        uuid id PK
        uuid destinatarioId FK
        ModuloOrigen moduloOrigen "RESERVAS, PAGOS, MENSAJERIA, RESENAS, VERIFICACION"
        string titulo "max 100"
        string mensaje "max 300"
        string tipoReferencia "nullable max 40, UK con destinatarioId y referenciaId"
        string referenciaId "nullable max 36, UK con destinatarioId y tipoReferencia"
        EstadoNotificacion estado "NO_LEIDA, LEIDA"
        datetime creadaEn
        datetime leidaEn "nullable"
        datetime updatedAt
    }
    Conversacion {
        uuid id PK
        uuid bienId FK
        uuid reservaId FK "nullable, unico"
        uuid arrendadorId FK
        uuid arrendatarioId FK
        datetime creadaEn
        datetime updatedAt
    }
    
    Mensaje {
        uuid id PK
        uuid conversacionId FK
        uuid remitenteId FK
        string contenido "1-1000 caracteres"
        datetime creadoEn
    }

    Bien ||--o{ Conversacion : "recibe consultas"
    Reserva |o--o| Conversacion : "coordina"
    Usuario ||--o{ Conversacion : "arrendador"
    Usuario ||--o{ Conversacion : "arrendatario"
    Conversacion ||--o{ Mensaje : "contiene"
    Usuario ||--o{ Mensaje : "envia"

    Usuario ||--o{ RefreshToken : "tiene"
    Usuario ||--o{ Bien : "publica"
    Usuario ||--o{ Notificacion : "recibe"
    Bien ||--|{ FotoBien : "tiene 1 a 10"
    Bien ||--o| PoliticaVerificacionBien : "configura"
    Bien ||--o{ Reserva : "es reservado en"
    Usuario ||--o{ Reserva : "solicita"
    Bien ||--o{ BloqueoFecha : "bloquea"
    Reserva ||--o{ Pago : "se paga con"
    Reserva ||--o{ Resena : "recibe 0 a 3"
    Usuario ||--o{ Resena : "escribe"
    Reserva ||--o| Devolucion : "se cierra con"
    Usuario ||--o{ Devolucion : "registra"
    Reserva ||--o| Deposito : "genera"
    Usuario |o--o{ Deposito : "resuelve"
    Usuario ||--o{ SolicitudVerificacion : "envia"
    SolicitudVerificacion ||--|| DocumentoVerificacion : "adjunta"
```

## Nombres en la base

- Los modelos `Usuario`, `Bien`, `FotoBien` y `Notificacion` se guardan en las tablas `Usuarios`, `Bienes`, `FotosBien` y `Notificaciones` (las de reservas se describen más abajo), y `RefreshToken` en `refresh_tokens`.
- Las columnas usan snake_case, por ejemplo `nombre_usuario` y `creado_en`.
- El largo y el formato de `nombre_usuario` los imponen dos CHECK de la migración `agrega_rol_y_nombre_usuario`. Como solo admite minúsculas, su índice único impide repetidos sin distinguir mayúsculas.
- El modelo `PoliticaVerificacionBien` se guarda en la tabla `PoliticasVerificacionBien`, con `bien_id` como llave primaria: cada bien tiene como máximo un registro. Un bien sin registro se trata como `soloVerificados = false`; esa regla la aplica el backend (BE-19.2).
- Al borrar un bien se borra su política (`ON DELETE CASCADE`). Es una decisión técnica porque DB-19.1 no lo define: la política no tiene sentido sin su bien y `FotosBien` ya funciona así.
- Las reglas de precio, depósito, capacidad y título de `Bienes`, y la foto principal única de `FotosBien`, están en la migración `crea_bienes_y_fotos`. El límite de 1 a 10 fotos lo valida el backend.
- La búsqueda de texto completo está descrita en [busqueda-bienes.md](busqueda-bienes.md).
- Los filtros de búsqueda usan los índices parciales `idx_bienes_filtros`, sobre tipo, categoría y precio de los bienes activos, e `idx_bienes_capacidad`.
- En `Notificaciones`, el índice único `Notificaciones_referencia_key` impide repetir un aviso con la misma referencia para el mismo destinatario. Como PostgreSQL trata los NULL como distintos, solo actúa cuando hay referencia. El CHECK `Notificaciones_referencia_completa_check` exige `tipo_referencia` y `referencia_id` juntos o ambos vacíos.
- La llave foránea de `Notificaciones` hacia `Usuarios` usa `ON DELETE RESTRICT`. Es una decisión técnica: DB-20.1 no define ese comportamiento y los avisos no se eliminan en esta entrega.
- Los modelos `Reserva` y `BloqueoFecha` se guardan en `Reservas` y `BloqueosFecha`. Una solicitud de reserva es una `Reserva` en estado `EN_COLA`. Sus fechas son días completos y el rango es inclusivo: `fecha_fin` es el último día ocupado, y un CHECK exige `fecha_fin >= fecha_inicio` en ambas tablas.
- La restricción de exclusión `reserva_sin_solape` (GiST, extensión `btree_gist`) impide que un mismo bien tenga dos reservas `CONFIRMADA`, `EN_CURSO` o `FINALIZADA` con días en común, en cualquier combinación de esos estados. Las reservas `EN_COLA`, `RECHAZADA` y `CANCELADA` pueden solaparse. Prisma no puede expresarla en el schema, así que solo existe en la migración `crea_reservas_y_bloqueos_fecha`. Al violarla, PostgreSQL responde con el código `23P01` (`exclusion_violation`) y el nombre `reserva_sin_solape`, que el procesador de la cola (BE-6.2) trata como rechazo por fechas.
- Los bloqueos no tienen restricción de solape: los conflictos entre bloqueos, y entre un bloqueo y las reservas, los valida el backend (BE-7.1). Las llaves foráneas de `Reservas` usan `ON DELETE RESTRICT` porque son historial; la de `BloqueosFecha` usa `CASCADE`. Es una decisión técnica: DB-5.1 no define ese comportamiento.
- El modelo `Pago` se guarda en `Pagos`. Una reserva puede tener varios pagos, porque un pago rechazado deja el cobro pendiente y el reintento es un registro nuevo. El índice único parcial `Pagos_un_exitoso_por_reserva_key` (sobre `reserva_id`, solo donde `estado = 'SIMULADO_EXITOSO'`) impide dos pagos exitosos para la misma reserva, también bajo concurrencia. Al violarlo, PostgreSQL responde con el código `23505` (`unique_violation`) y ese nombre, que BE-8.1 traduce a 409. Prisma no puede expresar el índice parcial, así que solo existe en la migración `crea_pagos`, igual que el CHECK `Pagos_importes_check` (importes no negativos).
- `Pagos` no tiene columnas para el número de tarjeta ni el CVV: de la tarjeta solo se guardan los últimos cuatro dígitos. La llave foránea hacia `Reservas` usa `ON DELETE RESTRICT` porque los pagos son historial. Es una decisión técnica: DB-8.1 no define ese comportamiento.
- El modelo `Resena` se guarda en la tabla `Resenas`. Una reseña no se edita ni se borra, por eso no tiene `updatedAt`. El índice único `(reserva_id, tipo)` permite una reseña por tipo en cada reserva, y el CHECK `Resenas_puntuacion_check` limita la puntuación de 1 a 5.
- Las llaves foráneas de `Resenas` hacia `Reservas` y `Usuarios` usan `ON DELETE RESTRICT`. Es una decisión técnica: DB-15.1 no define ese comportamiento y las reseñas no se eliminan.
- El modelo `Devolucion` se guarda en la tabla `Devoluciones`. Una reserva tiene como máximo una devolución: el índice único `Devoluciones_reserva_id_key` lo impide. `registrado_por` y `created_at` dejan constancia de quién y cuándo la registró. `Reservas` agrega `finalizada_en` (nullable), que se llena al registrar la devolución o en el cierre automático, y `cierre_automatico` (`false` por defecto), que distingue ese segundo caso.
- Las llaves foráneas de `Devoluciones` hacia `Reservas` y `Usuarios` usan `ON DELETE RESTRICT`. Es una decisión técnica: DB-10.1 pide conservar el registro sin borrado físico, pero no define ese comportamiento.
- El modelo `Deposito` se guarda en la tabla `Depositos`. Una reserva tiene como máximo un depósito: el índice único `Depositos_reserva_id_key` lo impide. Nace `PENDIENTE` con `importe_retenido` e `importe_liberado` en 0. Dos CHECK de la migración exigen que los tres importes sean mayores o iguales a 0 (`Depositos_importes_check`) y que lo retenido más lo liberado no supere el importe original (`Depositos_suma_check`). Prisma no puede expresarlos en el schema.
- `resuelto_por` es nulo mientras el depósito está pendiente y cuando lo resuelve el sistema (`resolucion_automatica = true`). `plazo_resolucion` lo llena BE-10.1 y la liberación automática la aplica BE-10.2. Las llaves foráneas de `Depositos` hacia `Reservas` y `Usuarios` usan `ON DELETE RESTRICT`. Es una decisión técnica: DB-11.1 no define ese comportamiento y el depósito es un registro de auditoría.
- Los índices parciales `idx_pago_exitoso_fecha` (sobre `Pagos.fecha_hora`, solo `SIMULADO_EXITOSO`) e `idx_deposito_retenido_fecha` (sobre `Depositos.fecha_resolucion`, solo `RETENIDO` y `PARCIALMENTE_RETENIDO`) respaldan el reporte de ingresos por periodo. No son tablas ni columnas nuevas, y Prisma no puede expresarlos en el schema, así que solo existen en la migración `indices_pagos_depositos`.
- `npm run db:seed` carga los datos de prueba del panel de reportes: cinco bienes ACTIVA (cuatro del arrendador A y uno del B) con ids `00000000-0000-4000-8000-00000000000n`, y cinco reservas del usuario demo con ids `10000000-0000-4000-8000-00000000000n`, con sus pagos (`60000000-...`) y depósitos (`70000000-...`). Las fechas son relativas al día de carga. Para el arrendador A, el último mes y los últimos 3 meses suman $250.00 de ingreso (todo del Bien 1) y $50.00 de depósito retenido; el último año suma $330.00 y $65.00. El seed usa `upsert` por id y se puede repetir.
- Para la tasa de ocupación, `Reservas` tiene el índice `Reservas_bien_id_estado_fecha_inicio_fecha_fin_idx` (`bien_id`, `estado`, `fecha_inicio`, `fecha_fin`) y `BloqueosFecha` tiene `BloqueosFecha_bien_id_fecha_inicio_fecha_fin_idx` (`bien_id`, `fecha_inicio`, `fecha_fin`). Cubren la consulta de las reservas y los bloqueos de varios bienes que cruzan un periodo, así que PostgreSQL puede responderla solo con el índice. Los índices `(bien_id, fecha_inicio)` de DB-5.1 se conservan.
- Los datos de prueba de ocupación (reservas R6 a R10 con ids `10000000-...` y bloqueos con ids `41000000-...`) completan los del panel. Con el periodo del último mes (de hoy-29 a hoy), para el arrendador A: el Bien 1 tiene 10 días ocupados de 20 disponibles (50.0 %), el Bien 2 está bloqueado todo el periodo (sin días disponibles), el Bien 3 tiene 0 de 30 (0.0 %) y el Bien 4 tiene 30 de 30 (100.0 %). El Bien 5 es del arrendador B y no aparece para el A.
- Las reseñas de prueba del panel son del usuario demo sobre reservas `FINALIZADA` y no cambian el esquema. Con el periodo del último mes, para el arrendador A: el Bien 1 tiene 4.5 con 2 reseñas (R1 con 5 y R2 con 4), el Bien 4 tiene 3.0 con 1 (R8) y los Bienes 2 y 3 no tienen calificaciones. En el último año, el Bien 2 tiene 5.0 con 1 reseña (R4). R1 tiene además una reseña de tipo `ARRENDADOR` de 1, que no forma parte del promedio de un bien. La reserva R10 (Bien 5, `FINALIZADA`, de hoy-64 a hoy-60) existe solo para la reseña de 2 del arrendador B, porque R5 está `CONFIRMADA` y `reserva_sin_solape` no permite otra reserva `FINALIZADA` en esas fechas.
- Los importes de depósito que la tarea no fija son una decisión técnica: la reserva R4 usa $25.00 (el depósito del Taladro industrial), y R3 y R5 no tienen depósito.
- Los modelos `SolicitudVerificacion` y `DocumentoVerificacion` se guardan en `SolicitudesVerificacion` y `DocumentosVerificacion`. El documento va en una tabla aparte para no cargar el binario al listar solicitudes, y cada solicitud tiene exactamente un documento (`solicitud_id` es único).
- El estado de verificación de un usuario no se guarda: se deriva de su solicitud más reciente (`APROBADA` = Verificado, `RECHAZADA` = Rechazado, `EN_REVISION` = En revisión, sin solicitudes = No verificado). El índice `SolicitudesVerificacion_usuario_id_creada_en_idx` sirve para encontrar esa solicitud.
- El índice único parcial `solicitud_una_en_revision` impide que un usuario tenga dos solicitudes `EN_REVISION` a la vez; las `APROBADA` y `RECHAZADA` no cuentan, así que puede haber varias. El CHECK `DocumentosVerificacion_tamano_check` limita `tamano_bytes` a 5242880 (5 MB). El formato del archivo (JPG, PNG o PDF) lo valida el backend (BE-17.1), no la base. Prisma no puede expresar ninguna de las dos restricciones en el schema, así que solo existen en la migración `crea_solicitudes_verificacion`.
- La llave foránea de `SolicitudesVerificacion` hacia `Usuarios` usa `ON DELETE RESTRICT`, porque las solicitudes son historial; la de `DocumentosVerificacion` hacia su solicitud usa `CASCADE`. Es una decisión técnica: DB-17.1 no define ese comportamiento.
- Cada migración de estas se revierte con el `down.sql` de su carpeta.
