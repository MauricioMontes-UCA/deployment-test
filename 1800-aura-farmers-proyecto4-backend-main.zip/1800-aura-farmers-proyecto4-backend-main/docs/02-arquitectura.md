# Arquitectura

Aura Farmers está formado por tres piezas: un frontend en Next.js, una API REST en NestJS y una base de datos PostgreSQL. Cada pieza vive en su propio repositorio o contenedor y se comunica con la siguiente por una interfaz bien definida.

| Pieza | Repositorio o servicio |
|---|---|
| Frontend (Next.js) | [1800-aura-farmers-proyecto4-frontend](https://github.com/ErickGomezUCA/1800-aura-farmers-proyecto4-frontend) |
| Backend (NestJS + Prisma) | [1800-aura-farmers-proyecto4-backend](https://github.com/ErickGomezUCA/1800-aura-farmers-proyecto4-backend) (este repositorio, donde está la documentación completa) |
| Base de datos | PostgreSQL 18, definida en el `docker-compose.yml` del backend |

## Vista general

```mermaid
flowchart LR
    U[Usuario en el navegador] -->|HTTPS arre.live| NG[Nginx]
    NG --> FE

    subgraph FE[Frontend · Next.js]
        direction TB
        P[proxy.ts<br/>sesión y renovación del token]
        SC[Server components<br/>y server actions]
        RH[Route handlers /api<br/>puentes hacia la API]
    end

    FE -->|HTTP / JSON por la red de Docker<br/>Authorization: Bearer| BE

    subgraph BE[Backend · NestJS]
        direction TB
        C[controllers] --> S[services] --> R[repositories]
        SW[Swagger<br/>/api/docs]
        UP[Archivos estáticos<br/>/uploads]
    end

    R -->|Prisma + driver pg| DB[(PostgreSQL 18)]
    UP --- V[(Volumen<br/>uploads)]
```

En producción, las tres piezas corren como servicios de Docker Compose (`web`, `api` y `postgres`) en un VPS. Nginx recibe el tráfico HTTPS de `arre.live` y lo pasa al frontend, que llama a la API por la red interna de Docker (`http://api:3000/api/v1`). Cada repositorio publica su imagen en GitHub Container Registry y la despliega con su workflow de CI/CD al fusionar a `main`. Los detalles están en [06-despliegue.md](06-despliegue.md).

### Cómo viaja una petición

1. El navegador solo habla con el frontend. Nunca llama a la API directamente: el frontend guarda los tokens en cookies `httpOnly` (`access_token` y `refresh_token`), que JavaScript del navegador no puede leer.
2. Los *server components* y las *server actions* de Next.js llaman a la API desde el servidor con el access token en el encabezado `Authorization: Bearer`. Las pantallas que cargan datos desde el cliente (listas con «Cargar más», por ejemplo) pasan por *route handlers* en `app/api/**`, que reenvían la petición a la API con el token de la cookie.
3. `proxy.ts` revisa en cada navegación si el access token venció. Si venció, lo renueva con `POST /auth/refresh` y escribe las cookies nuevas. Si el backend rechaza el refresh, borra las cookies y envía al usuario a iniciar sesión.
4. En el backend, la petición recorre `controller → service → repository → Prisma → PostgreSQL`. El `JwtAuthGuard` global protege todo por defecto y las rutas públicas se abren con `@Public()`.
5. Las fotos de los bienes las guarda el backend en la carpeta `UPLOADS_DIR` y las sirve en `/uploads`, fuera del prefijo `/api/v1`. El frontend reenvía `/uploads/**` al origen de la API (`rewrites` en `next.config.ts`), de modo que el navegador las pida al mismo dominio que la aplicación.

Los detalles de la sesión están en la sección «Sesión y autenticación» del README del frontend y en [contrato-token-jwt.md](contrato-token-jwt.md). El contrato de los endpoints está en [04-api.md](04-api.md).

## Stack

| Capa | Tecnología | Versión |
|---|---|---|
| Frontend | Next.js (App Router) | 16.3 |
| Frontend | React | 19.2 |
| Frontend | TypeScript | 5 |
| Frontend | Tailwind CSS | 4 |
| Frontend | Vitest, React Testing Library y jsdom | 4, 16 y 31 |
| Frontend | ESLint | 9 |
| Backend | NestJS | 12 |
| Backend | TypeScript (ESM puro) | 6 |
| Backend | Prisma ORM con `@prisma/adapter-pg` | 7 |
| Backend | JWT (`@nestjs/jwt`) y bcrypt | 12 y 6 |
| Backend | class-validator y class-transformer | 0.15 y 0.5 |
| Backend | Swagger (`@nestjs/swagger`) | 12 |
| Backend | Vitest y Supertest (pruebas), oxlint (linter) | 4, 7 y 1 |
| Base de datos | PostgreSQL (`postgres:18-alpine`) | 18 |
| Contenedores | Docker y Docker Compose | Compose v2 o superior |
| Entorno de ejecución | Node.js (imagen `node:24-alpine`) | 24 |

Node.js 24 es la versión que usa la imagen de Docker. En local, el backend exige Node `^20.19`, `^22.12` o `>=24` (requisito de Prisma 7) y las pruebas del frontend necesitan Node 22.22 o superior (requisito de `jsdom` 31).

## Estructura de carpetas

### Backend (este repositorio)

```
.
├── docs/                  Documentación (este directorio)
├── prisma/
│   ├── schema.prisma      Modelos y enumeraciones
│   ├── migrations/        Migraciones versionadas
│   └── seed.ts            Datos de prueba
├── src/
│   ├── auth/              Inicio y cierre de sesión, JWT, guards y roles
│   ├── bienes/            Publicaciones, búsqueda, fotos y políticas
│   ├── bloqueos/          Bloqueos de fechas de un bien
│   ├── conversaciones/    Mensajería entre arrendador y arrendatario
│   ├── depositos/         Resolución de depósitos
│   ├── health/            Ruta de salud de la API
│   ├── notificaciones/    Notificaciones de los usuarios
│   ├── pagos/             Pago simulado y comprobantes
│   ├── reportes/          Reportes del arrendador
│   ├── reservas/          Reservas, devoluciones, cola de solicitudes y tareas automáticas
│   ├── resenas/           Reseñas y calificaciones
│   ├── users/             Usuarios
│   ├── verificaciones/    Verificación de identidad
│   ├── common/            Código compartido (decoradores)
│   ├── config/            Variables de entorno y su validación
│   ├── prisma/            PrismaService
│   ├── app.module.ts      Módulo raíz
│   ├── app.setup.ts       CORS, prefijo /api/v1, validación y archivos estáticos
│   └── main.ts            Arranque y Swagger
├── test/                  Pruebas e2e (*.e2e-spec.ts) y utilidades
├── .github/workflows/     CI/CD: pruebas, imagen en GHCR y despliegue al VPS
├── Dockerfile             Imagen de la API (multi-stage)
├── docker-compose.yml     PostgreSQL y API
├── prisma.config.ts       Configuración del CLI de Prisma
└── vitest.config*.ts      Configuración de pruebas unitarias y e2e
```

Dentro de cada módulo, el código se organiza por responsabilidad en `controllers/`, `services/`, `repositories/`, `dto/` y `errors/`, y cada carpeta expone un `index.ts`. Los import entre módulos usan *path aliases* (`@Auth`, `@Bienes`, `@Prisma`…). El README explica las capas en [Arquitectura por capas](../README.md#arquitectura-por-capas) y los alias en [Path aliases](../README.md#path-aliases).

### Frontend

```
.
├── app/                   Rutas (App Router): páginas, acciones y route handlers
│   ├── api/               Puentes hacia la API del backend
│   └── actions/           Server actions (por ejemplo, cerrar sesión)
├── components/            Componentes; components/ui es el Design System «Arre»
├── lib/                   Cliente de la API, sesión, validaciones y utilidades
├── pruebas/               Utilidades compartidas entre pruebas
├── public/                Íconos e imágenes estáticas
├── scripts/               next-con-puerto.mjs (arranque con el puerto de PORT)
├── docs/                  Notas del frontend (docs/pruebas.md)
├── .github/workflows/     CI/CD: pruebas, imagen en GHCR y despliegue al VPS
├── Dockerfile             Imagen de producción (servidor standalone de Next)
├── docker-compose.yml     Levanta el frontend unido a la red del backend
├── proxy.ts               Sesión, rutas por rol y renovación del token
├── instrumentation.ts     Valida las variables de entorno al arrancar
└── next.config.ts         Salida standalone, imágenes y reenvío de /uploads al backend
```

Las pruebas viven junto al código, en archivos `*.test.ts(x)`.

## Decisiones técnicas

| Decisión | Alternativas consideradas | Motivo |
|---|---|---|
| API REST con prefijo `/api/v1` y Swagger en `/api/docs` | Una API por pantalla o GraphQL | Un contrato simple y versionado que el frontend y los compañeros del equipo pueden probar sin código. Swagger documenta cada endpoint a partir del propio código. |
| Capas `controller → service → repository` | Que los servicios usen Prisma directamente | Cada tabla se consulta en un solo lugar, los servicios se prueban sin base de datos y los errores del ORM no se filtran hacia HTTP. |
| Prisma 7 con `@prisma/adapter-pg` y `engineType = "client"` | Prisma con el motor nativo de Rust, TypeORM | Migraciones versionadas y tipos generados desde el schema. Sin el motor nativo, la imagen Alpine funciona sin instalar `libssl`. |
| JWT de acceso (15 min) y refresh token (7 días) con rotación | Sesiones en el servidor | La API no guarda estado de sesión por petición. La rotación del refresh token con detección de reúso cierra todas las sesiones si un token se canjea dos veces. |
| El frontend guarda los tokens en cookies `httpOnly` y llama a la API desde el servidor | Guardar el token en `localStorage` y llamar desde el navegador | Un script del navegador no puede leer los tokens, lo que reduce el daño de un ataque XSS. |
| Renovación compartida del token en `proxy.ts` | Renovar en cada componente | Varias peticiones simultáneas con el mismo refresh token esperan una sola llamada. El backend trata un refresh usado dos veces como robado, así que no se puede renovar en paralelo. |
| Permisos por rol leídos de la base en cada petición | Confiar en el rol del token | Un cambio de rol o una cuenta desactivada se aplican en la siguiente petición, sin esperar a que el token expire. |
| Fotos de los bienes en una carpeta (`UPLOADS_DIR`) con volumen de Docker | Almacenamiento de objetos en la nube | Es lo más sencillo para el alcance del curso. Tiene un costo: la carpeta debe persistir entre despliegues y no escala a varias instancias. |
| Pago, revisión de identidad y cola de reservas simulados dentro de la API | Integrar una pasarela y un servicio de verificación reales | El proyecto es académico: se simula el comportamiento y los tiempos (`PAGO_SIMULADO_DEMORA_MS`, `REVISION_VERIFICACION_ACTIVA`, `COLA_RESERVAS_ACTIVA`) sin depender de terceros. |
| Docker Compose con PostgreSQL y API | Instalar PostgreSQL en cada máquina | Todo el equipo trabaja con la misma versión de la base. La API espera el *healthcheck* de la base antes de aplicar migraciones. |
| Next.js con App Router, React y Tailwind 4 con tokens del diseño | Una SPA con React solo del lado del cliente | Permite leer la sesión y cargar datos en el servidor, y mantiene los colores y espaciados del diseño en un solo lugar. |
| Vitest en el frontend y en el backend | Jest | La misma herramienta y la misma API de pruebas en los dos repositorios. |
