<!--
Título del PR: empieza con el código de la tarea de Jira, por ejemplo:
AF-20 Agregar rol y nombre de usuario

Rama destino: feature/* hacia develop, y release/* hacia main.
-->

## Tarea de Jira

AF-XXX: https://1800-aura-farmers.atlassian.net/browse/AF-XXX

## Cambios

-

## Cómo se probó

-

## Notas para la revisión

<!-- Decisiones, pendientes o riesgos que deba conocer quien revisa. Si no hay, borra esta sección. -->

## Antes de pedir revisión

- [ ] El título incluye el código de la tarea
- [ ] La rama destino es la correcta
- [ ] `npm run build`, `npm test` y `npm run lint` pasan
