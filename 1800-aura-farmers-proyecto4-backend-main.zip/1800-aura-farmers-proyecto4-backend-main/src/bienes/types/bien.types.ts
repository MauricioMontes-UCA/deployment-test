import type { Prisma } from '@PrismaClient';

/** Formatos de imagen aceptados para las fotos de un bien. */
export type FormatoFoto = 'jpg' | 'png' | 'webp';

/**
 * Foto ya validada, lista para guardarse.
 *
 * `FotosBienPipe` la arma a partir del archivo de multer. El servicio y el
 * almacenamiento trabajan con este tipo y no con `Express.Multer.File`, así no
 * dependen de cómo llegó el archivo por HTTP.
 */
export interface FotoSubida {
  buffer: Buffer;
  /** Formato detectado por el contenido del archivo, no por su extensión. */
  formato: FormatoFoto;
}

/** Bien con sus fotos ordenadas, tal como lo devuelve `BienRepository`. */
export type BienConFotos = Prisma.BienGetPayload<{ include: { fotos: true } }>;
