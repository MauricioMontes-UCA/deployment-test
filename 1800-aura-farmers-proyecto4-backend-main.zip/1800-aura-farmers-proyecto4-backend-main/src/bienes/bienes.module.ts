import { Module } from '@nestjs/common';
import {
  BienesController,
  BienesPublicosController,
  BienesResenasController,
  DisponibilidadController,
} from '@Bienes/controllers';
import {
  BienesService,
  DisponibilidadService,
  FotoStorageService,
} from '@Bienes/services';
import { BienRepository, DisponibilidadRepository } from '@Bienes/repositories';
import { ResenasModule } from '@Resenas';

@Module({
  // ResenasModule es el dueño de la calificación; la dependencia va solo en
  // este sentido (bienes → reseñas) para no crear un ciclo de módulos.
  imports: [ResenasModule],
  controllers: [
    BienesController,
    BienesPublicosController,
    BienesResenasController,
    DisponibilidadController,
  ],
  providers: [
    BienesService,
    FotoStorageService,
    DisponibilidadService,
    BienRepository,
    DisponibilidadRepository,
  ],
  // El repositorio se exporta para que otros módulos (reservas, búsqueda)
  // reutilicen el acceso a datos de bienes, igual que UsersModule.
  exports: [BienesService, DisponibilidadService, BienRepository],
})
export class BienesModule {}
