import {
  BadRequestException,
  InternalServerErrorException,
  NotFoundException,
} from '@nestjs/common';
import { FotoNoGuardadaError } from '@Bienes/errors';
import { BienesService, PUBLICACION_NO_DISPONIBLE } from './bienes.service.js';
import type { CreateBienDto } from '@Bienes/dto';
import type {
  BienDetalle,
  BienRepository,
  CreateBienData,
} from '@Bienes/repositories';
import type { FotoSubida } from '@Bienes/types';
import type { ResenasService } from '@Resenas/services';
import type { FotoStorageService } from './foto-storage.service.js';

const ARRENDADOR_ID = '11111111-1111-4111-8111-111111111111';

/** Los campos del DTO como objeto plano, para poder copiarlo con spread. */
type DatosBien = Pick<CreateBienDto, keyof CreateBienDto>;

const dto: DatosBien = {
  tipo: 'PROPIEDAD',
  categoria: 'Salón de eventos',
  titulo: 'Salón de eventos Las Palmas',
  descripcion: 'Salón climatizado con cocina y parqueo.',
  precio: 80,
  unidadCobro: 'DIA',
  departamento: 'San Salvador',
  municipio: 'San Salvador',
};

function fotos(cantidad: number): FotoSubida[] {
  return Array.from({ length: cantidad }, () => ({
    buffer: Buffer.from('foto'),
    formato: 'jpg' as const,
  }));
}

/** Arma el servicio con dobles del repositorio y del almacenamiento. */
function crearServicio({ falla }: { falla?: number } = {}) {
  const guardar = vi.fn((bienId: string, orden: number) =>
    orden === falla
      ? Promise.reject(new FotoNoGuardadaError(bienId, orden))
      : Promise.resolve(`/uploads/bienes/${bienId}/${orden}.jpg`),
  );
  const eliminar = vi.fn().mockResolvedValue(undefined);
  const create = vi.fn((data: CreateBienData) =>
    Promise.resolve({ ...data, fotos: data.fotos }),
  );

  const service = new BienesService(
    { create } as unknown as BienRepository,
    { guardar, eliminar } as unknown as FotoStorageService,
    {} as ResenasService,
  );
  const datosCreados = () => create.mock.calls[0]![0];
  return { service, guardar, eliminar, create, datosCreados };
}

describe('BienesService.create', () => {
  it('guarda las fotos en orden y crea el bien con ellas', async () => {
    const { service, guardar, eliminar, datosCreados } = crearServicio();

    await service.create(ARRENDADOR_ID, dto, fotos(3));

    const bienId = guardar.mock.calls[0]![0];
    expect(guardar.mock.calls.map(([id, orden]) => [id, orden])).toEqual([
      [bienId, 1],
      [bienId, 2],
      [bienId, 3],
    ]);
    expect(datosCreados()).toMatchObject({
      ...dto,
      id: bienId,
      arrendadorId: ARRENDADOR_ID,
    });
    expect(datosCreados().fotos).toEqual([
      { url: `/uploads/bienes/${bienId}/1.jpg`, orden: 1, esPrincipal: true },
      { url: `/uploads/bienes/${bienId}/2.jpg`, orden: 2, esPrincipal: false },
      { url: `/uploads/bienes/${bienId}/3.jpg`, orden: 3, esPrincipal: false },
    ]);
    expect(eliminar).not.toHaveBeenCalled();
  });

  it('toma el arrendador del parámetro aunque el DTO traiga otro', async () => {
    const { service, datosCreados } = crearServicio();
    const conIntruso = { ...dto, arrendadorId: 'otro' } as DatosBien;

    await service.create(ARRENDADOR_ID, conIntruso, fotos(1));

    expect(datosCreados().arrendadorId).toBe(ARRENDADOR_ID);
  });

  it('marca como principal la foto de indicePrincipal', async () => {
    const { service, datosCreados } = crearServicio();

    await service.create(
      ARRENDADOR_ID,
      { ...dto, indicePrincipal: 2 },
      fotos(3),
    );

    expect(datosCreados().fotos.map((f) => f.esPrincipal)).toEqual([
      false,
      false,
      true,
    ]);
    expect(datosCreados()).not.toHaveProperty('indicePrincipal');
  });

  it('rechaza un indicePrincipal sin foto y no guarda nada', async () => {
    const { service, guardar, create } = crearServicio();

    await expect(
      service.create(ARRENDADOR_ID, { ...dto, indicePrincipal: 3 }, fotos(3)),
    ).rejects.toThrow(BadRequestException);
    expect(guardar).not.toHaveBeenCalled();
    expect(create).not.toHaveBeenCalled();
  });

  it('si falla la tercera foto no crea el bien y borra las ya guardadas', async () => {
    const { service, guardar, eliminar, create } = crearServicio({ falla: 3 });

    await expect(service.create(ARRENDADOR_ID, dto, fotos(5))).rejects.toThrow(
      InternalServerErrorException,
    );

    expect(guardar).toHaveBeenCalledTimes(3);
    expect(create).not.toHaveBeenCalled();
    expect(eliminar).toHaveBeenCalledWith(guardar.mock.calls[0]![0]);
  });

  it('si falla la base borra las fotos y propaga el error', async () => {
    const { service, guardar, eliminar, create } = crearServicio();
    const error = new Error('conexión perdida');
    create.mockRejectedValueOnce(error);

    await expect(service.create(ARRENDADOR_ID, dto, fotos(2))).rejects.toBe(
      error,
    );
    expect(eliminar).toHaveBeenCalledWith(guardar.mock.calls[0]![0]);
  });

  it('usa un id nuevo en cada publicación', async () => {
    const { service, guardar } = crearServicio();

    await service.create(ARRENDADOR_ID, dto, fotos(1));
    await service.create(ARRENDADOR_ID, dto, fotos(1));

    expect(guardar.mock.calls[0]![0]).not.toBe(guardar.mock.calls[1]![0]);
  });
});

describe('BienesService.findDetalle', () => {
  const BIEN_ID = '7c9e6679-7425-40de-944b-e07fc1f90ae7';

  function crearConDetalle(
    resultado: BienDetalle | null,
    calificacion: { promedio: number | null; totalResenas: number } = {
      promedio: null,
      totalResenas: 0,
    },
  ) {
    const findActivoConDetalle = vi.fn().mockResolvedValue(resultado);
    const calificacionDeBien = vi.fn().mockResolvedValue(calificacion);
    const service = new BienesService(
      { findActivoConDetalle } as unknown as BienRepository,
      {} as FotoStorageService,
      { calificacionDeBien } as unknown as ResenasService,
    );
    return { service, findActivoConDetalle, calificacionDeBien };
  }

  it('devuelve el detalle del repositorio con la calificación de reseñas', async () => {
    const detalle = { id: BIEN_ID } as BienDetalle;
    const { service, findActivoConDetalle, calificacionDeBien } =
      crearConDetalle(detalle, { promedio: 4.5, totalResenas: 2 });

    await expect(service.findDetalle(BIEN_ID)).resolves.toEqual({
      id: BIEN_ID,
      calificacion: { promedio: 4.5, totalResenas: 2 },
    });
    expect(findActivoConDetalle).toHaveBeenCalledWith(BIEN_ID);
    expect(calificacionDeBien).toHaveBeenCalledWith(BIEN_ID);
  });

  it('conserva promedio null y total 0 si no hay reseñas', async () => {
    const { service } = crearConDetalle({} as BienDetalle);

    expect((await service.findDetalle(BIEN_ID)).calificacion).toEqual({
      promedio: null,
      totalResenas: 0,
    });
  });

  it('responde 404 con el mensaje acordado si no hay bien activo', async () => {
    const { service } = crearConDetalle(null);

    const error = await service.findDetalle(BIEN_ID).catch((e: unknown) => e);

    expect(error).toBeInstanceOf(NotFoundException);
    expect((error as NotFoundException).getResponse()).toEqual({
      message: PUBLICACION_NO_DISPONIBLE,
      error: 'Not Found',
      statusCode: 404,
    });
  });
});

describe('BienesService.verificarPublicado', () => {
  const crear = (publicado: boolean) =>
    new BienesService(
      {
        estaPublicado: vi.fn().mockResolvedValue(publicado),
      } as unknown as BienRepository,
      {} as FotoStorageService,
      {} as ResenasService,
    );

  it('no falla si el bien está publicado', async () => {
    await expect(crear(true).verificarPublicado('id')).resolves.toBeUndefined();
  });

  it('responde 404 con el mensaje de publicación no disponible', async () => {
    await expect(crear(false).verificarPublicado('id')).rejects.toThrow(
      PUBLICACION_NO_DISPONIBLE,
    );
  });
});
