import { randomUUID } from 'node:crypto';
import {
  BadRequestException,
  Injectable,
  InternalServerErrorException,
  NotFoundException,
} from '@nestjs/common';
import {
  BienRepository,
  type MiBien,
  type PaginaDeBienes,
} from '@Bienes/repositories';
import { MIS_BIENES_POR_PAGINA } from '@Bienes/constants';
import { FotoNoGuardadaError } from '@Bienes/errors';
import { ResenasService } from '@Resenas/services';
import { hoyEn, parseDia, ZONA_HORARIA } from '@Bienes/utils';
import { FotoStorageService } from './foto-storage.service.js';
import type {
  BienDetalleConCalificacion,
  BuscarBienesQueryDto,
  ConsultarMisBienesDto,
  CreateBienDto,
} from '@Bienes/dto';
import type { BienConFotos, FotoSubida } from '@Bienes/types';

/**
 * Mismo mensaje para un bien inexistente, uno INACTIVA y uno de un arrendador
 * desactivado: no revela cuál es.
 */
export const PUBLICACION_NO_DISPONIBLE =
  'La publicación ya no está disponible.';

/**
 * Lógica de negocio de los bienes.
 *
 * No conoce Prisma: los datos pasan por BienRepository y los archivos por
 * FotoStorageService.
 */
@Injectable()
export class BienesService {
  constructor(
    private readonly bienRepository: BienRepository,
    private readonly fotoStorage: FotoStorageService,
    private readonly resenasService: ResenasService,
  ) {}

  /**
   * Publica un bien con sus fotos. Queda en estado ACTIVA.
   *
   * Primero escribe las fotos y después crea el bien con todas ellas en una
   * transacción. Si algo falla en cualquiera de los dos pasos, borra las fotos
   * ya escritas: no queda ni el bien ni archivos sueltos.
   *
   * @param arrendadorId viene del usuario autenticado, nunca del body.
   * @param fotos en el orden en que se mostrarán.
   */
  async create(
    arrendadorId: string,
    { indicePrincipal = 0, ...datos }: CreateBienDto,
    fotos: FotoSubida[],
  ): Promise<BienConFotos> {
    if (indicePrincipal >= fotos.length) {
      throw new BadRequestException([
        `El índice de la foto principal (${indicePrincipal}) no corresponde a ninguna foto: se subieron ${fotos.length} y el índice empieza en 0.`,
      ]);
    }

    // El id se genera acá y no en la base porque nombra la carpeta de las
    // fotos, que se escriben antes de insertar el bien.
    const bienId = randomUUID();

    try {
      // Una por una, para que al fallar una no queden escrituras en curso
      // mientras se borra la carpeta.
      const urls: string[] = [];
      for (const [indice, foto] of fotos.entries()) {
        urls.push(await this.fotoStorage.guardar(bienId, indice + 1, foto));
      }

      return await this.bienRepository.create({
        ...datos,
        id: bienId,
        arrendadorId,
        fotos: urls.map((url, indice) => ({
          url,
          orden: indice + 1,
          esPrincipal: indice === indicePrincipal,
        })),
      });
    } catch (error) {
      await this.fotoStorage.eliminar(bienId);

      if (error instanceof FotoNoGuardadaError) {
        throw new InternalServerErrorException(
          'No se pudieron guardar las fotos. Intenta publicar de nuevo.',
          { cause: error },
        );
      }
      throw error;
    }
  }

  /**
   * Detalle público de un bien publicado, con su calificación: promedio con un
   * decimal (null sin reseñas) y total de reseñas de tipo BIEN.
   *
   * @throws {NotFoundException} el bien no existe, está INACTIVA o su
   * arrendador está desactivado.
   */
  async findDetalle(id: string): Promise<BienDetalleConCalificacion> {
    // Independientes: se leen a la vez. Si el bien no se publica se descarta
    // la calificación, que es solo una consulta de agregado.
    const [bien, calificacion] = await Promise.all([
      this.bienRepository.findActivoConDetalle(id),
      this.resenasService.calificacionDeBien(id),
    ]);
    if (!bien) {
      throw new NotFoundException(PUBLICACION_NO_DISPONIBLE);
    }
    return { ...bien, calificacion };
  }

  /**
   * Comprueba que el bien tenga publicación visible.
   * @throws {NotFoundException} mismo criterio y mensaje que el detalle.
   */
  async verificarPublicado(id: string): Promise<void> {
    if (!(await this.bienRepository.estaPublicado(id))) {
      throw new NotFoundException(PUBLICACION_NO_DISPONIBLE);
    }
  }

  /**
   * Los bienes publicados por el arrendador, ACTIVA e INACTIVA, de a
   * `MIS_BIENES_POR_PAGINA` (BE-1.3). `arrendadorId` es siempre el usuario del
   * token. Una página posterior a la última devuelve `bienes` vacío, con el
   * `total` real y `hayMas` en false.
   */
  async listarMios(
    arrendadorId: string,
    { pagina }: ConsultarMisBienesDto,
  ): Promise<{
    bienes: MiBien[];
    pagina: number;
    total: number;
    hayMas: boolean;
  }> {
    const limite = MIS_BIENES_POR_PAGINA;
    const { bienes, total } = await this.bienRepository.findMios(
      arrendadorId,
      (pagina - 1) * limite,
      limite,
    );

    return { bienes, pagina, total, hayMas: pagina * limite < total };
  }

  /**
   * Página de resultados de la búsqueda de bienes ACTIVA, con los filtros de
   * H4 combinados con AND. `total` ya cuenta solo los bienes filtrados.
   *
   * `hayMas` es verdadero si después de esta página quedan más resultados.
   *
   * @throws {BadRequestException} (con `message` como lista de un mensaje, igual
   * que los errores del DTO) precioMin mayor que precioMax, solo una de
   * las dos fechas, una fecha que no es un día real, fechaFin anterior a
   * fechaInicio o fechaInicio anterior a hoy.
   *
   * `ahora` se recibe para poder probar la regla "no anterior a hoy".
   */
  async buscar(
    {
      q,
      departamento,
      municipio,
      precioMin,
      precioMax,
      tipo,
      categoria,
      capacidadMin,
      fechaInicio,
      fechaFin,
      pagina,
      tamano,
    }: BuscarBienesQueryDto,
    ahora: Date = new Date(),
  ): Promise<
    PaginaDeBienes & { pagina: number; tamano: number; hayMas: boolean }
  > {
    if (
      precioMin !== undefined &&
      precioMax !== undefined &&
      precioMin > precioMax
    ) {
      throw new BadRequestException([
        'El precio mínimo no puede ser mayor que el precio máximo.',
      ]);
    }
    const periodo = this.validarPeriodo(fechaInicio, fechaFin, ahora);

    const { total, resultados } = await this.bienRepository.buscar(
      {
        q,
        departamento,
        municipio,
        precioMin,
        precioMax,
        tipo,
        categoria,
        capacidadMin,
        periodo,
      },
      tamano,
      (pagina - 1) * tamano,
    );

    return {
      pagina,
      tamano,
      total,
      hayMas: pagina * tamano < total,
      resultados,
    };
  }

  /** El periodo de disponibilidad, o `undefined` si no se pidió. */
  private validarPeriodo(
    fechaInicio: string | undefined,
    fechaFin: string | undefined,
    ahora: Date,
  ): { fechaInicio: string; fechaFin: string } | undefined {
    if (fechaInicio === undefined && fechaFin === undefined) return undefined;
    if (fechaInicio === undefined || fechaFin === undefined) {
      throw new BadRequestException([
        'Para filtrar por disponibilidad indica la fecha de inicio y la fecha de fin.',
      ]);
    }

    const inicio = parseDia(fechaInicio);
    if (!inicio) {
      throw new BadRequestException([
        'La fecha de inicio no es un día válido.',
      ]);
    }
    const fin = parseDia(fechaFin);
    if (!fin) {
      throw new BadRequestException(['La fecha de fin no es un día válido.']);
    }
    if (fin < inicio) {
      throw new BadRequestException([
        'La fecha de fin no puede ser anterior a la fecha de inicio.',
      ]);
    }
    if (inicio < hoyEn(ZONA_HORARIA, ahora)) {
      throw new BadRequestException([
        'La fecha de inicio no puede ser anterior a hoy.',
      ]);
    }
    return { fechaInicio, fechaFin };
  }
}
