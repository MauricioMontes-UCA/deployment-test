import { BadRequestException, NotFoundException } from '@nestjs/common';
import { DisponibilidadService } from './disponibilidad.service.js';
import type {
  BienRepository,
  DisponibilidadRepository,
} from '@Bienes/repositories';

const BIEN_ID = '7c9e6679-7425-40de-944b-e07fc1f90ae7';
// 03:00 UTC del 13 de noviembre = 12 de noviembre, 21:00 en El Salvador.
const AHORA = new Date('2026-11-13T03:00:00.000Z');

const dia = (valor: string) => new Date(`${valor}T00:00:00.000Z`);

function crear({ existe = true } = {}) {
  const ocupados = {
    reservados: [
      { fechaInicio: dia('2026-12-10'), fechaFin: dia('2026-12-12') },
    ],
    bloqueados: [
      { fechaInicio: dia('2026-12-20'), fechaFin: dia('2026-12-25') },
    ],
  };
  const bienRepository = {
    existsActive: vi.fn().mockResolvedValue(existe),
  };
  const disponibilidadRepository = {
    findOcupados: vi.fn().mockResolvedValue(ocupados),
  };
  const service = new DisponibilidadService(
    bienRepository as unknown as BienRepository,
    disponibilidadRepository as unknown as DisponibilidadRepository,
  );
  return { service, bienRepository, disponibilidadRepository, ocupados };
}

describe('DisponibilidadService.consultar', () => {
  it('devuelve el bien con sus reservados y bloqueados', async () => {
    const { service, ocupados, disponibilidadRepository } = crear();

    const resultado = await service.consultar(
      BIEN_ID,
      { desde: '2026-11-01', hasta: '2027-10-31' },
      AHORA,
    );

    expect(resultado).toEqual({ bienId: BIEN_ID, ...ocupados });
    expect(disponibilidadRepository.findOcupados).toHaveBeenCalledWith(
      BIEN_ID,
      dia('2026-11-01'),
      dia('2027-10-31'),
    );
  });

  it('sin fechas usa hoy (día de El Salvador) y una ventana de 12 meses', async () => {
    const { service, disponibilidadRepository } = crear();

    await service.consultar(BIEN_ID, {}, AHORA);

    expect(disponibilidadRepository.findOcupados).toHaveBeenCalledWith(
      BIEN_ID,
      dia('2026-11-12'),
      dia('2027-11-11'),
    );
  });

  it('con solo `desde`, `hasta` cierra la ventana de 12 meses', async () => {
    const { service, disponibilidadRepository } = crear();

    await service.consultar(BIEN_ID, { desde: '2026-11-01' }, AHORA);

    expect(disponibilidadRepository.findOcupados).toHaveBeenCalledWith(
      BIEN_ID,
      dia('2026-11-01'),
      dia('2027-10-31'),
    );
  });

  it('acepta una ventana de exactamente 12 meses y rechaza un día más', async () => {
    const { service } = crear();

    await expect(
      service.consultar(
        BIEN_ID,
        { desde: '2026-11-01', hasta: '2027-10-31' },
        AHORA,
      ),
    ).resolves.toBeDefined();
    await expect(
      service.consultar(
        BIEN_ID,
        { desde: '2026-11-01', hasta: '2027-11-01' },
        AHORA,
      ),
    ).rejects.toThrow(BadRequestException);
  });

  it.each([
    ['desde no es un día real', { desde: '2026-02-30' }],
    ['hasta no es un día real', { hasta: '2026-13-01' }],
    ['hasta es anterior a desde', { desde: '2026-12-10', hasta: '2026-12-09' }],
    [
      'la ventana pasa de 12 meses',
      { desde: '2026-01-01', hasta: '2028-01-01' },
    ],
  ])('responde 400 si %s', async (_caso, query) => {
    const { service, bienRepository } = crear();

    await expect(service.consultar(BIEN_ID, query, AHORA)).rejects.toThrow(
      BadRequestException,
    );
    // Valida las fechas antes de tocar la base.
    expect(bienRepository.existsActive).not.toHaveBeenCalled();
  });

  it('responde 404 si el bien no existe o no está activo', async () => {
    const { service, disponibilidadRepository } = crear({ existe: false });

    await expect(service.consultar(BIEN_ID, {}, AHORA)).rejects.toThrow(
      NotFoundException,
    );
    expect(disponibilidadRepository.findOcupados).not.toHaveBeenCalled();
  });
});
