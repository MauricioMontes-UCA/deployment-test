import { BienesService } from './bienes.service.js';
import type { BuscarBienesQueryDto } from '@Bienes/dto';
import type { BienRepository } from '@Bienes/repositories';
import type { ResenasService } from '@Resenas/services';
import type { FotoStorageService } from './foto-storage.service.js';

function crearServicio(total: number) {
  const buscar = vi.fn().mockResolvedValue({ total, resultados: [] });
  const service = new BienesService(
    { buscar } as unknown as BienRepository,
    {} as FotoStorageService,
    {} as ResenasService,
  );
  return { service, buscar };
}

const consulta = (parcial: Partial<BuscarBienesQueryDto> = {}) =>
  ({ pagina: 1, tamano: 20, ...parcial }) as BuscarBienesQueryDto;

describe('BienesService.buscar', () => {
  it('pasa los filtros y calcula el desplazamiento de la página', async () => {
    const { service, buscar } = crearServicio(100);

    await service.buscar(
      consulta({
        q: 'salon',
        departamento: 'San Salvador',
        municipio: 'Mejicanos',
        pagina: 3,
        tamano: 10,
      }),
    );

    expect(buscar).toHaveBeenCalledWith(
      { q: 'salon', departamento: 'San Salvador', municipio: 'Mejicanos' },
      10,
      20,
    );
  });

  it('la página 1 no se desplaza', async () => {
    const { service, buscar } = crearServicio(5);

    await service.buscar(consulta());

    expect(buscar).toHaveBeenCalledWith({}, 20, 0);
  });

  it.each([
    // [total, pagina, tamano, hayMas]
    [45, 1, 20, true],
    [45, 2, 20, true],
    [45, 3, 20, false],
    [40, 2, 20, false],
    [41, 2, 20, true],
    [20, 1, 20, false],
    [0, 1, 20, false],
    [45, 9, 20, false],
  ])(
    'con %i resultados, página %i de %i: hayMas = %s',
    async (total, pagina, tamano, hayMas) => {
      const { service } = crearServicio(total);

      const res = await service.buscar(consulta({ pagina, tamano }));

      expect(res).toMatchObject({ total, pagina, tamano, hayMas });
    },
  );
});
