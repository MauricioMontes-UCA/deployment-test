import {
  BadRequestException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import {
  BienRepository,
  DisponibilidadRepository,
  type Disponibilidad,
} from '@Bienes/repositories';
import {
  hoyEn,
  parseDia,
  ultimoDiaDeVentana,
  ZONA_HORARIA,
} from '@Bienes/utils';
import type { ConsultaDisponibilidadDto } from '@Bienes/dto';

/** Ventana máxima de consulta, en meses. */
export const VENTANA_MAXIMA_MESES = 12;

/**
 * Disponibilidad de un bien: reservas que ocupan días y bloqueos de fechas.
 *
 * No conoce Prisma: todo el acceso a datos pasa por los repositorios.
 */
@Injectable()
export class DisponibilidadService {
  constructor(
    private readonly bienRepository: BienRepository,
    private readonly disponibilidadRepository: DisponibilidadRepository,
  ) {}

  /**
   * @throws {BadRequestException} fechas inválidas, `desde` > `hasta` o ventana
   * mayor a 12 meses.
   * @throws {NotFoundException} el bien no existe o no está activo.
   *
   * `ahora` se recibe para poder probar el valor por defecto de `desde`.
   */
  async consultar(
    bienId: string,
    { desde, hasta }: ConsultaDisponibilidadDto,
    ahora: Date = new Date(),
  ): Promise<Disponibilidad> {
    const inicio =
      desde === undefined
        ? hoyEn(ZONA_HORARIA, ahora)
        : this.parsear('desde', desde);
    const fin =
      hasta === undefined
        ? ultimoDiaDeVentana(inicio, VENTANA_MAXIMA_MESES)
        : this.parsear('hasta', hasta);

    if (fin < inicio) {
      throw new BadRequestException('`hasta` no puede ser anterior a `desde`.');
    }
    if (fin > ultimoDiaDeVentana(inicio, VENTANA_MAXIMA_MESES)) {
      throw new BadRequestException(
        `La ventana de consulta no puede superar ${VENTANA_MAXIMA_MESES} meses.`,
      );
    }

    if (!(await this.bienRepository.existsActive(bienId))) {
      throw new NotFoundException('El bien no existe.');
    }

    const ocupados = await this.disponibilidadRepository.findOcupados(
      bienId,
      inicio,
      fin,
    );
    return { bienId, ...ocupados };
  }

  private parsear(campo: string, valor: string): Date {
    const fecha = parseDia(valor);
    if (!fecha) {
      throw new BadRequestException(
        `\`${campo}\` no es una fecha válida (YYYY-MM-DD).`,
      );
    }
    return fecha;
  }
}
