import { BadRequestException } from '@nestjs/common';
import { BienesService } from './bienes.service.js';
import type { BuscarBienesQueryDto } from '@Bienes/dto';
import type { BienRepository } from '@Bienes/repositories';
import type { ResenasService } from '@Resenas/services';
import type { FotoStorageService } from './foto-storage.service.js';

// 2026-11-15 18:00 en El Salvador (UTC-6) ya es 2026-11-16 en UTC.
const AHORA = new Date('2026-11-16T00:00:00.000Z');

function crearServicio() {
  const buscar = vi.fn().mockResolvedValue({ total: 0, resultados: [] });
  const service = new BienesService(
    { buscar } as unknown as BienRepository,
    {} as FotoStorageService,
    {} as ResenasService,
  );
  return { service, buscar };
}

const consulta = (parcial: Partial<BuscarBienesQueryDto> = {}) =>
  ({ pagina: 1, tamano: 20, ...parcial }) as BuscarBienesQueryDto;

describe('BienesService.buscar: filtros de H4', () => {
  it('pasa todos los filtros al repositorio, con el periodo', async () => {
    const { service, buscar } = crearServicio();

    await service.buscar(
      consulta({
        precioMin: 20,
        precioMax: 100,
        tipo: 'PROPIEDAD',
        categoria: 'Salón de eventos',
        capacidadMin: 50,
        fechaInicio: '2026-11-20',
        fechaFin: '2026-11-22',
      }),
      AHORA,
    );

    expect(buscar).toHaveBeenCalledWith(
      expect.objectContaining({
        precioMin: 20,
        precioMax: 100,
        tipo: 'PROPIEDAD',
        categoria: 'Salón de eventos',
        capacidadMin: 50,
        periodo: { fechaInicio: '2026-11-20', fechaFin: '2026-11-22' },
      }),
      20,
      0,
    );
  });

  it('sin fechas no filtra por disponibilidad', async () => {
    const { service, buscar } = crearServicio();
    await service.buscar(consulta(), AHORA);
    expect(buscar.mock.calls[0][0].periodo).toBeUndefined();
  });

  it('acepta precioMin igual a precioMax', async () => {
    const { service } = crearServicio();
    await expect(
      service.buscar(consulta({ precioMin: 50, precioMax: 50 }), AHORA),
    ).resolves.toBeDefined();
  });

  it('acepta un periodo de un solo día que empieza hoy en El Salvador', async () => {
    const { service } = crearServicio();
    await expect(
      service.buscar(
        consulta({ fechaInicio: '2026-11-15', fechaFin: '2026-11-15' }),
        AHORA,
      ),
    ).resolves.toBeDefined();
  });

  it.each([
    [
      'precioMin mayor que precioMax',
      { precioMin: 100, precioMax: 20 },
      'El precio mínimo no puede ser mayor que el precio máximo.',
    ],
    [
      'solo la fecha de inicio',
      { fechaInicio: '2026-11-20' },
      'Para filtrar por disponibilidad indica la fecha de inicio y la fecha de fin.',
    ],
    [
      'solo la fecha de fin',
      { fechaFin: '2026-11-22' },
      'Para filtrar por disponibilidad indica la fecha de inicio y la fecha de fin.',
    ],
    [
      'una fecha de inicio que no existe',
      { fechaInicio: '2026-02-30', fechaFin: '2026-03-02' },
      'La fecha de inicio no es un día válido.',
    ],
    [
      'una fecha de fin que no existe',
      { fechaInicio: '2026-11-20', fechaFin: '2026-11-31' },
      'La fecha de fin no es un día válido.',
    ],
    [
      'fechaFin anterior a fechaInicio',
      { fechaInicio: '2026-11-22', fechaFin: '2026-11-20' },
      'La fecha de fin no puede ser anterior a la fecha de inicio.',
    ],
    [
      'fechaInicio de ayer en El Salvador',
      { fechaInicio: '2026-11-14', fechaFin: '2026-11-20' },
      'La fecha de inicio no puede ser anterior a hoy.',
    ],
  ])('rechaza %s con 400', async (_caso, filtros, mensaje) => {
    const { service, buscar } = crearServicio();

    const error = await service
      .buscar(consulta(filtros as Partial<BuscarBienesQueryDto>), AHORA)
      .catch((e: unknown) => e);

    expect(error).toBeInstanceOf(BadRequestException);
    // Lista de mensajes, igual que los errores del DTO.
    expect((error as BadRequestException).getResponse()).toMatchObject({
      message: [mensaje],
    });
    expect(buscar).not.toHaveBeenCalled();
  });
});
