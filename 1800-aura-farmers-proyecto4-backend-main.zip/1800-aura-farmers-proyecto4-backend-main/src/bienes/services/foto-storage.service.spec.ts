import { mkdtemp, readFile, readdir, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { FotoNoGuardadaError } from '@Bienes/errors';
import { FotoStorageService } from './foto-storage.service.js';
import type { ConfigService } from '@nestjs/config';
import type { FotoSubida } from '@Bienes/types';

const BIEN_ID = '7c9e6679-7425-40de-944b-e07fc1f90ae7';
const foto: FotoSubida = { buffer: Buffer.from('contenido'), formato: 'webp' };

describe('FotoStorageService', () => {
  let uploads: string;
  let storage: FotoStorageService;

  beforeEach(async () => {
    uploads = await mkdtemp(path.join(tmpdir(), 'uploads-'));
    const config = { get: () => uploads } as unknown as ConfigService<
      never,
      true
    >;
    storage = new FotoStorageService(config);
  });

  afterEach(async () => {
    await rm(uploads, { recursive: true, force: true });
  });

  it('escribe la foto en la carpeta del bien y devuelve su URL pública', async () => {
    const url = await storage.guardar(BIEN_ID, 1, foto);

    expect(url).toBe(`/uploads/bienes/${BIEN_ID}/1.webp`);
    const escrita = await readFile(
      path.join(uploads, 'bienes', BIEN_ID, '1.webp'),
    );
    expect(escrita.equals(foto.buffer)).toBe(true);
  });

  it('no pisa una foto que ya existe', async () => {
    await storage.guardar(BIEN_ID, 1, foto);

    await expect(storage.guardar(BIEN_ID, 1, foto)).rejects.toThrow(
      FotoNoGuardadaError,
    );
  });

  it('lanza FotoNoGuardadaError si no puede escribir', async () => {
    // Un archivo en el lugar de la carpeta "bienes" hace fallar el mkdir.
    await writeFile(path.join(uploads, 'bienes'), '');

    await expect(storage.guardar(BIEN_ID, 1, foto)).rejects.toThrow(
      FotoNoGuardadaError,
    );
  });

  it('eliminar borra todas las fotos del bien y nada más', async () => {
    const otroBien = '00000000-0000-4000-8000-000000000001';
    await storage.guardar(BIEN_ID, 1, foto);
    await storage.guardar(BIEN_ID, 2, foto);
    await storage.guardar(otroBien, 1, foto);

    await storage.eliminar(BIEN_ID);

    expect(await readdir(path.join(uploads, 'bienes'))).toEqual([otroBien]);
  });

  it('eliminar no falla si el bien no tiene fotos', async () => {
    await expect(storage.eliminar(BIEN_ID)).resolves.toBeUndefined();
  });
});
