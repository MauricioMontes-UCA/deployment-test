import { BienesService } from './bienes.service.js';
import type { ConsultarMisBienesDto } from '@Bienes/dto';
import type { BienRepository, MiBien } from '@Bienes/repositories';
import type { ResenasService } from '@Resenas/services';
import type { FotoStorageService } from './foto-storage.service.js';

const ARRENDADOR_ID = '11111111-1111-4111-8111-111111111111';

function crearServicio(total: number, bienes: MiBien[] = []) {
  const findMios = vi.fn().mockResolvedValue({ bienes, total });
  const service = new BienesService(
    { findMios } as unknown as BienRepository,
    {} as FotoStorageService,
    {} as ResenasService,
  );
  return { service, findMios };
}

const consulta = (pagina: number) => ({ pagina }) as ConsultarMisBienesDto;

describe('BienesService.listarMios', () => {
  it('pide al repositorio los bienes del arrendador de la sesión, 20 por página', async () => {
    const { service, findMios } = crearServicio(5);

    await service.listarMios(ARRENDADOR_ID, consulta(1));

    expect(findMios).toHaveBeenCalledWith(ARRENDADOR_ID, 0, 20);
  });

  it.each([
    [1, 0],
    [2, 20],
    [3, 40],
    [10_000, 199_980],
  ])('la página %i salta %i bienes', async (pagina, salto) => {
    const { service, findMios } = crearServicio(0);

    await service.listarMios(ARRENDADOR_ID, consulta(pagina));

    expect(findMios).toHaveBeenCalledWith(ARRENDADOR_ID, salto, 20);
  });

  it('devuelve los bienes, la página y el total', async () => {
    const bienes = [{ id: 'a' }, { id: 'b' }] as MiBien[];
    const { service } = crearServicio(2, bienes);

    const resultado = await service.listarMios(ARRENDADOR_ID, consulta(1));

    expect(resultado).toEqual({ bienes, pagina: 1, total: 2, hayMas: false });
  });

  it.each([
    [0, 1, false], // sin bienes
    [19, 1, false],
    [20, 1, false], // exactamente una página
    [21, 1, true],
    [21, 2, false], // la última página
    [40, 2, false],
    [41, 2, true],
    [25, 3, false], // página posterior a la última
  ])(
    'con total %i en la página %i, hayMas es %s',
    async (total, pagina, hayMas) => {
      const { service } = crearServicio(total);

      const resultado = await service.listarMios(
        ARRENDADOR_ID,
        consulta(pagina),
      );

      expect(resultado.hayMas).toBe(hayMas);
      expect(resultado.total).toBe(total);
      expect(resultado.pagina).toBe(pagina);
    },
  );
});
