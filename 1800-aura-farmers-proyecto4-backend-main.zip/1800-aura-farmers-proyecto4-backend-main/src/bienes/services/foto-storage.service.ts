import { mkdir, rm, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { FotoNoGuardadaError } from '@Bienes/errors';
import { UPLOADS_URL_PREFIX, type EnvConfig } from '@Config';
import type { FotoSubida } from '@Bienes/types';

/** Subcarpeta de `UPLOADS_DIR` (y de la URL pública) para las fotos de bienes. */
const CARPETA_BIENES = 'bienes';

/**
 * Guarda las fotos de los bienes en disco.
 *
 * Cada bien tiene su carpeta, `<UPLOADS_DIR>/bienes/<bienId>/`, y cada foto se
 * llama por su orden: `1.jpg`, `2.webp`... Así borrar las fotos de un bien es
 * borrar una carpeta. El `bienId` lo genera el servidor, nunca el cliente, por
 * lo que no puede usarse para escribir fuera de esa carpeta.
 */
@Injectable()
export class FotoStorageService {
  private readonly logger = new Logger(FotoStorageService.name);
  private readonly directorioBienes: string;

  constructor(configService: ConfigService<EnvConfig, true>) {
    this.directorioBienes = path.resolve(
      configService.get('UPLOADS_DIR', { infer: true }),
      CARPETA_BIENES,
    );
  }

  /**
   * Escribe una foto y devuelve la URL pública con la que se sirve.
   *
   * @throws {FotoNoGuardadaError} si no se pudo escribir el archivo.
   */
  async guardar(
    bienId: string,
    orden: number,
    foto: FotoSubida,
  ): Promise<string> {
    const nombre = `${orden}.${foto.formato}`;
    const carpeta = path.join(this.directorioBienes, bienId);

    try {
      await mkdir(carpeta, { recursive: true });
      // `wx` falla si el archivo ya existe en vez de pisar la foto de otro bien.
      await writeFile(path.join(carpeta, nombre), foto.buffer, { flag: 'wx' });
    } catch (error) {
      throw new FotoNoGuardadaError(bienId, orden, { cause: error });
    }

    return `${UPLOADS_URL_PREFIX}/${CARPETA_BIENES}/${bienId}/${nombre}`;
  }

  /**
   * Borra todas las fotos de un bien.
   *
   * No lanza: se usa para limpiar después de otro error, y un fallo acá no
   * debe tapar ese error. Si no puede borrar, lo deja en el log.
   */
  async eliminar(bienId: string): Promise<void> {
    try {
      await rm(path.join(this.directorioBienes, bienId), {
        recursive: true,
        force: true,
      });
    } catch (error) {
      this.logger.error(
        `No se pudieron borrar las fotos del bien ${bienId}.`,
        error instanceof Error ? error.stack : String(error),
      );
    }
  }
}
