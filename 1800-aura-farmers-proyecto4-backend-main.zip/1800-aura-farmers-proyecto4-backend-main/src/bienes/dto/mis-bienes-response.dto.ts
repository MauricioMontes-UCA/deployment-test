import { ApiProperty } from '@nestjs/swagger';
import { EstadoBien, TipoBien, UnidadCobro } from '@PrismaClient';
import type { MiBien } from '@Bienes/repositories';

/** Un bien en «Mis bienes» (BE-1.3). */
export class MiBienResponseDto {
  @ApiProperty({ format: 'uuid' })
  id!: string;

  @ApiProperty({ example: 'Salón de eventos Las Palmas' })
  titulo!: string;

  @ApiProperty({ enum: TipoBien, enumName: 'TipoBien' })
  tipo!: TipoBien;

  @ApiProperty({ example: 'Salón de eventos' })
  categoria!: string;

  @ApiProperty({
    enum: EstadoBien,
    enumName: 'EstadoBien',
    description: 'También se listan los bienes INACTIVA.',
  })
  estado!: EstadoBien;

  @ApiProperty({ example: 80 })
  precio!: number;

  @ApiProperty({ enum: UnidadCobro, enumName: 'UnidadCobro' })
  unidadCobro!: UnidadCobro;

  @ApiProperty({ example: 25 })
  deposito!: number;

  @ApiProperty({ example: 'San Salvador' })
  departamento!: string;

  @ApiProperty({ example: 'San Salvador' })
  municipio!: string;

  @ApiProperty({
    type: String,
    nullable: true,
    example: '/uploads/bienes/7c9e6679-7425-40de-944b-e07fc1f90ae7/1.webp',
    description: 'URL de la foto principal; null si el bien no tiene fotos.',
  })
  fotoPrincipalUrl!: string | null;

  @ApiProperty({
    example: false,
    description:
      'Valor de «Solo usuarios verificados» (H19). false si el bien nunca configuró la política.',
  })
  soloVerificados!: boolean;

  @ApiProperty({ type: String, format: 'date-time' })
  creadoEn!: Date;

  static fromEntity(bien: MiBien): MiBienResponseDto {
    return {
      id: bien.id,
      titulo: bien.titulo,
      tipo: bien.tipo,
      categoria: bien.categoria,
      estado: bien.estado,
      // Prisma devuelve DECIMAL como Decimal; la API lo expone como número.
      precio: bien.precio.toNumber(),
      unidadCobro: bien.unidadCobro,
      deposito: bien.deposito.toNumber(),
      departamento: bien.departamento,
      municipio: bien.municipio,
      fotoPrincipalUrl: bien.fotos[0]?.url ?? null,
      soloVerificados: bien.politicaVerificacion?.soloVerificados ?? false,
      creadoEn: bien.creadoEn,
    };
  }
}

/** Página de `GET /bienes/mios` (BE-1.3). */
export class MisBienesResponseDto {
  @ApiProperty({ type: [MiBienResponseDto] })
  items!: MiBienResponseDto[];

  @ApiProperty({ example: 1, description: 'Página solicitada.' })
  pagina!: number;

  @ApiProperty({
    example: 45,
    description: 'Bienes del arrendador, sin contar la paginación.',
  })
  total!: number;

  @ApiProperty({
    example: true,
    description: 'Si hay más bienes después de esta página.',
  })
  hayMas!: boolean;
}
