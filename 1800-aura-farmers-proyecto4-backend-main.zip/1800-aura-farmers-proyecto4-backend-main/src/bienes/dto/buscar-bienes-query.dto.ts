import { ApiPropertyOptional } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import {
  IsEnum,
  IsIn,
  IsInt,
  IsNumber,
  IsOptional,
  IsString,
  Matches,
  Max,
  MaxLength,
  Min,
} from 'class-validator';
import { TipoBien } from '@PrismaClient';
import {
  CAPACIDAD_MAXIMA_FILTRO,
  CATEGORIAS_POR_TIPO,
  MAX_LARGO_TEXTO_BUSQUEDA,
  PRECIO_MAXIMO_FILTRO,
  PAGINA_MAXIMA,
  TAMANO_PAGINA_MAXIMO,
  TAMANO_PAGINA_POR_DEFECTO,
} from '@Bienes/constants';

/** Postgres rechaza el carácter nulo en un texto y respondería 500. */
// oxlint-disable-next-line no-control-regex
const SIN_CARACTER_NULO = /^[^\u0000]*$/;

const FORMATO_DIA = /^\d{4}-\d{2}-\d{2}$/;

/** Un campo de texto vacío o de solo espacios se trata como no enviado. */
function textoOpcional({ value }: { value: unknown }): unknown {
  if (typeof value !== 'string') return value;
  const recortado = value.trim();
  return recortado === '' ? undefined : recortado;
}

/**
 * Un filtro numérico vacío o de solo espacios se trata como no enviado, igual
 * que los de texto: `?precioMax=` no filtra. Con `@Type(() => Number)` el texto
 * vacío se convertía en 0 (y `precioMax=` filtraba `precio <= 0`). Lo demás se
 * convierte con `Number` y, si no es un número, lo rechaza la validación.
 */
function numeroOpcional({ value }: { value: unknown }): unknown {
  if (typeof value !== 'string') return value;
  return value.trim() === '' ? undefined : Number(value);
}

/** Sin tildes ni mayúsculas, para comparar categorías. */
const normalizar = (texto: string): string =>
  texto
    .normalize('NFD')
    .replace(/\p{Diacritic}/gu, '')
    .toLowerCase();

const CATEGORIAS: readonly string[] = Object.values(CATEGORIAS_POR_TIPO).flat();
const CATEGORIA_POR_CLAVE = new Map(
  CATEGORIAS.map((categoria) => [normalizar(categoria), categoria]),
);

/**
 * La categoría tal como la guarda el catálogo de H1, sin importar mayúsculas
 * ni tildes: "salon de EVENTOS" pasa a "Salón de eventos". Así la consulta
 * compara por igualdad y sigue usando el índice. Un texto que no es del
 * catálogo se deja igual para que lo rechace la validación.
 */
function categoriaDelCatalogo(parametros: { value: unknown }): unknown {
  const valor = textoOpcional(parametros);
  if (typeof valor !== 'string') return valor;
  return CATEGORIA_POR_CLAVE.get(normalizar(valor)) ?? valor;
}

/**
 * Query de `GET /bienes`.
 *
 * Texto y ubicación (H3) y los filtros de precio, tipo, categoría, capacidad y
 * disponibilidad (H4). Todos son opcionales y se combinan con AND.
 *
 * Aquí se valida cada parámetro por separado. Las reglas entre parámetros
 * (precioMin <= precioMax, las dos fechas juntas, el orden de las fechas y que
 * el inicio no sea anterior a hoy) las valida `BienesService`.
 */
export class BuscarBienesQueryDto {
  @ApiPropertyOptional({
    description:
      'Texto a buscar en el título y la descripción. Ignora mayúsculas y tildes. Vacío equivale a no buscar por texto.',
    example: 'salon',
    maxLength: MAX_LARGO_TEXTO_BUSQUEDA,
  })
  @IsOptional()
  @Transform(textoOpcional)
  @IsString({ message: 'El texto de búsqueda debe ser texto.' })
  @MaxLength(MAX_LARGO_TEXTO_BUSQUEDA, {
    message: `El texto de búsqueda no puede superar los ${MAX_LARGO_TEXTO_BUSQUEDA} caracteres.`,
  })
  @Matches(SIN_CARACTER_NULO, {
    message: 'El texto de búsqueda contiene caracteres no permitidos.',
  })
  q?: string;

  @ApiPropertyOptional({
    description: 'Departamento exacto, como lo guarda el bien.',
    example: 'San Salvador',
  })
  @IsOptional()
  @Transform(textoOpcional)
  @IsString({ message: 'El departamento debe ser texto.' })
  @MaxLength(50, {
    message: 'El departamento no puede superar los 50 caracteres.',
  })
  @Matches(SIN_CARACTER_NULO, {
    message: 'El departamento contiene caracteres no permitidos.',
  })
  departamento?: string;

  @ApiPropertyOptional({
    description: 'Municipio exacto, como lo guarda el bien.',
    example: 'Antiguo Cuscatlán',
  })
  @IsOptional()
  @Transform(textoOpcional)
  @IsString({ message: 'El municipio debe ser texto.' })
  @MaxLength(80, {
    message: 'El municipio no puede superar los 80 caracteres.',
  })
  @Matches(SIN_CARACTER_NULO, {
    message: 'El municipio contiene caracteres no permitidos.',
  })
  municipio?: string;

  @ApiPropertyOptional({
    description: 'Precio mínimo, inclusive. No negativo, hasta 2 decimales.',
    example: 20,
    minimum: 0,
  })
  @IsOptional()
  @Transform(numeroOpcional)
  @IsNumber(
    { allowNaN: false, allowInfinity: false, maxDecimalPlaces: 2 },
    { message: 'El precio mínimo debe ser un número con hasta 2 decimales.' },
  )
  @Min(0, { message: 'El precio mínimo no puede ser negativo.' })
  @Max(PRECIO_MAXIMO_FILTRO, {
    message: 'El precio mínimo es demasiado grande.',
  })
  precioMin?: number;

  @ApiPropertyOptional({
    description: 'Precio máximo, inclusive. No negativo, hasta 2 decimales.',
    example: 100,
    minimum: 0,
  })
  @IsOptional()
  @Transform(numeroOpcional)
  @IsNumber(
    { allowNaN: false, allowInfinity: false, maxDecimalPlaces: 2 },
    { message: 'El precio máximo debe ser un número con hasta 2 decimales.' },
  )
  @Min(0, { message: 'El precio máximo no puede ser negativo.' })
  @Max(PRECIO_MAXIMO_FILTRO, {
    message: 'El precio máximo es demasiado grande.',
  })
  precioMax?: number;

  @ApiPropertyOptional({ enum: TipoBien, enumName: 'TipoBien' })
  @IsOptional()
  @IsEnum(TipoBien, { message: 'El tipo debe ser PROPIEDAD o EQUIPO.' })
  tipo?: TipoBien;

  @ApiPropertyOptional({
    description:
      'Una categoría del catálogo de H1. No distingue mayúsculas ni tildes ("salon de eventos" equivale a "Salón de eventos").',
    example: 'Salón de eventos',
    enum: CATEGORIAS,
  })
  @IsOptional()
  @Transform(categoriaDelCatalogo)
  @IsIn(CATEGORIAS, {
    message: `La categoría no existe. Opciones: ${CATEGORIAS.join(', ')}.`,
  })
  categoria?: string;

  @ApiPropertyOptional({
    description:
      'Capacidad mínima. Excluye los bienes que no tienen capacidad registrada.',
    example: 50,
    minimum: 1,
  })
  @IsOptional()
  @Transform(numeroOpcional)
  @IsInt({ message: 'La capacidad mínima debe ser un número entero.' })
  @Min(1, { message: 'La capacidad mínima debe ser 1 o mayor.' })
  @Max(CAPACIDAD_MAXIMA_FILTRO, {
    message: 'La capacidad mínima es demasiado grande.',
  })
  capacidadMin?: number;

  @ApiPropertyOptional({
    description:
      'Primer día del periodo, YYYY-MM-DD. Va junto con `fechaFin` y no puede ser anterior a hoy (hora de El Salvador).',
    example: '2026-11-20',
  })
  @IsOptional()
  @Matches(FORMATO_DIA, {
    message: 'La fecha de inicio debe tener el formato YYYY-MM-DD.',
  })
  fechaInicio?: string;

  @ApiPropertyOptional({
    description:
      'Último día del periodo, inclusive, YYYY-MM-DD. Va junto con `fechaInicio`.',
    example: '2026-11-22',
  })
  @IsOptional()
  @Matches(FORMATO_DIA, {
    message: 'La fecha de fin debe tener el formato YYYY-MM-DD.',
  })
  fechaFin?: string;

  @ApiPropertyOptional({
    description: 'Número de página, empezando en 1.',
    example: 1,
    minimum: 1,
    maximum: PAGINA_MAXIMA,
    default: 1,
  })
  @IsOptional()
  @Type(() => Number)
  @IsInt({ message: 'La página debe ser un número entero.' })
  @Min(1, { message: `La página debe ser de 1 a ${PAGINA_MAXIMA}.` })
  @Max(PAGINA_MAXIMA, {
    message: `La página debe ser de 1 a ${PAGINA_MAXIMA}.`,
  })
  pagina: number = 1;

  @ApiPropertyOptional({
    description: 'Resultados por página.',
    example: TAMANO_PAGINA_POR_DEFECTO,
    minimum: 1,
    maximum: TAMANO_PAGINA_MAXIMO,
    default: TAMANO_PAGINA_POR_DEFECTO,
  })
  @IsOptional()
  @Type(() => Number)
  @IsInt({ message: 'El tamaño de página debe ser un número entero.' })
  @Min(1, { message: 'El tamaño de página debe ser de 1 a 50.' })
  @Max(TAMANO_PAGINA_MAXIMO, {
    message: `El tamaño de página debe ser de 1 a ${TAMANO_PAGINA_MAXIMO}.`,
  })
  tamano: number = TAMANO_PAGINA_POR_DEFECTO;
}
