import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsOptional, Matches } from 'class-validator';

const FORMATO_DIA = /^\d{4}-\d{2}-\d{2}$/;
const MENSAJE_FORMATO = 'Debe tener el formato YYYY-MM-DD.';

/**
 * Query de `GET /bienes/:bienId/disponibilidad`.
 *
 * Aquí solo se valida el formato. Que sea un día real, que `desde <= hasta` y
 * la ventana máxima son reglas de negocio y las valida el servicio.
 */
export class ConsultaDisponibilidadDto {
  @ApiPropertyOptional({
    example: '2026-11-01',
    description: 'Primer día de la ventana. Por defecto, hoy.',
  })
  @IsOptional()
  @Matches(FORMATO_DIA, { message: MENSAJE_FORMATO })
  desde?: string;

  @ApiPropertyOptional({
    example: '2027-10-31',
    description:
      'Último día de la ventana, inclusive. Por defecto, 12 meses desde `desde`.',
  })
  @IsOptional()
  @Matches(FORMATO_DIA, { message: MENSAJE_FORMATO })
  hasta?: string;
}
