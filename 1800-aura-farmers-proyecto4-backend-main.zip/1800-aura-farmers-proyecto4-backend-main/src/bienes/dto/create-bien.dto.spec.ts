import { plainToInstance } from 'class-transformer';
import { validate } from 'class-validator';
import { CreateBienDto } from './create-bien.dto.js';

// En multipart/form-data todos los campos llegan como texto.
const base = {
  tipo: 'PROPIEDAD',
  categoria: 'Salón de eventos',
  titulo: 'Salón de eventos Las Palmas',
  descripcion: 'Salón climatizado con cocina y parqueo.',
  precio: '80.00',
  unidadCobro: 'DIA',
  departamento: 'San Salvador',
  municipio: 'San Salvador',
};

async function errores(parcial: Record<string, unknown>) {
  const dto = plainToInstance(CreateBienDto, { ...base, ...parcial });
  const result = await validate(dto);
  return { dto, campos: result.map((e) => e.property), result };
}

describe('CreateBienDto', () => {
  it('acepta un bien válido con solo los campos obligatorios', async () => {
    expect((await errores({})).campos).toEqual([]);
  });

  it('acepta un bien con todos los campos', async () => {
    const { dto, campos } = await errores({
      deposito: '50',
      capacidad: '120',
      condiciones: 'No se permite fumar.',
      direccionReferencia: 'Frente al parque.',
      indicePrincipal: '2',
    });
    expect(campos).toEqual([]);
    expect(dto).toMatchObject({
      deposito: 50,
      capacidad: 120,
      indicePrincipal: 2,
    });
  });

  it('convierte el precio de texto a número', async () => {
    const { dto } = await errores({ precio: ' 80.50 ' });
    expect(dto.precio).toBe(80.5);
  });

  it('recorta los espacios del texto', async () => {
    const { dto } = await errores({ titulo: '  Salón Las Palmas  ' });
    expect(dto.titulo).toBe('Salón Las Palmas');
  });

  it.each([
    'tipo',
    'categoria',
    'titulo',
    'descripcion',
    'precio',
    'unidadCobro',
    'departamento',
    'municipio',
  ])('rechaza el bien sin %s', async (campo) => {
    expect((await errores({ [campo]: undefined })).campos).toContain(campo);
  });

  it.each(['titulo', 'descripcion', 'precio', 'departamento', 'municipio'])(
    'rechaza %s vacío',
    async (campo) => {
      expect((await errores({ [campo]: '   ' })).campos).toContain(campo);
    },
  );

  describe('categoria', () => {
    it.each([
      ['PROPIEDAD', 'Casa'],
      ['PROPIEDAD', 'Terreno'],
      ['EQUIPO', 'Herramientas'],
      ['EQUIPO', 'Jardinería'],
    ])('acepta una categoría de su tipo (%s, %s)', async (tipo, categoria) => {
      expect((await errores({ tipo, categoria })).campos).toEqual([]);
    });

    it('rechaza una categoría de otro tipo y dice cuáles valen', async () => {
      const { campos, result } = await errores({
        tipo: 'EQUIPO',
        categoria: 'Casa',
      });
      expect(campos).toEqual(['categoria']);
      expect(result[0]!.constraints?.esCategoriaDelTipo).toContain(
        'no pertenece al tipo EQUIPO',
      );
    });

    it('rechaza una categoría que no existe', async () => {
      expect((await errores({ categoria: 'Castillo' })).campos).toEqual([
        'categoria',
      ]);
    });

    it('distingue mayúsculas', async () => {
      expect((await errores({ categoria: 'casa' })).campos).toContain(
        'categoria',
      );
    });

    it('con un tipo inválido solo reporta el tipo si la categoría existe', async () => {
      expect(
        (await errores({ tipo: 'VEHICULO', categoria: 'Casa' })).campos,
      ).toEqual(['tipo']);
    });
  });

  describe('precio', () => {
    it.each(['0', '-5', 'abc', '10.555'])('rechaza %s', async (precio) => {
      expect((await errores({ precio })).campos).toContain('precio');
    });
  });

  describe('titulo', () => {
    it('acepta 100 caracteres', async () => {
      expect((await errores({ titulo: 'a'.repeat(100) })).campos).toEqual([]);
    });

    it('rechaza más de 100 caracteres', async () => {
      expect((await errores({ titulo: 'a'.repeat(101) })).campos).toContain(
        'titulo',
      );
    });

    it('rechaza menos de 5 caracteres', async () => {
      expect((await errores({ titulo: 'Casa' })).campos).toContain('titulo');
    });
  });

  it.each([
    ['tipo', 'VEHICULO'],
    ['unidadCobro', 'MES'],
    ['deposito', '-1'],
    ['capacidad', '0'],
    ['capacidad', '2.5'],
    ['indicePrincipal', '-1'],
    ['indicePrincipal', '10'],
    ['condiciones', 'a'.repeat(1001)],
    ['direccionReferencia', 'a'.repeat(201)],
  ])('rechaza %s = %s', async (campo, valor) => {
    expect((await errores({ [campo]: valor })).campos).toContain(campo);
  });

  it('trata los opcionales vacíos como no enviados', async () => {
    const { dto, campos } = await errores({
      deposito: '',
      capacidad: '',
      condiciones: '  ',
      direccionReferencia: '',
      indicePrincipal: '',
    });
    expect(campos).toEqual([]);
    expect(dto.deposito).toBeUndefined();
    expect(dto.capacidad).toBeUndefined();
    expect(dto.condiciones).toBeUndefined();
    expect(dto.direccionReferencia).toBeUndefined();
    expect(dto.indicePrincipal).toBeUndefined();
  });
});
