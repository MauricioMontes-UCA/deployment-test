import { DisponibilidadResponseDto } from './disponibilidad-response.dto.js';

describe('DisponibilidadResponseDto.from', () => {
  it('serializa los rangos como YYYY-MM-DD y no agrega otros campos', () => {
    const dto = DisponibilidadResponseDto.from({
      bienId: 'bien-1',
      reservados: [
        {
          fechaInicio: new Date('2026-12-10T00:00:00.000Z'),
          fechaFin: new Date('2026-12-12T00:00:00.000Z'),
          // Aunque el repositorio filtrara mal y llegara de más, no sale.
          arrendatarioId: 'secreto',
          estado: 'CONFIRMADA',
        } as never,
      ],
      bloqueados: [
        {
          fechaInicio: new Date('2026-12-20T00:00:00.000Z'),
          fechaFin: new Date('2026-12-25T00:00:00.000Z'),
        },
      ],
    });

    expect(dto).toEqual({
      bienId: 'bien-1',
      reservados: [{ fechaInicio: '2026-12-10', fechaFin: '2026-12-12' }],
      bloqueados: [{ fechaInicio: '2026-12-20', fechaFin: '2026-12-25' }],
    });
  });
});
