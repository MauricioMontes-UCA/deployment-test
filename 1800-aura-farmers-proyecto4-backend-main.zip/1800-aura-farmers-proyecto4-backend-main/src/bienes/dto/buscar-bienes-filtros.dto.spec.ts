import { plainToInstance } from 'class-transformer';
import { validate } from 'class-validator';
import { BuscarBienesQueryDto } from './buscar-bienes-query.dto.js';

// En la query string todo llega como texto.
async function validar(query: Record<string, unknown>) {
  const dto = plainToInstance(BuscarBienesQueryDto, query);
  const errores = await validate(dto);
  return { dto, campos: errores.map((e) => e.property) };
}

describe('BuscarBienesQueryDto: filtros de H4', () => {
  it('acepta todos los filtros y los convierte', async () => {
    const { dto, campos } = await validar({
      precioMin: '20',
      precioMax: '100.50',
      tipo: 'PROPIEDAD',
      categoria: ' Salón de eventos ',
      capacidadMin: '50',
      fechaInicio: '2026-11-20',
      fechaFin: '2026-11-22',
    });

    expect(campos).toEqual([]);
    expect(dto).toMatchObject({
      precioMin: 20,
      precioMax: 100.5,
      tipo: 'PROPIEDAD',
      categoria: 'Salón de eventos',
      capacidadMin: 50,
      fechaInicio: '2026-11-20',
      fechaFin: '2026-11-22',
    });
  });

  it('sin filtros los deja sin definir', async () => {
    const { dto } = await validar({});
    expect(dto.precioMin).toBeUndefined();
    expect(dto.tipo).toBeUndefined();
    expect(dto.fechaInicio).toBeUndefined();
  });

  it('acepta precio 0', async () => {
    const { campos } = await validar({ precioMin: '0', precioMax: '0' });
    expect(campos).toEqual([]);
  });

  it.each(['-1', '-0.01', 'abc', '10.123', '99999999999'])(
    'rechaza el precio %j',
    async (precio) => {
      const { campos } = await validar({
        precioMin: precio,
        precioMax: precio,
      });
      expect(campos).toEqual(['precioMin', 'precioMax']);
    },
  );

  it.each(['propiedad', 'CASA', '1'])('rechaza el tipo %j', async (tipo) => {
    expect((await validar({ tipo })).campos).toEqual(['tipo']);
  });

  it('acepta EQUIPO', async () => {
    expect((await validar({ tipo: 'EQUIPO' })).campos).toEqual([]);
  });

  it.each([
    ['precioMin', { precioMin: '' }],
    ['precioMax', { precioMax: '  ' }],
    ['capacidadMin', { capacidadMin: '' }],
  ])('trata un %s vacío como no enviado', async (campo, query) => {
    const { dto, campos } = await validar(query);
    expect(campos).toEqual([]);
    expect(dto[campo as keyof typeof dto]).toBeUndefined();
  });

  it.each([
    ['salon de eventos', 'Salón de eventos'],
    ['AUDIO Y SONIDO', 'Audio y sonido'],
    ['computo', 'Cómputo'],
    ['  Jardineria ', 'Jardinería'],
  ])('lleva la categoría %j a la del catálogo', async (categoria, esperada) => {
    const { dto, campos } = await validar({ categoria });
    expect(campos).toEqual([]);
    expect(dto.categoria).toBe(esperada);
  });

  it('trata una categoría en blanco como no enviada', async () => {
    const { dto, campos } = await validar({ categoria: '   ' });
    expect(campos).toEqual([]);
    expect(dto.categoria).toBeUndefined();
  });

  it.each(['a'.repeat(51), 'sa\u0000lon', 'Castillo', 'Sonido', 'Salones'])(
    'rechaza la categoría %j, que no es del catálogo',
    async (categoria) => {
      expect((await validar({ categoria })).campos).toEqual(['categoria']);
    },
  );

  it.each(['0', '-5', '2.5', 'abc', '2147483648'])(
    'rechaza la capacidad mínima %j',
    async (capacidadMin) => {
      expect((await validar({ capacidadMin })).campos).toEqual([
        'capacidadMin',
      ]);
    },
  );

  it('acepta capacidad mínima 1', async () => {
    expect((await validar({ capacidadMin: '1' })).campos).toEqual([]);
  });

  it.each(['20-11-2026', '2026/11/20', '2026-11-20T00:00:00Z', 'mañana'])(
    'rechaza la fecha con formato %j',
    async (fecha) => {
      const { campos } = await validar({ fechaInicio: fecha, fechaFin: fecha });
      expect(campos).toEqual(['fechaInicio', 'fechaFin']);
    },
  );
});
