import { ApiPropertyOptional } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsInt, Max, Min } from 'class-validator';
import { MIS_BIENES_POR_PAGINA, PAGINA_MAXIMA } from '@Bienes/constants';

/** Query de `GET /bienes/mios` (BE-1.3). */
export class ConsultarMisBienesDto {
  @ApiPropertyOptional({
    type: Number,
    minimum: 1,
    maximum: PAGINA_MAXIMA,
    default: 1,
    description: `Número de página, empezando en 1. Cada página tiene ${MIS_BIENES_POR_PAGINA} bienes.`,
  })
  // Solo dígitos decimales sin ceros a la izquierda: `1e2`, `0x10`, ` 2`,
  // `1.0` o `+1` no son una página, en vez de convertirse en otra con Number().
  @Transform(({ value }: { value: unknown }) => {
    if (value === undefined) return 1;
    if (typeof value !== 'string' || !/^[1-9]\d*$/.test(value)) {
      return Number.NaN;
    }
    return Number(value);
  })
  @IsInt({ message: 'La página debe ser un número entero.' })
  @Min(1, { message: 'La página debe ser mayor o igual que 1.' })
  @Max(PAGINA_MAXIMA, {
    message: `La página debe ser menor o igual que ${PAGINA_MAXIMA}.`,
  })
  pagina: number = 1;
}
