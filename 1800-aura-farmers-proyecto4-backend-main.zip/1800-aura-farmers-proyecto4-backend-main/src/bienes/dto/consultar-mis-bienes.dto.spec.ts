import { plainToInstance } from 'class-transformer';
import { validate } from 'class-validator';
import { PAGINA_MAXIMA } from '@Bienes/constants';
import { ConsultarMisBienesDto } from './consultar-mis-bienes.dto.js';

// En la query string todo llega como texto.
async function validar(query: Record<string, unknown>) {
  const dto = plainToInstance(ConsultarMisBienesDto, query);
  const errores = await validate(dto);
  return { dto, campos: errores.map((e) => e.property) };
}

describe('ConsultarMisBienesDto', () => {
  it('sin pagina usa la página 1', async () => {
    const { dto, campos } = await validar({});

    expect(campos).toEqual([]);
    expect(dto.pagina).toBe(1);
  });

  it.each([
    ['1', 1],
    ['2', 2],
    ['20', 20],
    [String(PAGINA_MAXIMA), PAGINA_MAXIMA],
  ])('acepta pagina=%s', async (texto, esperado) => {
    const { dto, campos } = await validar({ pagina: texto });

    expect(campos).toEqual([]);
    expect(dto.pagina).toBe(esperado);
  });

  it.each([
    '0',
    '-1',
    '-0',
    '1.5',
    '1.0',
    'abc',
    '',
    ' ',
    '01',
    '1e2',
    '0x10',
    '+1',
    ' 2',
    '2 ',
    '1,5',
    'NaN',
    'Infinity',
    String(PAGINA_MAXIMA + 1),
    '9007199254740993',
  ])('rechaza pagina=%j', async (texto) => {
    const { campos } = await validar({ pagina: texto });

    expect(campos).toEqual(['pagina']);
  });

  it('rechaza un valor que no es texto, como un arreglo (pagina repetida)', async () => {
    const { campos } = await validar({ pagina: ['1', '2'] });

    expect(campos).toEqual(['pagina']);
  });
});
