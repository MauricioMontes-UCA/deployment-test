import { ApiProperty } from '@nestjs/swagger';
import { EstadoBien, UnidadCobro, type FotoBien } from '@PrismaClient';
import type { BienConFotos } from '@Bienes/types';

export class FotoBienResponseDto {
  @ApiProperty({ format: 'uuid' })
  id!: string;

  @ApiProperty({
    example: '/uploads/bienes/7c9e6679-7425-40de-944b-e07fc1f90ae7/1.webp',
  })
  url!: string;

  @ApiProperty({ example: 1 })
  orden!: number;

  @ApiProperty({ example: true })
  esPrincipal!: boolean;

  static fromEntity(foto: FotoBien): FotoBienResponseDto {
    return {
      id: foto.id,
      url: foto.url,
      orden: foto.orden,
      esPrincipal: foto.esPrincipal,
    };
  }
}

/** Respuesta de la publicación de un bien. */
export class BienResponseDto {
  @ApiProperty({ format: 'uuid' })
  id!: string;

  @ApiProperty({ example: 'Salón de eventos Las Palmas' })
  titulo!: string;

  @ApiProperty({ example: 80 })
  precio!: number;

  @ApiProperty({
    enum: UnidadCobro,
    enumName: 'UnidadCobro',
    example: UnidadCobro.DIA,
  })
  unidadCobro!: UnidadCobro;

  @ApiProperty({
    enum: EstadoBien,
    enumName: 'EstadoBien',
    example: EstadoBien.ACTIVA,
  })
  estado!: EstadoBien;

  @ApiProperty({ type: [FotoBienResponseDto] })
  fotos!: FotoBienResponseDto[];

  @ApiProperty({ type: String, format: 'date-time' })
  creadoEn!: Date;

  static fromEntity(bien: BienConFotos): BienResponseDto {
    return {
      id: bien.id,
      titulo: bien.titulo,
      // Prisma devuelve DECIMAL como Decimal; la API lo expone como número.
      precio: bien.precio.toNumber(),
      unidadCobro: bien.unidadCobro,
      estado: bien.estado,
      fotos: bien.fotos.map((foto) => FotoBienResponseDto.fromEntity(foto)),
      creadoEn: bien.creadoEn,
    };
  }
}

/** Un bien en los resultados de la búsqueda. */
export class BienEncontradoResponseDto {
  @ApiProperty({ format: 'uuid' })
  id!: string;

  @ApiProperty({ example: 'Salón de eventos Las Palmas' })
  titulo!: string;

  @ApiProperty({
    type: String,
    nullable: true,
    example: '/uploads/bienes/7c9e6679-7425-40de-944b-e07fc1f90ae7/1.webp',
    description: 'Foto principal. Es null si el bien no tiene fotos.',
  })
  fotoPrincipal!: string | null;

  @ApiProperty({ example: 80 })
  precio!: number;

  @ApiProperty({
    enum: UnidadCobro,
    enumName: 'UnidadCobro',
    example: UnidadCobro.DIA,
  })
  unidadCobro!: UnidadCobro;

  @ApiProperty({ example: 'San Salvador' })
  departamento!: string;

  @ApiProperty({ example: 'San Salvador' })
  municipio!: string;
}

/** Página de resultados de `GET /bienes`. */
export class BusquedaBienesResponseDto {
  @ApiProperty({ example: 1 })
  pagina!: number;

  @ApiProperty({ example: 20 })
  tamanoPagina!: number;

  @ApiProperty({
    example: 45,
    description: 'Bienes que cumplen la búsqueda, sin contar la paginación.',
  })
  total!: number;

  @ApiProperty({
    example: true,
    description: 'Si hay más resultados después de esta página.',
  })
  hayMas!: boolean;

  @ApiProperty({ type: [BienEncontradoResponseDto] })
  resultados!: BienEncontradoResponseDto[];
}
