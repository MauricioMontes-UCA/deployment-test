import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import {
  IsDefined,
  IsEnum,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsPositive,
  IsString,
  Max,
  MaxLength,
  Min,
  MinLength,
} from 'class-validator';
import { EsCategoriaDelTipo } from '@Bienes/decorators';
import { CATEGORIAS_POR_TIPO, MAX_FOTOS } from '@Bienes/constants';
import { TipoBien, UnidadCobro } from '@PrismaClient';

/** Mayor monto que cabe en una columna DECIMAL(12, 2). */
const MONTO_MAXIMO = 9_999_999_999.99;

/** Mayor valor de una columna INTEGER de Postgres. */
const ENTERO_MAXIMO = 2_147_483_647;

// En multipart/form-data todos los campos llegan como texto. Estas funciones
// los preparan antes de validar: recortan espacios, convierten los números y
// tratan un campo vacío del formulario como no enviado.

function texto({ value }: { value: unknown }): unknown {
  return typeof value === 'string' ? value.trim() : value;
}

function textoOpcional({ value }: { value: unknown }): unknown {
  if (typeof value !== 'string') return value;
  const recortado = value.trim();
  return recortado === '' ? undefined : recortado;
}

function numero({ value }: { value: unknown }): unknown {
  if (typeof value !== 'string') return value;
  const recortado = value.trim();
  // Number('abc') da NaN, que @IsNumber e @IsInt rechazan.
  return recortado === '' ? undefined : Number(recortado);
}

/**
 * Campos de texto del formulario para publicar un bien.
 *
 * Las fotos no van acá: llegan como archivos en el campo `fotos` y las valida
 * `FotosBienPipe`. El arrendador tampoco: se toma del token con
 * `@CurrentUser()` y nunca del body.
 */
export class CreateBienDto {
  @ApiProperty({
    enum: TipoBien,
    enumName: 'TipoBien',
    example: TipoBien.PROPIEDAD,
  })
  @IsEnum(TipoBien, { message: 'El tipo debe ser PROPIEDAD o EQUIPO.' })
  tipo!: TipoBien;

  @ApiProperty({
    description: `Debe ser una categoría del tipo elegido. PROPIEDAD: ${CATEGORIAS_POR_TIPO.PROPIEDAD.join(', ')}. EQUIPO: ${CATEGORIAS_POR_TIPO.EQUIPO.join(', ')}.`,
    example: 'Salón de eventos',
  })
  @Transform(texto)
  @IsString({ message: 'La categoría es obligatoria.' })
  @EsCategoriaDelTipo()
  categoria!: string;

  @ApiProperty({
    example: 'Salón de eventos Las Palmas',
    minLength: 5,
    maxLength: 100,
  })
  @Transform(texto)
  @IsString({ message: 'El título es obligatorio.' })
  @MinLength(5, { message: 'El título debe tener al menos 5 caracteres.' })
  @MaxLength(100, { message: 'El título no puede superar los 100 caracteres.' })
  titulo!: string;

  @ApiProperty({
    example:
      'Salón climatizado con cocina, parqueo y mobiliario para 120 personas.',
    maxLength: 2000,
  })
  @Transform(texto)
  @IsString({ message: 'La descripción es obligatoria.' })
  @IsNotEmpty({ message: 'La descripción no puede estar vacía.' })
  @MaxLength(2000, {
    message: 'La descripción no puede superar los 2000 caracteres.',
  })
  descripcion!: string;

  @ApiProperty({
    description: 'Mayor que 0, con hasta dos decimales.',
    example: 80,
  })
  @Transform(numero)
  @IsDefined({ message: 'El precio es obligatorio.' })
  @IsNumber(
    { maxDecimalPlaces: 2 },
    { message: 'El precio debe ser un número con hasta dos decimales.' },
  )
  @IsPositive({ message: 'El precio debe ser mayor que 0.' })
  @Max(MONTO_MAXIMO, { message: 'El precio es demasiado alto.' })
  precio!: number;

  @ApiProperty({
    enum: UnidadCobro,
    enumName: 'UnidadCobro',
    example: UnidadCobro.DIA,
  })
  @IsEnum(UnidadCobro, {
    message: 'La unidad de cobro debe ser HORA, DIA, NOCHE o SEMANA.',
  })
  unidadCobro!: UnidadCobro;

  @ApiPropertyOptional({
    description: 'Depósito de garantía. Si no se envía, es 0.',
    example: 50,
  })
  @IsOptional()
  @Transform(numero)
  @IsNumber(
    { maxDecimalPlaces: 2 },
    { message: 'El depósito debe ser un número con hasta dos decimales.' },
  )
  @Min(0, { message: 'El depósito no puede ser negativo.' })
  @Max(MONTO_MAXIMO, { message: 'El depósito es demasiado alto.' })
  deposito?: number;

  @ApiPropertyOptional({ description: 'Cantidad de personas.', example: 120 })
  @IsOptional()
  @Transform(numero)
  @IsInt({ message: 'La capacidad debe ser un número entero.' })
  @Min(1, { message: 'La capacidad debe ser mayor que 0.' })
  @Max(ENTERO_MAXIMO, { message: 'La capacidad es demasiado alta.' })
  capacidad?: number;

  @ApiPropertyOptional({
    description: 'Condiciones de uso.',
    example: 'No se permite fumar. Horario hasta las 23:00.',
    maxLength: 1000,
  })
  @IsOptional()
  @Transform(textoOpcional)
  @IsString({ message: 'Las condiciones deben ser texto.' })
  @MaxLength(1000, {
    message: 'Las condiciones no pueden superar los 1000 caracteres.',
  })
  condiciones?: string;

  @ApiProperty({ example: 'San Salvador', maxLength: 50 })
  @Transform(texto)
  @IsString({ message: 'El departamento es obligatorio.' })
  @IsNotEmpty({ message: 'El departamento no puede estar vacío.' })
  @MaxLength(50, {
    message: 'El departamento no puede superar los 50 caracteres.',
  })
  departamento!: string;

  @ApiProperty({ example: 'San Salvador', maxLength: 80 })
  @Transform(texto)
  @IsString({ message: 'El municipio es obligatorio.' })
  @IsNotEmpty({ message: 'El municipio no puede estar vacío.' })
  @MaxLength(80, {
    message: 'El municipio no puede superar los 80 caracteres.',
  })
  municipio!: string;

  @ApiPropertyOptional({
    example: 'Frente al parque central, portón negro.',
    maxLength: 200,
  })
  @IsOptional()
  @Transform(textoOpcional)
  @IsString({ message: 'La dirección de referencia debe ser texto.' })
  @MaxLength(200, {
    message: 'La dirección de referencia no puede superar los 200 caracteres.',
  })
  direccionReferencia?: string;

  @ApiPropertyOptional({
    description:
      'Posición de la foto principal dentro de `fotos`, empezando en 0. Si no se envía, la principal es la primera.',
    example: 0,
    minimum: 0,
    maximum: MAX_FOTOS - 1,
  })
  @IsOptional()
  @Transform(numero)
  @IsInt({
    message: 'El índice de la foto principal debe ser un número entero.',
  })
  @Min(0, { message: 'El índice de la foto principal no puede ser negativo.' })
  @Max(MAX_FOTOS - 1, {
    message: `El índice de la foto principal debe ser menor que ${MAX_FOTOS}.`,
  })
  indicePrincipal?: number;
}

/**
 * Forma completa del formulario, solo para Swagger.
 *
 * Agrega el campo de archivos para que /api/docs muestre el selector de fotos.
 * La validación de los archivos la hace `FotosBienPipe`.
 */
export class CreateBienFormDto extends CreateBienDto {
  @ApiProperty({
    description: `De 1 a ${MAX_FOTOS} fotos JPG, PNG o WEBP de hasta 5 MB cada una. El orden en que se envían es el orden en que se muestran.`,
    type: 'array',
    items: { type: 'string', format: 'binary' },
  })
  fotos!: unknown[];
}
