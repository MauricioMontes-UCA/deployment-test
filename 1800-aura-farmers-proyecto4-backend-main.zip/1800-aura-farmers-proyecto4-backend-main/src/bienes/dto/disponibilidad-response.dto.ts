import { ApiProperty } from '@nestjs/swagger';
import { formatDia } from '@Bienes/utils';
import type { Disponibilidad, RangoFechas } from '@Bienes/repositories';

export class RangoFechasResponseDto {
  @ApiProperty({ example: '2026-12-10', format: 'date' })
  fechaInicio!: string;

  @ApiProperty({ example: '2026-12-12', format: 'date' })
  fechaFin!: string;

  static fromRango(rango: RangoFechas): RangoFechasResponseDto {
    return {
      fechaInicio: formatDia(rango.fechaInicio),
      fechaFin: formatDia(rango.fechaFin),
    };
  }
}

/**
 * Forma pública de la disponibilidad de un bien.
 *
 * Solo trae rangos de fechas: no incluye al arrendatario, el estado ni el id
 * de la reserva, así que nada de las solicitudes se filtra por descuido.
 */
export class DisponibilidadResponseDto {
  @ApiProperty({ format: 'uuid' })
  bienId!: string;

  @ApiProperty({ type: [RangoFechasResponseDto] })
  reservados!: RangoFechasResponseDto[];

  @ApiProperty({ type: [RangoFechasResponseDto] })
  bloqueados!: RangoFechasResponseDto[];

  static from(disponibilidad: Disponibilidad): DisponibilidadResponseDto {
    return {
      bienId: disponibilidad.bienId,
      reservados: disponibilidad.reservados.map((r) =>
        RangoFechasResponseDto.fromRango(r),
      ),
      bloqueados: disponibilidad.bloqueados.map((r) =>
        RangoFechasResponseDto.fromRango(r),
      ),
    };
  }
}
