import { Prisma } from '@PrismaClient';
import type { MiBien } from '@Bienes/repositories';
import { MiBienResponseDto } from './mis-bienes-response.dto.js';

const base = {
  id: '7c9e6679-7425-40de-944b-e07fc1f90ae7',
  titulo: 'Salón de eventos Las Palmas',
  tipo: 'PROPIEDAD',
  categoria: 'Salón de eventos',
  estado: 'ACTIVA',
  precio: new Prisma.Decimal('80.50'),
  unidadCobro: 'DIA',
  deposito: new Prisma.Decimal('25'),
  departamento: 'San Salvador',
  municipio: 'San Salvador',
  creadoEn: new Date('2026-11-02T15:00:00.000Z'),
  fotos: [{ url: '/uploads/bienes/x/1.webp' }],
  politicaVerificacion: { soloVerificados: true },
} as MiBien;

describe('MiBienResponseDto.fromEntity', () => {
  it('convierte los decimales a número y toma la foto principal y la política', () => {
    expect(MiBienResponseDto.fromEntity(base)).toEqual({
      id: base.id,
      titulo: 'Salón de eventos Las Palmas',
      tipo: 'PROPIEDAD',
      categoria: 'Salón de eventos',
      estado: 'ACTIVA',
      precio: 80.5,
      unidadCobro: 'DIA',
      deposito: 25,
      departamento: 'San Salvador',
      municipio: 'San Salvador',
      fotoPrincipalUrl: '/uploads/bienes/x/1.webp',
      soloVerificados: true,
      creadoEn: new Date('2026-11-02T15:00:00.000Z'),
    });
  });

  it('sin fotos, fotoPrincipalUrl es null', () => {
    const dto = MiBienResponseDto.fromEntity({ ...base, fotos: [] } as MiBien);

    expect(dto.fotoPrincipalUrl).toBeNull();
  });

  it('sin registro de política, soloVerificados es false', () => {
    const dto = MiBienResponseDto.fromEntity({
      ...base,
      politicaVerificacion: null,
    } as MiBien);

    expect(dto.soloVerificados).toBe(false);
  });

  it('con la política en false explícito, soloVerificados es false', () => {
    const dto = MiBienResponseDto.fromEntity({
      ...base,
      politicaVerificacion: { soloVerificados: false },
    } as MiBien);

    expect(dto.soloVerificados).toBe(false);
  });

  it('un bien INACTIVA conserva su estado', () => {
    const dto = MiBienResponseDto.fromEntity({
      ...base,
      estado: 'INACTIVA',
    } as MiBien);

    expect(dto.estado).toBe('INACTIVA');
  });

  it('solo expone los campos acordados', () => {
    const dto = MiBienResponseDto.fromEntity({
      ...base,
      descripcion: 'no debe salir',
      arrendadorId: 'no debe salir',
    } as unknown as MiBien);

    expect(Object.keys(dto).sort()).toEqual(
      [
        'categoria',
        'creadoEn',
        'departamento',
        'deposito',
        'estado',
        'fotoPrincipalUrl',
        'id',
        'municipio',
        'precio',
        'soloVerificados',
        'tipo',
        'titulo',
        'unidadCobro',
      ].sort(),
    );
  });
});
