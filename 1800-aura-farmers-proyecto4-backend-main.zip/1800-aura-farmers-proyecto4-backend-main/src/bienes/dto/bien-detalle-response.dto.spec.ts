import { Prisma } from '@PrismaClient';
import {
  BienDetalleResponseDto,
  type BienDetalleConCalificacion,
} from './bien-detalle-response.dto.js';
import { BienResponseDto } from './bien-response.dto.js';
import type { BienDetalle } from '@Bienes/repositories';

const CREADO_EN = new Date('2026-11-02T15:00:00.000Z');

function detalle(
  cambios: Partial<BienDetalleConCalificacion> = {},
): BienDetalleConCalificacion {
  return {
    id: '7c9e6679-7425-40de-944b-e07fc1f90ae7',
    tipo: 'PROPIEDAD',
    categoria: 'Salón de eventos',
    titulo: 'Salón de eventos Las Palmas',
    descripcion: 'Salón climatizado con cocina y parqueo.',
    precio: new Prisma.Decimal('80.50'),
    unidadCobro: 'DIA',
    deposito: new Prisma.Decimal('25.00'),
    capacidad: 120,
    condiciones: 'No se permite pirotecnia',
    departamento: 'San Salvador',
    municipio: 'Antiguo Cuscatlán',
    direccionReferencia: 'Frente al parque central',
    creadoEn: CREADO_EN,
    arrendador: {
      id: '29bda5e8-e0c8-4a1f-9a3b-0c1d2e3f4a5b',
      nombreUsuario: 'ana_m',
    },
    fotos: [
      { url: '/uploads/bienes/x/3.webp', orden: 3, esPrincipal: true },
      { url: '/uploads/bienes/x/1.webp', orden: 1, esPrincipal: false },
    ],
    calificacion: { promedio: 4.5, totalResenas: 2 },
    ...cambios,
  };
}

describe('BienDetalleResponseDto.fromEntity', () => {
  it('arma el contrato completo y convierte los Decimal a número', () => {
    expect(BienDetalleResponseDto.fromEntity(detalle())).toEqual({
      id: '7c9e6679-7425-40de-944b-e07fc1f90ae7',
      tipo: 'PROPIEDAD',
      categoria: 'Salón de eventos',
      titulo: 'Salón de eventos Las Palmas',
      descripcion: 'Salón climatizado con cocina y parqueo.',
      precio: 80.5,
      unidadCobro: 'DIA',
      deposito: 25,
      capacidad: 120,
      condiciones: 'No se permite pirotecnia',
      departamento: 'San Salvador',
      municipio: 'Antiguo Cuscatlán',
      direccionReferencia: 'Frente al parque central',
      arrendador: {
        id: '29bda5e8-e0c8-4a1f-9a3b-0c1d2e3f4a5b',
        nombreUsuario: 'ana_m',
      },
      fotos: [
        { url: '/uploads/bienes/x/3.webp', orden: 3, esPrincipal: true },
        { url: '/uploads/bienes/x/1.webp', orden: 1, esPrincipal: false },
      ],
      calificacion: { promedio: 4.5, totalResenas: 2 },
      creadoEn: CREADO_EN,
    });
  });

  it('expone promedio null y total 0 cuando el bien no tiene reseñas', () => {
    const dto = BienDetalleResponseDto.fromEntity(
      detalle({ calificacion: { promedio: null, totalResenas: 0 } }),
    );

    expect(dto.calificacion).toEqual({ promedio: null, totalResenas: 0 });
  });

  it('devuelve números y no Decimal', () => {
    const dto = BienDetalleResponseDto.fromEntity(detalle());

    expect(typeof dto.precio).toBe('number');
    expect(typeof dto.deposito).toBe('number');
  });

  it('mantiene null en los campos opcionales y 0 sin depósito', () => {
    const dto = BienDetalleResponseDto.fromEntity(
      detalle({
        capacidad: null,
        condiciones: null,
        direccionReferencia: null,
        deposito: new Prisma.Decimal(0),
      }),
    );

    expect(dto.capacidad).toBeNull();
    expect(dto.condiciones).toBeNull();
    expect(dto.direccionReferencia).toBeNull();
    expect(dto.deposito).toBe(0);
  });

  it('no deja pasar datos privados aunque lleguen en la entidad', () => {
    const conDeMas = detalle({
      arrendador: {
        id: '29bda5e8-e0c8-4a1f-9a3b-0c1d2e3f4a5b',
        nombreUsuario: 'ana_m',
        email: 'ana@example.com',
        passwordHash: '$2b$12$secreto',
      } as BienDetalle['arrendador'],
      fotos: [
        {
          url: '/uploads/bienes/x/1.webp',
          orden: 1,
          esPrincipal: true,
          id: 'foto-1',
        } as BienDetalle['fotos'][number],
      ],
    });
    Object.assign(conDeMas, { estado: 'ACTIVA', arrendadorId: 'interno' });

    const dto = BienDetalleResponseDto.fromEntity(conDeMas);

    expect(Object.keys(dto.arrendador).sort()).toEqual(['id', 'nombreUsuario']);
    expect(Object.keys(dto.fotos[0]!).sort()).toEqual([
      'esPrincipal',
      'orden',
      'url',
    ]);
    expect(dto).not.toHaveProperty('estado');
    expect(dto).not.toHaveProperty('arrendadorId');
    expect(JSON.stringify(dto)).not.toContain('ana@example.com');
    expect(JSON.stringify(dto)).not.toContain('secreto');
  });
});

describe('BienDetalleResponseDto (documentación)', () => {
  // Lista de propiedades que @ApiProperty registra para Swagger.
  const propiedades = (dto: object): string[] =>
    (
      (Reflect.getMetadata(
        'swagger/apiModelPropertiesArray',
        (dto as { prototype: object }).prototype,
      ) ?? []) as string[]
    ).map((propiedad) => propiedad.replace(/^:/, ''));

  it('documenta todos los campos del contrato y ninguno más', () => {
    expect(propiedades(BienDetalleResponseDto).sort()).toEqual(
      [
        'id',
        'tipo',
        'categoria',
        'titulo',
        'descripcion',
        'precio',
        'unidadCobro',
        'deposito',
        'capacidad',
        'condiciones',
        'departamento',
        'municipio',
        'direccionReferencia',
        'arrendador',
        'calificacion',
        'fotos',
        'creadoEn',
      ].sort(),
    );
  });

  it('toma de BienResponseDto la documentación de los campos compartidos', () => {
    const metadatos = (dto: object, propiedad: string): unknown =>
      Reflect.getMetadata(
        'swagger/apiModelProperties',
        (dto as { prototype: object }).prototype,
        propiedad,
      );

    for (const propiedad of [
      'id',
      'titulo',
      'precio',
      'unidadCobro',
      'creadoEn',
    ]) {
      // PickType agrega isArray: false al copiar; el resto debe ser idéntico.
      expect(metadatos(BienDetalleResponseDto, propiedad)).toMatchObject(
        metadatos(BienResponseDto, propiedad) as object,
      );
    }
    expect(propiedades(BienDetalleResponseDto)).not.toContain('estado');
  });
});
