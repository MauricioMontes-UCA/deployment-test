import { ApiProperty, PickType } from '@nestjs/swagger';
import { TipoBien } from '@PrismaClient';
import { BienResponseDto, FotoBienResponseDto } from './bien-response.dto.js';
import type { BienDetalle } from '@Bienes/repositories';

/** Foto del detalle: sin id, solo lo que necesita la galería. */
export class FotoDetalleResponseDto extends PickType(FotoBienResponseDto, [
  'url',
  'orden',
  'esPrincipal',
] as const) {
  static from(foto: BienDetalle['fotos'][number]): FotoDetalleResponseDto {
    return {
      url: foto.url,
      orden: foto.orden,
      esPrincipal: foto.esPrincipal,
    };
  }
}

/** Datos públicos del arrendador: nunca el email ni datos de autenticación. */
export class ArrendadorPublicoResponseDto {
  @ApiProperty({ format: 'uuid' })
  id!: string;

  @ApiProperty({ example: 'ana_m' })
  nombreUsuario!: string;
}

/** Detalle público del bien más su calificación (solo reseñas de tipo BIEN). */
export type BienDetalleConCalificacion = BienDetalle & {
  calificacion: { promedio: number | null; totalResenas: number };
};

/** Calificación del bien: solo cuenta reseñas de tipo BIEN. */
export class CalificacionBienResponseDto {
  @ApiProperty({
    type: Number,
    nullable: true,
    example: 4.5,
    description:
      'Promedio con un decimal. Es null (no 0) si el bien no tiene reseñas: un 0 se leería como una calificación real.',
  })
  promedio!: number | null;

  @ApiProperty({ example: 12 })
  totalResenas!: number;
}

/**
 * Detalle público de un bien publicado.
 *
 * Hereda de `BienResponseDto` las propiedades que significan lo mismo en los
 * dos contratos. No hereda `estado`, que el detalle no expone (solo muestra
 * bienes ACTIVA), ni `fotos`, porque aquí cada foto va sin su id.
 */
export class BienDetalleResponseDto extends PickType(BienResponseDto, [
  'id',
  'titulo',
  'precio',
  'unidadCobro',
  'creadoEn',
] as const) {
  @ApiProperty({
    enum: TipoBien,
    enumName: 'TipoBien',
    example: TipoBien.PROPIEDAD,
  })
  tipo!: TipoBien;

  @ApiProperty({ example: 'Salón de eventos' })
  categoria!: string;

  @ApiProperty({ example: 'Salón climatizado con cocina y parqueo.' })
  descripcion!: string;

  @ApiProperty({
    example: 0,
    description: '0 cuando el bien no pide depósito.',
  })
  deposito!: number;

  @ApiProperty({ type: Number, nullable: true, example: 120 })
  capacidad!: number | null;

  @ApiProperty({
    type: String,
    nullable: true,
    example: 'No se permite pirotecnia',
  })
  condiciones!: string | null;

  @ApiProperty({ example: 'San Salvador' })
  departamento!: string;

  @ApiProperty({ example: 'Antiguo Cuscatlán' })
  municipio!: string;

  @ApiProperty({
    type: String,
    nullable: true,
    example: 'Frente al parque central',
  })
  direccionReferencia!: string | null;

  @ApiProperty({ type: ArrendadorPublicoResponseDto })
  arrendador!: ArrendadorPublicoResponseDto;

  @ApiProperty({
    type: [FotoDetalleResponseDto],
    description: 'La foto principal primero; las demás por orden ascendente.',
  })
  fotos!: FotoDetalleResponseDto[];

  @ApiProperty({ type: CalificacionBienResponseDto })
  calificacion!: CalificacionBienResponseDto;

  static fromEntity(bien: BienDetalleConCalificacion): BienDetalleResponseDto {
    return {
      id: bien.id,
      tipo: bien.tipo,
      categoria: bien.categoria,
      titulo: bien.titulo,
      descripcion: bien.descripcion,
      // Prisma devuelve DECIMAL como Decimal; la API lo expone como número.
      precio: bien.precio.toNumber(),
      unidadCobro: bien.unidadCobro,
      deposito: bien.deposito.toNumber(),
      capacidad: bien.capacidad,
      condiciones: bien.condiciones,
      departamento: bien.departamento,
      municipio: bien.municipio,
      direccionReferencia: bien.direccionReferencia,
      arrendador: {
        id: bien.arrendador.id,
        nombreUsuario: bien.arrendador.nombreUsuario,
      },
      fotos: bien.fotos.map((foto) => FotoDetalleResponseDto.from(foto)),
      calificacion: {
        promedio: bien.calificacion.promedio,
        totalResenas: bien.calificacion.totalResenas,
      },
      creadoEn: bien.creadoEn,
    };
  }
}
