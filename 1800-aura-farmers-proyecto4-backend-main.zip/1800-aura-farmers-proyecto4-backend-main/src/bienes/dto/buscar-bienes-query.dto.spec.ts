import { plainToInstance } from 'class-transformer';
import { validate } from 'class-validator';
import { BuscarBienesQueryDto } from './buscar-bienes-query.dto.js';

// En la query string todo llega como texto.
async function validar(query: Record<string, unknown>) {
  const dto = plainToInstance(BuscarBienesQueryDto, query);
  const errores = await validate(dto);
  return { dto, campos: errores.map((e) => e.property) };
}

describe('BuscarBienesQueryDto', () => {
  it('sin parámetros usa la página 1 y 20 resultados', async () => {
    const { dto, campos } = await validar({});

    expect(campos).toEqual([]);
    expect(dto).toMatchObject({ pagina: 1, tamano: 20 });
    expect(dto.q).toBeUndefined();
  });

  it('convierte la página y el tamaño a número', async () => {
    const { dto, campos } = await validar({ pagina: '3', tamano: '50' });

    expect(campos).toEqual([]);
    expect(dto).toMatchObject({ pagina: 3, tamano: 50 });
  });

  it('recorta el texto y la ubicación', async () => {
    const { dto } = await validar({
      q: '  salon  ',
      departamento: ' San Salvador ',
      municipio: ' Antiguo Cuscatlán ',
    });

    expect(dto).toMatchObject({
      q: 'salon',
      departamento: 'San Salvador',
      municipio: 'Antiguo Cuscatlán',
    });
  });

  it.each(['', '   '])('trata q = %j como búsqueda sin texto', async (q) => {
    const { dto, campos } = await validar({ q });

    expect(campos).toEqual([]);
    expect(dto.q).toBeUndefined();
  });

  it('acepta un q de exactamente 100 caracteres', async () => {
    expect((await validar({ q: 'a'.repeat(100) })).campos).toEqual([]);
  });

  it('rechaza un q de más de 100 caracteres', async () => {
    expect((await validar({ q: 'a'.repeat(101) })).campos).toEqual(['q']);
  });

  it('acepta la página máxima', async () => {
    const { dto, campos } = await validar({ pagina: '10000' });
    expect(campos).toEqual([]);
    expect(dto.pagina).toBe(10_000);
  });

  it.each(['0', '-1', '1.5', 'abc', '10001', '9999999999999999999'])(
    'rechaza la página %j',
    async (pagina) => {
      expect((await validar({ pagina })).campos).toEqual(['pagina']);
    },
  );

  it.each(['0', '51', '-5', '2.5', 'abc'])(
    'rechaza el tamaño %j',
    async (tamano) => {
      expect((await validar({ tamano })).campos).toEqual(['tamano']);
    },
  );

  it('rechaza el carácter nulo, que Postgres no admite en un texto', async () => {
    const { campos } = await validar({
      q: 'sa\u0000lon',
      departamento: 'San\u0000',
      municipio: 'Mejicanos\u0000',
    });

    expect(campos.sort()).toEqual(['departamento', 'municipio', 'q']);
  });

  it('acepta comillas y símbolos en el texto', async () => {
    expect((await validar({ q: `"salon" -casa ' ; -- ()` })).campos).toEqual(
      [],
    );
  });
});
