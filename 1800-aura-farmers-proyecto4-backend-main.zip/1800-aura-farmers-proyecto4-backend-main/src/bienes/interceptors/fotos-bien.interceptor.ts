import {
  BadRequestException,
  HttpException,
  Injectable,
  type CallHandler,
  type ExecutionContext,
  type NestInterceptor,
} from '@nestjs/common';
import multer from 'multer';
import type { Request, Response } from 'express';
import type { Observable } from 'rxjs';
import {
  CAMPO_FOTOS,
  MAX_CAMPOS_FORMULARIO,
  MAX_FOTO_BYTES,
  MAX_FOTO_MB,
  MAX_FOTOS,
  MAX_PARTES_FORMULARIO,
} from '@Bienes/constants';

/**
 * Recibe las fotos del campo `fotos` con multer y las deja en `request.files`.
 *
 * Cumple el mismo papel que `FilesInterceptor` de Nest, pero traduce los
 * errores de multer a 400 con un mensaje claro. `FilesInterceptor` responde
 * 413 a una foto de más de 5 MB y "Unexpected field" a la foto número 11, y
 * H1 pide un 400 que diga qué corregir en ambos casos.
 *
 * Los archivos quedan en memoria (como máximo 10 de 5 MB) porque el servicio
 * los escribe recién cuando todo el formulario es válido.
 *
 * También se limitan los campos de texto y las partes: sin eso, un formulario
 * con miles de campos se lee completo en memoria antes de que el
 * ValidationPipe lo rechace.
 */
@Injectable()
export class FotosBienInterceptor implements NestInterceptor {
  private readonly recibirFotos = multer({
    storage: multer.memoryStorage(),
    limits: {
      fileSize: MAX_FOTO_BYTES,
      fields: MAX_CAMPOS_FORMULARIO,
      parts: MAX_PARTES_FORMULARIO,
    },
  }).array(CAMPO_FOTOS, MAX_FOTOS);

  async intercept(
    context: ExecutionContext,
    next: CallHandler,
  ): Promise<Observable<unknown>> {
    const http = context.switchToHttp();

    await new Promise<void>((resolve, reject) => {
      this.recibirFotos(
        http.getRequest<Request>(),
        http.getResponse<Response>(),
        (error: unknown) =>
          error ? reject(traducirErrorDeMulter(error)) : resolve(),
      );
    });

    return next.handle();
  }
}

/** Convierte un error de multer o de busboy en un 400 con mensaje en español. */
export function traducirErrorDeMulter(error: unknown): HttpException {
  if (error instanceof HttpException) return error;

  if (error instanceof multer.MulterError) {
    switch (error.code) {
      case 'LIMIT_FILE_SIZE':
        return new BadRequestException([
          `Cada foto debe pesar como máximo ${MAX_FOTO_MB} MB.`,
        ]);
      case 'LIMIT_UNEXPECTED_FILE':
        // multer usa el mismo código para un campo desconocido y para la foto
        // que pasa del máximo del campo `fotos`.
        return new BadRequestException([
          error.field === CAMPO_FOTOS
            ? `Se pueden subir como máximo ${MAX_FOTOS} fotos.`
            : `El campo ${error.field ?? 'recibido'} no admite archivos.`,
        ]);
      case 'LIMIT_FIELD_COUNT':
      case 'LIMIT_PART_COUNT':
        return new BadRequestException([
          'El formulario tiene más campos de los permitidos.',
        ]);
      default:
        return new BadRequestException([error.message]);
    }
  }

  // Lo demás viene de busboy al leer un cuerpo multipart mal formado.
  return new BadRequestException(['El formulario multipart está mal formado.']);
}
