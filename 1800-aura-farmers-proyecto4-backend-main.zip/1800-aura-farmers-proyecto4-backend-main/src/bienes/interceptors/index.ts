export * from './fotos-bien.interceptor.js';
