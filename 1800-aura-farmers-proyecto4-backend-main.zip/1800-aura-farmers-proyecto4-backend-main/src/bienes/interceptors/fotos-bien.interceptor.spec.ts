import { BadRequestException, ForbiddenException } from '@nestjs/common';
import multer from 'multer';
import { traducirErrorDeMulter } from './fotos-bien.interceptor.js';

function mensaje(error: unknown): string {
  const traducido = traducirErrorDeMulter(error);
  expect(traducido).toBeInstanceOf(BadRequestException);
  return (traducido.getResponse() as { message: string[] }).message[0]!;
}

describe('traducirErrorDeMulter', () => {
  it('responde 400 y no 413 a una foto de más de 5 MB', () => {
    expect(mensaje(new multer.MulterError('LIMIT_FILE_SIZE', 'fotos'))).toBe(
      'Cada foto debe pesar como máximo 5 MB.',
    );
  });

  it('explica el máximo cuando sobran fotos', () => {
    expect(
      mensaje(new multer.MulterError('LIMIT_UNEXPECTED_FILE', 'fotos')),
    ).toBe('Se pueden subir como máximo 10 fotos.');
  });

  it('distingue un archivo en otro campo', () => {
    expect(
      mensaje(new multer.MulterError('LIMIT_UNEXPECTED_FILE', 'portada')),
    ).toBe('El campo portada no admite archivos.');
  });

  it.each(['LIMIT_FIELD_COUNT', 'LIMIT_PART_COUNT'] as const)(
    'responde 400 cuando el formulario pasa del límite (%s)',
    (codigo) => {
      expect(mensaje(new multer.MulterError(codigo))).toBe(
        'El formulario tiene más campos de los permitidos.',
      );
    },
  );

  it('responde 400 a un multipart mal formado', () => {
    expect(mensaje(new Error('Unexpected end of form'))).toBe(
      'El formulario multipart está mal formado.',
    );
  });

  it('deja pasar las excepciones HTTP', () => {
    const forbidden = new ForbiddenException();
    expect(traducirErrorDeMulter(forbidden)).toBe(forbidden);
  });
});
