import { Injectable } from '@nestjs/common';
import { PrismaService } from '@Prisma/services';
import { EstadoReserva, Prisma } from '@PrismaClient';

/** Rango inclusivo de días completos (ambos extremos están ocupados). */
export interface RangoFechas {
  fechaInicio: Date;
  fechaFin: Date;
}

export interface Disponibilidad {
  bienId: string;
  reservados: RangoFechas[];
  bloqueados: RangoFechas[];
}

/**
 * Estados de reserva que ocupan los días del bien.
 *
 * Son los mismos que la restricción de exclusión de la base impide solapar
 * (CONFIRMADA, EN_CURSO y FINALIZADA). EN_COLA, RECHAZADA y CANCELADA no ocupan
 * días: pueden solaparse y no se muestran.
 */
export const ESTADOS_QUE_OCUPAN: EstadoReserva[] = [
  EstadoReserva.CONFIRMADA,
  EstadoReserva.EN_CURSO,
  EstadoReserva.FINALIZADA,
];

/**
 * Regla única de cruce de rangos: dos rangos de días inclusivos se cruzan si
 * cada uno empieza antes de que termine el otro (basta un día en común).
 *
 * La usan el calendario (`findOcupados`, con Prisma) y la búsqueda con filtro
 * de fechas (`ocupadoEnPeriodoSql`, en SQL crudo porque va dentro de
 * `$queryRaw`). Las dos versiones están aquí juntas para que no se separen; si
 * cambia una, hay que cambiar la otra, y `test/bienes-filtros.e2e-spec.ts`
 * comprueba que el calendario y la búsqueda dan la misma respuesta.
 */
export function cruzaConPeriodo(desde: Date, hasta: Date) {
  return { fechaInicio: { lte: hasta }, fechaFin: { gte: desde } };
}

/**
 * Condición SQL: el bien (`bienId`, una columna de la consulta externa) tiene
 * en el periodo alguna reserva que ocupa días (`ESTADOS_QUE_OCUPAN`) o algún
 * bloqueo. Misma regla que `cruzaConPeriodo`.
 *
 * Las fechas entran como texto `AAAA-MM-DD` con `::date`: un `Date` llegaría
 * como timestamptz y, según la zona de la sesión, podría correr un día.
 */
export function ocupadoEnPeriodoSql(
  bienId: Prisma.Sql,
  desde: string,
  hasta: string,
): Prisma.Sql {
  const estados = Prisma.join(
    ESTADOS_QUE_OCUPAN.map((estado) => Prisma.sql`${estado}::"EstadoReserva"`),
  );
  return Prisma.sql`(
    EXISTS (
      SELECT 1 FROM "Reservas" r
      WHERE r.bien_id = ${bienId}
        AND r.estado IN (${estados})
        AND r.fecha_inicio <= ${hasta}::date
        AND r.fecha_fin >= ${desde}::date
    )
    OR EXISTS (
      SELECT 1 FROM "BloqueosFecha" bf
      WHERE bf.bien_id = ${bienId}
        AND bf.fecha_inicio <= ${hasta}::date
        AND bf.fecha_fin >= ${desde}::date
    )
  )`;
}

/** Lectura de rangos ocupados de un bien; usa los índices por bien y fecha. */
@Injectable()
export class DisponibilidadRepository {
  constructor(private readonly prisma: PrismaService) {}

  /**
   * Rangos de `desde` a `hasta` (inclusive) con reservas y bloqueos.
   *
   * Trae todo rango que se cruce con la ventana, no solo los contenidos en
   * ella: una reserva que empieza antes de `desde` y termina dentro también
   * ocupa días de la ventana. Solo se seleccionan las fechas, nunca al
   * arrendatario.
   */
  async findOcupados(
    bienId: string,
    desde: Date,
    hasta: Date,
  ): Promise<Omit<Disponibilidad, 'bienId'>> {
    const cruzaConLaVentana = { bienId, ...cruzaConPeriodo(desde, hasta) };
    const soloFechas = { fechaInicio: true, fechaFin: true } as const;
    const porInicio = { fechaInicio: 'asc' } as const;

    const [reservados, bloqueados] = await Promise.all([
      this.prisma.reserva.findMany({
        where: { ...cruzaConLaVentana, estado: { in: ESTADOS_QUE_OCUPAN } },
        select: soloFechas,
        orderBy: porInicio,
      }),
      this.prisma.bloqueoFecha.findMany({
        where: cruzaConLaVentana,
        select: soloFechas,
        orderBy: porInicio,
      }),
    ]);

    return { reservados, bloqueados };
  }
}
