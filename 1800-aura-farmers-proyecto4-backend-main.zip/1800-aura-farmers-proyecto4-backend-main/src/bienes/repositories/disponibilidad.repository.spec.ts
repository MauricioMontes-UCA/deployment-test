import {
  DisponibilidadRepository,
  ESTADOS_QUE_OCUPAN,
} from './disponibilidad.repository.js';
import type { PrismaService } from '@Prisma/services';

const BIEN_ID = '7c9e6679-7425-40de-944b-e07fc1f90ae7';
const DESDE = new Date('2026-11-01T00:00:00.000Z');
const HASTA = new Date('2027-10-31T00:00:00.000Z');

function crear() {
  const prisma = {
    reserva: { findMany: vi.fn().mockResolvedValue([]) },
    bloqueoFecha: { findMany: vi.fn().mockResolvedValue([]) },
  };
  const repository = new DisponibilidadRepository(
    prisma as unknown as PrismaService,
  );
  return { repository, prisma };
}

describe('DisponibilidadRepository.findOcupados', () => {
  it('solo cuenta como reservados los estados que ocupan días', () => {
    expect([...ESTADOS_QUE_OCUPAN].sort()).toEqual([
      'CONFIRMADA',
      'EN_CURSO',
      'FINALIZADA',
    ]);
  });

  it('pide las reservas que cruzan la ventana, solo con estados que ocupan', async () => {
    const { repository, prisma } = crear();

    await repository.findOcupados(BIEN_ID, DESDE, HASTA);

    expect(prisma.reserva.findMany).toHaveBeenCalledWith({
      where: {
        bienId: BIEN_ID,
        fechaInicio: { lte: HASTA },
        fechaFin: { gte: DESDE },
        estado: { in: ESTADOS_QUE_OCUPAN },
      },
      select: { fechaInicio: true, fechaFin: true },
      orderBy: { fechaInicio: 'asc' },
    });
  });

  it('pide los bloqueos que cruzan la ventana', async () => {
    const { repository, prisma } = crear();

    await repository.findOcupados(BIEN_ID, DESDE, HASTA);

    expect(prisma.bloqueoFecha.findMany).toHaveBeenCalledWith({
      where: {
        bienId: BIEN_ID,
        fechaInicio: { lte: HASTA },
        fechaFin: { gte: DESDE },
      },
      select: { fechaInicio: true, fechaFin: true },
      orderBy: { fechaInicio: 'asc' },
    });
  });

  it('nunca selecciona datos del arrendatario', async () => {
    const { repository, prisma } = crear();

    await repository.findOcupados(BIEN_ID, DESDE, HASTA);

    const { select } = prisma.reserva.findMany.mock.calls[0]![0];
    expect(Object.keys(select)).toEqual(['fechaInicio', 'fechaFin']);
  });
});
