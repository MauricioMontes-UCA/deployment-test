import { Injectable } from '@nestjs/common';
import { PrismaService } from '@Prisma/services';
import {
  EstadoBien,
  Prisma,
  type TipoBien,
  type UnidadCobro,
} from '@PrismaClient';
import type { BienConFotos } from '@Bienes/types';
import { ocupadoEnPeriodoSql } from './disponibilidad.repository.js';

export interface CreateFotoBienData {
  url: string;
  orden: number;
  esPrincipal: boolean;
}

export interface CreateBienData {
  /** Lo genera el servicio, porque la carpeta de las fotos lo usa antes del insert. */
  id: string;
  arrendadorId: string;
  tipo: TipoBien;
  categoria: string;
  titulo: string;
  descripcion: string;
  precio: number;
  unidadCobro: UnidadCobro;
  deposito?: number;
  capacidad?: number;
  condiciones?: string;
  departamento: string;
  municipio: string;
  direccionReferencia?: string;
  fotos: CreateFotoBienData[];
}

/**
 * Columnas del detalle público de un bien.
 *
 * Es un `select` y no un `include` para que los datos privados no se lean de
 * la base: del arrendador solo salen el id y el nombre de usuario, nunca el
 * email ni el hash de la contraseña.
 */
export const BIEN_DETALLE_SELECT = {
  id: true,
  tipo: true,
  categoria: true,
  titulo: true,
  descripcion: true,
  precio: true,
  unidadCobro: true,
  deposito: true,
  capacidad: true,
  condiciones: true,
  departamento: true,
  municipio: true,
  direccionReferencia: true,
  creadoEn: true,
  arrendador: { select: { id: true, nombreUsuario: true } },
  fotos: {
    select: { url: true, orden: true, esPrincipal: true },
    // La principal primero; las demás en el orden en que se publicaron.
    orderBy: [{ esPrincipal: 'desc' }, { orden: 'asc' }],
  },
} satisfies Prisma.BienSelect;

/** Detalle público de un bien, tal como lo devuelve `BienRepository`. */
export type BienDetalle = Prisma.BienGetPayload<{
  select: typeof BIEN_DETALLE_SELECT;
}>;

/**
 * Columnas de un bien en «Mis bienes» (BE-1.3): lo que necesita la tarjeta, sin
 * la descripción ni los datos del arrendador (que es quien consulta).
 */
export const MI_BIEN_SELECT = {
  id: true,
  titulo: true,
  tipo: true,
  categoria: true,
  estado: true,
  precio: true,
  unidadCobro: true,
  deposito: true,
  departamento: true,
  municipio: true,
  creadoEn: true,
  fotos: {
    where: { esPrincipal: true },
    select: { url: true },
    take: 1,
  },
  // Sin registro, la política es «cualquiera puede reservar» (false).
  politicaVerificacion: { select: { soloVerificados: true } },
} satisfies Prisma.BienSelect;

/** Un bien de «Mis bienes», tal como lo devuelve `BienRepository`. */
export type MiBien = Prisma.BienGetPayload<{ select: typeof MI_BIEN_SELECT }>;

export interface PaginaMisBienes {
  bienes: MiBien[];
  /** Bienes del arrendador, sin contar la paginación. */
  total: number;
}

/** Por qué no se puede iniciar una conversación sobre el bien. */
export type RechazoConversacion = 'NO_EXISTE' | 'INACTIVA';

/**
 * Resultado de `findParaConversacion`: el arrendador del bien si se puede
 * conversar sobre él, o el motivo por el que no.
 */
export type BienParaConversacion =
  { arrendadorId: string } | { rechazo: RechazoConversacion };

/** Criterios de la búsqueda de bienes. Todos son opcionales. */
export interface FiltrosBusqueda {
  /** Texto libre, ya recortado. Si falta, no se filtra ni se ordena por texto. */
  q?: string;
  departamento?: string;
  municipio?: string;
  precioMin?: number;
  precioMax?: number;
  tipo?: TipoBien;
  categoria?: string;
  capacidadMin?: number;
  /** Excluye los bienes ocupados en este periodo (días YYYY-MM-DD, inclusive). */
  periodo?: { fechaInicio: string; fechaFin: string };
}

/** Un bien en el listado de resultados. */
export interface BienEncontrado {
  id: string;
  titulo: string;
  /** URL de la foto principal; `null` si el bien no tiene ninguna. */
  fotoPrincipal: string | null;
  precio: number;
  unidadCobro: UnidadCobro;
  departamento: string;
  municipio: string;
}

export interface PaginaDeBienes {
  /** Bienes que cumplen los criterios, sin contar la paginación. */
  total: number;
  resultados: BienEncontrado[];
}

/**
 * Cuándo un bien tiene publicación visible: ACTIVA y de un arrendador activo.
 * Lo comparten el detalle público y la comprobación del listado de reseñas, para
 * que la regla viva en un solo sitio. (`findParaConversacion` y
 * `findActivoParaReserva` aplican otras reglas, porque distinguen o relajan
 * motivos de rechazo.)
 */
const PUBLICACION_VISIBLE = {
  estado: EstadoBien.ACTIVA,
  arrendador: { isActive: true },
} satisfies Prisma.BienWhereInput;

/** Único punto del módulo que habla con las tablas `Bienes` y `FotosBien`. */
@Injectable()
export class BienRepository {
  constructor(private readonly prisma: PrismaService) {}

  /**
   * Crea el bien con todas sus fotos.
   *
   * Es una escritura anidada, y Prisma la ejecuta en una sola transacción: si
   * falla el insert de cualquier foto, el bien tampoco queda guardado. El
   * estado no se envía porque la columna ya nace en ACTIVA.
   */
  create({ fotos, ...bien }: CreateBienData): Promise<BienConFotos> {
    return this.prisma.bien.create({
      data: {
        ...bien,
        fotos: { createMany: { data: fotos } },
      },
      include: { fotos: { orderBy: { orden: 'asc' } } },
    });
  }

  /**
   * Bien ACTIVA con el dato que hace falta para solicitar una reserva (su
   * dueño), o null si no existe o está INACTIVA: un bien inactivo no es
   * reservable.
   */
  findActivoParaReserva(
    id: string,
  ): Promise<{ id: string; arrendadorId: string } | null> {
    return this.prisma.bien.findFirst({
      where: { id, estado: EstadoBien.ACTIVA },
      select: { id: true, arrendadorId: true },
    });
  }

  /**
   * Detalle público de un bien ACTIVA de un arrendador activo, con su
   * arrendador y sus fotos.
   *
   * Devuelve null si el bien no existe, está INACTIVA o su arrendador está
   * desactivado: para quien consulta, los tres casos son la misma publicación
   * no disponible.
   */
  findActivoConDetalle(id: string): Promise<BienDetalle | null> {
    return this.prisma.bien.findFirst({
      where: { id, ...PUBLICACION_VISIBLE },
      select: BIEN_DETALLE_SELECT,
    });
  }

  /**
   * Los bienes del arrendador, ACTIVA e INACTIVA, del más reciente al más
   * antiguo (BE-1.3). `id` desempata para que la paginación sea estable.
   *
   * El arrendador viene siempre de la sesión: nunca de la petición.
   */
  async findMios(
    arrendadorId: string,
    desplazamiento: number,
    limite: number,
  ): Promise<PaginaMisBienes> {
    const where = { arrendadorId } satisfies Prisma.BienWhereInput;

    const [total, bienes] = await this.prisma.$transaction([
      this.prisma.bien.count({ where }),
      this.prisma.bien.findMany({
        where,
        select: MI_BIEN_SELECT,
        orderBy: [{ creadoEn: 'desc' }, { id: 'desc' }],
        skip: desplazamiento,
        take: limite,
      }),
    ]);

    return { bienes, total };
  }

  /**
   * Indica si el bien tiene publicación visible: ACTIVA y de un arrendador
   * activo, el mismo criterio del detalle público.
   */
  async estaPublicado(id: string): Promise<boolean> {
    const total = await this.prisma.bien.count({
      where: { id, ...PUBLICACION_VISIBLE },
    });
    return total > 0;
  }

  /**
   * Indica si se puede iniciar una conversación sobre el bien y, si se puede,
   * quién es su arrendador.
   *
   * Hace falta que el bien esté ACTIVA y que su arrendador esté activo. Un
   * bien de un arrendador desactivado se trata como inexistente, igual que en
   * el detalle público, porque para quien consulta no hay publicación. Un bien
   * INACTIVA se distingue porque la API lo rechaza con otro código.
   */
  async findParaConversacion(id: string): Promise<BienParaConversacion> {
    const bien = await this.prisma.bien.findUnique({
      where: { id },
      select: {
        arrendadorId: true,
        estado: true,
        arrendador: { select: { isActive: true } },
      },
    });

    if (!bien || !bien.arrendador.isActive) return { rechazo: 'NO_EXISTE' };
    if (bien.estado !== EstadoBien.ACTIVA) return { rechazo: 'INACTIVA' };
    return { arrendadorId: bien.arrendadorId };
  }

  /** Indica si el bien existe y está ACTIVA (un bien INACTIVA no es reservable). */
  async existsActive(id: string): Promise<boolean> {
    const total = await this.prisma.bien.count({
      where: { id, estado: EstadoBien.ACTIVA },
    });
    return total > 0;
  }

  /**
   * Busca bienes ACTIVA y devuelve una página.
   *
   * Prisma no puede consultar la columna `busqueda` (`Unsupported`), así que
   * va con `$queryRaw`. Los valores siempre entran como parámetros de la
   * plantilla: nunca se concatena el texto del usuario en el SQL.
   *
   * Con texto, primero salen los bienes cuyo título coincide, después los que
   * coinciden solo en la descripción. Dentro de cada grupo, y sin texto, el
   * orden es del más reciente al más antiguo, con `id` para desempatar: sin
   * eso, dos bienes creados al mismo instante podrían cambiar de lugar entre
   * una página y la siguiente.
   */
  async buscar(
    {
      q,
      departamento,
      municipio,
      precioMin,
      precioMax,
      tipo,
      categoria,
      capacidadMin,
      periodo,
    }: FiltrosBusqueda,
    limite: number,
    desplazamiento: number,
  ): Promise<PaginaDeBienes> {
    // La consulta de texto se calcula una sola vez y se une a la tabla.
    const origen = q
      ? Prisma.sql`"Bienes" b CROSS JOIN websearch_to_tsquery('spanish', f_unaccent(${q}::text)) AS consulta`
      : Prisma.sql`"Bienes" b`;

    const condiciones = [Prisma.sql`b.estado = 'ACTIVA'`];
    if (q) condiciones.push(Prisma.sql`b.busqueda @@ consulta`);
    if (departamento) {
      condiciones.push(Prisma.sql`b.departamento = ${departamento}`);
    }
    if (municipio) condiciones.push(Prisma.sql`b.municipio = ${municipio}`);
    if (precioMin !== undefined) {
      condiciones.push(
        Prisma.sql`b.precio >= ${precioMin.toFixed(2)}::numeric`,
      );
    }
    if (precioMax !== undefined) {
      condiciones.push(
        Prisma.sql`b.precio <= ${precioMax.toFixed(2)}::numeric`,
      );
    }
    if (tipo) condiciones.push(Prisma.sql`b.tipo = ${tipo}::"TipoBien"`);
    if (categoria) condiciones.push(Prisma.sql`b.categoria = ${categoria}`);
    if (capacidadMin !== undefined) {
      // Un bien sin capacidad registrada (NULL) no cumple la comparación.
      condiciones.push(Prisma.sql`b.capacidad >= ${capacidadMin}`);
    }
    if (periodo) {
      condiciones.push(
        Prisma.sql`NOT ${ocupadoEnPeriodoSql(Prisma.sql`b.id`, periodo.fechaInicio, periodo.fechaFin)}`,
      );
    }
    const donde = Prisma.join(condiciones, ' AND ');

    // El título coincide si la consulta encaja con la parte de peso A de la
    // columna `busqueda`, que es justamente el título. Equivale a
    // to_tsvector('spanish', f_unaccent(titulo)) @@ consulta, pero reutiliza
    // la columna ya guardada en vez de volver a analizar el título por fila.
    const orden = q
      ? Prisma.sql`(ts_filter(b.busqueda, '{a}') @@ consulta) DESC, b.creado_en DESC, b.id DESC`
      : Prisma.sql`b.creado_en DESC, b.id DESC`;

    const [[{ total }], filas] = await Promise.all([
      this.prisma.$queryRaw<[{ total: bigint }]>`
        SELECT COUNT(*) AS total FROM ${origen} WHERE ${donde}`,
      this.prisma.$queryRaw<FilaBusqueda[]>`
        SELECT b.id, b.titulo, b.precio, b.unidad_cobro AS "unidadCobro",
               b.departamento, b.municipio,
               (SELECT f.url FROM "FotosBien" f
                 WHERE f.bien_id = b.id AND f.es_principal) AS "fotoPrincipal"
        FROM ${origen}
        WHERE ${donde}
        ORDER BY ${orden}
        LIMIT ${limite} OFFSET ${desplazamiento}`,
    ]);

    return {
      total: Number(total),
      resultados: filas.map((fila) => ({
        ...fila,
        // `precio` es NUMERIC: el driver lo entrega como Decimal.
        precio: Number(fila.precio),
      })),
    };
  }
}

/** Fila tal como la devuelve la consulta, antes de convertir el precio. */
type FilaBusqueda = Omit<BienEncontrado, 'precio'> & {
  precio: Prisma.Decimal | number | string;
};
