import { BIEN_DETALLE_SELECT, BienRepository } from './bien.repository.js';
import type { PrismaService } from '@Prisma/services';

const BIEN_ID = '7c9e6679-7425-40de-944b-e07fc1f90ae7';

function crear(resultado: unknown = null) {
  const prisma = {
    bien: { findFirst: vi.fn().mockResolvedValue(resultado) },
  };
  const repository = new BienRepository(prisma as unknown as PrismaService);
  return { repository, prisma };
}

describe('BienRepository.findActivoConDetalle', () => {
  it('busca por id solo entre los bienes ACTIVA de arrendadores activos, con el select del detalle', async () => {
    const { repository, prisma } = crear();

    await repository.findActivoConDetalle(BIEN_ID);

    expect(prisma.bien.findFirst).toHaveBeenCalledWith({
      where: {
        id: BIEN_ID,
        estado: 'ACTIVA',
        arrendador: { isActive: true },
      },
      select: BIEN_DETALLE_SELECT,
    });
  });

  it('devuelve null si la base no encuentra el bien', async () => {
    const { repository } = crear(null);

    await expect(repository.findActivoConDetalle(BIEN_ID)).resolves.toBeNull();
  });

  it('del arrendador solo lee id y nombre de usuario', () => {
    expect(BIEN_DETALLE_SELECT.arrendador).toEqual({
      select: { id: true, nombreUsuario: true },
    });
  });

  it('ordena las fotos con la principal primero y luego por orden', () => {
    expect(BIEN_DETALLE_SELECT.fotos).toEqual({
      select: { url: true, orden: true, esPrincipal: true },
      orderBy: [{ esPrincipal: 'desc' }, { orden: 'asc' }],
    });
  });

  it('no lee columnas internas del bien', () => {
    const columnas = Object.keys(BIEN_DETALLE_SELECT);

    for (const interna of [
      'arrendadorId',
      'estado',
      'actualizadoEn',
      'busqueda',
    ]) {
      expect(columnas).not.toContain(interna);
    }
  });
});

describe('BienRepository.findParaConversacion', () => {
  function conBien(bien: unknown) {
    const prisma = {
      bien: { findUnique: vi.fn().mockResolvedValue(bien) },
    };
    const repository = new BienRepository(prisma as unknown as PrismaService);
    return { repository, prisma };
  }

  it('lee solo el estado, el arrendador y si está activo', async () => {
    const { repository, prisma } = conBien(null);

    await repository.findParaConversacion(BIEN_ID);

    expect(prisma.bien.findUnique).toHaveBeenCalledWith({
      where: { id: BIEN_ID },
      select: {
        arrendadorId: true,
        estado: true,
        arrendador: { select: { isActive: true } },
      },
    });
  });

  it('devuelve el arrendador si el bien está ACTIVA y su arrendador activo', async () => {
    const { repository } = conBien({
      arrendadorId: 'arrendador-1',
      estado: 'ACTIVA',
      arrendador: { isActive: true },
    });

    await expect(repository.findParaConversacion(BIEN_ID)).resolves.toEqual({
      arrendadorId: 'arrendador-1',
    });
  });

  it('rechaza con NO_EXISTE si el bien no existe', async () => {
    const { repository } = conBien(null);

    await expect(repository.findParaConversacion(BIEN_ID)).resolves.toEqual({
      rechazo: 'NO_EXISTE',
    });
  });

  it('trata el bien de un arrendador desactivado como inexistente', async () => {
    const { repository } = conBien({
      arrendadorId: 'arrendador-1',
      estado: 'ACTIVA',
      arrendador: { isActive: false },
    });

    await expect(repository.findParaConversacion(BIEN_ID)).resolves.toEqual({
      rechazo: 'NO_EXISTE',
    });
  });

  it('rechaza con INACTIVA si el bien está INACTIVA', async () => {
    const { repository } = conBien({
      arrendadorId: 'arrendador-1',
      estado: 'INACTIVA',
      arrendador: { isActive: true },
    });

    await expect(repository.findParaConversacion(BIEN_ID)).resolves.toEqual({
      rechazo: 'INACTIVA',
    });
  });
});

describe('BienRepository.estaPublicado', () => {
  it.each([
    [1, true],
    [0, false],
  ])('con %i coincidencias responde %s', async (cuenta, esperado) => {
    const prisma = { bien: { count: vi.fn().mockResolvedValue(cuenta) } };
    const repository = new BienRepository(prisma as unknown as PrismaService);

    await expect(repository.estaPublicado(BIEN_ID)).resolves.toBe(esperado);
    expect(prisma.bien.count).toHaveBeenCalledWith({
      where: { id: BIEN_ID, estado: 'ACTIVA', arrendador: { isActive: true } },
    });
  });
});
