import { BienRepository, MI_BIEN_SELECT } from './bien.repository.js';
import type { PrismaService } from '@Prisma/services';

const ARRENDADOR_ID = '11111111-1111-4111-8111-111111111111';

function crear({ total = 0, bienes = [] as unknown[] } = {}) {
  const count = vi.fn().mockReturnValue('count');
  const findMany = vi.fn().mockReturnValue('findMany');
  const prisma = {
    bien: { count, findMany },
    $transaction: vi.fn().mockResolvedValue([total, bienes]),
  };
  const repository = new BienRepository(prisma as unknown as PrismaService);
  return { repository, prisma, count, findMany };
}

describe('BienRepository.findMios', () => {
  it('filtra por el arrendador, sin filtrar por estado, para el conteo y la página', async () => {
    const { repository, count, findMany } = crear();

    await repository.findMios(ARRENDADOR_ID, 0, 20);

    expect(count).toHaveBeenCalledWith({
      where: { arrendadorId: ARRENDADOR_ID },
    });
    const { where } = findMany.mock.calls[0]![0] as { where: object };
    expect(where).toEqual({ arrendadorId: ARRENDADOR_ID });
    expect(where).not.toHaveProperty('estado');
  });

  it('ordena por creadoEn descendente con id como desempate, y pagina', async () => {
    const { repository, findMany } = crear();

    await repository.findMios(ARRENDADOR_ID, 40, 20);

    expect(findMany).toHaveBeenCalledWith({
      where: { arrendadorId: ARRENDADOR_ID },
      select: MI_BIEN_SELECT,
      orderBy: [{ creadoEn: 'desc' }, { id: 'desc' }],
      skip: 40,
      take: 20,
    });
  });

  it('cuenta y consulta en una sola transacción', async () => {
    const { repository, prisma } = crear();

    await repository.findMios(ARRENDADOR_ID, 0, 20);

    expect(prisma.$transaction).toHaveBeenCalledWith(['count', 'findMany']);
  });

  it('devuelve los bienes y el total', async () => {
    const bienes = [{ id: 'a' }];
    const { repository } = crear({ total: 7, bienes });

    await expect(repository.findMios(ARRENDADOR_ID, 0, 20)).resolves.toEqual({
      bienes,
      total: 7,
    });
  });

  it('selecciona la foto principal (una) y la política, y no la descripción ni el arrendador', () => {
    expect(MI_BIEN_SELECT.fotos).toEqual({
      where: { esPrincipal: true },
      select: { url: true },
      take: 1,
    });
    expect(MI_BIEN_SELECT.politicaVerificacion).toEqual({
      select: { soloVerificados: true },
    });
    expect(MI_BIEN_SELECT).not.toHaveProperty('descripcion');
    expect(MI_BIEN_SELECT).not.toHaveProperty('arrendador');
    expect(MI_BIEN_SELECT).not.toHaveProperty('arrendadorId');
  });
});
