/** Nombre del campo multipart que trae las fotos. */
export const CAMPO_FOTOS = 'fotos';

/** Un bien se publica con 1 a 10 fotos (H1). */
export const MIN_FOTOS = 1;
export const MAX_FOTOS = 10;

/** Peso máximo de cada foto. */
export const MAX_FOTO_MB = 5;
export const MAX_FOTO_BYTES = MAX_FOTO_MB * 1024 * 1024;

/**
 * Campos de texto que acepta el formulario. El DTO tiene 13; el margen evita
 * rechazar un formulario válido si se agrega un campo.
 */
export const MAX_CAMPOS_FORMULARIO = 20;

/** Partes del multipart: los campos de texto más las fotos. */
export const MAX_PARTES_FORMULARIO = MAX_CAMPOS_FORMULARIO + MAX_FOTOS;
