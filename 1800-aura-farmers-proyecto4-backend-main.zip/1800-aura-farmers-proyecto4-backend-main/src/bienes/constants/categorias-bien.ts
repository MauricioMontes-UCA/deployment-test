import { TipoBien } from '@PrismaClient';

/**
 * Categorías que admite cada tipo de bien, tal como las define H1.
 *
 * Se guardan con el mismo texto que ve el usuario ("Salón de eventos"), igual
 * que en los datos de prueba del seed, para que los filtros de búsqueda (H4)
 * comparen contra un único conjunto de valores.
 */
export const CATEGORIAS_POR_TIPO = {
  [TipoBien.PROPIEDAD]: [
    'Casa',
    'Apartamento',
    'Habitación',
    'Salón de eventos',
    'Oficina',
    'Local comercial',
    'Bodega',
    'Terreno',
  ],
  [TipoBien.EQUIPO]: [
    'Herramientas',
    'Maquinaria de construcción',
    'Audio y sonido',
    'Video y fotografía',
    'Cómputo',
    'Mobiliario para eventos',
    'Deportes y recreación',
    'Jardinería',
  ],
} as const satisfies Record<TipoBien, readonly string[]>;

const TIPOS_BIEN: readonly unknown[] = Object.values(TipoBien);

export function esTipoBien(valor: unknown): valor is TipoBien {
  return TIPOS_BIEN.includes(valor);
}

/** Indica si `categoria` es una de las categorías del tipo `tipo`. */
export function esCategoriaDelTipo(
  tipo: TipoBien,
  categoria: unknown,
): boolean {
  const categorias: readonly unknown[] = CATEGORIAS_POR_TIPO[tipo];
  return categorias.includes(categoria);
}
