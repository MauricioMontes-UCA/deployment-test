/** Bienes por página de `GET /bienes/mios` (BE-1.3). */
export const MIS_BIENES_POR_PAGINA = 20;
