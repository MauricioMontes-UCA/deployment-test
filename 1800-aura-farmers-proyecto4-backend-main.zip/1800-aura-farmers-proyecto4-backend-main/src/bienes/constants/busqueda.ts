/** Resultados por página si el cliente no pide un tamaño. */
export const TAMANO_PAGINA_POR_DEFECTO = 20;

/** Mayor tamaño de página que se acepta. */
export const TAMANO_PAGINA_MAXIMO = 50;

/** Largo máximo del texto de búsqueda. */
export const MAX_LARGO_TEXTO_BUSQUEDA = 100;

/**
 * Mayor número de página que se acepta. Sin tope, un valor enorme desborda el
 * OFFSET de PostgreSQL (bigint) y la consulta falla con 500. Con 50 por página
 * cubre 500 000 resultados, muy por encima del catálogo.
 */
export const PAGINA_MAXIMA = 10_000;

/** El precio más alto que cabe en NUMERIC(12,2). */
export const PRECIO_MAXIMO_FILTRO = 9_999_999_999.99;

/** El mayor entero de una columna INTEGER: más alto, Postgres respondería 500. */
export const CAPACIDAD_MAXIMA_FILTRO = 2_147_483_647;
