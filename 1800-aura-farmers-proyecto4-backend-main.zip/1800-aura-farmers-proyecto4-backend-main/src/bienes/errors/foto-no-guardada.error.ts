/**
 * Error de dominio: no se pudo escribir una foto en disco.
 *
 * Lo lanza `FotoStorageService`. `BienesService` lo usa para saber que el fallo
 * fue del almacenamiento y no de los datos del usuario: borra las fotos ya
 * escritas, no crea el bien y responde 500.
 */
export class FotoNoGuardadaError extends Error {
  constructor(
    public readonly bienId: string,
    public readonly orden: number,
    options?: ErrorOptions,
  ) {
    super(`No se pudo guardar la foto ${orden} del bien ${bienId}.`, options);
    this.name = 'FotoNoGuardadaError';
  }
}
