export * from './bienes.module.js';
