const FORMATO_DIA = /^\d{4}-\d{2}-\d{2}$/;

/** Los bienes están en El Salvador: "hoy" es el día de esa zona, no el de UTC. */
export const ZONA_HORARIA = 'America/El_Salvador';

/**
 * Convierte "YYYY-MM-DD" en un Date a medianoche UTC.
 *
 * Las columnas de fecha de Reserva y BloqueoFecha son `@db.Date` (días
 * completos, sin hora), y Prisma las entrega a medianoche UTC. Trabajar todo en
 * UTC evita que una zona horaria corra un día.
 *
 * Devuelve null si el texto no tiene el formato o no es un día real
 * (por ejemplo "2026-02-30", que `Date` normalizaría a marzo).
 */
export function parseDia(valor: string): Date | null {
  if (!FORMATO_DIA.test(valor)) return null;
  const fecha = new Date(`${valor}T00:00:00.000Z`);
  if (Number.isNaN(fecha.getTime())) return null;
  return formatDia(fecha) === valor ? fecha : null;
}

/** "YYYY-MM-DD" de un Date en UTC. */
export function formatDia(fecha: Date): string {
  return fecha.toISOString().slice(0, 10);
}

/** El día de calendario de `ahora` en la zona dada, a medianoche UTC. */
export function hoyEn(zonaHoraria: string, ahora: Date = new Date()): Date {
  const dia = new Intl.DateTimeFormat('en-CA', {
    timeZone: zonaHoraria,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(ahora);
  return parseDia(dia) as Date;
}

/**
 * Último día de una ventana de `meses` meses que empieza en `desde`.
 *
 * La ventana es inclusiva: desde 2026-11-01, 12 meses terminan el 2027-10-31.
 */
export function ultimoDiaDeVentana(desde: Date, meses: number): Date {
  const limite = new Date(
    Date.UTC(
      desde.getUTCFullYear(),
      desde.getUTCMonth() + meses,
      desde.getUTCDate(),
    ),
  );
  limite.setUTCDate(limite.getUTCDate() - 1);
  return limite;
}
