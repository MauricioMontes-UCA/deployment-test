import { formatDia, hoyEn, parseDia, ultimoDiaDeVentana } from './fechas.js';

describe('parseDia', () => {
  it('convierte un día válido a medianoche UTC', () => {
    expect(parseDia('2026-12-10')?.toISOString()).toBe(
      '2026-12-10T00:00:00.000Z',
    );
  });

  it.each([
    '2026-12-1',
    '10-12-2026',
    '2026-12-10T00:00:00Z',
    'mañana',
    '',
    '2026-02-30',
    '2026-13-01',
    '2027-02-29',
  ])('rechaza "%s"', (valor) => {
    expect(parseDia(valor)).toBeNull();
  });

  it('acepta el 29 de febrero de un año bisiesto', () => {
    expect(parseDia('2028-02-29')).not.toBeNull();
  });
});

describe('formatDia', () => {
  it('devuelve YYYY-MM-DD en UTC', () => {
    expect(formatDia(new Date('2026-12-10T00:00:00.000Z'))).toBe('2026-12-10');
  });
});

describe('hoyEn', () => {
  it('usa el día de la zona y no el de UTC', () => {
    // 03:00 UTC del 13 es todavía el 12 a las 21:00 en El Salvador (UTC-6).
    const ahora = new Date('2026-11-13T03:00:00.000Z');
    expect(formatDia(hoyEn('America/El_Salvador', ahora))).toBe('2026-11-12');
    expect(formatDia(hoyEn('UTC', ahora))).toBe('2026-11-13');
  });
});

describe('ultimoDiaDeVentana', () => {
  it('12 meses desde el 1 de noviembre terminan el 31 de octubre', () => {
    const desde = parseDia('2026-11-01') as Date;
    expect(formatDia(ultimoDiaDeVentana(desde, 12))).toBe('2027-10-31');
  });

  it('12 meses desde una fecha a mitad de mes terminan un día antes', () => {
    const desde = parseDia('2026-11-13') as Date;
    expect(formatDia(ultimoDiaDeVentana(desde, 12))).toBe('2027-11-12');
  });

  it('desde un 29 de febrero cae en el 28 de febrero del año siguiente', () => {
    const desde = parseDia('2028-02-29') as Date;
    expect(formatDia(ultimoDiaDeVentana(desde, 12))).toBe('2029-02-28');
  });
});
