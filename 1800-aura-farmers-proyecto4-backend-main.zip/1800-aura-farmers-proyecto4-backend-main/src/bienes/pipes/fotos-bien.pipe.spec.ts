import { BadRequestException } from '@nestjs/common';
import { MAX_FOTO_BYTES } from '@Bienes/constants';
import { FotosBienPipe, detectarFormato } from './fotos-bien.pipe.js';

const JPG = Buffer.from([0xff, 0xd8, 0xff, 0xe0, 0x00, 0x10]);
const PNG = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00]);
const WEBP = Buffer.concat([
  Buffer.from('RIFF'),
  Buffer.from([0x24, 0x00, 0x00, 0x00]),
  Buffer.from('WEBPVP8 '),
]);
const GIF = Buffer.from('GIF89a');

function archivo(
  buffer: Buffer,
  extra: Partial<Express.Multer.File> = {},
): Express.Multer.File {
  return {
    buffer,
    size: buffer.length,
    originalname: 'foto.jpg',
    mimetype: 'image/jpeg',
    ...extra,
  } as Express.Multer.File;
}

function mensajes(fn: () => unknown): string[] {
  try {
    fn();
  } catch (error) {
    expect(error).toBeInstanceOf(BadRequestException);
    const respuesta = (error as BadRequestException).getResponse() as {
      message: string[];
    };
    return respuesta.message;
  }
  throw new Error('Se esperaba BadRequestException');
}

describe('FotosBienPipe', () => {
  const pipe = new FotosBienPipe();

  it('acepta JPG, PNG y WEBP y conserva el orden', () => {
    const fotos = pipe.transform([archivo(PNG), archivo(JPG), archivo(WEBP)]);
    expect(fotos.map((f) => f.formato)).toEqual(['png', 'jpg', 'webp']);
    expect(fotos[0]!.buffer).toBe(PNG);
  });

  it.each([undefined, []])('rechaza que no haya fotos (%s)', (archivos) => {
    expect(mensajes(() => pipe.transform(archivos))).toEqual([
      'Debes subir al menos una foto.',
    ]);
  });

  it('rechaza más de 10 fotos', () => {
    const once = Array.from({ length: 11 }, () => archivo(JPG));
    expect(mensajes(() => pipe.transform(once))[0]).toContain('como máximo 10');
  });

  it('detecta el formato por el contenido y no por el mimetype', () => {
    const disfrazado = archivo(GIF, {
      originalname: 'gato.jpg',
      mimetype: 'image/jpeg',
    });
    expect(mensajes(() => pipe.transform([archivo(JPG), disfrazado]))).toEqual([
      'La foto 2 (gato.jpg) debe ser JPG, PNG o WEBP.',
    ]);
  });

  it('rechaza una foto de más de 5 MB', () => {
    const pesada = archivo(JPG, { size: MAX_FOTO_BYTES + 1 });
    expect(mensajes(() => pipe.transform([pesada]))[0]).toContain(
      'pesa más de 5 MB',
    );
  });

  it('reporta todas las fotos inválidas a la vez', () => {
    const malas = [archivo(GIF), archivo(JPG), archivo(Buffer.alloc(0))];
    expect(mensajes(() => pipe.transform(malas))).toHaveLength(2);
  });
});

describe('detectarFormato', () => {
  it('no confunde un RIFF que no es WEBP', () => {
    const wav = Buffer.concat([
      Buffer.from('RIFF'),
      Buffer.alloc(4),
      Buffer.from('WAVE'),
    ]);
    expect(detectarFormato(wav)).toBeNull();
  });

  it('devuelve null con un archivo vacío', () => {
    expect(detectarFormato(Buffer.alloc(0))).toBeNull();
  });
});
