import {
  BadRequestException,
  Injectable,
  type PipeTransform,
} from '@nestjs/common';
import {
  MAX_FOTO_BYTES,
  MAX_FOTO_MB,
  MAX_FOTOS,
  MIN_FOTOS,
} from '@Bienes/constants';
import type { FormatoFoto, FotoSubida } from '@Bienes/types';

const FIRMA_JPG = Buffer.from([0xff, 0xd8, 0xff]);
const FIRMA_PNG = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);

/**
 * Valida las fotos que dejó `FotosBienInterceptor` y las convierte en
 * `FotoSubida`.
 *
 * El formato se detecta por los primeros bytes del archivo y no por el
 * `mimetype` ni la extensión, que los decide el cliente. Ese formato es el que
 * después da la extensión con la que se guarda y se sirve la foto.
 *
 * Cantidad y peso se vuelven a revisar aunque multer ya los limite, para que
 * el pipe no dependa de cómo se configuró el interceptor.
 */
@Injectable()
export class FotosBienPipe implements PipeTransform<
  Express.Multer.File[] | undefined,
  FotoSubida[]
> {
  transform(archivos: Express.Multer.File[] | undefined): FotoSubida[] {
    const fotos = archivos ?? [];

    if (fotos.length < MIN_FOTOS) {
      throw new BadRequestException(['Debes subir al menos una foto.']);
    }
    if (fotos.length > MAX_FOTOS) {
      throw new BadRequestException([
        `Se pueden subir como máximo ${MAX_FOTOS} fotos.`,
      ]);
    }

    const errores: string[] = [];
    const validas: FotoSubida[] = [];

    for (const [indice, archivo] of fotos.entries()) {
      const nombre = `La foto ${indice + 1} (${archivo.originalname})`;
      const formato = detectarFormato(archivo.buffer);

      if (!formato) {
        errores.push(`${nombre} debe ser JPG, PNG o WEBP.`);
      } else if (archivo.size > MAX_FOTO_BYTES) {
        errores.push(`${nombre} pesa más de ${MAX_FOTO_MB} MB.`);
      } else {
        validas.push({ buffer: archivo.buffer, formato });
      }
    }

    if (errores.length > 0) throw new BadRequestException(errores);
    return validas;
  }
}

/** Reconoce JPG, PNG y WEBP por su firma. Cualquier otro contenido da `null`. */
export function detectarFormato(buffer: Buffer): FormatoFoto | null {
  if (buffer.subarray(0, FIRMA_JPG.length).equals(FIRMA_JPG)) return 'jpg';
  if (buffer.subarray(0, FIRMA_PNG.length).equals(FIRMA_PNG)) return 'png';
  if (
    buffer.length >= 12 &&
    buffer.toString('ascii', 0, 4) === 'RIFF' &&
    buffer.toString('ascii', 8, 12) === 'WEBP'
  ) {
    return 'webp';
  }
  return null;
}
