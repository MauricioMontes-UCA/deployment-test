export * from './fotos-bien.pipe.js';
