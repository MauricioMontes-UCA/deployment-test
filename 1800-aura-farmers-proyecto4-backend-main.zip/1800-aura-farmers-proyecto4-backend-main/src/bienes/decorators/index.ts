export * from './es-categoria-del-tipo.decorator.js';
