import { ValidateBy, type ValidationArguments } from 'class-validator';
import {
  CATEGORIAS_POR_TIPO,
  esCategoriaDelTipo,
  esTipoBien,
} from '@Bienes/constants';

/**
 * Valida que la categoría pertenezca al tipo de bien del mismo objeto.
 *
 * Lee la propiedad `tipo` del DTO. Si el tipo no es válido, ya lo reporta su
 * propia validación; en ese caso la categoría solo se compara contra todas las
 * categorías, para no esconder un valor que no existe en ninguna lista.
 */
export function EsCategoriaDelTipo(): PropertyDecorator {
  return ValidateBy({
    name: 'esCategoriaDelTipo',
    validator: {
      validate(categoria: unknown, args?: ValidationArguments): boolean {
        const tipo = tipoDe(args);
        if (tipo) return esCategoriaDelTipo(tipo, categoria);

        return Object.values(CATEGORIAS_POR_TIPO).some(
          (categorias: readonly unknown[]) => categorias.includes(categoria),
        );
      },
      defaultMessage(args?: ValidationArguments): string {
        const tipo = tipoDe(args);
        if (!tipo) return 'La categoría no existe.';

        return (
          `La categoría no pertenece al tipo ${tipo}. ` +
          `Opciones: ${CATEGORIAS_POR_TIPO[tipo].join(', ')}.`
        );
      },
    },
  });
}

function tipoDe(args?: ValidationArguments) {
  const tipo = (args?.object as { tipo?: unknown } | undefined)?.tipo;
  return esTipoBien(tipo) ? tipo : null;
}
