import 'reflect-metadata';
import { IS_PUBLIC_KEY } from '@Auth/decorators';
import { NotFoundException } from '@nestjs/common';
import type { ResenasService } from '@Resenas/services';
import type { BienesService } from '@Bienes/services';
import { BienesResenasController } from './bienes-resenas.controller.js';

const API_SECURITY = 'swagger/apiSecurity';
const BIEN_ID = '7c9e6679-7425-40de-944b-e07fc1f90ae7';

describe('BienesResenasController', () => {
  const { listar } = BienesResenasController.prototype;

  it('es público y sin candado en Swagger', () => {
    expect(Reflect.getMetadata(IS_PUBLIC_KEY, listar)).toBe(true);
    expect(
      Reflect.getMetadata(API_SECURITY, BienesResenasController),
    ).toBeUndefined();
  });

  it('convierte la página del servicio al contrato', async () => {
    const listarDeBien = vi.fn().mockResolvedValue({
      items: [
        {
          id: 'r1',
          puntuacion: 4,
          comentario: null,
          creadaEn: new Date('2026-11-10T15:00:00.000Z'),
          autor: { nombreUsuario: 'carlos_r' },
        },
      ],
      total: 11,
      pagina: 1,
      hayMas: true,
    });
    const verificarPublicado = vi.fn().mockResolvedValue(undefined);
    const controller = new BienesResenasController(
      { verificarPublicado } as unknown as BienesService,
      { listarDeBien } as unknown as ResenasService,
    );

    const respuesta = await controller.listar(BIEN_ID, { pagina: 1 });

    expect(verificarPublicado).toHaveBeenCalledWith(BIEN_ID);
    expect(listarDeBien).toHaveBeenCalledWith(BIEN_ID, 1);
    expect(respuesta).toEqual({
      items: [
        {
          id: 'r1',
          puntuacion: 4,
          autor: { nombreUsuario: 'carlos_r' },
          creadaEn: '2026-11-10T15:00:00.000Z',
        },
      ],
      pagina: 1,
      total: 11,
      hayMas: true,
    });
  });

  it('un bien no publicado da 404 aunque el listado responda', async () => {
    const controller = new BienesResenasController(
      {
        verificarPublicado: vi
          .fn()
          .mockRejectedValue(new NotFoundException('no disponible')),
      } as unknown as BienesService,
      {
        listarDeBien: vi
          .fn()
          .mockResolvedValue({ items: [], total: 0, pagina: 1, hayMas: false }),
      } as unknown as ResenasService,
    );

    await expect(
      controller.listar(BIEN_ID, { pagina: 1 }),
    ).rejects.toBeInstanceOf(NotFoundException);
  });
});
