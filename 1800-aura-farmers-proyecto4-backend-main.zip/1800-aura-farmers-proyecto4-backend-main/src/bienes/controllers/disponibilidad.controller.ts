import { Controller, Get, Param, ParseUUIDPipe, Query } from '@nestjs/common';
import {
  ApiBadRequestResponse,
  ApiBearerAuth,
  ApiNotFoundResponse,
  ApiOkResponse,
  ApiOperation,
  ApiTags,
  ApiUnauthorizedResponse,
} from '@nestjs/swagger';
import { DisponibilidadService } from '@Bienes/services';
import {
  ConsultaDisponibilidadDto,
  DisponibilidadResponseDto,
} from '@Bienes/dto';

@ApiTags('bienes')
@ApiBearerAuth()
@Controller('bienes')
export class DisponibilidadController {
  constructor(private readonly disponibilidadService: DisponibilidadService) {}

  /** Protegido por el guard global: requiere sesión. */
  @Get(':bienId/disponibilidad')
  @ApiOperation({
    summary: 'Consulta los rangos reservados y bloqueados de un bien',
  })
  @ApiOkResponse({ type: DisponibilidadResponseDto })
  @ApiBadRequestResponse({
    description: 'Fechas inválidas o ventana mayor a 12 meses.',
  })
  @ApiUnauthorizedResponse({
    description: 'Token ausente, inválido o expirado.',
  })
  @ApiNotFoundResponse({ description: 'El bien no existe.' })
  async consultar(
    @Param('bienId', ParseUUIDPipe) bienId: string,
    @Query() query: ConsultaDisponibilidadDto,
  ): Promise<DisponibilidadResponseDto> {
    return DisponibilidadResponseDto.from(
      await this.disponibilidadService.consultar(bienId, query),
    );
  }
}
