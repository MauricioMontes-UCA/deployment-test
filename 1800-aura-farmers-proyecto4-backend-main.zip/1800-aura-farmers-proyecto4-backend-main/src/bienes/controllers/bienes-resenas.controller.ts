import { Controller, Get, Param, ParseUUIDPipe, Query } from '@nestjs/common';
import {
  ApiBadRequestResponse,
  ApiNotFoundResponse,
  ApiOkResponse,
  ApiOperation,
  ApiTags,
} from '@nestjs/swagger';
import { Public } from '@Auth/decorators';
import {
  ListarResenasBienQueryDto,
  PaginaResenasBienResponseDto,
  ResenaBienResponseDto,
} from '@Resenas/dto';
import { ResenasService } from '@Resenas/services';
import { BienesService } from '@Bienes/services';

/**
 * Reseñas públicas de un bien (H15). Vive en el módulo de bienes porque la
 * ruta es `/bienes/:bienId/resenas` y la publicación la decide `BienesService`;
 * los datos los entrega `ResenasService`. Es público como el detalle, así que
 * no declara `@ApiBearerAuth()`.
 */
@ApiTags('resenas')
@Controller('bienes')
export class BienesResenasController {
  constructor(
    private readonly bienesService: BienesService,
    private readonly resenasService: ResenasService,
  ) {}

  @Get(':bienId/resenas')
  @Public()
  @ApiOperation({
    summary: 'Lista las reseñas de un bien',
    description:
      'No requiere token. Solo reseñas de tipo BIEN, de la más reciente a la más antigua, 10 por página. No expone las reseñas sobre el arrendador ni sobre el arrendatario.',
  })
  @ApiOkResponse({ type: PaginaResenasBienResponseDto })
  @ApiBadRequestResponse({
    description: 'El bienId no es un UUID o la página no es válida.',
  })
  @ApiNotFoundResponse({
    description:
      'La publicación ya no está disponible: el bien no existe, está INACTIVA o su arrendador está desactivado.',
  })
  async listar(
    @Param('bienId', ParseUUIDPipe) bienId: string,
    @Query() { pagina }: ListarResenasBienQueryDto,
  ): Promise<PaginaResenasBienResponseDto> {
    // Las dos lecturas son independientes: se hacen a la vez y, si el bien no
    // está publicado, el 404 gana sobre cualquier resultado del listado.
    const [, resultado] = await Promise.all([
      this.bienesService.verificarPublicado(bienId),
      this.resenasService.listarDeBien(bienId, pagina),
    ]);
    return {
      items: resultado.items.map((resena) =>
        ResenaBienResponseDto.from(resena),
      ),
      pagina: resultado.pagina,
      total: resultado.total,
      hayMas: resultado.hayMas,
    };
  }
}
