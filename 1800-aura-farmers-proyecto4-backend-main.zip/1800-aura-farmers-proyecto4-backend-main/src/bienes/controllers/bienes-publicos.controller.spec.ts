import { IS_PUBLIC_KEY } from '@Auth/decorators';
import type { BienesService } from '@Bienes/services';
import { Prisma } from '@PrismaClient';
import { BienesPublicosController } from './bienes-publicos.controller.js';
import { BienesController } from './bienes.controller.js';
import { DisponibilidadController } from './disponibilidad.controller.js';

// Clave con la que @ApiBearerAuth() guarda la seguridad para Swagger.
const API_SECURITY = 'swagger/apiSecurity';

// Handler de la ruta, donde los decoradores de método guardan sus metadatos.
const findOne = Object.getOwnPropertyDescriptor(
  BienesPublicosController.prototype,
  'findOne',
)!.value as object;

describe('BienesPublicosController', () => {
  it('no declara seguridad en Swagger: sus rutas no llevan candado', () => {
    expect(
      Reflect.getMetadata(API_SECURITY, BienesPublicosController),
    ).toBeUndefined();
    expect(Reflect.getMetadata(API_SECURITY, findOne)).toBeUndefined();
  });

  it('marca el detalle como público para el guard de JWT', () => {
    expect(Reflect.getMetadata(IS_PUBLIC_KEY, findOne)).toBe(true);
  });

  it('devuelve el detalle del servicio ya convertido al DTO', async () => {
    const findDetalle = vi.fn().mockResolvedValue({
      id: '7c9e6679-7425-40de-944b-e07fc1f90ae7',
      tipo: 'EQUIPO',
      categoria: 'Herramientas',
      titulo: 'Taladro',
      descripcion: 'Taladro percutor.',
      precio: new Prisma.Decimal('12.50'),
      unidadCobro: 'DIA',
      deposito: new Prisma.Decimal(0),
      capacidad: null,
      condiciones: null,
      departamento: 'San Salvador',
      municipio: 'San Salvador',
      direccionReferencia: null,
      creadoEn: new Date('2026-11-02T15:00:00.000Z'),
      arrendador: { id: 'a', nombreUsuario: 'ana_m' },
      fotos: [],
      calificacion: { promedio: null, totalResenas: 0 },
    });
    const controller = new BienesPublicosController({
      findDetalle,
    } as unknown as BienesService);

    const dto = await controller.findOne(
      '7c9e6679-7425-40de-944b-e07fc1f90ae7',
    );

    expect(findDetalle).toHaveBeenCalledWith(
      '7c9e6679-7425-40de-944b-e07fc1f90ae7',
    );
    expect(dto.precio).toBe(12.5);
    expect(dto.deposito).toBe(0);
    expect(dto.calificacion).toEqual({ promedio: null, totalResenas: 0 });
  });
});

describe('Controladores protegidos de bienes', () => {
  it('declaran el bearer en la clase, así toda ruta nueva sale con candado', () => {
    for (const controlador of [BienesController, DisponibilidadController]) {
      expect(Reflect.getMetadata(API_SECURITY, controlador)).toEqual([
        { bearer: [] },
      ]);
    }
  });
});
