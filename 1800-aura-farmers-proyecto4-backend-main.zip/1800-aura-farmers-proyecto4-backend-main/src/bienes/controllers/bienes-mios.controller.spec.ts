import { ROLES_KEY } from '@Auth/decorators';
import type { AuthenticatedUser } from '@Auth/types';
import type { BienesService } from '@Bienes/services';
import { Rol } from '@PrismaClient';
import { BienesController } from './bienes.controller.js';
import { BienesPublicosController } from './bienes-publicos.controller.js';

const USUARIO = { id: 'arrendador-1' } as AuthenticatedUser;
const listarMios = Object.getOwnPropertyDescriptor(
  BienesController.prototype,
  'listarMios',
)!.value as object;

describe('BienesController.listarMios', () => {
  it('es solo para ARRENDADOR', () => {
    expect(Reflect.getMetadata(ROLES_KEY, listarMios)).toEqual([
      Rol.ARRENDADOR,
    ]);
  });

  it('se declara en la ruta `mios`, que BienesModule registra antes que `:bienId`', () => {
    expect(Reflect.getMetadata('path', listarMios)).toBe('mios');
    expect(Reflect.getMetadata('path', BienesController)).toBe('bienes');
    expect(Reflect.getMetadata('path', BienesPublicosController)).toBe(
      'bienes',
    );
  });

  it('pide al servicio los bienes del usuario del token y mapea la respuesta', async () => {
    const bien = {
      id: 'b1',
      titulo: 'Casa',
      tipo: 'PROPIEDAD',
      categoria: 'Casa',
      estado: 'INACTIVA',
      precio: { toNumber: () => 10 },
      unidadCobro: 'DIA',
      deposito: { toNumber: () => 0 },
      departamento: 'San Salvador',
      municipio: 'San Salvador',
      creadoEn: new Date('2026-11-02T15:00:00.000Z'),
      fotos: [],
      politicaVerificacion: null,
    };
    const servicio = vi.fn().mockResolvedValue({
      bienes: [bien],
      pagina: 2,
      total: 21,
      hayMas: false,
    });
    const controller = new BienesController({
      listarMios: servicio,
    } as unknown as BienesService);

    const respuesta = await controller.listarMios(USUARIO, { pagina: 2 });

    expect(servicio).toHaveBeenCalledWith('arrendador-1', { pagina: 2 });
    expect(respuesta).toEqual({
      items: [
        expect.objectContaining({
          id: 'b1',
          estado: 'INACTIVA',
          precio: 10,
          deposito: 0,
          fotoPrincipalUrl: null,
          soloVerificados: false,
        }),
      ],
      pagina: 2,
      total: 21,
      hayMas: false,
    });
  });
});
