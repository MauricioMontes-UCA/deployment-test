import { Controller, Get, Param, ParseUUIDPipe } from '@nestjs/common';
import {
  ApiBadRequestResponse,
  ApiNotFoundResponse,
  ApiOkResponse,
  ApiOperation,
  ApiTags,
} from '@nestjs/swagger';
import { Public } from '@Auth/decorators';
import { BienesService } from '@Bienes/services';
import { BienDetalleResponseDto } from '@Bienes/dto';

/**
 * Rutas públicas de bienes: no requieren sesión.
 *
 * Están aparte de `BienesController` porque Swagger suma el `@ApiBearerAuth()`
 * de la clase a todos sus métodos y un método no lo puede quitar. Así cada
 * controlador declara la seguridad una sola vez, en la clase: con candado los
 * protegidos y sin él este.
 */
@ApiTags('bienes')
@Controller('bienes')
export class BienesPublicosController {
  constructor(private readonly bienesService: BienesService) {}

  /** Detalle de un bien publicado. */
  @Get(':bienId')
  @Public()
  @ApiOperation({
    summary: 'Consulta el detalle público de un bien',
    description:
      'No requiere token. Solo devuelve bienes ACTIVA de arrendadores activos. Del arrendador expone únicamente id y nombre de usuario.',
  })
  @ApiOkResponse({ type: BienDetalleResponseDto })
  @ApiBadRequestResponse({ description: 'El bienId no es un UUID.' })
  @ApiNotFoundResponse({
    description:
      'La publicación ya no está disponible: el bien no existe, está INACTIVA o su arrendador está desactivado.',
  })
  async findOne(
    @Param('bienId', ParseUUIDPipe) bienId: string,
  ): Promise<BienDetalleResponseDto> {
    const bien = await this.bienesService.findDetalle(bienId);
    return BienDetalleResponseDto.fromEntity(bien);
  }
}
