import {
  Body,
  Controller,
  Get,
  Post,
  Query,
  UploadedFiles,
  UseInterceptors,
} from '@nestjs/common';
import {
  ApiBadRequestResponse,
  ApiBearerAuth,
  ApiBody,
  ApiConsumes,
  ApiCreatedResponse,
  ApiForbiddenResponse,
  ApiOkResponse,
  ApiOperation,
  ApiTags,
  ApiUnauthorizedResponse,
} from '@nestjs/swagger';
import { CurrentUser, Public, Roles } from '@Auth/decorators';
import { BienesService } from '@Bienes/services';
import { FotosBienInterceptor } from '@Bienes/interceptors';
import { FotosBienPipe } from '@Bienes/pipes';
import {
  BienResponseDto,
  BuscarBienesQueryDto,
  BusquedaBienesResponseDto,
  ConsultarMisBienesDto,
  CreateBienDto,
  CreateBienFormDto,
  MiBienResponseDto,
  MisBienesResponseDto,
} from '@Bienes/dto';
import { Rol } from '@PrismaClient';
import type { AuthenticatedUser } from '@Auth/types';
import type { FotoSubida } from '@Bienes/types';

@ApiTags('bienes')
@ApiBearerAuth()
@Controller('bienes')
export class BienesController {
  constructor(private readonly bienesService: BienesService) {}

  /**
   * Busca bienes por texto y ubicación, paginado. Es público: el catálogo se
   * puede ver sin iniciar sesión.
   */
  @Public()
  @Get()
  @ApiOperation({
    summary:
      'Busca bienes por texto, ubicación, precio, tipo, categoría, capacidad y disponibilidad, paginado',
  })
  @ApiOkResponse({ type: BusquedaBienesResponseDto })
  @ApiBadRequestResponse({
    description:
      'Página o tamaño fuera de rango, texto de más de 100 caracteres, precio negativo o precioMin > precioMax, tipo desconocido, capacidadMin < 1, solo una de las dos fechas, fecha inválida, fechaFin < fechaInicio o fechaInicio anterior a hoy.',
  })
  async buscar(
    @Query() query: BuscarBienesQueryDto,
  ): Promise<BusquedaBienesResponseDto> {
    const { tamano, ...pagina } = await this.bienesService.buscar(query);
    return { ...pagina, tamanoPagina: tamano };
  }

  /**
   * Los bienes publicados por el arrendador autenticado (BE-1.3), también los
   * INACTIVA. Tiene que declararse antes que `GET /bienes/:bienId`
   * (`BienesPublicosController`) para que `mios` no se interprete como un id:
   * Nest registra los controladores en el orden de `BienesModule`, donde este
   * va primero.
   */
  @Get('mios')
  @Roles(Rol.ARRENDADOR)
  @ApiOperation({
    summary: 'Lista los bienes publicados por el arrendador autenticado',
    description:
      'De a 20 por página, del más reciente al más antiguo. Incluye los bienes INACTIVA, la foto principal y el valor de «Solo usuarios verificados».',
  })
  @ApiOkResponse({ type: MisBienesResponseDto })
  @ApiBadRequestResponse({
    description: 'Página inválida o parámetro desconocido.',
  })
  @ApiUnauthorizedResponse({
    description: 'Token ausente, inválido o expirado.',
  })
  @ApiForbiddenResponse({ description: 'El usuario no tiene rol ARRENDADOR.' })
  async listarMios(
    @CurrentUser() usuario: AuthenticatedUser,
    @Query() query: ConsultarMisBienesDto,
  ): Promise<MisBienesResponseDto> {
    const { bienes, pagina, total, hayMas } =
      await this.bienesService.listarMios(usuario.id, query);

    return {
      items: bienes.map((bien) => MiBienResponseDto.fromEntity(bien)),
      pagina,
      total,
      hayMas,
    };
  }

  /**
   * Publica un bien. Llega como multipart/form-data porque trae las fotos
   * junto con los datos, y se guarda todo o nada.
   */
  @Post()
  @Roles(Rol.ARRENDADOR)
  @UseInterceptors(FotosBienInterceptor)
  @ApiOperation({ summary: 'Publica un bien con sus fotos' })
  @ApiConsumes('multipart/form-data')
  @ApiBody({ type: CreateBienFormDto })
  @ApiCreatedResponse({ type: BienResponseDto })
  @ApiBadRequestResponse({
    description:
      'Falta un campo, la categoría no es del tipo elegido, el precio no es mayor que 0, el título supera 100 caracteres, no hay fotos, hay más de 10, o alguna no es JPG, PNG o WEBP o pesa más de 5 MB.',
  })
  @ApiUnauthorizedResponse({
    description: 'Token ausente, inválido o expirado.',
  })
  @ApiForbiddenResponse({ description: 'El usuario no tiene rol ARRENDADOR.' })
  async create(
    @CurrentUser() usuario: AuthenticatedUser,
    @Body() dto: CreateBienDto,
    @UploadedFiles(FotosBienPipe) fotos: FotoSubida[],
  ): Promise<BienResponseDto> {
    const bien = await this.bienesService.create(usuario.id, dto, fotos);
    return BienResponseDto.fromEntity(bien);
  }
}
