import type { EventEmitter2 } from '@nestjs/event-emitter';
import type { BienRepository } from '@Bienes/repositories';
import type { VerificacionService } from '@Verificaciones/services';
import type {
  ReservaConsulta,
  ReservaRepository,
} from '@Reservas/repositories';
import { ReservasService } from './reservas.service.js';

const reserva = { id: 'reserva-1' } as ReservaConsulta;

function crear(total: number, reservas: ReservaConsulta[] = []) {
  const findRecibidas = vi.fn().mockResolvedValue({ reservas, total });
  const service = new ReservasService(
    { findRecibidas } as unknown as ReservaRepository,
    {} as BienRepository,
    {} as VerificacionService,
    {} as EventEmitter2,
  );
  return { service, findRecibidas };
}

describe('ReservasService.listarRecibidas (BE-27.1)', () => {
  it('consulta las reservas del arrendador indicado, desde el inicio y de a 20', async () => {
    const { service, findRecibidas } = crear(1, [reserva]);

    await expect(
      service.listarRecibidas('arrendador-1', { pagina: 1 }),
    ).resolves.toEqual({
      reservas: [reserva],
      pagina: 1,
      total: 1,
      hayMas: false,
    });
    expect(findRecibidas).toHaveBeenCalledWith({
      arrendadorId: 'arrendador-1',
      estado: undefined,
      desplazamiento: 0,
      limite: 20,
    });
  });

  it('pasa el filtro de estado y salta las páginas anteriores', async () => {
    const { service, findRecibidas } = crear(45);

    await service.listarRecibidas('arrendador-1', {
      estado: 'CONFIRMADA',
      pagina: 3,
    });

    expect(findRecibidas).toHaveBeenCalledWith({
      arrendadorId: 'arrendador-1',
      estado: 'CONFIRMADA',
      desplazamiento: 40,
      limite: 20,
    });
  });

  it.each([
    [45, 1, true],
    [45, 2, true],
    [45, 3, false],
    [20, 1, false],
    [21, 1, true],
    [0, 1, false],
  ])(
    'con %i reservas, la página %i tiene hayMas = %s',
    async (total, pagina, hayMas) => {
      const { service } = crear(total);

      const resultado = await service.listarRecibidas('arrendador-1', {
        pagina,
      });

      expect(resultado).toMatchObject({ pagina, total, hayMas });
    },
  );

  it('una página posterior a la última devuelve la página pedida, el total real y hayMas en false', async () => {
    const { service } = crear(45);

    await expect(
      service.listarRecibidas('arrendador-1', { pagina: 4 }),
    ).resolves.toEqual({ reservas: [], pagina: 4, total: 45, hayMas: false });
  });

  it('con la página máxima admitida (Number.MAX_SAFE_INTEGER) no falla: el desplazamiento supera el total y hayMas queda en false', async () => {
    const { service, findRecibidas } = crear(45);
    const pagina = Number.MAX_SAFE_INTEGER;

    await expect(
      service.listarRecibidas('arrendador-1', { pagina }),
    ).resolves.toEqual({ reservas: [], pagina, total: 45, hayMas: false });

    const { desplazamiento, limite } = findRecibidas.mock.calls[0]![0];
    // Un número finito y mayor que el total: el repositorio no consulta filas,
    // así que nunca llega a Prisma (ver reserva.repository.recibidas.spec).
    expect(Number.isFinite(desplazamiento)).toBe(true);
    expect(desplazamiento).toBeGreaterThan(45);
    expect(limite).toBe(20);
  });
});
