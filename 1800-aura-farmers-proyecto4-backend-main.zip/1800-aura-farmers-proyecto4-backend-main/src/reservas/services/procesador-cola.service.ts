import { Injectable, Logger } from '@nestjs/common';
import type { Prisma } from '@PrismaClient';
import {
  MotivoRechazo,
  ReservaRepository,
  type DecisionSolicitud,
  type ResultadoProcesamiento,
  type SolicitudEnCola,
} from '@Reservas/repositories';
import { VerificacionService } from '@Verificaciones/services';

/** Una solicitud que lleva más de esto EN_COLA ya no se procesa: se rechaza. */
export const TIEMPO_MAXIMO_EN_COLA_MS = 5 * 60 * 1000;

/**
 * Resuelve las solicitudes EN_COLA como CONFIRMADA o RECHAZADA, de la más
 * antigua a la más nueva.
 *
 * Aquí vive la regla de negocio; el repositorio solo da la transacción, el
 * bloqueo de la fila y el del bien.
 */
@Injectable()
export class ProcesadorColaService {
  private readonly logger = new Logger(ProcesadorColaService.name);

  /** Corrida en curso: evita que eventos seguidos lancen varias en paralelo. */
  private enCurso: Promise<number> | null = null;
  /** Llegó otra petición mientras corría una: hay que revisar la cola otra vez. */
  private repetir = false;

  constructor(
    private readonly reservaRepository: ReservaRepository,
    private readonly verificacionService: VerificacionService,
  ) {}

  /**
   * Procesa solicitudes hasta vaciar la cola y devuelve cuántas resolvió.
   *
   * Si ya hay una corrida en curso no abre otra: la marca para repetir al
   * terminar y devuelve la misma promesa. Nunca lanza: un error se registra y
   * la solicitud sigue EN_COLA, así que se reintenta en la siguiente revisión
   * (y si pasa de 5 minutos, se rechaza por error de procesamiento).
   */
  procesarPendientes(): Promise<number> {
    if (this.enCurso) {
      this.repetir = true;
      return this.enCurso;
    }
    this.enCurso = this.correr().finally(() => {
      this.enCurso = null;
    });
    return this.enCurso;
  }

  /**
   * Resuelve la solicitud más antigua. `ahora` se recibe para poder probar el
   * plazo de 5 minutos.
   */
  procesarSiguiente(ahora: Date = new Date()): Promise<ResultadoProcesamiento> {
    return this.reservaRepository.procesarSiguiente(
      ahora,
      (solicitud, ocupado, tx) => this.decidir(solicitud, ocupado, ahora, tx),
    );
  }

  private async correr(): Promise<number> {
    let total = 0;
    do {
      this.repetir = false;
      total += await this.vaciarCola();
    } while (this.repetir);
    return total;
  }

  private async vaciarCola(): Promise<number> {
    let procesadas = 0;
    try {
      for (;;) {
        const resultado = await this.procesarSiguiente();
        if (resultado.tipo !== 'PROCESADA') return procesadas;
        procesadas += 1;
      }
    } catch (error) {
      this.logger.error(
        'Falló el procesamiento de la cola de reservas; se reintentará.',
        error instanceof Error ? error.stack : String(error),
      );
      return procesadas;
    }
  }

  /**
   * El orden importa: el plazo va primero para que una solicitud vieja se
   * descarte sin consultar nada más, también si esas consultas fueran lo que
   * falla.
   *
   * Todas las lecturas van por `tx`, la transacción que ya tiene la solicitud
   * tomada. Si una usara el pool, cada procesador retendría una conexión y
   * pediría otra: con tantos procesadores a la vez como conexiones hay, todos
   * esperarían y la transacción vencería (P2028).
   */
  private async decidir(
    solicitud: SolicitudEnCola,
    ocupado: () => Promise<boolean>,
    ahora: Date,
    tx: Prisma.TransactionClient,
  ): Promise<DecisionSolicitud> {
    if (
      ahora.getTime() - solicitud.creadaEn.getTime() >
      TIEMPO_MAXIMO_EN_COLA_MS
    ) {
      return rechazo(MotivoRechazo.ERROR_DE_PROCESAMIENTO);
    }

    // La verificación pudo revocarse desde que se encoló la solicitud.
    if (
      !(await this.verificacionService.puedeReservar(
        {
          arrendatarioId: solicitud.arrendatarioId,
          bienId: solicitud.bienId,
        },
        tx,
      ))
    ) {
      return rechazo(MotivoRechazo.VERIFICACION_REQUERIDA);
    }

    if (await ocupado()) {
      return rechazo(MotivoRechazo.FECHAS_NO_DISPONIBLES);
    }
    return { estado: 'CONFIRMADA' };
  }
}

function rechazo(motivo: MotivoRechazo): DecisionSolicitud {
  return { estado: 'RECHAZADA', motivo };
}
