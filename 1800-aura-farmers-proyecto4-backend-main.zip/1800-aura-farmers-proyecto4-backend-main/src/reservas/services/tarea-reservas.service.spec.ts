import { describe, expect, it, vi } from 'vitest';
import { TareaReservasService } from '@Reservas/services';
const fecha = (dia: string) => new Date(`${dia}T12:00:00.000Z`);
const HOY = new Date('2026-11-16T06:05:00.000Z'); // 00:05 El Salvador

function escenario(
  opciones: {
    confirmadas?: string[];
    enCurso?: string[];
    depositos?: Array<{ id: string; finalizada: string; automatico?: boolean }>;
    plazoDevolucion?: number;
    plazoDeposito?: number;
  } = {},
) {
  const repository = {
    listarConfirmadas: vi
      .fn()
      .mockResolvedValue(
        (opciones.confirmadas ?? []).map((d, i) => ({
          id: `c${i}`,
          fechaInicio: fecha(d),
        })),
      ),
    iniciar: vi.fn().mockResolvedValue(true),
    listarEnCurso: vi
      .fn()
      .mockResolvedValue(
        (opciones.enCurso ?? []).map((d, i) => ({
          id: `r${i}`,
          fechaFin: fecha(d),
        })),
      ),
    cerrar: vi.fn().mockResolvedValue(true),
    listarDepositosPendientes: vi.fn().mockResolvedValue(
      (opciones.depositos ?? []).map((d) => ({
        id: d.id,
        reserva: {
          finalizadaEn: fecha(d.finalizada),
          cierreAutomatico: d.automatico ?? false,
        },
      })),
    ),
  };
  const depositos = { resolver: vi.fn().mockResolvedValue({ id: 'd1' }) };
  const config = {
    get: vi.fn((key: string) => {
      if (key === 'PLAZO_DEVOLUCION_DIAS') return opciones.plazoDevolucion ?? 3;
      if (key === 'PLAZO_DEPOSITO_DIAS') return opciones.plazoDeposito ?? 3;
      throw new Error(`Configuración inesperada: ${key}`);
    }),
  };
  const service = new TareaReservasService(
    repository as never,
    depositos as never,
    config as never,
  );
  return { service, repository, depositos };
}

describe('BE-10.2 — tarea diaria', () => {
  it('inicia confirmadas desde hoy, sin tocar las futuras', async () => {
    const { service, repository } = escenario({
      confirmadas: ['2026-11-15', '2026-11-16', '2026-11-17'],
    });
    expect((await service.ejecutar(HOY)).iniciadas).toBe(2);
    expect(repository.iniciar).toHaveBeenCalledTimes(2);
  });

  it('cierra reservas justo al cumplir tres días, pero no a los dos días', async () => {
    const { service, repository } = escenario({
      enCurso: ['2026-11-13', '2026-11-14'],
    });
    expect((await service.ejecutar(HOY)).finalizadas).toBe(1);
    expect(repository.cerrar).toHaveBeenCalledWith('r0', HOY);
  });

  it('libera depósitos vencidos y los de cierres automáticos, pero no los vigentes', async () => {
    const { service, depositos } = escenario({
      depositos: [
        { id: 'vencido', finalizada: '2026-11-13' },
        { id: 'vigente', finalizada: '2026-11-14' },
        { id: 'automatico', finalizada: '2026-11-16', automatico: true },
      ],
    });
    expect((await service.ejecutar(HOY)).depositosLiberados).toBe(2);
    expect(depositos.resolver).toHaveBeenCalledTimes(2);
    expect(depositos.resolver).toHaveBeenCalledWith(
      'automatico',
      { tipo: 'SISTEMA' },
      'LIBERAR',
      undefined,
      undefined,
      HOY,
    );
  });

  it('un error individual no detiene el resto', async () => {
    const { service, repository } = escenario({
      confirmadas: ['2026-11-15', '2026-11-15'],
    });
    repository.iniciar.mockRejectedValueOnce(new Error('fallo'));
    const resumen = await service.ejecutar(HOY);
    expect(resumen).toMatchObject({ iniciadas: 1, errores: 1 });
    expect(repository.iniciar).toHaveBeenCalledTimes(2);
  });

  it('usa plazos diferentes para devolución y depósito', async () => {
    const { service, repository, depositos } = escenario({
      plazoDevolucion: 2,
      plazoDeposito: 5,
      enCurso: ['2026-11-14'],
      depositos: [{ id: 'aun-vigente', finalizada: '2026-11-12' }],
    });
    const resumen = await service.ejecutar(HOY);
    expect(resumen.finalizadas).toBe(1);
    expect(resumen.depositosLiberados).toBe(0);
    expect(repository.cerrar).toHaveBeenCalledWith('r0', HOY);
    expect(depositos.resolver).not.toHaveBeenCalled();
  });

  it('segunda ejecución es idempotente con un repositorio que conserva estados', async () => {
    const { service, repository, depositos } = escenario();
    let estado: 'CONFIRMADA' | 'EN_CURSO' | 'FINALIZADA' = 'CONFIRMADA';
    let depositoPendiente = true;
    repository.listarConfirmadas.mockImplementation(async () =>
      estado === 'CONFIRMADA'
        ? [{ id: 'r1', fechaInicio: fecha('2026-11-01') }]
        : [],
    );
    repository.iniciar.mockImplementation(async () => {
      if (estado !== 'CONFIRMADA') return false;
      estado = 'EN_CURSO';
      return true;
    });
    repository.listarEnCurso.mockImplementation(async () =>
      estado === 'EN_CURSO'
        ? [{ id: 'r1', fechaFin: fecha('2026-11-10') }]
        : [],
    );
    repository.cerrar.mockImplementation(async () => {
      if (estado !== 'EN_CURSO') return false;
      estado = 'FINALIZADA';
      return true;
    });
    repository.listarDepositosPendientes.mockImplementation(async () =>
      estado === 'FINALIZADA' && depositoPendiente
        ? [{ id: 'd1', reserva: { finalizadaEn: HOY, cierreAutomatico: true } }]
        : [],
    );
    depositos.resolver.mockImplementation(async () => {
      depositoPendiente = false;
      return { id: 'd1' };
    });
    expect(await service.ejecutar(HOY)).toEqual({
      iniciadas: 1,
      finalizadas: 1,
      depositosLiberados: 1,
      errores: 0,
    });
    expect(await service.ejecutar(HOY)).toEqual({
      iniciadas: 0,
      finalizadas: 0,
      depositosLiberados: 0,
      errores: 0,
    });
    expect(repository.iniciar).toHaveBeenCalledTimes(1);
    expect(repository.cerrar).toHaveBeenCalledTimes(1);
    expect(depositos.resolver).toHaveBeenCalledTimes(1);
  });
});
