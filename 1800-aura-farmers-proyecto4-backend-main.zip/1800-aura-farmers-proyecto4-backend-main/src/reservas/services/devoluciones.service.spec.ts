import {
  ConflictException,
  ForbiddenException,
  NotFoundException,
  UnprocessableEntityException,
} from '@nestjs/common';
import {
  DevolucionesService,
  PLAZO_DEPOSITO_DIAS,
} from './devoluciones.service.js';
import type {
  RechazoDevolucion,
  ReservaRepository,
} from '@Reservas/repositories';
import type { RegistrarDevolucionDto } from '@Reservas/dto';
import type { Devolucion } from '@PrismaClient';

const RESERVA_ID = '11111111-1111-4111-8111-111111111111';
const ARRENDADOR_ID = '22222222-2222-4222-8222-222222222222';
const AHORA = new Date('2026-12-12T18:00:00.000Z');

/** Los campos del DTO como objeto plano, para poder copiarlo con spread. */
type DatosDevolucion = Pick<
  RegistrarDevolucionDto,
  keyof RegistrarDevolucionDto
>;

const dto: DatosDevolucion = {
  fechaDevolucion: '2026-12-12T15:30:00Z',
  estadoFinalBien: 'BUEN_ESTADO',
  observaciones: 'Sin novedades.',
};

function crearServicio(
  resultado:
    { devolucion: Partial<Devolucion> } | { rechazo: RechazoDevolucion } = {
    devolucion: { id: 'dev-1' },
  },
) {
  const registrarDevolucion = vi.fn().mockResolvedValue(resultado);
  const service = new DevolucionesService({
    registrarDevolucion,
  } as unknown as ReservaRepository);
  return { service, registrarDevolucion };
}

describe('DevolucionesService.registrar', () => {
  it('registra con el arrendador del token y el plazo de 3 días', async () => {
    const { service, registrarDevolucion } = crearServicio();

    const devolucion = await service.registrar(
      RESERVA_ID,
      ARRENDADOR_ID,
      dto,
      AHORA,
    );

    expect(devolucion).toEqual({ id: 'dev-1' });
    expect(registrarDevolucion).toHaveBeenCalledWith({
      reservaId: RESERVA_ID,
      registradoPorId: ARRENDADOR_ID,
      fechaDevolucion: new Date('2026-12-12T15:30:00Z'),
      estadoFinalBien: 'BUEN_ESTADO',
      observaciones: 'Sin novedades.',
      ahora: AHORA,
      plazoDepositoDias: 3,
    });
    expect(PLAZO_DEPOSITO_DIAS).toBe(3);
  });

  it('acepta una fecha igual al instante actual', async () => {
    const { service } = crearServicio();

    await expect(
      service.registrar(
        RESERVA_ID,
        ARRENDADOR_ID,
        { ...dto, fechaDevolucion: AHORA.toISOString() },
        AHORA,
      ),
    ).resolves.toBeDefined();
  });

  it('acepta una fecha sin hora, que cuenta como medianoche UTC', async () => {
    const { service, registrarDevolucion } = crearServicio();

    await service.registrar(
      RESERVA_ID,
      ARRENDADOR_ID,
      { ...dto, fechaDevolucion: '2026-12-12' },
      AHORA,
    );

    expect(registrarDevolucion.mock.calls[0]![0].fechaDevolucion).toEqual(
      new Date('2026-12-12T00:00:00.000Z'),
    );
  });

  it('rechaza con 422 una fecha futura, sin tocar la base', async () => {
    const { service, registrarDevolucion } = crearServicio();

    await expect(
      service.registrar(
        RESERVA_ID,
        ARRENDADOR_ID,
        { ...dto, fechaDevolucion: '2026-12-12T18:00:00.001Z' },
        AHORA,
      ),
    ).rejects.toThrow(UnprocessableEntityException);
    expect(registrarDevolucion).not.toHaveBeenCalled();
  });

  it('compara el instante y no el texto: una hora con otra zona', async () => {
    const { service } = crearServicio();

    // 12:30 en -06:00 son las 18:30 UTC: es futura respecto a las 18:00 UTC.
    await expect(
      service.registrar(
        RESERVA_ID,
        ARRENDADOR_ID,
        { ...dto, fechaDevolucion: '2026-12-12T12:30:00-06:00' },
        AHORA,
      ),
    ).rejects.toThrow(UnprocessableEntityException);
    // 11:30 en -06:00 son las 17:30 UTC: ya pasó.
    await expect(
      service.registrar(
        RESERVA_ID,
        ARRENDADOR_ID,
        { ...dto, fechaDevolucion: '2026-12-12T11:30:00-06:00' },
        AHORA,
      ),
    ).resolves.toBeDefined();
  });

  it.each([
    ['NO_EXISTE', NotFoundException, 'La reserva no existe.'],
    [
      'NO_ES_PROPIETARIO',
      ForbiddenException,
      'No tienes permiso para registrar esta devolución.',
    ],
    [
      'NO_EN_CURSO',
      ConflictException,
      'No se puede registrar la devolución porque el alquiler no ha iniciado.',
    ],
    [
      'YA_DEVUELTA',
      ConflictException,
      'La devolución de esta reserva ya fue registrada.',
    ],
    [
      'CIERRE_AUTOMATICO',
      ConflictException,
      'La reserva ya fue cerrada automáticamente por vencimiento del plazo.',
    ],
  ] as const)('traduce el rechazo %s', async (rechazo, excepcion, mensaje) => {
    const { service } = crearServicio({ rechazo });

    const error = await service
      .registrar(RESERVA_ID, ARRENDADOR_ID, dto, AHORA)
      .catch((e: unknown) => e);

    expect(error).toBeInstanceOf(excepcion);
    expect((error as Error).message).toBe(mensaje);
  });
});
