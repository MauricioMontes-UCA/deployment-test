import {
  BadRequestException,
  ConflictException,
  ForbiddenException,
  Injectable,
  Logger,
  NotFoundException,
  UnprocessableEntityException,
} from '@nestjs/common';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { BienRepository } from '@Bienes/repositories';
import {
  hoyEn,
  parseDia,
  ultimoDiaDeVentana,
  ZONA_HORARIA,
} from '@Bienes/utils';
import {
  ReservaRepository,
  type ConflictoReserva,
  type ReservaConsulta,
} from '@Reservas/repositories';
import { SOLICITUD_ENCOLADA, SolicitudEncoladaEvent } from '@Reservas/events';
import { VerificacionService } from '@Verificaciones/services';
import {
  RESERVAS_RECIBIDAS_POR_PAGINA,
  type ConsultarReservasRecibidasDto,
  type CreateReservaDto,
} from '@Reservas/dto';
import type { Reserva, EstadoReserva } from '@PrismaClient';

/** Duración máxima de una reserva, contando el primer y el último día. */
export const MAXIMO_DIAS_RESERVA = 30;

/** Qué tan adelante puede empezar una reserva, en meses desde hoy. */
export const MAXIMO_MESES_ANTICIPACION = 12;

const MS_POR_DIA = 24 * 60 * 60 * 1000;

const MENSAJES_CONFLICTO: Record<ConflictoReserva, string> = {
  RESERVA_OCUPADA: 'Las fechas se solapan con una reserva existente del bien.',
  BLOQUEO: 'Las fechas se solapan con un bloqueo del bien.',
  SOLICITUD_PROPIA_EN_COLA:
    'Ya tienes una solicitud en cola para este bien en fechas que se solapan.',
};

/**
 * Lógica de negocio de las reservas.
 *
 * No conoce Prisma: el acceso a datos pasa por los repositorios.
 */
@Injectable()
export class ReservasService {
  private readonly logger = new Logger(ReservasService.name);

  constructor(
    private readonly reservaRepository: ReservaRepository,
    private readonly bienRepository: BienRepository,
    private readonly verificacionService: VerificacionService,
    private readonly eventEmitter: EventEmitter2,
  ) {}

  /**
   * Reservas recibidas en los bienes del arrendador autenticado (BE-27.1),
   * de a `RESERVAS_RECIBIDAS_POR_PAGINA`.
   *
   * `arrendadorId` es siempre el usuario del token. Una página posterior a la
   * última devuelve `reservas` vacío, con el `total` real y `hayMas` en false.
   */
  async listarRecibidas(
    arrendadorId: string,
    { estado, pagina }: ConsultarReservasRecibidasDto,
  ): Promise<{
    reservas: ReservaConsulta[];
    pagina: number;
    total: number;
    hayMas: boolean;
  }> {
    const limite = RESERVAS_RECIBIDAS_POR_PAGINA;
    const { reservas, total } = await this.reservaRepository.findRecibidas({
      arrendadorId,
      estado,
      desplazamiento: (pagina - 1) * limite,
      limite,
    });

    return { reservas, pagina, total, hayMas: pagina * limite < total };
  }

  async listarMias(
    arrendatarioId: string,
    estado?: EstadoReserva,
  ): Promise<ReservaConsulta[]> {
    return this.reservaRepository.findMias(arrendatarioId, estado);
  }

  /**
   * Detalle de una reserva para sus dos participantes: el arrendatario que la
   * solicitó y el arrendador dueño del bien (BE-27.2).
   *
   * Una reserva ajena responde igual que una inexistente (404, mismo mensaje),
   * para no revelar que existe.
   *
   * @throws {NotFoundException} la reserva no existe o el usuario no participa.
   */
  async consultarPorId(
    id: string,
    usuarioId: string,
  ): Promise<ReservaConsulta> {
    const reserva = await this.reservaRepository.findDeParticipante(
      id,
      usuarioId,
    );

    if (!reserva) {
      throw new NotFoundException('La reserva no existe.');
    }

    return reserva;
  }

  /**
   * Valida la solicitud y la inserta como EN_COLA. No retiene fechas: la
   * confirmación la decide después el procesador de la cola.
   *
   * @throws {BadRequestException} una fecha no es un día real.
   * @throws {UnprocessableEntityException} inicio anterior a hoy, fin anterior
   * a inicio, más de 30 días o bien propio.
   * @throws {NotFoundException} el bien no existe o no está activo.
   * @throws {ForbiddenException} el bien exige verificación y el usuario no la tiene.
   * @throws {ConflictException} las fechas chocan con una reserva, un bloqueo
   * o una solicitud propia en cola.
   *
   * `ahora` se recibe para poder probar la regla "no anterior a hoy".
   */
  async solicitar(
    arrendatarioId: string,
    { bienId, fechaInicio, fechaFin }: CreateReservaDto,
    ahora: Date = new Date(),
  ): Promise<Reserva> {
    const inicio = this.parsear('fechaInicio', fechaInicio);
    const fin = this.parsear('fechaFin', fechaFin);

    this.validarFechas(inicio, fin, hoyEn(ZONA_HORARIA, ahora));

    const bien = await this.bienRepository.findActivoParaReserva(bienId);
    if (!bien) {
      throw new NotFoundException('El bien no existe.');
    }
    if (bien.arrendadorId === arrendatarioId) {
      throw new UnprocessableEntityException(
        'No puedes reservar un bien propio.',
      );
    }

    if (
      !(await this.verificacionService.puedeReservar({
        arrendatarioId,
        bienId,
      }))
    ) {
      throw new ForbiddenException({
        codigo: 'VERIFICACION_REQUERIDA',
        mensaje: 'Este bien solo se renta a usuarios verificados.',
      });
    }

    const datos = {
      bienId,
      arrendatarioId,
      fechaInicio: inicio,
      fechaFin: fin,
    };
    const resultado = await this.reservaRepository.encolar(datos);
    if ('conflicto' in resultado) {
      throw new ConflictException(MENSAJES_CONFLICTO[resultado.conflicto]);
    }

    this.emitirSolicitudEncolada(resultado.reserva);
    return resultado.reserva;
  }

  /**
   * Avisa que hay una solicitud nueva en la cola.
   *
   * La solicitud ya está guardada, así que un oyente que falle no debe
   * convertir la respuesta en un 500: el cliente reintentaría y chocaría con su
   * propia solicitud en cola (409). El error se registra y se sigue.
   */
  private emitirSolicitudEncolada(reserva: Reserva): void {
    try {
      this.eventEmitter.emit(
        SOLICITUD_ENCOLADA,
        new SolicitudEncoladaEvent(
          reserva.id,
          reserva.bienId,
          reserva.arrendatarioId,
          reserva.fechaInicio,
          reserva.fechaFin,
          reserva.creadaEn,
        ),
      );
    } catch (error) {
      this.logger.error(
        `Falló un oyente de ${SOLICITUD_ENCOLADA} (reserva ${reserva.id}).`,
        error instanceof Error ? error.stack : String(error),
      );
    }
  }

  private validarFechas(inicio: Date, fin: Date, hoy: Date): void {
    if (inicio < hoy) {
      throw new UnprocessableEntityException(
        'La fecha de inicio no puede ser anterior a hoy.',
      );
    }
    // El mismo horizonte que el calendario de disponibilidad (12 meses desde hoy).
    if (inicio > ultimoDiaDeVentana(hoy, MAXIMO_MESES_ANTICIPACION)) {
      throw new UnprocessableEntityException(
        `La fecha de inicio no puede ser más de ${MAXIMO_MESES_ANTICIPACION} meses posterior a hoy.`,
      );
    }
    if (fin < inicio) {
      throw new UnprocessableEntityException(
        'La fecha de fin no puede ser anterior a la fecha de inicio.',
      );
    }
    // Inclusivo: del día 10 al 39 son 30 días; del 10 al 40, 31.
    const dias =
      Math.round((fin.getTime() - inicio.getTime()) / MS_POR_DIA) + 1;
    if (dias > MAXIMO_DIAS_RESERVA) {
      throw new UnprocessableEntityException(
        `La reserva no puede durar más de ${MAXIMO_DIAS_RESERVA} días (contando el primero y el último); la solicitada dura ${dias}.`,
      );
    }
  }

  private parsear(campo: string, valor: string): Date {
    const fecha = parseDia(valor);
    if (!fecha) {
      throw new BadRequestException(
        `\`${campo}\` no es una fecha válida (YYYY-MM-DD).`,
      );
    }
    return fecha;
  }
}
