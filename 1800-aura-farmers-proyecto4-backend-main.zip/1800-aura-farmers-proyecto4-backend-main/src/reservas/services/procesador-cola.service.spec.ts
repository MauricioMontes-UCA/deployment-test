import {
  MotivoRechazo,
  type DecisionSolicitud,
  type ReservaRepository,
  type ResolverSolicitud,
  type ResultadoProcesamiento,
  type SolicitudEnCola,
} from '@Reservas/repositories';
import {
  ProcesadorColaService,
  TIEMPO_MAXIMO_EN_COLA_MS,
} from './procesador-cola.service.js';
import type { Prisma } from '@PrismaClient';
import type { VerificacionService } from '@Verificaciones/services';

const AHORA = new Date('2026-11-12T18:00:00.000Z');

const solicitud = (creadaHaceMs: number): SolicitudEnCola => ({
  id: 'reserva-1',
  bienId: 'bien-1',
  arrendatarioId: 'usuario-1',
  fechaInicio: new Date('2026-12-10T00:00:00.000Z'),
  fechaFin: new Date('2026-12-12T00:00:00.000Z'),
  creadaEn: new Date(AHORA.getTime() - creadaHaceMs),
});

/**
 * El repositorio falso ejecuta el resolver con la solicitud dada, como haría la
 * transacción real, y guarda la decisión para poder inspeccionarla.
 */
function crear(opciones: {
  puedeReservar?: boolean;
  ocupado?: boolean;
  creadaHaceMs?: number;
}) {
  const {
    puedeReservar = true,
    ocupado = false,
    creadaHaceMs = 1000,
  } = opciones;
  const consultarOcupado = vi.fn().mockResolvedValue(ocupado);
  const puede = vi.fn().mockResolvedValue(puedeReservar);
  const decisiones: DecisionSolicitud[] = [];
  // La transacción en curso: el procesador debe usarla, no el pool.
  const tx = {} as Prisma.TransactionClient;
  const repository = {
    procesarSiguiente: vi.fn(
      async (_ahora: Date, resolver: ResolverSolicitud) => {
        decisiones.push(
          await resolver(solicitud(creadaHaceMs), consultarOcupado, tx),
        );
        return { tipo: 'COLA_VACIA' } as ResultadoProcesamiento;
      },
    ),
  };
  const service = new ProcesadorColaService(
    repository as unknown as ReservaRepository,
    { puedeReservar: puede } as unknown as VerificacionService,
  );
  return { service, repository, puede, consultarOcupado, decisiones, tx };
}

describe('ProcesadorColaService.procesarSiguiente', () => {
  it('confirma la solicitud si la verificación es válida y las fechas están libres', async () => {
    const { service, repository, decisiones } = crear({});

    await service.procesarSiguiente(AHORA);

    expect(decisiones).toEqual([{ estado: 'CONFIRMADA' }]);
    expect(repository.procesarSiguiente).toHaveBeenCalledWith(
      AHORA,
      expect.any(Function),
    );
  });

  it('rechaza con VERIFICACION_REQUERIDA si ya no puede reservar el bien', async () => {
    const { service, puede, consultarOcupado, decisiones, tx } = crear({
      puedeReservar: false,
    });

    await service.procesarSiguiente(AHORA);

    expect(decisiones).toEqual([
      { estado: 'RECHAZADA', motivo: MotivoRechazo.VERIFICACION_REQUERIDA },
    ]);
    // Comprueba la verificación con la transacción en curso: con otra conexión
    // del pool, varios procesadores a la vez agotan el pool y expiran.
    expect(puede).toHaveBeenCalledWith(
      { arrendatarioId: 'usuario-1', bienId: 'bien-1' },
      tx,
    );
    // Con la verificación fallida no hace falta mirar las fechas.
    expect(consultarOcupado).not.toHaveBeenCalled();
  });

  it('rechaza con FECHAS_NO_DISPONIBLES si las fechas están ocupadas', async () => {
    const { service, decisiones } = crear({ ocupado: true });

    await service.procesarSiguiente(AHORA);

    expect(decisiones).toEqual([
      { estado: 'RECHAZADA', motivo: MotivoRechazo.FECHAS_NO_DISPONIBLES },
    ]);
  });

  it('rechaza con ERROR_DE_PROCESAMIENTO si lleva más de 5 minutos en cola, sin consultar nada más', async () => {
    const { service, puede, consultarOcupado, decisiones } = crear({
      creadaHaceMs: TIEMPO_MAXIMO_EN_COLA_MS + 1,
    });

    await service.procesarSiguiente(AHORA);

    expect(decisiones).toEqual([
      { estado: 'RECHAZADA', motivo: MotivoRechazo.ERROR_DE_PROCESAMIENTO },
    ]);
    expect(puede).not.toHaveBeenCalled();
    expect(consultarOcupado).not.toHaveBeenCalled();
  });

  it('con exactamente 5 minutos en cola todavía la procesa', async () => {
    const { service, decisiones } = crear({
      creadaHaceMs: TIEMPO_MAXIMO_EN_COLA_MS,
    });

    await service.procesarSiguiente(AHORA);

    expect(decisiones).toEqual([{ estado: 'CONFIRMADA' }]);
  });
});

describe('ProcesadorColaService.procesarPendientes', () => {
  const procesada = {
    tipo: 'PROCESADA',
    reserva: {},
  } as ResultadoProcesamiento;
  const vacia: ResultadoProcesamiento = { tipo: 'COLA_VACIA' };

  function conResultados(...resultados: ResultadoProcesamiento[]) {
    const procesarSiguiente = vi.fn();
    for (const resultado of resultados) {
      procesarSiguiente.mockResolvedValueOnce(resultado);
    }
    procesarSiguiente.mockResolvedValue(vacia);
    const service = new ProcesadorColaService(
      { procesarSiguiente } as unknown as ReservaRepository,
      {} as VerificacionService,
    );
    return { service, procesarSiguiente };
  }

  it('procesa hasta vaciar la cola y devuelve cuántas resolvió', async () => {
    const { service, procesarSiguiente } = conResultados(
      procesada,
      procesada,
      procesada,
    );

    await expect(service.procesarPendientes()).resolves.toBe(3);
    expect(procesarSiguiente).toHaveBeenCalledTimes(4);
  });

  it('con la cola vacía no hace nada más', async () => {
    const { service, procesarSiguiente } = conResultados();

    await expect(service.procesarPendientes()).resolves.toBe(0);
    expect(procesarSiguiente).toHaveBeenCalledTimes(1);
  });

  it('se detiene si la siguiente queda aplazada, para no dar vueltas sobre la misma', async () => {
    const { service, procesarSiguiente } = conResultados(procesada, {
      tipo: 'APLAZADA',
    });

    await expect(service.procesarPendientes()).resolves.toBe(1);
    expect(procesarSiguiente).toHaveBeenCalledTimes(2);
  });

  it('no lanza si el repositorio falla: registra el error y devuelve lo procesado', async () => {
    const { service, procesarSiguiente } = conResultados();
    procesarSiguiente
      .mockReset()
      .mockResolvedValueOnce(procesada)
      .mockRejectedValueOnce(new Error('conexión caída'));
    const error = vi
      .spyOn(
        (service as unknown as { logger: { error: () => void } }).logger,
        'error',
      )
      .mockImplementation(() => undefined);

    await expect(service.procesarPendientes()).resolves.toBe(1);
    expect(error).toHaveBeenCalledOnce();
  });

  it('una llamada mientras corre otra no abre una corrida paralela, pero repite al terminar', async () => {
    let liberar!: (resultado: ResultadoProcesamiento) => void;
    const bloqueada = new Promise<ResultadoProcesamiento>((resolver) => {
      liberar = resolver;
    });
    const procesarSiguiente = vi
      .fn()
      .mockReturnValueOnce(bloqueada)
      .mockResolvedValue(vacia);
    const service = new ProcesadorColaService(
      { procesarSiguiente } as unknown as ReservaRepository,
      {} as VerificacionService,
    );

    const primera = service.procesarPendientes();
    const segunda = service.procesarPendientes();
    expect(segunda).toBe(primera);
    expect(procesarSiguiente).toHaveBeenCalledTimes(1);

    liberar(procesada);
    await primera;
    // 1.ª corrida: procesada + vacía; la repetición pedida: otra revisión vacía.
    expect(procesarSiguiente).toHaveBeenCalledTimes(3);
  });

  it('permite una corrida nueva cuando la anterior terminó', async () => {
    const { service, procesarSiguiente } = conResultados();

    await service.procesarPendientes();
    await service.procesarPendientes();

    expect(procesarSiguiente).toHaveBeenCalledTimes(2);
  });
});
