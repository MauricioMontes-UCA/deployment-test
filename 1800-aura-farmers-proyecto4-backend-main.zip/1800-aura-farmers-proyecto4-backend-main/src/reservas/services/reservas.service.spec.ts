import { describe, expect, it, vi } from 'vitest';
import {
  BadRequestException,
  ConflictException,
  ForbiddenException,
  Logger,
  NotFoundException,
  UnprocessableEntityException,
} from '@nestjs/common';
import {
  Prisma,
  EstadoReserva,
  UnidadCobro,
} from '@PrismaClient';import { ReservasService } from './reservas.service.js';
import { SOLICITUD_ENCOLADA, SolicitudEncoladaEvent } from '@Reservas/events';
import type { EventEmitter2 } from '@nestjs/event-emitter';
import type { BienRepository } from '@Bienes/repositories';
import type {
  ReservaConsulta,
  ReservaRepository,
} from '@Reservas/repositories';
import type { VerificacionService } from '@Verificaciones/services';
import type { ConflictoReserva } from '@Reservas/repositories';

const BIEN_ID = '7c9e6679-7425-40de-944b-e07fc1f90ae7';
const ARRENDATARIO_ID = 'arrendatario-1';
const ARRENDADOR_ID = 'arrendador-1';
// 03:00 UTC del 13 de noviembre = 12 de noviembre, 21:00 en El Salvador.
const AHORA = new Date('2026-11-13T03:00:00.000Z');

const dia = (valor: string) => new Date(`${valor}T00:00:00.000Z`);

const reserva: ReservaConsulta = {
  id: '3f2504e0-4f89-41d3-9a0c-0305e82c3301',
  bienId: BIEN_ID,
  arrendatarioId: 'usuario-1',

  fechaInicio: new Date('2026-12-10T00:00:00.000Z'),
  fechaFin: new Date('2026-12-12T00:00:00.000Z'),

  estado: EstadoReserva.EN_COLA,
  motivoResolucion: null,

  creadaEn: new Date('2026-11-14T12:00:00.000Z'),
  procesadaEn: null,
  finalizadaEn: null,

  bien: {
    id: BIEN_ID,
    titulo: 'Cámara profesional',
    precio: new Prisma.Decimal('25.00'),
    unidadCobro: UnidadCobro.DIA,

    arrendador: {
      id: ARRENDADOR_ID,
      nombreUsuario: 'arrendador',
    },

    fotos: [
      {
        url: 'https://ejemplo.com/camara.jpg',
      },
    ],
  },

  arrendatario: {
    id: 'usuario-1',
    nombreUsuario: 'arrendatario',
  },

  pagos: [],

  deposito: null,
};

function crearServicio() {
  const repo = {
    findMias: vi.fn(),
    findDeParticipante: vi.fn(),
  };

  const bienRepository = {
    findActivoParaReserva: vi.fn(),
  };

  const verificacionService = {
    puedeReservar: vi.fn(),
  };

  const eventEmitter = {
    emit: vi.fn(),
  };

  const service = new ReservasService(
    repo as unknown as ReservaRepository,
    bienRepository as unknown as BienRepository,
    verificacionService as unknown as VerificacionService,
    eventEmitter as unknown as EventEmitter2,
  );

  return { repo, service };
}

describe('ReservasService (BE-6.3)', () => {
  it('lista únicamente por el identificador autenticado, sin filtro', async () => {
    const { repo, service } = crearServicio();
    repo.findMias.mockResolvedValue([reserva]);
    expect(await service.listarMias('usuario-1')).toEqual([reserva]);
    expect(repo.findMias).toHaveBeenCalledWith('usuario-1', undefined);
  });

  it.each([
    EstadoReserva.EN_COLA,
    EstadoReserva.CONFIRMADA,
    EstadoReserva.RECHAZADA,
    EstadoReserva.CANCELADA,
    EstadoReserva.EN_CURSO,
    EstadoReserva.FINALIZADA,
  ])('envía el filtro %s al repositorio', async (estado) => {
    const { repo, service } = crearServicio();
    repo.findMias.mockResolvedValue([]);
    await service.listarMias('usuario-1', estado);
    expect(repo.findMias).toHaveBeenCalledWith('usuario-1', estado);
  });

  it('devuelve la reserva a un participante, buscándola por id y usuario', async () => {
    const { repo, service } = crearServicio();
    repo.findDeParticipante.mockResolvedValue(reserva);
    expect(await service.consultarPorId(reserva.id, 'usuario-1')).toEqual(
      reserva,
    );
    expect(repo.findDeParticipante).toHaveBeenCalledWith(
      reserva.id,
      'usuario-1',
    );
  });

  it('el arrendador dueño del bien también la recibe (la pertenencia la filtra el repositorio)', async () => {
    const { repo, service } = crearServicio();
    repo.findDeParticipante.mockResolvedValue(reserva);
    expect(await service.consultarPorId(reserva.id, 'arrendador-1')).toEqual(
      reserva,
    );
    expect(repo.findDeParticipante).toHaveBeenCalledWith(
      reserva.id,
      'arrendador-1',
    );
  });

  it('responde 404 cuando la reserva no existe o es ajena', async () => {
    const { repo, service } = crearServicio();
    repo.findDeParticipante.mockResolvedValue(null);
    await expect(
      service.consultarPorId(reserva.id, 'usuario-2'),
    ).rejects.toBeInstanceOf(NotFoundException);
  });

  it('una reserva ajena y una inexistente responden con el mismo mensaje', async () => {
    const { repo, service } = crearServicio();
    repo.findDeParticipante.mockResolvedValue(null);
    const ajena = service.consultarPorId(reserva.id, 'usuario-2');
    const inexistente = service.consultarPorId(
      '00000000-0000-4000-8000-000000000000',
      'usuario-1',
    );
    await expect(ajena).rejects.toThrow('La reserva no existe.');
    await expect(inexistente).rejects.toThrow('La reserva no existe.');
  });

  it('no lanza ForbiddenException para una reserva ajena', async () => {
    const { repo, service } = crearServicio();
    repo.findDeParticipante.mockResolvedValue(null);
    await expect(
      service.consultarPorId(reserva.id, 'usuario-2'),
    ).rejects.not.toBeInstanceOf(ForbiddenException);
  });
});

function crear({
  bien = { id: BIEN_ID, arrendadorId: ARRENDADOR_ID } as {
    id: string;
    arrendadorId: string;
  } | null,
  puedeReservar = true,
  conflicto = null as ConflictoReserva | null,
} = {}) {
  const reservaGuardada = {
    id: 'reserva-1',
    bienId: BIEN_ID,
    arrendatarioId: ARRENDATARIO_ID,
    fechaInicio: dia('2026-12-10'),
    fechaFin: dia('2026-12-12'),
    estado: 'EN_COLA',
    creadaEn: new Date('2026-11-12T21:00:00.000Z'),
  };
  const reservaRepository = {
    encolar: vi
      .fn()
      .mockResolvedValue(
        conflicto ? { conflicto } : { reserva: reservaGuardada },
      ),
  };
  const bienRepository = {
    findActivoParaReserva: vi.fn().mockResolvedValue(bien),
  };
  const verificacionService = {
    puedeReservar: vi.fn().mockResolvedValue(puedeReservar),
  };
  const eventEmitter = { emit: vi.fn() };
  const service = new ReservasService(
    reservaRepository as unknown as ReservaRepository,
    bienRepository as unknown as BienRepository,
    verificacionService as unknown as VerificacionService,
    eventEmitter as unknown as EventEmitter2,
  );
  return {
    service,
    reservaRepository,
    bienRepository,
    verificacionService,
    eventEmitter,
    reservaGuardada,
  };
}

const dto = (fechaInicio: string, fechaFin: string) => ({
  bienId: BIEN_ID,
  fechaInicio,
  fechaFin,
});

describe('ReservasService.solicitar', () => {
  it('con fechas libres inserta la solicitud y la devuelve', async () => {
    const { service, reservaRepository, reservaGuardada } = crear();

    const reserva = await service.solicitar(
      ARRENDATARIO_ID,
      dto('2026-12-10', '2026-12-12'),
      AHORA,
    );

    expect(reserva).toBe(reservaGuardada);
    expect(reservaRepository.encolar).toHaveBeenCalledWith({
      bienId: BIEN_ID,
      arrendatarioId: ARRENDATARIO_ID,
      fechaInicio: dia('2026-12-10'),
      fechaFin: dia('2026-12-12'),
    });
  });

  it('emite el evento "solicitud encolada" con los datos de la solicitud', async () => {
    const { service, eventEmitter, reservaGuardada } = crear();

    await service.solicitar(
      ARRENDATARIO_ID,
      dto('2026-12-10', '2026-12-12'),
      AHORA,
    );

    expect(eventEmitter.emit).toHaveBeenCalledOnce();
    const [nombre, evento] = eventEmitter.emit.mock.calls[0]!;
    expect(nombre).toBe(SOLICITUD_ENCOLADA);
    expect(evento).toBeInstanceOf(SolicitudEncoladaEvent);
    expect(evento).toMatchObject({
      reservaId: reservaGuardada.id,
      bienId: BIEN_ID,
      arrendatarioId: ARRENDATARIO_ID,
    });
  });

  it('si un oyente del evento falla, igual devuelve la solicitud ya guardada', async () => {
    const { service, eventEmitter, reservaGuardada } = crear();
    eventEmitter.emit.mockImplementation(() => {
      throw new Error('falla el oyente');
    });
    // El error se registra; se silencia para no ensuciar la salida de la prueba.
    vi.spyOn(Logger.prototype, 'error').mockImplementation(() => undefined);

    await expect(
      service.solicitar(
        ARRENDATARIO_ID,
        dto('2026-12-10', '2026-12-12'),
        AHORA,
      ),
    ).resolves.toBe(reservaGuardada);
  });

  it('acepta empezar hoy (día de El Salvador, no el de UTC)', async () => {
    const { service } = crear();

    await expect(
      service.solicitar(
        ARRENDATARIO_ID,
        dto('2026-11-12', '2026-11-12'),
        AHORA,
      ),
    ).resolves.toBeDefined();
  });

  describe('anticipación máxima de 12 meses', () => {
    // hoy es el 2026-11-12, así que el último inicio permitido es el 2027-11-11.
    it('acepta empezar el último día del horizonte', async () => {
      const { service } = crear();

      await expect(
        service.solicitar(
          ARRENDATARIO_ID,
          dto('2027-11-11', '2027-11-12'),
          AHORA,
        ),
      ).resolves.toBeDefined();
    });

    it('rechaza empezar un día después, con el motivo', async () => {
      const { service, bienRepository } = crear();

      const promesa = service.solicitar(
        ARRENDATARIO_ID,
        dto('2027-11-12', '2027-11-13'),
        AHORA,
      );

      await expect(promesa).rejects.toThrow(UnprocessableEntityException);
      await expect(promesa).rejects.toThrow(/12 meses posterior a hoy/);
      expect(bienRepository.findActivoParaReserva).not.toHaveBeenCalled();
    });

    it('rechaza un año absurdo', async () => {
      const { service } = crear();

      await expect(
        service.solicitar(
          ARRENDATARIO_ID,
          dto('9999-12-31', '9999-12-31'),
          AHORA,
        ),
      ).rejects.toThrow(UnprocessableEntityException);
    });
  });

  describe('30 días inclusivos', () => {
    it('del día 10 al 39 es válido', async () => {
      const { service } = crear();

      await expect(
        service.solicitar(
          ARRENDATARIO_ID,
          dto('2026-12-10', '2027-01-08'),
          AHORA,
        ),
      ).resolves.toBeDefined();
    });

    it('del día 10 al 40 responde 422 con el motivo', async () => {
      const { service } = crear();

      await expect(
        service.solicitar(
          ARRENDATARIO_ID,
          dto('2026-12-10', '2027-01-09'),
          AHORA,
        ),
      ).rejects.toThrow(/más de 30 días/);
    });
  });

  it.each([
    ['inicio anterior a hoy', '2026-11-11', '2026-11-12', /anterior a hoy/],
    [
      'fin anterior a inicio',
      '2026-12-12',
      '2026-12-10',
      /fin no puede ser anterior/,
    ],
  ])(
    'responde 422 si hay %s, con un mensaje que explica el motivo',
    async (_caso, inicio, fin, mensaje) => {
      const { service, bienRepository } = crear();

      const promesa = service.solicitar(
        ARRENDATARIO_ID,
        dto(inicio, fin),
        AHORA,
      );

      await expect(promesa).rejects.toThrow(UnprocessableEntityException);
      await expect(promesa).rejects.toThrow(mensaje);
      // Las reglas de fechas se validan antes de tocar la base.
      expect(bienRepository.findActivoParaReserva).not.toHaveBeenCalled();
    },
  );

  it('responde 422 si el bien es del propio usuario', async () => {
    const { service, reservaRepository } = crear({
      bien: { id: BIEN_ID, arrendadorId: ARRENDATARIO_ID },
    });

    const promesa = service.solicitar(
      ARRENDATARIO_ID,
      dto('2026-12-10', '2026-12-12'),
      AHORA,
    );

    await expect(promesa).rejects.toThrow(UnprocessableEntityException);
    await expect(promesa).rejects.toThrow(/bien propio/);
    expect(reservaRepository.encolar).not.toHaveBeenCalled();
  });

  it.each([
    ['no es un día real', '2026-02-30', '2026-12-12'],
    ['no es un día real (fin)', '2026-12-10', '2026-13-01'],
  ])('responde 400 si la fecha %s', async (_caso, inicio, fin) => {
    const { service } = crear();

    await expect(
      service.solicitar(ARRENDATARIO_ID, dto(inicio, fin), AHORA),
    ).rejects.toThrow(BadRequestException);
  });

  it('responde 404 si el bien no existe o no está activo', async () => {
    const { service, reservaRepository } = crear({ bien: null });

    await expect(
      service.solicitar(
        ARRENDATARIO_ID,
        dto('2026-12-10', '2026-12-12'),
        AHORA,
      ),
    ).rejects.toThrow(NotFoundException);
    expect(reservaRepository.encolar).not.toHaveBeenCalled();
  });

  it('responde 403 con el código VERIFICACION_REQUERIDA si no puede reservar', async () => {
    const { service, reservaRepository, verificacionService } = crear({
      puedeReservar: false,
    });

    const promesa = service.solicitar(
      ARRENDATARIO_ID,
      dto('2026-12-10', '2026-12-12'),
      AHORA,
    );

    await expect(promesa).rejects.toThrow(ForbiddenException);
    await expect(promesa).rejects.toMatchObject({
      response: {
        codigo: 'VERIFICACION_REQUERIDA',
        mensaje: 'Este bien solo se renta a usuarios verificados.',
      },
    });
    expect(verificacionService.puedeReservar).toHaveBeenCalledWith({
      arrendatarioId: ARRENDATARIO_ID,
      bienId: BIEN_ID,
    });
    expect(reservaRepository.encolar).not.toHaveBeenCalled();
  });

  it.each<ConflictoReserva>([
    'RESERVA_OCUPADA',
    'BLOQUEO',
    'SOLICITUD_PROPIA_EN_COLA',
  ])(
    'responde 409 y no emite el evento si hay conflicto (%s)',
    async (conflicto) => {
      const { service, eventEmitter } = crear({ conflicto });

      await expect(
        service.solicitar(
          ARRENDATARIO_ID,
          dto('2026-12-10', '2026-12-12'),
          AHORA,
        ),
      ).rejects.toThrow(ConflictException);
      expect(eventEmitter.emit).not.toHaveBeenCalled();
    },
  );
});
