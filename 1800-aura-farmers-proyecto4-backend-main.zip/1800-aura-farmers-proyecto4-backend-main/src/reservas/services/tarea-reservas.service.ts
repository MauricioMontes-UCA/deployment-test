import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { DepositoService } from '@Depositos/services';
import type { EnvConfig } from '@Config';
import { TareaReservasRepository } from '@Reservas/repositories';
import { diaFecha, fechaLocal, plazoVencido } from '@Reservas/utils';

export interface ResumenTareaReservas {
  iniciadas: number;
  finalizadas: number;
  depositosLiberados: number;
  errores: number;
}

@Injectable()
export class TareaReservasService {
  private readonly logger = new Logger(TareaReservasService.name);

  constructor(
    private readonly repository: TareaReservasRepository,
    private readonly depositos: DepositoService,
    private readonly config: ConfigService<EnvConfig, true>,
  ) {}

  /** Ejecutable manualmente en tests; el worker controla el candado global. */
  async ejecutar(ahora: Date = new Date()): Promise<ResumenTareaReservas> {
    const hoy = fechaLocal(ahora);
    const plazoDevolucion = this.config.get('PLAZO_DEVOLUCION_DIAS', {
      infer: true,
    });
    const plazoDeposito = this.config.get('PLAZO_DEPOSITO_DIAS', {
      infer: true,
    });
    const resumen: ResumenTareaReservas = {
      iniciadas: 0,
      finalizadas: 0,
      depositosLiberados: 0,
      errores: 0,
    };
    const intentar = async (
      tipo: string,
      id: string,
      accion: () => Promise<void>,
    ) => {
      try {
        await accion();
      } catch (error) {
        resumen.errores++;
        this.logger.error(`BE-10.2 ${tipo} ${id}: ${String(error)}`);
      }
    };

    for (const reserva of await this.repository.listarConfirmadas()) {
      if (diaFecha(reserva.fechaInicio) > hoy) continue;
      await intentar('inicio', reserva.id, async () => {
        if (await this.repository.iniciar(reserva.id)) resumen.iniciadas++;
      });
    }

    for (const reserva of await this.repository.listarEnCurso()) {
      if (!plazoVencido(diaFecha(reserva.fechaFin), plazoDevolucion, hoy))
        continue;
      await intentar('cierre', reserva.id, async () => {
        if (await this.repository.cerrar(reserva.id, ahora))
          resumen.finalizadas++;
      });
    }

    // Incluye depósitos de cierres automáticos anteriores que no pudieron liberarse.
    for (const deposito of await this.repository.listarDepositosPendientes()) {
      const reserva = deposito.reserva;
      if (!reserva.finalizadaEn) continue;
      if (
        !reserva.cierreAutomatico &&
        !plazoVencido(fechaLocal(reserva.finalizadaEn), plazoDeposito, hoy)
      )
        continue;
      await intentar('deposito', deposito.id, async () => {
        await this.depositos.resolver(
          deposito.id,
          { tipo: 'SISTEMA' },
          'LIBERAR',
          undefined,
          undefined,
          ahora,
        );
        resumen.depositosLiberados++;
      });
    }

    this.logger.log(
      `BE-10.2: iniciadas=${resumen.iniciadas}, finalizadas=${resumen.finalizadas}, depositosLiberados=${resumen.depositosLiberados}, errores=${resumen.errores}`,
    );
    return resumen;
  }
}
