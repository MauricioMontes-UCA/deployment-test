import { ConfigService } from '@nestjs/config';
import type { EnvConfig } from '@Config';
import {
  ConflictException,
  ForbiddenException,
  Injectable,
  NotFoundException,
  UnprocessableEntityException,
} from '@nestjs/common';
import {
  ReservaRepository,
  type RechazoDevolucion,
} from '@Reservas/repositories';
import type { RegistrarDevolucionDto } from '@Reservas/dto';
import type { Devolucion } from '@PrismaClient';

/**
 * Días que tiene el arrendador para resolver el depósito desde que la renta
 * queda FINALIZADA. BE-10.2 aplica la liberación automática al vencer.
 */
export const PLAZO_DEPOSITO_DIAS = 3;

const RECHAZOS: Record<RechazoDevolucion, new (mensaje: string) => Error> = {
  NO_EXISTE: NotFoundException,
  NO_ES_PROPIETARIO: ForbiddenException,
  NO_EN_CURSO: ConflictException,
  YA_DEVUELTA: ConflictException,
  CIERRE_AUTOMATICO: ConflictException,
};

const MENSAJES: Record<RechazoDevolucion, string> = {
  NO_EXISTE: 'La reserva no existe.',
  NO_ES_PROPIETARIO: 'No tienes permiso para registrar esta devolución.',
  NO_EN_CURSO:
    'No se puede registrar la devolución porque el alquiler no ha iniciado.',
  YA_DEVUELTA: 'La devolución de esta reserva ya fue registrada.',
  CIERRE_AUTOMATICO:
    'La reserva ya fue cerrada automáticamente por vencimiento del plazo.',
};

/**
 * Registro de la devolución del bien (H10).
 *
 * No conoce Prisma: el acceso a datos pasa por `ReservaRepository`.
 */
@Injectable()
export class DevolucionesService {
  constructor(
    private readonly reservaRepository: ReservaRepository,
    private readonly config?: ConfigService<EnvConfig, true>,
  ) {}

  /**
   * Registra la devolución de una reserva EN_CURSO y la finaliza.
   *
   * @param arrendadorId viene del usuario autenticado, nunca del cuerpo.
   * @throws {UnprocessableEntityException} la fecha de devolución es futura.
   * @throws {NotFoundException} la reserva no existe.
   * @throws {ForbiddenException} el bien de la reserva no es del arrendador.
   * @throws {ConflictException} la reserva no está EN_CURSO, ya tiene
   * devolución o se cerró automáticamente.
   *
   * `ahora` se recibe para poder probar la regla de la fecha futura.
   */
  async registrar(
    reservaId: string,
    arrendadorId: string,
    dto: RegistrarDevolucionDto,
    ahora: Date = new Date(),
  ): Promise<Devolucion> {
    const fechaDevolucion = new Date(dto.fechaDevolucion);
    if (fechaDevolucion.getTime() > ahora.getTime()) {
      throw new UnprocessableEntityException(
        'La fecha de devolución no puede ser futura.',
      );
    }

    const resultado = await this.reservaRepository.registrarDevolucion({
      reservaId,
      registradoPorId: arrendadorId,
      fechaDevolucion,
      estadoFinalBien: dto.estadoFinalBien,
      observaciones: dto.observaciones,
      ahora,
      plazoDepositoDias:
        this.config?.get('PLAZO_DEPOSITO_DIAS', { infer: true }) ??
        PLAZO_DEPOSITO_DIAS,
    });

    if ('rechazo' in resultado) {
      throw new RECHAZOS[resultado.rechazo](MENSAJES[resultado.rechazo]);
    }
    return resultado.devolucion;
  }
}
