import { Injectable, Logger } from '@nestjs/common';
import { OnEvent } from '@nestjs/event-emitter';
import { ModuloOrigen } from '@PrismaClient';
import { NotificacionesService } from '@Notificaciones/services';
import { ReservaRepository } from '@Reservas/repositories';
import { SOLICITUD_ENCOLADA, SolicitudEncoladaEvent } from '@Reservas/events';

export const TITULO_SOLICITUD_RESERVA = 'Nueva solicitud de reserva';

export const TIPO_REFERENCIA_SOLICITUD = 'RESERVA_SOLICITADA';

export function formatearFechaReserva(fecha: Date): string {
  const dia = String(fecha.getUTCDate()).padStart(2, '0');
  const mes = String(fecha.getUTCMonth() + 1).padStart(2, '0');
  const anio = fecha.getUTCFullYear();

  return `${dia}/${mes}/${anio}`;
}

export function construirMensajeSolicitudReserva(
  nombreUsuario: string,
  nombreBien: string,
  fechaInicio: Date,
  fechaFin: Date,
): string {
  const inicio = formatearFechaReserva(fechaInicio);
  const fin = formatearFechaReserva(fechaFin);

  const sufijo = ` del ${inicio} al ${fin}.`;
  const prefijo = `${nombreUsuario} solicitó `;
  const espacioDisponible = 300 - prefijo.length - sufijo.length;

  if (espacioDisponible >= 0) {
    return prefijo + nombreBien.slice(0, espacioDisponible) + sufijo;
  }

  // Protección adicional si el nombre de usuario es
  // excepcionalmente largo.
  const texto = `${nombreUsuario} solicitó ${nombreBien}`;
  return `${texto.slice(0, 300 - sufijo.length)}${sufijo}`;
}

@Injectable()
export class NotificarSolicitudReservaListener {
  private readonly logger = new Logger(NotificarSolicitudReservaListener.name);

  constructor(
    private readonly reservaRepository: ReservaRepository,
    private readonly notificacionesService: NotificacionesService,
  ) {}

  @OnEvent(SOLICITUD_ENCOLADA)
  async procesar(evento: SolicitudEncoladaEvent): Promise<void> {
    try {
      await this.crearNotificacion(evento.reservaId);
    } catch (error) {
      this.logger.error(
        `No se pudo crear la notificación de la reserva ${evento.reservaId}.`,
        error instanceof Error ? error.stack : String(error),
      );
    }
  }

  private async crearNotificacion(reservaId: string): Promise<void> {
    const reserva =
      await this.reservaRepository.obtenerDatosParaNotificacion(reservaId);

    if (!reserva) {
      this.logger.warn(
        `No se encontró la reserva ${reservaId} para notificar.`,
      );
      return;
    }

    const mensaje = construirMensajeSolicitudReserva(
      reserva.arrendatario.nombreUsuario,
      reserva.bien.titulo,
      reserva.fechaInicio,
      reserva.fechaFin,
    );

    const resultado = await this.notificacionesService.crear(
      reserva.bien.arrendadorId,
      TITULO_SOLICITUD_RESERVA,
      mensaje,
      ModuloOrigen.RESERVAS,
      {
        tipoReferencia: TIPO_REFERENCIA_SOLICITUD,
        referenciaId: reserva.id,
      },
    );

    if (resultado.creada) {
      this.logger.log(`Notificación creada para la reserva ${reservaId}.`);
    } else {
      this.logger.debug(
        `La notificación de la reserva ${reservaId} ya existía.`,
      );
    }
  }
}
