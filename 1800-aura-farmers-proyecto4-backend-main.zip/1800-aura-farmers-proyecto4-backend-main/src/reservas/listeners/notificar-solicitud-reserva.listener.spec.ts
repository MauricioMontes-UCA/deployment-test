import { describe, expect, it, vi } from 'vitest';
import { Logger } from '@nestjs/common';
import { ModuloOrigen } from '@PrismaClient';
import type { ReservaRepository } from '@Reservas/repositories';
import type { NotificacionesService } from '@Notificaciones/services';
import { SolicitudEncoladaEvent } from '@Reservas/events';
import {
  NotificarSolicitudReservaListener,
  construirMensajeSolicitudReserva,
  formatearFechaReserva,
  TITULO_SOLICITUD_RESERVA,
  TIPO_REFERENCIA_SOLICITUD,
} from './notificar-solicitud-reserva.listener.js';

const reservaId = '11111111-1111-4111-8111-111111111111';
const bienId = '22222222-2222-4222-8222-222222222222';
const arrendatarioId = '33333333-3333-4333-8333-333333333333';
const arrendadorId = '44444444-4444-4444-8444-444444444444';

const inicio = new Date('2026-12-10T00:00:00.000Z');
const fin = new Date('2026-12-15T00:00:00.000Z');

function crearEvento() {
  return new SolicitudEncoladaEvent(
    reservaId,
    bienId,
    arrendatarioId,
    inicio,
    fin,
    new Date('2026-11-15T12:00:00.000Z'),
  );
}

function crearEscenario() {
  const obtenerDatosParaNotificacion = vi.fn().mockResolvedValue({
    id: reservaId,
    fechaInicio: inicio,
    fechaFin: fin,
    bien: {
      titulo: 'Cámara Sony Alpha',
      arrendadorId,
    },
    arrendatario: {
      nombreUsuario: 'carlos23',
    },
  });

  const crear = vi.fn().mockResolvedValue({
    creada: true,
    notificacionId: '55555555-5555-4555-8555-555555555555',
  });

  const repository = {
    obtenerDatosParaNotificacion,
  };

  const notificacionesService = { crear };

  const listener = new NotificarSolicitudReservaListener(
    repository as unknown as ReservaRepository,
    notificacionesService as unknown as NotificacionesService,
  );

  return {
    listener,
    obtenerDatosParaNotificacion,
    crear,
  };
}

describe('BE-22.1 - Notificación de solicitud de reserva', () => {
  it('formatea fechas como dd/mm/aaaa', () => {
    expect(formatearFechaReserva(inicio)).toBe('10/12/2026');
  });

  it('construye el mensaje con usuario, bien y fechas', () => {
    const mensaje = construirMensajeSolicitudReserva(
      'carlos23',
      'Cámara Sony Alpha',
      inicio,
      fin,
    );

    expect(mensaje).toBe(
      'carlos23 solicitó Cámara Sony Alpha del 10/12/2026 al 15/12/2026.',
    );
  });

  it('respeta el máximo de 300 caracteres', () => {
    const mensaje = construirMensajeSolicitudReserva(
      'carlos23',
      'A'.repeat(500),
      inicio,
      fin,
    );

    expect(mensaje.length).toBeLessThanOrEqual(300);
    expect(mensaje).toContain('10/12/2026');
    expect(mensaje).toContain('15/12/2026');
  });

  it('notifica exclusivamente al propietario del bien', async () => {
    const { listener, obtenerDatosParaNotificacion, crear } = crearEscenario();

    await listener.procesar(crearEvento());

    expect(obtenerDatosParaNotificacion).toHaveBeenCalledExactlyOnceWith(
      reservaId,
    );

    expect(crear).toHaveBeenCalledExactlyOnceWith(
      arrendadorId,
      TITULO_SOLICITUD_RESERVA,
      'carlos23 solicitó Cámara Sony Alpha del 10/12/2026 al 15/12/2026.',
      ModuloOrigen.RESERVAS,
      {
        tipoReferencia: TIPO_REFERENCIA_SOLICITUD,
        referenciaId: reservaId,
      },
    );
  });

  it('no crea avisos para una reserva inexistente', async () => {
    const { listener, obtenerDatosParaNotificacion, crear } = crearEscenario();

    obtenerDatosParaNotificacion.mockResolvedValue(null);

    await listener.procesar(crearEvento());

    expect(crear).not.toHaveBeenCalled();
  });

  it('registra un error sin propagarlo al flujo de reserva', async () => {
    const { listener, crear } = crearEscenario();

    const logError = vi
      .spyOn(Logger.prototype, 'error')
      .mockImplementation(() => undefined);

    try {
      crear.mockRejectedValue(new Error('Fallo simulado de notificaciones'));

      await expect(listener.procesar(crearEvento())).resolves.toBeUndefined();

      expect(logError).toHaveBeenCalled();
    } finally {
      logError.mockRestore();
    }
  });

  it('utiliza la misma referencia en dos procesamientos', async () => {
    const { listener, crear } = crearEscenario();

    await listener.procesar(crearEvento());
    await listener.procesar(crearEvento());

    expect(crear).toHaveBeenCalledTimes(2);

    expect(crear.mock.calls[0]?.[4]).toEqual(crear.mock.calls[1]?.[4]);
  });
});
