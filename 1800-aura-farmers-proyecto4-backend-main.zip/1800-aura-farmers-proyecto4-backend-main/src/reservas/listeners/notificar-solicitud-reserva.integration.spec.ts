import { randomUUID } from 'node:crypto';
import { Test, type TestingModule } from '@nestjs/testing';
import { EventEmitterModule } from '@nestjs/event-emitter';
import { PrismaPg } from '@prisma/adapter-pg';
import {
  PrismaClient,
  Rol,
  TipoBien,
  UnidadCobro,
  EstadoReserva,
  EstadoNotificacion,
  ModuloOrigen,
} from '@PrismaClient';
import { PrismaService } from '@Prisma/services';
import { ReservaRepository } from '@Reservas/repositories';
import { ReservasService } from '@Reservas/services';
import { VerificacionService } from '@Verificaciones/services';
import { BienRepository } from '@Bienes/repositories';
import { NotificacionesRepository } from '@Notificaciones/repositories';
import { NotificacionesService } from '@Notificaciones/services';
import { SolicitudEncoladaEvent } from '@Reservas/events';
import { NotificarSolicitudReservaListener } from './notificar-solicitud-reserva.listener.js';

const habilitada = process.env.RUN_DB_INTEGRATION === '1';

if (habilitada && !process.env.DATABASE_URL) {
  throw new Error('RUN_DB_INTEGRATION=1 requiere DATABASE_URL configurada.');
}

describe.skipIf(!habilitada)('BE-22.1 - Integración con PostgreSQL', () => {
  let prisma: PrismaClient;
  let modulo: TestingModule | undefined;
  let reservasService: ReservasService;
  let listener: NotificarSolicitudReservaListener;

  let arrendadorId = '';
  let arrendatarioId = '';
  let bienId = '';
  let reservaId = '';

  beforeAll(async () => {
    prisma = new PrismaClient({
      adapter: new PrismaPg({
        connectionString: process.env.DATABASE_URL!,
      }),
    });

    await prisma.$connect();

    const sufijo = randomUUID().replaceAll('-', '').slice(0, 10);

    const arrendador = await prisma.usuario.create({
      data: {
        nombreUsuario: `dueno_${sufijo}`,
        email: `dueno_${sufijo}@example.com`,
        passwordHash: 'hash-prueba',
        rol: Rol.ARRENDADOR,
      },
    });

    arrendadorId = arrendador.id;

    const arrendatario = await prisma.usuario.create({
      data: {
        nombreUsuario: `cliente_${sufijo}`,
        email: `cliente_${sufijo}@example.com`,
        passwordHash: 'hash-prueba',
        rol: Rol.ARRENDATARIO,
      },
    });

    arrendatarioId = arrendatario.id;

    const bien = await prisma.bien.create({
      data: {
        arrendadorId,
        tipo: TipoBien.EQUIPO,
        categoria: 'Fotografía',
        titulo: 'Cámara de prueba BE22',
        descripcion: 'Bien para prueba de integración',
        precio: 25,
        unidadCobro: UnidadCobro.DIA,
        departamento: 'San Salvador',
        municipio: 'San Salvador',
      },
    });

    bienId = bien.id;

    modulo = await Test.createTestingModule({
      imports: [EventEmitterModule.forRoot()],
      providers: [
        {
          provide: PrismaService,
          useValue: prisma as unknown as PrismaService,
        },
        ReservaRepository,
        NotificacionesRepository,
        NotificacionesService,
        NotificarSolicitudReservaListener,
        ReservasService,
        {
          provide: BienRepository,
          useValue: {
            findActivoParaReserva: async () => ({
              id: bienId,
              arrendadorId,
            }),
          },
        },
        {
          provide: VerificacionService,
          useValue: {
            puedeReservar: async () => true,
          },
        },
      ],
    }).compile();

    await modulo.init();

    reservasService = modulo.get(ReservasService);
    listener = modulo.get(NotificarSolicitudReservaListener);
  });

  afterAll(async () => {
    if (modulo) {
      await modulo.close();
    }

    if (prisma) {
      if (reservaId) {
        await prisma.notificacion.deleteMany({
          where: {
            tipoReferencia: 'RESERVA_SOLICITADA',
            referenciaId: reservaId,
          },
        });

        await prisma.reserva.deleteMany({
          where: { id: reservaId },
        });
      }

      if (bienId) {
        await prisma.bien.deleteMany({
          where: { id: bienId },
        });
      }

      const ids = [arrendadorId, arrendatarioId].filter(Boolean);

      if (ids.length) {
        await prisma.usuario.deleteMany({
          where: {
            id: { in: ids },
          },
        });
      }

      await prisma.$disconnect();
    }
  });

  it('crea la reserva y notifica solo al arrendador', async () => {
    const reserva = await reservasService.solicitar(
      arrendatarioId,
      {
        bienId,
        fechaInicio: '2027-01-10',
        fechaFin: '2027-01-12',
      },
      new Date('2026-11-15T12:00:00.000Z'),
    );

    reservaId = reserva.id;

    expect(reserva.estado).toBe(EstadoReserva.EN_COLA);

    // El emisor de eventos no espera a los listeners
    // asíncronos. Esperamos a que se persista el aviso.
    let avisos: Awaited<ReturnType<typeof prisma.notificacion.findMany>> = [];

    for (let intento = 0; intento < 30; intento++) {
      avisos = await prisma.notificacion.findMany({
        where: {
          tipoReferencia: 'RESERVA_SOLICITADA',
          referenciaId: reserva.id,
        },
      });

      if (avisos.length > 0) break;

      await new Promise((resolve) => setTimeout(resolve, 50));
    }

    expect(avisos).toHaveLength(1);

    const aviso = avisos[0]!;

    expect(aviso.destinatarioId).toBe(arrendadorId);
    expect(aviso.estado).toBe(EstadoNotificacion.NO_LEIDA);
    expect(aviso.moduloOrigen).toBe(ModuloOrigen.RESERVAS);
    expect(aviso.titulo).toBe('Nueva solicitud de reserva');
    expect(aviso.mensaje).toContain('Cámara de prueba BE22');
    expect(aviso.mensaje).toContain('10/01/2027');
    expect(aviso.mensaje).toContain('12/01/2027');

    expect(
      await prisma.notificacion.count({
        where: {
          destinatarioId: arrendatarioId,
          tipoReferencia: 'RESERVA_SOLICITADA',
          referenciaId: reserva.id,
        },
      }),
    ).toBe(0);
  });

  it('no duplica la notificación al procesar dos veces', async () => {
    const reserva = await prisma.reserva.findUniqueOrThrow({
      where: { id: reservaId },
    });

    const evento = new SolicitudEncoladaEvent(
      reserva.id,
      reserva.bienId,
      reserva.arrendatarioId,
      reserva.fechaInicio,
      reserva.fechaFin,
      reserva.creadaEn,
    );

    await listener.procesar(evento);
    await listener.procesar(evento);

    const avisos = await prisma.notificacion.findMany({
      where: {
        tipoReferencia: 'RESERVA_SOLICITADA',
        referenciaId: reservaId,
      },
    });

    expect(avisos).toHaveLength(1);
  });
});
