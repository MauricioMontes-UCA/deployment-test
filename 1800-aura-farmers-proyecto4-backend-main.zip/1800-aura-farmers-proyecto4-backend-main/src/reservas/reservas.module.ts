import { Module } from '@nestjs/common';
import { BienesModule } from '@Bienes';
import { DepositosModule } from '@Depositos';
import { TareaReservasRepository } from '@Reservas/repositories';
import { TareaReservasService } from '@Reservas/services';
import { TareaReservasWorker } from '@Reservas/workers';
import { NotificacionesModule } from '@Notificaciones';
import { VerificacionesModule } from '@Verificaciones';
import {
  DevolucionesController,
  ReservasController,
} from '@Reservas/controllers';
import {
  DevolucionesService,
  ProcesadorColaService,
  ReservasService,
} from '@Reservas/services';
import { ColaReservasWorker } from '@Reservas/workers';
import { ReservaRepository } from '@Reservas/repositories';
import { NotificarSolicitudReservaListener } from '@Reservas/listeners';

/**
 * Importa VerificacionesModule para usar `VerificacionService.puedeReservar`
 * (BE-19.2), la política de verificación que se revisa al encolar y al
 * procesar una solicitud.
 */
@Module({
  imports: [
    BienesModule,
    NotificacionesModule,
    DepositosModule,
    VerificacionesModule,
  ],
  controllers: [ReservasController, DevolucionesController],
  providers: [
    TareaReservasRepository,
    TareaReservasService,
    TareaReservasWorker,
    ReservasService,
    DevolucionesService,
    ProcesadorColaService,
    ColaReservasWorker,
    ReservaRepository,
    NotificarSolicitudReservaListener,
  ],
  exports: [ReservasService, DevolucionesService, ReservaRepository],
})
export class ReservasModule {}
