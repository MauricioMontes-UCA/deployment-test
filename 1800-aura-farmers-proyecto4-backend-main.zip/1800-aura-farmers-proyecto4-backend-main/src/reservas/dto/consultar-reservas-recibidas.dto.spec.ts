import { plainToInstance } from 'class-transformer';
import { validate } from 'class-validator';
import {
  ConsultarReservasRecibidasDto,
  ESTADOS_FILTRO_RECIBIDAS,
  RESERVAS_RECIBIDAS_POR_PAGINA,
} from './consultar-reservas-recibidas.dto.js';

/** Igual que el ValidationPipe global: transforma la query y la valida. */
async function validar(query: Record<string, unknown>) {
  const dto = plainToInstance(ConsultarReservasRecibidasDto, query);
  const errores = await validate(dto, {
    whitelist: true,
    forbidNonWhitelisted: true,
  });
  return { dto, campos: errores.map((e) => e.property) };
}

describe('ConsultarReservasRecibidasDto (BE-27.1)', () => {
  it('sin parámetros: página 1 y sin filtro de estado', async () => {
    const { dto, campos } = await validar({});

    expect(campos).toEqual([]);
    expect(dto.pagina).toBe(1);
    expect(dto.estado).toBeUndefined();
  });

  it('las páginas son de 20 reservas', () => {
    expect(RESERVAS_RECIBIDAS_POR_PAGINA).toBe(20);
  });

  it('admite exactamente cinco estados, sin CANCELADA', () => {
    expect([...ESTADOS_FILTRO_RECIBIDAS]).toEqual([
      'EN_COLA',
      'CONFIRMADA',
      'RECHAZADA',
      'EN_CURSO',
      'FINALIZADA',
    ]);
  });

  it.each(['EN_COLA', 'CONFIRMADA', 'RECHAZADA', 'EN_CURSO', 'FINALIZADA'])(
    'acepta el estado %s',
    async (estado) => {
      const { dto, campos } = await validar({ estado });

      expect(campos).toEqual([]);
      expect(dto.estado).toBe(estado);
    },
  );

  it('estado vacío equivale a no filtrar', async () => {
    const { dto, campos } = await validar({ estado: '' });

    expect(campos).toEqual([]);
    expect(dto.estado).toBeUndefined();
  });

  it.each([
    ['CANCELADA', 'CANCELADA'],
    ['un estado en minúsculas', 'en_cola'],
    ['un estado inexistente', 'PENDIENTE'],
    ['varios estados', ['EN_COLA', 'CONFIRMADA']],
  ])('rechaza %s como filtro', async (_caso, estado) => {
    const { campos } = await validar({ estado });

    expect(campos).toEqual(['estado']);
  });

  it.each([
    ['1', 1],
    ['2', 2],
    ['20', 20],
    ['9007199254740991', Number.MAX_SAFE_INTEGER],
  ])('acepta la página %s', async (pagina, esperada) => {
    const { dto, campos } = await validar({ pagina });

    expect(campos).toEqual([]);
    expect(dto.pagina).toBe(esperada);
  });

  it.each([
    '0',
    '-1',
    '1.5',
    'abc',
    '',
    // Otras formas de escribir un número: solo se aceptan dígitos decimales,
    // sin ceros a la izquierda.
    '1e2',
    '0x10',
    ' 2',
    '2 ',
    '1.0',
    '+1',
    '01',
    '0b11',
    // Mayores que Number.MAX_SAFE_INTEGER: se rechazan en vez de perder
    // precisión (9007199254740993 llegaría como 9007199254740992).
    '9007199254740992',
    '9007199254740993',
    '99999999999999999999',
  ])('rechaza la página "%s"', async (pagina) => {
    const { campos } = await validar({ pagina });

    expect(campos).toEqual(['pagina']);
  });

  it('rechaza una página repetida en la query (llega como lista)', async () => {
    const { campos } = await validar({ pagina: ['1', '2'] });

    expect(campos).toEqual(['pagina']);
  });

  it('rechaza un parámetro desconocido, como arrendadorId', async () => {
    const { campos } = await validar({ arrendadorId: 'otro' });

    expect(campos).toEqual(['arrendadorId']);
  });
});
