import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsEnum, IsOptional } from 'class-validator';
import { EstadoReserva } from '@PrismaClient';

export class ConsultarReservasDto {
  @ApiPropertyOptional({ enum: EstadoReserva, description: 'Filtrar reservas por estado.' })
  @IsOptional()
  @IsEnum(EstadoReserva)
  estado?: EstadoReserva;
}
