import { ApiProperty } from '@nestjs/swagger';
import { ReservaResponseDto } from './reserva-response.dto.js';

/**
 * Página de `GET /reservas/recibidas` (BE-27.1).
 *
 * Cada elemento usa el mismo formato que el resto de las consultas de
 * reservas (`ReservaResponseDto`), así que recibe sin cambios los campos que
 * se agreguen a ese formato.
 */
export class ReservasRecibidasResponseDto {
  @ApiProperty({ type: [ReservaResponseDto] })
  items!: ReservaResponseDto[];

  @ApiProperty({ example: 1, description: 'Página solicitada.' })
  pagina!: number;

  @ApiProperty({
    example: 45,
    description: 'Reservas que cumplen el filtro, sin contar la paginación.',
  })
  total!: number;

  @ApiProperty({
    example: true,
    description: 'Si hay más reservas después de esta página.',
  })
  hayMas!: boolean;
}
