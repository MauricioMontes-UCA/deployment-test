import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import {
  IsEnum,
  IsISO8601,
  IsOptional,
  IsString,
  Matches,
  MaxLength,
} from 'class-validator';
import { EstadoFinalBien } from '@PrismaClient';

/**
 * Fecha, o fecha y hora con zona (`Z` o `±hh:mm`). Una hora sin zona se leería
 * en la zona del servidor y daría un instante distinto según dónde corra.
 */
const FECHA_CON_ZONA =
  /^\d{4}-\d{2}-\d{2}(T\d{2}:\d{2}(:\d{2}(\.\d+)?)?(Z|[+-]\d{2}:\d{2}))?$/;

const MENSAJE_FECHA =
  'La fecha de devolución debe ser ISO 8601 (YYYY-MM-DD o YYYY-MM-DDThh:mm:ssZ, con zona si lleva hora).';

/** Un texto vacío o de solo espacios se trata como no enviado. */
function textoOpcional({ value }: { value: unknown }): unknown {
  if (typeof value !== 'string') return value;
  const recortado = value.trim();
  return recortado === '' ? undefined : recortado;
}

/**
 * Cuerpo de `POST /reservas/:reservaId/devolucion`.
 *
 * Aquí solo se valida la forma. Que la fecha no sea futura y las reglas de la
 * reserva (propietario, estado) las valida el servicio. Quien registra sale del
 * token, nunca del cuerpo.
 */
export class RegistrarDevolucionDto {
  @ApiProperty({
    example: '2026-12-12T15:30:00Z',
    description:
      'Cuándo se devolvió el bien. No puede ser futura. Si lleva hora, debe llevar zona.',
  })
  @IsISO8601(
    { strict: true, strictSeparator: true },
    { message: MENSAJE_FECHA },
  )
  @Matches(FECHA_CON_ZONA, { message: MENSAJE_FECHA })
  fechaDevolucion!: string;

  @ApiProperty({
    enum: EstadoFinalBien,
    enumName: 'EstadoFinalBien',
    example: EstadoFinalBien.BUEN_ESTADO,
  })
  @IsEnum(EstadoFinalBien, {
    message: 'El estado final debe ser BUEN_ESTADO, DANADO o INCOMPLETO.',
  })
  estadoFinalBien!: EstadoFinalBien;

  @ApiPropertyOptional({
    example: 'Sin novedades.',
    maxLength: 500,
  })
  @IsOptional()
  @Transform(textoOpcional)
  @IsString({ message: 'Las observaciones deben ser texto.' })
  @MaxLength(500, {
    message: 'Las observaciones no pueden superar los 500 caracteres.',
  })
  observaciones?: string;
}
