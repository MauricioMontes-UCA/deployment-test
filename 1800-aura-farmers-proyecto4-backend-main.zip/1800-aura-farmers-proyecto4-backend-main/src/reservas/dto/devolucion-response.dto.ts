import { ApiProperty } from '@nestjs/swagger';
import { EstadoFinalBien, EstadoReserva, type Devolucion } from '@PrismaClient';

/** Respuesta de `POST /reservas/:reservaId/devolucion`. */
export class DevolucionResponseDto {
  @ApiProperty({ format: 'uuid' })
  devolucionId!: string;

  @ApiProperty({ format: 'uuid' })
  reservaId!: string;

  @ApiProperty({ type: String, format: 'date-time' })
  fechaDevolucion!: string;

  @ApiProperty({ enum: EstadoFinalBien, enumName: 'EstadoFinalBien' })
  estadoFinalBien!: EstadoFinalBien;

  @ApiProperty({
    format: 'uuid',
    description: 'Arrendador que registró la devolución.',
  })
  registradoPor!: string;

  @ApiProperty({
    enum: [EstadoReserva.FINALIZADA],
    description: 'La reserva siempre queda FINALIZADA al registrar.',
  })
  estadoReserva!: typeof EstadoReserva.FINALIZADA;

  static fromEntity(devolucion: Devolucion): DevolucionResponseDto {
    return {
      devolucionId: devolucion.id,
      reservaId: devolucion.reservaId,
      fechaDevolucion: devolucion.fechaDevolucion.toISOString(),
      estadoFinalBien: devolucion.estadoFinalBien,
      registradoPor: devolucion.registradoPorId,
      estadoReserva: EstadoReserva.FINALIZADA,
    };
  }
}
