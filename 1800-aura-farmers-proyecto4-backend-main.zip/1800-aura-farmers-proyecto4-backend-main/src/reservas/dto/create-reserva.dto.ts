import { ApiProperty } from '@nestjs/swagger';
import { IsUUID, Matches } from 'class-validator';

const FORMATO_DIA = /^\d{4}-\d{2}-\d{2}$/;
const MENSAJE_FORMATO = 'Debe tener el formato YYYY-MM-DD.';

/**
 * Cuerpo de `POST /reservas`.
 *
 * Aquí solo se valida la forma. Que sea un día real y las reglas de negocio
 * (no pasado, fin >= inicio, máximo 30 días) las valida el servicio.
 */
export class CreateReservaDto {
  @ApiProperty({
    format: 'uuid',
    example: '7c9e6679-7425-40de-944b-e07fc1f90ae7',
  })
  @IsUUID()
  bienId!: string;

  @ApiProperty({ example: '2026-12-10', description: 'Primer día, inclusive.' })
  @Matches(FORMATO_DIA, { message: MENSAJE_FORMATO })
  fechaInicio!: string;

  @ApiProperty({ example: '2026-12-12', description: 'Último día, inclusive.' })
  @Matches(FORMATO_DIA, { message: MENSAJE_FORMATO })
  fechaFin!: string;
}
