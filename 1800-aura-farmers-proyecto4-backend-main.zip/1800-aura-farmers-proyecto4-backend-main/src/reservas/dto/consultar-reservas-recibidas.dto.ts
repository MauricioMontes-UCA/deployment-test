import { ApiPropertyOptional } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsIn, IsInt, IsOptional, Max, Min } from 'class-validator';
import { EstadoReserva } from '@PrismaClient';

/**
 * Estados por los que el arrendador puede filtrar sus reservas recibidas
 * (BE-27.1). CANCELADA no es un filtro válido, aunque las reservas canceladas
 * sí aparecen en el listado sin filtro.
 */
export const ESTADOS_FILTRO_RECIBIDAS = [
  EstadoReserva.EN_COLA,
  EstadoReserva.CONFIRMADA,
  EstadoReserva.RECHAZADA,
  EstadoReserva.EN_CURSO,
  EstadoReserva.FINALIZADA,
] as const;

export type EstadoFiltroRecibidas = (typeof ESTADOS_FILTRO_RECIBIDAS)[number];

/** Reservas por página de `GET /reservas/recibidas`. */
export const RESERVAS_RECIBIDAS_POR_PAGINA = 20;

/** Un entero positivo escrito solo con dígitos decimales, sin ceros a la izquierda. */
const PAGINA_DECIMAL = /^[1-9]\d*$/;

/** Query de `GET /reservas/recibidas`. */
export class ConsultarReservasRecibidasDto {
  @ApiPropertyOptional({
    enum: ESTADOS_FILTRO_RECIBIDAS,
    description:
      'Filtra por estado. Vacío o ausente: sin filtro (incluye las canceladas).',
  })
  // `estado=` (vacío) equivale a no filtrar.
  @Transform(({ value }: { value: unknown }) =>
    value === '' ? undefined : value,
  )
  @IsOptional()
  @IsIn(ESTADOS_FILTRO_RECIBIDAS, {
    message: `El estado debe ser uno de: ${ESTADOS_FILTRO_RECIBIDAS.join(', ')}.`,
  })
  estado?: EstadoFiltroRecibidas;

  @ApiPropertyOptional({
    description: `Número de página, empezando en 1, escrito solo con dígitos decimales y sin ceros a la izquierda. Cada página tiene ${RESERVAS_RECIBIDAS_POR_PAGINA} reservas. El máximo es técnico, no de negocio: el mayor entero que JavaScript representa sin perder precisión.`,
    example: 1,
    minimum: 1,
    maximum: Number.MAX_SAFE_INTEGER,
    default: 1,
  })
  // Sin `pagina` se toma la 1. Cualquier otra forma de escribir un número
  // (`1e2`, `0x10`, ` 2`, `1.0`, `+1`, `01`), o un valor repetido, queda como
  // NaN y la rechaza @IsInt.
  @Transform(({ value }: { value: unknown }) => {
    if (value === undefined) return 1;
    if (typeof value !== 'string' || !PAGINA_DECIMAL.test(value)) {
      return Number.NaN;
    }
    return Number(value);
  })
  @IsOptional()
  @IsInt({
    message:
      'La página debe ser un número entero positivo, escrito solo con dígitos.',
  })
  @Min(1, { message: 'La página debe ser mayor o igual que 1.' })
  // Un número mayor ya no se representa exacto: 9007199254740993 llegaría
  // como 9007199254740992. Se rechaza en lugar de responder otra página.
  @Max(Number.MAX_SAFE_INTEGER, {
    message: `La página debe ser un entero entre 1 y ${Number.MAX_SAFE_INTEGER}.`,
  })
  pagina: number = 1;
}
