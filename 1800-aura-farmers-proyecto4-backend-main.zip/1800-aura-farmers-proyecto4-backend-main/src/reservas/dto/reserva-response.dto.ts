import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { formatDia } from '@Bienes/utils';
import {
  EstadoReserva,
  EstadoPago,
  EstadoDeposito,
  UnidadCobro,
  type Reserva,
} from '@PrismaClient';
import type { ReservaConsulta } from '@Reservas/repositories';

export class ReservaBienResponseDto {
  @ApiProperty({ format: 'uuid' })
  id!: string;

  @ApiProperty()
  titulo!: string;

  @ApiPropertyOptional({
    type: String,
    nullable: true,
  })
  fotoPrincipalUrl!: string | null;

  @ApiProperty({
    type: Number,
    example: 25.00,
  })
  precio!: number;

  @ApiProperty({
    enum: UnidadCobro,
    enumName: 'UnidadCobro',
  })
  unidadCobro!: UnidadCobro;
}

export class ReservaUsuarioResponseDto {
  @ApiProperty({ format: 'uuid' })
  id!: string;

  @ApiProperty()
  nombreUsuario!: string;
}

export class ReservaPagoResponseDto {
  @ApiProperty({ format: 'uuid' })
  id!: string;

  @ApiProperty({
    enum: EstadoPago,
    enumName: 'EstadoPago',
  })
  estado!: EstadoPago;

  @ApiProperty({
    type: Number,
    example: 75.00,
  })
  total!: number;
}

export class ReservaDepositoResponseDto {
  @ApiProperty({
    enum: EstadoDeposito,
    enumName: 'EstadoDeposito',
  })
  estado!: EstadoDeposito;

  @ApiProperty({
    type: Number,
    example: 100.00,
  })
  importeOriginal!: number; 
}

/**
 * Representación pública de una solicitud de reserva.
 *
 * Se utiliza tanto para entidades completas de Prisma
 * como para consultas realizadas mediante ReservaRepository.
 */
export class ReservaResponseDto {
  @ApiProperty({ format: 'uuid' })
  id!: string;

  @ApiProperty({ format: 'uuid' })
  bienId!: string;

  @ApiProperty({ format: 'uuid' })
  arrendatarioId!: string;

  @ApiProperty({
    format: 'date',
    example: '2026-12-10',
  })
  fechaInicio!: string;

  @ApiProperty({
    format: 'date',
    example: '2026-12-12',
  })
  fechaFin!: string;

  @ApiProperty({
    enum: EstadoReserva,
    enumName: 'EstadoReserva',
    example: EstadoReserva.EN_COLA,
  })
  estado!: EstadoReserva;

  @ApiPropertyOptional({
    type: String,
    nullable: true,
    example: 'FECHAS_NO_DISPONIBLES',
  })
  motivoResolucion!: string | null;

  @ApiProperty({
    type: String,
    format: 'date-time',
  })
  creadaEn!: string;

  @ApiPropertyOptional({
    type: String,
    format: 'date-time',
    nullable: true,
  })
  procesadaEn!: string | null;

  @ApiPropertyOptional({
    type: () => ReservaBienResponseDto,
  })
  bien?: ReservaBienResponseDto;

  @ApiPropertyOptional({
    type: () => ReservaUsuarioResponseDto,
  })
  arrendatario?: ReservaUsuarioResponseDto;

  @ApiPropertyOptional({
    type: () => ReservaUsuarioResponseDto,
  })
  arrendador?: ReservaUsuarioResponseDto;

  @ApiPropertyOptional({
    type: () => ReservaPagoResponseDto,
    nullable: true,
  })
  pago?: ReservaPagoResponseDto | null;

  @ApiPropertyOptional({
    type: () => ReservaDepositoResponseDto,
    nullable: true,
  })
  deposito?: ReservaDepositoResponseDto | null;

  @ApiPropertyOptional({
    type: String,
    format: 'date-time',
    nullable: true,
  })
  finalizadaEn?: string | null;

  static from(reserva: ReservaConsulta): ReservaResponseDto {
    const pago =
      reserva.pagos.find(
        (item) => item.estado === EstadoPago.SIMULADO_EXITOSO,
      ) ?? reserva.pagos[0];

    return {
      id: reserva.id,
      bienId: reserva.bienId,
      arrendatarioId: reserva.arrendatarioId,
      fechaInicio: formatDia(reserva.fechaInicio),
      fechaFin: formatDia(reserva.fechaFin),
      estado: reserva.estado,
      motivoResolucion: reserva.motivoResolucion,
      creadaEn: reserva.creadaEn.toISOString(),
      procesadaEn: reserva.procesadaEn?.toISOString() ?? null,

      finalizadaEn:
        reserva.finalizadaEn?.toISOString() ?? null,

      bien: {
        id: reserva.bien.id,
        titulo: reserva.bien.titulo,
        fotoPrincipalUrl:
          reserva.bien.fotos[0]?.url ?? null,
        precio: Number(reserva.bien.precio),
        unidadCobro: reserva.bien.unidadCobro,
      },

      arrendatario: {
        id: reserva.arrendatario.id,
        nombreUsuario: reserva.arrendatario.nombreUsuario,
      },

      arrendador: {
        id: reserva.bien.arrendador.id,
        nombreUsuario: reserva.bien.arrendador.nombreUsuario,
      },

      pago: pago
        ? {
            id: pago.id,
            estado: pago.estado,
            total: Number(pago.total),
          }
        : null,

      deposito: reserva.deposito
        ? {
            estado: reserva.deposito.estado,
            importeOriginal:
              Number(reserva.deposito.importeOriginal),
          }
        : null,
    };
  }

  static fromEntity(reserva: Reserva): ReservaResponseDto {
    return {
      id: reserva.id,
      bienId: reserva.bienId,
      arrendatarioId: reserva.arrendatarioId,
      fechaInicio: formatDia(reserva.fechaInicio),
      fechaFin: formatDia(reserva.fechaFin),
      estado: reserva.estado,
      motivoResolucion: reserva.motivoResolucion,
      creadaEn: reserva.creadaEn.toISOString(),
      procesadaEn: reserva.procesadaEn?.toISOString() ?? null,
    };
  }
}