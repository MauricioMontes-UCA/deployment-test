import { ReservaResponseDto } from './reserva-response.dto.js';
import { EstadoReserva, type Reserva } from '@PrismaClient';

describe('ReservaResponseDto.fromEntity', () => {
  it('devuelve los campos públicos con fechas normalizadas', () => {
    const reserva = {
      id: 'reserva-1',
      bienId: 'bien-1',
      arrendatarioId: 'secreto',
      fechaInicio: new Date('2026-12-10T00:00:00.000Z'),
      fechaFin: new Date('2026-12-12T00:00:00.000Z'),
      estado: EstadoReserva.EN_COLA,
      motivoResolucion: null,
      creadaEn: new Date('2026-11-03T15:20:00.000Z'),
      procesadaEn: null,
      finalizadaEn: null,
      cierreAutomatico: false,
    } as Reserva;

    expect(ReservaResponseDto.fromEntity(reserva)).toEqual({
      id: 'reserva-1',
      bienId: 'bien-1',
      arrendatarioId: 'secreto',
      fechaInicio: '2026-12-10',
      fechaFin: '2026-12-12',
      estado: EstadoReserva.EN_COLA,
      motivoResolucion: null,
      creadaEn: '2026-11-03T15:20:00.000Z',
      procesadaEn: null,
    });
  });
});
