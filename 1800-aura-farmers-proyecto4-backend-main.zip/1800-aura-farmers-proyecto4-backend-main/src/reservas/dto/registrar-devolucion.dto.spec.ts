import { plainToInstance } from 'class-transformer';
import { validate } from 'class-validator';
import { RegistrarDevolucionDto } from './registrar-devolucion.dto.js';

const base = {
  fechaDevolucion: '2026-12-12T15:30:00Z',
  estadoFinalBien: 'BUEN_ESTADO',
};

async function errores(parcial: Record<string, unknown>) {
  const dto = plainToInstance(RegistrarDevolucionDto, { ...base, ...parcial });
  const result = await validate(dto);
  return { dto, campos: result.map((e) => e.property) };
}

describe('RegistrarDevolucionDto', () => {
  it('acepta solo los campos obligatorios', async () => {
    const { dto, campos } = await errores({});

    expect(campos).toEqual([]);
    expect(dto.observaciones).toBeUndefined();
  });

  it.each([
    '2026-12-12',
    '2026-12-12T15:30:00Z',
    '2026-12-12T15:30Z',
    '2026-12-12T15:30:00.123Z',
    '2026-12-12T09:30:00-06:00',
  ])('acepta la fecha %s', async (fechaDevolucion) => {
    expect((await errores({ fechaDevolucion })).campos).toEqual([]);
  });

  it.each([
    ['sin zona', '2026-12-12T15:30:00'],
    ['día inexistente', '2026-02-30'],
    ['formato local', '12/12/2026'],
    ['con espacio en vez de T', '2026-12-12 15:30:00Z'],
    ['vacía', ''],
    ['texto', 'ayer'],
    ['número', 1765555800000],
  ])('rechaza la fecha %s', async (_caso, fechaDevolucion) => {
    expect((await errores({ fechaDevolucion })).campos).toEqual([
      'fechaDevolucion',
    ]);
  });

  it('exige la fecha y el estado final', async () => {
    const dto = plainToInstance(RegistrarDevolucionDto, {});

    const campos = (await validate(dto)).map((e) => e.property).sort();

    expect(campos).toEqual(['estadoFinalBien', 'fechaDevolucion']);
  });

  it.each(['BUEN_ESTADO', 'DANADO', 'INCOMPLETO'])(
    'acepta el estado final %s',
    async (estadoFinalBien) => {
      expect((await errores({ estadoFinalBien })).campos).toEqual([]);
    },
  );

  it.each(['ROTO', 'buen_estado', '', 1])(
    'rechaza el estado final %j',
    async (estadoFinalBien) => {
      expect((await errores({ estadoFinalBien })).campos).toEqual([
        'estadoFinalBien',
      ]);
    },
  );

  it('acepta observaciones de exactamente 500 caracteres', async () => {
    expect((await errores({ observaciones: 'a'.repeat(500) })).campos).toEqual(
      [],
    );
  });

  it('rechaza observaciones de más de 500 caracteres', async () => {
    expect((await errores({ observaciones: 'a'.repeat(501) })).campos).toEqual([
      'observaciones',
    ]);
  });

  it('recorta las observaciones y trata las vacías como no enviadas', async () => {
    expect(
      (await errores({ observaciones: '  Rayón  ' })).dto.observaciones,
    ).toBe('Rayón');
    expect((await errores({ observaciones: '   ' })).dto.observaciones).toBe(
      undefined,
    );
  });
});
