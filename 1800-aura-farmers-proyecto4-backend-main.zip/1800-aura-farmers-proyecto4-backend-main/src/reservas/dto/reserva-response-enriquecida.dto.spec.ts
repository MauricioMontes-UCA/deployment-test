import {
  Prisma,
  EstadoPago,
  EstadoReserva,
  EstadoDeposito,
  UnidadCobro,
} from '@PrismaClient';

import type { ReservaConsulta } from '@Reservas/repositories';

import { ReservaResponseDto } from './reserva-response.dto.js';

const base = {
  id: 'reserva-1',
  bienId: 'bien-1',
  arrendatarioId: 'usuario-1',

  fechaInicio: new Date('2026-12-10T00:00:00Z'),
  fechaFin: new Date('2026-12-12T00:00:00Z'),

  estado: EstadoReserva.FINALIZADA,
  motivoResolucion: null,

  creadaEn: new Date('2026-11-01T12:00:00Z'),
  procesadaEn: null,
  finalizadaEn: new Date('2026-12-15T12:00:00Z'),

  bien: {
    id: 'bien-1',
    titulo: 'Cámara',
    precio: new Prisma.Decimal('25.00'),
    unidadCobro: UnidadCobro.DIA,

    arrendador: {
      id: 'usuario-2',
      nombreUsuario: 'arrendador',
    },

    fotos: [{ url: 'foto.jpg' }],
  },

  arrendatario: {
    id: 'usuario-1',
    nombreUsuario: 'arrendatario',
  },

  pagos: [
    {
      id: 'fallido',
      estado: EstadoPago.SIMULADO_RECHAZADO,
      total: new Prisma.Decimal('75.00'),
    },
    {
      id: 'exitoso',
      estado: EstadoPago.SIMULADO_EXITOSO,
      total: new Prisma.Decimal('75.00'),
    },
  ],

  deposito: {
    estado: EstadoDeposito.LIBERADO,
    importeOriginal: new Prisma.Decimal('100.00'),
  },
} as ReservaConsulta;

describe('BE-6.5 ReservaResponseDto', () => {
  it('incluye bien, participantes, depósito, finalización y prioriza pago exitoso', () => {
    const dto = ReservaResponseDto.from(base);

    expect(dto.bien).toEqual({
      id: 'bien-1',
      titulo: 'Cámara',
      fotoPrincipalUrl: 'foto.jpg',
      precio: 25,
      unidadCobro: UnidadCobro.DIA,
    });

    expect(dto.arrendador?.nombreUsuario).toBe('arrendador');
    expect(dto.arrendatario?.nombreUsuario).toBe('arrendatario');

    expect(dto.pago?.id).toBe('exitoso');
    expect(dto.pago?.estado).toBe(EstadoPago.SIMULADO_EXITOSO);
    expect(dto.pago?.total).toBe(75);

    expect(dto.deposito?.estado).toBe(EstadoDeposito.LIBERADO);
    expect(dto.deposito?.importeOriginal).toBe(100);

    expect(dto.finalizadaEn).toBe('2026-12-15T12:00:00.000Z');
  });

  it('selecciona el último intento cuando no existe pago exitoso', () => {
    const dto = ReservaResponseDto.from({
      ...base,
      pagos: [base.pagos[0]],
    } as ReservaConsulta);

    expect(dto.pago?.id).toBe('fallido');
    expect(dto.pago?.estado).toBe(EstadoPago.SIMULADO_RECHAZADO);
    expect(dto.pago?.total).toBe(75);
  });

  it('admite reserva sin fotos, pagos ni depósito', () => {
    const dto = ReservaResponseDto.from({
      ...base,
      pagos: [],
      deposito: null,
      finalizadaEn: null,

      bien: {
        ...base.bien,
        fotos: [],
      },
    } as ReservaConsulta);

    expect(dto.bien?.fotoPrincipalUrl).toBeNull();
    expect(dto.bien?.precio).toBe(25);

    expect(dto.pago).toBeNull();
    expect(dto.deposito).toBeNull();
    expect(dto.finalizadaEn).toBeNull();
  });
});
