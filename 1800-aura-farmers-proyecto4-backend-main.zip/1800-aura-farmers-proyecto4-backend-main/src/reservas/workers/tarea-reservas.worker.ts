import { Injectable, Logger, OnApplicationBootstrap } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Cron } from '@nestjs/schedule';
import { Client } from 'pg';
import type { EnvConfig } from '@Config';
import { TareaReservasService } from '@Reservas/services';

/** Candado de sesión en conexión dedicada; permanece activo mientras corren las transacciones Prisma. */
@Injectable()
export class TareaReservasWorker implements OnApplicationBootstrap {
  private readonly logger = new Logger(TareaReservasWorker.name);
  private static readonly LOCK_ID = '1022202';

  constructor(
    private readonly tarea: TareaReservasService,
    private readonly config: ConfigService<EnvConfig, true>,
  ) {}

  @Cron('5 0 * * *', {
    timeZone: 'America/El_Salvador',
    waitForCompletion: true,
  })
  async ejecutar(): Promise<void> {
    if (!this.config.get('TAREA_RESERVAS_ACTIVA', { infer: true })) return;
    const cliente = new Client({
      connectionString: this.config.get('DATABASE_URL', { infer: true }),
      connectionTimeoutMillis: 5000,
    });
    let conectado = false;
    let bloqueado = false;
    try {
      await cliente.connect();
      conectado = true;
      const resultado = await cliente.query<{ adquirido: boolean }>(
        'SELECT pg_try_advisory_lock($1::bigint) AS adquirido',
        [TareaReservasWorker.LOCK_ID],
      );
      bloqueado = resultado.rows[0]?.adquirido === true;
      if (!bloqueado) {
        this.logger.log(
          'BE-10.2: otra instancia está procesando; se omite esta ejecución.',
        );
        return;
      }
      await this.tarea.ejecutar();
    } catch (error) {
      this.logger.error(`BE-10.2: fallo de ejecución: ${String(error)}`);
    } finally {
      if (conectado) {
        if (bloqueado) {
          try {
            await cliente.query('SELECT pg_advisory_unlock($1::bigint)', [
              TareaReservasWorker.LOCK_ID,
            ]);
          } catch (error) {
            this.logger.error(
              `BE-10.2: fallo al liberar candado: ${String(error)}`,
            );
          }
        }
        await cliente.end();
      }
    }
  }

  async onApplicationBootstrap(): Promise<void> {
    if (!this.config.get('TAREA_RESERVAS_ACTIVA', { infer: true })) {
      return;
    }
    
    this.logger.log(
      'BE-10.2: ejecutando recuperación de reservas al iniciar la aplicación.',
    );
    
    await this.ejecutar();
  }
}
