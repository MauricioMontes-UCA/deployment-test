import { ColaReservasWorker } from './cola-reservas.worker.js';
import type { ConfigService } from '@nestjs/config';
import type { ProcesadorColaService } from '@Reservas/services';

function crear(activa: boolean, intervalo = 30_000) {
  const procesarPendientes = vi.fn().mockResolvedValue(0);
  const config = {
    get: vi.fn((clave: string) =>
      clave === 'COLA_RESERVAS_ACTIVA' ? activa : intervalo,
    ),
  };
  const worker = new ColaReservasWorker(
    { procesarPendientes } as unknown as ProcesadorColaService,
    config as unknown as ConfigService<never, true>,
  );
  return { worker, procesarPendientes };
}

describe('ColaReservasWorker', () => {
  beforeEach(() => {
    vi.useFakeTimers();
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it('al arrancar revisa la cola de inmediato, para recuperar lo pendiente tras un reinicio', () => {
    const { worker, procesarPendientes } = crear(true);

    worker.onModuleInit();

    expect(procesarPendientes).toHaveBeenCalledTimes(1);
    worker.onModuleDestroy();
  });

  it('revisa la cola cada intervalo', () => {
    const { worker, procesarPendientes } = crear(true, 1000);

    worker.onModuleInit();
    vi.advanceTimersByTime(3000);

    // 1 al arrancar + 3 del temporizador.
    expect(procesarPendientes).toHaveBeenCalledTimes(4);
    worker.onModuleDestroy();
  });

  it('al encolar una solicitud revisa la cola', () => {
    const { worker, procesarPendientes } = crear(true);

    worker.alEncolar();

    expect(procesarPendientes).toHaveBeenCalledTimes(1);
  });

  it('al cerrar la aplicación deja de revisar', () => {
    const { worker, procesarPendientes } = crear(true, 1000);

    worker.onModuleInit();
    worker.onModuleDestroy();
    procesarPendientes.mockClear();
    vi.advanceTimersByTime(5000);

    expect(procesarPendientes).not.toHaveBeenCalled();
  });

  it('desactivado no arranca el temporizador ni reacciona a los eventos', () => {
    const { worker, procesarPendientes } = crear(false, 1000);

    worker.onModuleInit();
    worker.alEncolar();
    vi.advanceTimersByTime(5000);

    expect(procesarPendientes).not.toHaveBeenCalled();
  });
});
