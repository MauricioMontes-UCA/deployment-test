export * from './cola-reservas.worker.js';
export * from './tarea-reservas.worker.js';
