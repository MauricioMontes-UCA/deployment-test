import {
  Injectable,
  Logger,
  type OnModuleDestroy,
  type OnModuleInit,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { OnEvent } from '@nestjs/event-emitter';
import { SOLICITUD_ENCOLADA } from '@Reservas/events';
import { ProcesadorColaService } from '@Reservas/services';
import type { EnvConfig } from '@Config';

/**
 * Pone en marcha el procesador de la cola de reservas.
 *
 * Lo despierta de tres formas: al arrancar (recupera lo que quedó EN_COLA si el
 * proceso se reinició), cuando se encola una solicitud y cada
 * `COLA_RESERVAS_INTERVALO_MS` (cubre fallos y solicitudes de otras instancias).
 * La cola en la base es la fuente de verdad: el evento solo avisa, no lleva los datos.
 */
@Injectable()
export class ColaReservasWorker implements OnModuleInit, OnModuleDestroy {
  private readonly logger = new Logger(ColaReservasWorker.name);
  private temporizador: NodeJS.Timeout | null = null;

  constructor(
    private readonly procesador: ProcesadorColaService,
    private readonly config: ConfigService<EnvConfig, true>,
  ) {}

  onModuleInit(): void {
    if (!this.activo()) {
      this.logger.log('Procesador de la cola de reservas desactivado.');
      return;
    }

    const intervalo = this.config.get('COLA_RESERVAS_INTERVALO_MS', {
      infer: true,
    });
    this.temporizador = setInterval(() => this.despertar(), intervalo);
    // No mantiene vivo el proceso si todo lo demás ya terminó.
    this.temporizador.unref();
    this.despertar();
  }

  onModuleDestroy(): void {
    if (this.temporizador) clearInterval(this.temporizador);
    this.temporizador = null;
  }

  @OnEvent(SOLICITUD_ENCOLADA)
  alEncolar(): void {
    if (this.activo()) this.despertar();
  }

  private activo(): boolean {
    return this.config.get('COLA_RESERVAS_ACTIVA', { infer: true });
  }

  /** No espera el resultado: quien despierta (evento, arranque) no debe bloquearse. */
  private despertar(): void {
    void this.procesador.procesarPendientes();
  }
}
