import { beforeEach, describe, expect, it, vi } from 'vitest';

const pgMock = vi.hoisted(() => {
  const connect = vi.fn();
  const query = vi.fn();
  const end = vi.fn();
  return { connect, query, end };
});

vi.mock('pg', () => ({
  Client: class {
    connect = pgMock.connect;
    query = pgMock.query;
    end = pgMock.end;
  },
}));

import { TareaReservasWorker } from '@Reservas/workers';

describe('BE-10.2 — worker y candado PostgreSQL', () => {
  const tarea = { ejecutar: vi.fn() };
  let activa = true;
  const config = {
    get: vi.fn((key: string) => {
      if (key === 'TAREA_RESERVAS_ACTIVA') return activa;
      if (key === 'DATABASE_URL')
        return 'postgresql://test:test@localhost:5432/test';
      throw new Error(`Variable inesperada: ${key}`);
    }),
  };

  beforeEach(() => {
    vi.clearAllMocks();
    activa = true;
    pgMock.connect.mockResolvedValue(undefined);
    pgMock.end.mockResolvedValue(undefined);
    tarea.ejecutar.mockResolvedValue(undefined);
  });

  it('no abre conexión ni ejecuta la tarea si está desactivada', async () => {
    activa = false;
    await new TareaReservasWorker(tarea as never, config as never).ejecutar();
    expect(pgMock.connect).not.toHaveBeenCalled();
    expect(tarea.ejecutar).not.toHaveBeenCalled();
  });

  it('omite la ejecución si otra instancia tiene el candado', async () => {
    pgMock.query.mockResolvedValueOnce({ rows: [{ adquirido: false }] });
    await new TareaReservasWorker(tarea as never, config as never).ejecutar();
    expect(tarea.ejecutar).not.toHaveBeenCalled();
    expect(pgMock.end).toHaveBeenCalledTimes(1);
    expect(pgMock.query).toHaveBeenCalledTimes(1);
  });

  it('ejecuta y libera el candado si lo adquiere', async () => {
    pgMock.query
      .mockResolvedValueOnce({ rows: [{ adquirido: true }] })
      .mockResolvedValueOnce({ rows: [{ pg_advisory_unlock: true }] });
    await new TareaReservasWorker(tarea as never, config as never).ejecutar();
    expect(tarea.ejecutar).toHaveBeenCalledTimes(1);
    expect(pgMock.query).toHaveBeenCalledTimes(2);
    expect(String(pgMock.query.mock.calls[1]?.[0])).toContain(
      'pg_advisory_unlock',
    );
    expect(pgMock.end).toHaveBeenCalledTimes(1);
  });

  it('libera el candado aunque falle el servicio', async () => {
    pgMock.query
      .mockResolvedValueOnce({ rows: [{ adquirido: true }] })
      .mockResolvedValueOnce({ rows: [{ pg_advisory_unlock: true }] });
    tarea.ejecutar.mockRejectedValueOnce(new Error('fallo simulado'));
    await new TareaReservasWorker(tarea as never, config as never).ejecutar();
    expect(pgMock.query).toHaveBeenCalledTimes(2);
    expect(pgMock.end).toHaveBeenCalledTimes(1);
  });
});
