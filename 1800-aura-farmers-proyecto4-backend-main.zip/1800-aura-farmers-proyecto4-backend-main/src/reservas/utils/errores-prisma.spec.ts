import { esViolacionDeSolape } from './errores-prisma.js';

describe('esViolacionDeSolape', () => {
  it.each([
    ['el SQLSTATE en code', { code: '23P01' }],
    ['el SQLSTATE en originalCode', { originalCode: '23P01' }],
    [
      'el nombre de la restricción en el mensaje',
      new Error('conflicting key value violates "reserva_sin_solape"'),
    ],
    [
      'el SQLSTATE en meta',
      {
        code: 'P2010',
        meta: { driverAdapterError: { cause: { originalCode: '23P01' } } },
      },
    ],
    ['el error original en cause', { message: 'x', cause: { code: '23P01' } }],
  ])('lo reconoce por %s', (_caso, error) => {
    expect(esViolacionDeSolape(error)).toBe(true);
  });

  it.each([
    ['otro SQLSTATE', { code: '23505' }],
    ['un error cualquiera', new Error('connection reset')],
    ['un valor que no es objeto', 'reserva_sin_solape'],
    ['null', null],
  ])('no lo confunde con %s', (_caso, error) => {
    expect(esViolacionDeSolape(error)).toBe(false);
  });

  it('no se cuelga con referencias circulares', () => {
    const error: Record<string, unknown> = { message: 'x' };
    error.cause = error;
    expect(esViolacionDeSolape(error)).toBe(false);
  });
});
