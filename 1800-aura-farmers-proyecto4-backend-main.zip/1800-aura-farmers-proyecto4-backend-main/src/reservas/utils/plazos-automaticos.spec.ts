import { describe, expect, it } from 'vitest';
import { diaFecha, fechaLocal, plazoVencido } from '@Reservas/utils';

describe('BE-10.2 — calendario salvadoreño', () => {
  it('usa el día local aunque UTC ya haya cambiado', () => {
    expect(fechaLocal(new Date('2026-11-16T04:00:00Z'))).toBe('2026-11-15');
  });
  it('vence exactamente al cumplirse el plazo de tres días', () => {
    expect(plazoVencido('2026-11-13', 3, '2026-11-16')).toBe(true);
    expect(plazoVencido('2026-11-14', 3, '2026-11-16')).toBe(false);
    expect(plazoVencido('2026-11-12', 3, '2026-11-16')).toBe(true);
  });
  it('lee DATE de PostgreSQL como fecha ISO', () => {
    expect(diaFecha(new Date('2026-11-16T00:00:00Z'))).toBe('2026-11-16');
  });
});
