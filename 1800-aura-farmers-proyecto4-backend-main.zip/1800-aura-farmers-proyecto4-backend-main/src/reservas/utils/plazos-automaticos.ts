/** Fecha de calendario en El Salvador, independiente de la zona del servidor. */
export function fechaLocal(ahora: Date): string {
  const partes = new Intl.DateTimeFormat('en-US', {
    timeZone: 'America/El_Salvador',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(ahora);
  const dato = (tipo: string) =>
    partes.find((parte) => parte.type === tipo)!.value;
  return `${dato('year')}-${dato('month')}-${dato('day')}`;
}

export function sumarDias(fecha: string, dias: number): string {
  const dia = new Date(`${fecha}T00:00:00.000Z`);
  dia.setUTCDate(dia.getUTCDate() + dias);
  return dia.toISOString().slice(0, 10);
}

export function diaFecha(fecha: Date): string {
  return fecha.toISOString().slice(0, 10);
}

export function plazoVencido(
  fecha: string,
  dias: number,
  hoy: string,
): boolean {
  return sumarDias(fecha, dias) <= hoy;
}
