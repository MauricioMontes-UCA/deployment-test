/** SQLSTATE de exclusion_violation, el que lanza PostgreSQL al chocar `reserva_sin_solape`. */
export const SQLSTATE_EXCLUSION_VIOLATION = '23P01';

const RESTRICCION_SIN_SOLAPE = 'reserva_sin_solape';

/**
 * Indica si el error viene de la restricción `reserva_sin_solape`.
 *
 * Prisma 7 con el adaptador de pg puede envolver el error de PostgreSQL de más
 * de una forma (código propio, `meta`, `cause`), así que se busca el SQLSTATE o
 * el nombre de la restricción a lo largo de toda la cadena en vez de depender
 * de una forma concreta.
 */
export function esViolacionDeSolape(
  error: unknown,
  vistos = new Set<object>(),
): boolean {
  if (typeof error !== 'object' || error === null || vistos.has(error)) {
    return false;
  }
  vistos.add(error);

  const campos = error as Record<string, unknown>;
  if (
    campos.code === SQLSTATE_EXCLUSION_VIOLATION ||
    campos.originalCode === SQLSTATE_EXCLUSION_VIOLATION
  ) {
    return true;
  }
  if (
    typeof campos.message === 'string' &&
    campos.message.includes(RESTRICCION_SIN_SOLAPE)
  ) {
    return true;
  }

  return ['meta', 'cause', 'driverAdapterError'].some((clave) =>
    esViolacionDeSolape(campos[clave], vistos),
  );
}
