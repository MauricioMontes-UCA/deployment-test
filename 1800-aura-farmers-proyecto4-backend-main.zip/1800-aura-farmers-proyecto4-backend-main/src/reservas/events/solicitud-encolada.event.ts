/** Nombre del evento que se emite cuando una solicitud de reserva queda EN_COLA. */
export const SOLICITUD_ENCOLADA = 'solicitud.encolada';

/**
 * Datos de la solicitud recién encolada.
 *
 * Quien la escuche (el procesador de la cola, notificaciones) recibe ids y
 * fechas, no la entidad de Prisma, para no acoplarse al ORM.
 */
export class SolicitudEncoladaEvent {
  constructor(
    readonly reservaId: string,
    readonly bienId: string,
    readonly arrendatarioId: string,
    readonly fechaInicio: Date,
    readonly fechaFin: Date,
    readonly creadaEn: Date,
  ) {}
}
