import { Body, Controller, Param, ParseUUIDPipe, Post } from '@nestjs/common';
import {
  ApiBadRequestResponse,
  ApiBearerAuth,
  ApiConflictResponse,
  ApiCreatedResponse,
  ApiForbiddenResponse,
  ApiNotFoundResponse,
  ApiOperation,
  ApiTags,
  ApiUnauthorizedResponse,
  ApiUnprocessableEntityResponse,
} from '@nestjs/swagger';
import { CurrentUser, Roles } from '@Auth/decorators';
import type { AuthenticatedUser } from '@Auth/types';
import { Rol } from '@PrismaClient';
import { DevolucionResponseDto, RegistrarDevolucionDto } from '@Reservas/dto';
import { DevolucionesService } from '@Reservas/services';

/**
 * Devolución del bien. Comparte la ruta `/reservas` con `ReservasController`,
 * pero es del arrendador: aquel controlador es del arrendatario.
 */
@ApiTags('reservas')
@ApiBearerAuth()
@Roles(Rol.ARRENDADOR)
@Controller('reservas')
export class DevolucionesController {
  constructor(private readonly devolucionesService: DevolucionesService) {}

  @Post(':reservaId/devolucion')
  @ApiOperation({
    summary: 'Registra la devolución del bien y finaliza la reserva',
  })
  @ApiCreatedResponse({ type: DevolucionResponseDto })
  @ApiBadRequestResponse({
    description:
      'El id no es un UUID, falta un campo, la fecha o el estado final no son válidos, o las observaciones superan los 500 caracteres.',
  })
  @ApiUnauthorizedResponse({
    description: 'Token ausente, inválido o expirado.',
  })
  @ApiForbiddenResponse({
    description: 'El usuario no es ARRENDADOR o el bien no es suyo.',
  })
  @ApiNotFoundResponse({ description: 'La reserva no existe.' })
  @ApiConflictResponse({
    description:
      'La reserva no está EN_CURSO, ya tiene devolución o fue cerrada automáticamente.',
  })
  @ApiUnprocessableEntityResponse({
    description: 'La fecha de devolución es futura.',
  })
  async registrar(
    @Param('reservaId', ParseUUIDPipe) reservaId: string,
    @CurrentUser() usuario: AuthenticatedUser,
    @Body() dto: RegistrarDevolucionDto,
  ): Promise<DevolucionResponseDto> {
    const devolucion = await this.devolucionesService.registrar(
      reservaId,
      usuario.id,
      dto,
    );
    return DevolucionResponseDto.fromEntity(devolucion);
  }
}
