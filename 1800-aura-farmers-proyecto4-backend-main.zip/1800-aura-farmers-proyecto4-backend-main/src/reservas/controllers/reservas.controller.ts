
import {
  Body,
  Controller,
  Get,
  HttpCode,
  HttpStatus,
  Param,
  ParseUUIDPipe,
  Post,
  Query,
} from '@nestjs/common';
import {
  ApiAcceptedResponse,
  ApiBadRequestResponse,
  ApiBearerAuth,
  ApiConflictResponse,
  ApiForbiddenResponse,
  ApiNotFoundResponse,
  ApiOkResponse,
  ApiOperation,
  ApiTags,
  ApiUnauthorizedResponse,
  ApiUnprocessableEntityResponse,
} from '@nestjs/swagger';
import { CurrentUser, Roles } from '@Auth/decorators';
import type { AuthenticatedUser } from '@Auth/types';
import { Rol } from '@PrismaClient';
import {
  ConsultarReservasDto,
  ConsultarReservasRecibidasDto,
  CreateReservaDto,
  ReservaResponseDto,
  ReservasRecibidasResponseDto,
} from '@Reservas/dto';
import { ReservasService } from '@Reservas/services';

@ApiTags('reservas')
@ApiBearerAuth()
@Roles(Rol.ARRENDATARIO)
@Controller('reservas')
export class ReservasController {
  constructor(private readonly reservasService: ReservasService) {}

  /**
   * Solicita una reserva y responde 202.
   * La solicitud queda EN_COLA hasta su procesamiento.
   */
  @Post()
  @HttpCode(HttpStatus.ACCEPTED)
  @ApiOperation({
    summary: 'Solicita la reserva de un bien (queda EN_COLA)',
  })
  @ApiAcceptedResponse({ type: ReservaResponseDto })
  @ApiBadRequestResponse({
    description: 'Formato de fecha inválido.',
  })
  @ApiUnauthorizedResponse({
    description: 'Token ausente, inválido o expirado.',
  })
  @ApiForbiddenResponse({
    description:
      'Rol no permitido o verificación requerida.',
  })
  @ApiNotFoundResponse({
    description: 'El bien no existe.',
  })
  @ApiConflictResponse({
    description:
      'Las fechas chocan con una reserva, bloqueo o solicitud propia en cola.',
  })
  @ApiUnprocessableEntityResponse({
    description:
      'Fechas fuera de rango, duración inválida o bien propio.',
  })
  async solicitar(
    @CurrentUser() usuario: AuthenticatedUser,
    @Body() dto: CreateReservaDto,
  ): Promise<ReservaResponseDto> {
    const reserva = await this.reservasService.solicitar(
      usuario.id,
      dto,
    );

    return ReservaResponseDto.fromEntity(reserva);
  }

  /**
   * Reservas recibidas en los bienes del arrendador autenticado (BE-27.1).
   * Va antes de `GET :id` para que `recibidas` no se tome como un id, y su
   * `@Roles` reemplaza al de la clase solo en este método.
   */
  @Get('recibidas')
  @Roles(Rol.ARRENDADOR)
  @ApiOperation({
    summary: 'Lista las reservas recibidas en los bienes del arrendador',
    description:
      'Solo reservas de bienes del arrendador autenticado, de a 20 por página, ordenadas por fecha de inicio ascendente y, ante empate, de la más reciente a la más antigua. Sin filtro de estado incluye todas, también las canceladas.',
  })
  @ApiOkResponse({ type: ReservasRecibidasResponseDto })
  @ApiBadRequestResponse({
    description:
      'Estado no permitido, página inválida o parámetro desconocido.',
  })
  @ApiUnauthorizedResponse({
    description: 'Sesión ausente o inválida.',
  })
  @ApiForbiddenResponse({
    description: 'El usuario no es arrendador.',
  })
  async listarRecibidas(
    @CurrentUser() usuario: AuthenticatedUser,
    @Query() query: ConsultarReservasRecibidasDto,
  ): Promise<ReservasRecibidasResponseDto> {
    const { reservas, pagina, total, hayMas } =
      await this.reservasService.listarRecibidas(usuario.id, query);

    return {
      items: reservas.map((reserva) => ReservaResponseDto.from(reserva)),
      pagina,
      total,
      hayMas,
    };
  }

  @Get('mias')
  @ApiOperation({
    summary: 'Lista las reservas del arrendatario autenticado',
  })
  @ApiOkResponse({
    type: ReservaResponseDto,
    isArray: true,
  })
  @ApiBadRequestResponse({
    description: 'Estado de reserva inválido.',
  })
  @ApiUnauthorizedResponse({
    description: 'Sesión ausente o inválida.',
  })
  @ApiForbiddenResponse({
    description: 'El usuario no es arrendatario.',
  })
  async listarMias(
    @CurrentUser() usuario: AuthenticatedUser,
    @Query() query: ConsultarReservasDto,
  ): Promise<ReservaResponseDto[]> {
    const reservas = await this.reservasService.listarMias(
      usuario.id,
      query.estado,
    );

    return reservas.map((reserva) =>
      ReservaResponseDto.from(reserva),
    );
  }

  @Get(':id')
  @Roles(Rol.ARRENDATARIO, Rol.ARRENDADOR)
  @ApiOperation({
    summary:
      'Consulta una reserva propia (arrendatario o arrendador dueño del bien)',
    description:
      'Solo para sus dos participantes: el arrendatario que la solicitó y el arrendador dueño del bien reservado. Una reserva ajena responde 404, igual que una inexistente.',
  })
  @ApiOkResponse({ type: ReservaResponseDto })
  @ApiBadRequestResponse({
    description: 'El identificador no es UUID.',
  })
  @ApiUnauthorizedResponse({
    description: 'Sesión ausente o inválida.',
  })
  @ApiNotFoundResponse({
    description: 'La reserva no existe o no participas en ella.',
  })
  async consultarPorId(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser() usuario: AuthenticatedUser,
  ): Promise<ReservaResponseDto> {
    const reserva = await this.reservasService.consultarPorId(
      id,
      usuario.id,
    );

    return ReservaResponseDto.from(reserva);
  }
}
