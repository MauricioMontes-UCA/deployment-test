import { ESTADOS_QUE_OCUPAN } from '@Bienes/repositories';
import { RESERVA_SELECT, ReservaRepository } from './reserva.repository.js';
import type { PrismaService } from '@Prisma/services';
import { EstadoReserva } from '../../generated/prisma/browser.js';

const datos = {
  bienId: 'bien-1',
  arrendatarioId: 'usuario-1',
  fechaInicio: new Date('2026-12-10T00:00:00.000Z'),
  fechaFin: new Date('2026-12-12T00:00:00.000Z'),
};

function crear(conteos: {
  reservas?: number;
  bloqueos?: number;
  propias?: number;
}) {
  const { reservas = 0, bloqueos = 0, propias = 0 } = conteos;
  const reservaGuardada = { id: 'reserva-1', ...datos, estado: 'EN_COLA' };
  const tx = {
    $executeRaw: vi.fn().mockResolvedValue(1),
    // La primera llamada cuenta reservas ocupadas y la segunda las propias.
    reserva: {
      count: vi
        .fn()
        .mockResolvedValueOnce(reservas)
        .mockResolvedValueOnce(propias),
      create: vi.fn().mockResolvedValue(reservaGuardada),
    },
    bloqueoFecha: { count: vi.fn().mockResolvedValue(bloqueos) },
  };
  const prisma = {
    $transaction: vi.fn((callback: (cliente: typeof tx) => unknown) =>
      callback(tx),
    ),
  };
  return {
    repository: new ReservaRepository(prisma as unknown as PrismaService),
    prisma,
    tx,
    reservaGuardada,
  };
}

describe('ReservaRepository.encolar', () => {
  it('con las fechas libres inserta la solicitud y la devuelve', async () => {
    const { repository, tx, reservaGuardada } = crear({});

    await expect(repository.encolar(datos)).resolves.toEqual({
      reserva: reservaGuardada,
    });
    // No envía estado: la columna ya nace en EN_COLA.
    expect(tx.reserva.create).toHaveBeenCalledWith({
      data: {
        ...datos,
        estado: EstadoReserva.EN_COLA,
        motivoResolucion: null,
        creadaEn: expect.any(Date),
        procesadaEn: null,
      },
    });
  });

  it.each([
    ['una reserva ocupa los días', { reservas: 1 }, 'RESERVA_OCUPADA'],
    ['hay un bloqueo', { bloqueos: 1 }, 'BLOQUEO'],
    [
      'hay una solicitud propia en cola',
      { propias: 1 },
      'SOLICITUD_PROPIA_EN_COLA',
    ],
  ])(
    'devuelve el motivo y no inserta cuando %s',
    async (_caso, conteos, esperado) => {
      const { repository, tx } = crear(conteos);

      await expect(repository.encolar(datos)).resolves.toEqual({
        conflicto: esperado,
      });
      expect(tx.reserva.create).not.toHaveBeenCalled();
    },
  );

  it('prioriza la reserva sobre el bloqueo y la solicitud propia', async () => {
    const { repository } = crear({ reservas: 1, bloqueos: 1, propias: 1 });

    await expect(repository.encolar(datos)).resolves.toEqual({
      conflicto: 'RESERVA_OCUPADA',
    });
  });

  it('cuenta como ocupadas los mismos estados que la disponibilidad, con solape inclusivo', async () => {
    const { repository, tx } = crear({});

    await repository.encolar(datos);

    const solape = {
      bienId: 'bien-1',
      fechaInicio: { lte: datos.fechaFin },
      fechaFin: { gte: datos.fechaInicio },
    };
    expect([...ESTADOS_QUE_OCUPAN].sort()).toEqual([
      'CONFIRMADA',
      'EN_CURSO',
      'FINALIZADA',
    ]);
    expect(tx.reserva.count).toHaveBeenNthCalledWith(1, {
      where: { ...solape, estado: { in: ESTADOS_QUE_OCUPAN } },
    });
    expect(tx.bloqueoFecha.count).toHaveBeenCalledWith({ where: solape });
    // Las solicitudes en cola solo importan si son del mismo usuario.
    expect(tx.reserva.count).toHaveBeenNthCalledWith(2, {
      where: { ...solape, arrendatarioId: 'usuario-1', estado: 'EN_COLA' },
    });
  });

  it('toma el lock del par (bien, arrendatario) antes de leer y de insertar, en una transacción', async () => {
    const { repository, prisma, tx } = crear({});

    await repository.encolar(datos);

    expect(prisma.$transaction).toHaveBeenCalledOnce();
    expect(tx.$executeRaw).toHaveBeenCalledOnce();
    // Los valores del lock viajan como parámetros, no pegados al SQL.
    const [sql, ...parametros] = tx.$executeRaw.mock.calls[0] as unknown as [
      string[],
      ...string[],
    ];
    expect(sql.join('?')).toContain('pg_advisory_xact_lock');
    expect(parametros).toEqual(['bien-1', 'usuario-1']);

    const orden = (mock: { mock: { invocationCallOrder: number[] } }) =>
      mock.mock.invocationCallOrder[0]!;
    expect(orden(tx.$executeRaw)).toBeLessThan(orden(tx.reserva.count));
    expect(orden(tx.$executeRaw)).toBeLessThan(orden(tx.reserva.create));
  });
});

describe('ReservaRepository.findDeParticipante (BE-27.2)', () => {
  function crearLectura(resultado: unknown) {
    const prisma = {
      reserva: { findFirst: vi.fn().mockResolvedValue(resultado) },
    };
    return {
      repository: new ReservaRepository(prisma as unknown as PrismaService),
      findFirst: prisma.reserva.findFirst,
    };
  }

  it('filtra por id y por pertenencia en la misma consulta: arrendatario o arrendador del bien', async () => {
    const { repository, findFirst } = crearLectura(null);

    await repository.findDeParticipante('reserva-1', 'usuario-1');

    expect(findFirst).toHaveBeenCalledTimes(1);
    expect(findFirst).toHaveBeenCalledWith({
      where: {
        id: 'reserva-1',
        OR: [
          { arrendatarioId: 'usuario-1' },
          { bien: { arrendadorId: 'usuario-1' } },
        ],
      },
      select: RESERVA_SELECT,
    });
  });

  it('devuelve la reserva que encuentra la consulta', async () => {
    const reserva = { id: 'reserva-1' };
    const { repository } = crearLectura(reserva);

    await expect(
      repository.findDeParticipante('reserva-1', 'usuario-1'),
    ).resolves.toBe(reserva);
  });

  it('devuelve null si la reserva no existe o es ajena', async () => {
    const { repository } = crearLectura(null);

    await expect(
      repository.findDeParticipante('reserva-1', 'otro-usuario'),
    ).resolves.toBeNull();
  });
});
