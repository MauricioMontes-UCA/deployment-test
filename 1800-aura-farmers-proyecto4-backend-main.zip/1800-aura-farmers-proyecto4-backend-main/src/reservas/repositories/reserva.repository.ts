import { Injectable } from '@nestjs/common';
import { PrismaService } from '@Prisma/services';
import { ESTADOS_QUE_OCUPAN } from '@Bienes/repositories';
import { esViolacionDeSolape } from '@Reservas/utils';
import {
  EstadoDeposito,
  EstadoReserva,
  type Devolucion,
  type EstadoFinalBien,
  type Prisma,
  type Reserva,
} from '@PrismaClient';

export const RESERVA_SELECT = {
  id: true,
  bienId: true,
  arrendatarioId: true,
  fechaInicio: true,
  fechaFin: true,
  estado: true,
  motivoResolucion: true,
  creadaEn: true,
  procesadaEn: true,
  finalizadaEn: true,

  bien: {
    select: {
      id: true,
      titulo: true,
      precio: true,
      unidadCobro: true,

      arrendador: {
        select: {
          id: true,
          nombreUsuario: true,
        },
      },

      fotos: {
        where: {
          esPrincipal: true,
        },
        select: {
          url: true,
        },
        take: 1,
      },
    },
  },

  arrendatario: {
    select: {
      id: true,
      nombreUsuario: true,
    },
  },

  pagos: {
    select: {
      id: true,
      estado: true,
      total: true,
    },
    orderBy: {
      fechaHora: 'desc',
    },
  },

  deposito: {
    select: {
      estado: true,
      importeOriginal: true,
    },
  },
} as const;

export type ReservaConsulta = Prisma.ReservaGetPayload<{
  select: typeof RESERVA_SELECT;
}>;

export interface CreateReservaData {
  bienId: string;
  arrendatarioId: string;
  fechaInicio: Date;
  fechaFin: Date;
}

/** Qué impide encolar la solicitud. */
export type ConflictoReserva =
  'RESERVA_OCUPADA' | 'BLOQUEO' | 'SOLICITUD_PROPIA_EN_COLA';

/** Resultado de intentar encolar: la reserva creada o el motivo del rechazo. */
export type ResultadoEncolado =
  { reserva: Reserva } | { conflicto: ConflictoReserva };

/** Por qué una solicitud pasa a RECHAZADA; se guarda en `motivoResolucion`. */
export const MotivoRechazo = {
  VERIFICACION_REQUERIDA: 'VERIFICACION_REQUERIDA',
  FECHAS_NO_DISPONIBLES: 'FECHAS_NO_DISPONIBLES',
  ERROR_DE_PROCESAMIENTO: 'ERROR_DE_PROCESAMIENTO',
} as const;
export type MotivoRechazo = (typeof MotivoRechazo)[keyof typeof MotivoRechazo];

/** Solicitud EN_COLA que el procesador está resolviendo. */
export interface SolicitudEnCola {
  id: string;
  bienId: string;
  arrendatarioId: string;
  fechaInicio: Date;
  fechaFin: Date;
  creadaEn: Date;
}

/** Lo que el servicio decide para la solicitud. */
export type DecisionSolicitud =
  { estado: 'CONFIRMADA' } | { estado: 'RECHAZADA'; motivo: MotivoRechazo };

/** Lo que pasó al intentar procesar la siguiente solicitud. */
export type ResultadoProcesamiento =
  | { tipo: 'PROCESADA'; reserva: Reserva }
  | { tipo: 'COLA_VACIA' }
  // Otra instancia tiene una solicitud más antigua del mismo bien: se deja
  // para después y se respeta el orden de llegada.
  | { tipo: 'APLAZADA' };

/** Una página de las reservas recibidas por un arrendador (BE-27.1). */
export interface ConsultaRecibidas {
  /** Siempre el usuario autenticado; nunca un dato de la petición. */
  arrendadorId: string;
  estado?: EstadoReserva;
  /** Reservas que se saltan antes de la página: `(pagina - 1) * limite`. */
  desplazamiento: number;
  limite: number;
}

export interface PaginaReservas {
  reservas: ReservaConsulta[];
  /** Reservas que cumplen el filtro, sin contar la paginación. */
  total: number;
}

/** Decide el destino de una solicitud; `ocupado` consulta las fechas en la misma transacción. */
export type ResolverSolicitud = (
  solicitud: SolicitudEnCola,
  ocupado: () => Promise<boolean>,
  tx: Prisma.TransactionClient,
) => Promise<DecisionSolicitud>;

/** Fila cruda de la consulta con FOR UPDATE SKIP LOCKED. */
interface FilaEnCola {
  id: string;
  bienId: string;
  arrendatarioId: string;
  fechaInicio: Date | string;
  fechaFin: Date | string;
  creadaEn: Date | string;
}

export interface RegistrarDevolucionData {
  reservaId: string;
  /** Arrendador autenticado: debe ser el dueño del bien de la reserva. */
  registradoPorId: string;
  fechaDevolucion: Date;
  estadoFinalBien: EstadoFinalBien;
  observaciones?: string;
  /** Instante de la operación: `finalizadaEn` y base del plazo del depósito. */
  ahora: Date;
  /** Días, desde `ahora`, que tiene el arrendador para resolver el depósito. */
  plazoDepositoDias: number;
}

/** Por qué no se pudo registrar la devolución. */
export type RechazoDevolucion =
  | 'NO_EXISTE'
  | 'NO_ES_PROPIETARIO'
  | 'NO_EN_CURSO'
  | 'YA_DEVUELTA'
  | 'CIERRE_AUTOMATICO';

/** La devolución registrada o el motivo del rechazo. */
export type ResultadoDevolucion =
  { devolucion: Devolucion } | { rechazo: RechazoDevolucion };

const MS_POR_DIA = 24 * 60 * 60 * 1000;

/** Único punto del módulo que escribe en la tabla `Reservas`. */
@Injectable()
export class ReservaRepository {
  constructor(private readonly prisma: PrismaService) {}

  /**
   * Inserta la solicitud como EN_COLA, salvo que las fechas estén ocupadas.
   *
   * La comprobación y el insert van en una sola transacción, serializada por
   * (bien, arrendatario) con un advisory lock: sin él, dos POST idénticos casi
   * simultáneos (doble clic, reintento) leerían ambos "sin conflicto" e
   * insertarían dos solicitudes EN_COLA solapadas del mismo usuario. El lock se
   * libera solo al terminar la transacción.
   *
   * Contra otros usuarios sigue siendo una comprobación temprana, no una
   * garantía: una solicitud ajena puede confirmarse entre la lectura y el
   * insert. La decisión final la toma el procesador de la cola.
   */
  encolar(data: CreateReservaData): Promise<ResultadoEncolado> {
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${data.bienId}), hashtext(${data.arrendatarioId}))`;

      const conflicto = await this.findConflicto(tx, data);
      if (conflicto) return { conflicto };

      // La columna `estado` ya nace en EN_COLA.
      return {
        reserva: await tx.reserva.create({
          data: {
            ...data,
            estado: EstadoReserva.EN_COLA,
            motivoResolucion: null,
            creadaEn: new Date(),
            procesadaEn: null,
          },
        }),
      };
    });
  }

  /** Primer motivo que impide encolar, o null si las fechas están libres. */
  private async findConflicto(
    tx: Prisma.TransactionClient,
    { bienId, arrendatarioId, fechaInicio, fechaFin }: CreateReservaData,
  ): Promise<ConflictoReserva | null> {
    // Dos rangos inclusivos se solapan si cada uno empieza antes de que
    // termine el otro.
    const solapa = {
      bienId,
      fechaInicio: { lte: fechaFin },
      fechaFin: { gte: fechaInicio },
    };

    const [reservas, bloqueos, propias] = await Promise.all([
      // Los mismos estados que muestra la disponibilidad y que la base impide
      // solapar. Las EN_COLA de otros usuarios no retienen fechas.
      tx.reserva.count({
        where: { ...solapa, estado: { in: ESTADOS_QUE_OCUPAN } },
      }),
      tx.bloqueoFecha.count({ where: solapa }),
      tx.reserva.count({
        where: { ...solapa, arrendatarioId, estado: EstadoReserva.EN_COLA },
      }),
    ]);

    if (reservas > 0) return 'RESERVA_OCUPADA';
    if (bloqueos > 0) return 'BLOQUEO';
    if (propias > 0) return 'SOLICITUD_PROPIA_EN_COLA';
    return null;
  }

  /**
   * Resuelve la solicitud EN_COLA más antigua, si hay alguna, en una sola
   * transacción:
   *
   * 1. La toma con `FOR UPDATE SKIP LOCKED`: dos instancias nunca procesan la
   *    misma, y una que llegue con la fila tomada pasa a la siguiente.
   * 2. Toma un advisory lock del bien, para que las solicitudes de un mismo
   *    bien se resuelvan de una en una aunque haya varias instancias.
   * 3. Si otra instancia tiene una solicitud más antigua del mismo bien que
   *    solapa, se aplaza (rollback): resolverla antes respeta el orden de llegada.
   * 4. Pide la decisión al servicio y la escribe junto con `procesadaEn`.
   *
   * Si la base rechaza la confirmación con `reserva_sin_solape` (23P01), la
   * transacción queda abortada y no se puede seguir en ella: la solicitud se
   * rechaza por fechas en una transacción nueva.
   */
  async procesarSiguiente(
    ahora: Date,
    resolver: ResolverSolicitud,
  ): Promise<ResultadoProcesamiento> {
    // Objeto y no variable suelta: TypeScript no ve la asignación dentro del callback.
    const seguimiento: { id: string | null } = { id: null };
    try {
      return await this.prisma.$transaction(async (tx) => {
        const solicitud = await this.tomarSiguiente(tx);
        if (!solicitud) return { tipo: 'COLA_VACIA' } as const;
        seguimiento.id = solicitud.id;

        await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${solicitud.bienId}))`;
        if (await this.hayAnteriorSinResolver(tx, solicitud)) {
          return { tipo: 'APLAZADA' } as const;
        }

        const decision = await resolver(
          solicitud,
          () => this.estaOcupado(tx, solicitud),
          tx,
        );
        const reserva = await tx.reserva.update({
          where: { id: solicitud.id },
          data: {
            estado: decision.estado,
            motivoResolucion:
              decision.estado === 'RECHAZADA' ? decision.motivo : null,
            procesadaEn: ahora,
          },
        });
        return { tipo: 'PROCESADA', reserva } as const;
      });
    } catch (error) {
      if (seguimiento.id && esViolacionDeSolape(error)) {
        return {
          tipo: 'PROCESADA',
          reserva: await this.rechazar(
            seguimiento.id,
            MotivoRechazo.FECHAS_NO_DISPONIBLES,
            ahora,
          ),
        };
      }
      throw error;
    }
  }

  /** Rechaza una solicitud que sigue EN_COLA, fuera de la transacción abortada. */
  private rechazar(
    id: string,
    motivo: MotivoRechazo,
    ahora: Date,
  ): Promise<Reserva> {
    return this.prisma.reserva.update({
      where: { id },
      data: {
        estado: EstadoReserva.RECHAZADA,
        motivoResolucion: motivo,
        procesadaEn: ahora,
      },
    });
  }

  private async tomarSiguiente(
    tx: Prisma.TransactionClient,
  ): Promise<SolicitudEnCola | null> {
    const filas = await tx.$queryRaw<FilaEnCola[]>`
      SELECT id,
             bien_id AS "bienId",
             arrendatario_id AS "arrendatarioId",
             fecha_inicio AS "fechaInicio",
             fecha_fin AS "fechaFin",
             creada_en AS "creadaEn"
      FROM "Reservas"
      WHERE estado = 'EN_COLA'
      ORDER BY creada_en, id
      LIMIT 1
      FOR UPDATE SKIP LOCKED`;
    const fila = filas[0];
    if (!fila) return null;

    return {
      id: fila.id,
      bienId: fila.bienId,
      arrendatarioId: fila.arrendatarioId,
      fechaInicio: new Date(fila.fechaInicio),
      fechaFin: new Date(fila.fechaFin),
      creadaEn: new Date(fila.creadaEn),
    };
  }

  /** ¿Hay una solicitud más antigua del mismo bien, con días en común, aún en cola? */
  private async hayAnteriorSinResolver(
    tx: Prisma.TransactionClient,
    solicitud: SolicitudEnCola,
  ): Promise<boolean> {
    const anteriores = await tx.reserva.count({
      where: {
        bienId: solicitud.bienId,
        estado: EstadoReserva.EN_COLA,
        id: { not: solicitud.id },
        creadaEn: { lte: solicitud.creadaEn },
        fechaInicio: { lte: solicitud.fechaFin },
        fechaFin: { gte: solicitud.fechaInicio },
        // Con la misma marca de tiempo manda el id, como en el ORDER BY.
        OR: [
          { creadaEn: { lt: solicitud.creadaEn } },
          { id: { lt: solicitud.id } },
        ],
      },
    });
    return anteriores > 0;
  }

  /** ¿Las fechas chocan con una reserva que ocupa días o con un bloqueo? */
  private async estaOcupado(
    tx: Prisma.TransactionClient,
    { bienId, fechaInicio, fechaFin }: SolicitudEnCola,
  ): Promise<boolean> {
    const solapa = {
      bienId,
      fechaInicio: { lte: fechaFin },
      fechaFin: { gte: fechaInicio },
    };
    const reservas = await tx.reserva.count({
      where: { ...solapa, estado: { in: ESTADOS_QUE_OCUPAN } },
    });
    if (reservas > 0) return true;
    return (await tx.bloqueoFecha.count({ where: solapa })) > 0;
  }

  /**
   * Reservas de los bienes del arrendador (BE-27.1), con el filtro de estado
   * opcional y paginadas.
   *
   * - La pertenencia se filtra en la base por `bien.arrendadorId`.
   * - Orden: `fechaInicio` ascendente, luego `creadaEn` descendente y, como
   *   desempate final, `id`, para que la paginación sea estable.
   * - Si el desplazamiento alcanza o supera el total (una página posterior a
   *   la última, por grande que sea), no se consultan filas: así Prisma nunca
   *   recibe un `skip` fuera de rango.
   * - El conteo y la página son dos consultas separadas, sin transacción:
   *   con escrituras concurrentes, `total` e `items` pueden reflejar instantes
   *   ligeramente distintos. Es el mismo criterio del resto de los listados.
   */
  async findRecibidas({
    arrendadorId,
    estado,
    desplazamiento,
    limite,
  }: ConsultaRecibidas): Promise<PaginaReservas> {
    const where: Prisma.ReservaWhereInput = {
      bien: { arrendadorId },
      ...(estado ? { estado } : {}),
    };

    const total = await this.prisma.reserva.count({ where });
    if (desplazamiento >= total) return { reservas: [], total };

    const reservas = await this.prisma.reserva.findMany({
      where,
      select: RESERVA_SELECT,
      orderBy: [{ fechaInicio: 'asc' }, { creadaEn: 'desc' }, { id: 'asc' }],
      skip: desplazamiento,
      take: limite,
    });
    return { reservas, total };
  }

  async findMias(
    arrendatarioId: string,
    estado?: EstadoReserva,
  ): Promise<ReservaConsulta[]> {
    return this.prisma.reserva.findMany({
      where: {
        arrendatarioId,
        ...(estado ? { estado } : {}),
      },
      select: RESERVA_SELECT,
      orderBy: [{ creadaEn: 'desc' }, { id: 'desc' }],
    });
  }

  /**
   * La reserva, solo si el usuario participa en ella: es su arrendatario o es
   * el arrendador dueño del bien reservado (BE-27.2). La pertenencia se
   * comprueba en la misma consulta, así que de una reserva ajena no se lee
   * ningún dato: devuelve `null`, igual que si no existiera.
   */
  async findDeParticipante(
    id: string,
    usuarioId: string,
  ): Promise<ReservaConsulta | null> {
    return this.prisma.reserva.findFirst({
      where: {
        id,
        OR: [
          { arrendatarioId: usuarioId },
          { bien: { arrendadorId: usuarioId } },
        ],
      },
      select: RESERVA_SELECT,
    });
  }

  /**
   * Registra la devolución y finaliza la reserva, todo en una transacción:
   * inserta la devolución, pasa la reserva a FINALIZADA con `finalizadaEn` y
   * fija el plazo de resolución del depósito PENDIENTE, si lo hay.
   *
   * La fila de la reserva se bloquea (`FOR UPDATE`) antes de leer su estado.
   * Sin eso, dos peticiones casi simultáneas verían ambas EN_CURSO y la
   * segunda chocaría con la restricción única de la devolución, con un 500 en
   * vez del 409 que corresponde. Con el bloqueo, la segunda espera, ve
   * FINALIZADA y recibe `YA_DEVUELTA`.
   *
   * Las comprobaciones van dentro de la transacción y no antes: el estado que
   * se valida es el mismo que se cambia.
   */
  registrarDevolucion({
    reservaId,
    registradoPorId,
    fechaDevolucion,
    estadoFinalBien,
    observaciones,
    ahora,
    plazoDepositoDias,
  }: RegistrarDevolucionData): Promise<ResultadoDevolucion> {
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT 1 FROM "Reservas" WHERE id = ${reservaId}::uuid FOR UPDATE`;

      const reserva = await tx.reserva.findUnique({
        where: { id: reservaId },
        select: {
          estado: true,
          cierreAutomatico: true,
          bien: { select: { arrendadorId: true } },
          devolucion: { select: { id: true } },
        },
      });

      if (!reserva) return { rechazo: 'NO_EXISTE' };
      if (reserva.bien.arrendadorId !== registradoPorId) {
        return { rechazo: 'NO_ES_PROPIETARIO' };
      }
      if (reserva.estado === EstadoReserva.FINALIZADA) {
        return {
          rechazo: reserva.cierreAutomatico
            ? 'CIERRE_AUTOMATICO'
            : 'YA_DEVUELTA',
        };
      }
      if (reserva.devolucion) return { rechazo: 'YA_DEVUELTA' };
      if (reserva.estado !== EstadoReserva.EN_CURSO) {
        return { rechazo: 'NO_EN_CURSO' };
      }

      const devolucion = await tx.devolucion.create({
        data: {
          reservaId,
          registradoPorId,
          fechaDevolucion,
          estadoFinalBien,
          observaciones: observaciones ?? null,
        },
      });
      await tx.reserva.update({
        where: { id: reservaId },
        data: { estado: EstadoReserva.FINALIZADA, finalizadaEn: ahora },
      });
      // Solo un depósito PENDIENTE: si no hay depósito, o ya se resolvió, no
      // hay plazo que fijar.
      await tx.deposito.updateMany({
        where: { reservaId, estado: EstadoDeposito.PENDIENTE },
        data: {
          plazoResolucion: new Date(
            ahora.getTime() + plazoDepositoDias * MS_POR_DIA,
          ),
        },
      });

      return { devolucion };
    });
  }

  /**
   * BE-22.1
   * Obtiene los datos necesarios para notificar una solicitud
   * de reserva que ya fue persistida.
   */
  async obtenerDatosParaNotificacion(reservaId: string) {
    return this.prisma.reserva.findUnique({
      where: {
        id: reservaId,
      },
      select: {
        id: true,
        fechaInicio: true,
        fechaFin: true,
        bien: {
          select: {
            titulo: true,
            arrendadorId: true,
          },
        },
        arrendatario: {
          select: {
            nombreUsuario: true,
          },
        },
      },
    });
  }
}
