import { Injectable } from '@nestjs/common';
import { EstadoDeposito, EstadoReserva } from '@PrismaClient';
import { PrismaService } from '@Prisma/services';

@Injectable()
export class TareaReservasRepository {
  constructor(private readonly prisma: PrismaService) {}

  listarConfirmadas() {
    return this.prisma.reserva.findMany({
      where: { estado: EstadoReserva.CONFIRMADA },
      select: { id: true, fechaInicio: true },
    });
  }

  async iniciar(id: string): Promise<boolean> {
    return (
      (
        await this.prisma.$transaction(async (tx) =>
          tx.reserva.updateMany({
            where: { id, estado: EstadoReserva.CONFIRMADA },
            data: { estado: EstadoReserva.EN_CURSO },
          }),
        )
      ).count === 1
    );
  }

  listarEnCurso() {
    return this.prisma.reserva.findMany({
      where: { estado: EstadoReserva.EN_CURSO, devolucion: null },
      select: { id: true, fechaFin: true },
    });
  }

  async cerrar(id: string, ahora: Date): Promise<boolean> {
    return this.prisma.$transaction(async (tx) => {
      // Bloquea la fila para coordinar con la devolución manual.
      await tx.$queryRaw`SELECT id FROM "Reservas" WHERE id = ${id}::uuid FOR UPDATE`;
      const reserva = await tx.reserva.findUnique({
        where: { id },
        select: { estado: true, devolucion: { select: { id: true } } },
      });
      if (reserva?.estado !== EstadoReserva.EN_CURSO || reserva.devolucion)
        return false;
      await tx.reserva.update({
        where: { id },
        data: {
          estado: EstadoReserva.FINALIZADA,
          cierreAutomatico: true,
          finalizadaEn: ahora,
        },
      });
      return true;
    });
  }

  listarDepositosPendientes() {
    return this.prisma.deposito.findMany({
      where: {
        estado: EstadoDeposito.PENDIENTE,
        reserva: { estado: EstadoReserva.FINALIZADA },
      },
      select: {
        id: true,
        reserva: { select: { finalizadaEn: true, cierreAutomatico: true } },
      },
    });
  }
}
