import type { PrismaService } from '@Prisma/services';
import { RESERVA_SELECT, ReservaRepository } from './reserva.repository.js';

function crear(total: number, filas: unknown[] = []) {
  const prisma = {
    reserva: {
      count: vi.fn().mockResolvedValue(total),
      findMany: vi.fn().mockResolvedValue(filas),
    },
  };
  return {
    repository: new ReservaRepository(prisma as unknown as PrismaService),
    count: prisma.reserva.count,
    findMany: prisma.reserva.findMany,
  };
}

describe('ReservaRepository.findRecibidas (BE-27.1)', () => {
  it('filtra por el arrendador dueño del bien, ordena y pagina', async () => {
    const filas = [{ id: 'reserva-1' }];
    const { repository, count, findMany } = crear(45, filas);

    await expect(
      repository.findRecibidas({
        arrendadorId: 'arrendador-1',
        desplazamiento: 20,
        limite: 20,
      }),
    ).resolves.toEqual({ reservas: filas, total: 45 });

    const where = { bien: { arrendadorId: 'arrendador-1' } };
    expect(count).toHaveBeenCalledWith({ where });
    expect(findMany).toHaveBeenCalledWith({
      where,
      select: RESERVA_SELECT,
      orderBy: [{ fechaInicio: 'asc' }, { creadaEn: 'desc' }, { id: 'asc' }],
      skip: 20,
      take: 20,
    });
  });

  it('con estado, lo agrega al mismo filtro para el conteo y para las filas', async () => {
    const { repository, count, findMany } = crear(3);

    await repository.findRecibidas({
      arrendadorId: 'arrendador-1',
      estado: 'RECHAZADA',
      desplazamiento: 0,
      limite: 20,
    });

    const where = {
      bien: { arrendadorId: 'arrendador-1' },
      estado: 'RECHAZADA',
    };
    expect(count).toHaveBeenCalledWith({ where });
    expect(findMany.mock.calls[0]![0].where).toEqual(where);
  });

  it('sin reservas no consulta filas', async () => {
    const { repository, findMany } = crear(0);

    await expect(
      repository.findRecibidas({
        arrendadorId: 'arrendador-1',
        desplazamiento: 0,
        limite: 20,
      }),
    ).resolves.toEqual({ reservas: [], total: 0 });
    expect(findMany).not.toHaveBeenCalled();
  });

  it.each([45, 60, 1e21, Number.MAX_VALUE])(
    'con un desplazamiento de %s sobre 45 reservas no consulta filas ni pasa el skip a Prisma',
    async (desplazamiento) => {
      const { repository, findMany } = crear(45);

      await expect(
        repository.findRecibidas({
          arrendadorId: 'arrendador-1',
          desplazamiento,
          limite: 20,
        }),
      ).resolves.toEqual({ reservas: [], total: 45 });
      expect(findMany).not.toHaveBeenCalled();
    },
  );
});
