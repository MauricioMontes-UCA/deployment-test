import { ReservaRepository, MotivoRechazo } from './reserva.repository.js';
import type { ResolverSolicitud } from './reserva.repository.js';
import type { PrismaService } from '@Prisma/services';

const AHORA = new Date('2026-11-12T18:00:00.000Z');

const fila = {
  id: 'reserva-1',
  bienId: 'bien-1',
  arrendatarioId: 'usuario-1',
  fechaInicio: '2026-12-10T00:00:00.000Z',
  fechaFin: new Date('2026-12-12T00:00:00.000Z'),
  creadaEn: new Date('2026-11-12T17:59:00.000Z'),
};

function crear(
  opciones: {
    filas?: unknown[];
    anteriores?: number;
    reservasOcupadas?: number;
    bloqueos?: number;
  } = {},
) {
  const {
    filas = [fila],
    anteriores = 0,
    reservasOcupadas = 0,
    bloqueos = 0,
  } = opciones;
  const reservaActualizada = { id: 'reserva-1', estado: 'CONFIRMADA' };
  const orden: string[] = [];

  const tx = {
    $queryRaw: vi.fn(() => {
      orden.push('queryRaw');
      return Promise.resolve(filas);
    }),
    $executeRaw: vi.fn(() => {
      orden.push('lock');
      return Promise.resolve(1);
    }),
    reserva: {
      // Las EN_COLA anteriores y las reservas que ocupan días se distinguen por el estado.
      count: vi.fn(({ where }: { where: { estado: unknown } }) => {
        orden.push('count');
        return Promise.resolve(
          where.estado === 'EN_COLA' ? anteriores : reservasOcupadas,
        );
      }),
      update: vi.fn().mockResolvedValue(reservaActualizada),
    },
    bloqueoFecha: { count: vi.fn().mockResolvedValue(bloqueos) },
  };
  const prisma = {
    $transaction: vi.fn((callback: (cliente: typeof tx) => unknown) =>
      callback(tx),
    ),
    reserva: {
      update: vi
        .fn()
        .mockResolvedValue({ id: 'reserva-1', estado: 'RECHAZADA' }),
    },
  };
  return {
    repository: new ReservaRepository(prisma as unknown as PrismaService),
    prisma,
    tx,
    orden,
    reservaActualizada,
  };
}

const confirmar: ResolverSolicitud = () =>
  Promise.resolve({ estado: 'CONFIRMADA' });

describe('ReservaRepository.procesarSiguiente', () => {
  it('con la cola vacía no toma ningún lock ni escribe', async () => {
    const { repository, tx } = crear({ filas: [] });
    const resolver = vi.fn(confirmar);

    await expect(
      repository.procesarSiguiente(AHORA, resolver),
    ).resolves.toEqual({ tipo: 'COLA_VACIA' });
    expect(tx.$executeRaw).not.toHaveBeenCalled();
    expect(tx.reserva.update).not.toHaveBeenCalled();
    expect(resolver).not.toHaveBeenCalled();
  });

  it('toma la fila, bloquea el bien y recién entonces mira anteriores y decide', async () => {
    const { repository, orden } = crear();

    await repository.procesarSiguiente(AHORA, confirmar);

    expect(orden).toEqual(['queryRaw', 'lock', 'count']);
  });

  it('entrega al resolver la solicitud con las fechas como Date y la transacción en curso', async () => {
    const { repository, tx } = crear();
    const resolver = vi.fn(confirmar);

    await repository.procesarSiguiente(AHORA, resolver);

    expect(resolver).toHaveBeenCalledWith(
      {
        id: 'reserva-1',
        bienId: 'bien-1',
        arrendatarioId: 'usuario-1',
        fechaInicio: new Date('2026-12-10T00:00:00.000Z'),
        fechaFin: new Date('2026-12-12T00:00:00.000Z'),
        creadaEn: new Date('2026-11-12T17:59:00.000Z'),
      },
      expect.any(Function),
      tx,
    );
  });

  it('confirma: guarda el estado y procesadaEn, sin motivo', async () => {
    const { repository, tx, reservaActualizada } = crear();

    await expect(
      repository.procesarSiguiente(AHORA, confirmar),
    ).resolves.toEqual({ tipo: 'PROCESADA', reserva: reservaActualizada });
    expect(tx.reserva.update).toHaveBeenCalledWith({
      where: { id: 'reserva-1' },
      data: {
        estado: 'CONFIRMADA',
        motivoResolucion: null,
        procesadaEn: AHORA,
      },
    });
  });

  it('rechaza: guarda el motivo y procesadaEn', async () => {
    const { repository, tx } = crear();

    await repository.procesarSiguiente(AHORA, () =>
      Promise.resolve({
        estado: 'RECHAZADA',
        motivo: MotivoRechazo.VERIFICACION_REQUERIDA,
      }),
    );

    expect(tx.reserva.update).toHaveBeenCalledWith({
      where: { id: 'reserva-1' },
      data: {
        estado: 'RECHAZADA',
        motivoResolucion: 'VERIFICACION_REQUERIDA',
        procesadaEn: AHORA,
      },
    });
  });

  it('aplaza la solicitud si hay una más antigua del mismo bien con días en común', async () => {
    const { repository, tx } = crear({ anteriores: 1 });
    const resolver = vi.fn(confirmar);

    await expect(
      repository.procesarSiguiente(AHORA, resolver),
    ).resolves.toEqual({ tipo: 'APLAZADA' });
    expect(resolver).not.toHaveBeenCalled();
    expect(tx.reserva.update).not.toHaveBeenCalled();
  });

  it('busca anteriores del mismo bien, EN_COLA, que solapen y la precedan', async () => {
    const { repository, tx } = crear();

    await repository.procesarSiguiente(AHORA, confirmar);

    expect(tx.reserva.count).toHaveBeenCalledWith({
      where: {
        bienId: 'bien-1',
        estado: 'EN_COLA',
        id: { not: 'reserva-1' },
        creadaEn: { lte: new Date('2026-11-12T17:59:00.000Z') },
        fechaInicio: { lte: new Date('2026-12-12T00:00:00.000Z') },
        fechaFin: { gte: new Date('2026-12-10T00:00:00.000Z') },
        OR: [
          { creadaEn: { lt: new Date('2026-11-12T17:59:00.000Z') } },
          { id: { lt: 'reserva-1' } },
        ],
      },
    });
  });

  describe('ocupado', () => {
    async function consultar(opciones: Parameters<typeof crear>[0]) {
      const { repository, tx } = crear(opciones);
      let respuesta: boolean | undefined;
      await repository.procesarSiguiente(AHORA, async (_s, ocupado) => {
        respuesta = await ocupado();
        return { estado: 'CONFIRMADA' };
      });
      return { respuesta, tx };
    }

    it('es true si una reserva que ocupa días solapa', async () => {
      const { respuesta, tx } = await consultar({ reservasOcupadas: 1 });

      expect(respuesta).toBe(true);
      // Con una reserva ya no hace falta mirar los bloqueos.
      expect(tx.bloqueoFecha.count).not.toHaveBeenCalled();
    });

    it('es true si solo hay un bloqueo', async () => {
      expect((await consultar({ bloqueos: 1 })).respuesta).toBe(true);
    });

    it('es false si no hay reservas ni bloqueos', async () => {
      expect((await consultar({})).respuesta).toBe(false);
    });

    it('cuenta solo los estados que ocupan días', async () => {
      const { tx } = await consultar({});

      expect(tx.reserva.count).toHaveBeenCalledWith({
        where: {
          bienId: 'bien-1',
          fechaInicio: { lte: new Date('2026-12-12T00:00:00.000Z') },
          fechaFin: { gte: new Date('2026-12-10T00:00:00.000Z') },
          estado: { in: ['CONFIRMADA', 'EN_CURSO', 'FINALIZADA'] },
        },
      });
    });
  });

  describe('si la base rechaza la confirmación con reserva_sin_solape (23P01)', () => {
    it('rechaza por fechas en una transacción nueva, no en la abortada', async () => {
      const { repository, tx, prisma } = crear();
      tx.reserva.update.mockRejectedValueOnce({ code: '23P01' });

      const resultado = await repository.procesarSiguiente(AHORA, confirmar);

      expect(resultado).toEqual({
        tipo: 'PROCESADA',
        reserva: { id: 'reserva-1', estado: 'RECHAZADA' },
      });
      expect(prisma.reserva.update).toHaveBeenCalledWith({
        where: { id: 'reserva-1' },
        data: {
          estado: 'RECHAZADA',
          motivoResolucion: 'FECHAS_NO_DISPONIBLES',
          procesadaEn: AHORA,
        },
      });
    });

    it('lo reconoce también envuelto en el error de Prisma', async () => {
      const { repository, tx, prisma } = crear();
      tx.reserva.update.mockRejectedValueOnce(
        Object.assign(new Error('Invalid prisma.reserva.update()'), {
          meta: { driverAdapterError: { cause: { originalCode: '23P01' } } },
        }),
      );

      await repository.procesarSiguiente(AHORA, confirmar);

      expect(prisma.reserva.update).toHaveBeenCalledOnce();
    });
  });

  it('propaga cualquier otro error sin rechazar la solicitud', async () => {
    const { repository, tx, prisma } = crear();
    tx.reserva.update.mockRejectedValueOnce(new Error('conexión caída'));

    await expect(
      repository.procesarSiguiente(AHORA, confirmar),
    ).rejects.toThrow('conexión caída');
    expect(prisma.reserva.update).not.toHaveBeenCalled();
  });

  it('un 23P01 antes de tomar ninguna fila no rechaza nada', async () => {
    const { repository, tx, prisma } = crear();
    tx.$queryRaw.mockRejectedValueOnce({ code: '23P01' });

    await expect(
      repository.procesarSiguiente(AHORA, confirmar),
    ).rejects.toEqual({
      code: '23P01',
    });
    expect(prisma.reserva.update).not.toHaveBeenCalled();
  });
});
