import { randomUUID } from 'node:crypto';
import { Injectable } from '@nestjs/common';
import { PrismaService } from '@Prisma/services';
import {
  EstadoDeposito,
  EstadoPago,
  EstadoReserva,
  Prisma,
  type ModalidadPago,
  type Pago,
} from '@PrismaClient';
import type { Cargos, ResultadoPasarela } from '@Pagos/utils';

const UNIQUE_CONSTRAINT_VIOLATION = 'P2002';

/** Lo que se lee de la reserva para decidir si se puede pagar y cuánto. */
export const RESERVA_PARA_PAGO_SELECT = {
  id: true,
  arrendatarioId: true,
  fechaInicio: true,
  fechaFin: true,
  estado: true,
  bien: { select: { precio: true, unidadCobro: true, deposito: true } },
  // Basta saber si existe uno: el índice único parcial permite como máximo uno.
  pagos: {
    where: { estado: EstadoPago.SIMULADO_EXITOSO },
    select: { id: true },
    take: 1,
  },
} as const;

export type ReservaParaPago = Prisma.ReservaGetPayload<{
  select: typeof RESERVA_PARA_PAGO_SELECT;
}>;

/** Por qué no se puede consultar o pagar la reserva. */
export type RechazoPago =
  'NO_EXISTE' | 'NO_ES_PROPIETARIO' | 'PAGO_DUPLICADO' | 'NO_PAGABLE';

export interface RegistrarPagoData {
  reservaId: string;
  /** Arrendatario autenticado: debe ser el dueño de la reserva. */
  arrendatarioId: string;
  modalidad: ModalidadPago;
  cargos: Cargos;
  resultado: ResultadoPasarela;
  /** Instante del pago: `fechaHora` del registro. */
  ahora: Date;
}

/** El pago registrado o el motivo del rechazo. */
export type ResultadoRegistroPago = { pago: Pago } | { rechazo: RechazoPago };

/** Lo que se lee de un pago para mostrar su comprobante. */
export const PAGO_COMPROBANTE_SELECT = {
  id: true,
  reservaId: true,
  fechaHora: true,
  importeAlquiler: true,
  importeDeposito: true,
  total: true,
  modalidad: true,
  estado: true,
  comprobanteId: true,
  // Solo para validar que el pago es de quien lo consulta.
  reserva: { select: { arrendatarioId: true } },
} as const;

export type PagoComprobante = Prisma.PagoGetPayload<{
  select: typeof PAGO_COMPROBANTE_SELECT;
}>;

/**
 * Primer motivo que impide pagar la reserva, o null si se puede pagar.
 *
 * El orden importa: no se revela nada de una reserva ajena, y un pago ya
 * completado tiene un mensaje propio aunque la reserva haya cambiado de estado.
 */
export function motivoNoPagable(
  reserva: ReservaParaPago | null,
  arrendatarioId: string,
): RechazoPago | null {
  if (!reserva) return 'NO_EXISTE';
  if (reserva.arrendatarioId !== arrendatarioId) return 'NO_ES_PROPIETARIO';
  if (reserva.pagos.length > 0) return 'PAGO_DUPLICADO';
  if (reserva.estado !== EstadoReserva.CONFIRMADA) return 'NO_PAGABLE';
  return null;
}

/** Único punto del módulo que escribe en `Pagos` y crea el depósito. */
@Injectable()
export class PagoRepository {
  constructor(private readonly prisma: PrismaService) {}

  findReservaParaPago(reservaId: string): Promise<ReservaParaPago | null> {
    return this.prisma.reserva.findUnique({
      where: { id: reservaId },
      select: RESERVA_PARA_PAGO_SELECT,
    });
  }

  findComprobante(pagoId: string): Promise<PagoComprobante | null> {
    return this.prisma.pago.findUnique({
      where: { id: pagoId },
      select: PAGO_COMPROBANTE_SELECT,
    });
  }

  /**
   * Guarda el resultado de la pasarela y, si fue exitoso y el bien pide
   * depósito, crea el depósito PENDIENTE en la misma transacción.
   *
   * La fila de la reserva se bloquea (`FOR UPDATE`) antes de volver a validar.
   * Así, de dos pagos simultáneos, el segundo espera, ve el pago exitoso del
   * primero y recibe `PAGO_DUPLICADO`. Si aun así el índice único parcial
   * `Pagos_un_exitoso_por_reserva_key` salta (P2002), también es un duplicado.
   *
   * Un pago rechazado se guarda igual, sin comprobante: el cobro queda
   * pendiente y el reintento es un registro nuevo.
   */
  async registrarPago({
    reservaId,
    arrendatarioId,
    modalidad,
    cargos,
    resultado,
    ahora,
  }: RegistrarPagoData): Promise<ResultadoRegistroPago> {
    try {
      return await this.prisma.$transaction(async (tx) => {
        await tx.$executeRaw`SELECT 1 FROM "Reservas" WHERE id = ${reservaId}::uuid FOR UPDATE`;

        const reserva = await tx.reserva.findUnique({
          where: { id: reservaId },
          select: RESERVA_PARA_PAGO_SELECT,
        });
        const rechazo = motivoNoPagable(reserva, arrendatarioId);
        if (rechazo) return { rechazo };

        const exitoso = resultado.estado === EstadoPago.SIMULADO_EXITOSO;
        const pago = await tx.pago.create({
          data: {
            reservaId,
            modalidad,
            importeAlquiler: cargos.importeAlquiler,
            importeDeposito: cargos.importeDeposito,
            total: cargos.total,
            estado: resultado.estado,
            fechaHora: ahora,
            comprobanteId: exitoso ? randomUUID() : null,
            referenciaSimulada: resultado.referenciaSimulada,
            ultimosCuatro: resultado.ultimosCuatro,
            motivoRechazo: resultado.motivoRechazo,
          },
        });

        if (exitoso && cargos.importeDeposito.gt(0)) {
          await tx.deposito.create({
            data: {
              reservaId,
              importeOriginal: cargos.importeDeposito,
              estado: EstadoDeposito.PENDIENTE,
            },
          });
        }

        return { pago };
      });
    } catch (error) {
      if (
        error instanceof Prisma.PrismaClientKnownRequestError &&
        error.code === UNIQUE_CONSTRAINT_VIOLATION
      ) {
        return { rechazo: 'PAGO_DUPLICADO' };
      }
      throw error;
    }
  }

  async obtenerDatosNotificacion(pagoId: string) {
    return this.prisma.pago.findUnique({
      where: { id: pagoId },
      select: {
        id: true,
        estado: true,
        total: true,
        reserva: {
          select: {
            arrendatario: {
              select: {
                nombreUsuario: true,
              },
            },
            bien: {
              select: {
                titulo: true,
                arrendadorId: true,
              },
            },
          },
        },
      },
    });
  }
}
