import { Prisma } from '@PrismaClient';
import type { PrismaService } from '@Prisma/services';
import type { ResultadoPasarela } from '@Pagos/utils';
import {
  motivoNoPagable,
  PagoRepository,
  type RegistrarPagoData,
  type ReservaParaPago,
} from './pago.repository.js';

const RESERVA_ID = '11111111-1111-4111-8111-111111111111';
const ARRENDATARIO_ID = '22222222-2222-4222-8222-222222222222';
const AHORA = new Date('2026-12-01T18:00:00.000Z');

const decimal = (valor: string) => new Prisma.Decimal(valor);

function reserva(cambios: Partial<ReservaParaPago> = {}): ReservaParaPago {
  return {
    id: RESERVA_ID,
    arrendatarioId: ARRENDATARIO_ID,
    fechaInicio: new Date('2026-12-10T00:00:00.000Z'),
    fechaFin: new Date('2026-12-12T00:00:00.000Z'),
    estado: 'CONFIRMADA',
    bien: {
      precio: decimal('20'),
      unidadCobro: 'DIA',
      deposito: decimal('25'),
    },
    pagos: [],
    ...cambios,
  };
}

const EXITOSO: ResultadoPasarela = {
  estado: 'SIMULADO_EXITOSO',
  motivoRechazo: null,
  ultimosCuatro: '4242',
  referenciaSimulada: null,
};

const RECHAZADO: ResultadoPasarela = {
  estado: 'SIMULADO_RECHAZADO',
  motivoRechazo: 'Tarjeta rechazada por la pasarela simulada.',
  ultimosCuatro: '0002',
  referenciaSimulada: null,
};

function datos(cambios: Partial<RegistrarPagoData> = {}): RegistrarPagoData {
  return {
    reservaId: RESERVA_ID,
    arrendatarioId: ARRENDATARIO_ID,
    modalidad: 'TARJETA',
    cargos: {
      importeAlquiler: decimal('60.00'),
      importeDeposito: decimal('25.00'),
      total: decimal('85.00'),
    },
    resultado: EXITOSO,
    ahora: AHORA,
    ...cambios,
  };
}

function crear(reservaEnTransaccion: ReservaParaPago | null = reserva()) {
  const tx = {
    $executeRaw: vi.fn().mockResolvedValue(1),
    reserva: { findUnique: vi.fn().mockResolvedValue(reservaEnTransaccion) },
    pago: {
      create: vi.fn(({ data }: { data: object }) =>
        Promise.resolve({ id: 'pago-1', ...data }),
      ),
    },
    deposito: { create: vi.fn().mockResolvedValue({ id: 'deposito-1' }) },
  };
  const prisma = {
    $transaction: vi.fn((callback: (cliente: typeof tx) => unknown) =>
      callback(tx),
    ),
  };
  return {
    repository: new PagoRepository(prisma as unknown as PrismaService),
    prisma,
    tx,
  };
}

describe('motivoNoPagable', () => {
  it('una reserva CONFIRMADA y sin pago exitoso se puede pagar', () => {
    expect(motivoNoPagable(reserva(), ARRENDATARIO_ID)).toBeNull();
  });

  it.each([
    ['no existe', null, 'NO_EXISTE'],
    [
      'es de otro arrendatario',
      reserva({ arrendatarioId: 'otro' }),
      'NO_ES_PROPIETARIO',
    ],
    [
      'ya tiene un pago exitoso',
      reserva({ pagos: [{ id: 'pago-0' }] }),
      'PAGO_DUPLICADO',
    ],
    ['no está CONFIRMADA', reserva({ estado: 'EN_COLA' }), 'NO_PAGABLE'],
  ] as const)('si la reserva %s: %s', (_caso, valor, motivo) => {
    expect(motivoNoPagable(valor, ARRENDATARIO_ID)).toBe(motivo);
  });

  it('no revela el estado de una reserva ajena', () => {
    const ajena = reserva({ arrendatarioId: 'otro', estado: 'CANCELADA' });

    expect(motivoNoPagable(ajena, ARRENDATARIO_ID)).toBe('NO_ES_PROPIETARIO');
  });
});

describe('PagoRepository.registrarPago', () => {
  it('bloquea la reserva antes de volver a validarla', async () => {
    const { repository, tx } = crear();

    await repository.registrarPago(datos());

    const [sql] = tx.$executeRaw.mock.calls[0] as [TemplateStringsArray];
    expect(sql.join('?')).toContain('FOR UPDATE');
    expect(tx.$executeRaw.mock.invocationCallOrder[0]).toBeLessThan(
      tx.reserva.findUnique.mock.invocationCallOrder[0],
    );
  });

  it('guarda el pago exitoso con comprobante y crea el depósito PENDIENTE', async () => {
    const { repository, tx } = crear();

    const resultado = await repository.registrarPago(datos());

    expect(resultado).toMatchObject({ pago: { id: 'pago-1' } });
    const { data } = tx.pago.create.mock.calls[0][0] as {
      data: Record<string, unknown>;
    };
    expect(data).toMatchObject({
      reservaId: RESERVA_ID,
      modalidad: 'TARJETA',
      estado: 'SIMULADO_EXITOSO',
      fechaHora: AHORA,
      ultimosCuatro: '4242',
      motivoRechazo: null,
    });
    expect(data.comprobanteId).toEqual(expect.any(String));
    expect(tx.deposito.create).toHaveBeenCalledWith({
      data: {
        reservaId: RESERVA_ID,
        importeOriginal: decimal('25.00'),
        estado: 'PENDIENTE',
      },
    });
  });

  it('un pago rechazado se guarda sin comprobante y sin depósito', async () => {
    const { repository, tx } = crear();

    await repository.registrarPago(datos({ resultado: RECHAZADO }));

    const { data } = tx.pago.create.mock.calls[0][0] as {
      data: Record<string, unknown>;
    };
    expect(data).toMatchObject({
      estado: 'SIMULADO_RECHAZADO',
      comprobanteId: null,
      motivoRechazo: 'Tarjeta rechazada por la pasarela simulada.',
    });
    expect(tx.deposito.create).not.toHaveBeenCalled();
  });

  it('un pago exitoso sin depósito no crea depósito', async () => {
    const { repository, tx } = crear();
    const sinDeposito = datos({
      cargos: {
        importeAlquiler: decimal('60.00'),
        importeDeposito: decimal('0.00'),
        total: decimal('60.00'),
      },
    });

    await repository.registrarPago(sinDeposito);

    expect(tx.pago.create).toHaveBeenCalled();
    expect(tx.deposito.create).not.toHaveBeenCalled();
  });

  it('si al bloquear ya hay un pago exitoso, no guarda y devuelve PAGO_DUPLICADO', async () => {
    const { repository, tx } = crear(reserva({ pagos: [{ id: 'pago-0' }] }));

    const resultado = await repository.registrarPago(datos());

    expect(resultado).toEqual({ rechazo: 'PAGO_DUPLICADO' });
    expect(tx.pago.create).not.toHaveBeenCalled();
  });

  it('si al bloquear la reserva ya no está CONFIRMADA, devuelve NO_PAGABLE', async () => {
    const { repository } = crear(reserva({ estado: 'CANCELADA' }));

    expect(await repository.registrarPago(datos())).toEqual({
      rechazo: 'NO_PAGABLE',
    });
  });

  it('traduce la violación del índice único (P2002) a PAGO_DUPLICADO', async () => {
    const { repository, prisma } = crear();
    prisma.$transaction.mockRejectedValueOnce(
      new Prisma.PrismaClientKnownRequestError('Unique constraint failed', {
        code: 'P2002',
        clientVersion: 'test',
      }),
    );

    expect(await repository.registrarPago(datos())).toEqual({
      rechazo: 'PAGO_DUPLICADO',
    });
  });

  it('deja pasar cualquier otro error', async () => {
    const { repository, prisma } = crear();
    prisma.$transaction.mockRejectedValueOnce(new Error('se cayó la base'));

    await expect(repository.registrarPago(datos())).rejects.toThrow(
      'se cayó la base',
    );
  });
});

describe('PagoRepository.findComprobante', () => {
  it('busca el pago por id con el arrendatario de su reserva, sin datos de la tarjeta', async () => {
    const findUnique = vi.fn().mockResolvedValue(null);
    const repository = new PagoRepository({
      pago: { findUnique },
    } as unknown as PrismaService);

    await repository.findComprobante('pago-1');

    const [{ where, select }] = findUnique.mock.calls[0] as [
      { where: unknown; select: Record<string, unknown> },
    ];
    expect(where).toEqual({ id: 'pago-1' });
    expect(select.reserva).toEqual({ select: { arrendatarioId: true } });
    expect(select).not.toHaveProperty('ultimosCuatro');
    expect(select).not.toHaveProperty('referenciaSimulada');
  });
});
