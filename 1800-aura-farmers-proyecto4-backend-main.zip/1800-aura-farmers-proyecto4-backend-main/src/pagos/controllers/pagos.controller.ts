import {
  Body,
  Controller,
  Get,
  HttpCode,
  HttpStatus,
  Param,
  ParseUUIDPipe,
  Post,
} from '@nestjs/common';
import {
  ApiBadRequestResponse,
  ApiBearerAuth,
  ApiConflictResponse,
  ApiCreatedResponse,
  ApiForbiddenResponse,
  ApiNotFoundResponse,
  ApiOkResponse,
  ApiOperation,
  ApiTags,
  ApiUnauthorizedResponse,
  ApiUnprocessableEntityResponse,
} from '@nestjs/swagger';
import { CurrentUser, Roles } from '@Auth/decorators';
import type { AuthenticatedUser } from '@Auth/types';
import { Rol } from '@PrismaClient';
import {
  CrearPagoDto,
  PagoResponseDto,
  ResumenPagoResponseDto,
} from '@Pagos/dto';
import { PagosService } from '@Pagos/services';

/**
 * Cobro de una reserva (H8). Comparte la ruta `/reservas` con los
 * controladores de reservas; es del arrendatario dueño de la reserva.
 */
@ApiTags('pagos')
@ApiBearerAuth()
@Roles(Rol.ARRENDATARIO)
@Controller('reservas')
export class PagosController {
  constructor(private readonly pagosService: PagosService) {}

  @Get(':reservaId/resumen-pago')
  @ApiOperation({
    summary: 'Consulta el alquiler, el depósito y el total de una reserva',
  })
  @ApiOkResponse({ type: ResumenPagoResponseDto })
  @ApiBadRequestResponse({ description: 'El id no es un UUID.' })
  @ApiUnauthorizedResponse({
    description: 'Token ausente, inválido o expirado.',
  })
  @ApiForbiddenResponse({
    description: 'El usuario no es ARRENDATARIO o la reserva no es suya.',
  })
  @ApiNotFoundResponse({ description: 'La reserva no existe.' })
  @ApiUnprocessableEntityResponse({
    description:
      'La reserva no es pagable: no está CONFIRMADA o ya tiene un pago exitoso.',
  })
  async resumen(
    @Param('reservaId', ParseUUIDPipe) reservaId: string,
    @CurrentUser() usuario: AuthenticatedUser,
  ): Promise<ResumenPagoResponseDto> {
    const { cargos } = await this.pagosService.resumen(reservaId, usuario.id);
    return ResumenPagoResponseDto.from(reservaId, cargos);
  }

  @Post(':reservaId/pagos')
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({
    summary: 'Simula el pago de una reserva y guarda el resultado',
    description:
      'Responde 201 tanto si la pasarela aprueba como si rechaza: el pago queda registrado. Revisa `estado`.',
  })
  @ApiCreatedResponse({ type: PagoResponseDto })
  @ApiBadRequestResponse({
    description:
      'El id no es un UUID, falta un campo, un campo no tiene el formato, se envió un campo no permitido (como importes o usuario) o la tarjeta está vencida.',
  })
  @ApiUnauthorizedResponse({
    description: 'Token ausente, inválido o expirado.',
  })
  @ApiForbiddenResponse({
    description: 'El usuario no es ARRENDATARIO o la reserva no es suya.',
  })
  @ApiNotFoundResponse({ description: 'La reserva no existe.' })
  @ApiConflictResponse({
    description: 'La reserva ya tiene un pago completado.',
  })
  @ApiUnprocessableEntityResponse({
    description: 'La reserva no está CONFIRMADA.',
  })
  async pagar(
    @Param('reservaId', ParseUUIDPipe) reservaId: string,
    @CurrentUser() usuario: AuthenticatedUser,
    @Body() dto: CrearPagoDto,
  ): Promise<PagoResponseDto> {
    const pago = await this.pagosService.pagar(reservaId, usuario.id, dto);
    return PagoResponseDto.fromEntity(pago);
  }
}
