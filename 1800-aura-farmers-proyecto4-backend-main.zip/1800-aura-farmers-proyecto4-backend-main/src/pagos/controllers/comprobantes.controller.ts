import { Controller, Get, Param, ParseUUIDPipe } from '@nestjs/common';
import {
  ApiBadRequestResponse,
  ApiBearerAuth,
  ApiConflictResponse,
  ApiForbiddenResponse,
  ApiNotFoundResponse,
  ApiOkResponse,
  ApiOperation,
  ApiTags,
  ApiUnauthorizedResponse,
} from '@nestjs/swagger';
import { CurrentUser, Roles } from '@Auth/decorators';
import type { AuthenticatedUser } from '@Auth/types';
import { Rol } from '@PrismaClient';
import { ComprobanteResponseDto } from '@Pagos/dto';
import { PagosService } from '@Pagos/services';

/** Comprobante de un pago (H9), solo para el arrendatario dueño. */
@ApiTags('pagos')
@ApiBearerAuth()
@Roles(Rol.ARRENDATARIO)
@Controller('pagos')
export class ComprobantesController {
  constructor(private readonly pagosService: PagosService) {}

  @Get(':pagoId/comprobante')
  @ApiOperation({ summary: 'Consulta el comprobante de un pago exitoso' })
  @ApiOkResponse({ type: ComprobanteResponseDto })
  @ApiBadRequestResponse({ description: 'El id no es un UUID.' })
  @ApiUnauthorizedResponse({
    description: 'Token ausente, inválido o expirado.',
  })
  @ApiForbiddenResponse({
    description: 'El usuario no es ARRENDATARIO o el pago no es suyo.',
  })
  @ApiNotFoundResponse({ description: 'El pago no existe.' })
  @ApiConflictResponse({
    description: 'El pago no cuenta con un comprobante de éxito.',
  })
  async comprobante(
    @Param('pagoId', ParseUUIDPipe) pagoId: string,
    @CurrentUser() usuario: AuthenticatedUser,
  ): Promise<ComprobanteResponseDto> {
    const comprobante = await this.pagosService.comprobante(pagoId, usuario.id);
    return ComprobanteResponseDto.fromEntity(comprobante);
  }
}
