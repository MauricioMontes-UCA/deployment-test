import {
  BadRequestException,
  ConflictException,
  ForbiddenException,
  NotFoundException,
  UnprocessableEntityException,
} from '@nestjs/common';
import type { ConfigService } from '@nestjs/config';
import { Prisma } from '@PrismaClient';
import type { EnvConfig } from '@Config';
import type {
  PagoComprobante,
  PagoRepository,
  RechazoPago,
  ReservaParaPago,
} from '@Pagos/repositories';
import type { CrearPagoDto } from '@Pagos/dto';
import { PagosService } from './pagos.service.js';
import type { NotificacionesService } from '@Notificaciones/services';

const RESERVA_ID = '11111111-1111-4111-8111-111111111111';
const ARRENDATARIO_ID = '22222222-2222-4222-8222-222222222222';
const AHORA = new Date('2026-11-15T18:00:00.000Z');

const decimal = (valor: string) => new Prisma.Decimal(valor);

function reserva(cambios: Partial<ReservaParaPago> = {}): ReservaParaPago {
  return {
    id: RESERVA_ID,
    arrendatarioId: ARRENDATARIO_ID,
    fechaInicio: new Date('2026-12-10T00:00:00.000Z'),
    fechaFin: new Date('2026-12-12T00:00:00.000Z'),
    estado: 'CONFIRMADA',
    bien: {
      precio: decimal('20.00'),
      unidadCobro: 'DIA',
      deposito: decimal('25.00'),
    },
    pagos: [],
    ...cambios,
  };
}

const conTarjeta = (
  numeroTarjeta = '4242424242424242',
  vencimiento = '12/28',
): CrearPagoDto => ({
  modalidad: 'TARJETA',
  numeroTarjeta,
  vencimiento,
  codigoSeguridad: '123',
});

function crearServicio({
  leida = reserva(),
  pagoLeido = null,
  registro = { pago: { id: 'pago-1' } } as
    { pago: object } | { rechazo: RechazoPago },
  demoraMs = 2000,
}: {
  leida?: ReservaParaPago | null;
  registro?: { pago: object } | { rechazo: RechazoPago };
  demoraMs?: number;
  pagoLeido?: PagoComprobante | null;
} = {}) {
  const repository = {
    findComprobante: vi.fn().mockResolvedValue(pagoLeido),
    findReservaParaPago: vi.fn().mockResolvedValue(leida),
    registrarPago: vi.fn().mockResolvedValue(registro),
    obtenerDatosNotificacion: vi.fn().mockResolvedValue(null),
  };
  const config = { get: vi.fn().mockReturnValue(demoraMs) };
  const notificaciones = {
    crear: vi.fn().mockResolvedValue({
      creada: true,
      notificacionId: 'aviso-prueba',
    }),
  };
  const service = new PagosService(
    repository as unknown as PagoRepository,
    config as unknown as ConfigService<EnvConfig, true>,
    notificaciones as unknown as NotificacionesService,
  );
  const esperar = vi.fn().mockResolvedValue(undefined);
  service.esperar = esperar;
  return { service, repository, esperar, notificaciones };
}

describe('PagosService.resumen', () => {
  it('calcula el cobro en el servidor con los datos de la reserva y el bien', async () => {
    const { service } = crearServicio();

    const { reservaId, cargos } = await service.resumen(
      RESERVA_ID,
      ARRENDATARIO_ID,
    );

    expect(reservaId).toBe(RESERVA_ID);
    expect(cargos.importeAlquiler.toFixed(2)).toBe('60.00');
    expect(cargos.importeDeposito.toFixed(2)).toBe('25.00');
    expect(cargos.total.toFixed(2)).toBe('85.00');
  });

  it.each([
    ['no existe', null, NotFoundException],
    ['es ajena', reserva({ arrendatarioId: 'otro' }), ForbiddenException],
    [
      'no está CONFIRMADA',
      reserva({ estado: 'EN_COLA' }),
      UnprocessableEntityException,
    ],
    [
      'ya está pagada',
      reserva({ pagos: [{ id: 'pago-0' }] }),
      UnprocessableEntityException,
    ],
  ])('si la reserva %s lanza %O', async (_caso, leida, Excepcion) => {
    const { service } = crearServicio({ leida });

    await expect(service.resumen(RESERVA_ID, ARRENDATARIO_ID)).rejects.toThrow(
      Excepcion,
    );
  });
});

describe('PagosService.pagar', () => {
  it('simula, espera la demora de la pasarela y guarda con los importes del servidor', async () => {
    const { service, repository, esperar } = crearServicio();

    const pago = await service.pagar(
      RESERVA_ID,
      ARRENDATARIO_ID,
      conTarjeta(),
      AHORA,
    );

    expect(pago).toEqual({ id: 'pago-1' });
    expect(esperar).toHaveBeenCalledWith(2000);
    expect(esperar.mock.invocationCallOrder[0]).toBeLessThan(
      repository.registrarPago.mock.invocationCallOrder[0],
    );
    const [datos] = repository.registrarPago.mock.calls[0];
    expect(datos).toMatchObject({
      reservaId: RESERVA_ID,
      arrendatarioId: ARRENDATARIO_ID,
      modalidad: 'TARJETA',
      ahora: AHORA,
      resultado: { estado: 'SIMULADO_EXITOSO', ultimosCuatro: '4242' },
    });
    expect(datos.cargos.total.toFixed(2)).toBe('85.00');
  });

  it('nunca pasa el número completo ni el CVV al repositorio', async () => {
    const { service, repository } = crearServicio();

    await service.pagar(RESERVA_ID, ARRENDATARIO_ID, conTarjeta(), AHORA);

    const enviado = JSON.stringify(repository.registrarPago.mock.calls[0][0]);
    expect(enviado).not.toContain('4242424242424242');
    expect(enviado).not.toContain('"123"');
  });

  it('un rechazo de la pasarela también se guarda', async () => {
    const { service, repository } = crearServicio();

    await service.pagar(
      RESERVA_ID,
      ARRENDATARIO_ID,
      conTarjeta('4000000000000002'),
      AHORA,
    );

    expect(repository.registrarPago.mock.calls[0][0].resultado).toMatchObject({
      estado: 'SIMULADO_RECHAZADO',
      motivoRechazo: 'Tarjeta rechazada por la pasarela simulada.',
    });
  });

  it('con demora 0 no espera', async () => {
    const { service, esperar } = crearServicio({ demoraMs: 0 });

    await service.pagar(RESERVA_ID, ARRENDATARIO_ID, conTarjeta(), AHORA);

    expect(esperar).not.toHaveBeenCalled();
  });

  it('rechaza una tarjeta vencida con 400 sin leer la reserva', async () => {
    const { service, repository } = crearServicio();
    const vencida = conTarjeta('4242424242424242', '10/26');

    await expect(
      service.pagar(RESERVA_ID, ARRENDATARIO_ID, vencida, AHORA),
    ).rejects.toThrow(BadRequestException);
    expect(repository.findReservaParaPago).not.toHaveBeenCalled();
  });

  it.each([
    ['no existe', null, NotFoundException],
    ['es ajena', reserva({ arrendatarioId: 'otro' }), ForbiddenException],
    [
      'ya está pagada',
      reserva({ pagos: [{ id: 'pago-0' }] }),
      ConflictException,
    ],
    [
      'no está CONFIRMADA',
      reserva({ estado: 'FINALIZADA' }),
      UnprocessableEntityException,
    ],
  ])(
    'si la reserva %s lanza %O sin esperar ni guardar',
    async (_caso, leida, Excepcion) => {
      const { service, repository, esperar } = crearServicio({ leida });

      await expect(
        service.pagar(RESERVA_ID, ARRENDATARIO_ID, conTarjeta(), AHORA),
      ).rejects.toThrow(Excepcion);
      expect(esperar).not.toHaveBeenCalled();
      expect(repository.registrarPago).not.toHaveBeenCalled();
    },
  );

  it.each([
    [
      'PAGO_DUPLICADO',
      ConflictException,
      'Esta reserva ya tiene un pago completado.',
    ],
    [
      'NO_PAGABLE',
      UnprocessableEntityException,
      'La reserva no se puede pagar porque no está confirmada.',
    ],
  ] as const)(
    'traduce el rechazo %s del repositorio',
    async (rechazo, Excepcion, mensaje) => {
      const { service } = crearServicio({ registro: { rechazo } });

      const intento = service.pagar(
        RESERVA_ID,
        ARRENDATARIO_ID,
        conTarjeta(),
        AHORA,
      );

      await expect(intento).rejects.toThrow(Excepcion);
      await expect(intento).rejects.toThrow(mensaje);
    },
  );
});

describe('PagosService.comprobante', () => {
  const PAGO_ID = '33333333-3333-4333-8333-333333333333';
  const COMPROBANTE_ID = '44444444-4444-4444-8444-444444444444';

  function pago(cambios: Partial<PagoComprobante> = {}): PagoComprobante {
    return {
      id: PAGO_ID,
      reservaId: RESERVA_ID,
      fechaHora: AHORA,
      importeAlquiler: decimal('60.00'),
      importeDeposito: decimal('25.00'),
      total: decimal('85.00'),
      modalidad: 'TARJETA',
      estado: 'SIMULADO_EXITOSO',
      comprobanteId: COMPROBANTE_ID,
      reserva: { arrendatarioId: ARRENDATARIO_ID },
      ...cambios,
    };
  }

  it('devuelve el pago exitoso tal como está guardado', async () => {
    const guardado = pago();
    const { service, repository } = crearServicio({ pagoLeido: guardado });

    const comprobante = await service.comprobante(PAGO_ID, ARRENDATARIO_ID);

    expect(repository.findComprobante).toHaveBeenCalledWith(PAGO_ID);
    expect(comprobante).toBe(guardado);
  });

  it('404 si el pago no existe', async () => {
    const { service } = crearServicio({ pagoLeido: null });

    await expect(service.comprobante(PAGO_ID, ARRENDATARIO_ID)).rejects.toThrow(
      new NotFoundException('El pago no existe.'),
    );
  });

  it('403 si el pago es de otro arrendatario, aunque haya sido rechazado', async () => {
    const ajeno = pago({
      estado: 'SIMULADO_RECHAZADO',
      comprobanteId: null,
      reserva: { arrendatarioId: 'otro' },
    });
    const { service } = crearServicio({ pagoLeido: ajeno });

    await expect(service.comprobante(PAGO_ID, ARRENDATARIO_ID)).rejects.toThrow(
      ForbiddenException,
    );
  });

  it.each(['SIMULADO_RECHAZADO', 'PENDIENTE'] as const)(
    '409 si el pago está %s',
    async (estado) => {
      const { service } = crearServicio({
        pagoLeido: pago({ estado, comprobanteId: null }),
      });

      await expect(
        service.comprobante(PAGO_ID, ARRENDATARIO_ID),
      ).rejects.toThrow(
        new ConflictException('El pago no cuenta con un comprobante de éxito.'),
      );
    },
  );
});
