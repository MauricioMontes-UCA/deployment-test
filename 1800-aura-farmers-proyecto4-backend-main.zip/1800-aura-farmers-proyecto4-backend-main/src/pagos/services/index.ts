export * from './pagos.service.js';
