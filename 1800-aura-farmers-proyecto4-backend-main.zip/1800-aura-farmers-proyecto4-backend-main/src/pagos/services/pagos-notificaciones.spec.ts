import { describe, expect, it, vi } from 'vitest';
import type { ConfigService } from '@nestjs/config';
import { EstadoPago, ModuloOrigen, Prisma } from '@PrismaClient';
import type { EnvConfig } from '@Config';
import type { PagoRepository } from '@Pagos/repositories';
import type { NotificacionesService } from '@Notificaciones/services';
import { PagosService } from './pagos.service.js';

const PAGO_ID = '11111111-1111-4111-8111-111111111111';
const RESERVA_ID = '22222222-2222-4222-8222-222222222222';
const ARRENDADOR_ID = '33333333-3333-4333-8333-333333333333';
const ARRENDATARIO_ID = '44444444-4444-4444-8444-444444444444';

function escenario(estado: EstadoPago = EstadoPago.SIMULADO_EXITOSO) {
  const pago = {
    id: PAGO_ID,
    estado,
  };

  const repository = {
    findReservaParaPago: vi.fn().mockResolvedValue({
      id: RESERVA_ID,
      arrendatarioId: ARRENDATARIO_ID,
      fechaInicio: new Date('2027-01-10T00:00:00Z'),
      fechaFin: new Date('2027-01-12T00:00:00Z'),
      estado: 'CONFIRMADA',
      bien: {
        precio: new Prisma.Decimal('25'),
        unidadCobro: 'DIA',
        deposito: new Prisma.Decimal('50'),
      },
      pagos: [],
    }),
    registrarPago: vi.fn().mockResolvedValue({
      pago,
    }),
    obtenerDatosNotificacion: vi.fn().mockResolvedValue({
      id: PAGO_ID,
      estado,
      total: new Prisma.Decimal('125'),
      reserva: {
        arrendatario: {
          nombreUsuario: 'carlos23',
        },
        bien: {
          titulo: 'Cámara Sony',
          arrendadorId: ARRENDADOR_ID,
        },
      },
    }),
  };

  const notificaciones = {
    crear: vi.fn().mockResolvedValue({
      creada: true,
      notificacionId: 'aviso-prueba',
    }),
  };

  const config = {
    get: vi.fn().mockReturnValue(0),
  };

  const service = new PagosService(
    repository as unknown as PagoRepository,
    config as unknown as ConfigService<EnvConfig, true>,
    notificaciones as unknown as NotificacionesService,
  );

  return { service, repository, notificaciones };
}

const dto = {
  modalidad: 'TARJETA' as const,
  numeroTarjeta: '4242424242424242',
  vencimiento: '12/30',
  codigoSeguridad: '123',
};

describe('BE-22.2 - Notificaciones de pagos', () => {
  it('notifica al arrendador con el total 125.00', async () => {
    const { service, notificaciones } = escenario();

    await service.pagar(
      RESERVA_ID,
      ARRENDATARIO_ID,
      dto,
      new Date('2026-11-15T12:00:00Z'),
    );

    expect(notificaciones.crear).toHaveBeenCalledWith(
      ARRENDADOR_ID,
      'Pago recibido',
      'Se aprobó el pago de $125.00 de carlos23 por Cámara Sony.',
      ModuloOrigen.PAGOS,
      {
        tipoReferencia: 'PAGO_APROBADO',
        referenciaId: PAGO_ID,
      },
    );
  });

  it('no notifica un pago rechazado', async () => {
    const { service, notificaciones } = escenario(
      EstadoPago.SIMULADO_RECHAZADO,
    );

    await service.pagar(
      RESERVA_ID,
      ARRENDATARIO_ID,
      dto,
      new Date('2026-11-15T12:00:00Z'),
    );

    expect(notificaciones.crear).not.toHaveBeenCalled();
  });

  it('un error de notificaciones no revierte el pago', async () => {
    const { service, notificaciones } = escenario();

    notificaciones.crear.mockRejectedValue(new Error('Fallo simulado'));

    const pago = await service.pagar(
      RESERVA_ID,
      ARRENDATARIO_ID,
      dto,
      new Date('2026-11-15T12:00:00Z'),
    );

    expect(pago.estado).toBe(EstadoPago.SIMULADO_EXITOSO);
  });

  it('usa la misma referencia si se procesa nuevamente', async () => {
    const { service, notificaciones } = escenario();

    await service.pagar(
      RESERVA_ID,
      ARRENDATARIO_ID,
      dto,
      new Date('2026-11-15T12:00:00Z'),
    );

    await service.pagar(
      RESERVA_ID,
      ARRENDATARIO_ID,
      dto,
      new Date('2026-11-15T12:00:00Z'),
    );

    expect(notificaciones.crear.mock.calls[0]?.[4]).toEqual(
      notificaciones.crear.mock.calls[1]?.[4],
    );
  });
});
