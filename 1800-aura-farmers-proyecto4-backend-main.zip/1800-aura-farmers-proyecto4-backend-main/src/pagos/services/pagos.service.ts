import {
  BadRequestException,
  ConflictException,
  ForbiddenException,
  Injectable,
  NotFoundException,
  UnprocessableEntityException,
  Logger,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { hoyEn, ZONA_HORARIA } from '@Bienes/utils';
import type { EnvConfig } from '@Config';
import {
  motivoNoPagable,
  PagoRepository,
  type PagoComprobante,
  type RechazoPago,
  type ReservaParaPago,
} from '@Pagos/repositories';
import {
  calcularCargos,
  simularPasarela,
  tarjetaVencida,
  type Cargos,
  mensajePagoAprobado,
  REFERENCIA_PAGO_APROBADO,
  TITULO_PAGO_APROBADO,
} from '@Pagos/utils';
import type { CrearPagoDto } from '@Pagos/dto';
import {
  EstadoPago,
  ModalidadPago,
  type Pago,
  ModuloOrigen,
} from '@PrismaClient';
import { NotificacionesService } from '@Notificaciones/services';

type ExcepcionHttp = new (mensaje: string) => Error;

const MENSAJES: Record<RechazoPago, string> = {
  NO_EXISTE: 'La reserva no existe.',
  NO_ES_PROPIETARIO: 'No tienes permiso para pagar esta reserva.',
  PAGO_DUPLICADO: 'Esta reserva ya tiene un pago completado.',
  NO_PAGABLE: 'La reserva no se puede pagar porque no está confirmada.',
};

/** Al pagar, un segundo pago exitoso es un conflicto (409). */
const RECHAZOS_PAGO: Record<RechazoPago, ExcepcionHttp> = {
  NO_EXISTE: NotFoundException,
  NO_ES_PROPIETARIO: ForbiddenException,
  PAGO_DUPLICADO: ConflictException,
  NO_PAGABLE: UnprocessableEntityException,
};

/** Al consultar el resumen, una reserva ya pagada simplemente no es pagable. */
const RECHAZOS_RESUMEN: Record<RechazoPago, ExcepcionHttp> = {
  ...RECHAZOS_PAGO,
  PAGO_DUPLICADO: UnprocessableEntityException,
};

const esperarMs = (ms: number) =>
  new Promise<void>((resolve) => setTimeout(resolve, ms));

/** Comprobante de un pago exitoso: siempre tiene `comprobanteId`. */
export type Comprobante = PagoComprobante & { comprobanteId: string };

/** Resumen del cobro de una reserva pagable. */
export interface ResumenPago {
  reservaId: string;
  cargos: Cargos;
}

/**
 * Consulta de cargos y pago simulado de una reserva (H8), y comprobante de un
 * pago exitoso (H9).
 *
 * No conoce Prisma: el acceso a datos pasa por `PagoRepository`.
 */
@Injectable()
export class PagosService {
  private readonly demoraMs: number;

  /** Espera de la pasarela. Es un campo para poder reemplazarla en pruebas. */
  esperar: (ms: number) => Promise<void> = esperarMs;

  private readonly logger = new Logger(PagosService.name);

  constructor(
    private readonly pagoRepository: PagoRepository,
    configService: ConfigService<EnvConfig, true>,
    private readonly notificacionesService: NotificacionesService,
  ) {
    this.demoraMs = configService.get('PAGO_SIMULADO_DEMORA_MS', {
      infer: true,
    });
  }

  /**
   * Alquiler, depósito y total de una reserva pagable, calculados en el
   * servidor con los datos persistidos de la reserva y su bien.
   *
   * @param arrendatarioId viene del usuario autenticado.
   * @throws {NotFoundException} la reserva no existe.
   * @throws {ForbiddenException} la reserva es de otro arrendatario.
   * @throws {UnprocessableEntityException} la reserva no está CONFIRMADA o ya
   * tiene un pago exitoso.
   */
  async resumen(
    reservaId: string,
    arrendatarioId: string,
  ): Promise<ResumenPago> {
    const reserva = await this.reservaPagable(
      reservaId,
      arrendatarioId,
      RECHAZOS_RESUMEN,
    );
    return { reservaId, cargos: this.cargosDe(reserva) };
  }

  /**
   * Simula el pago de una reserva y guarda el resultado, aprobado o rechazado.
   *
   * Primero valida sin bloquear, para no hacer esperar la demora de la
   * pasarela a quien no puede pagar. La demora corre antes de abrir la
   * transacción, para no tener la reserva bloqueada mientras tanto. El
   * repositorio vuelve a validar con la reserva bloqueada.
   *
   * @param arrendatarioId viene del usuario autenticado, nunca del cuerpo.
   * @throws {BadRequestException} la tarjeta está vencida.
   * @throws {NotFoundException} la reserva no existe.
   * @throws {ForbiddenException} la reserva es de otro arrendatario.
   * @throws {ConflictException} la reserva ya tiene un pago exitoso, también si
   * llegan dos pagos a la vez.
   * @throws {UnprocessableEntityException} la reserva no está CONFIRMADA.
   *
   * `ahora` se recibe para poder probar el vencimiento; también es la
   * `fechaHora` con que se guarda el pago.
   */
  async pagar(
    reservaId: string,
    arrendatarioId: string,
    dto: CrearPagoDto,
    ahora: Date = new Date(),
  ): Promise<Pago> {
    if (
      dto.modalidad === ModalidadPago.TARJETA &&
      dto.vencimiento &&
      tarjetaVencida(dto.vencimiento, hoyEn(ZONA_HORARIA, ahora))
    ) {
      throw new BadRequestException('La tarjeta está vencida.');
    }

    const reserva = await this.reservaPagable(
      reservaId,
      arrendatarioId,
      RECHAZOS_PAGO,
    );
    const cargos = this.cargosDe(reserva);
    const resultado = simularPasarela(dto);

    if (this.demoraMs > 0) await this.esperar(this.demoraMs);

    const registro = await this.pagoRepository.registrarPago({
      reservaId,
      arrendatarioId,
      modalidad: dto.modalidad,
      cargos,
      resultado,
      ahora,
    });
    if ('rechazo' in registro) {
      throw new RECHAZOS_PAGO[registro.rechazo](MENSAJES[registro.rechazo]);
    }

    if (registro.pago.estado === EstadoPago.SIMULADO_EXITOSO) {
      try {
        await this.notificarPagoAprobado(registro.pago.id);
      } catch (error) {
        this.logger.error(
          `Error al notificar el pago ${registro.pago.id}.`,
          error instanceof Error ? error.stack : String(error),
        );
      }
    }

    return registro.pago;
  }

  /**
   * Comprobante de un pago exitoso, leído tal como quedó guardado.
   *
   * @param arrendatarioId viene del usuario autenticado.
   * @throws {NotFoundException} el pago no existe.
   * @throws {ForbiddenException} el pago es de una reserva de otro
   * arrendatario. No se revela ningún dato del pago.
   * @throws {ConflictException} el pago no es SIMULADO_EXITOSO.
   */
  async comprobante(
    pagoId: string,
    arrendatarioId: string,
  ): Promise<Comprobante> {
    const pago = await this.pagoRepository.findComprobante(pagoId);
    if (!pago) throw new NotFoundException('El pago no existe.');
    if (pago.reserva.arrendatarioId !== arrendatarioId) {
      throw new ForbiddenException(
        'No tienes permiso para consultar este pago.',
      );
    }
    if (pago.estado !== EstadoPago.SIMULADO_EXITOSO || !pago.comprobanteId) {
      throw new ConflictException(
        'El pago no cuenta con un comprobante de éxito.',
      );
    }
    return pago as Comprobante;
  }

  private async notificarPagoAprobado(pagoId: string): Promise<void> {
    const pago = await this.pagoRepository.obtenerDatosNotificacion(pagoId);

    if (!pago || pago.estado !== EstadoPago.SIMULADO_EXITOSO) {
      return;
    }

    const mensaje = mensajePagoAprobado(
      pago.total,
      pago.reserva.arrendatario.nombreUsuario,
      pago.reserva.bien.titulo,
    );

    await this.notificacionesService.crear(
      pago.reserva.bien.arrendadorId,
      TITULO_PAGO_APROBADO,
      mensaje,
      ModuloOrigen.PAGOS,
      {
        tipoReferencia: REFERENCIA_PAGO_APROBADO,
        referenciaId: pago.id,
      },
    );
  }

  private async reservaPagable(
    reservaId: string,
    arrendatarioId: string,
    rechazos: Record<RechazoPago, ExcepcionHttp>,
  ): Promise<ReservaParaPago> {
    const reserva = await this.pagoRepository.findReservaParaPago(reservaId);
    const rechazo = motivoNoPagable(reserva, arrendatarioId);
    if (rechazo) throw new rechazos[rechazo](MENSAJES[rechazo]);
    return reserva as ReservaParaPago;
  }

  private cargosDe(reserva: ReservaParaPago): Cargos {
    return calcularCargos({
      fechaInicio: reserva.fechaInicio,
      fechaFin: reserva.fechaFin,
      precio: reserva.bien.precio,
      unidadCobro: reserva.bien.unidadCobro,
      deposito: reserva.bien.deposito,
    });
  }
}
