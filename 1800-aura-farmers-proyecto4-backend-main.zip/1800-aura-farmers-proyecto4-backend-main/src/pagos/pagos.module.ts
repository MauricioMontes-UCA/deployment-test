import { Module } from '@nestjs/common';
import { NotificacionesModule } from '@Notificaciones';
import { ComprobantesController, PagosController } from '@Pagos/controllers';
import { PagosService } from '@Pagos/services';
import { PagoRepository } from '@Pagos/repositories';

@Module({
  imports: [NotificacionesModule],
  controllers: [PagosController, ComprobantesController],
  providers: [PagosService, PagoRepository],
  exports: [PagosService],
})
export class PagosModule {}
