import { Prisma } from '@PrismaClient';
import type { Comprobante } from '@Pagos/services';
import { ComprobanteResponseDto } from './comprobante-response.dto.js';

describe('ComprobanteResponseDto.fromEntity', () => {
  it('expone los datos guardados del pago, con importes como número', () => {
    const comprobante: Comprobante = {
      id: '33333333-3333-4333-8333-333333333333',
      reservaId: '11111111-1111-4111-8111-111111111111',
      fechaHora: new Date('2026-11-15T20:30:00.000Z'),
      importeAlquiler: new Prisma.Decimal('60.00'),
      importeDeposito: new Prisma.Decimal('25.50'),
      total: new Prisma.Decimal('85.50'),
      modalidad: 'TRANSFERENCIA_BANCARIA',
      estado: 'SIMULADO_EXITOSO',
      comprobanteId: '44444444-4444-4444-8444-444444444444',
      reserva: { arrendatarioId: '22222222-2222-4222-8222-222222222222' },
    };

    expect(ComprobanteResponseDto.fromEntity(comprobante)).toEqual({
      pagoId: '33333333-3333-4333-8333-333333333333',
      comprobanteId: '44444444-4444-4444-8444-444444444444',
      reservaId: '11111111-1111-4111-8111-111111111111',
      fechaHora: '2026-11-15T20:30:00.000Z',
      importeAlquiler: 60,
      importeDeposito: 25.5,
      total: 85.5,
      modalidad: 'TRANSFERENCIA_BANCARIA',
      estado: 'SIMULADO_EXITOSO',
    });
  });

  it('no incluye el arrendatario de la reserva', () => {
    const dto = ComprobanteResponseDto.fromEntity({
      id: 'p',
      reservaId: 'r',
      fechaHora: new Date(0),
      importeAlquiler: new Prisma.Decimal(1),
      importeDeposito: new Prisma.Decimal(0),
      total: new Prisma.Decimal(1),
      modalidad: 'TARJETA',
      estado: 'SIMULADO_EXITOSO',
      comprobanteId: 'c',
      reserva: { arrendatarioId: 'secreto' },
    });

    expect(JSON.stringify(dto)).not.toContain('secreto');
  });
});
