import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { EstadoPago, ModalidadPago, type Pago } from '@PrismaClient';

/** Respuesta de `POST /reservas/:reservaId/pagos`. */
export class PagoResponseDto {
  @ApiProperty({ format: 'uuid' })
  pagoId!: string;

  @ApiProperty({ format: 'uuid' })
  reservaId!: string;

  @ApiProperty({ type: String, format: 'date-time' })
  fechaHora!: string;

  @ApiProperty({ example: 150 })
  importeAlquiler!: number;

  @ApiProperty({ example: 25 })
  importeDeposito!: number;

  @ApiProperty({ example: 175 })
  total!: number;

  @ApiProperty({ enum: ModalidadPago, enumName: 'ModalidadPago' })
  modalidad!: ModalidadPago;

  @ApiProperty({
    enum: [EstadoPago.SIMULADO_EXITOSO, EstadoPago.SIMULADO_RECHAZADO],
    enumName: 'EstadoPago',
  })
  estado!: EstadoPago;

  @ApiPropertyOptional({
    example: 'Tarjeta rechazada por la pasarela simulada.',
    description: 'Solo si el pago fue rechazado.',
  })
  motivoRechazo?: string;

  @ApiPropertyOptional({
    format: 'uuid',
    description: 'Solo si el pago fue aprobado.',
  })
  comprobanteId?: string;

  static fromEntity(pago: Pago): PagoResponseDto {
    return {
      pagoId: pago.id,
      reservaId: pago.reservaId,
      fechaHora: pago.fechaHora.toISOString(),
      importeAlquiler: pago.importeAlquiler.toNumber(),
      importeDeposito: pago.importeDeposito.toNumber(),
      total: pago.total.toNumber(),
      modalidad: pago.modalidad,
      estado: pago.estado,
      ...(pago.motivoRechazo ? { motivoRechazo: pago.motivoRechazo } : {}),
      ...(pago.comprobanteId ? { comprobanteId: pago.comprobanteId } : {}),
    };
  }
}
