import { ApiProperty } from '@nestjs/swagger';
import { EstadoPago, ModalidadPago } from '@PrismaClient';
import type { Comprobante } from '@Pagos/services';

/** Respuesta de `GET /pagos/:pagoId/comprobante`. */
export class ComprobanteResponseDto {
  @ApiProperty({ format: 'uuid' })
  pagoId!: string;

  @ApiProperty({ format: 'uuid' })
  comprobanteId!: string;

  @ApiProperty({ format: 'uuid' })
  reservaId!: string;

  @ApiProperty({ type: String, format: 'date-time' })
  fechaHora!: string;

  @ApiProperty({ example: 240, description: 'Alquiler, en USD.' })
  importeAlquiler!: number;

  @ApiProperty({ example: 0, description: 'Depósito de garantía, en USD.' })
  importeDeposito!: number;

  @ApiProperty({ example: 240, description: 'Alquiler más depósito, en USD.' })
  total!: number;

  @ApiProperty({ enum: ModalidadPago, enumName: 'ModalidadPago' })
  modalidad!: ModalidadPago;

  @ApiProperty({
    enum: [EstadoPago.SIMULADO_EXITOSO],
    description: 'Solo un pago exitoso tiene comprobante.',
  })
  estado!: typeof EstadoPago.SIMULADO_EXITOSO;

  static fromEntity(comprobante: Comprobante): ComprobanteResponseDto {
    return {
      pagoId: comprobante.id,
      comprobanteId: comprobante.comprobanteId,
      reservaId: comprobante.reservaId,
      fechaHora: comprobante.fechaHora.toISOString(),
      // Prisma devuelve DECIMAL como Decimal; la API lo expone como número.
      importeAlquiler: comprobante.importeAlquiler.toNumber(),
      importeDeposito: comprobante.importeDeposito.toNumber(),
      total: comprobante.total.toNumber(),
      modalidad: comprobante.modalidad,
      estado: EstadoPago.SIMULADO_EXITOSO,
    };
  }
}
