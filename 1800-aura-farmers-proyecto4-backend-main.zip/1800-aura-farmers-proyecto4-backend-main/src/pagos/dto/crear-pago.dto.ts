import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsEnum, IsString, Matches, ValidateIf } from 'class-validator';
import { ModalidadPago } from '@PrismaClient';

const esTarjeta = (dto: CrearPagoDto) =>
  dto.modalidad === ModalidadPago.TARJETA;
const esTransferencia = (dto: CrearPagoDto) =>
  dto.modalidad === ModalidadPago.TRANSFERENCIA_BANCARIA;

/**
 * Cuerpo de `POST /reservas/:reservaId/pagos`.
 *
 * No lleva importes ni usuario: los importes se calculan en el servidor y el
 * arrendatario sale del token. El `ValidationPipe` global rechaza con 400
 * cualquier campo que no esté aquí.
 *
 * El número de tarjeta y el CVV solo se usan para simular el cobro: nunca se
 * guardan. De la tarjeta se guardan los últimos cuatro dígitos.
 */
export class CrearPagoDto {
  @ApiProperty({
    enum: ModalidadPago,
    enumName: 'ModalidadPago',
    example: ModalidadPago.TARJETA,
  })
  @IsEnum(ModalidadPago, {
    message: 'La modalidad debe ser TARJETA o TRANSFERENCIA_BANCARIA.',
  })
  modalidad!: ModalidadPago;

  @ApiPropertyOptional({
    example: '4242424242424242',
    description:
      'Obligatorio con TARJETA. De 12 a 19 dígitos, sin espacios. Terminada en 4242 se aprueba; en 0002 se rechaza.',
  })
  @ValidateIf(esTarjeta)
  @IsString({ message: 'El número de tarjeta debe ser texto.' })
  @Matches(/^\d{12,19}$/, {
    message:
      'El número de tarjeta debe tener de 12 a 19 dígitos, sin espacios.',
  })
  numeroTarjeta?: string;

  @ApiPropertyOptional({
    example: '12/28',
    description: 'Obligatorio con TARJETA. Formato MM/AA y no vencido.',
  })
  @ValidateIf(esTarjeta)
  @IsString({ message: 'El vencimiento debe ser texto.' })
  @Matches(/^(0[1-9]|1[0-2])\/\d{2}$/, {
    message: 'El vencimiento debe tener el formato MM/AA.',
  })
  vencimiento?: string;

  @ApiPropertyOptional({
    example: '123',
    description: 'Obligatorio con TARJETA. De 3 o 4 dígitos.',
  })
  @ValidateIf(esTarjeta)
  @IsString({ message: 'El código de seguridad debe ser texto.' })
  @Matches(/^\d{3,4}$/, {
    message: 'El código de seguridad debe tener 3 o 4 dígitos.',
  })
  codigoSeguridad?: string;

  @ApiPropertyOptional({
    example: 'SIM-APRUEBA',
    description:
      'Obligatoria con TRANSFERENCIA_BANCARIA. De 6 a 20 letras, números o guiones. SIM-APRUEBA se aprueba.',
  })
  @ValidateIf(esTransferencia)
  @IsString({ message: 'La referencia debe ser texto.' })
  @Matches(/^[A-Za-z0-9-]{6,20}$/, {
    message:
      'La referencia debe tener de 6 a 20 caracteres: letras, números o guiones.',
  })
  referenciaSimulada?: string;
}
