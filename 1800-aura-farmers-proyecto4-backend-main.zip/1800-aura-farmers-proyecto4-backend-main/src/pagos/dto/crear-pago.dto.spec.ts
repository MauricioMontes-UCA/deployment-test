import { plainToInstance } from 'class-transformer';
import { validate } from 'class-validator';
import { CrearPagoDto } from './crear-pago.dto.js';

const conTarjeta = {
  modalidad: 'TARJETA',
  numeroTarjeta: '4242424242424242',
  vencimiento: '12/28',
  codigoSeguridad: '123',
};

const conTransferencia = {
  modalidad: 'TRANSFERENCIA_BANCARIA',
  referenciaSimulada: 'SIM-APRUEBA',
};

async function campos(cuerpo: Record<string, unknown>) {
  const result = await validate(plainToInstance(CrearPagoDto, cuerpo));
  return result.map((e) => e.property);
}

describe('CrearPagoDto', () => {
  it('acepta un pago con tarjeta completo', async () => {
    expect(await campos(conTarjeta)).toEqual([]);
  });

  it('acepta una transferencia sin datos de tarjeta', async () => {
    expect(await campos(conTransferencia)).toEqual([]);
  });

  it('con transferencia no exige los datos de tarjeta', async () => {
    expect(
      await campos({ ...conTransferencia, numeroTarjeta: undefined }),
    ).toEqual([]);
  });

  it('rechaza una modalidad fuera del catálogo', async () => {
    expect(
      await campos({ ...conTransferencia, modalidad: 'EFECTIVO' }),
    ).toEqual(['modalidad']);
  });

  it('con tarjeta exige número, vencimiento y código', async () => {
    expect(await campos({ modalidad: 'TARJETA' })).toEqual([
      'numeroTarjeta',
      'vencimiento',
      'codigoSeguridad',
    ]);
  });

  it('con transferencia exige la referencia', async () => {
    expect(await campos({ modalidad: 'TRANSFERENCIA_BANCARIA' })).toEqual([
      'referenciaSimulada',
    ]);
  });

  it.each([
    ['con espacios', '4242 4242 4242 4242'],
    ['corto', '42424242'],
    ['con letras', '4242abcd42424242'],
  ])('rechaza un número de tarjeta %s', async (_caso, numeroTarjeta) => {
    expect(await campos({ ...conTarjeta, numeroTarjeta })).toEqual([
      'numeroTarjeta',
    ]);
  });

  it.each(['13/28', '1/28', '12/2028', '12-28'])(
    'rechaza el vencimiento %s',
    async (vencimiento) => {
      expect(await campos({ ...conTarjeta, vencimiento })).toEqual([
        'vencimiento',
      ]);
    },
  );

  it.each(['12', '12345', 'abc'])(
    'rechaza el código de seguridad %s',
    async (codigoSeguridad) => {
      expect(await campos({ ...conTarjeta, codigoSeguridad })).toEqual([
        'codigoSeguridad',
      ]);
    },
  );

  it.each(['SIM', 'REF_123456', 'A'.repeat(21), 'REF 12345'])(
    'rechaza la referencia %s',
    async (referenciaSimulada) => {
      expect(await campos({ ...conTransferencia, referenciaSimulada })).toEqual(
        ['referenciaSimulada'],
      );
    },
  );
});
