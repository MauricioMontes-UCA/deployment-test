import { ApiProperty } from '@nestjs/swagger';
import type { Cargos } from '@Pagos/utils';

/** Respuesta de `GET /reservas/:reservaId/resumen-pago`. */
export class ResumenPagoResponseDto {
  @ApiProperty({ format: 'uuid' })
  reservaId!: string;

  @ApiProperty({ example: 150, description: 'Alquiler, en USD.' })
  importeAlquiler!: number;

  @ApiProperty({
    example: 25,
    description: 'Depósito de garantía, en USD. 0 si el bien no lo pide.',
  })
  importeDeposito!: number;

  @ApiProperty({ example: 175, description: 'Alquiler más depósito, en USD.' })
  total!: number;

  @ApiProperty({ enum: ['USD'], example: 'USD' })
  moneda!: 'USD';

  static from(reservaId: string, cargos: Cargos): ResumenPagoResponseDto {
    return {
      reservaId,
      // Prisma devuelve DECIMAL como Decimal; la API lo expone como número.
      importeAlquiler: cargos.importeAlquiler.toNumber(),
      importeDeposito: cargos.importeDeposito.toNumber(),
      total: cargos.total.toNumber(),
      moneda: 'USD',
    };
  }
}
