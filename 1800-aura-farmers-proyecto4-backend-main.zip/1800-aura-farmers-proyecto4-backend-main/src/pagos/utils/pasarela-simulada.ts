import { EstadoPago, ModalidadPago } from '@PrismaClient';

/** Últimos dígitos de la tarjeta de prueba que la pasarela aprueba. */
export const TARJETA_QUE_APRUEBA = '4242';
/** Últimos dígitos de la tarjeta de prueba que la pasarela rechaza. */
export const TARJETA_QUE_RECHAZA = '0002';
/** Referencia de transferencia de prueba que la pasarela aprueba. */
export const REFERENCIA_QUE_APRUEBA = 'SIM-APRUEBA';

export const MOTIVOS_RECHAZO = {
  TARJETA_RECHAZADA: 'Tarjeta rechazada por la pasarela simulada.',
  TARJETA_NO_RECONOCIDA: 'Tarjeta no reconocida por la pasarela simulada.',
  REFERENCIA_NO_RECONOCIDA: 'Referencia de transferencia no reconocida.',
} as const;

/** Lo que la pasarela necesita del cuerpo del pago. */
export interface SolicitudPasarela {
  modalidad: ModalidadPago;
  numeroTarjeta?: string;
  referenciaSimulada?: string;
}

/**
 * Resultado de la pasarela, listo para guardarse. De la tarjeta solo quedan los
 * últimos cuatro dígitos: el número completo y el CVV no salen de aquí.
 */
export interface ResultadoPasarela {
  estado:
    typeof EstadoPago.SIMULADO_EXITOSO | typeof EstadoPago.SIMULADO_RECHAZADO;
  motivoRechazo: string | null;
  ultimosCuatro: string | null;
  referenciaSimulada: string | null;
}

const exito = (
  datos: Pick<ResultadoPasarela, 'ultimosCuatro' | 'referenciaSimulada'>,
): ResultadoPasarela => ({
  estado: EstadoPago.SIMULADO_EXITOSO,
  motivoRechazo: null,
  ...datos,
});

const rechazo = (
  motivoRechazo: string,
  datos: Pick<ResultadoPasarela, 'ultimosCuatro' | 'referenciaSimulada'>,
): ResultadoPasarela => ({
  estado: EstadoPago.SIMULADO_RECHAZADO,
  motivoRechazo,
  ...datos,
});

/**
 * Pasarela de pago simulada: decide el resultado sin ninguna integración
 * financiera real.
 *
 * - Tarjeta terminada en 4242: aprobada. En 0002: rechazada. Cualquier otra:
 *   rechazada como no reconocida.
 * - Transferencia con la referencia SIM-APRUEBA: aprobada. Cualquier otra:
 *   rechazada como no reconocida.
 *
 * La forma de los datos (dígitos, longitud de la referencia) ya la validó el
 * DTO; aquí solo se aplican las reglas de la pasarela.
 */
export function simularPasarela(
  solicitud: SolicitudPasarela,
): ResultadoPasarela {
  if (solicitud.modalidad === ModalidadPago.TARJETA) {
    const ultimosCuatro = (solicitud.numeroTarjeta ?? '').slice(-4);
    const datos = { ultimosCuatro, referenciaSimulada: null };
    if (ultimosCuatro === TARJETA_QUE_APRUEBA) return exito(datos);
    if (ultimosCuatro === TARJETA_QUE_RECHAZA) {
      return rechazo(MOTIVOS_RECHAZO.TARJETA_RECHAZADA, datos);
    }
    return rechazo(MOTIVOS_RECHAZO.TARJETA_NO_RECONOCIDA, datos);
  }

  const referenciaSimulada = solicitud.referenciaSimulada ?? null;
  const datos = { ultimosCuatro: null, referenciaSimulada };
  if (referenciaSimulada === REFERENCIA_QUE_APRUEBA) return exito(datos);
  return rechazo(MOTIVOS_RECHAZO.REFERENCIA_NO_RECONOCIDA, datos);
}

/**
 * Indica si una tarjeta con vencimiento `MM/AA` ya venció el día `hoy`.
 *
 * Una tarjeta vale hasta el último día de su mes de vencimiento. Los años de
 * dos dígitos se leen como 20AA.
 */
export function tarjetaVencida(vencimiento: string, hoy: Date): boolean {
  const [mes, anio] = vencimiento.split('/').map(Number);
  const anioCompleto = 2000 + anio;
  const anioHoy = hoy.getUTCFullYear();
  const mesHoy = hoy.getUTCMonth() + 1;
  return anioCompleto < anioHoy || (anioCompleto === anioHoy && mes < mesHoy);
}
