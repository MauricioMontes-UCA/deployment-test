import { describe, expect, it } from 'vitest';
import { Prisma } from '@PrismaClient';
import { mensajePagoAprobado } from './notificacion-pago.js';

describe('BE-22.2 - Mensaje de pago aprobado', () => {
  it('muestra el monto con dos decimales', () => {
    const mensaje = mensajePagoAprobado(
      new Prisma.Decimal('125'),
      'carlos23',
      'Cámara Sony',
    );

    expect(mensaje).toBe(
      'Se aprobó el pago de $125.00 de carlos23 por Cámara Sony.',
    );
  });

  it('conserva los centavos', () => {
    const mensaje = mensajePagoAprobado(
      new Prisma.Decimal('125.50'),
      'carlos23',
      'Cámara Sony',
    );

    expect(mensaje).toContain('$125.50');
  });

  it('no supera los 300 caracteres', () => {
    const mensaje = mensajePagoAprobado(
      new Prisma.Decimal('125'),
      'carlos23',
      'A'.repeat(500),
    );

    expect(mensaje.length).toBeLessThanOrEqual(300);
  });
});
