import { Prisma, UnidadCobro } from '@PrismaClient';

const MS_POR_DIA = 24 * 60 * 60 * 1000;
const HORAS_POR_DIA = 24;
const DIAS_POR_SEMANA = 7;

/** Lo que hace falta de la reserva y su bien para calcular el cobro. */
export interface DatosCargo {
  /** Primer día de la reserva (`@db.Date`, medianoche UTC). */
  fechaInicio: Date;
  /** Último día de la reserva, incluido. */
  fechaFin: Date;
  precio: Prisma.Decimal;
  unidadCobro: UnidadCobro;
  deposito: Prisma.Decimal;
}

/** Importes del cobro, ya redondeados a dos decimales. */
export interface Cargos {
  importeAlquiler: Prisma.Decimal;
  importeDeposito: Prisma.Decimal;
  total: Prisma.Decimal;
}

/** Días de la reserva contando el primero y el último. */
export function diasDeReserva(fechaInicio: Date, fechaFin: Date): number {
  return (
    Math.round((fechaFin.getTime() - fechaInicio.getTime()) / MS_POR_DIA) + 1
  );
}

/**
 * Cuántas unidades de cobro ocupa una reserva de `dias` días completos.
 *
 * Las reservas son por días, pero el bien puede cobrarse por hora, día, noche o
 * semana. Ninguna tarea fija la conversión; es una decisión técnica de BE-8.1:
 * - DIA: un cobro por día.
 * - NOCHE: las noches entre el primer y el último día, mínimo una.
 * - SEMANA: semanas iniciadas, redondeando hacia arriba.
 * - HORA: 24 horas por día.
 */
export function unidadesACobrar(
  unidadCobro: UnidadCobro,
  dias: number,
): number {
  switch (unidadCobro) {
    case UnidadCobro.DIA:
      return dias;
    case UnidadCobro.NOCHE:
      return Math.max(dias - 1, 1);
    case UnidadCobro.SEMANA:
      return Math.ceil(dias / DIAS_POR_SEMANA);
    case UnidadCobro.HORA:
      return dias * HORAS_POR_DIA;
  }
}

/**
 * Calcula el cobro de una reserva solo con datos persistidos: nunca con
 * importes que mande el cliente.
 *
 * Se trabaja con `Decimal` para no arrastrar errores de punto flotante.
 */
export function calcularCargos({
  fechaInicio,
  fechaFin,
  precio,
  unidadCobro,
  deposito,
}: DatosCargo): Cargos {
  const unidades = unidadesACobrar(
    unidadCobro,
    diasDeReserva(fechaInicio, fechaFin),
  );
  const importeAlquiler = precio
    .mul(unidades)
    .toDecimalPlaces(2, Prisma.Decimal.ROUND_HALF_UP);
  const importeDeposito = deposito.toDecimalPlaces(
    2,
    Prisma.Decimal.ROUND_HALF_UP,
  );
  return {
    importeAlquiler,
    importeDeposito,
    total: importeAlquiler.add(importeDeposito),
  };
}
