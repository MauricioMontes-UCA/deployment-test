import { Prisma } from '@PrismaClient';

export const TITULO_PAGO_APROBADO = 'Pago recibido';
export const REFERENCIA_PAGO_APROBADO = 'PAGO_APROBADO';

export function mensajePagoAprobado(
  total: Prisma.Decimal,
  usuario: string,
  bien: string,
): string {
  const prefijo = `Se aprobó el pago de $${total.toFixed(2)} de `;
  const separador = ' por ';
  const sufijo = '.';

  const maxUsuario = Math.max(
    0,
    300 - prefijo.length - separador.length - sufijo.length,
  );

  const nombreUsuario = usuario.slice(0, maxUsuario);

  const maxBien = Math.max(
    0,
    300 -
      prefijo.length -
      nombreUsuario.length -
      separador.length -
      sufijo.length,
  );

  return prefijo + nombreUsuario + separador + bien.slice(0, maxBien) + sufijo;
}
