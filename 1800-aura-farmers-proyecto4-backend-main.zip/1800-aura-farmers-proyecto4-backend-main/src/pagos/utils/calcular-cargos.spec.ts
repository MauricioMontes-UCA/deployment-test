import { Prisma } from '../../generated/prisma/browser.js';
import {
  calcularCargos,
  diasDeReserva,
  unidadesACobrar,
} from './calcular-cargos.js';

const dia = (n: number) => new Date(Date.UTC(2026, 11, n));
const decimal = (valor: number | string) => new Prisma.Decimal(valor);

describe('diasDeReserva', () => {
  it('cuenta el primer y el último día', () => {
    expect(diasDeReserva(dia(10), dia(12))).toBe(3);
  });

  it('una reserva de un solo día dura 1', () => {
    expect(diasDeReserva(dia(10), dia(10))).toBe(1);
  });
});

describe('unidadesACobrar', () => {
  it.each([
    ['DIA', 3, 3],
    ['NOCHE', 3, 2],
    ['NOCHE', 1, 1],
    ['SEMANA', 3, 1],
    ['SEMANA', 7, 1],
    ['SEMANA', 8, 2],
    ['HORA', 3, 72],
  ] as const)('%s con %i días cobra %i unidades', (unidad, dias, unidades) => {
    expect(unidadesACobrar(unidad, dias)).toBe(unidades);
  });
});

describe('calcularCargos', () => {
  const base = {
    fechaInicio: dia(10),
    fechaFin: dia(12),
    precio: decimal('20.00'),
    unidadCobro: 'DIA' as const,
    deposito: decimal('25.00'),
  };

  it('suma el alquiler y el depósito del bien', () => {
    const cargos = calcularCargos(base);

    expect(cargos.importeAlquiler.toFixed(2)).toBe('60.00');
    expect(cargos.importeDeposito.toFixed(2)).toBe('25.00');
    expect(cargos.total.toFixed(2)).toBe('85.00');
  });

  it('con un bien sin depósito el total es el alquiler', () => {
    const cargos = calcularCargos({ ...base, deposito: decimal(0) });

    expect(cargos.importeDeposito.toFixed(2)).toBe('0.00');
    expect(cargos.total.toFixed(2)).toBe('60.00');
  });

  it('no arrastra errores de punto flotante', () => {
    // 0.1 × 3 en número da 0.30000000000000004.
    const cargos = calcularCargos({
      ...base,
      precio: decimal('0.10'),
      deposito: decimal('0.20'),
    });

    expect(cargos.importeAlquiler.toNumber()).toBe(0.3);
    expect(cargos.total.toNumber()).toBe(0.5);
  });

  it('usa la unidad de cobro del bien', () => {
    const cargos = calcularCargos({ ...base, unidadCobro: 'NOCHE' });

    expect(cargos.importeAlquiler.toFixed(2)).toBe('40.00');
  });
});
