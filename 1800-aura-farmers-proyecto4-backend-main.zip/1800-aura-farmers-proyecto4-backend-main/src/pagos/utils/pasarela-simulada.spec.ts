import {
  MOTIVOS_RECHAZO,
  simularPasarela,
  tarjetaVencida,
} from './pasarela-simulada.js';

describe('simularPasarela', () => {
  const tarjeta = (numeroTarjeta: string) =>
    simularPasarela({ modalidad: 'TARJETA', numeroTarjeta });
  const transferencia = (referenciaSimulada: string) =>
    simularPasarela({
      modalidad: 'TRANSFERENCIA_BANCARIA',
      referenciaSimulada,
    });

  it('aprueba una tarjeta terminada en 4242 y solo guarda los últimos cuatro', () => {
    expect(tarjeta('4242424242424242')).toEqual({
      estado: 'SIMULADO_EXITOSO',
      motivoRechazo: null,
      ultimosCuatro: '4242',
      referenciaSimulada: null,
    });
  });

  it('rechaza una tarjeta terminada en 0002', () => {
    expect(tarjeta('4000000000000002')).toEqual({
      estado: 'SIMULADO_RECHAZADO',
      motivoRechazo: MOTIVOS_RECHAZO.TARJETA_RECHAZADA,
      ultimosCuatro: '0002',
      referenciaSimulada: null,
    });
  });

  it('rechaza cualquier otra tarjeta como no reconocida', () => {
    expect(tarjeta('5555555555554444')).toMatchObject({
      estado: 'SIMULADO_RECHAZADO',
      motivoRechazo: MOTIVOS_RECHAZO.TARJETA_NO_RECONOCIDA,
      ultimosCuatro: '4444',
    });
  });

  it('aprueba la transferencia con la referencia SIM-APRUEBA', () => {
    expect(transferencia('SIM-APRUEBA')).toEqual({
      estado: 'SIMULADO_EXITOSO',
      motivoRechazo: null,
      ultimosCuatro: null,
      referenciaSimulada: 'SIM-APRUEBA',
    });
  });

  it('rechaza cualquier otra referencia y la guarda para el registro', () => {
    expect(transferencia('REF-123456')).toEqual({
      estado: 'SIMULADO_RECHAZADO',
      motivoRechazo: MOTIVOS_RECHAZO.REFERENCIA_NO_RECONOCIDA,
      ultimosCuatro: null,
      referenciaSimulada: 'REF-123456',
    });
  });

  it('el resultado no contiene el número completo de la tarjeta', () => {
    const resultado = tarjeta('4242424242424242');

    expect(JSON.stringify(resultado)).not.toContain('4242424242424242');
  });
});

describe('tarjetaVencida', () => {
  const hoy = new Date(Date.UTC(2026, 10, 15)); // 15 de noviembre de 2026

  it.each([
    ['11/26', false], // vale hasta el último día de su mes
    ['12/26', false],
    ['01/27', false],
    ['10/26', true],
    ['12/25', true],
  ])('%s vencida: %s', (vencimiento, vencida) => {
    expect(tarjetaVencida(vencimiento, hoy)).toBe(vencida);
  });
});
