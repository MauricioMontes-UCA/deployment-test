import { ForbiddenException, NotFoundException } from '@nestjs/common';
import { BloqueosService } from './bloqueos.service.js';
import type { BloqueoRepository } from '@Bloqueos/repositories';

const ARRENDADOR_ID = '11111111-1111-4111-8111-111111111111';
const OTRO_ARRENDADOR_ID = '22222222-2222-4222-8222-222222222222';
const BIEN_ID = '7c9e6679-7425-40de-944b-e07fc1f90ae7';
const dia = (valor: string) => new Date(`${valor}T00:00:00.000Z`);
const BLOQUEOS = [
  {
    id: '9b2d4c6e-1a3f-4b5c-8d7e-6f5a4b3c2d1e',
    fechaInicio: dia('2026-12-20'),
    fechaFin: dia('2026-12-25'),
    creadoEn: new Date('2026-11-01T15:00:00.000Z'),
  },
];

function crear({
  dueno = ARRENDADOR_ID as string | null,
  bloqueos = BLOQUEOS,
} = {}) {
  const repository = {
    findArrendadorDelBien: vi.fn().mockResolvedValue(dueno),
    findVigentes: vi.fn().mockResolvedValue(bloqueos),
  };
  const service = new BloqueosService(
    repository as unknown as BloqueoRepository,
  );
  return { service, repository };
}

describe('BloqueosService.listar', () => {
  it('devuelve los bloqueos vigentes del bien del arrendador', async () => {
    const { service, repository } = crear();

    const resultado = await service.listar(
      ARRENDADOR_ID,
      BIEN_ID,
      new Date('2026-11-13T18:00:00.000Z'),
    );

    expect(resultado).toBe(BLOQUEOS);
    expect(repository.findVigentes).toHaveBeenCalledOnce();
  });

  it('"hoy" es el día de El Salvador, no el de UTC', async () => {
    const { service, repository } = crear();

    // 03:00 UTC del 13 de noviembre = 12 de noviembre, 21:00 en El Salvador.
    await service.listar(
      ARRENDADOR_ID,
      BIEN_ID,
      new Date('2026-11-13T03:00:00.000Z'),
    );

    expect(repository.findVigentes).toHaveBeenCalledWith(
      BIEN_ID,
      dia('2026-11-12'),
    );
  });

  it('a las 06:00 UTC ya es el día siguiente en El Salvador', async () => {
    const { service, repository } = crear();

    await service.listar(
      ARRENDADOR_ID,
      BIEN_ID,
      new Date('2026-11-13T06:00:00.000Z'),
    );

    expect(repository.findVigentes).toHaveBeenCalledWith(
      BIEN_ID,
      dia('2026-11-13'),
    );
  });

  it('un bien sin bloqueos devuelve una lista vacía', async () => {
    const { service } = crear({ bloqueos: [] });

    await expect(service.listar(ARRENDADOR_ID, BIEN_ID)).resolves.toEqual([]);
  });

  it('un bien inexistente es 404 y no consulta los bloqueos', async () => {
    const { service, repository } = crear({ dueno: null });

    await expect(service.listar(ARRENDADOR_ID, BIEN_ID)).rejects.toBeInstanceOf(
      NotFoundException,
    );
    expect(repository.findVigentes).not.toHaveBeenCalled();
  });

  it('el bien de otro arrendador es 403 y no consulta los bloqueos', async () => {
    const { service, repository } = crear({ dueno: OTRO_ARRENDADOR_ID });

    await expect(service.listar(ARRENDADOR_ID, BIEN_ID)).rejects.toBeInstanceOf(
      ForbiddenException,
    );
    expect(repository.findVigentes).not.toHaveBeenCalled();
  });
});
