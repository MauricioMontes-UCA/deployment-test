import {
  BadRequestException,
  ConflictException,
  ForbiddenException,
  HttpStatus,
  Injectable,
  NotFoundException,
  UnprocessableEntityException,
} from '@nestjs/common';
import { hoyEn, parseDia } from '@Bienes/utils';
import {
  BloqueoRepository,
  type Bloqueo,
  type BloqueoListado,
} from '@Bloqueos/repositories';
import type { CreateBloqueoDto } from '@Bloqueos/dto';

/** Los bienes están en El Salvador: "hoy" es el día de esa zona, no el de UTC. */
const ZONA_HORARIA = 'America/El_Salvador';

/**
 * Bloqueos de fechas de un bien (H7).
 *
 * No conoce Prisma: el acceso a datos y el candado por bien viven en
 * BloqueoRepository.
 */
@Injectable()
export class BloqueosService {
  constructor(private readonly bloqueoRepository: BloqueoRepository) {}

  /**
   * Lista los bloqueos vigentes o futuros de un bien del arrendador (BE-7.3),
   * con su id, para que la gestión de bloqueos pueda eliminarlos. Un bloqueo
   * vigente es el que termina hoy o después; "hoy" es el día de El Salvador.
   *
   * @throws {NotFoundException} el bien no existe.
   * @throws {ForbiddenException} el bien no es del arrendador.
   *
   * `ahora` se recibe para poder probar la regla de "hoy".
   */
  async listar(
    arrendadorId: string,
    bienId: string,
    ahora: Date = new Date(),
  ): Promise<BloqueoListado[]> {
    await this.verificarDueno(arrendadorId, bienId);

    return this.bloqueoRepository.findVigentes(
      bienId,
      hoyEn(ZONA_HORARIA, ahora),
    );
  }

  /**
   * Bloquea un rango de días de un bien del arrendador.
   *
   * Los conflictos se revisan con el candado del bien tomado, el mismo que usa
   * el procesador de reservas: entre la revisión y el insert nadie puede
   * confirmar una reserva ni crear otro bloqueo en ese bien.
   *
   * @throws {BadRequestException} alguna fecha no es un día real.
   * @throws {NotFoundException} el bien no existe.
   * @throws {ForbiddenException} el bien no es del arrendador.
   * @throws {UnprocessableEntityException} inicio anterior a hoy o fin anterior
   * al inicio.
   * @throws {ConflictException} hay una reserva CONFIRMADA o EN_CURSO en el
   * rango (`reservaId`) o se solapa con otro bloqueo (`bloqueoId`).
   *
   * `ahora` se recibe para poder probar la regla de "hoy".
   */
  async create(
    arrendadorId: string,
    bienId: string,
    dto: CreateBloqueoDto,
    ahora: Date = new Date(),
  ): Promise<Bloqueo> {
    const rango = {
      fechaInicio: this.parsear('fechaInicio', dto.fechaInicio),
      fechaFin: this.parsear('fechaFin', dto.fechaFin),
    };

    await this.verificarDueno(arrendadorId, bienId);

    if (rango.fechaInicio < hoyEn(ZONA_HORARIA, ahora)) {
      throw new UnprocessableEntityException(
        'La fecha de inicio no puede ser anterior a hoy.',
      );
    }
    if (rango.fechaFin < rango.fechaInicio) {
      throw new UnprocessableEntityException(
        'La fecha de fin no puede ser anterior a la de inicio.',
      );
    }

    return this.bloqueoRepository.withCandadoDelBien(
      bienId,
      async (bloqueos) => {
        const reserva = await bloqueos.findReservaEnConflicto(rango);
        if (reserva) {
          throw conflicto(
            'El rango incluye una reserva confirmada o en curso.',
            { reservaId: reserva.id },
          );
        }

        const bloqueo = await bloqueos.findBloqueoSolapado(rango);
        if (bloqueo) {
          throw conflicto('El rango se solapa con otro bloqueo del bien.', {
            bloqueoId: bloqueo.id,
          });
        }

        return bloqueos.create(rango);
      },
    );
  }

  /**
   * Elimina un bloqueo de un bien del arrendador. Sus días vuelven a estar
   * disponibles.
   *
   * @throws {NotFoundException} el bien no existe o el bloqueo no es de ese bien.
   * @throws {ForbiddenException} el bien no es del arrendador.
   */
  async delete(
    arrendadorId: string,
    bienId: string,
    bloqueoId: string,
  ): Promise<void> {
    await this.verificarDueno(arrendadorId, bienId);

    const eliminado = await this.bloqueoRepository.withCandadoDelBien(
      bienId,
      (bloqueos) => bloqueos.delete(bloqueoId),
    );
    if (!eliminado) {
      throw new NotFoundException('El bloqueo no existe.');
    }
  }

  private async verificarDueno(
    arrendadorId: string,
    bienId: string,
  ): Promise<void> {
    const dueno = await this.bloqueoRepository.findArrendadorDelBien(bienId);
    if (dueno === null) {
      throw new NotFoundException('El bien no existe.');
    }
    if (dueno !== arrendadorId) {
      throw new ForbiddenException('El bien no es tuyo.');
    }
  }

  private parsear(campo: string, valor: string): Date {
    const fecha = parseDia(valor);
    if (!fecha) {
      throw new BadRequestException([
        `${campo}: no es una fecha válida (YYYY-MM-DD).`,
      ]);
    }
    return fecha;
  }
}

/** 409 con el formato `{ message, error, statusCode }` más el id en conflicto. */
function conflicto(
  message: string,
  extra: { reservaId: string } | { bloqueoId: string },
): ConflictException {
  return new ConflictException({
    message,
    error: 'Conflict',
    statusCode: HttpStatus.CONFLICT,
    ...extra,
  });
}
