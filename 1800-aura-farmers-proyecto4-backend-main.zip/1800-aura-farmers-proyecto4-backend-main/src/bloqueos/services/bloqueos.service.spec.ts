import {
  BadRequestException,
  ConflictException,
  ForbiddenException,
  NotFoundException,
  UnprocessableEntityException,
} from '@nestjs/common';
import { BloqueosService } from './bloqueos.service.js';
import type {
  BloqueoRepository,
  BloqueosDelBien,
} from '@Bloqueos/repositories';

const ARRENDADOR_ID = '11111111-1111-4111-8111-111111111111';
const OTRO_ARRENDADOR_ID = '22222222-2222-4222-8222-222222222222';
const BIEN_ID = '7c9e6679-7425-40de-944b-e07fc1f90ae7';
const BLOQUEO_ID = '9b2d4c6e-1a3f-4b5c-8d7e-6f5a4b3c2d1e';
const RESERVA_ID = '3f1e2d3c-4b5a-4968-8776-655443322110';
// 03:00 UTC del 13 de noviembre = 12 de noviembre, 21:00 en El Salvador.
const AHORA = new Date('2026-11-13T03:00:00.000Z');

const dia = (valor: string) => new Date(`${valor}T00:00:00.000Z`);

function crear({
  dueno = ARRENDADOR_ID as string | null,
  reservaEnConflicto = null as { id: string } | null,
  bloqueoSolapado = null as { id: string } | null,
  eliminado = true,
} = {}) {
  const bloqueos: { [K in keyof BloqueosDelBien]: ReturnType<typeof vi.fn> } = {
    findReservaEnConflicto: vi.fn().mockResolvedValue(reservaEnConflicto),
    findBloqueoSolapado: vi.fn().mockResolvedValue(bloqueoSolapado),
    create: vi
      .fn()
      .mockImplementation((rango) =>
        Promise.resolve({ id: BLOQUEO_ID, bienId: BIEN_ID, ...rango }),
      ),
    delete: vi.fn().mockResolvedValue(eliminado),
  };
  const repository = {
    findArrendadorDelBien: vi.fn().mockResolvedValue(dueno),
    withCandadoDelBien: vi.fn(
      (_bienId: string, trabajo: (b: BloqueosDelBien) => Promise<unknown>) =>
        trabajo(bloqueos as unknown as BloqueosDelBien),
    ),
  };
  const service = new BloqueosService(
    repository as unknown as BloqueoRepository,
  );
  return { service, repository, bloqueos };
}

const crearBloqueo = (
  service: BloqueosService,
  fechaInicio = '2026-12-20',
  fechaFin = '2026-12-25',
) => service.create(ARRENDADOR_ID, BIEN_ID, { fechaInicio, fechaFin }, AHORA);

describe('BloqueosService.create', () => {
  it('crea el bloqueo con el candado del bien tomado', async () => {
    const { service, repository, bloqueos } = crear();

    const bloqueo = await crearBloqueo(service);

    const rango = {
      fechaInicio: dia('2026-12-20'),
      fechaFin: dia('2026-12-25'),
    };
    expect(bloqueo).toEqual({ id: BLOQUEO_ID, bienId: BIEN_ID, ...rango });
    expect(repository.withCandadoDelBien).toHaveBeenCalledWith(
      BIEN_ID,
      expect.any(Function),
    );
    expect(bloqueos.findReservaEnConflicto).toHaveBeenCalledWith(rango);
    expect(bloqueos.findBloqueoSolapado).toHaveBeenCalledWith(rango);
    expect(bloqueos.create).toHaveBeenCalledWith(rango);
  });

  it('acepta un bloqueo de un solo día que empieza hoy (día de El Salvador)', async () => {
    const { service, bloqueos } = crear();

    await crearBloqueo(service, '2026-11-12', '2026-11-12');

    expect(bloqueos.create).toHaveBeenCalled();
  });

  it('rechaza con 400 un día que no existe', async () => {
    const { service, repository } = crear();

    await expect(
      crearBloqueo(service, '2026-02-30', '2026-03-02'),
    ).rejects.toBeInstanceOf(BadRequestException);
    expect(repository.findArrendadorDelBien).not.toHaveBeenCalled();
  });

  it('responde 404 si el bien no existe', async () => {
    const { service, repository } = crear({ dueno: null });

    await expect(crearBloqueo(service)).rejects.toBeInstanceOf(
      NotFoundException,
    );
    expect(repository.withCandadoDelBien).not.toHaveBeenCalled();
  });

  it('responde 403 si el bien es de otro arrendador', async () => {
    const { service, repository } = crear({ dueno: OTRO_ARRENDADOR_ID });

    await expect(crearBloqueo(service)).rejects.toBeInstanceOf(
      ForbiddenException,
    );
    expect(repository.withCandadoDelBien).not.toHaveBeenCalled();
  });

  it('responde 422 si el inicio es anterior a hoy', async () => {
    const { service, repository } = crear();

    await expect(
      crearBloqueo(service, '2026-11-11', '2026-11-20'),
    ).rejects.toBeInstanceOf(UnprocessableEntityException);
    expect(repository.withCandadoDelBien).not.toHaveBeenCalled();
  });

  it('responde 422 si el fin es anterior al inicio', async () => {
    const { service } = crear();

    await expect(
      crearBloqueo(service, '2026-12-25', '2026-12-20'),
    ).rejects.toBeInstanceOf(UnprocessableEntityException);
  });

  it('responde 409 con la reserva en conflicto y no crea el bloqueo', async () => {
    const { service, bloqueos } = crear({
      reservaEnConflicto: { id: RESERVA_ID },
    });

    const error = await crearBloqueo(service).catch((e: unknown) => e);

    expect(error).toBeInstanceOf(ConflictException);
    expect((error as ConflictException).getResponse()).toEqual({
      message: 'El rango incluye una reserva confirmada o en curso.',
      error: 'Conflict',
      statusCode: 409,
      reservaId: RESERVA_ID,
    });
    expect(bloqueos.create).not.toHaveBeenCalled();
  });

  it('responde 409 con el bloqueo solapado y no crea el bloqueo', async () => {
    const { service, bloqueos } = crear({
      bloqueoSolapado: { id: BLOQUEO_ID },
    });

    const error = await crearBloqueo(service).catch((e: unknown) => e);

    expect(error).toBeInstanceOf(ConflictException);
    expect((error as ConflictException).getResponse()).toMatchObject({
      statusCode: 409,
      bloqueoId: BLOQUEO_ID,
    });
    expect(bloqueos.create).not.toHaveBeenCalled();
  });
});

describe('BloqueosService.delete', () => {
  it('elimina el bloqueo con el candado del bien tomado', async () => {
    const { service, repository, bloqueos } = crear();

    await service.delete(ARRENDADOR_ID, BIEN_ID, BLOQUEO_ID);

    expect(repository.withCandadoDelBien).toHaveBeenCalledWith(
      BIEN_ID,
      expect.any(Function),
    );
    expect(bloqueos.delete).toHaveBeenCalledWith(BLOQUEO_ID);
  });

  it('responde 404 si el bloqueo no existe o es de otro bien', async () => {
    const { service } = crear({ eliminado: false });

    await expect(
      service.delete(ARRENDADOR_ID, BIEN_ID, BLOQUEO_ID),
    ).rejects.toBeInstanceOf(NotFoundException);
  });

  it('responde 404 si el bien no existe', async () => {
    const { service, bloqueos } = crear({ dueno: null });

    await expect(
      service.delete(ARRENDADOR_ID, BIEN_ID, BLOQUEO_ID),
    ).rejects.toBeInstanceOf(NotFoundException);
    expect(bloqueos.delete).not.toHaveBeenCalled();
  });

  it('responde 403 si el bien es de otro arrendador', async () => {
    const { service, bloqueos } = crear({ dueno: OTRO_ARRENDADOR_ID });

    await expect(
      service.delete(ARRENDADOR_ID, BIEN_ID, BLOQUEO_ID),
    ).rejects.toBeInstanceOf(ForbiddenException);
    expect(bloqueos.delete).not.toHaveBeenCalled();
  });
});
