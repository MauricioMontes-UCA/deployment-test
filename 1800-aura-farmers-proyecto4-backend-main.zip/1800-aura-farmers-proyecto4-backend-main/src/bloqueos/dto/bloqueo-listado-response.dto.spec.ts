import { BloqueoListadoResponseDto } from './bloqueo-listado-response.dto.js';

describe('BloqueoListadoResponseDto.fromEntity', () => {
  it('formatea las fechas como días y creadoEn como ISO 8601', () => {
    const dto = BloqueoListadoResponseDto.fromEntity({
      id: '9b2d4c6e-1a3f-4b5c-8d7e-6f5a4b3c2d1e',
      fechaInicio: new Date('2026-12-20T00:00:00.000Z'),
      fechaFin: new Date('2026-12-25T00:00:00.000Z'),
      creadoEn: new Date('2026-11-13T15:04:05.000Z'),
    });

    expect(dto).toEqual({
      id: '9b2d4c6e-1a3f-4b5c-8d7e-6f5a4b3c2d1e',
      fechaInicio: '2026-12-20',
      fechaFin: '2026-12-25',
      creadoEn: '2026-11-13T15:04:05.000Z',
    });
  });

  it('no expone el id del bien ni otros campos', () => {
    const dto = BloqueoListadoResponseDto.fromEntity({
      id: 'x',
      bienId: 'no-debe-salir',
      fechaInicio: new Date('2026-12-20T00:00:00.000Z'),
      fechaFin: new Date('2026-12-20T00:00:00.000Z'),
      creadoEn: new Date('2026-11-13T15:04:05.000Z'),
    } as never);

    expect(Object.keys(dto).sort()).toEqual([
      'creadoEn',
      'fechaFin',
      'fechaInicio',
      'id',
    ]);
  });
});
