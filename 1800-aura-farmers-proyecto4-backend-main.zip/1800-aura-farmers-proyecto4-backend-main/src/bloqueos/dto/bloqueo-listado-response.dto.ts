import { ApiProperty } from '@nestjs/swagger';
import { formatDia } from '@Bienes/utils';
import type { BloqueoListado } from '@Bloqueos/repositories';

/**
 * Bloqueo vigente o futuro de un bien propio (BE-7.3), con el id que necesita
 * `DELETE /bienes/:bienId/bloqueos/:id`. Las fechas van como días
 * (YYYY-MM-DD), igual que en BE-7.1.
 */
export class BloqueoListadoResponseDto {
  @ApiProperty({ format: 'uuid' })
  id!: string;

  @ApiProperty({ example: '2026-12-20', format: 'date' })
  fechaInicio!: string;

  @ApiProperty({ example: '2026-12-25', format: 'date' })
  fechaFin!: string;

  @ApiProperty({ example: '2026-11-13T15:04:05.000Z', format: 'date-time' })
  creadoEn!: string;

  static fromEntity(bloqueo: BloqueoListado): BloqueoListadoResponseDto {
    return {
      id: bloqueo.id,
      fechaInicio: formatDia(bloqueo.fechaInicio),
      fechaFin: formatDia(bloqueo.fechaFin),
      creadoEn: bloqueo.creadoEn.toISOString(),
    };
  }
}
