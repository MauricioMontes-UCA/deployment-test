import { plainToInstance } from 'class-transformer';
import { validate } from 'class-validator';
import { CreateBloqueoDto } from './create-bloqueo.dto.js';

async function errores(datos: Record<string, unknown>) {
  const resultado = await validate(plainToInstance(CreateBloqueoDto, datos));
  return resultado.map((e) => e.property);
}

describe('CreateBloqueoDto', () => {
  it('acepta dos fechas YYYY-MM-DD', async () => {
    expect(
      await errores({ fechaInicio: '2026-12-20', fechaFin: '2026-12-25' }),
    ).toEqual([]);
  });

  it('exige las dos fechas', async () => {
    expect(await errores({})).toEqual(['fechaInicio', 'fechaFin']);
  });

  it.each(['20-12-2026', '2026-12-20T00:00:00Z', '2026/12/20', 20261220])(
    'rechaza el formato %s',
    async (valor) => {
      expect(
        await errores({ fechaInicio: valor, fechaFin: '2026-12-25' }),
      ).toEqual(['fechaInicio']);
    },
  );
});
