import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString, Matches } from 'class-validator';

const FORMATO_DIA = /^\d{4}-\d{2}-\d{2}$/;
const MENSAJE_FORMATO = 'Debe tener el formato YYYY-MM-DD.';

/**
 * Body de `POST /bienes/:bienId/bloqueos`.
 *
 * Aquí solo se valida el formato (400). Que sea un día real también es formato
 * y lo revisa el servicio; que el inicio no sea pasado y el fin no sea anterior
 * al inicio son reglas de negocio y responden 422.
 */
export class CreateBloqueoDto {
  @ApiProperty({
    example: '2026-12-20',
    format: 'date',
    description: 'Primer día bloqueado. No puede ser anterior a hoy.',
  })
  @IsString()
  @IsNotEmpty()
  @Matches(FORMATO_DIA, { message: `fechaInicio: ${MENSAJE_FORMATO}` })
  fechaInicio!: string;

  @ApiProperty({
    example: '2026-12-25',
    format: 'date',
    description: 'Último día bloqueado, inclusive.',
  })
  @IsString()
  @IsNotEmpty()
  @Matches(FORMATO_DIA, { message: `fechaFin: ${MENSAJE_FORMATO}` })
  fechaFin!: string;
}
