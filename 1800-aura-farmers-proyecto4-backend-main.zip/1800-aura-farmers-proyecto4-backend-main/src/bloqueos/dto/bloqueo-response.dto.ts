import { ApiProperty } from '@nestjs/swagger';
import { formatDia } from '@Bienes/utils';
import type { Bloqueo } from '@Bloqueos/repositories';

/** Bloqueo creado. Las fechas van como días (YYYY-MM-DD), igual que en BE-5.1. */
export class BloqueoResponseDto {
  @ApiProperty({ format: 'uuid' })
  id!: string;

  @ApiProperty({ format: 'uuid' })
  bienId!: string;

  @ApiProperty({ example: '2026-12-20', format: 'date' })
  fechaInicio!: string;

  @ApiProperty({ example: '2026-12-25', format: 'date' })
  fechaFin!: string;

  static fromEntity(bloqueo: Bloqueo): BloqueoResponseDto {
    return {
      id: bloqueo.id,
      bienId: bloqueo.bienId,
      fechaInicio: formatDia(bloqueo.fechaInicio),
      fechaFin: formatDia(bloqueo.fechaFin),
    };
  }
}
