import { Injectable } from '@nestjs/common';
import { PrismaService } from '@Prisma/services';
import { EstadoReserva, type Prisma } from '@PrismaClient';

/** Rango inclusivo de días completos: `fechaFin` es el último día bloqueado. */
export interface RangoDias {
  fechaInicio: Date;
  fechaFin: Date;
}

export interface Bloqueo extends RangoDias {
  id: string;
  bienId: string;
}

/** Bloqueo tal como lo lista BE-7.3: con su id y cuándo se creó. */
export interface BloqueoListado extends RangoDias {
  id: string;
  creadoEn: Date;
}

/**
 * Reservas que impiden bloquear sus días (BE-7.1): las que ya están tomadas y
 * todavía no terminaron. EN_COLA no cuenta porque el procesador la va a
 * rechazar por el bloqueo; RECHAZADA y CANCELADA no ocupan días.
 */
export const ESTADOS_QUE_IMPIDEN_BLOQUEAR: EstadoReserva[] = [
  EstadoReserva.CONFIRMADA,
  EstadoReserva.EN_CURSO,
];

/**
 * Operaciones disponibles dentro de la transacción de un bien, ya con el
 * candado tomado. Todas usan la misma conexión.
 */
export interface BloqueosDelBien {
  /** Primera reserva (por fecha) que ocupa algún día del rango. */
  findReservaEnConflicto(rango: RangoDias): Promise<{ id: string } | null>;
  /** Primer bloqueo (por fecha) que comparte algún día con el rango. */
  findBloqueoSolapado(rango: RangoDias): Promise<{ id: string } | null>;
  create(rango: RangoDias): Promise<Bloqueo>;
  /** Borra el bloqueo si es de este bien. Devuelve false si no existía. */
  delete(id: string): Promise<boolean>;
}

const CAMPOS_BLOQUEO = {
  id: true,
  bienId: true,
  fechaInicio: true,
  fechaFin: true,
} as const;

/** Acceso a la tabla `BloqueosFecha` y al dueño del bien. */
@Injectable()
export class BloqueoRepository {
  constructor(private readonly prisma: PrismaService) {}

  /** `arrendadorId` del bien, o null si el bien no existe. */
  async findArrendadorDelBien(bienId: string): Promise<string | null> {
    const bien = await this.prisma.bien.findUnique({
      where: { id: bienId },
      select: { arrendadorId: true },
    });
    return bien?.arrendadorId ?? null;
  }

  /**
   * Bloqueos de un bien que siguen vigentes o son futuros (BE-7.3): los que
   * terminan en `desde` o después, de la fecha de inicio más cercana a la más
   * lejana. `desde` es el día de hoy en la zona del bien. Es una lectura: no
   * toma el candado del bien.
   */
  findVigentes(bienId: string, desde: Date): Promise<BloqueoListado[]> {
    return this.prisma.bloqueoFecha.findMany({
      where: { bienId, fechaFin: { gte: desde } },
      select: { id: true, fechaInicio: true, fechaFin: true, creadoEn: true },
      orderBy: { fechaInicio: 'asc' },
    });
  }

  /**
   * Ejecuta `trabajo` en una transacción con el candado del bien tomado.
   *
   * El candado es `pg_advisory_xact_lock(hashtext(bienId))`, el mismo que toma
   * el procesador de la cola de reservas antes de confirmar una solicitud
   * (`ReservaRepository.procesarSiguiente`). Así, entre revisar los conflictos y
   * escribir el bloqueo, nadie puede confirmar una reserva ni crear otro bloqueo
   * en ese bien. Se libera solo al terminar la transacción.
   */
  withCandadoDelBien<T>(
    bienId: string,
    trabajo: (bloqueos: BloqueosDelBien) => Promise<T>,
  ): Promise<T> {
    return this.prisma.$transaction(async (tx) => {
      await tomarCandadoDelBien(tx, bienId);
      return trabajo(bloqueosDelBien(tx, bienId));
    });
  }
}

/**
 * Candado de transacción por bien.
 *
 * Tiene que ser la misma clave que usa el procesador de la cola de reservas
 * (`hashtext(bienId)`): con otra expresión, como `hashtextextended`, los dos
 * candados serían independientes y un bloqueo podría cruzarse con una
 * confirmación del mismo bien.
 */
export async function tomarCandadoDelBien(
  tx: Prisma.TransactionClient,
  bienId: string,
): Promise<void> {
  await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${bienId}))`;
}

function bloqueosDelBien(
  tx: Prisma.TransactionClient,
  bienId: string,
): BloqueosDelBien {
  // Dos rangos inclusivos comparten días si cada uno empieza antes de que el
  // otro termine.
  const cruzaCon = ({ fechaInicio, fechaFin }: RangoDias) => ({
    bienId,
    fechaInicio: { lte: fechaFin },
    fechaFin: { gte: fechaInicio },
  });
  const porInicio = { fechaInicio: 'asc' } as const;

  return {
    findReservaEnConflicto: (rango) =>
      tx.reserva.findFirst({
        where: {
          ...cruzaCon(rango),
          estado: { in: ESTADOS_QUE_IMPIDEN_BLOQUEAR },
        },
        select: { id: true },
        orderBy: porInicio,
      }),
    findBloqueoSolapado: (rango) =>
      tx.bloqueoFecha.findFirst({
        where: cruzaCon(rango),
        select: { id: true },
        orderBy: porInicio,
      }),
    create: (rango) =>
      tx.bloqueoFecha.create({
        data: { bienId, ...rango },
        select: CAMPOS_BLOQUEO,
      }),
    delete: async (id) => {
      const { count } = await tx.bloqueoFecha.deleteMany({
        where: { id, bienId },
      });
      return count > 0;
    },
  };
}
