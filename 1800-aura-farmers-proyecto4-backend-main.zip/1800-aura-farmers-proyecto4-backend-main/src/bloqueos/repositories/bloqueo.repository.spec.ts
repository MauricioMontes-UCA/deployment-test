import { BloqueoRepository } from './bloqueo.repository.js';
import type { PrismaService } from '@Prisma/services';

const BIEN_ID = '7c9e6679-7425-40de-944b-e07fc1f90ae7';
const dia = (valor: string) => new Date(`${valor}T00:00:00.000Z`);
const RANGO = { fechaInicio: dia('2026-12-20'), fechaFin: dia('2026-12-25') };

function crear() {
  const orden: string[] = [];
  const tx = {
    $executeRaw: vi.fn(() => {
      orden.push('candado');
      return Promise.resolve(1);
    }),
    reserva: { findFirst: vi.fn().mockResolvedValue(null) },
    bloqueoFecha: {
      findFirst: vi.fn(() => {
        orden.push('consulta');
        return Promise.resolve(null);
      }),
      create: vi.fn().mockResolvedValue({}),
      deleteMany: vi.fn().mockResolvedValue({ count: 1 }),
    },
  };
  const prisma = {
    $transaction: vi.fn((fn: (t: typeof tx) => Promise<unknown>) => fn(tx)),
  };
  const repository = new BloqueoRepository(prisma as unknown as PrismaService);
  return { repository, prisma, tx, orden };
}

describe('BloqueoRepository.withCandadoDelBien', () => {
  it('toma el candado del bien antes de ejecutar el trabajo', async () => {
    const { repository, tx, orden } = crear();

    await repository.withCandadoDelBien(BIEN_ID, (b) =>
      b.findBloqueoSolapado(RANGO),
    );

    expect(orden).toEqual(['candado', 'consulta']);
    const [sql, ...valores] = tx.$executeRaw.mock.calls[0] as unknown as [
      TemplateStringsArray,
      ...unknown[],
    ];
    expect(sql.join('?')).toContain('pg_advisory_xact_lock(hashtext(?))');
    expect(valores).toEqual([BIEN_ID]);
  });

  it('busca reservas CONFIRMADA o EN_CURSO que crucen el rango', async () => {
    const { repository, tx } = crear();

    await repository.withCandadoDelBien(BIEN_ID, (b) =>
      b.findReservaEnConflicto(RANGO),
    );

    expect(tx.reserva.findFirst).toHaveBeenCalledWith(
      expect.objectContaining({
        where: {
          bienId: BIEN_ID,
          fechaInicio: { lte: RANGO.fechaFin },
          fechaFin: { gte: RANGO.fechaInicio },
          estado: { in: ['CONFIRMADA', 'EN_CURSO'] },
        },
      }),
    );
  });

  it('borra solo si el bloqueo es de ese bien', async () => {
    const { repository, tx } = crear();
    tx.bloqueoFecha.deleteMany.mockResolvedValue({ count: 0 });

    const eliminado = await repository.withCandadoDelBien(BIEN_ID, (b) =>
      b.delete('otro-id'),
    );

    expect(eliminado).toBe(false);
    expect(tx.bloqueoFecha.deleteMany).toHaveBeenCalledWith({
      where: { id: 'otro-id', bienId: BIEN_ID },
    });
  });
});
