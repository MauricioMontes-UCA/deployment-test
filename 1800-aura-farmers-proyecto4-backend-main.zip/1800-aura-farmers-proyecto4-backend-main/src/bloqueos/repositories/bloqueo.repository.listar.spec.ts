import { BloqueoRepository } from './bloqueo.repository.js';
import type { PrismaService } from '@Prisma/services';

const BIEN_ID = '7c9e6679-7425-40de-944b-e07fc1f90ae7';
const dia = (valor: string) => new Date(`${valor}T00:00:00.000Z`);

function crear(filas: unknown[] = []) {
  const prisma = {
    bloqueoFecha: { findMany: vi.fn().mockResolvedValue(filas) },
  };
  const repository = new BloqueoRepository(prisma as unknown as PrismaService);
  return { repository, prisma };
}

describe('BloqueoRepository.findVigentes', () => {
  it('pide los bloqueos del bien que terminan hoy o después, por fecha de inicio', async () => {
    const { repository, prisma } = crear();

    await repository.findVigentes(BIEN_ID, dia('2026-11-13'));

    expect(prisma.bloqueoFecha.findMany).toHaveBeenCalledWith({
      where: { bienId: BIEN_ID, fechaFin: { gte: dia('2026-11-13') } },
      select: { id: true, fechaInicio: true, fechaFin: true, creadoEn: true },
      orderBy: { fechaInicio: 'asc' },
    });
  });

  it('devuelve las filas tal como las entrega Prisma', async () => {
    const filas = [
      {
        id: 'a',
        fechaInicio: dia('2026-12-01'),
        fechaFin: dia('2026-12-03'),
        creadoEn: new Date('2026-11-01T00:00:00.000Z'),
      },
    ];
    const { repository } = crear(filas);

    await expect(
      repository.findVigentes(BIEN_ID, dia('2026-11-13')),
    ).resolves.toBe(filas);
  });

  it('no abre una transacción ni toma el candado del bien', async () => {
    const { repository, prisma } = crear();

    await repository.findVigentes(BIEN_ID, dia('2026-11-13'));

    expect(prisma).not.toHaveProperty('$transaction');
  });
});
