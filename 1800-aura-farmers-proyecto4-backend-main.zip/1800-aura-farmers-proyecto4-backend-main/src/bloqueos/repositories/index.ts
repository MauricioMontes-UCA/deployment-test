export * from './bloqueo.repository.js';
