import { Module } from '@nestjs/common';
import { BloqueosController } from '@Bloqueos/controllers';
import { BloqueosService } from '@Bloqueos/services';
import { BloqueoRepository } from '@Bloqueos/repositories';

/** Bloqueos de fechas de los bienes (H7). */
@Module({
  controllers: [BloqueosController],
  providers: [BloqueosService, BloqueoRepository],
})
export class BloqueosModule {}
