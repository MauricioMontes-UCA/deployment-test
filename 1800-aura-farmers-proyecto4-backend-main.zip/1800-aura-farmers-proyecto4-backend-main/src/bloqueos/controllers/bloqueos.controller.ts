import {
  Body,
  Controller,
  Delete,
  Get,
  HttpCode,
  HttpStatus,
  Param,
  ParseUUIDPipe,
  Post,
} from '@nestjs/common';
import {
  ApiBadRequestResponse,
  ApiBearerAuth,
  ApiConflictResponse,
  ApiCreatedResponse,
  ApiForbiddenResponse,
  ApiNoContentResponse,
  ApiNotFoundResponse,
  ApiOkResponse,
  ApiOperation,
  ApiTags,
  ApiUnauthorizedResponse,
  ApiUnprocessableEntityResponse,
} from '@nestjs/swagger';
import { CurrentUser, Roles } from '@Auth/decorators';
import { BloqueosService } from '@Bloqueos/services';
import {
  BloqueoListadoResponseDto,
  BloqueoResponseDto,
  CreateBloqueoDto,
} from '@Bloqueos/dto';
import { Rol } from '@PrismaClient';
import type { AuthenticatedUser } from '@Auth/types';

@ApiTags('bloqueos')
@ApiBearerAuth()
@Roles(Rol.ARRENDADOR)
@ApiUnauthorizedResponse({ description: 'Token ausente, inválido o expirado.' })
@ApiForbiddenResponse({
  description: 'El usuario no es ARRENDADOR o el bien no es suyo.',
})
@Controller('bienes/:bienId/bloqueos')
export class BloqueosController {
  constructor(private readonly bloqueosService: BloqueosService) {}

  @Get()
  @ApiOperation({
    summary: 'Lista los bloqueos vigentes o futuros de un bien propio',
    description:
      'Devuelve cada bloqueo con su id, para poder eliminarlo con `DELETE /bienes/:bienId/bloqueos/:id`. Solo incluye los que terminan hoy (día de El Salvador) o después, ordenados por fecha de inicio ascendente.',
  })
  @ApiOkResponse({ type: BloqueoListadoResponseDto, isArray: true })
  @ApiBadRequestResponse({ description: 'Id de bien inválido.' })
  @ApiNotFoundResponse({ description: 'El bien no existe.' })
  async listar(
    @CurrentUser() usuario: AuthenticatedUser,
    @Param('bienId', ParseUUIDPipe) bienId: string,
  ): Promise<BloqueoListadoResponseDto[]> {
    const bloqueos = await this.bloqueosService.listar(usuario.id, bienId);
    return bloqueos.map((bloqueo) =>
      BloqueoListadoResponseDto.fromEntity(bloqueo),
    );
  }

  @Post()
  @ApiOperation({ summary: 'Bloquea un rango de fechas de un bien propio' })
  @ApiCreatedResponse({ type: BloqueoResponseDto })
  @ApiBadRequestResponse({ description: 'Formato de fecha o de id inválido.' })
  @ApiNotFoundResponse({ description: 'El bien no existe.' })
  @ApiConflictResponse({
    description:
      'El rango incluye una reserva CONFIRMADA o EN_CURSO (trae `reservaId`) o se solapa con otro bloqueo (trae `bloqueoId`).',
  })
  @ApiUnprocessableEntityResponse({
    description: 'El inicio es anterior a hoy o el fin es anterior al inicio.',
  })
  async create(
    @CurrentUser() usuario: AuthenticatedUser,
    @Param('bienId', ParseUUIDPipe) bienId: string,
    @Body() dto: CreateBloqueoDto,
  ): Promise<BloqueoResponseDto> {
    return BloqueoResponseDto.fromEntity(
      await this.bloqueosService.create(usuario.id, bienId, dto),
    );
  }

  @Delete(':id')
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiOperation({ summary: 'Elimina un bloqueo de un bien propio' })
  @ApiNoContentResponse({ description: 'Bloqueo eliminado.' })
  @ApiBadRequestResponse({ description: 'Id inválido.' })
  @ApiNotFoundResponse({ description: 'El bien o el bloqueo no existe.' })
  async delete(
    @CurrentUser() usuario: AuthenticatedUser,
    @Param('bienId', ParseUUIDPipe) bienId: string,
    @Param('id', ParseUUIDPipe) id: string,
  ): Promise<void> {
    await this.bloqueosService.delete(usuario.id, bienId, id);
  }
}
