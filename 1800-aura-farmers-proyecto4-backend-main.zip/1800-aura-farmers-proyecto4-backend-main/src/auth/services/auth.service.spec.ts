import { UnauthorizedException } from '@nestjs/common';
import { AuthService } from './auth.service.js';
import type { UsersService } from '@Users/services';
import type { TokenService } from './token.service.js';
import type { Usuario } from '@PrismaClient';

function crear(usuario: Partial<Usuario> | null) {
  const usersService = {
    findById: vi.fn().mockResolvedValue(usuario),
  } as unknown as UsersService;
  return new AuthService(usersService, {} as TokenService);
}

describe('AuthService.getCurrentUser', () => {
  it('devuelve la entidad completa del usuario activo', async () => {
    const user = { id: '1', isActive: true, rol: 'ARRENDADOR' as const };
    await expect(crear(user).getCurrentUser('1')).resolves.toBe(user);
  });

  it.each([
    ['no existe', null],
    ['está inactivo', { id: '1', isActive: false }],
  ])('responde 401 si el usuario %s', async (_caso, user) => {
    await expect(crear(user).getCurrentUser('1')).rejects.toThrow(
      UnauthorizedException,
    );
  });
});
