import { JwtService } from '@nestjs/jwt';
import { TokenService } from './token.service.js';
import type { ConfigService } from '@nestjs/config';
import type { RefreshTokenRepository } from '@Auth/repositories';
import type { AccessTokenPayload } from '@Auth/types';
import type { Usuario } from '@PrismaClient';

const SECRET = 'secreto-de-prueba-suficientemente-largo';

function usuario(parcial: Partial<Usuario> = {}): Usuario {
  return {
    id: '29bda5e8-0000-4000-8000-000000000001',
    nombreUsuario: 'ana_m',
    email: 'ana@example.com',
    passwordHash: 'hash',
    rol: 'ARRENDADOR',
    isActive: true,
    creadoEn: new Date(),
    actualizadoEn: new Date(),
    ...parcial,
  } as Usuario;
}

function crear(
  repo: Partial<Record<keyof RefreshTokenRepository, unknown>> = {},
) {
  const jwt = new JwtService({
    secret: SECRET,
    signOptions: { expiresIn: '15m' },
  });
  const repository = {
    create: vi.fn().mockResolvedValue(undefined),
    ...repo,
  } as unknown as RefreshTokenRepository;
  const config = { get: () => 7 } as unknown as ConfigService<never, true>;
  return {
    service: new TokenService(repository, jwt, config),
    jwt,
    repository,
  };
}

describe('TokenService', () => {
  describe('issueTokenPair (login)', () => {
    it.each(['ARRENDADOR', 'ARRENDATARIO'] as const)(
      'firma sub, email y rol en el access token (%s)',
      async (rol) => {
        const { service, jwt } = crear();
        const user = usuario({ rol });

        const { accessToken } = await service.issueTokenPair(user);
        const payload = jwt.decode<AccessTokenPayload>(accessToken);

        expect(payload).toMatchObject({ sub: user.id, email: user.email, rol });
      },
    );

    it('mantiene la vigencia de 15 minutos', async () => {
      const { service } = crear();
      const { expiresIn } = await service.issueTokenPair(usuario());
      expect(expiresIn).toBe(15 * 60);
    });
  });

  describe('rotate (refresh)', () => {
    function almacenado(user: Usuario) {
      return {
        id: 'rt-1',
        userId: user.id,
        user,
        revocadoEn: null,
        expiraEn: new Date(Date.now() + 60_000),
      };
    }

    it('el access token nuevo lleva el rol vigente en la base', async () => {
      // El usuario que devuelve la base ya tiene el rol nuevo.
      const enBase = usuario({ rol: 'ARRENDATARIO' });
      const { service, jwt } = crear({
        findByTokenHashWithUser: vi.fn().mockResolvedValue(almacenado(enBase)),
        revokeById: vi.fn().mockResolvedValue(undefined),
      });

      const { tokens } = await service.rotate('refresh-token-viejo');
      const payload = jwt.decode<AccessTokenPayload>(tokens.accessToken);

      expect(payload.rol).toBe('ARRENDATARIO');
      expect(payload.sub).toBe(enBase.id);
    });
  });
});
