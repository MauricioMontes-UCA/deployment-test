import type { Rol } from '@PrismaClient';

/**
 * Payload que viaja dentro del JWT de acceso.
 *
 * El `rol` es para que el frontend decida qué mostrar sin otra llamada. Los
 * permisos no se evalúan con este valor: el guard relee el usuario de la base
 * y usa el rol vigente, así un cambio de rol aplica en la siguiente request.
 */
export interface AccessTokenPayload {
  /** ID del usuario (claim estándar `sub`). */
  sub: string;
  email: string;
  /** Rol vigente al emitir el token. */
  rol: Rol;
}

/**
 * Usuario autenticado que `JwtAuthGuard` adjunta al request y entrega
 * `@CurrentUser()`. Es una vista reducida a propósito: no incluye
 * `passwordHash` ni otros datos que un handler no debería tocar.
 */
export interface AuthenticatedUser {
  id: string;
  email: string;
  nombreUsuario: string;
  /** Rol leído de la base en esta request, no del token. */
  rol: Rol;
}

/** Par de tokens devuelto por login y refresh. */
export interface TokenPair {
  accessToken: string;
  refreshToken: string;
  /** Vigencia del access token, en segundos. */
  expiresIn: number;
}
