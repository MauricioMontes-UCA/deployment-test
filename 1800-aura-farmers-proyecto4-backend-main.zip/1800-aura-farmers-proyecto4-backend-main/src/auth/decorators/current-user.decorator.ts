import { createParamDecorator, ExecutionContext } from '@nestjs/common';
import type { Request } from 'express';
import type { AuthenticatedUser } from '@Auth/types';

export interface RequestWithUser extends Request {
  user?: AuthenticatedUser;
}

/**
 * Extrae el usuario que JwtAuthGuard adjuntó al request: `{ id, email,
 * nombreUsuario, rol }`. Solo tiene sentido en rutas protegidas por el guard.
 */
export const CurrentUser = createParamDecorator(
  (_data: unknown, ctx: ExecutionContext): AuthenticatedUser => {
    const request = ctx.switchToHttp().getRequest<RequestWithUser>();
    return request.user as AuthenticatedUser;
  },
);
