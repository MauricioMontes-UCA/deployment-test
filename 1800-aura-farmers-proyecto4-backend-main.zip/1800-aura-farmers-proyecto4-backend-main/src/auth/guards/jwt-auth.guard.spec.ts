import { UnauthorizedException, type ExecutionContext } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { JwtAuthGuard } from './jwt-auth.guard.js';
import type { Reflector } from '@nestjs/core';
import type { UsersService } from '@Users/services';
import type { RequestWithUser } from '../decorators/current-user.decorator.js';
import type { Usuario } from '@PrismaClient';

const SECRET = 'secreto-de-prueba-suficientemente-largo';
const ID = '29bda5e8-0000-4000-8000-000000000001';

function enBase(parcial: Partial<Usuario> = {}): Usuario {
  return {
    id: ID,
    nombreUsuario: 'ana_m',
    email: 'ana@example.com',
    passwordHash: 'hash',
    rol: 'ARRENDADOR',
    isActive: true,
    ...parcial,
  } as Usuario;
}

function crear(usuario: Usuario | null) {
  const jwt = new JwtService({
    secret: SECRET,
    signOptions: { expiresIn: '15m' },
  });
  const reflector = { getAllAndOverride: () => false } as unknown as Reflector;
  const usersService = {
    findById: vi.fn().mockResolvedValue(usuario),
  } as unknown as UsersService;
  const guard = new JwtAuthGuard(reflector, jwt, usersService);

  const contexto = (authorization?: string) => {
    const request = { headers: { authorization } } as RequestWithUser;
    const context = {
      getHandler: () => undefined,
      getClass: () => undefined,
      switchToHttp: () => ({ getRequest: () => request }),
    } as unknown as ExecutionContext;
    return { request, context };
  };

  return { guard, jwt, contexto };
}

describe('JwtAuthGuard', () => {
  it('adjunta { id, email, nombreUsuario, rol } y nunca passwordHash', async () => {
    const { guard, jwt, contexto } = crear(enBase());
    const token = await jwt.signAsync({
      sub: ID,
      email: 'ana@example.com',
      rol: 'ARRENDADOR',
    });
    const { request, context } = contexto(`Bearer ${token}`);

    await guard.canActivate(context);

    expect(request.user).toEqual({
      id: ID,
      email: 'ana@example.com',
      nombreUsuario: 'ana_m',
      rol: 'ARRENDADOR',
    });
  });

  it('usa el rol de la base aunque el token traiga otro', async () => {
    // El token se emitió cuando era ARRENDATARIO; en la base ya es ARRENDADOR.
    const { guard, jwt, contexto } = crear(enBase({ rol: 'ARRENDADOR' }));
    const token = await jwt.signAsync({
      sub: ID,
      email: 'ana@example.com',
      rol: 'ARRENDATARIO',
    });
    const { request, context } = contexto(`Bearer ${token}`);

    await guard.canActivate(context);

    expect(request.user?.rol).toBe('ARRENDADOR');
  });

  it('rechaza con 401 un token con el rol modificado a mano (firma inválida)', async () => {
    const { guard, jwt, contexto } = crear(enBase());
    const token = await jwt.signAsync({
      sub: ID,
      email: 'ana@example.com',
      rol: 'ARRENDATARIO',
    });
    const [cabecera, , firma] = token.split('.');
    const payloadFalso = Buffer.from(
      JSON.stringify({ sub: ID, email: 'ana@example.com', rol: 'ARRENDADOR' }),
    ).toString('base64url');
    const { context } = contexto(`Bearer ${cabecera}.${payloadFalso}.${firma}`);

    await expect(guard.canActivate(context)).rejects.toThrow(
      UnauthorizedException,
    );
  });

  it('rechaza con 401 si falta el token', async () => {
    const { guard, contexto } = crear(enBase());
    await expect(guard.canActivate(contexto().context)).rejects.toThrow(
      UnauthorizedException,
    );
  });

  it.each([
    ['no existe', null],
    ['está inactivo', enBase({ isActive: false })],
  ])('rechaza con 401 si el usuario %s', async (_caso, usuario) => {
    const { guard, jwt, contexto } = crear(usuario);
    const token = await jwt.signAsync({
      sub: ID,
      email: 'ana@example.com',
      rol: 'ARRENDADOR',
    });
    const { context } = contexto(`Bearer ${token}`);

    await expect(guard.canActivate(context)).rejects.toThrow(
      UnauthorizedException,
    );
  });
});
