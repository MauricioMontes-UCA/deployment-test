import 'reflect-metadata';

import {
  ExecutionContext,
  ForbiddenException,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { Rol } from '@PrismaClient';

import { Public } from '../decorators/public.decorator.js';
import { Roles } from '../decorators/roles.decorator.js';
import { RolesGuard } from './roles.guard.js';

import type { RequestWithUser } from '../decorators/current-user.decorator.js';
import type { Usuario } from '@PrismaClient';

function crearContexto(
  controller: new () => object,
  methodName: string,
  rol?: Rol,
): ExecutionContext {
  const handler = controller.prototype[
    methodName as keyof typeof controller.prototype
  ] as (...args: unknown[]) => unknown;

  const request = {
    user: rol
      ? ({ rol } as Usuario)
      : undefined,
  } as RequestWithUser;

  return {
    getClass: () => controller,
    getHandler: () => handler,
    switchToHttp: () => ({
      getRequest: () => request,
    }),
  } as unknown as ExecutionContext;
}

describe('RolesGuard', () => {
  let guard: RolesGuard;

  beforeEach(() => {
    guard = new RolesGuard(new Reflector());
  });

  describe('rutas protegidas por rol', () => {
    class BienesController {
      @Roles(Rol.ARRENDADOR)
      crear() {}
    }

    it('permite acceder a un ARRENDADOR autorizado', () => {
      const context = crearContexto(
        BienesController,
        'crear',
        Rol.ARRENDADOR,
      );

      expect(guard.canActivate(context)).toBe(true);
    });

    it('rechaza con 403 a un ARRENDATARIO', () => {
      const context = crearContexto(
        BienesController,
        'crear',
        Rol.ARRENDATARIO,
      );

      expect(() => guard.canActivate(context)).toThrow(
        ForbiddenException,
      );
    });

    it('devuelve el mensaje de error requerido', () => {
      const context = crearContexto(
        BienesController,
        'crear',
        Rol.ARRENDATARIO,
      );

      try {
        guard.canActivate(context);
        throw new Error('Se esperaba ForbiddenException');
      } catch (error) {
        expect(error).toBeInstanceOf(ForbiddenException);

        const exception = error as ForbiddenException;

        expect(exception.getStatus()).toBe(403);
        expect(exception.getResponse()).toEqual({
          message:
            'No tienes permiso para realizar esta acción.',
          error: 'Forbidden',
          statusCode: 403,
        });
      }
    });

    it('rechaza una ruta con roles cuando no hay usuario', () => {
      const context = crearContexto(
        BienesController,
        'crear',
      );

      expect(() => guard.canActivate(context)).toThrow(
        ForbiddenException,
      );
    });
  });

  describe('rutas sin @Roles()', () => {
    class PerfilController {
      consultar() {}
    }

    it('permite ambos roles', () => {
      const arrendador = crearContexto(
        PerfilController,
        'consultar',
        Rol.ARRENDADOR,
      );

      const arrendatario = crearContexto(
        PerfilController,
        'consultar',
        Rol.ARRENDATARIO,
      );

      expect(guard.canActivate(arrendador)).toBe(true);
      expect(guard.canActivate(arrendatario)).toBe(true);
    });
  });

  describe('rutas públicas', () => {
    class AuthController {
      @Public()
      login() {}

      @Public()
      @Roles(Rol.ARRENDADOR)
      registroPublico() {}
    }

    it('permite acceder sin token', () => {
      const context = crearContexto(
        AuthController,
        'login',
      );

      expect(guard.canActivate(context)).toBe(true);
    });

    it('ignora @Roles() cuando la ruta es pública', () => {
      const context = crearContexto(
        AuthController,
        'registroPublico',
      );

      expect(guard.canActivate(context)).toBe(true);
    });
  });

  describe('metadatos a nivel de clase', () => {
    @Roles(Rol.ARRENDADOR)
    class AdministracionController {
      consultar() {}

      @Roles(Rol.ARRENDATARIO)
      accionArrendatario() {}

      @Roles()
      accesoDenegado() {}
    }

    it('aplica el rol de clase a los métodos sin @Roles()', () => {
      const autorizado = crearContexto(
        AdministracionController,
        'consultar',
        Rol.ARRENDADOR,
      );

      const rechazado = crearContexto(
        AdministracionController,
        'consultar',
        Rol.ARRENDATARIO,
      );

      expect(guard.canActivate(autorizado)).toBe(true);

      expect(() => guard.canActivate(rechazado)).toThrow(
        ForbiddenException,
      );
    });

    it('permite que el rol del método sobrescriba el de clase', () => {
      const autorizado = crearContexto(
        AdministracionController,
        'accionArrendatario',
        Rol.ARRENDATARIO,
      );

      const rechazado = crearContexto(
        AdministracionController,
        'accionArrendatario',
        Rol.ARRENDADOR,
      );

      expect(guard.canActivate(autorizado)).toBe(true);

      expect(() => guard.canActivate(rechazado)).toThrow(
        ForbiddenException,
      );
    });

    it('interpreta @Roles() vacío como ningún rol autorizado', () => {
      const context = crearContexto(
        AdministracionController,
        'accesoDenegado',
        Rol.ARRENDADOR,
      );

      expect(() => guard.canActivate(context)).toThrow(
        ForbiddenException,
      );
    });
  });
});