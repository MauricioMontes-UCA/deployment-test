/**
 * Error de dominio: el nombre de usuario ya está registrado.
 *
 * Lo lanza el repositorio al detectar la violación de unicidad sobre
 * `nombre_usuario`; el servicio lo traduce a un 409. Es hermano de
 * `EmailAlreadyTakenError` para que cada colisión tenga su propio mensaje.
 */
export class UsernameAlreadyTakenError extends Error {
  constructor(public readonly nombreUsuario: string) {
    super(`El nombre de usuario "${nombreUsuario}" ya está registrado.`);
    this.name = 'UsernameAlreadyTakenError';
  }
}
