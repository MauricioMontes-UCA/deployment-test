import { ConflictException, Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import bcrypt from 'bcrypt';
import { UserRepository } from '@Users/repositories';
import {
  EmailAlreadyTakenError,
  UsernameAlreadyTakenError,
} from '@Users/errors';
import type { CreateUserDto } from '@Users/dto';
import type { EnvConfig } from '@Config';
import type { Usuario } from '@PrismaClient';

/**
 * Lógica de negocio de usuarios.
 *
 * No conoce Prisma: todo el acceso a datos pasa por UserRepository.
 */
@Injectable()
export class UsersService {
  private readonly saltRounds: number;

  constructor(
    private readonly userRepository: UserRepository,
    configService: ConfigService<EnvConfig, true>,
  ) {
    this.saltRounds = configService.get('BCRYPT_SALT_ROUNDS', { infer: true });
  }

  async create({
    nombreUsuario,
    email,
    rol,
    password,
  }: CreateUserDto): Promise<Usuario> {
    const passwordHash = await this.hashPassword(password);

    try {
      return await this.userRepository.create({
        nombreUsuario,
        email,
        rol,
        passwordHash,
      });
    } catch (error) {
      // Traduce el error de dominio del repositorio a una excepción HTTP.
      if (error instanceof EmailAlreadyTakenError) {
        throw new ConflictException('El email ya está registrado.');
      }
      if (error instanceof UsernameAlreadyTakenError) {
        throw new ConflictException('El nombre de usuario ya está registrado.');
      }
      throw error;
    }
  }

  findByEmail(email: string): Promise<Usuario | null> {
    return this.userRepository.findByEmail(email);
  }

  findById(id: string): Promise<Usuario | null> {
    return this.userRepository.findById(id);
  }

  hashPassword(password: string): Promise<string> {
    return bcrypt.hash(password, this.saltRounds);
  }

  verifyPassword(password: string, passwordHash: string): Promise<boolean> {
    return bcrypt.compare(password, passwordHash);
  }
}
