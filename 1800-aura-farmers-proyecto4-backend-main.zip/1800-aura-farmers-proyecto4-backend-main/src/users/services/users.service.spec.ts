import { ConflictException } from '@nestjs/common';
import {
  EmailAlreadyTakenError,
  UsernameAlreadyTakenError,
} from '@Users/errors';
import { UsersService } from './users.service.js';
import type { ConfigService } from '@nestjs/config';
import type { UserRepository } from '@Users/repositories';

const dto = {
  nombreUsuario: 'ana_m',
  email: 'ana@example.com',
  password: 'Str0ngPass',
  rol: 'ARRENDATARIO' as const,
};

function crearServicio(create: ReturnType<typeof vi.fn>) {
  const config = { get: () => 4 } as unknown as ConfigService<never, true>;
  return new UsersService({ create } as unknown as UserRepository, config);
}

describe('UsersService.create', () => {
  it('pasa nombre de usuario y rol al repositorio y hashea la contraseña', async () => {
    const create = vi.fn().mockResolvedValue({ id: '1' });
    await crearServicio(create).create(dto);
    const arg = create.mock.calls[0]![0] as Record<string, string>;
    expect(arg).toMatchObject({
      nombreUsuario: 'ana_m',
      email: 'ana@example.com',
      rol: 'ARRENDATARIO',
    });
    expect(arg.passwordHash).not.toBe(dto.password);
  });

  it('responde 409 si el nombre de usuario ya existe', async () => {
    const create = vi
      .fn()
      .mockRejectedValue(new UsernameAlreadyTakenError('ana_m'));
    await expect(crearServicio(create).create(dto)).rejects.toThrow(
      ConflictException,
    );
  });

  it('responde 409 si el email ya existe', async () => {
    const create = vi
      .fn()
      .mockRejectedValue(new EmailAlreadyTakenError('ana@example.com'));
    await expect(crearServicio(create).create(dto)).rejects.toThrow(
      ConflictException,
    );
  });
});
