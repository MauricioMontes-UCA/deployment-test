import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsIn, IsString, Matches, MaxLength, MinLength } from 'class-validator';
import { IsNormalizedEmail } from '@Common/decorators';

/** Roles que una persona puede elegir al registrarse. */
export const ROLES_REGISTRABLES = ['ARRENDADOR', 'ARRENDATARIO'] as const;
export type RolRegistrable = (typeof ROLES_REGISTRABLES)[number];

export class CreateUserDto {
  @ApiProperty({
    description:
      'Nombre de usuario único. Solo letras, números, punto, guion y guion bajo. Se guarda en minúsculas.',
    example: 'ana_m',
    minLength: 3,
    maxLength: 30,
    pattern: '^[A-Za-z0-9._-]+$',
  })
  // El Transform corre antes de validar, así que "Ana_M" se guarda como "ana_m"
  // y la unicidad no distingue mayúsculas.
  @Transform(({ value }: { value: unknown }) =>
    typeof value === 'string' ? value.trim().toLowerCase() : value,
  )
  @IsString({ message: 'El nombre de usuario es obligatorio.' })
  @MinLength(3, {
    message: 'El nombre de usuario debe tener al menos 3 caracteres.',
  })
  @MaxLength(30, {
    message: 'El nombre de usuario no puede superar los 30 caracteres.',
  })
  @Matches(/^[A-Za-z0-9._-]+$/, {
    message:
      'El nombre de usuario solo puede incluir letras, números, punto, guion y guion bajo.',
  })
  nombreUsuario!: string;

  @ApiProperty({
    description: 'Email del usuario. Se normaliza a minúsculas y sin espacios.',
    example: 'nestor@example.com',
    format: 'email',
    maxLength: 254,
  })
  @IsNormalizedEmail()
  email!: string;

  @ApiProperty({
    description:
      'Contraseña. Debe incluir al menos una minúscula, una mayúscula y un número.',
    example: 'Str0ngPass',
    minLength: 8,
    maxLength: 72,
  })
  @IsString()
  @MinLength(8, { message: 'La contraseña debe tener al menos 8 caracteres.' })
  // bcrypt trunca silenciosamente en 72 bytes, así que se rechaza antes de hashear.
  @MaxLength(72, {
    message: 'La contraseña no puede superar los 72 caracteres.',
  })
  @Matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).+$/, {
    message:
      'La contraseña debe incluir al menos una minúscula, una mayúscula y un número.',
  })
  password!: string;

  @ApiProperty({
    description: 'Rol de la cuenta.',
    enum: ROLES_REGISTRABLES,
    example: 'ARRENDADOR',
  })
  @IsIn(ROLES_REGISTRABLES, {
    message: `El rol debe ser uno de: ${ROLES_REGISTRABLES.join(', ')}.`,
  })
  rol!: RolRegistrable;
}
