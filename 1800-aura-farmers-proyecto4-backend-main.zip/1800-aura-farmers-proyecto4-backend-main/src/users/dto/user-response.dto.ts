import { ApiProperty } from '@nestjs/swagger';
import { Rol, type Usuario } from '@PrismaClient';

/**
 * Forma pública de un usuario.
 *
 * Los controladores devuelven esto y nunca la fila cruda de Prisma, para que
 * `passwordHash` no pueda filtrarse en una respuesta por descuido.
 */
export class UserResponseDto {
  @ApiProperty({ format: 'uuid' })
  id!: string;

  @ApiProperty({ example: 'ana_m' })
  nombreUsuario!: string;

  @ApiProperty({ example: 'nestor@example.com', format: 'email' })
  email!: string;

  @ApiProperty({ enum: Rol, enumName: 'Rol', example: Rol.ARRENDADOR })
  rol!: Rol;

  @ApiProperty()
  isActive!: boolean;

  @ApiProperty({ type: String, format: 'date-time' })
  createdAt!: Date;

  static fromEntity(user: Usuario): UserResponseDto {
    return {
      id: user.id,
      nombreUsuario: user.nombreUsuario,
      email: user.email,
      rol: user.rol,
      isActive: user.isActive,
      createdAt: user.creadoEn,
    };
  }
}
