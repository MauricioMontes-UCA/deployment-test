import { plainToInstance } from 'class-transformer';
import { validate } from 'class-validator';
import { CreateUserDto } from './create-user.dto.js';

const base = {
  nombreUsuario: 'ana_m',
  email: 'ana@example.com',
  password: 'Str0ngPass',
  rol: 'ARRENDADOR',
};

async function errores(parcial: Record<string, unknown>) {
  const dto = plainToInstance(CreateUserDto, { ...base, ...parcial });
  const result = await validate(dto);
  return { dto, campos: result.map((e) => e.property) };
}

describe('CreateUserDto', () => {
  describe('nombreUsuario', () => {
    it('acepta un nombre válido', async () => {
      expect((await errores({})).campos).toEqual([]);
    });

    it('lo convierte a minúsculas antes de guardar', async () => {
      const { dto, campos } = await errores({ nombreUsuario: 'Ana_M' });
      expect(campos).toEqual([]);
      expect(dto.nombreUsuario).toBe('ana_m');
    });

    it.each(['ab', 'a'.repeat(31)])(
      'rechaza una longitud fuera de 3-30 (%s)',
      async (nombre) => {
        expect((await errores({ nombreUsuario: nombre })).campos).toContain(
          'nombreUsuario',
        );
      },
    );

    it.each(['ana m', 'ana@m', 'aña', 'ana!'])(
      'rechaza un formato inválido (%s)',
      async (nombre) => {
        expect((await errores({ nombreUsuario: nombre })).campos).toContain(
          'nombreUsuario',
        );
      },
    );

    it('rechaza un nombre faltante', async () => {
      expect((await errores({ nombreUsuario: undefined })).campos).toContain(
        'nombreUsuario',
      );
    });
  });

  describe('rol', () => {
    it.each(['ARRENDADOR', 'ARRENDATARIO'])('acepta %s', async (rol) => {
      expect((await errores({ rol })).campos).toEqual([]);
    });

    it('rechaza un rol faltante', async () => {
      expect((await errores({ rol: undefined })).campos).toContain('rol');
    });

    it.each(['ADMIN', 'arrendador', ''])(
      'rechaza un rol no permitido (%s)',
      async (rol) => {
        expect((await errores({ rol })).campos).toContain('rol');
      },
    );
  });
});
