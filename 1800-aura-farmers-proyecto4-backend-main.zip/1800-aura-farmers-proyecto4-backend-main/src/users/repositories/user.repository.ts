import { ConflictException, Injectable } from '@nestjs/common';import { PrismaService } from '@Prisma/services';
import {
  EmailAlreadyTakenError,
  UsernameAlreadyTakenError,
} from '@Users/errors';
import { Prisma, type Rol, type Usuario } from '@PrismaClient';

/** Código de Prisma para violación de restricción única. */
const UNIQUE_CONSTRAINT_VIOLATION = 'P2002';

export interface CreateUserData {
  nombreUsuario: string;
  email: string;
  rol: Rol;
  passwordHash: string;
}

/**
 * Único punto del módulo que habla con la tabla `Usuarios`.
 *
 * Los servicios no conocen Prisma: reciben y devuelven entidades, y los
 * detalles del ORM (códigos de error, formas de `where`, `select`) quedan
 * encapsulados acá. Eso permite cambiar el acceso a datos sin tocar la lógica
 * de negocio, y testear los servicios con un doble de este repositorio.
 */
@Injectable()
export class UserRepository {
  constructor(private readonly prisma: PrismaService) {}

  /**
   * @throws {EmailAlreadyTakenError} si el email ya está registrado.
   * @throws {UsernameAlreadyTakenError} si el nombre de usuario ya está registrado.
   *
   * Se deja que la base decida la unicidad en vez de consultar antes: un
   * `findUnique` previo tiene una condición de carrera entre la lectura y el
   * insert. El código P2002 de Prisma se traduce a un error de dominio para
   * que la capa de servicio no tenga que conocer los códigos del ORM.
   */
  async create({
    nombreUsuario,
    email,
    rol,
    passwordHash,
  }: CreateUserData): Promise<Usuario> {
    try {
      return await this.prisma.usuario.create({
        data: {
          nombreUsuario: this.normalizeUsername(nombreUsuario),
          email: this.normalizeEmail(email),
          rol,
          passwordHash,
        },
      });
    } catch (error) {
      if (
        error instanceof Prisma.PrismaClientKnownRequestError &&
        error.code === UNIQUE_CONSTRAINT_VIOLATION
      ) {
        const campo = this.obtenerCampoUnico(error);
        
        if (campo === 'nombreUsuario') {
          throw new UsernameAlreadyTakenError(nombreUsuario);
        }
        
        if (campo === 'email') {
          throw new EmailAlreadyTakenError(email);
        }

        throw new ConflictException(
          'El correo electrónico o el nombre de usuario ya está registrado.',
        );
      }

      throw error;
    }
  }

  findById(id: string): Promise<Usuario | null> {
    return this.prisma.usuario.findUnique({ where: { id } });
  }

  findByEmail(email: string): Promise<Usuario | null> {
    return this.prisma.usuario.findUnique({
      where: { email: this.normalizeEmail(email) },
    });
  }

  existsByEmail(email: string): Promise<boolean> {
    return this.prisma.usuario
      .count({ where: { email: this.normalizeEmail(email) } })
      .then((count) => count > 0);
  }

  updatePasswordHash(id: string, passwordHash: string): Promise<Usuario> {
    return this.prisma.usuario.update({
      where: { id },
      data: { passwordHash },
    });
  }

  setActive(id: string, isActive: boolean): Promise<Usuario> {
    return this.prisma.usuario.update({ where: { id }, data: { isActive } });
  }

  deleteById(id: string): Promise<Usuario> {
    return this.prisma.usuario.delete({ where: { id } });
  }

  /**
   * Los emails se persisten y se consultan en minúsculas.
   *
   * El índice único de Postgres es sensible a mayúsculas, así que sin esto
   * "Demo@mail.com" y "demo@mail.com" serían dos cuentas distintas y el login
   * fallaría según cómo el usuario escribiera su email. Va en el repositorio a
   * propósito: es el único punto por el que pasan todas las lecturas y
   * escrituras, así que ningún llamador puede saltearse la normalización.
   */
  private normalizeEmail(email: string): string {
    return email.trim().toLowerCase();
  }
  
  /** Igual que el email: el índice único es sensible a mayúsculas. */
  private normalizeUsername(nombreUsuario: string): string {
    return nombreUsuario.trim().toLowerCase();
  }
  
  private obtenerCampoUnico(
  error: Prisma.PrismaClientKnownRequestError,
  ): 'email' | 'nombreUsuario' | null {
    const meta = error.meta;
    
    if (!meta || typeof meta !== 'object') {
      return null;
    }
    
    // Prisma puede devolver target como lista de columnas.
    const target = (meta as Record<string, unknown>).target;
    
    if (Array.isArray(target)) {
      const columnas = target.filter(
        (valor): valor is string => typeof valor === 'string',
      );
      
      if (columnas.length !== 1) {
        return null;
      }

      return this.identificarCampo(columnas[0]);
    }

    // Con driver adapters, la información puede estar anidada.
    // Se inspeccionan los valores disponibles sin realizar consultas.
    const mensajes: string[] = [];
    
    const recorrer = (valor: unknown, profundidad = 0): void => {
      if (profundidad > 6 || valor == null) {
        return;
      }

      if (typeof valor === 'string') {
        mensajes.push(valor);
        return;
      }

      if (Array.isArray(valor)) {
        for (const elemento of valor) {
          recorrer(elemento, profundidad + 1);
        }
        return;
      }
      
      if (typeof valor === 'object') {
        for (const [clave, contenido] of Object.entries(valor)) {
          // Evitar tratar nombres de propiedades genéricas como campos.
          if (
            clave === 'constraint' ||
            clave === 'index' ||
            clave === 'column' ||
            clave === 'originalMessage' ||
            clave === 'message' ||
            clave === 'target'
          ) {
            recorrer(contenido, profundidad + 1);
          } else if (typeof contenido === 'object') {
            recorrer(contenido, profundidad + 1);
          }
        }
      }
    };
    
    recorrer(meta);
    
    const campos = new Set<'email' | 'nombreUsuario'>();
    
    for (const mensaje of mensajes) {
      const campo = this.identificarCampo(mensaje);
      
      if (campo) {
        campos.add(campo);
      }
    }
    
    // Si hay información contradictoria, no se adivina.
    if (campos.size !== 1) {
      return null;
    }

    return [...campos][0];
  }

  private identificarCampo(
    valor: string,
  ): 'email' | 'nombreUsuario' | null {
    const texto = valor.toLowerCase();
    
    // Identificar nombres de columnas o restricciones que los contengan.
    const contieneEmail = /(?:^|[^a-z0-9])email(?:$|[^a-z0-9])/.test(texto);

    const contieneUsername =
      /(?:^|[^a-z0-9])nombre_?usuario(?:$|[^a-z0-9])/.test(texto);

    if (contieneEmail === contieneUsername) {
      return null;
    }

    return contieneEmail ? 'email' : 'nombreUsuario';
  }
}
