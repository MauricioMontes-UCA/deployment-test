import { ConflictException } from '@nestjs/common';
import { Prisma } from '@PrismaClient';
import type { PrismaService } from '@Prisma/services';
import {
  EmailAlreadyTakenError,
  UsernameAlreadyTakenError,
} from '@Users/errors';
import { UserRepository } from './user.repository.js';

function p2002(meta: Record<string, unknown>) {
  return new Prisma.PrismaClientKnownRequestError(
    'Unique constraint failed',
    {
      code: 'P2002',
      clientVersion: 'test',
      meta,
    },
  );
}

function crearRepo(
  create: ReturnType<typeof vi.fn>,
  findUnique = vi.fn(),
) {
  return {
    repo: new UserRepository({
      usuario: {
        create,
        findUnique,
      },
    } as unknown as PrismaService),
    findUnique,
  };
}

const datos = {
  nombreUsuario: 'Ana_M',
  email: 'Ana@Example.com',
  rol: 'ARRENDADOR' as const,
  passwordHash: 'hash',
};

describe('UserRepository.create', () => {
  it('guarda nombre de usuario y email en minúsculas junto con el rol', async () => {
    const create = vi.fn().mockResolvedValue({ id: '1' });
    const { repo } = crearRepo(create);

    await repo.create(datos);

    expect(create).toHaveBeenCalledWith({
      data: {
        nombreUsuario: 'ana_m',
        email: 'ana@example.com',
        rol: 'ARRENDADOR',
        passwordHash: 'hash',
      },
    });
  });

  it('lanza UsernameAlreadyTakenError si choca el nombre de usuario', async () => {
    const create = vi.fn().mockRejectedValue(
      p2002({ target: ['nombre_usuario'] }),
    );

    const { repo } = crearRepo(create);

    await expect(repo.create(datos)).rejects.toBeInstanceOf(
      UsernameAlreadyTakenError,
    );
  });

  it('lanza EmailAlreadyTakenError si choca el email', async () => {
    const create = vi.fn().mockRejectedValue(
      p2002({ target: ['email'] }),
    );

    const { repo } = crearRepo(create);

    await expect(repo.create(datos)).rejects.toBeInstanceOf(
      EmailAlreadyTakenError,
    );
  });

  it('propaga errores distintos de P2002', async () => {
    const create = vi.fn().mockRejectedValue(
      new Error('boom'),
    );

    const { repo } = crearRepo(create);

    await expect(repo.create(datos)).rejects.toThrow('boom');
  });

  it('devuelve conflicto genérico cuando Prisma no proporciona metadatos', async () => {
    const create = vi.fn().mockRejectedValue(p2002({}));
    const { repo } = crearRepo(create);

    await expect(repo.create(datos)).rejects.toBeInstanceOf(
      ConflictException,
    );
  });

  it('devuelve HTTP 409 cuando no puede identificar la restricción', async () => {
    const create = vi.fn().mockRejectedValue(p2002({}));
    const { repo } = crearRepo(create);

    await expect(repo.create(datos)).rejects.toMatchObject({
      status: 409,
      message:
        'El correo electrónico o el nombre de usuario ya está registrado.',
    });
  });

  it('identifica email desde metadatos del driver adapter', async () => {
    const create = vi.fn().mockRejectedValue(
      p2002({
        driverAdapterError: {
          cause: {
            constraint: {
              index: 'Usuarios_EMAIL_key',
            },
          },
        },
      }),
    );

    const { repo } = crearRepo(create);

    await expect(repo.create(datos)).rejects.toBeInstanceOf(
      EmailAlreadyTakenError,
    );
  });

  it('identifica nombreUsuario desde metadatos del driver adapter', async () => {
    const create = vi.fn().mockRejectedValue(
      p2002({
        driverAdapterError: {
          cause: {
            constraint: {
              index: 'Usuarios_NOMBRE_USUARIO_key',
            },
          },
        },
      }),
    );

    const { repo } = crearRepo(create);

    await expect(repo.create(datos)).rejects.toBeInstanceOf(
      UsernameAlreadyTakenError,
    );
  });

  it('identifica email mediante el nombre de la restricción', async () => {
    const create = vi.fn().mockRejectedValue(
      p2002({
        driverAdapterError: {
          cause: {
            constraint: {
              index: 'usuarios_email_key',
            },
          },
        },
      }),
    );

    const { repo } = crearRepo(create);

    await expect(repo.create(datos)).rejects.toBeInstanceOf(
      EmailAlreadyTakenError,
    );
  });

  it('identifica username mediante el nombre de la restricción', async () => {
    const create = vi.fn().mockRejectedValue(
      p2002({
        driverAdapterError: {
          cause: {
            constraint: {
              index: 'usuarios_nombre_usuario_key',
            },
          },
        },
      }),
    );

    const { repo } = crearRepo(create);

    await expect(repo.create(datos)).rejects.toBeInstanceOf(
      UsernameAlreadyTakenError,
    );
  });

  it('devuelve conflicto genérico cuando la restricción es desconocida', async () => {
    const create = vi.fn().mockRejectedValue(
      p2002({
        driverAdapterError: {
          cause: {
            constraint: {
              index: 'restriccion_123',
            },
          },
        },
      }),
    );

    const { repo } = crearRepo(create);

    await expect(repo.create(datos)).rejects.toBeInstanceOf(
      ConflictException,
    );
  });

  it('no atribuye el conflicto a un campo cuando los metadatos son ambiguos', async () => {
    const create = vi.fn().mockRejectedValue(
      p2002({
        target: ['email', 'nombre_usuario'],
      }),
    );

    const { repo } = crearRepo(create);

    await expect(repo.create(datos)).rejects.toBeInstanceOf(
      ConflictException,
    );
  });

  it('no realiza consultas adicionales después de un P2002', async () => {
    const create = vi.fn().mockRejectedValue(
      p2002({
        driverAdapterError: {
          cause: {
            constraint: {
              index: 'restriccion_desconocida',
            },
          },
        },
      }),
    );

    const { repo, findUnique } = crearRepo(create);

    await expect(repo.create(datos)).rejects.toBeInstanceOf(
      ConflictException,
    );

    expect(findUnique).not.toHaveBeenCalled();
    expect(create).toHaveBeenCalledTimes(1);
  });
});
