import { Module } from '@nestjs/common';
import { ResenasController } from '@Resenas/controllers';
import { ResenasService } from '@Resenas/services';
import { ResenaRepository } from '@Resenas/repositories';

/**
 * Dueño de las reseñas y de la calificación de un bien. No depende de
 * BienesModule: es BienesModule quien lo importa para mostrar la calificación
 * en el detalle y el listado de reseñas bajo `/bienes`.
 */
@Module({
  controllers: [ResenasController],
  providers: [ResenasService, ResenaRepository],
  exports: [ResenasService],
})
export class ResenasModule {}
