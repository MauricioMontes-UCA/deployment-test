import { Prisma } from '@PrismaClient';
import type { PrismaService } from '@Prisma/services';
import {
  motivoNoCalificable,
  ResenaRepository,
  type RegistrarResenasData,
  type ReservaParaResena,
} from './resena.repository.js';

const RESERVA_ID = '11111111-1111-4111-8111-111111111111';
const ARRENDATARIO_ID = '22222222-2222-4222-8222-222222222222';
const FINALIZADA_EN = new Date('2026-12-01T16:00:00.000Z');
const AHORA = new Date('2026-12-05T16:00:00.000Z');

function reserva(cambios: Partial<ReservaParaResena> = {}): ReservaParaResena {
  return {
    arrendatarioId: ARRENDATARIO_ID,
    estado: 'FINALIZADA',
    finalizadaEn: FINALIZADA_EN,
    resenas: [],
    ...cambios,
  };
}

const datos: RegistrarResenasData = {
  reservaId: RESERVA_ID,
  arrendatarioId: ARRENDATARIO_ID,
  bien: { puntuacion: 5, comentario: 'Todo en orden.' },
  arrendador: { puntuacion: 4 },
  ahora: AHORA,
};

function crear(leida: ReservaParaResena | null = reserva()) {
  const tx = {
    reserva: { findUnique: vi.fn().mockResolvedValue(leida) },
    resena: {
      create: vi.fn(({ data }: { data: { tipo: string } }) =>
        Promise.resolve({ id: `resena-${data.tipo}`, ...data }),
      ),
    },
  };
  const prisma = {
    $transaction: vi.fn((callback: (cliente: typeof tx) => unknown) =>
      callback(tx),
    ),
  };
  return {
    repository: new ResenaRepository(prisma as unknown as PrismaService),
    prisma,
    tx,
  };
}

describe('motivoNoCalificable', () => {
  it('una reserva propia, FINALIZADA, sin reseñas y en plazo se puede calificar', () => {
    expect(motivoNoCalificable(reserva(), ARRENDATARIO_ID, AHORA)).toBeNull();
  });

  it.each([
    ['no existe', null, 'NO_EXISTE'],
    [
      'es de otro arrendatario',
      reserva({ arrendatarioId: 'otro' }),
      'NO_EXISTE',
    ],
    ['ya tiene reseñas', reserva({ resenas: [{ id: 'r' }] }), 'YA_CALIFICADA'],
    ['no está FINALIZADA', reserva({ estado: 'EN_CURSO' }), 'NO_FINALIZADA'],
    [
      'no tiene finalizadaEn',
      reserva({ finalizadaEn: null }),
      'FUERA_DE_PLAZO',
    ],
  ] as const)('si la reserva %s: %s', (_caso, valor, motivo) => {
    expect(motivoNoCalificable(valor, ARRENDATARIO_ID, AHORA)).toBe(motivo);
  });

  it('el día 14 desde la finalización se permite y el 15 no', () => {
    const dia14 = new Date('2026-12-15T16:00:00.000Z');
    const dia15 = new Date('2026-12-16T16:00:00.000Z');

    expect(motivoNoCalificable(reserva(), ARRENDATARIO_ID, dia14)).toBeNull();
    expect(motivoNoCalificable(reserva(), ARRENDATARIO_ID, dia15)).toBe(
      'FUERA_DE_PLAZO',
    );
  });

  it('no revela el estado de una reserva ajena', () => {
    const ajena = reserva({ arrendatarioId: 'otro', estado: 'EN_COLA' });

    expect(motivoNoCalificable(ajena, ARRENDATARIO_ID, AHORA)).toBe(
      'NO_EXISTE',
    );
  });
});

describe('ResenaRepository.registrarResenasDeReserva', () => {
  it('guarda primero la reseña del bien y luego la del arrendador, con el arrendatario como autor', async () => {
    const { repository, tx } = crear();

    const resultado = await repository.registrarResenasDeReserva(datos);

    expect(tx.resena.create.mock.calls.map(([{ data }]) => data)).toEqual([
      {
        reservaId: RESERVA_ID,
        autorId: ARRENDATARIO_ID,
        tipo: 'BIEN',
        puntuacion: 5,
        comentario: 'Todo en orden.',
        creadaEn: AHORA,
      },
      {
        reservaId: RESERVA_ID,
        autorId: ARRENDATARIO_ID,
        tipo: 'ARRENDADOR',
        puntuacion: 4,
        comentario: null,
        creadaEn: AHORA,
      },
    ]);
    expect(resultado).toMatchObject({
      resenaBien: { id: 'resena-BIEN' },
      resenaArrendador: { id: 'resena-ARRENDADOR' },
    });
  });

  it('valida la reserva dentro de la misma transacción', async () => {
    const { repository, prisma, tx } = crear();

    await repository.registrarResenasDeReserva(datos);

    expect(prisma.$transaction).toHaveBeenCalledTimes(1);
    expect(tx.reserva.findUnique).toHaveBeenCalledWith(
      expect.objectContaining({ where: { id: RESERVA_ID } }),
    );
  });

  it('si la reserva no se puede calificar, no guarda nada', async () => {
    const { repository, tx } = crear(reserva({ estado: 'CONFIRMADA' }));

    expect(await repository.registrarResenasDeReserva(datos)).toEqual({
      rechazo: 'NO_FINALIZADA',
    });
    expect(tx.resena.create).not.toHaveBeenCalled();
  });

  it('si falla la segunda reseña, el error sale de la transacción para que se revierta', async () => {
    const { repository, tx } = crear();
    tx.resena.create
      .mockResolvedValueOnce({ id: 'resena-BIEN', tipo: 'BIEN' })
      .mockRejectedValueOnce(new Error('falló el insert'));

    await expect(repository.registrarResenasDeReserva(datos)).rejects.toThrow(
      'falló el insert',
    );
  });

  it('traduce la violación del índice único (P2002) a YA_CALIFICADA', async () => {
    const { repository, prisma } = crear();
    prisma.$transaction.mockRejectedValueOnce(
      new Prisma.PrismaClientKnownRequestError('Unique constraint failed', {
        code: 'P2002',
        clientVersion: 'test',
      }),
    );

    expect(await repository.registrarResenasDeReserva(datos)).toEqual({
      rechazo: 'YA_CALIFICADA',
    });
  });
});
