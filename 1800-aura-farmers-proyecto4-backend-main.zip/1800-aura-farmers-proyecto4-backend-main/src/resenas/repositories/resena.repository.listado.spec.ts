import type { PrismaService } from '@Prisma/services';
import { RESENAS_POR_PAGINA, ResenaRepository } from './resena.repository.js';

const BIEN_ID = '7c9e6679-7425-40de-944b-e07fc1f90ae7';

function crear(items: unknown[] = [], total = 0) {
  const prisma = {
    resena: {
      findMany: vi.fn().mockReturnValue('consulta-items'),
      count: vi.fn().mockReturnValue('consulta-total'),
    },
    $transaction: vi.fn().mockResolvedValue([items, total]),
  };
  return {
    repository: new ResenaRepository(prisma as unknown as PrismaService),
    prisma,
  };
}

describe('ResenaRepository.listarDeBien', () => {
  it('lee solo reseñas BIEN del bien, de la más reciente a la más antigua', async () => {
    const { repository, prisma } = crear();

    await repository.listarDeBien(BIEN_ID, 1);

    expect(prisma.resena.findMany).toHaveBeenCalledWith({
      where: { tipo: 'BIEN', reserva: { bienId: BIEN_ID } },
      select: {
        id: true,
        puntuacion: true,
        comentario: true,
        creadaEn: true,
        autor: { select: { nombreUsuario: true } },
      },
      orderBy: [{ creadaEn: 'desc' }, { id: 'desc' }],
      skip: 0,
      take: RESENAS_POR_PAGINA,
    });
    expect(prisma.resena.count).toHaveBeenCalledWith({
      where: { tipo: 'BIEN', reserva: { bienId: BIEN_ID } },
    });
    expect(prisma.$transaction).toHaveBeenCalledWith([
      'consulta-items',
      'consulta-total',
    ]);
  });

  it('salta las páginas anteriores', async () => {
    const { repository, prisma } = crear();

    await repository.listarDeBien(BIEN_ID, 3);

    expect(prisma.resena.findMany).toHaveBeenCalledWith(
      expect.objectContaining({ skip: 2 * RESENAS_POR_PAGINA, take: 10 }),
    );
  });

  it('devuelve las reseñas y el total', async () => {
    const items = [{ id: 'r1' }];
    const { repository } = crear(items, 11);

    await expect(repository.listarDeBien(BIEN_ID, 1)).resolves.toEqual({
      items,
      total: 11,
    });
  });
});

describe('ResenaRepository.calificacionDeBien', () => {
  function crearConAgregado(agregado: unknown) {
    const prisma = {
      resena: { aggregate: vi.fn().mockResolvedValue(agregado) },
    };
    return {
      repository: new ResenaRepository(prisma as unknown as PrismaService),
      prisma,
    };
  }

  it('agrega solo las reseñas de tipo BIEN de las reservas del bien', async () => {
    const { repository, prisma } = crearConAgregado({
      _sum: { puntuacion: 9 },
      _count: { _all: 2 },
    });

    await expect(repository.calificacionDeBien(BIEN_ID)).resolves.toEqual({
      suma: 9,
      total: 2,
    });
    expect(prisma.resena.aggregate).toHaveBeenCalledWith({
      where: { tipo: 'BIEN', reserva: { bienId: BIEN_ID } },
      _sum: { puntuacion: true },
      _count: { _all: true },
    });
  });

  it('sin reseñas la suma es 0 y no null', async () => {
    const { repository } = crearConAgregado({
      _sum: { puntuacion: null },
      _count: { _all: 0 },
    });

    await expect(repository.calificacionDeBien(BIEN_ID)).resolves.toEqual({
      suma: 0,
      total: 0,
    });
  });
});
