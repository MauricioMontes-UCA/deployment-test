import { Injectable } from '@nestjs/common';
import { PrismaService } from '@Prisma/services';
import { EstadoReserva, Prisma, TipoResena, type Resena } from '@PrismaClient';
import { calcularPromedio, dentroDelPlazoDeResena } from '@Resenas/utils';

const UNIQUE_CONSTRAINT_VIOLATION = 'P2002';

/** Tipos de reseña que escribe el arrendatario al calificar una reserva. */
export const TIPOS_DEL_ARRENDATARIO: TipoResena[] = [
  TipoResena.BIEN,
  TipoResena.ARRENDADOR,
];

/** Lo que se lee de la reserva para decidir si se puede calificar. */
export const RESERVA_PARA_RESENA_SELECT = {
  arrendatarioId: true,
  estado: true,
  finalizadaEn: true,
  // Basta saber si ya existe alguna de las dos reseñas del arrendatario.
  resenas: {
    where: { tipo: { in: TIPOS_DEL_ARRENDATARIO } },
    select: { id: true },
    take: 1,
  },
} as const;

export type ReservaParaResena = Prisma.ReservaGetPayload<{
  select: typeof RESERVA_PARA_RESENA_SELECT;
}>;

/** Por qué no se puede calificar la reserva. */
export type RechazoResena =
  'NO_EXISTE' | 'YA_CALIFICADA' | 'NO_FINALIZADA' | 'FUERA_DE_PLAZO';

export interface Calificacion {
  puntuacion: number;
  comentario?: string;
}

export interface RegistrarResenasData {
  reservaId: string;
  /** Arrendatario autenticado: autor de las dos reseñas. */
  arrendatarioId: string;
  bien: Calificacion;
  arrendador: Calificacion;
  /** Instante del registro: `creadaEn` de las dos reseñas y base del plazo. */
  ahora: Date;
}

/** Las dos reseñas guardadas o el motivo del rechazo. */
export type ResultadoResenas =
  { resenaBien: Resena; resenaArrendador: Resena } | { rechazo: RechazoResena };

/**
 * Primer motivo que impide calificar la reserva, o null si se puede.
 *
 * Una reserva de otro arrendatario se trata igual que una inexistente, para no
 * revelar que existe. Una reserva FINALIZADA sin `finalizadaEn` no tiene desde
 * dónde contar el plazo y se trata como fuera de plazo.
 */
export function motivoNoCalificable(
  reserva: ReservaParaResena | null,
  arrendatarioId: string,
  ahora: Date,
): RechazoResena | null {
  if (!reserva || reserva.arrendatarioId !== arrendatarioId) {
    return 'NO_EXISTE';
  }
  if (reserva.resenas.length > 0) return 'YA_CALIFICADA';
  if (reserva.estado !== EstadoReserva.FINALIZADA) return 'NO_FINALIZADA';
  if (
    !reserva.finalizadaEn ||
    !dentroDelPlazoDeResena(reserva.finalizadaEn, ahora)
  ) {
    return 'FUERA_DE_PLAZO';
  }
  return null;
}

/** Lo que se lee de la reserva para que el arrendador califique al arrendatario. */
export const RESERVA_PARA_CALIFICAR_ARRENDATARIO_SELECT = {
  arrendatarioId: true,
  estado: true,
  finalizadaEn: true,
  bien: { select: { arrendadorId: true } },
  resenas: {
    where: { tipo: TipoResena.ARRENDATARIO },
    select: { id: true },
    take: 1,
  },
} as const;

export type ReservaParaCalificarArrendatario = Prisma.ReservaGetPayload<{
  select: typeof RESERVA_PARA_CALIFICAR_ARRENDATARIO_SELECT;
}>;

export interface CalificarArrendatarioData extends Calificacion {
  reservaId: string;
  /** Arrendador autenticado: autor de la reseña y dueño del bien. */
  arrendadorId: string;
  /** Instante del registro: `creadaEn` de la reseña y base del plazo. */
  ahora: Date;
}

/** La reseña guardada con el promedio actualizado, o el motivo del rechazo. */
export type ResultadoCalificacionArrendatario =
  | {
      resena: Resena;
      promedioArrendatario: number;
      totalCalificaciones: number;
    }
  | { rechazo: RechazoResena };

/**
 * Primer motivo que impide al arrendador calificar al arrendatario de la
 * reserva, o null si se puede.
 *
 * Una reserva de un bien de otro arrendador se trata igual que una
 * inexistente, para no revelar que existe. El plazo cuenta desde
 * `finalizadaEn`, que se llena al registrar la devolución (o en el cierre
 * automático).
 */
export function motivoNoCalificableArrendatario(
  reserva: ReservaParaCalificarArrendatario | null,
  arrendadorId: string,
  ahora: Date,
): RechazoResena | null {
  if (!reserva || reserva.bien.arrendadorId !== arrendadorId) {
    return 'NO_EXISTE';
  }
  if (reserva.resenas.length > 0) return 'YA_CALIFICADA';
  if (reserva.estado !== EstadoReserva.FINALIZADA) return 'NO_FINALIZADA';
  if (
    !reserva.finalizadaEn ||
    !dentroDelPlazoDeResena(reserva.finalizadaEn, ahora)
  ) {
    return 'FUERA_DE_PLAZO';
  }
  return null;
}

/** Lo que se lee de la reserva para consultar la calificación del arrendatario. */
export const RESERVA_PARA_CONSULTAR_ARRENDATARIO_SELECT = {
  arrendatarioId: true,
  bien: { select: { arrendadorId: true } },
} as const;

const RESENA_ARRENDATARIO_SELECT = {
  id: true,
  puntuacion: true,
  comentario: true,
  creadaEn: true,
} satisfies Prisma.ResenaSelect;

/** Reseña ARRENDATARIO de una reserva, tal como se muestra al arrendador. */
export type ResenaArrendatario = Prisma.ResenaGetPayload<{
  select: typeof RESENA_ARRENDATARIO_SELECT;
}>;

export interface ConsultarCalificacionArrendatarioData {
  reservaId: string;
  /** Arrendador autenticado: debe ser el dueño del bien de la reserva. */
  arrendadorId: string;
}

/**
 * La reseña ARRENDATARIO de la reserva (o null si todavía no tiene) con el
 * promedio y el total del arrendatario, o `NO_EXISTE` si la reserva no existe
 * o su bien es de otro arrendador.
 */
export type ResultadoConsultaArrendatario =
  | {
      resena: ResenaArrendatario | null;
      /** null cuando el arrendatario no tiene ninguna calificación. */
      promedioArrendatario: number | null;
      totalCalificaciones: number;
    }
  | { rechazo: 'NO_EXISTE' };

/**
 * Suma y cantidad de las reseñas ARRENDATARIO de todas las reservas del
 * arrendatario. Lo usan la calificación (dentro de su transacción) y la
 * consulta, para que las dos calculen el promedio igual.
 */
async function agregadoDelArrendatario(
  cliente: Pick<Prisma.TransactionClient, 'resena'>,
  arrendatarioId: string,
): Promise<{ suma: number; total: number }> {
  const agregado = await cliente.resena.aggregate({
    where: {
      tipo: TipoResena.ARRENDATARIO,
      reserva: { arrendatarioId },
    },
    _sum: { puntuacion: true },
    _count: { _all: true },
  });
  return { suma: agregado._sum.puntuacion ?? 0, total: agregado._count._all };
}

/** Reseñas por página en el listado público de un bien. */
export const RESENAS_POR_PAGINA = 10;

const RESENA_DE_BIEN_SELECT = {
  id: true,
  puntuacion: true,
  comentario: true,
  creadaEn: true,
  autor: { select: { nombreUsuario: true } },
} satisfies Prisma.ResenaSelect;

/** Reseña de tipo BIEN con el nombre de usuario de su autor. */
export type ResenaDeBien = Prisma.ResenaGetPayload<{
  select: typeof RESENA_DE_BIEN_SELECT;
}>;

/** Una página de reseñas de un bien y cuántas hay en total. */
export interface PaginaDeResenas {
  items: ResenaDeBien[];
  total: number;
}

/** Reseñas de tipo BIEN de un bien: las del arrendador y las del arrendatario de la misma reserva no cuentan. */
function resenasDeBien(bienId: string) {
  return {
    tipo: TipoResena.BIEN,
    reserva: { bienId },
  } satisfies Prisma.ResenaWhereInput;
}

/** Único punto del módulo que escribe en `Resenas`. */
@Injectable()
export class ResenaRepository {
  constructor(private readonly prisma: PrismaService) {}

  /**
   * Suma y cantidad de las reseñas de tipo BIEN del bien. Es el único lugar
   * que filtra esas reseñas, igual que `listarDeBien`, para que el promedio
   * del detalle y el total del listado no puedan divergir.
   */
  async calificacionDeBien(
    bienId: string,
  ): Promise<{ suma: number; total: number }> {
    const agregado = await this.prisma.resena.aggregate({
      where: resenasDeBien(bienId),
      _sum: { puntuacion: true },
      _count: { _all: true },
    });
    return { suma: agregado._sum.puntuacion ?? 0, total: agregado._count._all };
  }

  /**
   * Reseñas de tipo BIEN de un bien, de la más reciente a la más antigua (con
   * el id como desempate para que las páginas no repitan ni salten reseñas).
   * Las reseñas sobre el arrendador y sobre el arrendatario no se incluyen.
   */
  async listarDeBien(bienId: string, pagina: number): Promise<PaginaDeResenas> {
    const where = resenasDeBien(bienId);
    const [items, total] = await this.prisma.$transaction([
      this.prisma.resena.findMany({
        where,
        select: RESENA_DE_BIEN_SELECT,
        orderBy: [{ creadaEn: 'desc' }, { id: 'desc' }],
        skip: (pagina - 1) * RESENAS_POR_PAGINA,
        take: RESENAS_POR_PAGINA,
      }),
      this.prisma.resena.count({ where }),
    ]);
    return { items, total };
  }

  /**
   * Valida la reserva y guarda la reseña del bien y la del arrendador en una
   * sola transacción: si falla una, no queda ninguna.
   *
   * Dos envíos simultáneos pueden pasar la validación a la vez; el segundo
   * choca con el índice único `(reserva_id, tipo)` y se traduce a
   * `YA_CALIFICADA`, sin dejar ninguna reseña suya.
   */
  async registrarResenasDeReserva({
    reservaId,
    arrendatarioId,
    bien,
    arrendador,
    ahora,
  }: RegistrarResenasData): Promise<ResultadoResenas> {
    try {
      return await this.prisma.$transaction(async (tx) => {
        const reserva = await tx.reserva.findUnique({
          where: { id: reservaId },
          select: RESERVA_PARA_RESENA_SELECT,
        });
        const rechazo = motivoNoCalificable(reserva, arrendatarioId, ahora);
        if (rechazo) return { rechazo };

        const datos = (tipo: TipoResena, calificacion: Calificacion) => ({
          reservaId,
          autorId: arrendatarioId,
          tipo,
          puntuacion: calificacion.puntuacion,
          comentario: calificacion.comentario ?? null,
          creadaEn: ahora,
        });

        // En secuencia y no en paralelo: si la segunda falla, la transacción
        // revierte la primera.
        const resenaBien = await tx.resena.create({
          data: datos(TipoResena.BIEN, bien),
        });
        const resenaArrendador = await tx.resena.create({
          data: datos(TipoResena.ARRENDADOR, arrendador),
        });
        return { resenaBien, resenaArrendador };
      });
    } catch (error) {
      if (esViolacionDeUnicidad(error)) return { rechazo: 'YA_CALIFICADA' };
      throw error;
    }
  }

  /**
   * Valida la reserva, guarda la reseña ARRENDATARIO y calcula el promedio
   * actualizado del arrendatario, todo en una sola transacción: el promedio ya
   * incluye la reseña recién guardada.
   *
   * El promedio sale de una consulta agregada sobre `Resenas` de tipo
   * ARRENDATARIO unida a `Reservas.arrendatario_id`, es decir, de todas las
   * reservas del arrendatario y no solo de esta.
   *
   * Dos envíos simultáneos pueden pasar la validación a la vez; el segundo
   * choca con el índice único `(reserva_id, tipo)` y se traduce a
   * `YA_CALIFICADA`, sin dejar reseña ni cambiar el promedio.
   */
  async calificarArrendatario({
    reservaId,
    arrendadorId,
    puntuacion,
    comentario,
    ahora,
  }: CalificarArrendatarioData): Promise<ResultadoCalificacionArrendatario> {
    try {
      return await this.prisma.$transaction(async (tx) => {
        const reserva = await tx.reserva.findUnique({
          where: { id: reservaId },
          select: RESERVA_PARA_CALIFICAR_ARRENDATARIO_SELECT,
        });
        const rechazo = motivoNoCalificableArrendatario(
          reserva,
          arrendadorId,
          ahora,
        );
        if (rechazo || !reserva) return { rechazo: rechazo ?? 'NO_EXISTE' };

        const resena = await tx.resena.create({
          data: {
            reservaId,
            autorId: arrendadorId,
            tipo: TipoResena.ARRENDATARIO,
            puntuacion,
            comentario: comentario ?? null,
            creadaEn: ahora,
          },
        });

        const { suma, total } = await agregadoDelArrendatario(
          tx,
          reserva.arrendatarioId,
        );
        return {
          resena,
          promedioArrendatario: calcularPromedio(suma, total),
          totalCalificaciones: total,
        };
      });
    } catch (error) {
      if (esViolacionDeUnicidad(error)) return { rechazo: 'YA_CALIFICADA' };
      throw error;
    }
  }

  /**
   * Consulta, sin escribir nada, la calificación que el arrendador dio al
   * arrendatario de la reserva y el promedio actual del arrendatario.
   *
   * - Una reserva de un bien de otro arrendador se trata igual que una
   *   inexistente, para no revelar que existe.
   * - No exige que la reserva esté FINALIZADA ni aplica el plazo de 14 días:
   *   eso solo limita cuándo se puede calificar, no cuándo se puede consultar.
   * - El promedio y el total son los del arrendatario en todas sus reservas,
   *   aunque esta todavía no tenga reseña. Sin ninguna calificación, el
   *   promedio es null.
   */
  async consultarCalificacionArrendatario({
    reservaId,
    arrendadorId,
  }: ConsultarCalificacionArrendatarioData): Promise<ResultadoConsultaArrendatario> {
    const reserva = await this.prisma.reserva.findUnique({
      where: { id: reservaId },
      select: RESERVA_PARA_CONSULTAR_ARRENDATARIO_SELECT,
    });
    if (!reserva || reserva.bien.arrendadorId !== arrendadorId) {
      return { rechazo: 'NO_EXISTE' };
    }

    const [resena, { suma, total }] = await Promise.all([
      this.prisma.resena.findUnique({
        where: {
          reservaId_tipo: { reservaId, tipo: TipoResena.ARRENDATARIO },
        },
        select: RESENA_ARRENDATARIO_SELECT,
      }),
      agregadoDelArrendatario(this.prisma, reserva.arrendatarioId),
    ]);
    return {
      resena,
      promedioArrendatario: total === 0 ? null : calcularPromedio(suma, total),
      totalCalificaciones: total,
    };
  }
}

function esViolacionDeUnicidad(error: unknown): boolean {
  return (
    error instanceof Prisma.PrismaClientKnownRequestError &&
    error.code === UNIQUE_CONSTRAINT_VIOLATION
  );
}
