import { Prisma } from '@PrismaClient';
import type { PrismaService } from '@Prisma/services';
import {
  motivoNoCalificableArrendatario,
  ResenaRepository,
  type CalificarArrendatarioData,
  type ReservaParaCalificarArrendatario,
} from './resena.repository.js';

const RESERVA_ID = '11111111-1111-4111-8111-111111111111';
const ARRENDATARIO_ID = '22222222-2222-4222-8222-222222222222';
const ARRENDADOR_ID = '33333333-3333-4333-8333-333333333333';
const FINALIZADA_EN = new Date('2026-12-01T16:00:00.000Z');
const AHORA = new Date('2026-12-05T16:00:00.000Z');

function reserva(
  cambios: Partial<ReservaParaCalificarArrendatario> = {},
): ReservaParaCalificarArrendatario {
  return {
    arrendatarioId: ARRENDATARIO_ID,
    estado: 'FINALIZADA',
    finalizadaEn: FINALIZADA_EN,
    bien: { arrendadorId: ARRENDADOR_ID },
    resenas: [],
    ...cambios,
  };
}

const datos: CalificarArrendatarioData = {
  reservaId: RESERVA_ID,
  arrendadorId: ARRENDADOR_ID,
  puntuacion: 4,
  comentario: 'Cuidó todo.',
  ahora: AHORA,
};

function crear(
  leida: ReservaParaCalificarArrendatario | null = reserva(),
  agregado = { _sum: { puntuacion: 13 as number | null }, _count: { _all: 3 } },
) {
  const tx = {
    reserva: { findUnique: vi.fn().mockResolvedValue(leida) },
    resena: {
      create: vi.fn(({ data }: { data: object }) =>
        Promise.resolve({ id: 'resena-arrendatario', ...data }),
      ),
      aggregate: vi.fn().mockResolvedValue(agregado),
    },
  };
  const prisma = {
    $transaction: vi.fn((callback: (cliente: typeof tx) => unknown) =>
      callback(tx),
    ),
  };
  return {
    repository: new ResenaRepository(prisma as unknown as PrismaService),
    prisma,
    tx,
  };
}

describe('motivoNoCalificableArrendatario', () => {
  it('una reserva de un bien propio, FINALIZADA, sin calificación y en plazo se puede calificar', () => {
    expect(
      motivoNoCalificableArrendatario(reserva(), ARRENDADOR_ID, AHORA),
    ).toBeNull();
  });

  it.each([
    ['no existe', null, 'NO_EXISTE'],
    [
      'es de un bien de otro arrendador',
      reserva({ bien: { arrendadorId: 'otro' } }),
      'NO_EXISTE',
    ],
    [
      'ya tiene calificación del arrendatario',
      reserva({ resenas: [{ id: 'r' }] }),
      'YA_CALIFICADA',
    ],
    ['no está FINALIZADA', reserva({ estado: 'EN_CURSO' }), 'NO_FINALIZADA'],
    [
      'no tiene finalizadaEn',
      reserva({ finalizadaEn: null }),
      'FUERA_DE_PLAZO',
    ],
  ] as const)('si la reserva %s: %s', (_caso, valor, motivo) => {
    expect(motivoNoCalificableArrendatario(valor, ARRENDADOR_ID, AHORA)).toBe(
      motivo,
    );
  });

  it('el día 14 desde la devolución se permite y el 15 no', () => {
    const dia14 = new Date('2026-12-15T16:00:00.000Z');
    const dia15 = new Date('2026-12-16T16:00:00.000Z');

    expect(
      motivoNoCalificableArrendatario(reserva(), ARRENDADOR_ID, dia14),
    ).toBeNull();
    expect(
      motivoNoCalificableArrendatario(reserva(), ARRENDADOR_ID, dia15),
    ).toBe('FUERA_DE_PLAZO');
  });

  it('el arrendatario de la reserva no cuenta como dueño del bien', () => {
    expect(
      motivoNoCalificableArrendatario(reserva(), ARRENDATARIO_ID, AHORA),
    ).toBe('NO_EXISTE');
  });

  it('no revela el estado de una reserva de otro arrendador', () => {
    const ajena = reserva({
      bien: { arrendadorId: 'otro' },
      estado: 'EN_COLA',
    });

    expect(motivoNoCalificableArrendatario(ajena, ARRENDADOR_ID, AHORA)).toBe(
      'NO_EXISTE',
    );
  });
});

describe('ResenaRepository.calificarArrendatario', () => {
  it('guarda la reseña ARRENDATARIO con el arrendador como autor', async () => {
    const { repository, tx } = crear();

    await repository.calificarArrendatario(datos);

    expect(tx.resena.create).toHaveBeenCalledWith({
      data: {
        reservaId: RESERVA_ID,
        autorId: ARRENDADOR_ID,
        tipo: 'ARRENDATARIO',
        puntuacion: 4,
        comentario: 'Cuidó todo.',
        creadaEn: AHORA,
      },
    });
  });

  it('sin comentario lo guarda como null', async () => {
    const { repository, tx } = crear();

    await repository.calificarArrendatario({ ...datos, comentario: undefined });

    expect(tx.resena.create).toHaveBeenCalledWith({
      data: expect.objectContaining({ comentario: null }),
    });
  });

  it('agrega las reseñas ARRENDATARIO de todas las reservas del arrendatario', async () => {
    const { repository, tx } = crear();

    await repository.calificarArrendatario(datos);

    expect(tx.resena.aggregate).toHaveBeenCalledWith({
      where: {
        tipo: 'ARRENDATARIO',
        reserva: { arrendatarioId: ARRENDATARIO_ID },
      },
      _sum: { puntuacion: true },
      _count: { _all: true },
    });
  });

  it('devuelve el promedio a un decimal y el total', async () => {
    const { repository } = crear(reserva(), {
      _sum: { puntuacion: 13 },
      _count: { _all: 3 },
    });

    expect(await repository.calificarArrendatario(datos)).toMatchObject({
      resena: { id: 'resena-arrendatario' },
      promedioArrendatario: 4.3,
      totalCalificaciones: 3,
    });
  });

  it('valida, guarda y agrega en la misma transacción, en ese orden', async () => {
    const { repository, prisma, tx } = crear();

    await repository.calificarArrendatario(datos);

    expect(prisma.$transaction).toHaveBeenCalledTimes(1);
    const [lectura] = tx.reserva.findUnique.mock.invocationCallOrder;
    const [guardado] = tx.resena.create.mock.invocationCallOrder;
    const [agregado] = tx.resena.aggregate.mock.invocationCallOrder;
    expect(lectura).toBeLessThan(guardado);
    expect(guardado).toBeLessThan(agregado);
  });

  it('si la reserva no se puede calificar, no guarda ni agrega nada', async () => {
    const { repository, tx } = crear(reserva({ estado: 'CONFIRMADA' }));

    expect(await repository.calificarArrendatario(datos)).toEqual({
      rechazo: 'NO_FINALIZADA',
    });
    expect(tx.resena.create).not.toHaveBeenCalled();
    expect(tx.resena.aggregate).not.toHaveBeenCalled();
  });

  it('traduce la violación del índice único (P2002) a YA_CALIFICADA', async () => {
    const { repository, prisma } = crear();
    prisma.$transaction.mockRejectedValueOnce(
      new Prisma.PrismaClientKnownRequestError('Unique constraint failed', {
        code: 'P2002',
        clientVersion: 'test',
      }),
    );

    expect(await repository.calificarArrendatario(datos)).toEqual({
      rechazo: 'YA_CALIFICADA',
    });
  });

  it('cualquier otro error sale tal cual', async () => {
    const { repository, tx } = crear();
    tx.resena.aggregate.mockRejectedValueOnce(new Error('falló la consulta'));

    await expect(repository.calificarArrendatario(datos)).rejects.toThrow(
      'falló la consulta',
    );
  });
});

describe('ResenaRepository.consultarCalificacionArrendatario', () => {
  const consulta = { reservaId: RESERVA_ID, arrendadorId: ARRENDADOR_ID };
  const resenaGuardada = {
    id: 'resena-arrendatario',
    puntuacion: 4,
    comentario: 'Cuidó todo.',
    creadaEn: AHORA,
  };
  const delDueno = {
    arrendatarioId: ARRENDATARIO_ID,
    bien: { arrendadorId: ARRENDADOR_ID },
  };

  function crearConsulta(
    leida: typeof delDueno | null = delDueno,
    resena: typeof resenaGuardada | null = resenaGuardada,
    agregado = {
      _sum: { puntuacion: 9 as number | null },
      _count: { _all: 2 },
    },
  ) {
    const prisma = {
      reserva: { findUnique: vi.fn().mockResolvedValue(leida) },
      resena: {
        findUnique: vi.fn().mockResolvedValue(resena),
        aggregate: vi.fn().mockResolvedValue(agregado),
        create: vi.fn(),
        update: vi.fn(),
        upsert: vi.fn(),
        delete: vi.fn(),
        deleteMany: vi.fn(),
      },
      $transaction: vi.fn(),
    };
    return {
      repository: new ResenaRepository(prisma as unknown as PrismaService),
      prisma,
    };
  }

  it('devuelve la reseña de la reserva con el promedio y el total del arrendatario', async () => {
    const { repository } = crearConsulta();

    // (5 + 4) / 2 = 4.5
    expect(
      await repository.consultarCalificacionArrendatario(consulta),
    ).toEqual({
      resena: resenaGuardada,
      promedioArrendatario: 4.5,
      totalCalificaciones: 2,
    });
  });

  it('busca la reseña por reserva y tipo ARRENDATARIO', async () => {
    const { repository, prisma } = crearConsulta();

    await repository.consultarCalificacionArrendatario(consulta);

    expect(prisma.resena.findUnique).toHaveBeenCalledWith({
      where: {
        reservaId_tipo: { reservaId: RESERVA_ID, tipo: 'ARRENDATARIO' },
      },
      select: { id: true, puntuacion: true, comentario: true, creadaEn: true },
    });
  });

  it('agrega igual que la calificación: ARRENDATARIO de todas las reservas del arrendatario', async () => {
    const { repository, prisma } = crearConsulta();

    await repository.consultarCalificacionArrendatario(consulta);

    expect(prisma.resena.aggregate).toHaveBeenCalledWith({
      where: {
        tipo: 'ARRENDATARIO',
        reserva: { arrendatarioId: ARRENDATARIO_ID },
      },
      _sum: { puntuacion: true },
      _count: { _all: true },
    });
  });

  it('sin reseña en esta reserva conserva el promedio de las demás', async () => {
    const { repository } = crearConsulta(delDueno, null, {
      _sum: { puntuacion: 13 },
      _count: { _all: 3 },
    });

    expect(
      await repository.consultarCalificacionArrendatario(consulta),
    ).toEqual({
      resena: null,
      promedioArrendatario: 4.3,
      totalCalificaciones: 3,
    });
  });

  it('sin ninguna calificación el promedio es null y el total 0', async () => {
    const { repository } = crearConsulta(delDueno, null, {
      _sum: { puntuacion: null },
      _count: { _all: 0 },
    });

    expect(
      await repository.consultarCalificacionArrendatario(consulta),
    ).toEqual({
      resena: null,
      promedioArrendatario: null,
      totalCalificaciones: 0,
    });
  });

  it.each([
    ['no existe', null],
    [
      'es de un bien de otro arrendador',
      { arrendatarioId: ARRENDATARIO_ID, bien: { arrendadorId: 'otro' } },
    ],
    [
      'la pide su arrendatario y no el dueño del bien',
      { arrendatarioId: ARRENDADOR_ID, bien: { arrendadorId: 'otro' } },
    ],
  ] as const)(
    'NO_EXISTE si la reserva %s, sin leer reseñas',
    async (_caso, leida) => {
      const { repository, prisma } = crearConsulta(leida);

      expect(
        await repository.consultarCalificacionArrendatario(consulta),
      ).toEqual({ rechazo: 'NO_EXISTE' });
      expect(prisma.resena.findUnique).not.toHaveBeenCalled();
      expect(prisma.resena.aggregate).not.toHaveBeenCalled();
    },
  );

  it('solo lee: no crea, modifica ni borra reseñas, ni abre una transacción', async () => {
    const { repository, prisma } = crearConsulta();

    await repository.consultarCalificacionArrendatario(consulta);

    for (const escritura of [
      prisma.resena.create,
      prisma.resena.update,
      prisma.resena.upsert,
      prisma.resena.delete,
      prisma.resena.deleteMany,
      prisma.$transaction,
    ]) {
      expect(escritura).not.toHaveBeenCalled();
    }
  });
});
