import {
  ConflictException,
  Injectable,
  NotFoundException,
  UnprocessableEntityException,
} from '@nestjs/common';
import {
  RESENAS_POR_PAGINA,
  ResenaRepository,
  type PaginaDeResenas,
  type RechazoResena,
  type ResenaArrendatario,
} from '@Resenas/repositories';
import { PLAZO_RESENA_DIAS, redondearUnDecimal } from '@Resenas/utils';
import type { CalificarArrendatarioDto, CrearResenasDto } from '@Resenas/dto';
import type { Resena } from '@PrismaClient';

const RECHAZOS: Record<RechazoResena, new (mensaje: string) => Error> = {
  NO_EXISTE: NotFoundException,
  YA_CALIFICADA: ConflictException,
  NO_FINALIZADA: UnprocessableEntityException,
  FUERA_DE_PLAZO: UnprocessableEntityException,
};

const MENSAJES: Record<RechazoResena, string> = {
  NO_EXISTE: 'La reserva no existe.',
  YA_CALIFICADA: 'Esta reserva ya fue calificada.',
  NO_FINALIZADA: 'Solo se puede calificar una reserva finalizada.',
  FUERA_DE_PLAZO: `El plazo de ${PLAZO_RESENA_DIAS} días para calificar esta reserva ya venció.`,
};

/** Mensajes cuando el arrendador califica al arrendatario (H16). */
const MENSAJES_ARRENDATARIO: Record<RechazoResena, string> = {
  ...MENSAJES,
  YA_CALIFICADA: 'Esta reserva ya tiene calificación del arrendatario.',
  FUERA_DE_PLAZO: `El plazo de ${PLAZO_RESENA_DIAS} días desde la devolución para calificar al arrendatario ya venció.`,
};

/**
 * Reseñas del bien y del arrendador tras una reserva (H15).
 *
 * No conoce Prisma: el acceso a datos pasa por `ResenaRepository`.
 */
@Injectable()
export class ResenasService {
  constructor(private readonly resenaRepository: ResenaRepository) {}

  /**
   * Calificación de un bien: promedio con un decimal y total de reseñas de
   * tipo BIEN. Sin reseñas el promedio es `null` (no hay nada que promediar),
   * igual que en la consulta de la calificación del arrendatario.
   *
   * No comprueba que el bien exista ni esté publicado: eso lo decide el
   * llamador (el módulo de bienes).
   */
  async calificacionDeBien(
    bienId: string,
  ): Promise<{ promedio: number | null; totalResenas: number }> {
    const { suma, total } =
      await this.resenaRepository.calificacionDeBien(bienId);
    return {
      promedio: total === 0 ? null : redondearUnDecimal(suma / total),
      totalResenas: total,
    };
  }

  /**
   * Página de reseñas de tipo BIEN de un bien.
   *
   * No comprueba que el bien esté publicado: el controlador de bienes lo
   * verifica antes con `BienesService.verificarPublicado`.
   */
  async listarDeBien(
    bienId: string,
    pagina: number,
  ): Promise<PaginaDeResenas & { pagina: number; hayMas: boolean }> {
    const { items, total } = await this.resenaRepository.listarDeBien(
      bienId,
      pagina,
    );
    return {
      items,
      total,
      pagina,
      hayMas: pagina * RESENAS_POR_PAGINA < total,
    };
  }

  /**
   * Guarda la reseña del bien y la del arrendador de una reserva finalizada.
   *
   * @param arrendatarioId viene del usuario autenticado, nunca del cuerpo.
   * @throws {NotFoundException} la reserva no existe o es de otro
   * arrendatario.
   * @throws {ConflictException} la reserva ya tiene reseñas del arrendatario.
   * @throws {UnprocessableEntityException} la reserva no está FINALIZADA o
   * pasaron más de 14 días desde su finalización.
   *
   * `ahora` se recibe para poder probar el plazo.
   */
  async registrar(
    reservaId: string,
    arrendatarioId: string,
    dto: CrearResenasDto,
    ahora: Date = new Date(),
  ): Promise<{ resenaBien: Resena; resenaArrendador: Resena }> {
    const resultado = await this.resenaRepository.registrarResenasDeReserva({
      reservaId,
      arrendatarioId,
      bien: dto.bien,
      arrendador: dto.arrendador,
      ahora,
    });
    if ('rechazo' in resultado) {
      throw new RECHAZOS[resultado.rechazo](MENSAJES[resultado.rechazo]);
    }
    return resultado;
  }

  /**
   * Guarda la calificación que el arrendador da al arrendatario de una reserva
   * finalizada y devuelve el promedio actualizado del arrendatario (H16).
   *
   * @param arrendadorId viene del usuario autenticado, nunca del cuerpo.
   * @throws {NotFoundException} la reserva no existe o su bien es de otro
   * arrendador.
   * @throws {ConflictException} la reserva ya tiene calificación del
   * arrendatario.
   * @throws {UnprocessableEntityException} la reserva no está FINALIZADA o
   * pasaron más de 14 días desde la devolución.
   *
   * `ahora` se recibe para poder probar el plazo.
   */
  async calificarArrendatario(
    reservaId: string,
    arrendadorId: string,
    dto: CalificarArrendatarioDto,
    ahora: Date = new Date(),
  ): Promise<{
    resena: Resena;
    promedioArrendatario: number;
    totalCalificaciones: number;
  }> {
    const resultado = await this.resenaRepository.calificarArrendatario({
      reservaId,
      arrendadorId,
      puntuacion: dto.puntuacion,
      comentario: dto.comentario,
      ahora,
    });
    if ('rechazo' in resultado) {
      throw new RECHAZOS[resultado.rechazo](
        MENSAJES_ARRENDATARIO[resultado.rechazo],
      );
    }
    return resultado;
  }

  /**
   * Calificación que el arrendador dio al arrendatario de la reserva (o null
   * si todavía no la calificó) y el promedio actual del arrendatario (H16).
   * Solo lee: no crea ni modifica reseñas.
   *
   * No exige que la reserva esté FINALIZADA ni aplica el plazo de 14 días.
   *
   * @param arrendadorId viene del usuario autenticado, nunca de la petición.
   * @throws {NotFoundException} la reserva no existe o su bien es de otro
   * arrendador, con el mismo mensaje en los dos casos.
   */
  async consultarCalificacionArrendatario(
    reservaId: string,
    arrendadorId: string,
  ): Promise<{
    resena: ResenaArrendatario | null;
    promedioArrendatario: number | null;
    totalCalificaciones: number;
  }> {
    const resultado =
      await this.resenaRepository.consultarCalificacionArrendatario({
        reservaId,
        arrendadorId,
      });
    if ('rechazo' in resultado) {
      throw new NotFoundException(MENSAJES_ARRENDATARIO.NO_EXISTE);
    }
    return resultado;
  }
}
