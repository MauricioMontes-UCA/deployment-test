import {
  ConflictException,
  NotFoundException,
  UnprocessableEntityException,
} from '@nestjs/common';
import type { RechazoResena, ResenaRepository } from '@Resenas/repositories';
import type { CalificarArrendatarioDto } from '@Resenas/dto';
import { ResenasService } from './resenas.service.js';

const RESERVA_ID = '11111111-1111-4111-8111-111111111111';
const ARRENDADOR_ID = '33333333-3333-4333-8333-333333333333';
const AHORA = new Date('2026-12-05T16:00:00.000Z');

const dto: CalificarArrendatarioDto = {
  puntuacion: 4,
  comentario: 'Cuidó todo.',
};

const guardada = {
  resena: { id: 'resena-arrendatario' },
  promedioArrendatario: 4.3,
  totalCalificaciones: 3,
};

function crearServicio(
  resultado: typeof guardada | { rechazo: RechazoResena } = guardada,
) {
  const calificarArrendatario = vi.fn().mockResolvedValue(resultado);
  const service = new ResenasService({
    calificarArrendatario,
  } as unknown as ResenaRepository);
  return { service, calificarArrendatario };
}

describe('ResenasService.calificarArrendatario', () => {
  it('guarda la calificación con el arrendador del token y devuelve el promedio', async () => {
    const { service, calificarArrendatario } = crearServicio();

    const resultado = await service.calificarArrendatario(
      RESERVA_ID,
      ARRENDADOR_ID,
      dto,
      AHORA,
    );

    expect(resultado).toEqual(guardada);
    expect(calificarArrendatario).toHaveBeenCalledWith({
      reservaId: RESERVA_ID,
      arrendadorId: ARRENDADOR_ID,
      puntuacion: 4,
      comentario: 'Cuidó todo.',
      ahora: AHORA,
    });
  });

  it.each([
    ['NO_EXISTE', NotFoundException, 'La reserva no existe.'],
    [
      'YA_CALIFICADA',
      ConflictException,
      'Esta reserva ya tiene calificación del arrendatario.',
    ],
    [
      'NO_FINALIZADA',
      UnprocessableEntityException,
      'Solo se puede calificar una reserva finalizada.',
    ],
    [
      'FUERA_DE_PLAZO',
      UnprocessableEntityException,
      'El plazo de 14 días desde la devolución para calificar al arrendatario ya venció.',
    ],
  ] as const)('traduce %s a %O', async (rechazo, Excepcion, mensaje) => {
    const { service } = crearServicio({ rechazo });

    const intento = service.calificarArrendatario(
      RESERVA_ID,
      ARRENDADOR_ID,
      dto,
      AHORA,
    );

    await expect(intento).rejects.toThrow(Excepcion);
    await expect(intento).rejects.toThrow(mensaje);
  });
});

describe('ResenasService.consultarCalificacionArrendatario', () => {
  function crearConsulta(resultado: object) {
    const consultarCalificacionArrendatario = vi
      .fn()
      .mockResolvedValue(resultado);
    const service = new ResenasService({
      consultarCalificacionArrendatario,
    } as unknown as ResenaRepository);
    return { service, consultarCalificacionArrendatario };
  }

  const resena = {
    id: 'resena-arrendatario',
    puntuacion: 4,
    comentario: 'Buen comportamiento',
    creadaEn: AHORA,
  };

  // Los tres casos que pide el DoD de AF-175 (BE-16.2).
  it.each([
    [
      'reseña existente',
      { resena, promedioArrendatario: 4.5, totalCalificaciones: 2 },
    ],
    [
      'reseña null, con el promedio real de sus otras reservas',
      { resena: null, promedioArrendatario: 4.3, totalCalificaciones: 3 },
    ],
    [
      'promedio sin calificaciones: null y total 0',
      { resena: null, promedioArrendatario: null, totalCalificaciones: 0 },
    ],
  ] as const)('%s', async (_caso, leido) => {
    const { service, consultarCalificacionArrendatario } = crearConsulta(leido);

    expect(
      await service.consultarCalificacionArrendatario(
        RESERVA_ID,
        ARRENDADOR_ID,
      ),
    ).toEqual(leido);
    // El arrendador es el del token; la reserva, la de la ruta.
    expect(consultarCalificacionArrendatario).toHaveBeenCalledWith({
      reservaId: RESERVA_ID,
      arrendadorId: ARRENDADOR_ID,
    });
  });

  it('traduce NO_EXISTE a 404 con el mismo mensaje que la calificación', async () => {
    const { service } = crearConsulta({ rechazo: 'NO_EXISTE' });

    const intento = service.consultarCalificacionArrendatario(
      RESERVA_ID,
      ARRENDADOR_ID,
    );

    await expect(intento).rejects.toThrow(NotFoundException);
    await expect(intento).rejects.toThrow('La reserva no existe.');
  });
});
