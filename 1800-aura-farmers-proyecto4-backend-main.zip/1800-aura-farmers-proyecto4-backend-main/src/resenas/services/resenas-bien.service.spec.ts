import type { ResenaRepository } from '@Resenas/repositories';
import { ResenasService } from './resenas.service.js';

const BIEN_ID = '7c9e6679-7425-40de-944b-e07fc1f90ae7';

function crear(total: number) {
  const listarDeBien = vi.fn().mockResolvedValue({ items: ['r'], total });
  const service = new ResenasService({
    listarDeBien,
  } as unknown as ResenaRepository);
  return { service, listarDeBien };
}

describe('ResenasService.listarDeBien', () => {
  it('devuelve la página pedida', async () => {
    const { service, listarDeBien } = crear(25);

    await expect(service.listarDeBien(BIEN_ID, 2)).resolves.toEqual({
      items: ['r'],
      total: 25,
      pagina: 2,
      hayMas: true,
    });
    expect(listarDeBien).toHaveBeenCalledWith(BIEN_ID, 2);
  });

  it.each([
    [1, 10, false],
    [1, 11, true],
    [2, 20, false],
    [2, 21, true],
    [3, 0, false],
  ])('página %i con %i reseñas: hayMas = %s', async (pagina, total, hayMas) => {
    const { service } = crear(total);

    expect((await service.listarDeBien(BIEN_ID, pagina)).hayMas).toBe(hayMas);
  });
});

describe('ResenasService.calificacionDeBien', () => {
  function crearConAgregado(suma: number, total: number) {
    const calificacionDeBien = vi.fn().mockResolvedValue({ suma, total });
    const service = new ResenasService({
      calificacionDeBien,
    } as unknown as ResenaRepository);
    return { service, calificacionDeBien };
  }

  it('calcula el promedio con un decimal', async () => {
    const { service, calificacionDeBien } = crearConAgregado(9, 2);

    await expect(service.calificacionDeBien(BIEN_ID)).resolves.toEqual({
      promedio: 4.5,
      totalResenas: 2,
    });
    expect(calificacionDeBien).toHaveBeenCalledWith(BIEN_ID);
  });

  it('redondea el promedio a un decimal', async () => {
    const { service } = crearConAgregado(13, 3);

    expect((await service.calificacionDeBien(BIEN_ID)).promedio).toBe(4.3);
  });

  it('sin reseñas el promedio es null y el total 0', async () => {
    const { service } = crearConAgregado(0, 0);

    await expect(service.calificacionDeBien(BIEN_ID)).resolves.toEqual({
      promedio: null,
      totalResenas: 0,
    });
  });
});
