import {
  ConflictException,
  NotFoundException,
  UnprocessableEntityException,
} from '@nestjs/common';
import type { RechazoResena, ResenaRepository } from '@Resenas/repositories';
import type { CrearResenasDto } from '@Resenas/dto';
import { ResenasService } from './resenas.service.js';

const RESERVA_ID = '11111111-1111-4111-8111-111111111111';
const ARRENDATARIO_ID = '22222222-2222-4222-8222-222222222222';
const AHORA = new Date('2026-12-05T16:00:00.000Z');

const dto: CrearResenasDto = {
  bien: { puntuacion: 5, comentario: 'Todo en orden.' },
  arrendador: { puntuacion: 4 },
};

function crearServicio(
  resultado:
    | { resenaBien: object; resenaArrendador: object }
    | { rechazo: RechazoResena } = {
    resenaBien: { id: 'resena-bien' },
    resenaArrendador: { id: 'resena-arrendador' },
  },
) {
  const registrarResenasDeReserva = vi.fn().mockResolvedValue(resultado);
  const service = new ResenasService({
    registrarResenasDeReserva,
  } as unknown as ResenaRepository);
  return { service, registrarResenasDeReserva };
}

describe('ResenasService.registrar', () => {
  it('guarda las dos reseñas con el arrendatario del token', async () => {
    const { service, registrarResenasDeReserva } = crearServicio();

    const resultado = await service.registrar(
      RESERVA_ID,
      ARRENDATARIO_ID,
      dto,
      AHORA,
    );

    expect(resultado).toEqual({
      resenaBien: { id: 'resena-bien' },
      resenaArrendador: { id: 'resena-arrendador' },
    });
    expect(registrarResenasDeReserva).toHaveBeenCalledWith({
      reservaId: RESERVA_ID,
      arrendatarioId: ARRENDATARIO_ID,
      bien: dto.bien,
      arrendador: dto.arrendador,
      ahora: AHORA,
    });
  });

  it.each([
    ['NO_EXISTE', NotFoundException, 'La reserva no existe.'],
    ['YA_CALIFICADA', ConflictException, 'Esta reserva ya fue calificada.'],
    [
      'NO_FINALIZADA',
      UnprocessableEntityException,
      'Solo se puede calificar una reserva finalizada.',
    ],
    [
      'FUERA_DE_PLAZO',
      UnprocessableEntityException,
      'El plazo de 14 días para calificar esta reserva ya venció.',
    ],
  ] as const)('traduce %s a %O', async (rechazo, Excepcion, mensaje) => {
    const { service } = crearServicio({ rechazo });

    const intento = service.registrar(RESERVA_ID, ARRENDATARIO_ID, dto, AHORA);

    await expect(intento).rejects.toThrow(Excepcion);
    await expect(intento).rejects.toThrow(mensaje);
  });
});
