import {
  dentroDelPlazoDeResena,
  diasDesdeFinalizacion,
  PLAZO_RESENA_DIAS,
} from './plazo-resena.js';

// 1 de diciembre de 2026 a las 10:00 en El Salvador (UTC-6).
const FINALIZADA_EN = new Date('2026-12-01T16:00:00.000Z');
/** `n` días después, a las 10:00 en El Salvador. */
const diaDespues = (n: number, hora = '16:00') =>
  new Date(`2026-12-${String(1 + n).padStart(2, '0')}T${hora}:00.000Z`);

describe('plazo de las reseñas', () => {
  it('es de 14 días', () => {
    expect(PLAZO_RESENA_DIAS).toBe(14);
  });

  it('el mismo día de la finalización es el día 0', () => {
    expect(diasDesdeFinalizacion(FINALIZADA_EN, FINALIZADA_EN)).toBe(0);
  });

  it('el día 14 todavía se permite', () => {
    expect(diasDesdeFinalizacion(FINALIZADA_EN, diaDespues(14))).toBe(14);
    expect(dentroDelPlazoDeResena(FINALIZADA_EN, diaDespues(14))).toBe(true);
  });

  it('el día 14 se permite hasta el final del día en El Salvador', () => {
    // 16 de diciembre a las 05:59 UTC = 15 de diciembre (día 14) a las 23:59
    // en El Salvador.
    const ultimoMinuto = new Date('2026-12-16T05:59:00.000Z');

    expect(dentroDelPlazoDeResena(FINALIZADA_EN, ultimoMinuto)).toBe(true);
  });

  it('el día 15 ya no se permite', () => {
    expect(diasDesdeFinalizacion(FINALIZADA_EN, diaDespues(15))).toBe(15);
    expect(dentroDelPlazoDeResena(FINALIZADA_EN, diaDespues(15))).toBe(false);
  });

  it('el día 15 empieza a medianoche en El Salvador, no en UTC', () => {
    // 16 de diciembre a las 06:00 UTC = 16 de diciembre (día 15) a las 00:00
    // en El Salvador.
    const medianoche = new Date('2026-12-16T06:00:00.000Z');

    expect(dentroDelPlazoDeResena(FINALIZADA_EN, medianoche)).toBe(false);
  });

  it('cuenta los días en la zona de El Salvador, no en UTC', () => {
    // 1 de diciembre a las 05:30 UTC = 30 de noviembre a las 23:30 en El Salvador.
    const finalizadaDeNoche = new Date('2026-12-01T05:30:00.000Z');
    // 15 de diciembre a las 10:00 en El Salvador (16:00 UTC). En UTC serían 14
    // días (del 1 al 15), pero en El Salvador son 15 (del 30 al 15).
    const ahora = new Date('2026-12-15T16:00:00.000Z');

    expect(diasDesdeFinalizacion(finalizadaDeNoche, ahora)).toBe(15);
    expect(dentroDelPlazoDeResena(finalizadaDeNoche, ahora)).toBe(false);
  });
});
