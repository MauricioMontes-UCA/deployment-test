/** Redondea a un decimal (4.25 → 4.3, 4.24 → 4.2). */
export function redondearUnDecimal(valor: number): number {
  return Math.round(valor * 10) / 10;
}

/**
 * Promedio de las puntuaciones del arrendatario: suma ÷ total, redondeado a un
 * decimal. Sin calificaciones el promedio es 0.
 */
export function calcularPromedio(suma: number, total: number): number {
  if (total <= 0) return 0;
  return redondearUnDecimal(suma / total);
}
