export * from './plazo-resena.js';
export * from './promedio.js';
