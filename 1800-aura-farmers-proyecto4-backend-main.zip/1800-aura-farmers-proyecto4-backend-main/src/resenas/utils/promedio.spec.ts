import { calcularPromedio, redondearUnDecimal } from './promedio.js';

/** Suma y total de una lista de puntuaciones, como los da la consulta agregada. */
const promedioDe = (puntuaciones: number[]) =>
  calcularPromedio(
    puntuaciones.reduce((suma, p) => suma + p, 0),
    puntuaciones.length,
  );

describe('calcularPromedio', () => {
  it('con una sola calificación, el promedio es esa puntuación', () => {
    expect(promedioDe([4])).toBe(4);
    expect(promedioDe([1])).toBe(1);
  });

  it('con varias calificaciones, es la suma entre el total', () => {
    expect(promedioDe([5, 3])).toBe(4);
    expect(promedioDe([4, 5])).toBe(4.5);
    expect(promedioDe([5, 5, 5, 5, 1])).toBe(4.2);
  });

  it.each([
    [[5, 4, 4], 4.3], // 4.333…
    [[5, 5, 4], 4.7], // 4.666…
    [[1, 2, 2], 1.7], // 1.666…
    [[1, 1, 2], 1.3], // 1.333…
    [[4, 4, 4, 5, 5, 5, 5, 5], 4.6], // 4.625
  ])('redondea %j a un decimal: %d', (puntuaciones, esperado) => {
    expect(promedioDe(puntuaciones)).toBe(esperado);
  });

  it('sin calificaciones el promedio es 0', () => {
    expect(calcularPromedio(0, 0)).toBe(0);
  });
});

describe('redondearUnDecimal', () => {
  it.each([
    [4.25, 4.3],
    [4.24, 4.2],
    [4.05, 4.1],
    [3, 3],
  ])('%d → %d', (valor, esperado) => {
    expect(redondearUnDecimal(valor)).toBe(esperado);
  });
});
