import { hoyEn, ZONA_HORARIA } from '@Bienes/utils';

/** Días completos, desde que la reserva queda finalizada, para calificarla. */
export const PLAZO_RESENA_DIAS = 14;

const MS_POR_DIA = 24 * 60 * 60 * 1000;

/**
 * Días de calendario entre la finalización de la reserva y `ahora`, contados en
 * la zona de El Salvador. El mismo día de la finalización es el día 0.
 */
export function diasDesdeFinalizacion(finalizadaEn: Date, ahora: Date): number {
  const desde = hoyEn(ZONA_HORARIA, finalizadaEn);
  const hasta = hoyEn(ZONA_HORARIA, ahora);
  return Math.round((hasta.getTime() - desde.getTime()) / MS_POR_DIA);
}

/**
 * Indica si todavía se puede calificar una reserva finalizada en
 * `finalizadaEn` (devolución registrada o cierre automático).
 *
 * El plazo son 14 días completos: el día 14 se permite y el 15 no.
 */
export function dentroDelPlazoDeResena(
  finalizadaEn: Date,
  ahora: Date,
): boolean {
  return diasDesdeFinalizacion(finalizadaEn, ahora) <= PLAZO_RESENA_DIAS;
}
