import { ResenaBienResponseDto } from './resenas-bien-response.dto.js';
import type { ResenaDeBien } from '@Resenas/repositories';

const resena = (cambios: Partial<ResenaDeBien> = {}): ResenaDeBien => ({
  id: 'r1',
  puntuacion: 5,
  comentario: 'Muy limpio.',
  creadaEn: new Date('2026-11-10T15:00:00.000Z'),
  autor: { nombreUsuario: 'carlos_r' },
  ...cambios,
});

describe('ResenaBienResponseDto.from', () => {
  it('expone id, puntuación, comentario, autor y fecha ISO', () => {
    expect(ResenaBienResponseDto.from(resena())).toEqual({
      id: 'r1',
      puntuacion: 5,
      comentario: 'Muy limpio.',
      autor: { nombreUsuario: 'carlos_r' },
      creadaEn: '2026-11-10T15:00:00.000Z',
    });
  });

  it('omite el comentario si no hay', () => {
    const dto = ResenaBienResponseDto.from(resena({ comentario: null }));
    expect('comentario' in dto).toBe(false);
  });
});
