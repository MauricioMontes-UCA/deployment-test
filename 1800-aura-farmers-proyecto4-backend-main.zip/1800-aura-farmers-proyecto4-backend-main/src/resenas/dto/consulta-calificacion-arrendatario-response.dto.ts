import { ApiProperty } from '@nestjs/swagger';
import type { ResenaArrendatario } from '@Resenas/repositories';

/** Calificación que el arrendador dio al arrendatario de una reserva. */
export class ResenaArrendatarioDto {
  @ApiProperty({ format: 'uuid' })
  resenaId!: string;

  @ApiProperty({ type: 'integer', minimum: 1, maximum: 5, example: 4 })
  puntuacion!: number;

  @ApiProperty({
    type: String,
    nullable: true,
    example: 'Cuidó todo.',
    description: 'null si la calificación se guardó sin comentario.',
  })
  comentario!: string | null;

  @ApiProperty({ type: String, format: 'date-time' })
  creadaEn!: string;

  static from(resena: ResenaArrendatario): ResenaArrendatarioDto {
    return {
      resenaId: resena.id,
      puntuacion: resena.puntuacion,
      comentario: resena.comentario,
      creadaEn: resena.creadaEn.toISOString(),
    };
  }
}

/** Respuesta de `GET /reservas/:reservaId/resenas/arrendatario`. */
export class ConsultaCalificacionArrendatarioResponseDto {
  @ApiProperty({
    type: ResenaArrendatarioDto,
    nullable: true,
    description: 'null si el arrendador todavía no calificó esta reserva.',
  })
  resena!: ResenaArrendatarioDto | null;

  @ApiProperty({
    type: Number,
    nullable: true,
    example: 4.5,
    description:
      'Promedio de todas las calificaciones del arrendatario, en todas sus reservas, redondeado a un decimal. null si no tiene ninguna.',
  })
  promedioArrendatario!: number | null;

  @ApiProperty({
    type: 'integer',
    example: 2,
    description:
      'Cantidad de calificaciones que tiene el arrendatario, en todas sus reservas.',
  })
  totalCalificaciones!: number;

  static from(
    resena: ResenaArrendatario | null,
    promedioArrendatario: number | null,
    totalCalificaciones: number,
  ): ConsultaCalificacionArrendatarioResponseDto {
    return {
      resena: resena ? ResenaArrendatarioDto.from(resena) : null,
      promedioArrendatario,
      totalCalificaciones,
    };
  }
}
