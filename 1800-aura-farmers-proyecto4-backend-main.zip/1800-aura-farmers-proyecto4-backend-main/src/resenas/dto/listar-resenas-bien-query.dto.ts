import { ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { IsInt, IsOptional, Max, Min } from 'class-validator';
import { PAGINA_MAXIMA } from '@Bienes/constants';

/** Query de `GET /bienes/:bienId/resenas`. */
export class ListarResenasBienQueryDto {
  @ApiPropertyOptional({
    description: 'Número de página, desde 1.',
    example: 1,
    default: 1,
    minimum: 1,
    maximum: PAGINA_MAXIMA,
  })
  @IsOptional()
  @Type(() => Number)
  @IsInt({ message: 'La página debe ser un número entero.' })
  @Min(1, { message: `La página debe ser de 1 a ${PAGINA_MAXIMA}.` })
  @Max(PAGINA_MAXIMA, {
    message: `La página debe ser de 1 a ${PAGINA_MAXIMA}.`,
  })
  pagina: number = 1;
}
