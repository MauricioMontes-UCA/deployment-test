import { ApiProperty } from '@nestjs/swagger';
import type { Resena } from '@PrismaClient';

/** Respuesta de `POST /reservas/:reservaId/resenas`. */
export class ResenasResponseDto {
  @ApiProperty({ format: 'uuid' })
  reservaId!: string;

  @ApiProperty({ format: 'uuid' })
  resenaBienId!: string;

  @ApiProperty({ format: 'uuid' })
  resenaArrendadorId!: string;

  @ApiProperty({ type: String, format: 'date-time' })
  creadaEn!: string;

  static from(
    resenaBien: Resena,
    resenaArrendador: Resena,
  ): ResenasResponseDto {
    return {
      reservaId: resenaBien.reservaId,
      resenaBienId: resenaBien.id,
      resenaArrendadorId: resenaArrendador.id,
      // Las dos se guardan con el mismo instante.
      creadaEn: resenaBien.creadaEn.toISOString(),
    };
  }
}
