import { ApiProperty } from '@nestjs/swagger';
import type { Resena } from '@PrismaClient';

/** Respuesta de `POST /reservas/:reservaId/resenas/arrendatario`. */
export class CalificacionArrendatarioResponseDto {
  @ApiProperty({ format: 'uuid' })
  resenaId!: string;

  @ApiProperty({
    example: 4.3,
    description:
      'Promedio de todas las calificaciones del arrendatario, redondeado a un decimal.',
  })
  promedioArrendatario!: number;

  @ApiProperty({
    example: 3,
    description: 'Cantidad de calificaciones que tiene el arrendatario.',
  })
  totalCalificaciones!: number;

  @ApiProperty({ type: String, format: 'date-time' })
  creadaEn!: string;

  static from(
    resena: Resena,
    promedioArrendatario: number,
    totalCalificaciones: number,
  ): CalificacionArrendatarioResponseDto {
    return {
      resenaId: resena.id,
      promedioArrendatario,
      totalCalificaciones,
      creadaEn: resena.creadaEn.toISOString(),
    };
  }
}
