import { CalificacionDto } from './crear-resenas.dto.js';

/**
 * Cuerpo de `POST /reservas/:reservaId/resenas/arrendatario`: puntuación
 * entera de 1 a 5 y comentario opcional de hasta 500 caracteres.
 *
 * Aquí solo se valida la forma. El dueño del bien, el estado, el plazo y la
 * unicidad los valida el servicio. El arrendador sale del token, nunca del
 * cuerpo.
 */
export class CalificarArrendatarioDto extends CalificacionDto {}
