import { ConsultaCalificacionArrendatarioResponseDto } from './consulta-calificacion-arrendatario-response.dto.js';

const CREADA_EN = new Date('2026-12-05T16:00:00.000Z');

describe('ConsultaCalificacionArrendatarioResponseDto', () => {
  it('con calificación: la reseña con su id como resenaId y la fecha en ISO', () => {
    expect(
      ConsultaCalificacionArrendatarioResponseDto.from(
        {
          id: 'resena-arrendatario',
          puntuacion: 4,
          comentario: 'Cuidó todo.',
          creadaEn: CREADA_EN,
        },
        4.5,
        2,
      ),
    ).toEqual({
      resena: {
        resenaId: 'resena-arrendatario',
        puntuacion: 4,
        comentario: 'Cuidó todo.',
        creadaEn: '2026-12-05T16:00:00.000Z',
      },
      promedioArrendatario: 4.5,
      totalCalificaciones: 2,
    });
  });

  it('una calificación sin comentario lo devuelve como null', () => {
    const dto = ConsultaCalificacionArrendatarioResponseDto.from(
      { id: 'r', puntuacion: 3, comentario: null, creadaEn: CREADA_EN },
      3,
      1,
    );

    expect(dto.resena?.comentario).toBeNull();
  });

  it('sin calificación: resena null, promedio null y total 0', () => {
    expect(
      ConsultaCalificacionArrendatarioResponseDto.from(null, null, 0),
    ).toEqual({
      resena: null,
      promedioArrendatario: null,
      totalCalificaciones: 0,
    });
  });

  it('no expone campos de la reseña fuera del contrato, aunque lleguen', () => {
    const conExtras = {
      id: 'r',
      puntuacion: 5,
      comentario: null,
      creadaEn: CREADA_EN,
      autorId: 'autor',
      reservaId: 'reserva',
    };

    const dto = ConsultaCalificacionArrendatarioResponseDto.from(
      conExtras,
      5,
      1,
    );

    expect(Object.keys(dto.resena ?? {}).sort()).toEqual([
      'comentario',
      'creadaEn',
      'puntuacion',
      'resenaId',
    ]);
  });
});
