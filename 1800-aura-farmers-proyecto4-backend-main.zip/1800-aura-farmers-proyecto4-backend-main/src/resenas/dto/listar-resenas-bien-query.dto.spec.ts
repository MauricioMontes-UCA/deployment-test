import { plainToInstance } from 'class-transformer';
import { validate } from 'class-validator';
import { ListarResenasBienQueryDto } from './listar-resenas-bien-query.dto.js';

async function evaluar(query: Record<string, unknown>) {
  const dto = plainToInstance(ListarResenasBienQueryDto, query);
  const errores = await validate(dto);
  return {
    dto,
    mensajes: errores.flatMap((e) => Object.values(e.constraints ?? {})),
  };
}

describe('ListarResenasBienQueryDto', () => {
  it('sin página usa la primera', async () => {
    const { dto, mensajes } = await evaluar({});
    expect(mensajes).toEqual([]);
    expect(dto.pagina).toBe(1);
  });

  it('convierte el texto a número', async () => {
    expect((await evaluar({ pagina: '3' })).dto.pagina).toBe(3);
  });

  it.each(['0', '-1', '1.5', 'abc', '10001'])(
    'rechaza la página %s',
    async (pagina) => {
      expect((await evaluar({ pagina })).mensajes.length).toBeGreaterThan(0);
    },
  );
});
