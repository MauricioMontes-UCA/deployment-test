import { plainToInstance } from 'class-transformer';
import { validate, type ValidationError } from 'class-validator';
import { CrearResenasDto } from './crear-resenas.dto.js';

const valido = {
  bien: { puntuacion: 5, comentario: 'Todo en orden.' },
  arrendador: { puntuacion: 4 },
};

/** Rutas de los campos con error, como `bien.puntuacion`. */
function rutas(errores: ValidationError[], padre = ''): string[] {
  return errores.flatMap((error) => {
    const ruta = padre ? `${padre}.${error.property}` : error.property;
    return error.children?.length ? rutas(error.children, ruta) : [ruta];
  });
}

async function errores(cuerpo: Record<string, unknown>) {
  const dto = plainToInstance(CrearResenasDto, cuerpo);
  return { dto, campos: rutas(await validate(dto)) };
}

describe('CrearResenasDto', () => {
  it('acepta las dos reseñas, con comentario opcional', async () => {
    expect((await errores(valido)).campos).toEqual([]);
  });

  it('un comentario vacío o de espacios cuenta como no enviado', async () => {
    const { dto, campos } = await errores({
      ...valido,
      bien: { puntuacion: 3, comentario: '   ' },
    });

    expect(campos).toEqual([]);
    expect(dto.bien.comentario).toBeUndefined();
  });

  it('recorta el comentario', async () => {
    const { dto } = await errores({
      ...valido,
      bien: { puntuacion: 3, comentario: '  Muy bien.  ' },
    });

    expect(dto.bien.comentario).toBe('Muy bien.');
  });

  it.each(['bien', 'arrendador'])('exige la reseña %s', async (campo) => {
    const cuerpo: Record<string, unknown> = { ...valido };
    delete cuerpo[campo];

    expect((await errores(cuerpo)).campos).toEqual([campo]);
  });

  it.each([0, 6, 3.5, '5', null])(
    'rechaza la puntuación %s',
    async (puntuacion) => {
      const { campos } = await errores({ ...valido, bien: { puntuacion } });

      expect(campos).toEqual(['bien.puntuacion']);
    },
  );

  it('acepta un comentario de 500 caracteres y rechaza uno de 501', async () => {
    const con = (n: number) =>
      errores({
        ...valido,
        arrendador: { puntuacion: 4, comentario: 'a'.repeat(n) },
      });

    expect((await con(500)).campos).toEqual([]);
    expect((await con(501)).campos).toEqual(['arrendador.comentario']);
  });

  it('rechaza una reseña que no es un objeto', async () => {
    expect((await errores({ ...valido, bien: 5 })).campos).toEqual(['bien']);
  });
});
