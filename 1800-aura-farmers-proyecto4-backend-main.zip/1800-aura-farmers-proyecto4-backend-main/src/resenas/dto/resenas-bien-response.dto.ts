import { ApiProperty } from '@nestjs/swagger';
import type { ResenaDeBien } from '@Resenas/repositories';

/** Autor de una reseña: solo su nombre de usuario, nunca el email. */
export class AutorResenaResponseDto {
  @ApiProperty({ example: 'carlos_r' })
  nombreUsuario!: string;
}

/** Una reseña de tipo BIEN en el listado público. */
export class ResenaBienResponseDto {
  @ApiProperty({ format: 'uuid' })
  id!: string;

  @ApiProperty({ example: 5, minimum: 1, maximum: 5 })
  puntuacion!: number;

  @ApiProperty({
    type: String,
    required: false,
    example: 'Muy limpio y bien ubicado.',
    description: 'Se omite si la reseña no tiene comentario.',
  })
  comentario?: string;

  @ApiProperty({ type: AutorResenaResponseDto })
  autor!: AutorResenaResponseDto;

  @ApiProperty({ type: String, format: 'date-time' })
  creadaEn!: string;

  static from(resena: ResenaDeBien): ResenaBienResponseDto {
    return {
      id: resena.id,
      puntuacion: resena.puntuacion,
      ...(resena.comentario === null ? {} : { comentario: resena.comentario }),
      autor: { nombreUsuario: resena.autor.nombreUsuario },
      creadaEn: resena.creadaEn.toISOString(),
    };
  }
}

/** Página de `GET /bienes/:bienId/resenas`. */
export class PaginaResenasBienResponseDto {
  @ApiProperty({ type: [ResenaBienResponseDto] })
  items!: ResenaBienResponseDto[];

  @ApiProperty({ example: 1 })
  pagina!: number;

  @ApiProperty({ example: 23, description: 'Reseñas del bien, sin paginar.' })
  total!: number;

  @ApiProperty({ description: 'Si hay más reseñas después de esta página.' })
  hayMas!: boolean;
}
