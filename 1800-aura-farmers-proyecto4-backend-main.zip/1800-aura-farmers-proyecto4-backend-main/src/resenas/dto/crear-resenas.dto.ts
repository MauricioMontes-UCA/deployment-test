import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import {
  IsDefined,
  IsInt,
  IsObject,
  IsOptional,
  IsString,
  Max,
  MaxLength,
  Min,
  ValidateNested,
} from 'class-validator';

/** Un texto vacío o de solo espacios se trata como no enviado. */
function textoOpcional({ value }: { value: unknown }): unknown {
  if (typeof value !== 'string') return value;
  const recortado = value.trim();
  return recortado === '' ? undefined : recortado;
}

/** Puntuación y comentario de una de las dos reseñas. */
export class CalificacionDto {
  @ApiProperty({ minimum: 1, maximum: 5, example: 5 })
  @IsInt({ message: 'La puntuación debe ser un número entero.' })
  @Min(1, { message: 'La puntuación debe estar entre 1 y 5.' })
  @Max(5, { message: 'La puntuación debe estar entre 1 y 5.' })
  puntuacion!: number;

  @ApiPropertyOptional({ maxLength: 500, example: 'Todo en orden.' })
  @IsOptional()
  @Transform(textoOpcional)
  @IsString({ message: 'El comentario debe ser texto.' })
  @MaxLength(500, {
    message: 'El comentario no puede superar los 500 caracteres.',
  })
  comentario?: string;
}

/**
 * Cuerpo de `POST /reservas/:reservaId/resenas`.
 *
 * Aquí solo se valida la forma. El estado, el plazo, la pertenencia y la
 * unicidad los valida el servicio. El autor sale del token, nunca del cuerpo.
 */
export class CrearResenasDto {
  @ApiProperty({ type: CalificacionDto, description: 'Reseña del bien.' })
  @IsDefined({ message: 'Falta la reseña del bien.' })
  @IsObject({ message: 'La reseña del bien debe ser un objeto.' })
  @ValidateNested()
  @Type(() => CalificacionDto)
  bien!: CalificacionDto;

  @ApiProperty({
    type: CalificacionDto,
    description: 'Reseña del arrendador.',
  })
  @IsDefined({ message: 'Falta la reseña del arrendador.' })
  @IsObject({ message: 'La reseña del arrendador debe ser un objeto.' })
  @ValidateNested()
  @Type(() => CalificacionDto)
  arrendador!: CalificacionDto;
}
