import {
  Body,
  Controller,
  Delete,
  Get,
  HttpException,
  HttpStatus,
  Param,
  ParseUUIDPipe,
  Post,
  Put,
  Res,
} from '@nestjs/common';
import {
  ApiBadRequestResponse,
  ApiBearerAuth,
  ApiConflictResponse,
  ApiCreatedResponse,
  ApiForbiddenResponse,
  ApiNotFoundResponse,
  ApiOkResponse,
  ApiOperation,
  ApiResponse,
  ApiTags,
  ApiUnauthorizedResponse,
  ApiUnprocessableEntityResponse,
} from '@nestjs/swagger';
import type { Response } from 'express';
import { CurrentUser, Public, Roles } from '@Auth/decorators';
import type { AuthenticatedUser } from '@Auth/types';
import { Rol } from '@PrismaClient';
import {
  CalificacionArrendatarioResponseDto,
  CalificarArrendatarioDto,
  ConsultaCalificacionArrendatarioResponseDto,
  CrearResenasDto,
  ResenasResponseDto,
} from '@Resenas/dto';
import { ResenasService } from '@Resenas/services';

/** Reseñas del bien y del arrendador: solo admite POST. */
const RUTA_RESENAS = ':reservaId/resenas';
/** Calificación del arrendatario: se registra con POST y se consulta con GET. */
const RUTA_ARRENDATARIO = ':reservaId/resenas/arrendatario';

/** Métodos que admite cada ruta, para la cabecera `Allow` de los 405. */
const ALLOW_RESENAS = 'POST';
const ALLOW_ARRENDATARIO = 'GET, POST';

/**
 * Reseñas de una reserva terminada. Comparte la ruta `/reservas` con los
 * controladores de reservas.
 *
 * - El arrendatario califica el bien y al arrendador (H15).
 * - El arrendador califica al arrendatario y consulta esa calificación (H16).
 *
 * Cada endpoint declara su rol, porque aquí escriben los dos lados. Una reseña
 * no se edita ni se borra: PUT y DELETE responden 405.
 */
@ApiTags('resenas')
@ApiBearerAuth()
@Controller('reservas')
export class ResenasController {
  constructor(private readonly resenasService: ResenasService) {}

  @Post(RUTA_RESENAS)
  @Roles(Rol.ARRENDATARIO)
  @ApiOperation({
    summary: 'Califica el bien y al arrendador de una reserva finalizada',
  })
  @ApiCreatedResponse({ type: ResenasResponseDto })
  @ApiBadRequestResponse({
    description:
      'El id no es un UUID, falta una reseña, la puntuación no es un entero de 1 a 5, el comentario supera los 500 caracteres o se envió un campo no permitido.',
  })
  @ApiUnauthorizedResponse({
    description: 'Token ausente, inválido o expirado.',
  })
  @ApiForbiddenResponse({ description: 'El usuario no es ARRENDATARIO.' })
  @ApiNotFoundResponse({
    description: 'La reserva no existe o es de otro arrendatario.',
  })
  @ApiConflictResponse({ description: 'La reserva ya fue calificada.' })
  @ApiUnprocessableEntityResponse({
    description:
      'La reserva no está FINALIZADA o pasaron más de 14 días desde su finalización.',
  })
  async registrar(
    @Param('reservaId', ParseUUIDPipe) reservaId: string,
    @CurrentUser() usuario: AuthenticatedUser,
    @Body() dto: CrearResenasDto,
  ): Promise<ResenasResponseDto> {
    const { resenaBien, resenaArrendador } =
      await this.resenasService.registrar(reservaId, usuario.id, dto);
    return ResenasResponseDto.from(resenaBien, resenaArrendador);
  }

  @Post(RUTA_ARRENDATARIO)
  @Roles(Rol.ARRENDADOR)
  @ApiOperation({
    summary:
      'Califica al arrendatario de una reserva finalizada y devuelve su promedio',
    description:
      'Solo el arrendador dueño del bien de la reserva. El promedio considera las calificaciones ARRENDATARIO de todas las reservas del arrendatario, redondeado a un decimal.',
  })
  @ApiCreatedResponse({ type: CalificacionArrendatarioResponseDto })
  @ApiBadRequestResponse({
    description:
      'El id no es un UUID, la puntuación no es un entero de 1 a 5, el comentario supera los 500 caracteres o se envió un campo no permitido.',
  })
  @ApiUnauthorizedResponse({
    description: 'Token ausente, inválido o expirado.',
  })
  @ApiForbiddenResponse({ description: 'El usuario no es ARRENDADOR.' })
  @ApiNotFoundResponse({
    description:
      'La reserva no existe o su bien no pertenece al arrendador autenticado.',
  })
  @ApiConflictResponse({
    description: 'La reserva ya tiene calificación del arrendatario.',
  })
  @ApiUnprocessableEntityResponse({
    description:
      'La reserva no está FINALIZADA o pasaron más de 14 días desde la devolución.',
  })
  async calificarArrendatario(
    @Param('reservaId', ParseUUIDPipe) reservaId: string,
    @CurrentUser() usuario: AuthenticatedUser,
    @Body() dto: CalificarArrendatarioDto,
  ): Promise<CalificacionArrendatarioResponseDto> {
    const { resena, promedioArrendatario, totalCalificaciones } =
      await this.resenasService.calificarArrendatario(
        reservaId,
        usuario.id,
        dto,
      );
    return CalificacionArrendatarioResponseDto.from(
      resena,
      promedioArrendatario,
      totalCalificaciones,
    );
  }

  @Get(RUTA_ARRENDATARIO)
  @Roles(Rol.ARRENDADOR)
  @ApiOperation({
    summary:
      'Consulta la calificación del arrendatario de una reserva y su promedio',
    description:
      'Solo el arrendador dueño del bien de la reserva. Solo lee: no crea ni modifica reseñas, y no exige que la reserva esté FINALIZADA ni que siga dentro del plazo de 14 días. `resena` es null si esta reserva todavía no tiene calificación. El promedio y el total son los del arrendatario en todas sus reservas; sin calificaciones, el promedio es null y el total 0.',
  })
  @ApiOkResponse({ type: ConsultaCalificacionArrendatarioResponseDto })
  @ApiBadRequestResponse({ description: 'El id no es un UUID.' })
  @ApiUnauthorizedResponse({
    description: 'Token ausente, inválido o expirado.',
  })
  @ApiForbiddenResponse({ description: 'El usuario no es ARRENDADOR.' })
  @ApiNotFoundResponse({
    description:
      'La reserva no existe o su bien no pertenece al arrendador autenticado (mismo mensaje en los dos casos).',
  })
  async consultarCalificacionArrendatario(
    @Param('reservaId', ParseUUIDPipe) reservaId: string,
    @CurrentUser() usuario: AuthenticatedUser,
  ): Promise<ConsultaCalificacionArrendatarioResponseDto> {
    const { resena, promedioArrendatario, totalCalificaciones } =
      await this.resenasService.consultarCalificacionArrendatario(
        reservaId,
        usuario.id,
      );
    return ConsultaCalificacionArrendatarioResponseDto.from(
      resena,
      promedioArrendatario,
      totalCalificaciones,
    );
  }

  // Públicas a propósito: una reseña nunca se edita ni se borra, así que la
  // respuesta es 405 haya o no sesión. Van separadas por ruta porque cada una
  // anuncia en `Allow` sus propios métodos.
  @Put(RUTA_RESENAS)
  @Public()
  @ApiOperation({ summary: 'No permitido: una reseña no se edita' })
  @ApiResponse({ status: 405, description: 'Las reseñas no se editan.' })
  editar(@Res({ passthrough: true }) res: Response): never {
    return metodoNoPermitido(
      res,
      ALLOW_RESENAS,
      'Las reseñas no se pueden editar.',
    );
  }

  @Delete(RUTA_RESENAS)
  @Public()
  @ApiOperation({ summary: 'No permitido: una reseña no se borra' })
  @ApiResponse({ status: 405, description: 'Las reseñas no se borran.' })
  eliminar(@Res({ passthrough: true }) res: Response): never {
    return metodoNoPermitido(
      res,
      ALLOW_RESENAS,
      'Las reseñas no se pueden eliminar.',
    );
  }

  @Put(RUTA_ARRENDATARIO)
  @Public()
  @ApiOperation({ summary: 'No permitido: una reseña no se edita' })
  @ApiResponse({ status: 405, description: 'Las reseñas no se editan.' })
  editarCalificacionArrendatario(
    @Res({ passthrough: true }) res: Response,
  ): never {
    return metodoNoPermitido(
      res,
      ALLOW_ARRENDATARIO,
      'Las reseñas no se pueden editar.',
    );
  }

  @Delete(RUTA_ARRENDATARIO)
  @Public()
  @ApiOperation({ summary: 'No permitido: una reseña no se borra' })
  @ApiResponse({ status: 405, description: 'Las reseñas no se borran.' })
  eliminarCalificacionArrendatario(
    @Res({ passthrough: true }) res: Response,
  ): never {
    return metodoNoPermitido(
      res,
      ALLOW_ARRENDATARIO,
      'Las reseñas no se pueden eliminar.',
    );
  }
}

/** Responde 405 indicando, como pide HTTP, qué métodos sí admite la ruta. */
function metodoNoPermitido(
  res: Response,
  permitidos: string,
  mensaje: string,
): never {
  res.setHeader('Allow', permitidos);
  throw new HttpException(mensaje, HttpStatus.METHOD_NOT_ALLOWED);
}
