/** Quién resuelve el depósito: el arrendador propietario o la tarea diaria. */
export type ActorResolucion =
  { tipo: 'ARRENDADOR'; usuarioId: string } | { tipo: 'SISTEMA' };
