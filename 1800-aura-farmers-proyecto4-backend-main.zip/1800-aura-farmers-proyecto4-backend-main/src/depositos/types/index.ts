export * from './actor-resolucion.js';
