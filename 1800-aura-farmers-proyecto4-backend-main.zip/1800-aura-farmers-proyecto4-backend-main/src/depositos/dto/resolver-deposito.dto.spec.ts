import { plainToInstance } from 'class-transformer';
import { validate } from 'class-validator';
import { ResolverDepositoDto } from './resolver-deposito.dto.js';

async function errores(cuerpo: Record<string, unknown>) {
  const dto = plainToInstance(ResolverDepositoDto, cuerpo);
  const result = await validate(dto);
  return { dto, campos: result.map((e) => e.property) };
}

describe('ResolverDepositoDto', () => {
  it('acepta LIBERAR sin más campos', async () => {
    expect((await errores({ accion: 'LIBERAR' })).campos).toEqual([]);
  });

  it('acepta RETENER con importe y justificación', async () => {
    const { campos } = await errores({
      accion: 'RETENER',
      importeRetenido: 25.5,
      justificacion: 'Puerta dañada.',
    });
    expect(campos).toEqual([]);
  });

  it.each([undefined, 'liberar', 'OTRA', 1])(
    'rechaza la acción %s',
    async (accion) => {
      expect((await errores({ accion })).campos).toContain('accion');
    },
  );

  it.each([-1, 10.123, '10', Number.NaN, 1e12])(
    'rechaza el importe %s',
    async (importeRetenido) => {
      const { campos } = await errores({ accion: 'RETENER', importeRetenido });
      expect(campos).toContain('importeRetenido');
    },
  );

  it('acepta 0 como importe (se valida en el servicio según la acción)', async () => {
    const { campos } = await errores({ accion: 'LIBERAR', importeRetenido: 0 });
    expect(campos).toEqual([]);
  });

  it('recorta la justificación y trata la vacía como no enviada', async () => {
    const { dto } = await errores({ accion: 'RETENER', justificacion: '  ' });
    expect(dto.justificacion).toBeUndefined();
    const otro = await errores({ accion: 'RETENER', justificacion: ' hola ' });
    expect(otro.dto.justificacion).toBe('hola');
  });

  it('rechaza una justificación de más de 500 caracteres', async () => {
    const { campos } = await errores({
      accion: 'RETENER',
      justificacion: 'a'.repeat(501),
    });
    expect(campos).toContain('justificacion');
  });

  it('acepta una justificación de exactamente 500 caracteres', async () => {
    const { campos } = await errores({
      accion: 'RETENER',
      justificacion: 'a'.repeat(500),
    });
    expect(campos).toEqual([]);
  });
});
