import { Prisma, type Deposito } from '@PrismaClient';
import { DepositoConsultaResponseDto } from './deposito-response.dto.js';

const d = (n: number | string) => new Prisma.Decimal(n);
const base = {
  id: 'dep-1',
  reservaId: 'res-1',
  importeOriginal: d(100),
  importeRetenido: d(0),
  importeLiberado: d(0),
  estado: 'PENDIENTE',
  resolucionAutomatica: false,
  justificacion: null,
  fechaResolucion: null,
  resueltoPorId: 'user-1',
} as unknown as Deposito;

describe('DepositoConsultaResponseDto.fromEntity', () => {
  it('un depósito PENDIENTE muestra todo el saldo y omite justificación y fecha', () => {
    const dto = DepositoConsultaResponseDto.fromEntity(base);

    expect(dto).toEqual({
      depositoId: 'dep-1',
      reservaId: 'res-1',
      importeOriginal: 100,
      importeDisponible: 100,
      importeRetenido: 0,
      importeLiberado: 0,
      estado: 'PENDIENTE',
      resolucionAutomatica: false,
    });
    expect('justificacion' in dto).toBe(false);
    expect('fechaResolucion' in dto).toBe(false);
  });

  it('un depósito retenido en parte muestra justificación, fecha y saldo 0', () => {
    const dto = DepositoConsultaResponseDto.fromEntity({
      ...base,
      estado: 'PARCIALMENTE_RETENIDO',
      importeRetenido: d('25.50'),
      importeLiberado: d('74.50'),
      justificacion: 'Puerta dañada.',
      fechaResolucion: new Date('2026-12-13T16:02:11Z'),
    });

    expect(dto).toMatchObject({
      importeRetenido: 25.5,
      importeLiberado: 74.5,
      importeDisponible: 0,
      justificacion: 'Puerta dañada.',
      fechaResolucion: '2026-12-13T16:02:11.000Z',
    });
  });

  it('un depósito liberado automáticamente lo indica y no expone quién lo resolvió', () => {
    const dto = DepositoConsultaResponseDto.fromEntity({
      ...base,
      estado: 'LIBERADO',
      importeLiberado: d(100),
      resolucionAutomatica: true,
      fechaResolucion: new Date('2026-12-15T00:05:00Z'),
    });

    expect(dto).toMatchObject({
      estado: 'LIBERADO',
      resolucionAutomatica: true,
      importeDisponible: 0,
    });
    expect(dto).not.toHaveProperty('resueltoPor');
    expect(dto).not.toHaveProperty('resueltoPorId');
  });
});
