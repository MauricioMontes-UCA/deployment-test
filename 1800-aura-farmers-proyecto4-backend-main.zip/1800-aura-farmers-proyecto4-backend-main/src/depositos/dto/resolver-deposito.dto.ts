import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import {
  IsEnum,
  IsNumber,
  IsOptional,
  IsString,
  Max,
  MaxLength,
  Min,
} from 'class-validator';

export const AccionResolucionDeposito = {
  LIBERAR: 'LIBERAR',
  RETENER: 'RETENER',
} as const;
export type AccionResolucionDeposito =
  (typeof AccionResolucionDeposito)[keyof typeof AccionResolucionDeposito];

/** El importe máximo que cabe en NUMERIC(12,2). */
const IMPORTE_MAXIMO = 9_999_999_999.99;

/** Un texto vacío o de solo espacios se trata como no enviado. */
function textoOpcional({ value }: { value: unknown }): unknown {
  if (typeof value !== 'string') return value;
  const recortado = value.trim();
  return recortado === '' ? undefined : recortado;
}

/**
 * Cuerpo de `POST /reservas/:reservaId/deposito/resolucion`.
 *
 * Aquí solo se valida la forma. Que RETENER lleve importe y justificación, y
 * que el importe no supere el saldo, lo valida `DepositoService`: también lo
 * usa la tarea diaria, que no pasa por este DTO.
 */
export class ResolverDepositoDto {
  @ApiProperty({
    enum: AccionResolucionDeposito,
    enumName: 'AccionResolucionDeposito',
  })
  @IsEnum(AccionResolucionDeposito, {
    message: 'La acción debe ser LIBERAR o RETENER.',
  })
  accion!: AccionResolucionDeposito;

  @ApiPropertyOptional({
    example: 25.5,
    description:
      'Obligatorio al RETENER (mayor que cero y hasta el saldo, 2 decimales). Al LIBERAR se omite o es 0.',
  })
  @IsOptional()
  @IsNumber(
    { allowNaN: false, allowInfinity: false, maxDecimalPlaces: 2 },
    {
      message: 'El importe a retener debe ser un número con hasta 2 decimales.',
    },
  )
  @Min(0, { message: 'El importe a retener no puede ser negativo.' })
  @Max(IMPORTE_MAXIMO, { message: 'El importe a retener es demasiado grande.' })
  importeRetenido?: number;

  @ApiPropertyOptional({
    example: 'La puerta quedó dañada.',
    minLength: 1,
    maxLength: 500,
    description: 'Obligatoria al RETENER.',
  })
  @IsOptional()
  @Transform(textoOpcional)
  @IsString({ message: 'La justificación debe ser texto.' })
  @MaxLength(500, {
    message: 'La justificación no puede superar los 500 caracteres.',
  })
  justificacion?: string;
}
