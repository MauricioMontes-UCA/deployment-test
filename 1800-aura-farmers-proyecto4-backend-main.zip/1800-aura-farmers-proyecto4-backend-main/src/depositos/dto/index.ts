export * from './resolver-deposito.dto.js';
export * from './deposito-response.dto.js';
