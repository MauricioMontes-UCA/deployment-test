import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { EstadoDeposito, type Deposito } from '@PrismaClient';
import { saldoDisponible } from '@Depositos/utils';

/** Respuesta de `POST /reservas/:reservaId/deposito/resolucion`. */
export class DepositoResponseDto {
  @ApiProperty({ format: 'uuid' })
  depositoId!: string;

  @ApiProperty({ enum: EstadoDeposito, enumName: 'EstadoDeposito' })
  estado!: EstadoDeposito;

  @ApiProperty({ example: 100 })
  importeOriginal!: number;

  @ApiProperty({ example: 25.5 })
  importeRetenido!: number;

  @ApiProperty({ example: 74.5 })
  importeLiberado!: number;

  @ApiProperty({ type: String, nullable: true })
  justificacion!: string | null;

  @ApiProperty({ type: String, format: 'date-time', nullable: true })
  fechaResolucion!: string | null;

  @ApiProperty({
    type: String,
    format: 'uuid',
    nullable: true,
    description: 'Nulo si lo resolvió el sistema o aún está pendiente.',
  })
  resueltoPor!: string | null;

  static fromEntity(deposito: Deposito): DepositoResponseDto {
    return {
      depositoId: deposito.id,
      estado: deposito.estado,
      importeOriginal: deposito.importeOriginal.toNumber(),
      importeRetenido: deposito.importeRetenido.toNumber(),
      importeLiberado: deposito.importeLiberado.toNumber(),
      justificacion: deposito.justificacion,
      fechaResolucion: deposito.fechaResolucion?.toISOString() ?? null,
      resueltoPor: deposito.resueltoPorId,
    };
  }
}

/**
 * Respuesta de `GET /reservas/:reservaId/deposito` (H12).
 *
 * `justificacion` y `fechaResolucion` se omiten mientras no existen: un
 * depósito PENDIENTE no tiene fecha de resolución. `resueltoPor` no se expone
 * al arrendatario.
 */
export class DepositoConsultaResponseDto {
  @ApiProperty({ format: 'uuid' })
  depositoId!: string;

  @ApiProperty({ format: 'uuid' })
  reservaId!: string;

  @ApiProperty({ example: 100 })
  importeOriginal!: number;

  @ApiProperty({
    example: 100,
    description:
      'Lo que aún se puede liberar o retener: el original menos lo retenido y lo liberado. 0 una vez resuelto.',
  })
  importeDisponible!: number;

  @ApiProperty({ example: 25.5 })
  importeRetenido!: number;

  @ApiProperty({ example: 74.5 })
  importeLiberado!: number;

  @ApiProperty({ enum: EstadoDeposito, enumName: 'EstadoDeposito' })
  estado!: EstadoDeposito;

  @ApiProperty({
    description: 'true si el sistema lo liberó por vencimiento del plazo.',
  })
  resolucionAutomatica!: boolean;

  @ApiPropertyOptional({ description: 'Solo si el arrendador la indicó.' })
  justificacion?: string;

  @ApiPropertyOptional({
    type: String,
    format: 'date-time',
    description: 'Solo cuando el depósito ya fue resuelto.',
  })
  fechaResolucion?: string;

  static fromEntity(deposito: Deposito): DepositoConsultaResponseDto {
    return {
      depositoId: deposito.id,
      reservaId: deposito.reservaId,
      importeOriginal: deposito.importeOriginal.toNumber(),
      importeDisponible: saldoDisponible(deposito).toNumber(),
      importeRetenido: deposito.importeRetenido.toNumber(),
      importeLiberado: deposito.importeLiberado.toNumber(),
      estado: deposito.estado,
      resolucionAutomatica: deposito.resolucionAutomatica,
      ...(deposito.justificacion
        ? { justificacion: deposito.justificacion }
        : {}),
      ...(deposito.fechaResolucion
        ? { fechaResolucion: deposito.fechaResolucion.toISOString() }
        : {}),
    };
  }
}
