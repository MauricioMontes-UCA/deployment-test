import {
  Body,
  Controller,
  Get,
  HttpCode,
  HttpStatus,
  Param,
  ParseUUIDPipe,
  Post,
} from '@nestjs/common';
import {
  ApiBadRequestResponse,
  ApiBearerAuth,
  ApiConflictResponse,
  ApiForbiddenResponse,
  ApiNotFoundResponse,
  ApiOkResponse,
  ApiOperation,
  ApiTags,
  ApiUnauthorizedResponse,
  ApiUnprocessableEntityResponse,
} from '@nestjs/swagger';
import { CurrentUser, Roles } from '@Auth/decorators';
import type { AuthenticatedUser } from '@Auth/types';
import { Rol } from '@PrismaClient';
import {
  DepositoConsultaResponseDto,
  DepositoResponseDto,
  ResolverDepositoDto,
} from '@Depositos/dto';
import { DepositoService } from '@Depositos/services';

/**
 * Depósito de garantía de una reserva. Comparte la ruta `/reservas` con
 * `ReservasController`. Resolverlo es del arrendador propietario del bien;
 * consultarlo, de los dos participantes de la reserva.
 */
@ApiTags('depositos')
@ApiBearerAuth()
@Roles(Rol.ARRENDADOR)
@Controller('reservas')
export class DepositosController {
  constructor(private readonly depositoService: DepositoService) {}

  @Get(':reservaId/deposito')
  // Anula el rol de la clase: lo consultan ambos participantes de la reserva.
  @Roles(Rol.ARRENDADOR, Rol.ARRENDATARIO)
  @ApiOperation({
    summary: 'Consulta el estado y el detalle del depósito de la reserva',
  })
  @ApiOkResponse({ type: DepositoConsultaResponseDto })
  @ApiBadRequestResponse({ description: 'El id no es un UUID.' })
  @ApiUnauthorizedResponse({
    description: 'Token ausente, inválido o expirado.',
  })
  @ApiForbiddenResponse({
    description:
      'El usuario no es el arrendatario de la reserva ni el arrendador del bien.',
  })
  @ApiNotFoundResponse({
    description: 'La reserva no existe o no tiene depósito.',
  })
  async consultar(
    @Param('reservaId', ParseUUIDPipe) reservaId: string,
    @CurrentUser() usuario: AuthenticatedUser,
  ): Promise<DepositoConsultaResponseDto> {
    const deposito = await this.depositoService.consultarPorReserva(
      reservaId,
      usuario.id,
    );
    return DepositoConsultaResponseDto.fromEntity(deposito);
  }

  @Post(':reservaId/deposito/resolucion')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    summary: 'Libera el depósito o retiene una parte o su totalidad',
  })
  @ApiOkResponse({ type: DepositoResponseDto })
  @ApiBadRequestResponse({
    description:
      'Acción inválida, RETENER sin importe positivo o sin justificación, importe con más de 2 decimales, LIBERAR con importe, o justificación de más de 500 caracteres.',
  })
  @ApiUnauthorizedResponse({
    description: 'Token ausente, inválido o expirado.',
  })
  @ApiForbiddenResponse({
    description: 'El usuario no es ARRENDADOR o el bien no es suyo.',
  })
  @ApiNotFoundResponse({
    description: 'La reserva no existe o no tiene depósito.',
  })
  @ApiConflictResponse({
    description:
      'El depósito ya fue resuelto, o se liberó automáticamente por vencimiento del plazo.',
  })
  @ApiUnprocessableEntityResponse({
    description:
      'La renta no está FINALIZADA con devolución registrada, o el importe a retener supera el saldo.',
  })
  async resolver(
    @Param('reservaId', ParseUUIDPipe) reservaId: string,
    @CurrentUser() usuario: AuthenticatedUser,
    @Body() dto: ResolverDepositoDto,
  ): Promise<DepositoResponseDto> {
    const deposito = await this.depositoService.resolverPorReserva(
      reservaId,
      usuario.id,
      dto,
    );
    return DepositoResponseDto.fromEntity(deposito);
  }
}
