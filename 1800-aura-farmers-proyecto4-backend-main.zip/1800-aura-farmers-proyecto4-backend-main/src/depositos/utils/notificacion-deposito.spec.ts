import { describe, expect, it } from 'vitest';
import { EstadoDeposito, Prisma } from '@PrismaClient';
import { mensajeDepositoResuelto } from './notificacion-deposito.js';

const decimal = (valor: string) => new Prisma.Decimal(valor);

describe('BE-22.2 - Mensaje de depósito resuelto', () => {
  const base = {
    importeOriginal: decimal('100.00'),
    importeLiberado: decimal('100.00'),
    importeRetenido: decimal('0.00'),
    estado: EstadoDeposito.LIBERADO,
    resolucionAutomatica: false,
    nombreBien: 'Cámara Sony',
  };

  it('describe una liberación completa', () => {
    expect(mensajeDepositoResuelto(base)).toBe(
      'Tu depósito de $100.00 por Cámara Sony fue liberado ($100.00).',
    );
  });

  it('describe una retención parcial', () => {
    const mensaje = mensajeDepositoResuelto({
      ...base,
      estado: EstadoDeposito.PARCIALMENTE_RETENIDO,
      importeLiberado: decimal('75.00'),
      importeRetenido: decimal('25.00'),
    });

    expect(mensaje).toContain('retenido en parte ($25.00)');
    expect(mensaje).toContain('se liberaron $75.00');
  });

  it('describe una retención completa', () => {
    const mensaje = mensajeDepositoResuelto({
      ...base,
      estado: EstadoDeposito.RETENIDO,
      importeLiberado: decimal('0.00'),
      importeRetenido: decimal('100.00'),
    });

    expect(mensaje).toContain('retenido por completo');
  });

  it('identifica una liberación automática', () => {
    const mensaje = mensajeDepositoResuelto({
      ...base,
      resolucionAutomatica: true,
    });

    expect(mensaje).toContain(
      'liberado automáticamente por vencimiento del plazo',
    );
  });

  it('limita el mensaje a 300 caracteres', () => {
    const mensaje = mensajeDepositoResuelto({
      ...base,
      nombreBien: 'A'.repeat(500),
    });

    expect(mensaje.length).toBeLessThanOrEqual(300);
  });
});
