import { EstadoDeposito, Prisma } from '@PrismaClient';

export type AccionResolucion = 'LIBERAR' | 'RETENER';

export interface ImportesDeposito {
  importeOriginal: Prisma.Decimal;
  importeRetenido: Prisma.Decimal;
  importeLiberado: Prisma.Decimal;
}

export type ResultadoCalculo =
  | {
      estado: EstadoDeposito;
      importeRetenido: Prisma.Decimal;
      importeLiberado: Prisma.Decimal;
    }
  | { rechazo: 'RETENCION_EXCEDE_SALDO' };

/** Lo que aún no se ha liberado ni retenido. */
export function saldoDisponible({
  importeOriginal,
  importeRetenido,
  importeLiberado,
}: ImportesDeposito): Prisma.Decimal {
  return importeOriginal.minus(importeRetenido).minus(importeLiberado);
}

/**
 * Reparte el saldo del depósito entre retenido y liberado.
 *
 * LIBERAR libera todo el saldo. RETENER retiene `importeRetenido` y libera el
 * resto, de modo que retenido + liberado = original (la base lo exige con un
 * CHECK). Retener el saldo completo da RETENIDO; una parte, PARCIALMENTE_RETENIDO.
 *
 * Es una función pura: la llama el repositorio con el depósito ya bloqueado.
 */
export function calcularResolucion(
  importes: ImportesDeposito,
  accion: AccionResolucion,
  importeRetenido: Prisma.Decimal,
): ResultadoCalculo {
  const saldo = saldoDisponible(importes);

  if (accion === 'LIBERAR') {
    return {
      estado: EstadoDeposito.LIBERADO,
      importeRetenido: importes.importeRetenido,
      importeLiberado: importes.importeLiberado.plus(saldo),
    };
  }

  if (importeRetenido.greaterThan(saldo)) {
    return { rechazo: 'RETENCION_EXCEDE_SALDO' };
  }
  return {
    estado: importeRetenido.equals(saldo)
      ? EstadoDeposito.RETENIDO
      : EstadoDeposito.PARCIALMENTE_RETENIDO,
    importeRetenido: importes.importeRetenido.plus(importeRetenido),
    importeLiberado: importes.importeLiberado.plus(
      saldo.minus(importeRetenido),
    ),
  };
}
