import { EstadoDeposito, Prisma } from '@PrismaClient';

export const TITULO_DEPOSITO_RESUELTO = 'Depósito resuelto';
export const REFERENCIA_DEPOSITO_RESUELTO = 'DEPOSITO_RESUELTO';

export interface DatosMensajeDeposito {
  importeOriginal: Prisma.Decimal;
  importeLiberado: Prisma.Decimal;
  importeRetenido: Prisma.Decimal;
  estado: EstadoDeposito;
  resolucionAutomatica: boolean;
  nombreBien: string;
}

export function mensajeDepositoResuelto(datos: DatosMensajeDeposito): string {
  const original = datos.importeOriginal.toFixed(2);
  const liberado = datos.importeLiberado.toFixed(2);
  const retenido = datos.importeRetenido.toFixed(2);

  const prefijo = `Tu depósito de $${original} por `;

  let sufijo: string;

  if (datos.resolucionAutomatica) {
    sufijo = ' fue liberado automáticamente por vencimiento del plazo.';
  } else {
    switch (datos.estado) {
      case EstadoDeposito.LIBERADO:
        sufijo = ` fue liberado ($${liberado}).`;
        break;

      case EstadoDeposito.PARCIALMENTE_RETENIDO:
        sufijo =
          ` fue retenido en parte ($${retenido})` +
          ` y se liberaron $${liberado}.`;
        break;

      case EstadoDeposito.RETENIDO:
        sufijo = ' fue retenido por completo.';
        break;

      default:
        throw new Error('El depósito todavía no tiene una resolución válida.');
    }
  }

  const espacioDisponible = Math.max(0, 300 - prefijo.length - sufijo.length);

  return prefijo + datos.nombreBien.slice(0, espacioDisponible) + sufijo;
}
