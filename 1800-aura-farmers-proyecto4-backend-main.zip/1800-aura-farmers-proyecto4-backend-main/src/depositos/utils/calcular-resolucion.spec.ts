import { Prisma } from '@PrismaClient';
import { calcularResolucion, saldoDisponible } from './calcular-resolucion.js';

const d = (n: number | string) => new Prisma.Decimal(n);
const pendiente = {
  importeOriginal: d(100),
  importeRetenido: d(0),
  importeLiberado: d(0),
};

describe('saldoDisponible', () => {
  it('es el original cuando nada se ha resuelto', () => {
    expect(saldoDisponible(pendiente).toString()).toBe('100');
  });

  it('descuenta lo retenido y lo liberado', () => {
    const saldo = saldoDisponible({
      importeOriginal: d(100),
      importeRetenido: d(30),
      importeLiberado: d(20),
    });
    expect(saldo.toString()).toBe('50');
  });
});

describe('calcularResolucion', () => {
  it('LIBERAR libera todo el saldo y no retiene nada', () => {
    expect(calcularResolucion(pendiente, 'LIBERAR', d(0))).toEqual({
      estado: 'LIBERADO',
      importeRetenido: d(0),
      importeLiberado: d(100),
    });
  });

  it('RETENER una parte deja el resto liberado', () => {
    expect(calcularResolucion(pendiente, 'RETENER', d('25.50'))).toEqual({
      estado: 'PARCIALMENTE_RETENIDO',
      importeRetenido: d('25.50'),
      importeLiberado: d('74.50'),
    });
  });

  it('RETENER todo el saldo da RETENIDO y no libera nada', () => {
    expect(calcularResolucion(pendiente, 'RETENER', d(100))).toEqual({
      estado: 'RETENIDO',
      importeRetenido: d(100),
      importeLiberado: d(0),
    });
  });

  it('retener un centavo sigue siendo parcial', () => {
    const r = calcularResolucion(pendiente, 'RETENER', d('0.01'));
    expect(r).toMatchObject({ estado: 'PARCIALMENTE_RETENIDO' });
  });

  it('rechaza retener más que el saldo, aunque sea por un centavo', () => {
    expect(calcularResolucion(pendiente, 'RETENER', d('100.01'))).toEqual({
      rechazo: 'RETENCION_EXCEDE_SALDO',
    });
  });

  it('retenido + liberado siempre suma el original', () => {
    for (const retenido of ['0.01', '33.33', '99.99', '100']) {
      const r = calcularResolucion(pendiente, 'RETENER', d(retenido));
      if ('rechazo' in r) throw new Error('no debía rechazar');
      expect(r.importeRetenido.plus(r.importeLiberado).toString()).toBe('100');
    }
  });
});
