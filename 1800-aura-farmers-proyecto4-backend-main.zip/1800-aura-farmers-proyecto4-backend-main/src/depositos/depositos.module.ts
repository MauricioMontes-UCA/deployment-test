import { Module } from '@nestjs/common';
import { NotificacionesModule } from '@Notificaciones';
import { DepositosController } from '@Depositos/controllers';
import { DepositoRepository } from '@Depositos/repositories';
import { DepositoService } from '@Depositos/services';

@Module({
  imports: [NotificacionesModule],
  controllers: [DepositosController],
  providers: [DepositoService, DepositoRepository],
  exports: [DepositoService],
})
export class DepositosModule {}
