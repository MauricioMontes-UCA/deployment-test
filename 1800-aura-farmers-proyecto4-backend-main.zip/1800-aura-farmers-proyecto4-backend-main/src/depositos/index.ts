export * from './depositos.module.js';
