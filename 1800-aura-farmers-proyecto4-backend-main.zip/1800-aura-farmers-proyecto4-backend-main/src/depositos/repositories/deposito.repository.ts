import { Injectable } from '@nestjs/common';
import { PrismaService } from '@Prisma/services';
import {
  EstadoDeposito,
  EstadoReserva,
  type Deposito,
  type Prisma,
} from '@PrismaClient';
import type { ActorResolucion } from '@Depositos/types';
import { calcularResolucion, type AccionResolucion } from '@Depositos/utils';

export interface ResolverDepositoData {
  depositoId: string;
  actor: ActorResolucion;
  accion: AccionResolucion;
  /** Solo se usa al RETENER. */
  importeRetenido: Prisma.Decimal;
  justificacion?: string;
  ahora: Date;
}

export type RechazoResolucion =
  | 'NO_EXISTE'
  | 'NO_ES_PROPIETARIO'
  | 'YA_RESUELTO'
  | 'LIBERADO_AUTOMATICAMENTE'
  | 'SIN_DEVOLUCION'
  | 'RETENCION_EXCEDE_SALDO';

export type ResultadoResolucion =
  { deposito: Deposito } | { rechazo: RechazoResolucion };

/** Depósito de una reserva junto con el dueño del bien, para autorizar. */
export interface DepositoDeReserva {
  deposito: Deposito | null;
  arrendadorId: string;
  arrendatarioId: string;
}

/**
 * Único punto de acceso a la tabla Depositos para resolverlos (H11).
 */
@Injectable()
export class DepositoRepository {
  constructor(private readonly prisma: PrismaService) {}

  /** `null` si la reserva no existe. */
  async buscarPorReserva(reservaId: string): Promise<DepositoDeReserva | null> {
    const reserva = await this.prisma.reserva.findUnique({
      where: { id: reservaId },
      select: {
        deposito: true,
        arrendatarioId: true,
        bien: { select: { arrendadorId: true } },
      },
    });
    return reserva
      ? {
          deposito: reserva.deposito,
          arrendadorId: reserva.bien.arrendadorId,
          arrendatarioId: reserva.arrendatarioId,
        }
      : null;
  }

  /**
   * Resuelve el depósito dentro de una transacción con la fila bloqueada
   * (`FOR UPDATE`): dos resoluciones simultáneas, o una del arrendador y otra
   * de la tarea diaria, se serializan y la segunda ve el depósito ya resuelto.
   *
   * Las comprobaciones van dentro de la transacción y no antes: el estado que
   * se valida es el mismo que se cambia.
   *
   * La devolución solo se exige al arrendador. El cierre automático (BE-10.2)
   * finaliza reservas que nunca tuvieron devolución y libera su depósito con el
   * actor SISTEMA.
   */
  resolver({
    depositoId,
    actor,
    accion,
    importeRetenido,
    justificacion,
    ahora,
  }: ResolverDepositoData): Promise<ResultadoResolucion> {
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT 1 FROM "Depositos" WHERE id = ${depositoId}::uuid FOR UPDATE`;

      const deposito = await tx.deposito.findUnique({
        where: { id: depositoId },
        include: {
          reserva: {
            select: {
              estado: true,
              devolucion: { select: { id: true } },
              bien: { select: { arrendadorId: true } },
            },
          },
        },
      });

      if (!deposito) return { rechazo: 'NO_EXISTE' };
      const { reserva } = deposito;
      if (
        actor.tipo === 'ARRENDADOR' &&
        reserva.bien.arrendadorId !== actor.usuarioId
      ) {
        return { rechazo: 'NO_ES_PROPIETARIO' };
      }
      if (deposito.estado !== EstadoDeposito.PENDIENTE) {
        return {
          rechazo: deposito.resolucionAutomatica
            ? 'LIBERADO_AUTOMATICAMENTE'
            : 'YA_RESUELTO',
        };
      }
      const finalizada = reserva.estado === EstadoReserva.FINALIZADA;
      if (!finalizada || (actor.tipo === 'ARRENDADOR' && !reserva.devolucion)) {
        return { rechazo: 'SIN_DEVOLUCION' };
      }

      const calculo = calcularResolucion(deposito, accion, importeRetenido);
      if ('rechazo' in calculo) return calculo;

      const resuelto = await tx.deposito.update({
        where: { id: depositoId },
        data: {
          estado: calculo.estado,
          importeRetenido: calculo.importeRetenido,
          importeLiberado: calculo.importeLiberado,
          justificacion: justificacion ?? null,
          fechaResolucion: ahora,
          resolucionAutomatica: actor.tipo === 'SISTEMA',
          resueltoPorId: actor.tipo === 'ARRENDADOR' ? actor.usuarioId : null,
        },
      });
      return { deposito: resuelto };
    });
  }

  async obtenerDatosNotificacion(depositoId: string) {
    return this.prisma.deposito.findUnique({
      where: { id: depositoId },
      select: {
        id: true,
        estado: true,
        importeOriginal: true,
        importeLiberado: true,
        importeRetenido: true,
        resolucionAutomatica: true,
        reserva: {
          select: {
            arrendatarioId: true,
            bien: {
              select: {
                titulo: true,
              },
            },
          },
        },
      },
    });
  }
}
