export * from './deposito.repository.js';
