export * from './deposito.service.js';
