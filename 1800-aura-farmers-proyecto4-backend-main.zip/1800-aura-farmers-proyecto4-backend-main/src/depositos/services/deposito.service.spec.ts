import {
  BadRequestException,
  ConflictException,
  ForbiddenException,
  NotFoundException,
  UnprocessableEntityException,
} from '@nestjs/common';
import { Prisma, type Deposito } from '@PrismaClient';
import type {
  DepositoDeReserva,
  DepositoRepository,
  RechazoResolucion,
} from '@Depositos/repositories';
import type { ActorResolucion } from '@Depositos/types';
import { DepositoService } from './deposito.service.js';
import type { NotificacionesService } from '@Notificaciones/services';

const RESERVA_ID = '11111111-1111-4111-8111-111111111111';
const DEPOSITO_ID = '33333333-3333-4333-8333-333333333333';
const ARRENDADOR_ID = '22222222-2222-4222-8222-222222222222';
const ARRENDATARIO_ID = '44444444-4444-4444-8444-444444444444';
const AHORA = new Date('2026-12-12T18:00:00.000Z');
const ARRENDADOR: ActorResolucion = {
  tipo: 'ARRENDADOR',
  usuarioId: ARRENDADOR_ID,
};
const SISTEMA: ActorResolucion = { tipo: 'SISTEMA' };

const deposito = { id: DEPOSITO_ID, estado: 'PENDIENTE' } as Deposito;

function crearServicio({
  resultado = { deposito },
  encontrado = {
    deposito,
    arrendadorId: ARRENDADOR_ID,
    arrendatarioId: ARRENDATARIO_ID,
  },
}: {
  resultado?: { deposito: Deposito } | { rechazo: RechazoResolucion };
  encontrado?: DepositoDeReserva | null;
} = {}) {
  const resolver = vi.fn().mockResolvedValue(resultado);
  const buscarPorReserva = vi.fn().mockResolvedValue(encontrado);
  const obtenerDatosNotificacion = vi.fn().mockResolvedValue(null);

  const notificaciones = {
    crear: vi.fn().mockResolvedValue({
      creada: true,
      notificacionId: 'aviso-prueba',
    }),
  };

  const service = new DepositoService(
    {
      resolver,
      buscarPorReserva,
      obtenerDatosNotificacion,
    } as unknown as DepositoRepository,
    notificaciones as unknown as NotificacionesService,
  );

  return {
    service,
    resolver,
    buscarPorReserva,
    obtenerDatosNotificacion,
    notificaciones,
  };
}

describe('DepositoService.resolver', () => {
  it('LIBERAR pasa el actor y no manda importe ni justificación', async () => {
    const { service, resolver } = crearServicio();

    const resultado = await service.resolver(
      DEPOSITO_ID,
      ARRENDADOR,
      'LIBERAR',
      undefined,
      undefined,
      AHORA,
    );

    expect(resultado).toBe(deposito);
    expect(resolver).toHaveBeenCalledWith({
      depositoId: DEPOSITO_ID,
      actor: ARRENDADOR,
      accion: 'LIBERAR',
      importeRetenido: new Prisma.Decimal(0),
      justificacion: undefined,
      ahora: AHORA,
    });
  });

  it('LIBERAR acepta importe 0', async () => {
    const { service } = crearServicio();
    await expect(
      service.resolver(DEPOSITO_ID, ARRENDADOR, 'LIBERAR', 0),
    ).resolves.toBe(deposito);
  });

  it('RETENER manda el importe como decimal exacto y la justificación recortada', async () => {
    const { service, resolver } = crearServicio();

    await service.resolver(
      DEPOSITO_ID,
      ARRENDADOR,
      'RETENER',
      25.1,
      '  Puerta dañada.  ',
      AHORA,
    );

    const llamada = resolver.mock.calls[0][0];
    expect(llamada.importeRetenido.toString()).toBe('25.1');
    expect(llamada.justificacion).toBe('Puerta dañada.');
  });

  it('el actor SISTEMA libera sin justificación', async () => {
    const { service, resolver } = crearServicio();
    await service.resolver(DEPOSITO_ID, SISTEMA, 'LIBERAR');
    expect(resolver).toHaveBeenCalledWith(
      expect.objectContaining({ actor: SISTEMA, accion: 'LIBERAR' }),
    );
  });

  it('el actor SISTEMA no puede retener', async () => {
    const { service, resolver } = crearServicio();
    await expect(
      service.resolver(DEPOSITO_ID, SISTEMA, 'RETENER', 10, 'x'),
    ).rejects.toThrow('SISTEMA');
    expect(resolver).not.toHaveBeenCalled();
  });

  describe('validación de entrada (no toca la base)', () => {
    it.each([
      ['sin importe', undefined, 'Hola'],
      ['importe 0', 0, 'Hola'],
      ['importe negativo', -5, 'Hola'],
      ['sin justificación', 10, undefined],
      ['justificación en blanco', 10, '   '],
      ['más de 2 decimales', 10.123, 'Hola'],
      ['importe infinito', Infinity, 'Hola'],
      ['justificación de 501 caracteres', 10, 'a'.repeat(501)],
    ])('RETENER %s da 400', async (_caso, importe, justificacion) => {
      const { service, resolver } = crearServicio();

      await expect(
        service.resolver(
          DEPOSITO_ID,
          ARRENDADOR,
          'RETENER',
          importe,
          justificacion,
        ),
      ).rejects.toThrow(BadRequestException);
      expect(resolver).not.toHaveBeenCalled();
    });

    it('LIBERAR con un importe a retener da 400', async () => {
      const { service, resolver } = crearServicio();
      await expect(
        service.resolver(DEPOSITO_ID, ARRENDADOR, 'LIBERAR', 10),
      ).rejects.toThrow(BadRequestException);
      expect(resolver).not.toHaveBeenCalled();
    });
  });

  describe('rechazos del repositorio', () => {
    it.each([
      ['NO_EXISTE', NotFoundException, 'El depósito no existe.'],
      [
        'NO_ES_PROPIETARIO',
        ForbiddenException,
        'No tienes permiso para resolver este depósito.',
      ],
      ['YA_RESUELTO', ConflictException, 'El depósito ya fue resuelto.'],
      [
        'LIBERADO_AUTOMATICAMENTE',
        ConflictException,
        'El plazo para resolver el depósito venció y fue liberado',
      ],
      [
        'SIN_DEVOLUCION',
        UnprocessableEntityException,
        'Debe registrarse la devolución antes de resolver el depósito',
      ],
      [
        'RETENCION_EXCEDE_SALDO',
        UnprocessableEntityException,
        'El importe a retener supera el saldo disponible del depósito.',
      ],
    ] as const)('%s', async (rechazo, excepcion, mensaje) => {
      const { service } = crearServicio({ resultado: { rechazo } });

      const error = await service
        .resolver(DEPOSITO_ID, ARRENDADOR, 'RETENER', 10, 'x')
        .catch((e: unknown) => e);

      expect(error).toBeInstanceOf(excepcion);
      expect((error as Error).message).toBe(mensaje);
    });
  });
});

describe('DepositoService.consultarPorReserva', () => {
  it.each([
    ['el arrendador propietario', ARRENDADOR_ID],
    ['el arrendatario de la reserva', ARRENDATARIO_ID],
  ])('devuelve el depósito a %s', async (_quien, usuarioId) => {
    const { service, buscarPorReserva } = crearServicio();
    await expect(
      service.consultarPorReserva(RESERVA_ID, usuarioId),
    ).resolves.toBe(deposito);
    expect(buscarPorReserva).toHaveBeenCalledWith(RESERVA_ID);
  });

  it('404 si la reserva no existe', async () => {
    const { service } = crearServicio({ encontrado: null });
    await expect(
      service.consultarPorReserva(RESERVA_ID, ARRENDADOR_ID),
    ).rejects.toThrow(NotFoundException);
  });

  it('403 a quien no participa, sin revelar si hay depósito', async () => {
    const { service } = crearServicio({
      encontrado: {
        deposito: null,
        arrendadorId: ARRENDADOR_ID,
        arrendatarioId: ARRENDATARIO_ID,
      },
    });
    await expect(
      service.consultarPorReserva(RESERVA_ID, 'otro'),
    ).rejects.toThrow(ForbiddenException);
  });

  it('403 al devolver el depósito a un usuario ajeno', async () => {
    const { service } = crearServicio();
    await expect(
      service.consultarPorReserva(RESERVA_ID, 'otro'),
    ).rejects.toThrow('No tienes permiso para consultar este depósito.');
  });

  it('404 si la reserva no tiene depósito', async () => {
    const { service } = crearServicio({
      encontrado: {
        deposito: null,
        arrendadorId: ARRENDADOR_ID,
        arrendatarioId: ARRENDATARIO_ID,
      },
    });
    await expect(
      service.consultarPorReserva(RESERVA_ID, ARRENDATARIO_ID),
    ).rejects.toThrow('La reserva no tiene depósito.');
  });
});

describe('DepositoService.resolverPorReserva', () => {
  it('ubica el depósito y lo resuelve con el arrendador del token', async () => {
    const { service, resolver } = crearServicio();

    await service.resolverPorReserva(RESERVA_ID, ARRENDADOR_ID, {
      accion: 'RETENER',
      importeRetenido: 10,
      justificacion: 'Rotura',
    });

    expect(resolver).toHaveBeenCalledWith(
      expect.objectContaining({
        depositoId: DEPOSITO_ID,
        actor: ARRENDADOR,
        accion: 'RETENER',
      }),
    );
  });

  it('no deja resolver al arrendatario de la reserva', async () => {
    const { service, resolver } = crearServicio();
    await expect(
      service.resolverPorReserva(RESERVA_ID, ARRENDATARIO_ID, {
        accion: 'LIBERAR',
      }),
    ).rejects.toThrow(ForbiddenException);
    expect(resolver).not.toHaveBeenCalled();
  });

  it('no resuelve si la reserva es de otro arrendador', async () => {
    const { service, resolver } = crearServicio({
      encontrado: {
        deposito,
        arrendadorId: 'otro',
        arrendatarioId: ARRENDATARIO_ID,
      },
    });
    await expect(
      service.resolverPorReserva(RESERVA_ID, ARRENDADOR_ID, {
        accion: 'LIBERAR',
      }),
    ).rejects.toThrow(ForbiddenException);
    expect(resolver).not.toHaveBeenCalled();
  });
});
