import { describe, expect, it, vi } from 'vitest';
import { EstadoDeposito, ModuloOrigen, Prisma } from '@PrismaClient';
import type { DepositoRepository } from '@Depositos/repositories';
import type { NotificacionesService } from '@Notificaciones/services';
import { DepositoService } from './deposito.service.js';

const DEPOSITO_ID = '11111111-1111-4111-8111-111111111111';
const ARRENDATARIO_ID = '22222222-2222-4222-8222-222222222222';
const ARRENDADOR_ID = '33333333-3333-4333-8333-333333333333';

function escenario(
  estado: EstadoDeposito = EstadoDeposito.LIBERADO,
  automatico = false,
) {
  const decimal = (valor: string) => new Prisma.Decimal(valor);

  const deposito = {
    id: DEPOSITO_ID,
    estado,
    importeOriginal: decimal('100'),
    importeRetenido: decimal(
      estado === EstadoDeposito.RETENIDO
        ? '100'
        : estado === EstadoDeposito.PARCIALMENTE_RETENIDO
          ? '25'
          : '0',
    ),
    importeLiberado: decimal(
      estado === EstadoDeposito.RETENIDO
        ? '0'
        : estado === EstadoDeposito.PARCIALMENTE_RETENIDO
          ? '75'
          : '100',
    ),
    resolucionAutomatica: automatico,
  };

  const repository = {
    resolver: vi.fn().mockResolvedValue({
      deposito,
    }),
    obtenerDatosNotificacion: vi.fn().mockResolvedValue({
      ...deposito,
      reserva: {
        arrendatarioId: ARRENDATARIO_ID,
        bien: { titulo: 'Cámara Sony' },
      },
    }),
  };

  const notificaciones = {
    crear: vi.fn().mockResolvedValue({
      creada: true,
      notificacionId: 'aviso-prueba',
    }),
  };

  const service = new DepositoService(
    repository as unknown as DepositoRepository,
    notificaciones as unknown as NotificacionesService,
  );

  return { service, repository, notificaciones };
}

describe('BE-22.2 - Notificaciones de depósitos', () => {
  it.each([
    [EstadoDeposito.LIBERADO, 'fue liberado'],
    [EstadoDeposito.PARCIALMENTE_RETENIDO, 'retenido en parte'],
    [EstadoDeposito.RETENIDO, 'retenido por completo'],
  ])('notifica la resolución %s al arrendatario', async (estado, texto) => {
    const { service, notificaciones } = escenario(estado);

    await service.resolver(
      DEPOSITO_ID,
      { tipo: 'ARRENDADOR', usuarioId: ARRENDADOR_ID },
      estado === EstadoDeposito.LIBERADO ? 'LIBERAR' : 'RETENER',
      estado === EstadoDeposito.LIBERADO
        ? undefined
        : estado === EstadoDeposito.RETENIDO
          ? 100
          : 25,
      estado === EstadoDeposito.LIBERADO ? undefined : 'Daños',
    );

    expect(notificaciones.crear).toHaveBeenCalledOnce();

    const [destinatario, titulo, mensaje, modulo, referencia] =
      notificaciones.crear.mock.calls[0];

    expect(destinatario).toBe(ARRENDATARIO_ID);
    expect(titulo).toBe('Depósito resuelto');
    expect(mensaje).toContain(texto);
    expect(modulo).toBe(ModuloOrigen.PAGOS);
    expect(referencia).toEqual({
      tipoReferencia: 'DEPOSITO_RESUELTO',
      referenciaId: DEPOSITO_ID,
    });
  });

  it('notifica la liberación automática', async () => {
    const { service, notificaciones } = escenario(
      EstadoDeposito.LIBERADO,
      true,
    );

    await service.resolver(DEPOSITO_ID, { tipo: 'SISTEMA' }, 'LIBERAR');

    expect(notificaciones.crear.mock.calls[0]?.[2]).toContain(
      'liberado automáticamente por vencimiento del plazo',
    );
  });

  it('un fallo de notificaciones no revierte la resolución', async () => {
    const { service, notificaciones } = escenario();

    notificaciones.crear.mockRejectedValue(new Error('Fallo simulado'));

    const resultado = await service.resolver(
      DEPOSITO_ID,
      { tipo: 'SISTEMA' },
      'LIBERAR',
    );

    expect(resultado.estado).toBe(EstadoDeposito.LIBERADO);
  });

  it('utiliza la misma referencia para el mismo depósito', async () => {
    const { service, notificaciones } = escenario();

    await service.resolver(DEPOSITO_ID, { tipo: 'SISTEMA' }, 'LIBERAR');

    await service.resolver(DEPOSITO_ID, { tipo: 'SISTEMA' }, 'LIBERAR');

    expect(notificaciones.crear.mock.calls[0]?.[4]).toEqual(
      notificaciones.crear.mock.calls[1]?.[4],
    );
  });
});
