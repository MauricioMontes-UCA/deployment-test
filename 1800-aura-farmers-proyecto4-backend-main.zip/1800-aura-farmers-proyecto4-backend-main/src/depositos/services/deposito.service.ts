import {
  BadRequestException,
  ConflictException,
  ForbiddenException,
  Injectable,
  NotFoundException,
  UnprocessableEntityException,
  Logger,
} from '@nestjs/common';
import { Prisma, type Deposito, ModuloOrigen } from '@PrismaClient';
import type { ResolverDepositoDto } from '@Depositos/dto';
import {
  DepositoRepository,
  type DepositoDeReserva,
  type RechazoResolucion,
} from '@Depositos/repositories';
import type { ActorResolucion } from '@Depositos/types';
import type { AccionResolucion } from '@Depositos/utils';
import { NotificacionesService } from '@Notificaciones/services';
import {
  mensajeDepositoResuelto,
  REFERENCIA_DEPOSITO_RESUELTO,
  TITULO_DEPOSITO_RESUELTO,
} from '@Depositos/utils';

const RECHAZOS: Record<RechazoResolucion, new (mensaje: string) => Error> = {
  NO_EXISTE: NotFoundException,
  NO_ES_PROPIETARIO: ForbiddenException,
  YA_RESUELTO: ConflictException,
  LIBERADO_AUTOMATICAMENTE: ConflictException,
  SIN_DEVOLUCION: UnprocessableEntityException,
  RETENCION_EXCEDE_SALDO: UnprocessableEntityException,
};

const MENSAJES: Record<RechazoResolucion, string> = {
  NO_EXISTE: 'El depósito no existe.',
  NO_ES_PROPIETARIO: 'No tienes permiso para resolver este depósito.',
  YA_RESUELTO: 'El depósito ya fue resuelto.',
  LIBERADO_AUTOMATICAMENTE:
    'El plazo para resolver el depósito venció y fue liberado',
  SIN_DEVOLUCION:
    'Debe registrarse la devolución antes de resolver el depósito',
  RETENCION_EXCEDE_SALDO:
    'El importe a retener supera el saldo disponible del depósito.',
};

const MAX_JUSTIFICACION = 500;

/**
 * Resolución del depósito de garantía (H11).
 *
 * No conoce Prisma: el acceso a datos pasa por `DepositoRepository`.
 */
@Injectable()
export class DepositoService {
  private readonly logger = new Logger(DepositoService.name);

  constructor(
    private readonly depositoRepository: DepositoRepository,
    private readonly notificacionesService: NotificacionesService,
  ) {}
  /**
   * Depósito de una reserva, para quien participa en ella: el arrendatario de
   * la reserva o el arrendador dueño del bien (H12). Solo lee.
   *
   * @param usuarioId viene del usuario autenticado, nunca del cliente.
   * @throws {NotFoundException} la reserva no existe o no tiene depósito.
   * @throws {ForbiddenException} el usuario no participa en la reserva. No se
   * revela ningún dato del depósito.
   */
  async consultarPorReserva(
    reservaId: string,
    usuarioId: string,
  ): Promise<Deposito> {
    return this.ubicar(reservaId, (e) =>
      e.arrendatarioId === usuarioId || e.arrendadorId === usuarioId
        ? null
        : 'No tienes permiso para consultar este depósito.',
    );
  }

  /** Ubica el depósito de la reserva si `denegar` no devuelve un motivo. */
  private async ubicar(
    reservaId: string,
    denegar: (encontrado: DepositoDeReserva) => string | null,
  ): Promise<Deposito> {
    const encontrado =
      await this.depositoRepository.buscarPorReserva(reservaId);
    if (!encontrado) throw new NotFoundException('La reserva no existe.');
    const motivo = denegar(encontrado);
    if (motivo) throw new ForbiddenException(motivo);
    if (!encontrado.deposito) {
      throw new NotFoundException('La reserva no tiene depósito.');
    }
    return encontrado.deposito;
  }

  /** Endpoint del arrendador: ubica el depósito por reserva y lo resuelve. */
  async resolverPorReserva(
    reservaId: string,
    arrendadorId: string,
    dto: ResolverDepositoDto,
  ): Promise<Deposito> {
    // Se valida el cuerpo antes de tocar la base, pero después de saber que la
    // reserva es del arrendador: no se revela nada de reservas ajenas.
    const deposito = await this.ubicar(reservaId, (e) =>
      e.arrendadorId === arrendadorId ? null : MENSAJES.NO_ES_PROPIETARIO,
    );
    return this.resolver(
      deposito.id,
      { tipo: 'ARRENDADOR', usuarioId: arrendadorId },
      dto.accion,
      dto.importeRetenido,
      dto.justificacion,
    );
  }

  /**
   * Libera o retiene el depósito. Lo usan el endpoint del arrendador y la tarea
   * diaria BE-10.2, que solo puede LIBERAR con el actor SISTEMA.
   *
   * @throws {BadRequestException} RETENER sin importe positivo o sin
   * justificación, o LIBERAR con importe a retener.
   * @throws {NotFoundException} el depósito no existe.
   * @throws {ForbiddenException} el actor ARRENDADOR no es dueño del bien.
   * @throws {ConflictException} ya fue resuelto, o se liberó automáticamente.
   * @throws {UnprocessableEntityException} la renta no está FINALIZADA con
   * devolución, o la retención supera el saldo.
   *
   * `ahora` se recibe para poder probar la fecha de resolución.
   */
  async resolver(
    depositoId: string,
    actor: ActorResolucion,
    accion: AccionResolucion,
    importeRetenido?: number,
    justificacion?: string,
    ahora: Date = new Date(),
  ): Promise<Deposito> {
    if (actor.tipo === 'SISTEMA' && accion !== 'LIBERAR') {
      // Error de programación, no del usuario: el sistema nunca retiene.
      throw new Error('El actor SISTEMA solo puede liberar un depósito.');
    }
    const texto = justificacion?.trim() || undefined;
    this.validarEntrada(accion, importeRetenido, texto);

    const resultado = await this.depositoRepository.resolver({
      depositoId,
      actor,
      accion,
      importeRetenido: new Prisma.Decimal((importeRetenido ?? 0).toFixed(2)),
      justificacion: texto,
      ahora,
    });

    if ('rechazo' in resultado) {
      throw new RECHAZOS[resultado.rechazo](MENSAJES[resultado.rechazo]);
    }

    try {
      await this.notificarDepositoResuelto(resultado.deposito.id);
    } catch (error) {
      this.logger.error(
        `Error al notificar el depósito ${resultado.deposito.id}.`,
        error instanceof Error ? error.stack : String(error),
      );
    }

    return resultado.deposito;
  }

  private async notificarDepositoResuelto(depositoId: string): Promise<void> {
    const deposito =
      await this.depositoRepository.obtenerDatosNotificacion(depositoId);

    if (!deposito || deposito.estado === 'PENDIENTE') {
      return;
    }

    const mensaje = mensajeDepositoResuelto({
      importeOriginal: deposito.importeOriginal,
      importeLiberado: deposito.importeLiberado,
      importeRetenido: deposito.importeRetenido,
      estado: deposito.estado,
      resolucionAutomatica: deposito.resolucionAutomatica,
      nombreBien: deposito.reserva.bien.titulo,
    });

    await this.notificacionesService.crear(
      deposito.reserva.arrendatarioId,
      TITULO_DEPOSITO_RESUELTO,
      mensaje,
      ModuloOrigen.PAGOS,
      {
        tipoReferencia: REFERENCIA_DEPOSITO_RESUELTO,
        referenciaId: deposito.id,
      },
    );
  }

  private validarEntrada(
    accion: AccionResolucion,
    importeRetenido: number | undefined,
    justificacion: string | undefined,
  ): void {
    if (justificacion && justificacion.length > MAX_JUSTIFICACION) {
      throw new BadRequestException(
        'La justificación no puede superar los 500 caracteres.',
      );
    }
    if (
      importeRetenido !== undefined &&
      (!Number.isFinite(importeRetenido) ||
        Number(importeRetenido.toFixed(2)) !== importeRetenido)
    ) {
      throw new BadRequestException(
        'El importe a retener debe ser un número con hasta 2 decimales.',
      );
    }

    if (accion === 'RETENER') {
      if (importeRetenido === undefined || importeRetenido <= 0) {
        throw new BadRequestException(
          'Al retener hay que indicar un importe mayor que cero.',
        );
      }
      if (!justificacion) {
        throw new BadRequestException(
          'La justificación es obligatoria al retener.',
        );
      }
    } else if (importeRetenido) {
      throw new BadRequestException(
        'Al liberar no se indica un importe a retener.',
      );
    }
  }
}
