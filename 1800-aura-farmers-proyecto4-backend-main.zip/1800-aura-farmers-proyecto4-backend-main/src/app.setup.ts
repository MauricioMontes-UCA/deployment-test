import path from 'node:path';
import { ValidationPipe } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import type { NestExpressApplication } from '@nestjs/platform-express';
import { UPLOADS_URL_PREFIX, type EnvConfig } from '@Config';

export const API_PREFIX = 'api/v1';

/**
 * Configuración HTTP de la aplicación: CORS, prefijo, validación y archivos
 * estáticos.
 *
 * `main.ts` y las pruebas e2e la usan, así que las pruebas ejercitan la misma
 * aplicación que corre en producción. Swagger y los shutdown hooks quedan en
 * `main.ts`: no cambian el comportamiento de la API.
 */
export function configurarApp(app: NestExpressApplication): void {
  const configService = app.get(ConfigService<EnvConfig, true>);

  // CORS (H28): el frontend desplegado vive en otro origen, y sin estos
  // encabezados el navegador bloquea sus peticiones. Solo se aceptan los
  // orígenes de CORS_ORIGINS. Sin credentials: el token viaja en el encabezado
  // Authorization, no en cookies.
  app.enableCors({
    origin: configService.get('CORS_ORIGINS', { infer: true }),
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization'],
  });

  // Versionado en la URI: /api/v1/...
  app.setGlobalPrefix(API_PREFIX);

  app.useGlobalPipes(
    new ValidationPipe({
      // Descarta propiedades que no estén en el DTO...
      whitelist: true,
      // ...y además rechaza la request con 400 si vienen de más, en vez de
      // ignorarlas en silencio.
      forbidNonWhitelisted: true,
      // Convierte el payload al tipo del DTO (los query/params llegan string).
      transform: true,
    }),
  );

  // Fotos de los bienes. Son archivos estáticos y públicos, como cualquier
  // imagen de un catálogo, así que no pasan por el prefijo ni por los guards.
  app.useStaticAssets(
    path.resolve(configService.get('UPLOADS_DIR', { infer: true })),
    {
      prefix: UPLOADS_URL_PREFIX,
      index: false,
      // El formato ya se validó por contenido al subirlas: nosniff evita que el
      // navegador intente interpretarlas como otra cosa.
      setHeaders: (res) => res.setHeader('X-Content-Type-Options', 'nosniff'),
    },
  );
}
