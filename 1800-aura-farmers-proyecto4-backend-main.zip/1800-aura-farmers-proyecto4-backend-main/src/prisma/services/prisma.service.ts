import {
  Injectable,
  Logger,
  OnModuleDestroy,
  OnModuleInit,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { PrismaPg } from '@prisma/adapter-pg';
import { PrismaClient } from '@PrismaClient';
import type { EnvConfig } from '@Config';

/** Parámetro de arranque de cada sesión: su zona horaria es UTC. */
export const OPCION_ZONA_UTC = '-c TimeZone=UTC';

/** Si unas `options` de libpq ya fijan la zona horaria de la sesión. */
const FIJA_ZONA = /(^|\s)(-c\s*|--)timezone\s*=/i;

/**
 * Nombres con los que PostgreSQL reporta UTC o un equivalente sin horario de
 * verano: los mismos que acepta la revisión simulada (`ZONAS_UTC`). No incluye
 * zonas que solo coinciden con UTC parte del año, como Europe/London.
 */
const ZONA_UTC =
  /^(etc\/)?(utc|uct|universal|zulu|greenwich|gmt|gmt0|gmt[+-]0)$/i;

/** Si la zona que reporta PostgreSQL es UTC o un equivalente. */
export function esSesionUtc(zona: string): boolean {
  return ZONA_UTC.test(zona.trim());
}

/**
 * Configuración de `pg` para que cada sesión arranque en UTC.
 *
 * `@prisma/adapter-pg` da por hecho que la sesión está en UTC: escribe los
 * `Date` como hora UTC sin desplazamiento (PostgreSQL los interpreta en la
 * zona de la sesión) y, al leer un `timestamptz`, reemplaza el desplazamiento
 * por `+00:00`. Con la sesión en otra zona, los instantes guardados por Prisma
 * quedan corridos respecto del reloj de PostgreSQL (`CURRENT_TIMESTAMP`, los
 * `DEFAULT`), aunque las columnas sean `timestamptz`.
 *
 * En `pg`, las `options` de la connection string tienen prioridad sobre las de
 * la configuración. Por eso:
 * - sin `options` en la URL, la URL queda intacta y se agrega la opción;
 * - con `options` en la URL, se le añade `-c TimeZone=UTC` sin quitar nada;
 * - si la URL ya fija la zona, se respeta: es una decisión explícita y la
 *   revisión simulada lo detecta (`ZonaHorariaNoUtcError`).
 */
export function conexionEnUtc(connectionString: string): {
  connectionString: string;
  options?: string;
} {
  let url: URL;
  try {
    url = new URL(connectionString);
  } catch {
    // No es una URL: se deja como está y la opción va en la configuración.
    return { connectionString, options: OPCION_ZONA_UTC };
  }

  const opciones = url.searchParams.get('options');
  if (opciones === null) return { connectionString, options: OPCION_ZONA_UTC };
  if (FIJA_ZONA.test(opciones)) return { connectionString };

  url.searchParams.set('options', `${opciones} ${OPCION_ZONA_UTC}`.trim());
  return { connectionString: url.toString() };
}

/**
 * Cliente de Prisma atado al ciclo de vida de Nest.
 *
 * Desde Prisma 7 la conexión ya no se resuelve desde schema.prisma: hay que
 * pasarle un driver adapter con la connection string en tiempo de ejecución.
 *
 * Solo los repositorios deberían inyectar este servicio. Los servicios de
 * negocio hablan con los repositorios, no con Prisma.
 *
 * Cada sesión arranca en UTC (`conexionEnUtc`), sin depender de la zona que
 * tenga configurada el servidor de PostgreSQL. Al arrancar se comprueba la
 * zona real de una sesión y se advierte si no es UTC (`advertirSiNoEsUtc`).
 */
@Injectable()
export class PrismaService
  extends PrismaClient
  implements OnModuleInit, OnModuleDestroy
{
  private readonly logger = new Logger(PrismaService.name);

  constructor(configService: ConfigService<EnvConfig, true>) {
    const adapter = new PrismaPg(
      conexionEnUtc(configService.get('DATABASE_URL', { infer: true })),
    );

    super({
      adapter,
      log:
        configService.get('NODE_ENV', { infer: true }) === 'development'
          ? ['warn', 'error']
          : ['error'],
    });
  }

  async onModuleInit(): Promise<void> {
    await this.$connect();
    this.logger.log('Conectado a PostgreSQL');
    await this.advertirSiNoEsUtc();
  }

  /**
   * Comprueba una sola vez, al arrancar, la zona horaria real de una sesión
   * del pool y advierte si no es UTC: por ejemplo, si `DATABASE_URL` fija otra
   * zona en `options`, o si un pooler (como PgBouncer) no reenvía esa opción.
   * Solo registra el aviso: no detiene la aplicación ni cambia la zona.
   *
   * Es una comprobación de diagnóstico, no una garantía: mira una sesión en el
   * momento del arranque, y otras sesiones del pool (o las que reparta un
   * pooler más adelante) podrían tener otra zona. La revisión simulada vuelve
   * a comprobarla en cada lote (`exigirUtc`). Nunca registra la URL ni las
   * credenciales.
   */
  private async advertirSiNoEsUtc(): Promise<void> {
    let zona: string;
    try {
      const [fila] = await this.$queryRaw<
        { zona: string }[]
      >`SELECT current_setting('TimeZone') AS zona`;
      zona = fila?.zona ?? '(desconocida)';
    } catch (error) {
      // Solo el tipo de error: su mensaje podría incluir datos de la conexión.
      this.logger.warn(
        `No se pudo comprobar la zona horaria de la sesión de PostgreSQL (${error instanceof Error ? error.name : 'error desconocido'}).`,
      );
      return;
    }
    if (!esSesionUtc(zona)) {
      this.logger.warn(
        `La sesión de PostgreSQL usa la zona horaria "${zona}" en lugar de UTC. ` +
          'El adaptador de Prisma da por hecho UTC: las fechas que guarde la aplicación ' +
          'quedarán corridas respecto del reloj de PostgreSQL. Revisa las opciones de ' +
          'DATABASE_URL (TimeZone) o el pooler de conexiones.',
      );
    }
  }

  async onModuleDestroy(): Promise<void> {
    await this.$disconnect();
  }
}
