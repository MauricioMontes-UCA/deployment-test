import { randomUUID } from 'node:crypto';
import { PrismaPg } from '@prisma/adapter-pg';
import { Logger } from '@nestjs/common';
import type { ConfigService } from '@nestjs/config';
import { PrismaClient, Rol } from '@PrismaClient';
import type { EnvConfig } from '@Config';
import { ZonaHorariaNoUtcError } from '@Verificaciones/errors';
import { RevisionVerificacionRepository } from '@Verificaciones/repositories';
import { conexionEnUtc, PrismaService } from './prisma.service.js';

const habilitada = process.env.RUN_DB_INTEGRATION === '1';

if (habilitada && !process.env.DATABASE_URL) {
  throw new Error('RUN_DB_INTEGRATION=1 requiere DATABASE_URL configurada.');
}

/**
 * Sesión en UTC contra PostgreSQL cuando el servidor tiene otra zona por
 * defecto. Usar solo con una base desechable.
 *
 * Para no afectar a las demás pruebas de integración, que corren en paralelo
 * contra la misma base, la zona America/El_Salvador no se fija en la base sino
 * en un rol propio y temporal (`ALTER ROLE … SET timezone`): solo las sesiones
 * de ese rol arrancan en esa zona. El rol se elimina al terminar.
 *
 * Comprueba que `PrismaService` abre cada sesión en UTC aun así, que los
 * instantes que guarda Prisma son los correctos, y que una conexión sin esa
 * opción sigue corrida (el motivo de la corrección) y la revisión simulada la
 * sigue rechazando.
 */
describe.skipIf(!habilitada)('PrismaService: sesión en UTC', () => {
  const SEIS_HORAS = 6 * 60 * 60;
  const rol = `utc_prueba_${randomUUID().replaceAll('-', '').slice(0, 10)}`;
  const clave = randomUUID();
  // Se calculan en beforeAll: sin RUN_DB_INTEGRATION no hay DATABASE_URL, y
  // el cuerpo del describe se evalúa igual aunque se salte.
  let url = '';
  /** La misma base, pero entrando con el rol temporal. */
  let urlDelRol = '';

  /** Para preparar y limpiar: siempre en UTC. */
  let admin: PrismaClient;
  /** Como la aplicación: `PrismaService` real, con el rol temporal. */
  let servicio: PrismaService;
  /** Una conexión del rol sin la opción: hereda su zona (El Salvador). */
  let crudo: PrismaClient;
  let usuarioId = '';
  let rolCreado = false;
  const usuarios: string[] = [];

  const config = {
    get: (nombre: string) => (nombre === 'DATABASE_URL' ? urlDelRol : 'test'),
  } as unknown as ConfigService<EnvConfig, true>;

  const zonaDe = async (cliente: PrismaClient) =>
    (
      await cliente.$queryRaw<
        { zona: string }[]
      >`SELECT current_setting('TimeZone') AS zona`
    )[0]!.zona;

  /** Segundos entre una columna de la solicitud y el reloj de PostgreSQL. */
  const desfase = async (id: string, columna: 'creada_en' | 'revisado_en') => {
    const [fila] = await admin.$queryRawUnsafe<{ segundos: number }[]>(
      `SELECT extract(epoch FROM (${columna} - now()))::float8 AS segundos
       FROM "SolicitudesVerificacion" WHERE id = $1::uuid`,
      id,
    );
    return fila!.segundos;
  };

  const crearUsuario = async (cliente: PrismaClient) => {
    const sufijo = randomUUID().replaceAll('-', '').slice(0, 10);
    const { id } = await cliente.usuario.create({
      data: {
        nombreUsuario: `utc_${sufijo}`,
        email: `utc_${sufijo}@example.com`,
        passwordHash: 'hash-prueba',
        rol: Rol.ARRENDATARIO,
      },
      select: { id: true },
    });
    usuarios.push(id);
    return id;
  };

  /**
   * Ejecuta una sentencia de administración armada por PostgreSQL con
   * `format` (%I para nombres, %L para valores): la plantilla y los valores
   * van como parámetros, sin concatenar texto.
   */
  const administrar = async (plantilla: string, ...valores: string[]) => {
    const marcadores = valores.map((_, i) => `, $${i + 2}::text`).join('');
    const [{ sql }] = await admin.$queryRawUnsafe<{ sql: string }[]>(
      `SELECT format($1::text${marcadores}) AS sql`,
      plantilla,
      ...valores,
    );
    await admin.$executeRawUnsafe(sql);
  };

  beforeAll(async () => {
    url = process.env.DATABASE_URL!;
    const conRol = new URL(url);
    conRol.username = rol;
    conRol.password = clave;
    urlDelRol = conRol.toString();

    admin = new PrismaClient({ adapter: new PrismaPg(conexionEnUtc(url)) });
    await admin.$connect();

    await administrar('CREATE ROLE %I LOGIN PASSWORD %L', rol, clave);
    rolCreado = true;
    await administrar('GRANT USAGE ON SCHEMA public TO %I', rol);
    await administrar(
      'GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO %I',
      rol,
    );
    await administrar(
      'ALTER ROLE %I SET timezone TO %L',
      rol,
      'America/El_Salvador',
    );

    servicio = new PrismaService(config);
    await servicio.$connect();
    crudo = new PrismaClient({
      adapter: new PrismaPg({ connectionString: urlDelRol }),
    });
    await crudo.$connect();

    usuarioId = await crearUsuario(admin);
  });

  afterAll(async () => {
    try {
      if (usuarios.length > 0) {
        await admin.solicitudVerificacion.deleteMany({
          where: { usuarioId: { in: usuarios } },
        });
        await admin.usuario.deleteMany({ where: { id: { in: usuarios } } });
      }
    } finally {
      await crudo?.$disconnect();
      await servicio?.$disconnect();
      if (rolCreado) {
        // DROP OWNED quita los privilegios del rol en esta base; luego se borra.
        await administrar('DROP OWNED BY %I', rol);
        await administrar('DROP ROLE %I', rol);
      }
      await admin?.$disconnect();
    }
  });

  it('una conexión sin la opción hereda la zona del rol (America/El_Salvador)', async () => {
    expect(await zonaDe(crudo)).toBe('America/El_Salvador');
  });

  it('PrismaService abre cada sesión en UTC, también dentro de una transacción', async () => {
    expect(await zonaDe(servicio)).toBe('UTC');
    const dentro = await servicio.$transaction(
      (tx) =>
        tx.$queryRaw<
          { zona: string }[]
        >`SELECT current_setting('TimeZone') AS zona`,
    );
    expect(dentro[0]!.zona).toBe('UTC');
  });

  it('con PrismaService, creada_en y revisado_en guardan el instante correcto', async () => {
    const { id } = await servicio.solicitudVerificacion.create({
      data: { usuarioId },
      select: { id: true },
    });
    await servicio.solicitudVerificacion.update({
      where: { id },
      data: { revisadoEn: new Date() },
    });

    expect(Math.abs(await desfase(id, 'creada_en'))).toBeLessThan(5);
    expect(Math.abs(await desfase(id, 'revisado_en'))).toBeLessThan(5);

    // Y Prisma lo lee como el mismo instante.
    const leida = await servicio.solicitudVerificacion.findUniqueOrThrow({
      where: { id },
      select: { creadaEn: true },
    });
    expect(Math.abs(leida.creadaEn.getTime() - Date.now())).toBeLessThan(5000);
  });

  it('sin la opción, un Date que escribe Prisma queda corrido 6 horas respecto del reloj de PostgreSQL', async () => {
    // Usuario propio: solo se admite una solicitud EN_REVISION por usuario.
    const { id } = await crudo.solicitudVerificacion.create({
      data: { usuarioId: await crearUsuario(admin) },
      select: { id: true },
    });
    await crudo.solicitudVerificacion.update({
      where: { id },
      data: { revisadoEn: new Date() },
    });

    // El adaptador envía la hora UTC sin desplazamiento y la sesión la toma
    // como hora de El Salvador (UTC-6): queda 6 horas en el futuro.
    expect(
      Math.abs((await desfase(id, 'revisado_en')) - SEIS_HORAS),
    ).toBeLessThan(60);
  });

  it('una solicitud guardada con PrismaService se toma recién al pasar la espera mínima', async () => {
    const repositorio = new RevisionVerificacionRepository(servicio);
    const { id } = await servicio.solicitudVerificacion.create({
      data: { usuarioId: await crearUsuario(servicio) },
      select: { id: true },
    });
    const tomada = async () => {
      // Se excluyen las demás solicitudes pendientes para no tomar las de
      // otras pruebas que corren en paralelo contra la misma base.
      const ajenas = await admin.$queryRaw<{ id: string }[]>`
        SELECT id FROM "SolicitudesVerificacion"
        WHERE estado = 'EN_REVISION' AND id <> ${id}::uuid`;
      const lote = await repositorio.resolverLote({
        revisadoEn: new Date(),
        excluir: ajenas.map((fila) => fila.id),
        lote: 1,
      });
      // Sin documento: se toma, pero queda EN_REVISION y se informa aparte.
      return lote.sinDocumento.includes(id);
    };
    const envejecer = (segundos: number) =>
      admin.$executeRaw`
        UPDATE "SolicitudesVerificacion"
        SET creada_en = now() - make_interval(secs => ${segundos}::double precision)
        WHERE id = ${id}::uuid`;

    expect(await tomada()).toBe(false);
    await envejecer(8);
    expect(await tomada()).toBe(false);
    await envejecer(11);
    expect(await tomada()).toBe(true);
  });

  it('exigirUtc sigue rechazando una sesión que no aplica la opción', async () => {
    const repositorio = new RevisionVerificacionRepository(
      crudo as unknown as PrismaService,
    );

    await expect(
      repositorio.resolverLote({
        revisadoEn: new Date(),
        excluir: [],
        lote: 1,
      }),
    ).rejects.toBeInstanceOf(ZonaHorariaNoUtcError);
  });

  describe('advertencia de zona horaria al arrancar', () => {
    afterEach(() => {
      vi.restoreAllMocks();
    });

    const advertencias = () => {
      vi.spyOn(Logger.prototype, 'log').mockImplementation(() => undefined);
      return vi
        .spyOn(Logger.prototype, 'warn')
        .mockImplementation(() => undefined);
    };

    it('con la sesión en UTC, onModuleInit no advierte nada', async () => {
      const warn = advertencias();

      await servicio.onModuleInit();

      expect(warn).not.toHaveBeenCalled();
    });

    it('si DATABASE_URL fija otra zona, onModuleInit advierte con la zona y sin la URL ni la contraseña', async () => {
      const conZona = new URL(urlDelRol);
      conZona.searchParams.set('options', '-c TimeZone=America/El_Salvador');
      const otro = new PrismaService({
        get: (nombre: string) =>
          nombre === 'DATABASE_URL' ? conZona.toString() : 'test',
      } as unknown as ConfigService<EnvConfig, true>);
      const warn = advertencias();

      try {
        await otro.onModuleInit();
        // La opción explícita se respeta: la sesión real no está en UTC.
        expect(await zonaDe(otro)).toBe('America/El_Salvador');
      } finally {
        await otro.$disconnect();
      }

      expect(warn).toHaveBeenCalledTimes(1);
      const mensaje = String(warn.mock.calls[0]![0]);
      expect(mensaje).toContain('"America/El_Salvador" en lugar de UTC');
      expect(mensaje).not.toContain(clave);
      expect(mensaje).not.toContain(rol);
      expect(mensaje).not.toContain('postgresql://');
    });
  });

  it('otros módulos: la fecha por defecto de un usuario creado con PrismaService es el instante actual', async () => {
    const id = await crearUsuario(servicio);

    const [fila] = await admin.$queryRaw<{ segundos: number }[]>`
      SELECT extract(epoch FROM (creado_en - now()))::float8 AS segundos
      FROM "Usuarios" WHERE id = ${id}::uuid`;
    expect(Math.abs(fila!.segundos)).toBeLessThan(5);
  });
});
