import { Logger } from '@nestjs/common';
import type { ConfigService } from '@nestjs/config';
import pg from 'pg';
import type { EnvConfig } from '@Config';
import { esZonaUtc } from '@Verificaciones/repositories';
import {
  conexionEnUtc,
  esSesionUtc,
  OPCION_ZONA_UTC,
  PrismaService,
} from './prisma.service.js';

/**
 * Lo que `pg` usará de verdad al conectar (la URL tiene prioridad sobre la
 * configuración). Crear el `Client` no abre ninguna conexión.
 */
const efectivo = (config: ReturnType<typeof conexionEnUtc>) =>
  (
    new pg.Client(config) as unknown as {
      connectionParameters: {
        options?: string;
        ssl: unknown;
        database: string;
        host: string;
        user: string;
        password: string;
      };
    }
  ).connectionParameters;

describe('conexionEnUtc', () => {
  it('sin options en la URL deja la URL intacta y agrega TimeZone=UTC', () => {
    const url =
      'postgresql://postgres:postgres@localhost:5432/si_be_boilerplate?schema=public';

    const config = conexionEnUtc(url);

    expect(config).toEqual({ connectionString: url, options: OPCION_ZONA_UTC });
    expect(efectivo(config).options).toBe('-c TimeZone=UTC');
  });

  it('con options en la URL añade TimeZone=UTC sin quitar las existentes', () => {
    const url =
      'postgresql://u:p@h:5432/db?options=-c%20search_path%3Dapp&schema=public';

    const config = conexionEnUtc(url);

    expect(config.options).toBeUndefined();
    expect(efectivo(config).options).toBe('-c search_path=app -c TimeZone=UTC');
    expect(new URL(config.connectionString).searchParams.get('schema')).toBe(
      'public',
    );
  });

  it.each([
    '-c TimeZone=America/Guatemala',
    '-c timezone=America/Guatemala',
    '-ctimezone=UTC',
    '--TimeZone=Europe/Madrid',
    '-c search_path=app -c TimeZone=America/El_Salvador',
  ])(
    'si la URL ya fija la zona (%s), la respeta y no agrega otra',
    (opciones) => {
      const url = `postgresql://u:p@h:5432/db?options=${encodeURIComponent(opciones)}`;

      const config = conexionEnUtc(url);

      expect(config).toEqual({ connectionString: url });
      expect(efectivo(config).options).toBe(opciones);
    },
  );

  it('no toca SSL, usuario, contraseña, host ni base', () => {
    const url =
      'postgresql://usuario:p%40ss%3Aword@db.example.com:6543/app?sslmode=no-verify';

    const antes = efectivo({ connectionString: url });
    const despues = efectivo(conexionEnUtc(url));

    expect(despues.ssl).toEqual(antes.ssl);
    expect(despues.user).toBe('usuario');
    expect(despues.password).toBe('p@ss:word');
    expect(despues.host).toBe('db.example.com');
    expect(despues.database).toBe('app');
  });

  it('con options en la URL conserva una contraseña con caracteres especiales', () => {
    const url =
      'postgresql://usuario:p%40ss%3Aword@h:5432/app?options=-c%20search_path%3Dapp';

    const despues = efectivo(conexionEnUtc(url));

    expect(despues.password).toBe('p@ss:word');
    expect(despues.options).toBe('-c search_path=app -c TimeZone=UTC');
  });

  it('una cadena que no es URL se deja como está y la opción va en la configuración', () => {
    expect(conexionEnUtc('no es una url')).toEqual({
      connectionString: 'no es una url',
      options: OPCION_ZONA_UTC,
    });
  });
});

describe('esSesionUtc', () => {
  it.each([
    'UTC',
    'Etc/UTC',
    'utc',
    'UCT',
    'Universal',
    'Etc/Zulu',
    'GMT',
    'Etc/GMT0',
    'GMT+0',
    'Etc/GMT-0',
    'Greenwich',
    ' UTC ',
  ])('%s es UTC', (zona) => {
    expect(esSesionUtc(zona)).toBe(true);
  });

  it.each([
    'America/El_Salvador',
    'America/Guatemala',
    'Europe/London',
    'GMT+6',
    'Etc/GMT-1',
    'UTC+1',
    '',
  ])('%s no es UTC', (zona) => {
    expect(esSesionUtc(zona)).toBe(false);
  });

  it('acepta los mismos nombres que la comprobación de la revisión simulada', () => {
    for (const zona of [
      'UTC',
      'Etc/UTC',
      'UCT',
      'Etc/UCT',
      'Universal',
      'Etc/Universal',
      'Zulu',
      'Etc/Zulu',
      'GMT',
      'Etc/GMT',
      'GMT0',
      'Etc/GMT0',
      'GMT+0',
      'Etc/GMT+0',
      'GMT-0',
      'Etc/GMT-0',
      'Greenwich',
      'Etc/Greenwich',
      'America/El_Salvador',
      'Europe/London',
    ]) {
      expect(esSesionUtc(zona)).toBe(esZonaUtc(zona));
    }
  });
});

describe('PrismaService.onModuleInit: advertencia de zona horaria', () => {
  const config = {
    get: (nombre: string) =>
      nombre === 'DATABASE_URL'
        ? 'postgresql://usuario:secreta@localhost:5432/app'
        : 'test',
  } as unknown as ConfigService<EnvConfig, true>;

  /** Un PrismaService sin base: la conexión y la consulta son simuladas. */
  const crear = (consulta: () => Promise<unknown>) => {
    const servicio = new PrismaService(config);
    const conectar = vi
      .spyOn(servicio, '$connect')
      .mockResolvedValue(undefined);
    const consultar = vi
      .spyOn(servicio, '$queryRaw')
      .mockImplementation(consulta as never);
    const warn = vi
      .spyOn(Logger.prototype, 'warn')
      .mockImplementation(() => undefined);
    vi.spyOn(Logger.prototype, 'log').mockImplementation(() => undefined);
    return { servicio, conectar, consultar, warn };
  };

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it('con la sesión en UTC no advierte nada', async () => {
    const { servicio, conectar, consultar, warn } = crear(() =>
      Promise.resolve([{ zona: 'UTC' }]),
    );

    await servicio.onModuleInit();

    expect(conectar).toHaveBeenCalledTimes(1);
    expect(consultar).toHaveBeenCalledTimes(1);
    const [partes] = consultar.mock.calls[0] as unknown as [
      TemplateStringsArray,
    ];
    expect(partes.join('?')).toContain("current_setting('TimeZone')");
    expect(warn).not.toHaveBeenCalled();
  });

  it('con la sesión en otra zona advierte con la zona, sin la URL ni la contraseña', async () => {
    const { servicio, warn } = crear(() =>
      Promise.resolve([{ zona: 'America/El_Salvador' }]),
    );

    await servicio.onModuleInit();

    expect(warn).toHaveBeenCalledTimes(1);
    const mensaje = String(warn.mock.calls[0]![0]);
    expect(mensaje).toContain('"America/El_Salvador" en lugar de UTC');
    expect(mensaje).not.toContain('secreta');
    expect(mensaje).not.toContain('postgresql://');
  });

  it('si la consulta falla, advierte sin detener el arranque y sin el mensaje del error', async () => {
    const { servicio, warn } = crear(() =>
      Promise.reject(new Error('fallo en host:5432 con secreta')),
    );

    await expect(servicio.onModuleInit()).resolves.toBeUndefined();

    expect(warn).toHaveBeenCalledTimes(1);
    const mensaje = String(warn.mock.calls[0]![0]);
    expect(mensaje).toContain('No se pudo comprobar la zona horaria');
    expect(mensaje).not.toContain('secreta');
  });

  it('comprueba una sola vez, al arrancar: no hay consultas por solicitud', async () => {
    const { servicio, consultar } = crear(() =>
      Promise.resolve([{ zona: 'UTC' }]),
    );

    await servicio.onModuleInit();

    expect(consultar).toHaveBeenCalledTimes(1);
  });
});
