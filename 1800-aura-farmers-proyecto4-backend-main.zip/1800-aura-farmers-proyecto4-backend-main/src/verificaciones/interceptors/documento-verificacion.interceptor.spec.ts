import {
  BadRequestException,
  ConflictException,
  PayloadTooLargeException,
} from '@nestjs/common';
import multer from 'multer';
import { traducirErrorDeMulterDocumento } from './documento-verificacion.interceptor.js';

function mensaje400(error: unknown): string {
  const traducido = traducirErrorDeMulterDocumento(error);
  expect(traducido).toBeInstanceOf(BadRequestException);
  return (traducido.getResponse() as { message: string[] }).message[0]!;
}

describe('traducirErrorDeMulterDocumento', () => {
  it('responde 413 a un archivo de más de 5 MB', () => {
    const traducido = traducirErrorDeMulterDocumento(
      new multer.MulterError('LIMIT_FILE_SIZE', 'documento'),
    );

    expect(traducido).toBeInstanceOf(PayloadTooLargeException);
    expect(traducido.getResponse()).toMatchObject({
      message: 'El archivo supera 5 MB.',
    });
  });

  it('responde 400 a un segundo documento', () => {
    expect(mensaje400(new multer.MulterError('LIMIT_FILE_COUNT'))).toBe(
      'Solo se puede enviar un documento.',
    );
    expect(
      mensaje400(new multer.MulterError('LIMIT_UNEXPECTED_FILE', 'documento')),
    ).toBe('Solo se puede enviar un documento.');
  });

  it('distingue un archivo en otro campo', () => {
    expect(
      mensaje400(new multer.MulterError('LIMIT_UNEXPECTED_FILE', 'archivo')),
    ).toBe(
      'El campo archivo no admite archivos. Envía el documento en el campo documento.',
    );
  });

  it.each(['LIMIT_FIELD_COUNT', 'LIMIT_PART_COUNT'] as const)(
    'responde 400 cuando el formulario pasa del límite (%s)',
    (codigo) => {
      expect(mensaje400(new multer.MulterError(codigo))).toBe(
        'El formulario tiene más campos de los permitidos.',
      );
    },
  );

  it('responde 400 a un multipart mal formado', () => {
    expect(mensaje400(new Error('Unexpected end of form'))).toBe(
      'El formulario multipart está mal formado.',
    );
  });

  it('deja pasar una HttpException sin cambiarla', () => {
    const original = new ConflictException('otro');

    expect(traducirErrorDeMulterDocumento(original)).toBe(original);
  });
});
