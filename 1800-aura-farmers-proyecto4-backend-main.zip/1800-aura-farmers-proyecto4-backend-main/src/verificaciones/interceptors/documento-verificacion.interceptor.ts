import {
  BadRequestException,
  HttpException,
  Injectable,
  PayloadTooLargeException,
  type CallHandler,
  type ExecutionContext,
  type NestInterceptor,
} from '@nestjs/common';
import multer from 'multer';
import type { Request, Response } from 'express';
import type { Observable } from 'rxjs';
import {
  CAMPO_DOCUMENTO,
  MAX_CAMPOS_FORMULARIO,
  MAX_DOCUMENTO_BYTES,
  MAX_PARTES_FORMULARIO,
  MENSAJES_VERIFICACION,
  campoSinArchivos,
} from '@Verificaciones/constants';

/**
 * Recibe el documento del campo `documento` con multer y lo deja en
 * `request.file`.
 *
 * Cumple el mismo papel que `FileInterceptor` de Nest, pero responde con
 * mensajes en español: 413 si el archivo supera 5 MB (BE-17.1) y 400 para los
 * demás errores del formulario.
 *
 * - El archivo queda en memoria (como máximo 5 MB): se guarda en la base, en
 *   `DocumentosVerificacion.contenido`, y nunca se escribe en disco.
 * - `defParamCharset: 'utf8'` conserva los acentos del nombre original; multer
 *   lo leería como latin1 por defecto ("cÃ©dula.jpg").
 * - `preservePath: true` deja el nombre tal como lo manda el cliente, y la
 *   ruta la quita `DocumentoVerificacionPipe`. Sin eso, busboy convierte un
 *   nombre como `..` o `docs/` en vacío y multer descarta el archivo, así que
 *   el cliente recibiría "falta el documento" en lugar de "nombre no válido".
 * - Se limitan los campos de texto y las partes: sin eso, un formulario con
 *   miles de campos se lee completo en memoria.
 */
@Injectable()
export class DocumentoVerificacionInterceptor implements NestInterceptor {
  private readonly recibirDocumento = multer({
    storage: multer.memoryStorage(),
    defParamCharset: 'utf8',
    preservePath: true,
    limits: {
      fileSize: MAX_DOCUMENTO_BYTES,
      files: 1,
      fields: MAX_CAMPOS_FORMULARIO,
      parts: MAX_PARTES_FORMULARIO,
    },
  }).single(CAMPO_DOCUMENTO);

  async intercept(
    context: ExecutionContext,
    next: CallHandler,
  ): Promise<Observable<unknown>> {
    const http = context.switchToHttp();

    await new Promise<void>((resolve, reject) => {
      this.recibirDocumento(
        http.getRequest<Request>(),
        http.getResponse<Response>(),
        (error: unknown) =>
          error ? reject(traducirErrorDeMulterDocumento(error)) : resolve(),
      );
    });

    return next.handle();
  }
}

/**
 * Convierte un error de multer o de busboy en la respuesta HTTP de BE-17.1:
 * 413 si el archivo supera 5 MB y 400 para lo demás.
 */
export function traducirErrorDeMulterDocumento(error: unknown): HttpException {
  if (error instanceof HttpException) return error;

  if (error instanceof multer.MulterError) {
    switch (error.code) {
      case 'LIMIT_FILE_SIZE':
        return new PayloadTooLargeException(
          MENSAJES_VERIFICACION.DOCUMENTO_DEMASIADO_GRANDE,
        );
      case 'LIMIT_FILE_COUNT':
        return new BadRequestException([
          MENSAJES_VERIFICACION.UN_SOLO_DOCUMENTO,
        ]);
      case 'LIMIT_UNEXPECTED_FILE':
        // multer usa el mismo código para un archivo en otro campo y para un
        // segundo archivo en `documento`.
        return new BadRequestException([
          error.field === CAMPO_DOCUMENTO
            ? MENSAJES_VERIFICACION.UN_SOLO_DOCUMENTO
            : campoSinArchivos(error.field),
        ]);
      case 'LIMIT_FIELD_COUNT':
      case 'LIMIT_PART_COUNT':
        return new BadRequestException([
          MENSAJES_VERIFICACION.DEMASIADOS_CAMPOS,
        ]);
      default:
        return new BadRequestException([error.message]);
    }
  }

  // Lo demás viene de busboy al leer un cuerpo multipart mal formado.
  return new BadRequestException([
    MENSAJES_VERIFICACION.FORMULARIO_MAL_FORMADO,
  ]);
}
