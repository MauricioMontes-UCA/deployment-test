import type { PrismaService } from '@Prisma/services';
import {
  ESPERA_MINIMA_REVISION_MS,
  GRACIA_CONCILIACION_MS,
  MOTIVO_RECHAZO_SIMULADO,
} from '@Verificaciones/constants';
import { ZonaHorariaNoUtcError } from '@Verificaciones/errors';
import {
  RevisionVerificacionRepository,
  esZonaUtc,
} from './revision-verificacion.repository.js';

const AHORA = new Date('2026-11-16T15:00:20.000Z');

/** La primera consulta de la transacción es la zona horaria; la segunda, el lote. */
function crear(filas: unknown[] = [], count = 1, zona = 'UTC') {
  const tx = {
    $queryRaw: vi
      .fn()
      .mockResolvedValueOnce([{ zona }])
      .mockResolvedValue(filas),
    solicitudVerificacion: {
      updateMany: vi.fn().mockResolvedValue({ count }),
    },
  };
  const prisma = {
    $transaction: vi.fn((fn: (cliente: typeof tx) => unknown) => fn(tx)),
  };
  const repository = new RevisionVerificacionRepository(
    prisma as unknown as PrismaService,
  );
  return { repository, prisma, tx };
}

const parametros = {
  revisadoEn: AHORA,
  excluir: ['excluida-1'],
  lote: 20,
};

/** El SQL de la llamada `n` a `$queryRaw`, sin los valores de los parámetros. */
function sqlDe(tx: ReturnType<typeof crear>['tx'], n = 1): string {
  const [partes] = tx.$queryRaw.mock.calls[n] as [TemplateStringsArray];
  return partes.join('?').replace(/\s+/g, ' ');
}

describe('RevisionVerificacionRepository: zona horaria de la sesión', () => {
  it('lee la zona efectiva de la sesión dentro de la misma transacción, antes del lote', async () => {
    const { repository, prisma, tx } = crear();

    await repository.resolverLote(parametros);

    expect(prisma.$transaction).toHaveBeenCalledTimes(1);
    expect(tx.$queryRaw).toHaveBeenCalledTimes(2);
    expect(sqlDe(tx, 0)).toContain("SELECT current_setting('TimeZone')");
    expect(sqlDe(tx, 1)).toContain('FOR UPDATE OF s SKIP LOCKED');
  });

  it('fuera de UTC lanza ZonaHorariaNoUtcError sin tomar ni actualizar nada', async () => {
    const { repository, tx } = crear(
      [{ id: 's-1', usuarioId: 'u-1', nombreArchivo: 'cedula.jpg' }],
      1,
      'America/Guatemala',
    );

    const error = await repository.resolverLote(parametros).catch((e) => e);

    expect(error).toBeInstanceOf(ZonaHorariaNoUtcError);
    expect((error as Error).message).toContain('"America/Guatemala"');
    expect((error as Error).message).toContain('requiere UTC');
    expect(tx.$queryRaw).toHaveBeenCalledTimes(1);
    expect(tx.solicitudVerificacion.updateMany).not.toHaveBeenCalled();
  });

  it.each([
    'UTC',
    'Etc/UTC',
    'utc',
    'UCT',
    'Universal',
    'Zulu',
    'GMT',
    'Etc/GMT',
  ])('acepta %s como UTC', (zona) => {
    expect(esZonaUtc(zona)).toBe(true);
  });

  it.each([
    'America/Guatemala',
    'America/El_Salvador',
    'Europe/London',
    'Etc/GMT+6',
    'UTC+1',
    '',
  ])('rechaza %j', (zona) => {
    expect(esZonaUtc(zona)).toBe(false);
  });
});

describe('RevisionVerificacionRepository.resolverLote', () => {
  it('toma el lote dentro de una transacción con FOR UPDATE OF s SKIP LOCKED', async () => {
    const { repository, prisma, tx } = crear();

    await repository.resolverLote(parametros);

    expect(prisma.$transaction).toHaveBeenCalledTimes(1);
    const sql = sqlDe(tx);
    expect(sql).toContain("WHERE s.estado = 'EN_REVISION'");
    expect(sql).toContain('NOT (s.id = ANY(?::uuid[]))');
    expect(sql).toContain('ORDER BY s.creada_en, s.id');
    expect(sql).toContain('LIMIT ?');
    expect(sql).toContain('FOR UPDATE OF s SKIP LOCKED');
  });

  it('mide la espera mínima con el reloj de PostgreSQL, no con una fecha de la aplicación', async () => {
    const { repository, tx } = crear();

    await repository.resolverLote(parametros);

    expect(sqlDe(tx)).toContain(
      's.creada_en <= CURRENT_TIMESTAMP - make_interval(secs => ?::double precision)',
    );
    // Ningún parámetro es una fecha: la de `revisadoEn` no entra en la consulta.
    const valores = tx.$queryRaw.mock.calls[1]!.slice(1) as unknown[];
    expect(valores.some((v) => v instanceof Date)).toBe(false);
  });

  it('la espera sale de ESPERA_MINIMA_REVISION_MS, como parámetro: no hay un intervalo escrito a mano', async () => {
    const { repository, tx } = crear();

    await repository.resolverLote(parametros);

    const sql = sqlDe(tx);
    expect(sql).not.toMatch(/INTERVAL\s*'/i);
    expect(sql).not.toMatch(/\b10\s*seconds?\b/i);
    // El primer parámetro de la consulta es la espera, en segundos y numérico.
    const [espera] = tx.$queryRaw.mock.calls[1]!.slice(1) as unknown[];
    expect(espera).toBe(ESPERA_MINIMA_REVISION_MS / 1000);
    expect(typeof espera).toBe('number');
  });

  it('con el valor actual, la espera es de 10 segundos', () => {
    expect(ESPERA_MINIMA_REVISION_MS).toBe(10_000);
    expect(ESPERA_MINIMA_REVISION_MS / 1000).toBe(10);
  });

  it('pasa como parámetros solo la espera, las excluidas y el tamaño del lote', async () => {
    const { repository, tx } = crear();

    await repository.resolverLote(parametros);

    expect(tx.$queryRaw.mock.calls[1]!.slice(1)).toEqual([
      ESPERA_MINIMA_REVISION_MS / 1000,
      ['excluida-1'],
      20,
    ]);
  });

  it('nunca lee el contenido del documento: solo su nombre', async () => {
    const { repository, tx } = crear();

    await repository.resolverLote(parametros);

    const sql = sqlDe(tx);
    expect(sql).toContain('d.nombre_archivo');
    expect(sql).not.toContain('contenido');
    expect(sql).not.toContain('d.*');
  });

  it('resuelve con updateMany condicionado al estado EN_REVISION', async () => {
    const { repository, tx } = crear([
      { id: 's-1', usuarioId: 'u-1', nombreArchivo: 'cedula.jpg' },
      { id: 's-2', usuarioId: 'u-2', nombreArchivo: 'rechazar_1.png' },
    ]);

    const resultado = await repository.resolverLote(parametros);

    expect(tx.solicitudVerificacion.updateMany).toHaveBeenNthCalledWith(1, {
      where: { id: 's-1', estado: 'EN_REVISION' },
      data: { estado: 'APROBADA', motivo: null, revisadoEn: AHORA },
    });
    expect(tx.solicitudVerificacion.updateMany).toHaveBeenNthCalledWith(2, {
      where: { id: 's-2', estado: 'EN_REVISION' },
      data: {
        estado: 'RECHAZADA',
        motivo: 'Documento no válido (revisión simulada).',
        revisadoEn: AHORA,
      },
    });
    expect(resultado).toEqual({
      tomadas: 2,
      sinDocumento: [],
      resueltas: [
        {
          id: 's-1',
          usuarioId: 'u-1',
          resultado: { estado: 'APROBADA', motivo: null },
        },
        {
          id: 's-2',
          usuarioId: 'u-2',
          resultado: {
            estado: 'RECHAZADA',
            motivo: 'Documento no válido (revisión simulada).',
          },
        },
      ],
    });
  });

  it('si updateMany no cambia ninguna fila, la solicitud no cuenta como resuelta', async () => {
    const { repository } = crear(
      [{ id: 's-1', usuarioId: 'u-1', nombreArchivo: 'cedula.jpg' }],
      0,
    );

    const resultado = await repository.resolverLote(parametros);

    expect(resultado.resueltas).toEqual([]);
    expect(resultado.tomadas).toBe(1);
  });

  it('una solicitud sin documento no se actualiza: se informa aparte', async () => {
    const { repository, tx } = crear([
      { id: 's-1', usuarioId: 'u-1', nombreArchivo: null },
      { id: 's-2', usuarioId: 'u-2', nombreArchivo: 'cedula.jpg' },
    ]);

    const resultado = await repository.resolverLote(parametros);

    expect(tx.solicitudVerificacion.updateMany).toHaveBeenCalledTimes(1);
    expect(resultado.sinDocumento).toEqual(['s-1']);
    expect(resultado.resueltas.map((s) => s.id)).toEqual(['s-2']);
  });

  it('sin solicitudes pendientes no actualiza nada', async () => {
    const { repository, tx } = crear([]);

    await expect(repository.resolverLote(parametros)).resolves.toEqual({
      tomadas: 0,
      resueltas: [],
      sinDocumento: [],
    });
    expect(tx.solicitudVerificacion.updateMany).not.toHaveBeenCalled();
  });
});

describe('RevisionVerificacionRepository.avisosPendientes', () => {
  function crearLectura(filas: unknown[] = []) {
    const prisma = {
      $queryRaw: vi.fn().mockResolvedValue(filas),
      $transaction: vi.fn(),
    };
    const repository = new RevisionVerificacionRepository(
      prisma as unknown as PrismaService,
    );
    const sql = () => {
      const [partes] = prisma.$queryRaw.mock.calls[0] as [TemplateStringsArray];
      return partes.join('?').replace(/\s+/g, ' ');
    };
    return { repository, prisma, sql };
  }

  it('busca resueltas sin aviso por la clave del Módulo 8, solo de usuarios activos', async () => {
    const { repository, sql } = crearLectura();

    await repository.avisosPendientes({ excluir: [], lote: 20 });

    const consulta = sql();
    expect(consulta).toContain(
      "WHERE ( s.estado = 'APROBADA' OR (s.estado = 'RECHAZADA' AND s.motivo = ?) )",
    );
    expect(consulta).toContain(
      'JOIN "Usuarios" u ON u.id = s.usuario_id AND u.is_active',
    );
    expect(consulta).toContain('NOT EXISTS ( SELECT 1 FROM "Notificaciones" n');
    expect(consulta).toContain('n.destinatario_id = s.usuario_id');
    expect(consulta).toContain('AND n.tipo_referencia = ?');
    expect(consulta).toContain('AND n.referencia_id = s.id::text');
  });

  it('las más antiguas primero, con un límite por corrida y sin antigüedad máxima', async () => {
    const { repository, sql } = crearLectura();

    await repository.avisosPendientes({ excluir: [], lote: 20 });

    const consulta = sql();
    expect(consulta).toContain('ORDER BY s.revisado_en, s.id');
    expect(consulta).toContain('LIMIT ?');
    // Solo un mínimo (la gracia): ninguna condición deja fuera a las antiguas.
    expect(consulta).toContain(
      's.revisado_en <= CURRENT_TIMESTAMP - make_interval(secs => ?::double precision)',
    );
    expect(consulta.match(/CURRENT_TIMESTAMP|now\(\)/gi)).toHaveLength(1);
    expect(consulta).not.toMatch(/revisado_en\s*>=?|INTERVAL\s*'/i);
  });

  it('solo concilia rechazos con el motivo de la revisión simulada, pasado como parámetro', async () => {
    const { repository, prisma, sql } = crearLectura();

    await repository.avisosPendientes({ excluir: [], lote: 20 });

    // El motivo no va escrito en el SQL: es un parámetro.
    expect(sql()).not.toContain(MOTIVO_RECHAZO_SIMULADO);
    expect(sql()).not.toContain('Documento no válido');
    expect(prisma.$queryRaw.mock.calls[0]![1]).toBe(MOTIVO_RECHAZO_SIMULADO);
    // Una APROBADA no depende del motivo.
    expect(sql()).not.toMatch(/'APROBADA' AND/);
  });

  it('pasa como parámetros solo el motivo, la gracia, las excluidas, el tipo de referencia y el lote', async () => {
    const { repository, prisma } = crearLectura();

    await repository.avisosPendientes({ excluir: ['s-1', 's-2'], lote: 7 });

    expect(prisma.$queryRaw.mock.calls[0]!.slice(1)).toEqual([
      MOTIVO_RECHAZO_SIMULADO,
      GRACIA_CONCILIACION_MS / 1000,
      ['s-1', 's-2'],
      'SOLICITUD_VERIFICACION',
      7,
    ]);
  });

  it('solo lee: no abre transacciones ni actualiza solicitudes', async () => {
    const filas = [
      { id: 's-1', usuarioId: 'u-1', estado: 'APROBADA', motivo: null },
    ];
    const { repository, prisma } = crearLectura(filas);

    await expect(
      repository.avisosPendientes({ excluir: [], lote: 20 }),
    ).resolves.toEqual(filas);
    expect(prisma.$transaction).not.toHaveBeenCalled();
  });
});
