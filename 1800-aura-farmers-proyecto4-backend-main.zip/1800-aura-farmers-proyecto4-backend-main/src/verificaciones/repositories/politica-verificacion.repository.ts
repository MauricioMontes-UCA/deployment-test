import { Injectable } from '@nestjs/common';
import { PrismaService } from '@Prisma/services';
import { Prisma } from '@PrismaClient';

const FOREIGN_KEY_VIOLATION = 'P2003';

/** Cliente con el que se lee: el pool, o la transacción en curso. */
type Cliente = PrismaService | Prisma.TransactionClient;

/** Lo que hace falta de un bien para su política: dueño y valor actual. */
export interface BienConPolitica {
  arrendadorId: string;
  /** `false` si el bien no tiene registro de política (DB-19.1). */
  soloVerificados: boolean;
}

export interface PoliticaGuardada {
  bienId: string;
  soloVerificados: boolean;
}

/** Política "Solo usuarios verificados" de cada bien (DB-19.1, BE-19.1). */
@Injectable()
export class PoliticaVerificacionRepository {
  constructor(private readonly prisma: PrismaService) {}

  /**
   * Si el bien exige usuarios verificados. Un bien sin registro de política se
   * trata como `false` (DB-19.1), exista o no el bien. `db` permite leer dentro
   * de una transacción en curso; sin él, usa el pool.
   */
  async soloVerificados(
    bienId: string,
    db: Cliente = this.prisma,
  ): Promise<boolean> {
    const politica = await db.politicaVerificacionBien.findUnique({
      where: { bienId },
      select: { soloVerificados: true },
    });
    return politica?.soloVerificados ?? false;
  }

  /**
   * El bien con su dueño y su política, o `null` si no existe. No filtra por
   * estado: un bien INACTIVA también tiene política. Un bien sin registro en
   * `PoliticasVerificacionBien` se trata como `soloVerificados = false`.
   */
  async findBien(bienId: string): Promise<BienConPolitica | null> {
    const bien = await this.prisma.bien.findUnique({
      where: { id: bienId },
      select: {
        arrendadorId: true,
        politicaVerificacion: { select: { soloVerificados: true } },
      },
    });
    if (!bien) return null;
    return {
      arrendadorId: bien.arrendadorId,
      soloVerificados: bien.politicaVerificacion?.soloVerificados ?? false,
    };
  }

  /**
   * Crea la política o actualiza la existente. `bienId` es la clave primaria,
   * así que nunca hay dos registros del mismo bien. Devuelve el valor tal como
   * quedó guardado, o `null` si el bien dejó de existir entre la consulta y la
   * escritura (la FK lo rechaza).
   */
  async guardar(
    bienId: string,
    soloVerificados: boolean,
  ): Promise<PoliticaGuardada | null> {
    try {
      return await this.prisma.politicaVerificacionBien.upsert({
        where: { bienId },
        create: { bienId, soloVerificados },
        update: { soloVerificados },
        select: { bienId: true, soloVerificados: true },
      });
    } catch (error) {
      if (
        error instanceof Prisma.PrismaClientKnownRequestError &&
        error.code === FOREIGN_KEY_VIOLATION
      ) {
        return null;
      }
      throw error;
    }
  }
}
