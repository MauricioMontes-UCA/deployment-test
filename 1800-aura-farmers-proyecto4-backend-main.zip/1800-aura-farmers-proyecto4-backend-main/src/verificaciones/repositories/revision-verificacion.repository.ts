import { Injectable } from '@nestjs/common';
import { PrismaService } from '@Prisma/services';
import { EstadoSolicitudVerificacion, type Prisma } from '@PrismaClient';
import {
  ESPERA_MINIMA_REVISION_MS,
  GRACIA_CONCILIACION_MS,
  MOTIVO_RECHAZO_SIMULADO,
  TIPO_REFERENCIA_SOLICITUD_VERIFICACION,
} from '@Verificaciones/constants';
import { ZonaHorariaNoUtcError } from '@Verificaciones/errors';
import {
  revisarDocumento,
  type ResultadoRevision,
} from '@Verificaciones/utils';

/**
 * Nombres con los que PostgreSQL puede reportar UTC (o su equivalente sin
 * horario de verano), comparados sin distinguir mayúsculas. No incluye zonas
 * que solo coinciden con UTC parte del año, como Europe/London.
 */
const ZONAS_UTC = new Set(
  [
    'UTC',
    'Etc/UTC',
    'UCT',
    'Etc/UCT',
    'Universal',
    'Etc/Universal',
    'Zulu',
    'Etc/Zulu',
    'GMT',
    'Etc/GMT',
    'GMT0',
    'Etc/GMT0',
    'GMT+0',
    'Etc/GMT+0',
    'GMT-0',
    'Etc/GMT-0',
    'Greenwich',
    'Etc/Greenwich',
  ].map((zona) => zona.toLowerCase()),
);

export function esZonaUtc(zona: string): boolean {
  return ZONAS_UTC.has(zona.trim().toLowerCase());
}

/** Fila cruda de la consulta con FOR UPDATE SKIP LOCKED. */
interface FilaPendiente {
  id: string;
  usuarioId: string;
  /** `null` si la solicitud no tiene documento. */
  nombreArchivo: string | null;
}

/** Solicitud que esta transacción resolvió: hay que avisar a su usuario. */
export interface SolicitudResuelta {
  id: string;
  usuarioId: string;
  resultado: ResultadoRevision;
}

export interface ParametrosLote {
  /** Lo que se guarda en `revisadoEn`. */
  revisadoEn: Date;
  /** Solicitudes que ya se descartaron en esta corrida (sin documento). */
  excluir: string[];
  lote: number;
}

export interface ResultadoLote {
  /** Filas que se tomaron y bloquearon; menos que `lote` es el último lote. */
  tomadas: number;
  resueltas: SolicitudResuelta[];
  /** Solicitudes sin documento: quedan EN_REVISION. */
  sinDocumento: string[];
}

/** Solicitud ya resuelta cuyo aviso todavía no existe en el Módulo 8. */
export interface AvisoPendiente {
  id: string;
  usuarioId: string;
  estado: 'APROBADA' | 'RECHAZADA';
  motivo: string | null;
}

export interface ParametrosAvisosPendientes {
  /** Solicitudes que no hay que devolver (las que esperan para reintentar). */
  excluir: string[];
  lote: number;
}

/**
 * Transacción de la revisión simulada (BE-18.1).
 *
 * Única parte del procesador que escribe en `SolicitudesVerificacion`. Nunca
 * lee `DocumentosVerificacion.contenido`: solo el nombre del archivo. Para la
 * conciliación de avisos lee también `Notificaciones` y `Usuarios`, solo por
 * las columnas de la clave del aviso y `is_active`; los avisos se crean
 * siempre con `NotificacionesService.crear`.
 */
@Injectable()
export class RevisionVerificacionRepository {
  constructor(private readonly prisma: PrismaService) {}

  /**
   * Toma un lote de solicitudes pendientes y las resuelve, todo en una sola
   * transacción, es decir, sobre una sola conexión del pool:
   *
   * 0. Comprueba que la sesión de esa conexión esté en UTC. `PrismaService`
   *    ya abre cada sesión en UTC (`conexionEnUtc`); esta comprobación es la
   *    protección para cuando eso no se cumple (una `DATABASE_URL` que fija
   *    otra zona, o un SET en la sesión). Si no está en UTC, lanza
   *    `ZonaHorariaNoUtcError` y la transacción se revierte sin tocar nada.
   *    Se comprueba en cada lote y en la misma transacción porque cada lote
   *    puede usar otra conexión del pool.
   * 1. `SELECT … FOR UPDATE OF s SKIP LOCKED`: las filas quedan bloqueadas
   *    hasta el commit, y otro procesador que corra a la vez salta las que ya
   *    se tomaron en lugar de esperarlas. Es `OF s` porque PostgreSQL no
   *    permite bloquear el lado opcional de un LEFT JOIN. La antigüedad
   *    mínima se mide con el reloj de PostgreSQL, así que un reloj desfasado
   *    en la aplicación no la acorta. Requiere UTC aunque las columnas sean
   *    `timestamptz`: el adaptador pg escribe los `Date` como hora UTC sin
   *    desplazamiento y la sesión la interpreta en su zona, así que fuera de
   *    UTC `creada_en` quedaría corrida respecto a `CURRENT_TIMESTAMP`.
   * 2. `updateMany` con `{ id, estado: 'EN_REVISION' }`: solo cuenta como
   *    resuelta si cambió una fila. Una solicitud ya resuelta no vuelve a
   *    cambiar ni su resultado ni su `revisadoEn`.
   *
   * Los avisos no se envían aquí: el llamador los pide después del commit.
   */
  resolverLote({
    revisadoEn,
    excluir,
    lote,
  }: ParametrosLote): Promise<ResultadoLote> {
    return this.prisma.$transaction(async (tx) => {
      await this.exigirUtc(tx);
      const filas = await this.tomarPendientes(tx, excluir, lote);

      const resueltas: SolicitudResuelta[] = [];
      const sinDocumento: string[] = [];
      for (const fila of filas) {
        const resultado = revisarDocumento(fila.nombreArchivo);
        if (!resultado) {
          sinDocumento.push(fila.id);
          continue;
        }
        const { count } = await tx.solicitudVerificacion.updateMany({
          where: {
            id: fila.id,
            estado: EstadoSolicitudVerificacion.EN_REVISION,
          },
          data: {
            estado: resultado.estado,
            motivo: resultado.motivo,
            revisadoEn,
          },
        });
        if (count === 1) {
          resueltas.push({ id: fila.id, usuarioId: fila.usuarioId, resultado });
        }
      }

      return { tomadas: filas.length, resueltas, sinDocumento };
    });
  }

  /**
   * Solicitudes ya resueltas (APROBADA o RECHAZADA) cuyo aviso no existe: el
   * fallo de un aviso o una caída entre el commit y el aviso las deja así.
   * Solo lee; no cambia ningún estado.
   *
   * - El aviso se busca por la misma clave con la que el Módulo 8 lo
   *   deduplica (`Notificaciones_referencia_key`: destinatario, tipo y
   *   referencia), así que el `NOT EXISTS` usa ese índice.
   * - Sin ventana de tiempo: una solicitud antigua se recupera igual, aunque
   *   la aplicación haya estado caída mucho tiempo. Las más antiguas primero.
   * - Solo las resueltas hace al menos `GRACIA_CONCILIACION_MS` (con el reloj
   *   de PostgreSQL): así no compite con el aviso normal, que se pide justo
   *   después del commit. Las resoluciones del procesador siempre tienen
   *   `revisado_en`; una sin él no la resolvió el procesador.
   * - Solo los resultados que pudo dar el procesador: una APROBADA, o una
   *   RECHAZADA con el motivo de la revisión simulada
   *   (`MOTIVO_RECHAZO_SIMULADO`, el único que escribe). Un rechazo con otro
   *   motivo no lo resolvió este procesador: no se le crea un aviso que diga
   *   lo contrario, ni se reintenta en cada corrida.
   * - Solo usuarios activos: el Módulo 8 no avisa a un usuario inactivo
   *   (`DESTINATARIO_INEXISTENTE`), y no tiene sentido intentarlo en cada
   *   corrida.
   *
   * No hay índice por `estado` y `revisado_en`: con el volumen de solicitudes
   * del proyecto, recorrerlas es barato. Si creciera, un índice parcial sobre
   * las resueltas sería la mejora (requiere una migración).
   */
  avisosPendientes({
    excluir,
    lote,
  }: ParametrosAvisosPendientes): Promise<AvisoPendiente[]> {
    return this.prisma.$queryRaw<AvisoPendiente[]>`
      SELECT s.id,
             s.usuario_id AS "usuarioId",
             s.estado::text AS estado,
             s.motivo
      FROM "SolicitudesVerificacion" s
      JOIN "Usuarios" u ON u.id = s.usuario_id AND u.is_active
      WHERE (
          s.estado = 'APROBADA'
          OR (s.estado = 'RECHAZADA' AND s.motivo = ${MOTIVO_RECHAZO_SIMULADO})
        )
        AND s.revisado_en <= CURRENT_TIMESTAMP - make_interval(secs => ${GRACIA_CONCILIACION_MS / 1000}::double precision)
        AND NOT (s.id = ANY(${excluir}::uuid[]))
        AND NOT EXISTS (
          SELECT 1
          FROM "Notificaciones" n
          WHERE n.destinatario_id = s.usuario_id
            AND n.tipo_referencia = ${TIPO_REFERENCIA_SOLICITUD_VERIFICACION}
            AND n.referencia_id = s.id::text
        )
      ORDER BY s.revisado_en, s.id
      LIMIT ${lote}`;
  }

  /**
   * Zona horaria efectiva de la sesión de esta transacción. Es una consulta
   * sin acceso a tablas. No cambia la zona: solo la verifica.
   */
  private async exigirUtc(tx: Prisma.TransactionClient): Promise<void> {
    const [fila] = await tx.$queryRaw<{ zona: string }[]>`
      SELECT current_setting('TimeZone') AS zona`;
    const zona = fila?.zona ?? '(desconocida)';
    if (!esZonaUtc(zona)) throw new ZonaHorariaNoUtcError(zona);
  }

  /**
   * Las más antiguas primero, con desempate por id.
   *
   * La espera mínima sale de `ESPERA_MINIMA_REVISION_MS`, pasada como
   * parámetro (en segundos) a `make_interval`: no hay un segundo valor escrito
   * a mano que mantener. La comparación la sigue haciendo PostgreSQL con su
   * propio reloj.
   */
  private tomarPendientes(
    tx: Prisma.TransactionClient,
    excluir: string[],
    lote: number,
  ): Promise<FilaPendiente[]> {
    return tx.$queryRaw<FilaPendiente[]>`
      SELECT s.id,
             s.usuario_id AS "usuarioId",
             d.nombre_archivo AS "nombreArchivo"
      FROM "SolicitudesVerificacion" s
      LEFT JOIN "DocumentosVerificacion" d ON d.solicitud_id = s.id
      WHERE s.estado = 'EN_REVISION'
        AND s.creada_en <= CURRENT_TIMESTAMP - make_interval(secs => ${ESPERA_MINIMA_REVISION_MS / 1000}::double precision)
        AND NOT (s.id = ANY(${excluir}::uuid[]))
      ORDER BY s.creada_en, s.id
      LIMIT ${lote}
      FOR UPDATE OF s SKIP LOCKED`;
  }
}
