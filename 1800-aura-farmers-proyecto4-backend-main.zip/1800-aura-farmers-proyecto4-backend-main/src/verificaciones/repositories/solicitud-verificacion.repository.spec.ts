import { Prisma } from '@PrismaClient';
import type { PrismaService } from '@Prisma/services';
import type { DocumentoSubido } from '@Verificaciones/types';
import {
  SOLICITUD_CREADA_SELECT,
  SolicitudVerificacionRepository,
  ULTIMA_SOLICITUD_SELECT,
} from './solicitud-verificacion.repository.js';

const USUARIO_ID = '29bda5e8-e0c8-4ec2-bc7f-94c41c3c0140';

const documento: DocumentoSubido = {
  nombreArchivo: 'dui.pdf',
  contenido: Buffer.from('%PDF-1.7\n'),
  mimeType: 'application/pdf',
  tamanoBytes: 9,
};

const solicitud = {
  id: '5d8e1f2a-7b9c-4d3e-a1b2-c3d4e5f60718',
  estado: 'EN_REVISION',
  creadaEn: new Date('2026-11-16T15:00:00.000Z'),
};

function crear() {
  const prisma = {
    solicitudVerificacion: {
      create: vi.fn().mockResolvedValue(solicitud),
      findFirst: vi.fn().mockResolvedValue(null),
    },
  };
  const repository = new SolicitudVerificacionRepository(
    prisma as unknown as PrismaService,
  );
  return { repository, prisma };
}

function errorPrisma(code: string) {
  return new Prisma.PrismaClientKnownRequestError('fallo', {
    code,
    clientVersion: 'test',
  });
}

describe('SolicitudVerificacionRepository.crearConDocumento', () => {
  it('crea la solicitud EN_REVISION y su documento en un solo create anidado', async () => {
    const { repository, prisma } = crear();

    await expect(
      repository.crearConDocumento(USUARIO_ID, documento),
    ).resolves.toEqual({ solicitud });

    expect(prisma.solicitudVerificacion.create).toHaveBeenCalledTimes(1);
    expect(prisma.solicitudVerificacion.create).toHaveBeenCalledWith({
      data: {
        usuarioId: USUARIO_ID,
        estado: 'EN_REVISION',
        documento: {
          create: {
            nombreArchivo: 'dui.pdf',
            contenido: new Uint8Array(documento.contenido),
            mimeType: 'application/pdf',
            tamanoBytes: 9,
          },
        },
      },
      select: SOLICITUD_CREADA_SELECT,
    });
  });

  it('solo lee id, estado y creadaEn: nunca el documento', () => {
    expect(SOLICITUD_CREADA_SELECT).toEqual({
      id: true,
      estado: true,
      creadaEn: true,
    });
  });

  it('devuelve el rechazo si el índice de una solicitud EN_REVISION la rechaza (P2002)', async () => {
    const { repository, prisma } = crear();
    prisma.solicitudVerificacion.create.mockRejectedValue(errorPrisma('P2002'));

    await expect(
      repository.crearConDocumento(USUARIO_ID, documento),
    ).resolves.toEqual({ rechazo: 'EN_REVISION_EXISTENTE' });
  });

  it('propaga cualquier otro error', async () => {
    const { repository, prisma } = crear();
    const fk = errorPrisma('P2003');
    prisma.solicitudVerificacion.create.mockRejectedValue(fk);

    await expect(
      repository.crearConDocumento(USUARIO_ID, documento),
    ).rejects.toBe(fk);
  });
});

describe('SolicitudVerificacionRepository.findUltimaDeUsuario', () => {
  it('busca solo las solicitudes del usuario, de la más reciente a la más antigua y con desempate por id', async () => {
    const { repository, prisma } = crear();

    await repository.findUltimaDeUsuario(USUARIO_ID);

    expect(prisma.solicitudVerificacion.findFirst).toHaveBeenCalledWith({
      where: { usuarioId: USUARIO_ID },
      orderBy: [{ creadaEn: 'desc' }, { id: 'desc' }],
      select: ULTIMA_SOLICITUD_SELECT,
    });
  });

  it('con un cliente de transacción, lee con ese cliente y no con el pool', async () => {
    const { repository, prisma } = crear();
    const tx = {
      solicitudVerificacion: { findFirst: vi.fn().mockResolvedValue(null) },
    };

    await repository.findUltimaDeUsuario(
      USUARIO_ID,
      tx as unknown as Prisma.TransactionClient,
    );

    expect(tx.solicitudVerificacion.findFirst).toHaveBeenCalledWith({
      where: { usuarioId: USUARIO_ID },
      orderBy: [{ creadaEn: 'desc' }, { id: 'desc' }],
      select: ULTIMA_SOLICITUD_SELECT,
    });
    expect(prisma.solicitudVerificacion.findFirst).not.toHaveBeenCalled();
  });

  it('solo lee id, estado, motivo y revisadoEn: nunca el documento', () => {
    expect(ULTIMA_SOLICITUD_SELECT).toEqual({
      id: true,
      estado: true,
      motivo: true,
      revisadoEn: true,
    });
  });

  it('devuelve null si el usuario no tiene solicitudes', async () => {
    const { repository } = crear();

    await expect(
      repository.findUltimaDeUsuario(USUARIO_ID),
    ).resolves.toBeNull();
  });

  it('devuelve la solicitud que encuentra la base', async () => {
    const { repository, prisma } = crear();
    const ultima = {
      id: 'solicitud-1',
      estado: 'APROBADA',
      motivo: null,
      revisadoEn: new Date('2026-11-16T15:00:10.000Z'),
    };
    prisma.solicitudVerificacion.findFirst.mockResolvedValue(ultima);

    await expect(repository.findUltimaDeUsuario(USUARIO_ID)).resolves.toBe(
      ultima,
    );
  });
});
