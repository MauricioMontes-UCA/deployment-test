import { randomUUID } from 'node:crypto';
import { PrismaPg } from '@prisma/adapter-pg';
import { EstadoSolicitudVerificacion, PrismaClient, Rol } from '@PrismaClient';
import type { PrismaService } from '@Prisma/services';
import { SolicitudVerificacionRepository } from './solicitud-verificacion.repository.js';

const habilitada = process.env.RUN_DB_INTEGRATION === '1';

if (habilitada && !process.env.DATABASE_URL) {
  throw new Error('RUN_DB_INTEGRATION=1 requiere DATABASE_URL configurada.');
}

/**
 * BE-17.2 contra PostgreSQL: qué solicitud cuenta como la más reciente. El
 * orden y el desempate los resuelve la base, así que no se pueden probar con
 * dobles.
 */
describe.skipIf(!habilitada)(
  'BE-17.2 - Solicitud más reciente con PostgreSQL',
  () => {
    let prisma: PrismaClient;
    let repository: SolicitudVerificacionRepository;
    let usuarioId = '';
    let otroId = '';

    const crearSolicitud = (
      usuario: string,
      estado: EstadoSolicitudVerificacion,
      creadaEn: Date,
    ) =>
      prisma.solicitudVerificacion.create({
        data: { usuarioId: usuario, estado, creadaEn },
        select: { id: true },
      });

    beforeAll(async () => {
      prisma = new PrismaClient({
        adapter: new PrismaPg({
          connectionString: process.env.DATABASE_URL!,
        }),
      });
      await prisma.$connect();
      repository = new SolicitudVerificacionRepository(
        prisma as unknown as PrismaService,
      );

      const sufijo = randomUUID().replaceAll('-', '').slice(0, 10);
      const crearUsuario = (prefijo: string) =>
        prisma.usuario.create({
          data: {
            nombreUsuario: `${prefijo}_${sufijo}`,
            email: `${prefijo}_${sufijo}@example.com`,
            passwordHash: 'hash-prueba',
            rol: Rol.ARRENDATARIO,
          },
        });
      usuarioId = (await crearUsuario('verif_est')).id;
      otroId = (await crearUsuario('verif_est_otro')).id;
    });

    beforeEach(async () => {
      await prisma.solicitudVerificacion.deleteMany({
        where: { usuarioId: { in: [usuarioId, otroId] } },
      });
    });

    afterAll(async () => {
      try {
        const ids = [usuarioId, otroId].filter(Boolean);
        if (ids.length > 0) {
          await prisma.solicitudVerificacion.deleteMany({
            where: { usuarioId: { in: ids } },
          });
          await prisma.usuario.deleteMany({ where: { id: { in: ids } } });
        }
      } finally {
        await prisma?.$disconnect();
      }
    });

    it('sin solicitudes devuelve null', async () => {
      await expect(repository.findUltimaDeUsuario(usuarioId)).resolves.toBe(
        null,
      );
    });

    it('devuelve la más reciente por creadaEn, sin importar el orden de inserción', async () => {
      const reciente = await crearSolicitud(
        usuarioId,
        'RECHAZADA',
        new Date('2026-11-16T12:00:00.000Z'),
      );
      await crearSolicitud(
        usuarioId,
        'APROBADA',
        new Date('2026-11-10T12:00:00.000Z'),
      );

      await expect(
        repository.findUltimaDeUsuario(usuarioId),
      ).resolves.toMatchObject({ id: reciente.id, estado: 'RECHAZADA' });
    });

    it('con la misma creadaEn desempata por id de forma determinista', async () => {
      const mismaFecha = new Date('2026-11-16T12:00:00.000Z');
      const a = await crearSolicitud(usuarioId, 'APROBADA', mismaFecha);
      const b = await crearSolicitud(usuarioId, 'RECHAZADA', mismaFecha);
      // PostgreSQL ordena los uuid como su texto en minúsculas.
      const esperado = [a.id, b.id].sort((x, y) => (x < y ? -1 : 1)).at(-1);

      for (let i = 0; i < 3; i++) {
        await expect(
          repository.findUltimaDeUsuario(usuarioId),
        ).resolves.toMatchObject({ id: esperado });
      }
    });

    it('no mira las solicitudes de otro usuario', async () => {
      await crearSolicitud(
        otroId,
        'APROBADA',
        new Date('2026-11-16T12:00:00.000Z'),
      );

      await expect(repository.findUltimaDeUsuario(usuarioId)).resolves.toBe(
        null,
      );
    });
  },
);
