import { Prisma } from '@PrismaClient';
import type { PrismaService } from '@Prisma/services';
import { PoliticaVerificacionRepository } from './politica-verificacion.repository.js';

const BIEN_ID = '7c9e6679-7425-40de-944b-e07fc1f90ae7';
const DUENO = '29bda5e8-e0c8-4ec2-bc7f-94c41c3c0140';

function crear() {
  const prisma = {
    bien: { findUnique: vi.fn() },
    politicaVerificacionBien: {
      upsert: vi.fn((args: { create: object }) => Promise.resolve(args.create)),
      findUnique: vi.fn().mockResolvedValue(null),
    },
  };
  const repository = new PoliticaVerificacionRepository(
    prisma as unknown as PrismaService,
  );
  return { repository, prisma };
}

function errorPrisma(code: string) {
  return new Prisma.PrismaClientKnownRequestError('fallo', {
    code,
    clientVersion: 'test',
  });
}

describe('PoliticaVerificacionRepository.soloVerificados', () => {
  it('sin registro de política devuelve false', async () => {
    const { repository, prisma } = crear();

    await expect(repository.soloVerificados(BIEN_ID)).resolves.toBe(false);
    expect(prisma.politicaVerificacionBien.findUnique).toHaveBeenCalledWith({
      where: { bienId: BIEN_ID },
      select: { soloVerificados: true },
    });
  });

  it.each([true, false])('devuelve el valor guardado (%s)', async (valor) => {
    const { repository, prisma } = crear();
    prisma.politicaVerificacionBien.findUnique.mockResolvedValue({
      soloVerificados: valor,
    });

    await expect(repository.soloVerificados(BIEN_ID)).resolves.toBe(valor);
  });

  it('con un cliente de transacción, lee con ese cliente y no con el pool', async () => {
    const { repository, prisma } = crear();
    const tx = {
      politicaVerificacionBien: {
        findUnique: vi.fn().mockResolvedValue({ soloVerificados: true }),
      },
    };

    await expect(
      repository.soloVerificados(
        BIEN_ID,
        tx as unknown as Prisma.TransactionClient,
      ),
    ).resolves.toBe(true);
    expect(tx.politicaVerificacionBien.findUnique).toHaveBeenCalledTimes(1);
    expect(prisma.politicaVerificacionBien.findUnique).not.toHaveBeenCalled();
  });

  it('propaga un error inesperado', async () => {
    const { repository, prisma } = crear();
    const fallo = errorPrisma('P1001');
    prisma.politicaVerificacionBien.findUnique.mockRejectedValue(fallo);

    await expect(repository.soloVerificados(BIEN_ID)).rejects.toBe(fallo);
  });
});

describe('PoliticaVerificacionRepository.findBien', () => {
  it('lee solo el dueño y la política, sin filtrar por estado del bien', async () => {
    const { repository, prisma } = crear();
    prisma.bien.findUnique.mockResolvedValue(null);

    await repository.findBien(BIEN_ID);

    expect(prisma.bien.findUnique).toHaveBeenCalledWith({
      where: { id: BIEN_ID },
      select: {
        arrendadorId: true,
        politicaVerificacion: { select: { soloVerificados: true } },
      },
    });
  });

  it('devuelve null si el bien no existe', async () => {
    const { repository, prisma } = crear();
    prisma.bien.findUnique.mockResolvedValue(null);

    await expect(repository.findBien(BIEN_ID)).resolves.toBeNull();
  });

  it('sin registro de política, soloVerificados es false', async () => {
    const { repository, prisma } = crear();
    prisma.bien.findUnique.mockResolvedValue({
      arrendadorId: DUENO,
      politicaVerificacion: null,
    });

    await expect(repository.findBien(BIEN_ID)).resolves.toEqual({
      arrendadorId: DUENO,
      soloVerificados: false,
    });
  });

  it('con registro, devuelve el valor guardado', async () => {
    const { repository, prisma } = crear();
    prisma.bien.findUnique.mockResolvedValue({
      arrendadorId: DUENO,
      politicaVerificacion: { soloVerificados: true },
    });

    await expect(repository.findBien(BIEN_ID)).resolves.toEqual({
      arrendadorId: DUENO,
      soloVerificados: true,
    });
  });
});

describe('PoliticaVerificacionRepository.guardar', () => {
  it('hace upsert por bienId: crea si no existe y actualiza si existe', async () => {
    const { repository, prisma } = crear();

    await expect(repository.guardar(BIEN_ID, true)).resolves.toEqual({
      bienId: BIEN_ID,
      soloVerificados: true,
    });
    expect(prisma.politicaVerificacionBien.upsert).toHaveBeenCalledWith({
      where: { bienId: BIEN_ID },
      create: { bienId: BIEN_ID, soloVerificados: true },
      update: { soloVerificados: true },
      select: { bienId: true, soloVerificados: true },
    });
  });

  it('devuelve null si la FK rechaza el bien (dejó de existir)', async () => {
    const { repository, prisma } = crear();
    prisma.politicaVerificacionBien.upsert.mockRejectedValue(
      errorPrisma('P2003'),
    );

    await expect(repository.guardar(BIEN_ID, false)).resolves.toBeNull();
  });

  it('propaga cualquier otro error', async () => {
    const { repository, prisma } = crear();
    const fallo = errorPrisma('P1001');
    prisma.politicaVerificacionBien.upsert.mockRejectedValue(fallo);

    await expect(repository.guardar(BIEN_ID, false)).rejects.toBe(fallo);
  });
});
