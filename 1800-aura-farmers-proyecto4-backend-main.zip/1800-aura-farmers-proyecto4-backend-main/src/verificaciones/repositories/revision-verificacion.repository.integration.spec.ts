import { randomUUID } from 'node:crypto';
import { Logger } from '@nestjs/common';
import { PrismaPg } from '@prisma/adapter-pg';
import { PrismaClient, Rol } from '@PrismaClient';
import type { PrismaService } from '@Prisma/services';
import { NotificacionesRepository } from '@Notificaciones/repositories';
import { NotificacionesService } from '@Notificaciones/services';
import { RevisionSimuladaService } from '@Verificaciones/services';
import {
  RevisionVerificacionRepository,
  esZonaUtc,
} from './revision-verificacion.repository.js';
import { SolicitudVerificacionRepository } from './solicitud-verificacion.repository.js';

const habilitada = process.env.RUN_DB_INTEGRATION === '1';

if (habilitada && !process.env.DATABASE_URL) {
  throw new Error('RUN_DB_INTEGRATION=1 requiere DATABASE_URL configurada.');
}

/**
 * BE-18.1 contra PostgreSQL: la espera mínima medida con el reloj de la base,
 * la transacción, el bloqueo con SKIP LOCKED, la actualización condicional y
 * el aviso único.
 *
 * Las solicitudes se crean por el flujo real (`crearConDocumento` de BE-17.1),
 * que guarda `creada_en` como lo hace la API, y se envejecen restándole
 * segundos al valor guardado (`creada_en = creada_en - <segundos>`). El
 * procesador toma cualquier solicitud EN_REVISION con 10 segundos o más; las
 * de otras pruebas que corren a la vez son recién creadas y no llegan a esa
 * edad. La base de pruebas debe estar en UTC.
 */
describe.skipIf(!habilitada)(
  'BE-18.1 - Revisión simulada con PostgreSQL',
  () => {
    let prisma: PrismaClient;
    let prismaOtro: PrismaClient;
    let usuarios: string[] = [];
    const sufijo = randomUUID().replaceAll('-', '').slice(0, 10);

    const nuevoCliente = (connectionString = process.env.DATABASE_URL!) =>
      new PrismaClient({ adapter: new PrismaPg({ connectionString }) });

    /** La misma base, pero con la sesión en otra zona horaria (`options` de libpq). */
    const urlConZona = (zona: string) => {
      const url = new URL(process.env.DATABASE_URL!);
      url.searchParams.set('options', `-c TimeZone=${zona}`);
      return url.toString();
    };

    /** Un procesador completo: repositorio, Módulo 8 real y servicio. */
    const procesador = (cliente: PrismaClient) => {
      const db = cliente as unknown as PrismaService;
      const repository = new RevisionVerificacionRepository(db);
      const service = new RevisionSimuladaService(
        repository,
        new NotificacionesService(new NotificacionesRepository(db)),
      );
      return { repository, service };
    };

    /** Crea `n` usuarios nuevos: una solicitud EN_REVISION por usuario. */
    const crearUsuarios = async (n: number) => {
      const datos = Array.from({ length: n }, () => {
        const id = randomUUID();
        const corto = id.slice(0, 8);
        return {
          id,
          nombreUsuario: `verif_rev_${sufijo}_${corto}`,
          email: `verif_rev_${sufijo}_${corto}@example.com`,
          passwordHash: 'hash-prueba',
          rol: Rol.ARRENDATARIO,
        };
      });
      await prisma.usuario.createMany({ data: datos });
      usuarios.push(...datos.map((u) => u.id));
      return datos.map((u) => u.id);
    };

    /** Resta `segundos` al `creada_en` guardado, sin reemplazarlo. */
    const envejecer = (id: string, segundos: number) =>
      prisma.$executeRaw`
      UPDATE "SolicitudesVerificacion"
      SET creada_en = creada_en - make_interval(secs => ${segundos}::double precision)
      WHERE id = ${id}::uuid`;

    /**
     * Solicitud EN_REVISION creada como la crea la API (con documento, por
     * `crearConDocumento`), envejecida `antiguedadSegundos`. Sin documento no
     * hay flujo real que la cree, así que se inserta directamente.
     */
    const crearSolicitud = async (
      usuarioId: string,
      antiguedadSegundos: number,
      nombreArchivo: string | null = 'cedula.jpg',
    ) => {
      let id: string;
      if (nombreArchivo === null) {
        ({ id } = await prisma.solicitudVerificacion.create({
          data: { usuarioId },
          select: { id: true },
        }));
      } else {
        const contenido = Buffer.from([0xff, 0xd8, 0xff, 0xe0]);
        const resultado = await new SolicitudVerificacionRepository(
          prisma as unknown as PrismaService,
        ).crearConDocumento(usuarioId, {
          nombreArchivo,
          contenido,
          mimeType: 'image/jpeg',
          tamanoBytes: contenido.length,
        });
        if (!('solicitud' in resultado)) {
          throw new Error('No se pudo crear la solicitud de prueba.');
        }
        id = resultado.solicitud.id;
      }
      if (antiguedadSegundos > 0) await envejecer(id, antiguedadSegundos);
      return { id };
    };

    const solicitud = (id: string) =>
      prisma.solicitudVerificacion.findUniqueOrThrow({
        where: { id },
        select: { estado: true, motivo: true, revisadoEn: true },
      });

    const avisosDe = (solicitudIds: string[]) =>
      prisma.notificacion.findMany({
        where: {
          tipoReferencia: 'SOLICITUD_VERIFICACION',
          referenciaId: { in: solicitudIds },
        },
      });

    beforeAll(async () => {
      prisma = nuevoCliente();
      prismaOtro = nuevoCliente();
      await prisma.$connect();
      await prismaOtro.$connect();
      const [{ zona }] = await prisma.$queryRaw<
        { zona: string }[]
      >`SELECT current_setting('TimeZone') AS zona`;
      if (!esZonaUtc(zona)) {
        throw new Error(
          `La base de pruebas está en "${zona}": estas pruebas requieren PostgreSQL en UTC.`,
        );
      }
    });

    beforeEach(() => {
      vi.spyOn(Logger.prototype, 'warn').mockImplementation(() => undefined);
      vi.spyOn(Logger.prototype, 'error').mockImplementation(() => undefined);
    });

    afterEach(async () => {
      vi.restoreAllMocks();
      if (usuarios.length > 0) {
        await prisma.notificacion.deleteMany({
          where: { destinatarioId: { in: usuarios } },
        });
        await prisma.solicitudVerificacion.deleteMany({
          where: { usuarioId: { in: usuarios } },
        });
        await prisma.usuario.deleteMany({ where: { id: { in: usuarios } } });
      }
      usuarios = [];
    });

    afterAll(async () => {
      await prisma?.$disconnect();
      await prismaOtro?.$disconnect();
    });

    it('una solicitud recién creada por el flujo real no se revisa; envejecida 11 s, sí', async () => {
      const [u] = await crearUsuarios(1);
      const { id } = await crearSolicitud(u!, 0);
      const { service } = procesador(prisma);

      await service.procesarPendientes();
      expect((await solicitud(id)).estado).toBe('EN_REVISION');

      await envejecer(id, 11);
      await service.procesarPendientes();
      expect((await solicitud(id)).estado).toBe('APROBADA');
    });

    it('con 8 segundos todavía no se revisa; al pasar de 10, sí', async () => {
      const [u] = await crearUsuarios(1);
      const { id } = await crearSolicitud(u!, 8);
      const { service } = procesador(prisma);

      await service.procesarPendientes();
      expect((await solicitud(id)).estado).toBe('EN_REVISION');

      await envejecer(id, 2);
      await service.procesarPendientes();
      expect((await solicitud(id)).estado).toBe('APROBADA');
    });

    it('si la sesión de PostgreSQL no está en UTC, no procesa nada y registra un error claro', async () => {
      const [u] = await crearUsuarios(1);
      const { id } = await crearSolicitud(u!, 60);
      const clienteGuatemala = nuevoCliente(urlConZona('America/Guatemala'));
      const error = vi.spyOn(Logger.prototype, 'error');

      try {
        const [{ zona }] = await clienteGuatemala.$queryRaw<
          { zona: string }[]
        >`SELECT current_setting('TimeZone') AS zona`;
        expect(zona).toBe('America/Guatemala');

        await expect(
          procesador(clienteGuatemala).service.procesarPendientes(),
        ).resolves.toEqual({ resueltas: 0, sinDocumento: 0 });
      } finally {
        await clienteGuatemala.$disconnect();
      }

      expect(await solicitud(id)).toEqual({
        estado: 'EN_REVISION',
        motivo: null,
        revisadoEn: null,
      });
      expect(await avisosDe([id])).toHaveLength(0);
      expect(error).toHaveBeenCalledWith(
        expect.stringContaining(
          'La sesión de PostgreSQL usa la zona horaria "America/Guatemala" y la revisión simulada de documentos requiere UTC',
        ),
      );

      // Con la sesión en UTC, la misma solicitud sí se revisa.
      await procesador(prisma).service.procesarPendientes();
      expect((await solicitud(id)).estado).toBe('APROBADA');
    });

    it('un reloj adelantado en la aplicación no adelanta la revisión', async () => {
      const [u] = await crearUsuarios(1);
      const { id } = await crearSolicitud(u!, 0);
      const { service } = procesador(prisma);

      // Una hora adelante: con el reloj de la aplicación, ya habría pasado la espera.
      await expect(
        service.procesarPendientes(new Date(Date.now() + 3_600_000)),
      ).resolves.toEqual({ resueltas: 0, sinDocumento: 0 });

      expect((await solicitud(id)).estado).toBe('EN_REVISION');
      expect(await avisosDe([id])).toHaveLength(0);
    });

    it('aprueba cedula.jpg y rechaza rechazar_1.png, guardando revisadoEn y avisando', async () => {
      const [u1, u2] = await crearUsuarios(2);
      const aprobada = await crearSolicitud(u1!, 15, 'cedula.jpg');
      const rechazada = await crearSolicitud(u2!, 15, 'rechazar_1.png');
      const { service } = procesador(prisma);
      const ahora = new Date();

      await expect(service.procesarPendientes(ahora)).resolves.toEqual({
        resueltas: 2,
        sinDocumento: 0,
      });

      expect(await solicitud(aprobada.id)).toEqual({
        estado: 'APROBADA',
        motivo: null,
        revisadoEn: ahora,
      });
      expect(await solicitud(rechazada.id)).toEqual({
        estado: 'RECHAZADA',
        motivo: 'Documento no válido (revisión simulada).',
        revisadoEn: ahora,
      });

      const avisos = await avisosDe([aprobada.id, rechazada.id]);
      expect(avisos).toHaveLength(2);
      expect(avisos.find((a) => a.referenciaId === aprobada.id)).toMatchObject({
        destinatarioId: u1,
        titulo: 'Resultado de tu verificación',
        mensaje: 'Tu documento fue aprobado. Ya estás verificado.',
        moduloOrigen: 'VERIFICACION',
        estado: 'NO_LEIDA',
      });
      expect(avisos.find((a) => a.referenciaId === rechazada.id)).toMatchObject(
        {
          destinatarioId: u2,
          mensaje:
            'Tu documento fue rechazado: Documento no válido (revisión simulada).',
        },
      );
    });

    it('una segunda ejecución no cambia el resultado, ni revisadoEn, ni crea otro aviso', async () => {
      const [u] = await crearUsuarios(1);
      const { id } = await crearSolicitud(u!, 15, 'rechazar_1.png');
      const { service } = procesador(prisma);

      await service.procesarPendientes();
      const despuesDeLaPrimera = await solicitud(id);
      await expect(
        service.procesarPendientes(new Date(Date.now() + 60_000)),
      ).resolves.toEqual({ resueltas: 0, sinDocumento: 0 });

      expect(await solicitud(id)).toEqual(despuesDeLaPrimera);
      expect(await avisosDe([id])).toHaveLength(1);
    });

    it('dos procesadores a la vez resuelven cada solicitud una sola vez, con un solo aviso', async () => {
      const ids = await crearUsuarios(30);
      const solicitudes = await Promise.all(
        ids.map((u, i) =>
          crearSolicitud(u, 15, i % 3 === 0 ? 'rechazar.png' : 'cedula.jpg'),
        ),
      );
      const a = procesador(prisma);
      const b = procesador(prismaOtro);

      const [ra, rb] = await Promise.all([
        a.service.procesarPendientes(),
        b.service.procesarPendientes(),
      ]);

      expect(ra.resueltas + rb.resueltas).toBe(30);
      const pendientes = await prisma.solicitudVerificacion.count({
        where: { usuarioId: { in: ids }, estado: 'EN_REVISION' },
      });
      expect(pendientes).toBe(0);
      const avisos = await avisosDe(solicitudes.map((s) => s.id));
      expect(avisos).toHaveLength(30);
      expect(new Set(avisos.map((x) => x.referenciaId)).size).toBe(30);
    });

    it('SKIP LOCKED: una fila bloqueada por otra transacción se salta sin esperar', async () => {
      const [u1, u2] = await crearUsuarios(2);
      const bloqueada = await crearSolicitud(u1!, 15);
      const libre = await crearSolicitud(u2!, 15);
      const { service } = procesador(prisma);

      let liberar!: () => void;
      const soltar = new Promise<void>((resolve) => (liberar = resolve));
      let avisarBloqueo!: () => void;
      const bloqueoTomado = new Promise<void>((r) => (avisarBloqueo = r));
      const transaccionAjena = prismaOtro.$transaction(
        async (tx) => {
          await tx.$executeRaw`SELECT 1 FROM "SolicitudesVerificacion" WHERE id = ${bloqueada.id}::uuid FOR UPDATE`;
          avisarBloqueo();
          await soltar;
        },
        { timeout: 20_000 },
      );

      try {
        await bloqueoTomado;
        const inicio = Date.now();
        await service.procesarPendientes();

        expect(Date.now() - inicio).toBeLessThan(5_000);
        expect((await solicitud(bloqueada.id)).estado).toBe('EN_REVISION');
        expect((await solicitud(libre.id)).estado).toBe('APROBADA');
      } finally {
        liberar();
        await transaccionAjena;
      }

      // Liberada la fila, la siguiente corrida la resuelve.
      await service.procesarPendientes();
      expect((await solicitud(bloqueada.id)).estado).toBe('APROBADA');
    });

    it('procesa en lotes de 20 hasta vaciar lo pendiente', async () => {
      const ids = await crearUsuarios(45);
      await Promise.all(ids.map((u, i) => crearSolicitud(u, 60 - i / 10)));
      const { repository, service } = procesador(prisma);
      const lotes = vi.spyOn(repository, 'resolverLote');

      await expect(service.procesarPendientes()).resolves.toEqual({
        resueltas: 45,
        sinDocumento: 0,
      });

      expect(lotes).toHaveBeenCalledTimes(3);
      expect(
        await prisma.solicitudVerificacion.count({
          where: { usuarioId: { in: ids }, estado: 'APROBADA' },
        }),
      ).toBe(45);
    });

    it('una solicitud sin documento queda EN_REVISION y no bloquea las demás', async () => {
      const ids = await crearUsuarios(22);
      // La más antigua no tiene documento: aparecería primera en cada lote.
      const sinDocumento = await crearSolicitud(ids[0]!, 60, null);
      await Promise.all(
        ids.slice(1).map((u, i) => crearSolicitud(u, 50 - i / 10)),
      );
      const { service } = procesador(prisma);

      await expect(service.procesarPendientes()).resolves.toEqual({
        resueltas: 21,
        sinDocumento: 1,
      });

      expect(await solicitud(sinDocumento.id)).toEqual({
        estado: 'EN_REVISION',
        motivo: null,
        revisadoEn: null,
      });
      expect(await avisosDe([sinDocumento.id])).toHaveLength(0);
    });

    it('si falla el servicio de avisos, la solicitud queda resuelta', async () => {
      const [u] = await crearUsuarios(1);
      const { id } = await crearSolicitud(u!, 15);
      const service = new RevisionSimuladaService(
        new RevisionVerificacionRepository(prisma as unknown as PrismaService),
        {
          crear: () => Promise.reject(new Error('avisos caídos')),
        } as unknown as NotificacionesService,
      );

      await expect(service.procesarPendientes()).resolves.toEqual({
        resueltas: 1,
        sinDocumento: 0,
      });

      expect((await solicitud(id)).estado).toBe('APROBADA');
      expect(await avisosDe([id])).toHaveLength(0);
    });

    describe('conciliación de avisos (avisos que no llegaron a crearse)', () => {
      const MINUTO = 60;
      const DIA = 24 * 60 * MINUTO;

      /** Resta segundos a `revisado_en`: una resolución más antigua. */
      const envejecerResolucion = (ids: string[], segundos: number) =>
        prisma.$executeRaw`
          UPDATE "SolicitudesVerificacion"
          SET revisado_en = revisado_en - make_interval(secs => ${segundos}::double precision)
          WHERE id = ANY(${ids}::uuid[])`;

      /**
       * Una caída entre el commit del lote y el aviso: resuelve las
       * pendientes sin pedir ningún aviso.
       */
      const resolverSinAvisar = (cliente: PrismaClient = prisma) =>
        new RevisionVerificacionRepository(
          cliente as unknown as PrismaService,
        ).resolverLote({ revisadoEn: new Date(), excluir: [], lote: 100 });

      /**
       * Módulo 8 real, pero que falla para los destinatarios indicados y
       * registra a quién se le pidió un aviso.
       */
      const avisosControlados = (
        cliente: PrismaClient,
        fallaPara: (destinatarioId: string) => boolean = () => false,
      ) => {
        const real = new NotificacionesService(
          new NotificacionesRepository(cliente as unknown as PrismaService),
        );
        const pedidos: string[] = [];
        const servicio = {
          crear: (destinatarioId: string, ...resto: unknown[]) => {
            pedidos.push(destinatarioId);
            if (fallaPara(destinatarioId)) {
              return Promise.reject(new Error('Módulo 8 caído'));
            }
            return (
              real.crear as unknown as (...args: unknown[]) => Promise<unknown>
            )(destinatarioId, ...resto);
          },
        } as unknown as NotificacionesService;
        return { servicio, pedidos };
      };

      const procesadorCon = (
        cliente: PrismaClient,
        avisos: NotificacionesService,
      ) =>
        new RevisionSimuladaService(
          new RevisionVerificacionRepository(
            cliente as unknown as PrismaService,
          ),
          avisos,
        );

      const contenido = async (id: string) => {
        const [aviso] = await avisosDe([id]);
        return {
          titulo: aviso!.titulo,
          mensaje: aviso!.mensaje,
          moduloOrigen: aviso!.moduloOrigen,
          tipoReferencia: aviso!.tipoReferencia,
        };
      };

      it('caída entre el commit y el aviso: la siguiente corrida lo crea, aunque la resolución sea muy antigua, sin cambiar el estado', async () => {
        const [u] = await crearUsuarios(1);
        const { id } = await crearSolicitud(u!, 15);
        await resolverSinAvisar();
        expect(await avisosDe([id])).toHaveLength(0);
        await envejecerResolucion([id], 30 * DIA);
        const antes = await solicitud(id);

        await procesador(prisma).service.procesarPendientes();

        const avisos = await avisosDe([id]);
        expect(avisos).toHaveLength(1);
        expect(avisos[0]!.destinatarioId).toBe(u);
        // La conciliación no cambia el resultado ni la fecha de la revisión.
        expect(await solicitud(id)).toEqual(antes);
        expect(antes.estado).toBe('APROBADA');
      });

      it('una resolución reciente no se concilia todavía: espera la gracia de un minuto', async () => {
        const [u] = await crearUsuarios(1);
        const { id } = await crearSolicitud(u!, 15);
        await resolverSinAvisar();

        await procesador(prisma).service.procesarPendientes();
        expect(await avisosDe([id])).toHaveLength(0);

        await envejecerResolucion([id], MINUTO + 1);
        await procesador(prisma).service.procesarPendientes();
        expect(await avisosDe([id])).toHaveLength(1);
      });

      it('un fallo pasajero se recupera, con el mismo título, mensaje y módulo que el aviso original', async () => {
        const [a1, a2, r1, r2] = await crearUsuarios(4);
        const aprobadaNormal = await crearSolicitud(a1!, 15);
        const aprobadaFallida = await crearSolicitud(a2!, 15);
        const rechazadaNormal = await crearSolicitud(r1!, 15, 'rechazar_1.png');
        const rechazadaFallida = await crearSolicitud(
          r2!,
          15,
          'rechazar_1.png',
        );
        const caido = avisosControlados(
          prisma,
          (destinatario) => destinatario === a2 || destinatario === r2,
        );

        await procesadorCon(prisma, caido.servicio).procesarPendientes();
        expect(
          await avisosDe([aprobadaFallida.id, rechazadaFallida.id]),
        ).toHaveLength(0);

        await envejecerResolucion(
          [aprobadaFallida.id, rechazadaFallida.id],
          2 * MINUTO,
        );
        await procesador(prisma).service.procesarPendientes();

        expect(await contenido(aprobadaFallida.id)).toEqual(
          await contenido(aprobadaNormal.id),
        );
        expect(await contenido(rechazadaFallida.id)).toEqual(
          await contenido(rechazadaNormal.id),
        );
        expect((await contenido(rechazadaFallida.id)).mensaje).toContain(
          'rechazado',
        );
      });

      it('no duplica un aviso que ya existe', async () => {
        const [u] = await crearUsuarios(1);
        const { id } = await crearSolicitud(u!, 15);
        await procesador(prisma).service.procesarPendientes();
        await envejecerResolucion([id], 2 * MINUTO);

        await procesador(prisma).service.procesarPendientes();
        await procesador(prisma).service.procesarPendientes();

        expect(await avisosDe([id])).toHaveLength(1);
      });

      it('dos procesadores conciliando a la vez generan un solo aviso', async () => {
        const [u] = await crearUsuarios(1);
        const { id } = await crearSolicitud(u!, 15);
        await resolverSinAvisar();
        await envejecerResolucion([id], 2 * MINUTO);

        await Promise.all([
          procesador(prisma).service.procesarPendientes(),
          procesador(prismaOtro).service.procesarPendientes(),
        ]);

        expect(await avisosDe([id])).toHaveLength(1);
      });

      it('recupera como máximo 20 por corrida, las más antiguas primero', async () => {
        const ids = await crearUsuarios(25);
        const solicitudes: string[] = [];
        for (const u of ids) solicitudes.push((await crearSolicitud(u, 15)).id);
        await resolverSinAvisar();
        // Muy antiguas, para que sean las primeras de la conciliación.
        await envejecerResolucion(solicitudes, 1000 * DIA);

        await procesador(prisma).service.procesarPendientes();
        expect(await avisosDe(solicitudes)).toHaveLength(20);

        await procesador(prisma).service.procesarPendientes();
        expect(await avisosDe(solicitudes)).toHaveLength(25);
      });

      it('un aviso que falla no detiene los demás', async () => {
        const [u1, u2, u3] = await crearUsuarios(3);
        const s1 = await crearSolicitud(u1!, 15);
        const s2 = await crearSolicitud(u2!, 15);
        const s3 = await crearSolicitud(u3!, 15);
        await resolverSinAvisar();
        await envejecerResolucion([s1.id, s2.id, s3.id], 2 * MINUTO);
        const caido = avisosControlados(
          prisma,
          (destinatario) => destinatario === u2,
        );

        await procesadorCon(prisma, caido.servicio).procesarPendientes();

        expect(await avisosDe([s1.id])).toHaveLength(1);
        expect(await avisosDe([s2.id])).toHaveLength(0);
        expect(await avisosDe([s3.id])).toHaveLength(1);
        expect(caido.pedidos).toContain(u2);
      });

      it('no avisa ni intenta avisar a un usuario inactivo', async () => {
        const [u] = await crearUsuarios(1);
        const { id } = await crearSolicitud(u!, 15);
        await resolverSinAvisar();
        await envejecerResolucion([id], 2 * MINUTO);
        await prisma.usuario.update({
          where: { id: u! },
          data: { isActive: false },
        });
        const registro = avisosControlados(prisma);

        await procesadorCon(prisma, registro.servicio).procesarPendientes();

        expect(registro.pedidos).not.toContain(u);
        expect(await avisosDe([id])).toHaveLength(0);
      });

      it('no concilia un rechazo con un motivo ajeno a la revisión simulada; sí los rechazos simulados y las aprobadas', async () => {
        const [ajeno, simulado, aprobado] = await crearUsuarios(3);
        const sAjena = await crearSolicitud(ajeno!, 0);
        const sSimulada = await crearSolicitud(simulado!, 15, 'rechazar_1.png');
        const sAprobada = await crearSolicitud(aprobado!, 15);
        await resolverSinAvisar();
        // Un rechazo que no escribió este procesador (otro motivo).
        await prisma.solicitudVerificacion.update({
          where: { id: sAjena.id },
          data: {
            estado: 'RECHAZADA',
            motivo: 'Rechazada manualmente por un administrador.',
            revisadoEn: new Date(),
          },
        });
        const todas = [sAjena.id, sSimulada.id, sAprobada.id];
        await envejecerResolucion(todas, 2 * MINUTO);
        const repositorio = new RevisionVerificacionRepository(
          prisma as unknown as PrismaService,
        );
        const ajenas = await prisma.solicitudVerificacion.findMany({
          where: { id: { notIn: todas } },
          select: { id: true },
        });

        const pendientes = await repositorio.avisosPendientes({
          excluir: ajenas.map((fila) => fila.id),
          lote: 100,
        });

        expect(pendientes.map((p) => p.id).sort()).toEqual(
          [sSimulada.id, sAprobada.id].sort(),
        );
        const antes = await solicitud(sAjena.id);
        await procesador(prisma).service.procesarPendientes();
        expect(await avisosDe([sAjena.id])).toHaveLength(0);
        expect(await avisosDe([sSimulada.id])).toHaveLength(1);
        expect(await avisosDe([sAprobada.id])).toHaveLength(1);
        // El rechazo ajeno queda como estaba.
        expect(await solicitud(sAjena.id)).toEqual(antes);
      });

      it('en la misma corrida resuelve y avisa lo nuevo, y recupera lo perdido', async () => {
        const [perdido, nuevo] = await crearUsuarios(2);
        const sPerdida = await crearSolicitud(perdido!, 15);
        await resolverSinAvisar();
        await envejecerResolucion([sPerdida.id], 2 * MINUTO);
        const sNueva = await crearSolicitud(nuevo!, 15);

        await expect(
          procesador(prisma).service.procesarPendientes(),
        ).resolves.toEqual({ resueltas: 1, sinDocumento: 0 });

        expect((await solicitud(sNueva.id)).estado).toBe('APROBADA');
        expect(await avisosDe([sNueva.id])).toHaveLength(1);
        expect(await avisosDe([sPerdida.id])).toHaveLength(1);
      });
    });
  },
);
