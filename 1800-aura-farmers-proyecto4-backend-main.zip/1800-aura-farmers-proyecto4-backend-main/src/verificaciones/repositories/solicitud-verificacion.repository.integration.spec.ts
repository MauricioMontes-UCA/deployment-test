import { randomUUID } from 'node:crypto';
import { PrismaPg } from '@prisma/adapter-pg';
import { EstadoSolicitudVerificacion, PrismaClient, Rol } from '@PrismaClient';
import type { PrismaService } from '@Prisma/services';
import { MAX_DOCUMENTO_BYTES } from '@Verificaciones/constants';
import type { DocumentoSubido } from '@Verificaciones/types';
import { SolicitudVerificacionRepository } from './solicitud-verificacion.repository.js';

const habilitada = process.env.RUN_DB_INTEGRATION === '1';

if (habilitada && !process.env.DATABASE_URL) {
  throw new Error('RUN_DB_INTEGRATION=1 requiere DATABASE_URL configurada.');
}

/**
 * BE-17.1 contra PostgreSQL: las garantías que da la base y no se pueden
 * probar con dobles (el índice único parcial y la transacción del create
 * anidado).
 */
describe.skipIf(!habilitada)('BE-17.1 - Integración con PostgreSQL', () => {
  let prisma: PrismaClient;
  let repository: SolicitudVerificacionRepository;
  let usuarioId = '';

  const documento = (n = 0): DocumentoSubido => {
    const contenido = Buffer.concat([
      Buffer.from([0xff, 0xd8, 0xff, 0xe0]),
      Buffer.alloc(256 + n, 0x33),
    ]);
    return {
      nombreArchivo: `dui-${n}.jpg`,
      contenido,
      mimeType: 'image/jpeg',
      tamanoBytes: contenido.length,
    };
  };

  const contar = async () => ({
    solicitudes: await prisma.solicitudVerificacion.count({
      where: { usuarioId },
    }),
    documentos: await prisma.documentoVerificacion.count({
      where: { solicitud: { usuarioId } },
    }),
  });

  beforeAll(async () => {
    prisma = new PrismaClient({
      adapter: new PrismaPg({ connectionString: process.env.DATABASE_URL! }),
    });
    await prisma.$connect();
    repository = new SolicitudVerificacionRepository(
      prisma as unknown as PrismaService,
    );

    const sufijo = randomUUID().replaceAll('-', '').slice(0, 10);
    const usuario = await prisma.usuario.create({
      data: {
        nombreUsuario: `verif_int_${sufijo}`,
        email: `verif_int_${sufijo}@example.com`,
        passwordHash: 'hash-prueba',
        rol: Rol.ARRENDATARIO,
      },
    });
    usuarioId = usuario.id;
  });

  beforeEach(async () => {
    await prisma.solicitudVerificacion.deleteMany({ where: { usuarioId } });
  });

  afterAll(async () => {
    try {
      if (usuarioId) {
        await prisma.solicitudVerificacion.deleteMany({ where: { usuarioId } });
        await prisma.usuario.delete({ where: { id: usuarioId } });
      }
    } finally {
      await prisma?.$disconnect();
    }
  });

  it('de varios intentos simultáneos solo uno crea la solicitud EN_REVISION', async () => {
    const resultados = await Promise.all(
      Array.from({ length: 10 }, (_, i) =>
        repository.crearConDocumento(usuarioId, documento(i)),
      ),
    );

    expect(resultados.filter((r) => 'solicitud' in r)).toHaveLength(1);
    expect(resultados.filter((r) => 'rechazo' in r)).toHaveLength(9);
    expect(await contar()).toEqual({ solicitudes: 1, documentos: 1 });
  });

  it('si la base rechaza el documento, la solicitud no queda', async () => {
    await expect(
      repository.crearConDocumento(usuarioId, {
        ...documento(),
        tamanoBytes: MAX_DOCUMENTO_BYTES + 1,
      }),
    ).rejects.toThrow();

    expect(await contar()).toEqual({ solicitudes: 0, documentos: 0 });
  });

  it.each([
    EstadoSolicitudVerificacion.APROBADA,
    EstadoSolicitudVerificacion.RECHAZADA,
  ])('permite una nueva solicitud después de una %s', async (estado) => {
    const primera = await repository.crearConDocumento(usuarioId, documento());
    if (!('solicitud' in primera)) throw new Error('No se creó la primera.');
    await prisma.solicitudVerificacion.update({
      where: { id: primera.solicitud.id },
      data: { estado, revisadoEn: new Date() },
    });

    const segunda = await repository.crearConDocumento(usuarioId, documento(1));

    expect('solicitud' in segunda).toBe(true);
    expect(await contar()).toEqual({ solicitudes: 2, documentos: 2 });
  });
});
