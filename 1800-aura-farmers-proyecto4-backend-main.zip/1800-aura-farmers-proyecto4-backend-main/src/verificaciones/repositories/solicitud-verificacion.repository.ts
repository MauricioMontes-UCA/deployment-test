import { Injectable } from '@nestjs/common';
import { PrismaService } from '@Prisma/services';
import { EstadoSolicitudVerificacion, Prisma } from '@PrismaClient';
import type { DocumentoSubido } from '@Verificaciones/types';

const UNIQUE_CONSTRAINT_VIOLATION = 'P2002';

/** Cliente con el que se lee: el pool, o la transacción en curso. */
type Cliente = PrismaService | Prisma.TransactionClient;

/** Lo que se devuelve de una solicitud: nunca el documento ni su nombre. */
export const SOLICITUD_CREADA_SELECT = {
  id: true,
  estado: true,
  creadaEn: true,
} satisfies Prisma.SolicitudVerificacionSelect;

export type SolicitudCreada = Prisma.SolicitudVerificacionGetPayload<{
  select: typeof SOLICITUD_CREADA_SELECT;
}>;

/**
 * Lo que se lee de la solicitud más reciente para derivar el estado: nunca el
 * documento.
 */
export const ULTIMA_SOLICITUD_SELECT = {
  id: true,
  estado: true,
  motivo: true,
  revisadoEn: true,
} satisfies Prisma.SolicitudVerificacionSelect;

export type UltimaSolicitud = Prisma.SolicitudVerificacionGetPayload<{
  select: typeof ULTIMA_SOLICITUD_SELECT;
}>;

export type ResultadoCrearSolicitud =
  { solicitud: SolicitudCreada } | { rechazo: 'EN_REVISION_EXISTENTE' };

/** Solicitudes de verificación y sus documentos (DB-17.1). */
@Injectable()
export class SolicitudVerificacionRepository {
  constructor(private readonly prisma: PrismaService) {}

  /**
   * Crea la solicitud `EN_REVISION` y su documento en un solo `create`
   * anidado: Prisma lo ejecuta en una transacción, así que si falla el
   * documento tampoco queda la solicitud, y nunca hay un documento sin
   * solicitud.
   *
   * La unicidad la garantiza la base con el índice único parcial
   * `solicitud_una_en_revision` (una sola solicitud `EN_REVISION` por
   * usuario), no una consulta previa: con dos envíos simultáneos solo uno
   * pasa y el otro recibe P2002, que aquí se devuelve como rechazo. Es el
   * único índice único que puede chocar: el `id` lo genera la base y
   * `solicitud_id` del documento es el de una solicitud recién creada.
   */
  async crearConDocumento(
    usuarioId: string,
    documento: DocumentoSubido,
  ): Promise<ResultadoCrearSolicitud> {
    try {
      const solicitud = await this.prisma.solicitudVerificacion.create({
        data: {
          usuarioId,
          estado: EstadoSolicitudVerificacion.EN_REVISION,
          documento: {
            create: {
              nombreArchivo: documento.nombreArchivo,
              // Prisma 7 tipa `Bytes` como `Uint8Array<ArrayBuffer>` y el
              // Buffer de Node no encaja en ese tipo; la copia es directa y de
              // como máximo 5 MB.
              contenido: new Uint8Array(documento.contenido),
              mimeType: documento.mimeType,
              tamanoBytes: documento.tamanoBytes,
            },
          },
        },
        select: SOLICITUD_CREADA_SELECT,
      });
      return { solicitud };
    } catch (error) {
      if (
        error instanceof Prisma.PrismaClientKnownRequestError &&
        error.code === UNIQUE_CONSTRAINT_VIOLATION
      ) {
        return { rechazo: 'EN_REVISION_EXISTENTE' };
      }
      throw error;
    }
  }

  /**
   * Solicitud más reciente del usuario, o `null` si nunca envió un documento.
   *
   * Ordena por `creadaEn` descendente y desempata por `id` descendente, para
   * que dos solicitudes con la misma fecha den siempre el mismo resultado. Usa
   * el índice `(usuario_id, creada_en DESC)` y no toca `DocumentosVerificacion`.
   *
   * `db` permite leer dentro de una transacción en curso (por ejemplo, la del
   * procesador de la cola de reservas); sin él, usa el pool.
   */
  findUltimaDeUsuario(
    usuarioId: string,
    db: Cliente = this.prisma,
  ): Promise<UltimaSolicitud | null> {
    return db.solicitudVerificacion.findFirst({
      where: { usuarioId },
      orderBy: [{ creadaEn: 'desc' }, { id: 'desc' }],
      select: ULTIMA_SOLICITUD_SELECT,
    });
  }
}
