import { randomUUID } from 'node:crypto';
import { PrismaPg } from '@prisma/adapter-pg';
import { PrismaClient, Rol } from '@PrismaClient';
import type { PrismaService } from '@Prisma/services';
import { PoliticaVerificacionRepository } from './politica-verificacion.repository.js';

const habilitada = process.env.RUN_DB_INTEGRATION === '1';

if (habilitada && !process.env.DATABASE_URL) {
  throw new Error('RUN_DB_INTEGRATION=1 requiere DATABASE_URL configurada.');
}

/**
 * BE-19.1 contra PostgreSQL: la política se crea y se actualiza sobre el mismo
 * registro (bienId es la clave primaria), vale false sin registro y depende de
 * la existencia del bien.
 */
describe.skipIf(!habilitada)(
  'BE-19.1 - Política de verificación con PostgreSQL',
  () => {
    let prisma: PrismaClient;
    let repository: PoliticaVerificacionRepository;
    let arrendadorId = '';
    const bienes: string[] = [];

    const crearBien = async (estado: 'ACTIVA' | 'INACTIVA' = 'ACTIVA') => {
      const { id } = await prisma.bien.create({
        data: {
          arrendadorId,
          tipo: 'PROPIEDAD',
          categoria: 'Casa',
          titulo: `Bien política ${randomUUID().slice(0, 8)}`,
          descripcion: 'Bien de prueba de integración',
          precio: 50,
          unidadCobro: 'NOCHE',
          departamento: 'San Salvador',
          municipio: 'San Salvador',
          estado,
        },
        select: { id: true },
      });
      bienes.push(id);
      return id;
    };

    const registros = (bienId: string) =>
      prisma.politicaVerificacionBien.count({ where: { bienId } });

    beforeAll(async () => {
      prisma = new PrismaClient({
        adapter: new PrismaPg({ connectionString: process.env.DATABASE_URL! }),
      });
      await prisma.$connect();
      repository = new PoliticaVerificacionRepository(
        prisma as unknown as PrismaService,
      );
      const sufijo = randomUUID().replaceAll('-', '').slice(0, 10);
      arrendadorId = (
        await prisma.usuario.create({
          data: {
            nombreUsuario: `verif_pol_${sufijo}`,
            email: `verif_pol_${sufijo}@example.com`,
            passwordHash: 'hash-prueba',
            rol: Rol.ARRENDADOR,
          },
        })
      ).id;
    });

    afterAll(async () => {
      try {
        if (bienes.length > 0) {
          await prisma.bien.deleteMany({ where: { id: { in: bienes } } });
        }
        if (arrendadorId) {
          await prisma.usuario.delete({ where: { id: arrendadorId } });
        }
      } finally {
        await prisma?.$disconnect();
      }
    });

    it('sin registro, la política vale false', async () => {
      const bienId = await crearBien();

      await expect(repository.findBien(bienId)).resolves.toEqual({
        arrendadorId,
        soloVerificados: false,
      });
      expect(await registros(bienId)).toBe(0);
    });

    it('la primera vez crea la política y después actualiza el mismo registro', async () => {
      const bienId = await crearBien();

      await expect(repository.guardar(bienId, true)).resolves.toEqual({
        bienId,
        soloVerificados: true,
      });
      expect(await registros(bienId)).toBe(1);

      await expect(repository.guardar(bienId, false)).resolves.toEqual({
        bienId,
        soloVerificados: false,
      });
      expect(await registros(bienId)).toBe(1);
      await expect(repository.findBien(bienId)).resolves.toMatchObject({
        soloVerificados: false,
      });
    });

    it('varios guardados simultáneos dejan un solo registro', async () => {
      const bienId = await crearBien();

      const resultados = await Promise.all(
        Array.from({ length: 10 }, (_, i) =>
          repository.guardar(bienId, i % 2 === 0),
        ),
      );

      expect(resultados.every((r) => r?.bienId === bienId)).toBe(true);
      expect(await registros(bienId)).toBe(1);
    });

    it('un bien INACTIVA también tiene política', async () => {
      const bienId = await crearBien('INACTIVA');

      await repository.guardar(bienId, true);

      await expect(repository.findBien(bienId)).resolves.toEqual({
        arrendadorId,
        soloVerificados: true,
      });
    });

    it('no se puede guardar la política de un bien inexistente', async () => {
      const inexistente = randomUUID();

      await expect(repository.guardar(inexistente, true)).resolves.toBeNull();
      await expect(repository.findBien(inexistente)).resolves.toBeNull();
      expect(await registros(inexistente)).toBe(0);
    });

    it('al borrar el bien se borra su política (FK en cascada)', async () => {
      const bienId = await crearBien();
      await repository.guardar(bienId, true);

      await prisma.bien.delete({ where: { id: bienId } });

      expect(await registros(bienId)).toBe(0);
    });
  },
);
