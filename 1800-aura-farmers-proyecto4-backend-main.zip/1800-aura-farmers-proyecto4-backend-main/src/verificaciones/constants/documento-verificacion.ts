/** Nombre del campo multipart que trae el documento (BE-17.1). */
export const CAMPO_DOCUMENTO = 'documento';

/**
 * Peso máximo del documento. Coincide con el CHECK
 * `DocumentosVerificacion_tamano_check` (`tamano_bytes <= 5242880`): un
 * archivo de exactamente 5 MB se acepta.
 */
export const MAX_DOCUMENTO_MB = 5;
export const MAX_DOCUMENTO_BYTES = MAX_DOCUMENTO_MB * 1024 * 1024;

/** Largo máximo del nombre original: la columna es `VARCHAR(255)`. */
export const MAX_LARGO_NOMBRE_ARCHIVO = 255;

/**
 * Campos de texto que se toleran en el formulario. El endpoint solo usa el
 * archivo y no lee ningún campo de texto; el tope evita que un formulario con
 * miles de campos se lea completo en memoria.
 */
export const MAX_CAMPOS_FORMULARIO = 5;

/** Partes del multipart: los campos de texto más el documento. */
export const MAX_PARTES_FORMULARIO = MAX_CAMPOS_FORMULARIO + 1;
