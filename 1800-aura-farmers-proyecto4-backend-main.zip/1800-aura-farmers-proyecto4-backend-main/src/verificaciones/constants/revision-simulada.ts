import { CronExpression } from '@nestjs/schedule';

/** Cada cuánto corre la revisión simulada (BE-18.1): cada 10 segundos. */
export const CRON_REVISION_SIMULADA = CronExpression.EVERY_10_SECONDS;

/** Nombre del cron en el SchedulerRegistry. */
export const NOMBRE_CRON_REVISION_SIMULADA = 'revision-simulada-verificacion';

/**
 * Antigüedad mínima de una solicitud para revisarla (espera simulada). La
 * consulta de `RevisionVerificacionRepository` la recibe como parámetro
 * (`make_interval`, en segundos) y la compara con el reloj de PostgreSQL:
 * este es el único lugar donde se define.
 */
export const ESPERA_MINIMA_REVISION_MS = 10_000;

/** Solicitudes que se toman en cada transacción. */
export const LOTE_REVISION_SIMULADA = 20;

/**
 * Avisos que la conciliación intenta recuperar en cada corrida: los de
 * solicitudes ya resueltas cuyo aviso no llegó a crearse.
 */
export const LOTE_CONCILIACION_AVISOS = 20;

/**
 * Antigüedad mínima de la resolución (`revisado_en`) para conciliar su aviso.
 * Da tiempo a que termine el aviso normal, que se pide justo después del
 * commit, incluso el de otra instancia del procesador. Es un mínimo, no una
 * ventana: no hay antigüedad máxima.
 */
export const GRACIA_CONCILIACION_MS = 60 * 1000;

/**
 * Tras un fallo, cuánto espera esa solicitud antes de que la conciliación la
 * vuelva a intentar. Mientras espera no ocupa lugar en el lote, así que una
 * que falle siempre no impide recuperar las demás.
 */
export const ESPERA_REINTENTO_AVISO_MS = 5 * 60 * 1000;

/** Texto que, en el nombre del archivo, hace que se rechace el documento. */
export const PALABRA_RECHAZO = 'rechazar';

/** Motivo exacto del rechazo simulado. */
export const MOTIVO_RECHAZO_SIMULADO =
  'Documento no válido (revisión simulada).';

/** Aviso al usuario con el resultado (Módulo 8). */
export const TITULO_RESULTADO_VERIFICACION = 'Resultado de tu verificación';
export const MENSAJE_VERIFICACION_APROBADA =
  'Tu documento fue aprobado. Ya estás verificado.';
export const TIPO_REFERENCIA_SOLICITUD_VERIFICACION = 'SOLICITUD_VERIFICACION';

/** Largo máximo que acepta `NotificacionesService.crear` para el mensaje. */
export const LONGITUD_MAXIMA_MENSAJE_AVISO = 300;
