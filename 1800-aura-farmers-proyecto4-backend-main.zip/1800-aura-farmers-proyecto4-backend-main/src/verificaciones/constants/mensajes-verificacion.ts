import {
  MAX_DOCUMENTO_MB,
  MAX_LARGO_NOMBRE_ARCHIVO,
} from './documento-verificacion.js';

/** Mensajes de error de la carga del documento (BE-17.1). */
export const MENSAJES_VERIFICACION = {
  DOCUMENTO_FALTANTE: 'Debes adjuntar el documento en el campo documento.',
  DOCUMENTO_DEMASIADO_GRANDE: `El archivo supera ${MAX_DOCUMENTO_MB} MB.`,
  DOCUMENTO_VACIO: 'El archivo está vacío. Usa JPG, PNG o PDF.',
  FORMATO_NO_PERMITIDO: 'Formato no permitido. Usa JPG, PNG o PDF.',
  NOMBRE_VACIO: 'El nombre del archivo no es válido.',
  NOMBRE_DEMASIADO_LARGO: `El nombre del archivo no puede superar ${MAX_LARGO_NOMBRE_ARCHIVO} caracteres.`,
  UN_SOLO_DOCUMENTO: 'Solo se puede enviar un documento.',
  FORMULARIO_MAL_FORMADO: 'El formulario multipart está mal formado.',
  DEMASIADOS_CAMPOS: 'El formulario tiene más campos de los permitidos.',
  SOLICITUD_EN_REVISION: 'Ya tienes un documento en revisión.',
} as const;

/** Mensaje para un archivo enviado en un campo que no es `documento`. */
export const campoSinArchivos = (campo: string | undefined): string =>
  `El campo ${campo ?? 'recibido'} no admite archivos. Envía el documento en el campo documento.`;
