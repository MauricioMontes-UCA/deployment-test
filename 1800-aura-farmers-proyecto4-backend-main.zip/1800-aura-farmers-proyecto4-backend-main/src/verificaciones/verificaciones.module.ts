import { Module } from '@nestjs/common';
import { NotificacionesModule } from '@Notificaciones';
import {
  PoliticaVerificacionController,
  VerificacionesController,
} from '@Verificaciones/controllers';
import {
  PoliticaVerificacionRepository,
  RevisionVerificacionRepository,
  SolicitudVerificacionRepository,
} from '@Verificaciones/repositories';
import {
  EstadoVerificacionService,
  PoliticaVerificacionService,
  RevisionSimuladaService,
  SolicitudesVerificacionService,
  VerificacionService,
} from '@Verificaciones/services';
import { RevisionSimuladaWorker } from '@Verificaciones/workers';

/**
 * Verificación de identidad (Módulo 7, H17, H18 y H19).
 *
 * Carga del documento (BE-17.1), consulta del propio estado (BE-17.2), la
 * revisión simulada que resuelve las solicitudes (BE-18.1) y la política
 * "Solo usuarios verificados" de cada bien (BE-19.1). Importa
 * NotificacionesModule para avisar el resultado.
 *
 * Exporta `EstadoVerificacionService` para que otros módulos calculen el
 * estado con la misma regla, y `VerificacionService` (`puedeReservar`,
 * BE-19.2) para el módulo de reservas. No importa nada de reservas ni de
 * bienes, así que no hay dependencias circulares.
 */
@Module({
  imports: [NotificacionesModule],
  controllers: [VerificacionesController, PoliticaVerificacionController],
  providers: [
    SolicitudesVerificacionService,
    EstadoVerificacionService,
    RevisionSimuladaService,
    PoliticaVerificacionService,
    VerificacionService,
    RevisionSimuladaWorker,
    SolicitudVerificacionRepository,
    RevisionVerificacionRepository,
    PoliticaVerificacionRepository,
  ],
  exports: [EstadoVerificacionService, VerificacionService],
})
export class VerificacionesModule {}
