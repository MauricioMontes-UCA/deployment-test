import {
  Controller,
  Get,
  Post,
  UploadedFile,
  UseInterceptors,
} from '@nestjs/common';
import {
  ApiBadRequestResponse,
  ApiBearerAuth,
  ApiBody,
  ApiConflictResponse,
  ApiConsumes,
  ApiCreatedResponse,
  ApiOkResponse,
  ApiOperation,
  ApiPayloadTooLargeResponse,
  ApiTags,
  ApiUnauthorizedResponse,
  ApiUnsupportedMediaTypeResponse,
} from '@nestjs/swagger';
import { CurrentUser, Roles } from '@Auth/decorators';
import type { AuthenticatedUser } from '@Auth/types';
import { Rol } from '@PrismaClient';
import {
  CargarDocumentoFormDto,
  EstadoVerificacionResponseDto,
  SolicitudVerificacionResponseDto,
} from '@Verificaciones/dto';
import { DocumentoVerificacionInterceptor } from '@Verificaciones/interceptors';
import { DocumentoVerificacionPipe } from '@Verificaciones/pipes';
import {
  EstadoVerificacionService,
  SolicitudesVerificacionService,
} from '@Verificaciones/services';
import type { DocumentoSubido } from '@Verificaciones/types';

/** Verificación de identidad (Módulo 7, H17). */
@ApiTags('verificaciones')
@ApiBearerAuth()
@Roles(Rol.ARRENDADOR, Rol.ARRENDATARIO)
@Controller('verificaciones')
export class VerificacionesController {
  constructor(
    private readonly solicitudesService: SolicitudesVerificacionService,
    private readonly estadoService: EstadoVerificacionService,
  ) {}

  /**
   * Solo el estado del propio usuario: el id sale del token y la ruta no
   * acepta ningún identificador (no existe una consulta del estado de otro).
   */
  @Get('mi-estado')
  @ApiOperation({
    summary: 'Consulta mi estado de verificación',
    description:
      'Roles ARRENDADOR y ARRENDATARIO. Devuelve el estado del usuario autenticado, derivado de su solicitud más reciente: NO_VERIFICADO (sin solicitudes), EN_REVISION, VERIFICADO (APROBADA) o RECHAZADO (RECHAZADA). Las cuatro propiedades están siempre presentes; motivo, solicitudId y revisadoEn van en null cuando no aplican. No incluye el documento.',
  })
  @ApiOkResponse({
    type: EstadoVerificacionResponseDto,
    description: 'Estado de verificación del usuario autenticado.',
  })
  @ApiUnauthorizedResponse({
    description: 'Token ausente, inválido o expirado.',
  })
  async miEstado(
    @CurrentUser() usuario: AuthenticatedUser,
  ): Promise<EstadoVerificacionResponseDto> {
    return EstadoVerificacionResponseDto.from(
      await this.estadoService.obtener(usuario.id),
    );
  }

  /**
   * El usuario sale siempre del token: el formulario no lleva ningún
   * identificador, y cualquier campo de texto que traiga se ignora.
   */
  @Post()
  @UseInterceptors(DocumentoVerificacionInterceptor)
  @ApiOperation({
    summary: 'Envía el documento de identidad para verificar la cuenta',
    description:
      'Roles ARRENDADOR y ARRENDATARIO. Crea una solicitud EN_REVISION con el documento, que queda a la espera de la revisión automática (BE-18.1). Solo se rechaza si el usuario ya tiene una solicitud EN_REVISION: tras una APROBADA (renovación) o una RECHAZADA se puede enviar otra.',
  })
  @ApiConsumes('multipart/form-data')
  @ApiBody({ type: CargarDocumentoFormDto })
  @ApiCreatedResponse({
    type: SolicitudVerificacionResponseDto,
    description: 'Solicitud creada EN_REVISION.',
  })
  @ApiBadRequestResponse({
    description:
      'Falta el documento, viene más de un archivo o en otro campo, el formulario está mal formado, o el nombre del archivo queda vacío o supera 255 caracteres.',
  })
  @ApiUnauthorizedResponse({
    description: 'Token ausente, inválido o expirado.',
  })
  @ApiConflictResponse({
    description: 'El usuario ya tiene una solicitud EN_REVISION.',
  })
  @ApiPayloadTooLargeResponse({ description: 'El archivo supera 5 MB.' })
  @ApiUnsupportedMediaTypeResponse({
    description:
      'El archivo está vacío o su contenido no es JPG, PNG ni PDF, sin importar su extensión o Content-Type.',
  })
  async cargarDocumento(
    @CurrentUser() usuario: AuthenticatedUser,
    @UploadedFile(DocumentoVerificacionPipe) documento: DocumentoSubido,
  ): Promise<SolicitudVerificacionResponseDto> {
    const solicitud = await this.solicitudesService.crear(
      usuario.id,
      documento,
    );
    return SolicitudVerificacionResponseDto.from(solicitud);
  }
}
