import {
  Body,
  Controller,
  Get,
  Param,
  ParseUUIDPipe,
  Put,
} from '@nestjs/common';
import {
  ApiBadRequestResponse,
  ApiBearerAuth,
  ApiForbiddenResponse,
  ApiNotFoundResponse,
  ApiOkResponse,
  ApiOperation,
  ApiTags,
  ApiUnauthorizedResponse,
} from '@nestjs/swagger';
import { CurrentUser, Roles } from '@Auth/decorators';
import type { AuthenticatedUser } from '@Auth/types';
import { Rol } from '@PrismaClient';
import {
  ActualizarPoliticaVerificacionDto,
  PoliticaVerificacionResponseDto,
} from '@Verificaciones/dto';
import { PoliticaVerificacionService } from '@Verificaciones/services';

/**
 * Política "Solo usuarios verificados" de un bien (H19, BE-19.1). Comparte la
 * ruta `/bienes` con los controladores de bienes, pero vive en el módulo de
 * verificación para no modificar el Módulo 1.
 */
@ApiTags('verificaciones')
@ApiBearerAuth()
@ApiUnauthorizedResponse({ description: 'Token ausente, inválido o expirado.' })
@Controller('bienes/:bienId/politica-verificacion')
export class PoliticaVerificacionController {
  constructor(private readonly politicaService: PoliticaVerificacionService) {}

  /** Cualquier usuario autenticado, sea cual sea su rol. */
  @Get()
  @ApiOperation({
    summary: 'Consulta si un bien solo acepta usuarios verificados',
    description:
      'Cualquier usuario autenticado. Un bien sin la política registrada devuelve soloVerificados = false. Incluye bienes INACTIVA.',
  })
  @ApiOkResponse({ type: PoliticaVerificacionResponseDto })
  @ApiBadRequestResponse({ description: 'El bienId no es un UUID.' })
  @ApiNotFoundResponse({ description: 'El bien no existe.' })
  async consultar(
    @Param('bienId', ParseUUIDPipe) bienId: string,
  ): Promise<PoliticaVerificacionResponseDto> {
    return PoliticaVerificacionResponseDto.from(
      await this.politicaService.consultar(bienId),
    );
  }

  /**
   * Solo el arrendador dueño del bien. Las reservas CONFIRMADA existentes no
   * cambian.
   */
  @Put()
  @Roles(Rol.ARRENDADOR)
  @ApiOperation({
    summary: 'Activa o desactiva "Solo usuarios verificados" en un bien propio',
    description:
      'Solo el ARRENDADOR dueño del bien. Activarla (true) exige que el arrendador esté VERIFICADO, también si ya estaba activa; desactivarla no. No modifica las reservas CONFIRMADA existentes.',
  })
  @ApiOkResponse({
    type: PoliticaVerificacionResponseDto,
    description: 'La política tal como quedó guardada.',
  })
  @ApiBadRequestResponse({
    description:
      'El bienId no es un UUID, o soloVerificados falta, no es booleano o viene con campos de más.',
  })
  @ApiForbiddenResponse({
    description:
      'El usuario no es ARRENDADOR, el bien es de otro arrendador, o quiere activar la política sin estar VERIFICADO.',
  })
  @ApiNotFoundResponse({ description: 'El bien no existe.' })
  async actualizar(
    @Param('bienId', ParseUUIDPipe) bienId: string,
    @Body() dto: ActualizarPoliticaVerificacionDto,
    @CurrentUser() usuario: AuthenticatedUser,
  ): Promise<PoliticaVerificacionResponseDto> {
    return PoliticaVerificacionResponseDto.from(
      await this.politicaService.actualizar(
        bienId,
        usuario.id,
        dto.soloVerificados,
      ),
    );
  }
}
