/** Tipos de archivo que acepta la carga del documento, por su firma. */
export type MimeDocumento = 'image/jpeg' | 'image/png' | 'application/pdf';

/**
 * Documento ya validado por `DocumentoVerificacionPipe`, listo para guardarse
 * en `DocumentosVerificacion`.
 *
 * `mimeType` es el tipo detectado por los primeros bytes, nunca el que declaró
 * el cliente, y `nombreArchivo` es el nombre original sin rutas.
 */
export interface DocumentoSubido {
  nombreArchivo: string;
  contenido: Buffer;
  mimeType: MimeDocumento;
  tamanoBytes: number;
}
