import type { EstadoSolicitudVerificacion } from '@PrismaClient';

/**
 * Estado de verificación del usuario (glosario de H17). Se calcula a partir de
 * su solicitud más reciente; no se guarda en la base.
 */
export const EstadoVerificacion = {
  NO_VERIFICADO: 'NO_VERIFICADO',
  EN_REVISION: 'EN_REVISION',
  VERIFICADO: 'VERIFICADO',
  RECHAZADO: 'RECHAZADO',
} as const;

export type EstadoVerificacion =
  (typeof EstadoVerificacion)[keyof typeof EstadoVerificacion];

/** Lo que se necesita de la solicitud más reciente para derivar el estado. */
export interface SolicitudParaEstado {
  id: string;
  estado: EstadoSolicitudVerificacion;
  motivo: string | null;
  revisadoEn: Date | null;
}

/** Estado de verificación de un usuario, tal como lo ve él mismo. */
export interface EstadoVerificacionUsuario {
  estado: EstadoVerificacion;
  /** Motivo del rechazo; `null` si el estado no es `RECHAZADO`. */
  motivo: string | null;
  /** Solicitud más reciente; `null` si nunca envió un documento. */
  solicitudId: string | null;
  /** Fecha de la revisión; `null` si todavía no se revisó. */
  revisadoEn: Date | null;
}
