import { Injectable, Logger } from '@nestjs/common';
import { EstadoSolicitudVerificacion, ModuloOrigen } from '@PrismaClient';
import { NotificacionesService } from '@Notificaciones/services';
import {
  ESPERA_REINTENTO_AVISO_MS,
  LOTE_CONCILIACION_AVISOS,
  LOTE_REVISION_SIMULADA,
  MOTIVO_RECHAZO_SIMULADO,
  TIPO_REFERENCIA_SOLICITUD_VERIFICACION,
  TITULO_RESULTADO_VERIFICACION,
} from '@Verificaciones/constants';
import { ZonaHorariaNoUtcError } from '@Verificaciones/errors';
import {
  RevisionVerificacionRepository,
  type AvisoPendiente,
  type SolicitudResuelta,
} from '@Verificaciones/repositories';
import {
  mensajeResultadoVerificacion,
  type ResultadoRevision,
} from '@Verificaciones/utils';

/** Qué pasó al pedir un aviso al Módulo 8. */
type ResultadoAviso = 'CREADO' | 'YA_EXISTIA' | 'FALLO';

/**
 * El resultado de la revisión simulada a partir de lo guardado en la
 * solicitud, para rearmar exactamente el mismo aviso. `null` si lo guardado
 * no es un resultado de la revisión simulada. `avisosPendientes` ya excluye
 * esos casos en la consulta; esta comprobación es solo una segunda barrera.
 */
function resultadoGuardado({
  estado,
  motivo,
}: AvisoPendiente): ResultadoRevision | null {
  if (estado === EstadoSolicitudVerificacion.APROBADA) {
    return { estado: EstadoSolicitudVerificacion.APROBADA, motivo: null };
  }
  if (
    estado === EstadoSolicitudVerificacion.RECHAZADA &&
    motivo === MOTIVO_RECHAZO_SIMULADO
  ) {
    return {
      estado: EstadoSolicitudVerificacion.RECHAZADA,
      motivo: MOTIVO_RECHAZO_SIMULADO,
    };
  }
  return null;
}

/** Lo que hizo una corrida del procesador. */
export interface ResumenRevision {
  resueltas: number;
  sinDocumento: number;
}

/**
 * Revisión simulada de documentos (H18, BE-18.1).
 *
 * Resuelve las solicitudes EN_REVISION con al menos 10 segundos de antigüedad,
 * en lotes de 20 por transacción, y avisa a cada usuario después del commit.
 * Después, en cada corrida, recupera los avisos que no llegaron a crearse
 * (conciliación).
 */
@Injectable()
export class RevisionSimuladaService {
  private readonly logger = new Logger(RevisionSimuladaService.name);

  /** Corrida en curso: una segunda llamada recibe la misma promesa. */
  private enCurso: Promise<ResumenRevision> | null = null;

  /**
   * Solicitudes cuyo aviso falló en la conciliación, con el instante (ms)
   * desde el que se pueden volver a intentar. Mientras esperan no se piden,
   * así que una que falle siempre no ocupa el lote de las demás. Vive en
   * memoria: tras un reinicio se reintentan todas, que es lo seguro.
   */
  private readonly reintentarDesde = new Map<string, number>();

  constructor(
    private readonly revisionRepository: RevisionVerificacionRepository,
    private readonly notificacionesService: NotificacionesService,
  ) {}

  /**
   * Procesa todo lo pendiente y devuelve cuántas solicitudes resolvió.
   *
   * Si ya hay una corrida en curso en esta instancia no abre otra. Entre
   * instancias, `FOR UPDATE SKIP LOCKED` hace que cada solicitud la tome una
   * sola. Nunca lanza: un error se registra y lo pendiente se reintenta en el
   * siguiente cron.
   *
   * La espera mínima de 10 segundos la mide PostgreSQL con su reloj; `ahora`
   * solo es el valor que se guarda en `revisadoEn` y no decide qué solicitudes
   * se toman. Si la sesión de PostgreSQL no está en UTC, no procesa nada y
   * registra el error.
   *
   * Después de revisar, concilia los avisos (`conciliarAvisos`). La
   * conciliación va aparte: si falla, no afecta lo que ya se revisó.
   */
  procesarPendientes(ahora: Date = new Date()): Promise<ResumenRevision> {
    if (this.enCurso) return this.enCurso;
    this.enCurso = this.correr(ahora).finally(() => {
      this.enCurso = null;
    });
    return this.enCurso;
  }

  private async correr(ahora: Date): Promise<ResumenRevision> {
    const resumen = await this.revisarPendientes(ahora);
    await this.conciliarAvisos(ahora);
    return resumen;
  }

  private async revisarPendientes(ahora: Date): Promise<ResumenRevision> {
    // Las solicitudes sin documento quedan EN_REVISION; se excluyen del resto
    // de la corrida para no tomarlas otra vez en cada lote.
    const excluir: string[] = [];
    const resumen: ResumenRevision = { resueltas: 0, sinDocumento: 0 };

    try {
      for (;;) {
        const lote = await this.revisionRepository.resolverLote({
          revisadoEn: ahora,
          excluir,
          lote: LOTE_REVISION_SIMULADA,
        });

        for (const id of lote.sinDocumento) {
          this.logger.warn(
            `La solicitud de verificación ${id} no tiene documento: queda EN_REVISION sin revisar.`,
          );
          excluir.push(id);
        }
        resumen.sinDocumento += lote.sinDocumento.length;
        resumen.resueltas += lote.resueltas.length;

        // La transacción del lote ya se confirmó: recién ahora se avisa.
        await this.avisar(lote.resueltas);

        if (lote.tomadas < LOTE_REVISION_SIMULADA) return resumen;
      }
    } catch (error) {
      if (error instanceof ZonaHorariaNoUtcError) {
        // Configuración incompatible: no es un fallo pasajero ni tiene traza útil.
        this.logger.error(error.message);
        return resumen;
      }
      this.logger.error(
        'Falló la revisión simulada de documentos; se reintentará.',
        error instanceof Error ? error.stack : String(error),
      );
      return resumen;
    }
  }

  /**
   * Un aviso por solicitud resuelta, con la solicitud como referencia. El
   * Módulo 8 deduplica por destinatario y referencia, así que nunca hay dos.
   * Un fallo se registra y no detiene los demás ni revierte la resolución.
   */
  private async avisar(resueltas: SolicitudResuelta[]): Promise<void> {
    for (const solicitud of resueltas) {
      await this.crearAviso(solicitud);
    }
  }

  /**
   * Recupera los avisos de solicitudes ya resueltas que no llegaron a crearse:
   * por un fallo del Módulo 8, o por una caída entre el commit del lote y el
   * aviso.
   *
   * - Un lote por corrida (`LOTE_CONCILIACION_AVISOS`), las más antiguas
   *   primero y sin ventana de tiempo: tras una caída larga se recuperan
   *   todas, de a un lote por corrida.
   * - El aviso es el mismo que el original (`crearAviso`). El Módulo 8
   *   deduplica por destinatario y referencia: con dos procesadores a la vez
   *   uno lo crea y el otro recibe `creada: false`.
   * - Un aviso que falla se registra, no detiene los demás y su solicitud
   *   espera `ESPERA_REINTENTO_AVISO_MS` antes de volver a pedirse: un fallo
   *   pasajero se recupera después, y uno permanente no monopoliza el lote.
   * - No cambia ningún estado de verificación y nunca lanza.
   */
  private async conciliarAvisos(ahora: Date): Promise<void> {
    const momento = ahora.getTime();
    for (const [id, desde] of this.reintentarDesde) {
      if (desde <= momento) this.reintentarDesde.delete(id);
    }

    let pendientes: AvisoPendiente[];
    try {
      pendientes = await this.revisionRepository.avisosPendientes({
        excluir: [...this.reintentarDesde.keys()],
        lote: LOTE_CONCILIACION_AVISOS,
      });
    } catch (error) {
      this.logger.error(
        'Falló la conciliación de avisos de verificación; se reintentará.',
        error instanceof Error ? error.stack : String(error),
      );
      return;
    }

    let recuperados = 0;
    for (const pendiente of pendientes) {
      const resultado = resultadoGuardado(pendiente);
      if (!resultado) {
        this.logger.warn(
          `La solicitud de verificación ${pendiente.id} no tiene un resultado de la revisión simulada; no se avisa.`,
        );
        this.esperarParaReintentar(pendiente.id, momento);
        continue;
      }
      const aviso = await this.crearAviso({
        id: pendiente.id,
        usuarioId: pendiente.usuarioId,
        resultado,
      });
      if (aviso === 'CREADO') recuperados += 1;
      if (aviso === 'FALLO') this.esperarParaReintentar(pendiente.id, momento);
    }

    if (recuperados > 0) {
      this.logger.log(
        `Se recuperaron ${recuperados} avisos de verificación que no se habían creado.`,
      );
    }
  }

  private esperarParaReintentar(id: string, momento: number): void {
    this.reintentarDesde.set(id, momento + ESPERA_REINTENTO_AVISO_MS);
  }

  /**
   * El aviso del resultado al usuario, con la solicitud como referencia. Lo
   * usan el aviso normal y la conciliación, así que los dos son idénticos.
   * Nunca lanza: un fallo se registra.
   */
  private async crearAviso(
    solicitud: SolicitudResuelta,
  ): Promise<ResultadoAviso> {
    try {
      const resultado = await this.notificacionesService.crear(
        solicitud.usuarioId,
        TITULO_RESULTADO_VERIFICACION,
        mensajeResultadoVerificacion(solicitud.resultado),
        ModuloOrigen.VERIFICACION,
        {
          tipoReferencia: TIPO_REFERENCIA_SOLICITUD_VERIFICACION,
          referenciaId: solicitud.id,
        },
      );
      if (!resultado.creada) {
        this.logger.debug(
          `El aviso de la solicitud de verificación ${solicitud.id} ya existía.`,
        );
        return 'YA_EXISTIA';
      }
      return 'CREADO';
    } catch (error) {
      this.logger.error(
        `No se pudo crear el aviso de la solicitud de verificación ${solicitud.id}.`,
        error instanceof Error ? error.stack : String(error),
      );
      return 'FALLO';
    }
  }
}
