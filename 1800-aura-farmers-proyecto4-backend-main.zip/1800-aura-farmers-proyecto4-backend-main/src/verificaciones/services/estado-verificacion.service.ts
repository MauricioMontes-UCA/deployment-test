import { Injectable } from '@nestjs/common';
import { SolicitudVerificacionRepository } from '@Verificaciones/repositories';
import type { EstadoVerificacionUsuario } from '@Verificaciones/types';
import { derivarEstadoVerificacion } from '@Verificaciones/utils';

/**
 * Estado de verificación de un usuario (H17, BE-17.2).
 *
 * `VerificacionesModule` lo exporta para que otros módulos usen el mismo
 * cálculo; BE-19.2 pide que la política "Solo usuarios verificados" se base en
 * esta misma regla.
 */
@Injectable()
export class EstadoVerificacionService {
  constructor(
    private readonly solicitudRepository: SolicitudVerificacionRepository,
  ) {}

  /** Estado derivado de la solicitud más reciente del usuario. */
  async obtener(usuarioId: string): Promise<EstadoVerificacionUsuario> {
    const ultima =
      await this.solicitudRepository.findUltimaDeUsuario(usuarioId);
    return derivarEstadoVerificacion(ultima);
  }
}
