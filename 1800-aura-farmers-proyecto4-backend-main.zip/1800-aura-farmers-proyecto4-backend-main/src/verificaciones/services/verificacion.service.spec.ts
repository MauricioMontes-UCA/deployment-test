import { Prisma } from '@PrismaClient';
import type {
  PoliticaVerificacionRepository,
  SolicitudVerificacionRepository,
} from '@Verificaciones/repositories';
import {
  VerificacionService,
  type ConsultaPuedeReservar,
} from './verificacion.service.js';

const ARRENDATARIO = '5d1e2f3a-4b5c-4d6e-8f70-8192a3b4c5d6';
const BIEN = '7c9e6679-7425-40de-944b-e07fc1f90ae7';
const CONSULTA: ConsultaPuedeReservar = {
  arrendatarioId: ARRENDATARIO,
  bienId: BIEN,
};

type EstadoSolicitud = 'EN_REVISION' | 'APROBADA' | 'RECHAZADA';

function crear({
  soloVerificados,
  ultima,
}: {
  soloVerificados: boolean;
  ultima: EstadoSolicitud | null;
}) {
  const politica = {
    soloVerificados: vi.fn().mockResolvedValue(soloVerificados),
  };
  const solicitudes = {
    findUltimaDeUsuario: vi.fn().mockResolvedValue(
      ultima === null
        ? null
        : {
            id: 'solicitud-1',
            estado: ultima,
            motivo: null,
            revisadoEn: null,
          },
    ),
  };
  const service = new VerificacionService(
    politica as unknown as PoliticaVerificacionRepository,
    solicitudes as unknown as SolicitudVerificacionRepository,
  );
  return { service, politica, solicitudes };
}

describe('VerificacionService.puedeReservar', () => {
  it('sin política activa permite a cualquiera y no consulta al arrendatario', async () => {
    // Sin registro o con soloVerificados=false, el repositorio devuelve false.
    const { service, solicitudes } = crear({
      soloVerificados: false,
      ultima: null,
    });

    await expect(service.puedeReservar(CONSULTA)).resolves.toBe(true);
    expect(solicitudes.findUltimaDeUsuario).not.toHaveBeenCalled();
  });

  it('sin política activa permite también a un arrendatario rechazado', async () => {
    const { service } = crear({ soloVerificados: false, ultima: 'RECHAZADA' });

    await expect(service.puedeReservar(CONSULTA)).resolves.toBe(true);
  });

  it('con política activa permite a un arrendatario VERIFICADO (más reciente APROBADA)', async () => {
    const { service, solicitudes } = crear({
      soloVerificados: true,
      ultima: 'APROBADA',
    });

    await expect(service.puedeReservar(CONSULTA)).resolves.toBe(true);
    expect(solicitudes.findUltimaDeUsuario).toHaveBeenCalledWith(
      ARRENDATARIO,
      undefined,
    );
  });

  it.each([
    ['EN_REVISION', 'EN_REVISION'],
    ['RECHAZADO (más reciente RECHAZADA)', 'RECHAZADA'],
    ['NO_VERIFICADO (sin solicitudes)', null],
  ] as const)(
    'con política activa rechaza a un arrendatario %s',
    async (_estado, ultima) => {
      const { service } = crear({ soloVerificados: true, ultima });

      await expect(service.puedeReservar(CONSULTA)).resolves.toBe(false);
    },
  );

  it('consulta la política del bien y luego al arrendatario, en ese orden de argumentos', async () => {
    const { service, politica, solicitudes } = crear({
      soloVerificados: true,
      ultima: 'APROBADA',
    });

    await service.puedeReservar(CONSULTA);

    expect(politica.soloVerificados).toHaveBeenCalledWith(BIEN, undefined);
    expect(solicitudes.findUltimaDeUsuario).toHaveBeenCalledWith(
      ARRENDATARIO,
      undefined,
    );
  });

  it('con tx, las dos lecturas usan ese mismo cliente de transacción', async () => {
    const { service, politica, solicitudes } = crear({
      soloVerificados: true,
      ultima: 'APROBADA',
    });
    const tx = {} as Prisma.TransactionClient;

    await service.puedeReservar(CONSULTA, tx);

    expect(politica.soloVerificados).toHaveBeenCalledWith(BIEN, tx);
    expect(solicitudes.findUltimaDeUsuario).toHaveBeenCalledWith(
      ARRENDATARIO,
      tx,
    );
  });

  it('no oculta un error inesperado de la base', async () => {
    const { service, politica } = crear({
      soloVerificados: true,
      ultima: null,
    });
    const fallo = new Prisma.PrismaClientKnownRequestError('fallo', {
      code: 'P1001',
      clientVersion: 'test',
    });
    politica.soloVerificados.mockRejectedValue(fallo);

    await expect(service.puedeReservar(CONSULTA)).rejects.toBe(fallo);
  });

  it('no oculta un error al leer la solicitud del arrendatario', async () => {
    const { service, solicitudes } = crear({
      soloVerificados: true,
      ultima: null,
    });
    const fallo = new Error('base caída');
    solicitudes.findUltimaDeUsuario.mockRejectedValue(fallo);

    await expect(service.puedeReservar(CONSULTA)).rejects.toBe(fallo);
  });

  it('con tx, pasa a los dos repositorios el mismo objeto, sin copiarlo', async () => {
    const { service, politica, solicitudes } = crear({
      soloVerificados: true,
      ultima: 'APROBADA',
    });
    const tx = { marca: 'tx-1' } as unknown as Prisma.TransactionClient;

    await service.puedeReservar(CONSULTA, tx);

    expect(politica.soloVerificados.mock.calls[0]![1]).toBe(tx);
    expect(solicitudes.findUltimaDeUsuario.mock.calls[0]![1]).toBe(tx);
  });

  it('el orden de las propiedades no importa: cada id va a su repositorio', async () => {
    const { service, politica, solicitudes } = crear({
      soloVerificados: true,
      ultima: 'APROBADA',
    });

    await service.puedeReservar({ bienId: BIEN, arrendatarioId: ARRENDATARIO });

    expect(politica.soloVerificados).toHaveBeenCalledWith(BIEN, undefined);
    expect(solicitudes.findUltimaDeUsuario).toHaveBeenCalledWith(
      ARRENDATARIO,
      undefined,
    );
  });

  it('con política activa y arrendatario sin verificar, la política se lee por el bien y el estado por el arrendatario', async () => {
    const { service, politica, solicitudes } = crear({
      soloVerificados: true,
      ultima: null,
    });

    await expect(service.puedeReservar(CONSULTA)).resolves.toBe(false);
    // Si los ids se intercambiaran, la política se leería con el del
    // arrendatario y estas expectativas fallarían.
    expect(politica.soloVerificados).toHaveBeenCalledWith(BIEN, undefined);
    expect(politica.soloVerificados).not.toHaveBeenCalledWith(
      ARRENDATARIO,
      undefined,
    );
    expect(solicitudes.findUltimaDeUsuario).toHaveBeenCalledWith(
      ARRENDATARIO,
      undefined,
    );
  });

  it('una llamada con argumentos posicionales no compila', () => {
    // Prueba solo de tipos: la función nunca se llama, así que la llamada
    // inválida no se ejecuta. Si la firma volviera a aceptar dos string, las
    // directivas de abajo quedarían sin error y `tsc` fallaría.
    const nuncaSeLlama = (service: VerificacionService) => {
      // @ts-expect-error: la firma posicional (bienId, usuarioId) ya no existe.
      void service.puedeReservar(BIEN, ARRENDATARIO);
      // @ts-expect-error: tampoco en el orden (arrendatarioId, bienId).
      void service.puedeReservar(ARRENDATARIO, BIEN);
    };

    expect(typeof nuncaSeLlama).toBe('function');
  });
});
