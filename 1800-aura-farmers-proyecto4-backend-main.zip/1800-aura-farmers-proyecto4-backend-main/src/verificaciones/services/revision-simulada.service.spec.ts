import { Logger } from '@nestjs/common';
import type { NotificacionesService } from '@Notificaciones/services';
import { ZonaHorariaNoUtcError } from '@Verificaciones/errors';
import type {
  AvisoPendiente,
  ResultadoLote,
  RevisionVerificacionRepository,
  SolicitudResuelta,
} from '@Verificaciones/repositories';
import { RevisionSimuladaService } from './revision-simulada.service.js';

const AHORA = new Date('2026-11-16T15:00:20.000Z');

const aprobada = (id: string): SolicitudResuelta => ({
  id,
  usuarioId: `usuario-${id}`,
  resultado: { estado: 'APROBADA', motivo: null },
});
const rechazada = (id: string): SolicitudResuelta => ({
  id,
  usuarioId: `usuario-${id}`,
  resultado: {
    estado: 'RECHAZADA',
    motivo: 'Documento no válido (revisión simulada).',
  },
});

const lote = (datos: Partial<ResultadoLote>): ResultadoLote => ({
  tomadas: 0,
  resueltas: [],
  sinDocumento: [],
  ...datos,
});

function crear(
  lotes: ResultadoLote[] = [lote({})],
  pendientes: AvisoPendiente[][] = [],
) {
  const orden: string[] = [];
  const resolverLote = vi.fn();
  for (const l of lotes) {
    resolverLote.mockImplementationOnce(() => {
      orden.push('commit');
      return Promise.resolve(l);
    });
  }
  resolverLote.mockResolvedValue(lote({}));
  // Por defecto no hay avisos que recuperar.
  const avisosPendientes = vi.fn();
  for (const p of pendientes) avisosPendientes.mockResolvedValueOnce(p);
  avisosPendientes.mockResolvedValue([]);
  const crearAviso = vi.fn(() => {
    orden.push('aviso');
    return Promise.resolve({ creada: true, notificacionId: 'n-1' });
  });
  const service = new RevisionSimuladaService(
    {
      resolverLote,
      avisosPendientes,
    } as unknown as RevisionVerificacionRepository,
    { crear: crearAviso } as unknown as NotificacionesService,
  );
  return { service, resolverLote, avisosPendientes, crearAviso, orden };
}

const pendiente = (
  id: string,
  estado: AvisoPendiente['estado'] = 'APROBADA',
): AvisoPendiente => ({
  id,
  usuarioId: `usuario-${id}`,
  estado,
  motivo:
    estado === 'RECHAZADA' ? 'Documento no válido (revisión simulada).' : null,
});

describe('RevisionSimuladaService.procesarPendientes', () => {
  beforeEach(() => {
    vi.spyOn(Logger.prototype, 'error').mockImplementation(() => undefined);
    vi.spyOn(Logger.prototype, 'warn').mockImplementation(() => undefined);
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it('pide lotes de 20 y pasa "ahora" solo como revisadoEn', async () => {
    const { service, resolverLote } = crear();

    await service.procesarPendientes(AHORA);

    expect(resolverLote).toHaveBeenCalledWith({
      revisadoEn: AHORA,
      excluir: [],
      lote: 20,
    });
  });

  it('un reloj adelantado en la aplicación no cambia qué solicitudes se toman', async () => {
    const { service, resolverLote } = crear();
    const adelantado = new Date('2099-01-01T00:00:00.000Z');

    await service.procesarPendientes(adelantado);

    // No hay ningún límite de fecha calculado en la aplicación: la antigüedad
    // la decide la consulta con el reloj de PostgreSQL.
    expect(
      Object.keys(resolverLote.mock.calls[0]![0] as object).sort(),
    ).toEqual(['excluir', 'lote', 'revisadoEn']);
  });

  it('avisa a cada usuario con el resultado, VERIFICACION y la solicitud como referencia', async () => {
    const { service, crearAviso } = crear([
      lote({ tomadas: 2, resueltas: [aprobada('s-1'), rechazada('s-2')] }),
    ]);

    await expect(service.procesarPendientes(AHORA)).resolves.toEqual({
      resueltas: 2,
      sinDocumento: 0,
    });

    expect(crearAviso).toHaveBeenNthCalledWith(
      1,
      'usuario-s-1',
      'Resultado de tu verificación',
      'Tu documento fue aprobado. Ya estás verificado.',
      'VERIFICACION',
      { tipoReferencia: 'SOLICITUD_VERIFICACION', referenciaId: 's-1' },
    );
    expect(crearAviso).toHaveBeenNthCalledWith(
      2,
      'usuario-s-2',
      'Resultado de tu verificación',
      'Tu documento fue rechazado: Documento no válido (revisión simulada).',
      'VERIFICACION',
      { tipoReferencia: 'SOLICITUD_VERIFICACION', referenciaId: 's-2' },
    );
  });

  it('avisa recién después de que el lote se confirmó', async () => {
    const { service, orden } = crear([
      lote({ tomadas: 1, resueltas: [aprobada('s-1')] }),
    ]);

    await service.procesarPendientes(AHORA);

    expect(orden).toEqual(['commit', 'aviso']);
  });

  it('sigue con el siguiente lote mientras vengan lotes llenos', async () => {
    const lleno = Array.from({ length: 20 }, (_, i) => aprobada(`a-${i}`));
    const { service, resolverLote, crearAviso } = crear([
      lote({ tomadas: 20, resueltas: lleno }),
      lote({ tomadas: 3, resueltas: [aprobada('b-1')] }),
    ]);

    await expect(service.procesarPendientes(AHORA)).resolves.toEqual({
      resueltas: 21,
      sinDocumento: 0,
    });
    expect(resolverLote).toHaveBeenCalledTimes(2);
    expect(crearAviso).toHaveBeenCalledTimes(21);
  });

  it('excluye en los lotes siguientes las solicitudes sin documento y lo registra', async () => {
    const warn = vi.spyOn(Logger.prototype, 'warn');
    const { service, resolverLote } = crear([
      lote({ tomadas: 20, sinDocumento: ['sin-doc'] }),
      lote({ tomadas: 0 }),
    ]);

    await expect(service.procesarPendientes(AHORA)).resolves.toEqual({
      resueltas: 0,
      sinDocumento: 1,
    });
    const segundo = resolverLote.mock.calls[1]![0] as { excluir: string[] };
    expect(segundo.excluir).toEqual(['sin-doc']);
    expect(warn).toHaveBeenCalledWith(expect.stringContaining('sin-doc'));
  });

  it('un fallo de un aviso se registra y no impide los demás', async () => {
    const error = vi.spyOn(Logger.prototype, 'error');
    const { service, crearAviso } = crear([
      lote({ tomadas: 2, resueltas: [aprobada('s-1'), aprobada('s-2')] }),
    ]);
    crearAviso.mockImplementationOnce(() =>
      Promise.reject(new Error('avisos caídos')),
    );

    await expect(service.procesarPendientes(AHORA)).resolves.toEqual({
      resueltas: 2,
      sinDocumento: 0,
    });
    expect(crearAviso).toHaveBeenCalledTimes(2);
    expect(error).toHaveBeenCalledWith(
      expect.stringContaining('s-1'),
      expect.any(String),
    );
  });

  it('un aviso que ya existía (creada: false) no es un error', async () => {
    const error = vi.spyOn(Logger.prototype, 'error');
    const { service, crearAviso } = crear([
      lote({ tomadas: 1, resueltas: [aprobada('s-1')] }),
    ]);
    crearAviso.mockImplementationOnce(() =>
      Promise.resolve({ creada: false, notificacionId: 'n-1' }),
    );

    await service.procesarPendientes(AHORA);

    expect(error).not.toHaveBeenCalled();
  });

  it('sin solicitudes resueltas no avisa a nadie (idempotencia)', async () => {
    const { service, crearAviso } = crear([lote({ tomadas: 0 })]);

    await service.procesarPendientes(AHORA);
    await service.procesarPendientes(AHORA);

    expect(crearAviso).not.toHaveBeenCalled();
  });

  it('dos llamadas superpuestas comparten la misma corrida', async () => {
    const { service, resolverLote } = crear();
    let liberar!: () => void;
    resolverLote.mockReset();
    resolverLote.mockImplementationOnce(
      () =>
        new Promise((resolve) => {
          liberar = () => resolve(lote({}));
        }),
    );

    const primera = service.procesarPendientes(AHORA);
    const segunda = service.procesarPendientes(AHORA);
    liberar();

    expect(segunda).toBe(primera);
    await primera;
    expect(resolverLote).toHaveBeenCalledTimes(1);
  });

  it('si la sesión de PostgreSQL no está en UTC, no procesa nada y registra un error claro', async () => {
    const error = vi.spyOn(Logger.prototype, 'error');
    const { service, resolverLote, crearAviso } = crear();
    resolverLote.mockReset();
    resolverLote.mockRejectedValue(
      new ZonaHorariaNoUtcError('America/Guatemala'),
    );

    await expect(service.procesarPendientes(AHORA)).resolves.toEqual({
      resueltas: 0,
      sinDocumento: 0,
    });

    expect(resolverLote).toHaveBeenCalledTimes(1);
    expect(crearAviso).not.toHaveBeenCalled();
    expect(error).toHaveBeenCalledWith(
      expect.stringContaining(
        'zona horaria "America/Guatemala" y la revisión simulada de documentos requiere UTC',
      ),
    );
  });

  it('un error de la base se registra y no se propaga', async () => {
    const error = vi.spyOn(Logger.prototype, 'error');
    const { service, resolverLote } = crear();
    resolverLote.mockReset();
    resolverLote.mockRejectedValue(new Error('base caída'));

    await expect(service.procesarPendientes(AHORA)).resolves.toEqual({
      resueltas: 0,
      sinDocumento: 0,
    });
    expect(error).toHaveBeenCalled();
  });
});

describe('RevisionSimuladaService: conciliación de avisos', () => {
  beforeEach(() => {
    vi.spyOn(Logger.prototype, 'error').mockImplementation(() => undefined);
    vi.spyOn(Logger.prototype, 'warn').mockImplementation(() => undefined);
    vi.spyOn(Logger.prototype, 'log').mockImplementation(() => undefined);
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  const referenciaDe = (llamada: unknown[]) =>
    (llamada[4] as { referenciaId: string }).referenciaId;

  it('después de revisar, pide los pendientes en un lote de 20, sin excluidas', async () => {
    const { service, avisosPendientes, orden, resolverLote } = crear();
    resolverLote.mockImplementation(() => {
      orden.push('commit');
      return Promise.resolve(lote({}));
    });
    avisosPendientes.mockImplementation(() => {
      orden.push('conciliacion');
      return Promise.resolve([]);
    });

    await service.procesarPendientes(AHORA);

    expect(avisosPendientes).toHaveBeenCalledWith({ excluir: [], lote: 20 });
    expect(orden).toEqual(['commit', 'conciliacion']);
  });

  it('crea el aviso faltante con el mismo título, mensaje, módulo y referencia que el original', async () => {
    const { service, crearAviso } = crear(
      [lote({ resueltas: [aprobada('a'), rechazada('b')], tomadas: 2 })],
      [[pendiente('c'), pendiente('d', 'RECHAZADA')]],
    );

    await service.procesarPendientes(AHORA);

    const llamadas = crearAviso.mock.calls as unknown as unknown[][];
    // Los dos primeros son los avisos normales (a y b); los otros, recuperados.
    const original = (id: string) =>
      llamadas.find((l) => referenciaDe(l) === id)!;
    expect(original('c').slice(1)).toEqual(
      original('a')
        .slice(1)
        .map((v, i) =>
          i === 3
            ? { tipoReferencia: 'SOLICITUD_VERIFICACION', referenciaId: 'c' }
            : v,
        ),
    );
    expect(original('d').slice(1)).toEqual(
      original('b')
        .slice(1)
        .map((v, i) =>
          i === 3
            ? { tipoReferencia: 'SOLICITUD_VERIFICACION', referenciaId: 'd' }
            : v,
        ),
    );
    expect(original('c')[0]).toBe('usuario-c');
    expect(original('d')[0]).toBe('usuario-d');
  });

  it('un aviso que ya existía (creada: false) no es un error ni se reintenta', async () => {
    const error = vi.spyOn(Logger.prototype, 'error');
    const { service, crearAviso, avisosPendientes } = crear(undefined, [
      [pendiente('a')],
    ]);
    crearAviso.mockResolvedValue({ creada: false, notificacionId: 'n-1' });

    await service.procesarPendientes(AHORA);
    await service.procesarPendientes(AHORA);

    expect(error).not.toHaveBeenCalled();
    // En la segunda corrida no se excluye: no falló.
    expect(avisosPendientes).toHaveBeenLastCalledWith({
      excluir: [],
      lote: 20,
    });
  });

  it('un aviso que falla no detiene los demás y su solicitud espera antes de reintentarse', async () => {
    const error = vi.spyOn(Logger.prototype, 'error');
    const { service, crearAviso, avisosPendientes } = crear(undefined, [
      [pendiente('a'), pendiente('b'), pendiente('c')],
    ]);
    crearAviso
      .mockResolvedValueOnce({ creada: true, notificacionId: 'n-a' })
      .mockRejectedValueOnce(new Error('Módulo 8 caído'))
      .mockResolvedValueOnce({ creada: true, notificacionId: 'n-c' });

    await service.procesarPendientes(AHORA);

    expect(crearAviso).toHaveBeenCalledTimes(3);
    expect(error).toHaveBeenCalledWith(
      'No se pudo crear el aviso de la solicitud de verificación b.',
      expect.any(String),
    );

    // Antes de 5 minutos, b no se pide; a partir de ahí, sí.
    await service.procesarPendientes(new Date(AHORA.getTime() + 60_000));
    expect(avisosPendientes).toHaveBeenLastCalledWith({
      excluir: ['b'],
      lote: 20,
    });
    await service.procesarPendientes(new Date(AHORA.getTime() + 5 * 60_000));
    expect(avisosPendientes).toHaveBeenLastCalledWith({
      excluir: [],
      lote: 20,
    });
  });

  it('un fallo pasajero se recupera en una corrida posterior', async () => {
    const { service, crearAviso, avisosPendientes } = crear();
    avisosPendientes.mockResolvedValue([pendiente('a')]);
    crearAviso
      .mockRejectedValueOnce(new Error('pasajero'))
      .mockResolvedValueOnce({ creada: true, notificacionId: 'n-a' });

    await service.procesarPendientes(AHORA);
    await service.procesarPendientes(new Date(AHORA.getTime() + 5 * 60_000));

    expect(crearAviso).toHaveBeenCalledTimes(2);
    expect(
      crearAviso.mock.calls.map((l) => referenciaDe(l as unknown[])),
    ).toEqual(['a', 'a']);
  });

  it('una solicitud cuyo resultado guardado no es de la revisión simulada no se avisa y no monopoliza el lote', async () => {
    const warn = vi.spyOn(Logger.prototype, 'warn');
    const { service, crearAviso, avisosPendientes } = crear(undefined, [
      [
        { ...pendiente('x', 'RECHAZADA'), motivo: 'Otro motivo' },
        pendiente('y'),
      ],
    ]);

    await service.procesarPendientes(AHORA);
    await service.procesarPendientes(new Date(AHORA.getTime() + 1000));

    expect(crearAviso).toHaveBeenCalledTimes(1);
    expect(warn).toHaveBeenCalledWith(expect.stringContaining('x'));
    expect(avisosPendientes).toHaveBeenLastCalledWith({
      excluir: ['x'],
      lote: 20,
    });
  });

  it('si la conciliación falla, se registra y la revisión ya hecha se mantiene', async () => {
    const error = vi.spyOn(Logger.prototype, 'error');
    const { service, avisosPendientes } = crear([
      lote({ resueltas: [aprobada('a')], tomadas: 1 }),
    ]);
    avisosPendientes.mockReset();
    avisosPendientes.mockRejectedValue(new Error('base caída'));

    await expect(service.procesarPendientes(AHORA)).resolves.toEqual({
      resueltas: 1,
      sinDocumento: 0,
    });
    expect(error).toHaveBeenCalledWith(
      'Falló la conciliación de avisos de verificación; se reintentará.',
      expect.any(String),
    );
  });

  it('también concilia aunque la revisión haya fallado (por ejemplo, fuera de UTC)', async () => {
    const { service, resolverLote, avisosPendientes, crearAviso } = crear(
      undefined,
      [[pendiente('a')]],
    );
    resolverLote.mockReset();
    resolverLote.mockRejectedValue(
      new ZonaHorariaNoUtcError('America/Guatemala'),
    );

    await service.procesarPendientes(AHORA);

    expect(avisosPendientes).toHaveBeenCalledTimes(1);
    expect(crearAviso).toHaveBeenCalledTimes(1);
  });
});
