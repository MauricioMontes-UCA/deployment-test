import { ConflictException, Injectable } from '@nestjs/common';
import { MENSAJES_VERIFICACION } from '@Verificaciones/constants';
import {
  SolicitudVerificacionRepository,
  type SolicitudCreada,
} from '@Verificaciones/repositories';
import type { DocumentoSubido } from '@Verificaciones/types';

/**
 * Carga del documento de identidad (H17, BE-17.1).
 *
 * Se llama `SolicitudesVerificacionService` porque gestiona las solicitudes de
 * verificación; no confundir con `VerificacionService` (también de este
 * módulo), que evalúa si un arrendatario cumple la política para reservar.
 */
@Injectable()
export class SolicitudesVerificacionService {
  constructor(
    private readonly solicitudRepository: SolicitudVerificacionRepository,
  ) {}

  /**
   * Crea la solicitud `EN_REVISION` del usuario con su documento. Queda a la
   * espera de la revisión automática de BE-18.1.
   *
   * Se puede enviar si no hay solicitudes, si la última está `APROBADA`
   * (renovación) o si está `RECHAZADA`: solo bloquea una `EN_REVISION`.
   *
   * @throws {ConflictException} el usuario ya tiene una solicitud
   * `EN_REVISION`, también cuando otro envío simultáneo la creó primero.
   */
  async crear(
    usuarioId: string,
    documento: DocumentoSubido,
  ): Promise<SolicitudCreada> {
    const resultado = await this.solicitudRepository.crearConDocumento(
      usuarioId,
      documento,
    );
    if ('rechazo' in resultado) {
      throw new ConflictException(MENSAJES_VERIFICACION.SOLICITUD_EN_REVISION);
    }
    return resultado.solicitud;
  }
}
