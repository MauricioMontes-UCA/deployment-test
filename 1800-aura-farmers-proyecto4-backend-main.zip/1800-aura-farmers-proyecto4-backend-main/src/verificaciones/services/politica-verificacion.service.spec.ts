import { ForbiddenException, NotFoundException } from '@nestjs/common';
import type { PoliticaVerificacionRepository } from '@Verificaciones/repositories';
import type { EstadoVerificacion } from '@Verificaciones/types';
import type { EstadoVerificacionService } from './estado-verificacion.service.js';
import { PoliticaVerificacionService } from './politica-verificacion.service.js';

const BIEN_ID = '7c9e6679-7425-40de-944b-e07fc1f90ae7';
const DUENO = '29bda5e8-e0c8-4ec2-bc7f-94c41c3c0140';
const OTRO = '5d1e2f3a-4b5c-4d6e-8f70-8192a3b4c5d6';

function crear({
  bien = { arrendadorId: DUENO, soloVerificados: false },
  estado = 'VERIFICADO',
}: {
  bien?: { arrendadorId: string; soloVerificados: boolean } | null;
  estado?: EstadoVerificacion;
} = {}) {
  const findBien = vi.fn().mockResolvedValue(bien);
  const guardar = vi.fn((bienId: string, soloVerificados: boolean) =>
    Promise.resolve({ bienId, soloVerificados }),
  );
  const obtener = vi.fn().mockResolvedValue({
    estado,
    motivo: null,
    solicitudId: null,
    revisadoEn: null,
  });
  const service = new PoliticaVerificacionService(
    { findBien, guardar } as unknown as PoliticaVerificacionRepository,
    { obtener } as unknown as EstadoVerificacionService,
  );
  return { service, findBien, guardar, obtener };
}

describe('PoliticaVerificacionService.consultar', () => {
  it('sin registro de política devuelve soloVerificados false', async () => {
    const { service, findBien } = crear();

    await expect(service.consultar(BIEN_ID)).resolves.toEqual({
      bienId: BIEN_ID,
      soloVerificados: false,
    });
    expect(findBien).toHaveBeenCalledWith(BIEN_ID);
  });

  it('con política guardada devuelve el valor almacenado', async () => {
    const { service } = crear({
      bien: { arrendadorId: DUENO, soloVerificados: true },
    });

    await expect(service.consultar(BIEN_ID)).resolves.toEqual({
      bienId: BIEN_ID,
      soloVerificados: true,
    });
  });

  it('no exige propiedad ni verificación', async () => {
    const { service, obtener } = crear({
      bien: { arrendadorId: OTRO, soloVerificados: true },
      estado: 'NO_VERIFICADO',
    });

    await service.consultar(BIEN_ID);

    expect(obtener).not.toHaveBeenCalled();
  });

  it('responde 404 si el bien no existe', async () => {
    const { service } = crear({ bien: null });

    await expect(service.consultar(BIEN_ID)).rejects.toThrow(
      new NotFoundException('El bien no existe.'),
    );
  });
});

describe('PoliticaVerificacionService.actualizar', () => {
  it('responde 404 si el bien no existe, sin consultar verificación ni guardar', async () => {
    const { service, obtener, guardar } = crear({ bien: null });

    await expect(service.actualizar(BIEN_ID, DUENO, true)).rejects.toThrow(
      new NotFoundException('El bien no existe.'),
    );
    expect(obtener).not.toHaveBeenCalled();
    expect(guardar).not.toHaveBeenCalled();
  });

  it('responde 403 si el bien es de otro arrendador, sin consultar verificación ni guardar', async () => {
    const { service, obtener, guardar } = crear({
      bien: { arrendadorId: OTRO, soloVerificados: false },
    });

    await expect(service.actualizar(BIEN_ID, DUENO, true)).rejects.toThrow(
      new ForbiddenException('El bien no es tuyo.'),
    );
    expect(obtener).not.toHaveBeenCalled();
    expect(guardar).not.toHaveBeenCalled();
  });

  it.each(['NO_VERIFICADO', 'EN_REVISION', 'RECHAZADO'] as const)(
    'responde 403 al activar con estado %s, sin guardar',
    async (estado) => {
      const { service, obtener, guardar } = crear({ estado });

      await expect(service.actualizar(BIEN_ID, DUENO, true)).rejects.toThrow(
        new ForbiddenException(
          'Debes estar verificado para exigir usuarios verificados.',
        ),
      );
      expect(obtener).toHaveBeenCalledWith(DUENO);
      expect(guardar).not.toHaveBeenCalled();
    },
  );

  it('activa estando VERIFICADO y devuelve lo guardado', async () => {
    const { service, guardar } = crear();

    await expect(service.actualizar(BIEN_ID, DUENO, true)).resolves.toEqual({
      bienId: BIEN_ID,
      soloVerificados: true,
    });
    expect(guardar).toHaveBeenCalledWith(BIEN_ID, true);
  });

  it('desactivar está permitido sin estar verificado y no consulta el estado', async () => {
    const { service, obtener, guardar } = crear({
      bien: { arrendadorId: DUENO, soloVerificados: true },
      estado: 'NO_VERIFICADO',
    });

    await expect(service.actualizar(BIEN_ID, DUENO, false)).resolves.toEqual({
      bienId: BIEN_ID,
      soloVerificados: false,
    });
    expect(obtener).not.toHaveBeenCalled();
    expect(guardar).toHaveBeenCalledWith(BIEN_ID, false);
  });

  it('activar una política ya activa vuelve a exigir verificación', async () => {
    const { service, obtener } = crear({
      bien: { arrendadorId: DUENO, soloVerificados: true },
      estado: 'EN_REVISION',
    });

    await expect(service.actualizar(BIEN_ID, DUENO, true)).rejects.toThrow(
      ForbiddenException,
    );
    expect(obtener).toHaveBeenCalledTimes(1);
  });

  it('si el bien deja de existir antes de guardar, responde 404', async () => {
    const { service, guardar } = crear();
    guardar.mockResolvedValueOnce(null as never);

    await expect(service.actualizar(BIEN_ID, DUENO, false)).rejects.toThrow(
      new NotFoundException('El bien no existe.'),
    );
  });
});
