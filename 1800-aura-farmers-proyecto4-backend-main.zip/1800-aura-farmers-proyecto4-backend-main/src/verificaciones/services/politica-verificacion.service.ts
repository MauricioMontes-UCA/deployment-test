import {
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import {
  PoliticaVerificacionRepository,
  type BienConPolitica,
  type PoliticaGuardada,
} from '@Verificaciones/repositories';
import { EstadoVerificacion } from '@Verificaciones/types';
import { EstadoVerificacionService } from './estado-verificacion.service.js';

export const MENSAJES_POLITICA = {
  BIEN_NO_EXISTE: 'El bien no existe.',
  BIEN_AJENO: 'El bien no es tuyo.',
  VERIFICACION_REQUERIDA:
    'Debes estar verificado para exigir usuarios verificados.',
} as const;

/**
 * Política "Solo usuarios verificados" de un bien (H19, BE-19.1).
 *
 * Cambiar la política no toca las reservas: solo se consulta al solicitar o
 * procesar una reserva EN_COLA, así que las CONFIRMADA quedan como están.
 */
@Injectable()
export class PoliticaVerificacionService {
  constructor(
    private readonly politicaRepository: PoliticaVerificacionRepository,
    private readonly estadoVerificacionService: EstadoVerificacionService,
  ) {}

  /**
   * Política de un bien para cualquier usuario autenticado. Sin registro,
   * `soloVerificados` es false.
   *
   * @throws {NotFoundException} el bien no existe.
   */
  async consultar(bienId: string): Promise<PoliticaGuardada> {
    const bien = await this.bienExistente(bienId);
    return { bienId, soloVerificados: bien.soloVerificados };
  }

  /**
   * Activa o desactiva la política de un bien propio. Activarla exige que el
   * arrendador esté VERIFICADO, también si ya estaba activa; desactivarla no.
   * El estado se calcula con la regla de AF-98 (`EstadoVerificacionService`).
   *
   * @throws {NotFoundException} el bien no existe.
   * @throws {ForbiddenException} el bien es de otro arrendador, o se quiere
   * activar sin estar VERIFICADO.
   */
  async actualizar(
    bienId: string,
    arrendadorId: string,
    soloVerificados: boolean,
  ): Promise<PoliticaGuardada> {
    const bien = await this.bienExistente(bienId);
    if (bien.arrendadorId !== arrendadorId) {
      throw new ForbiddenException(MENSAJES_POLITICA.BIEN_AJENO);
    }
    if (soloVerificados) {
      const { estado } =
        await this.estadoVerificacionService.obtener(arrendadorId);
      if (estado !== EstadoVerificacion.VERIFICADO) {
        throw new ForbiddenException(MENSAJES_POLITICA.VERIFICACION_REQUERIDA);
      }
    }

    const guardada = await this.politicaRepository.guardar(
      bienId,
      soloVerificados,
    );
    if (!guardada) {
      throw new NotFoundException(MENSAJES_POLITICA.BIEN_NO_EXISTE);
    }
    return guardada;
  }

  private async bienExistente(bienId: string): Promise<BienConPolitica> {
    const bien = await this.politicaRepository.findBien(bienId);
    if (!bien) throw new NotFoundException(MENSAJES_POLITICA.BIEN_NO_EXISTE);
    return bien;
  }
}
