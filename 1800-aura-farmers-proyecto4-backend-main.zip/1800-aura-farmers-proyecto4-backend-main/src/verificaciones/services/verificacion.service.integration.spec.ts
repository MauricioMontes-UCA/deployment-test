import { randomUUID } from 'node:crypto';
import { PrismaPg } from '@prisma/adapter-pg';
import { EstadoSolicitudVerificacion, PrismaClient, Rol } from '@PrismaClient';
import type { PrismaService } from '@Prisma/services';
import {
  PoliticaVerificacionRepository,
  SolicitudVerificacionRepository,
} from '@Verificaciones/repositories';
import { VerificacionService } from './verificacion.service.js';

const habilitada = process.env.RUN_DB_INTEGRATION === '1';

if (habilitada && !process.env.DATABASE_URL) {
  throw new Error('RUN_DB_INTEGRATION=1 requiere DATABASE_URL configurada.');
}

/** Error para revertir a propósito la transacción de una prueba. */
class Revertir extends Error {}

/**
 * BE-19.2 contra PostgreSQL: `puedeReservar` con la política y las solicitudes
 * reales, la solicitud más reciente (con desempate por id) y la lectura dentro
 * de una transacción en curso.
 */
describe.skipIf(!habilitada)('BE-19.2 - puedeReservar con PostgreSQL', () => {
  let prisma: PrismaClient;
  let service: VerificacionService;
  let arrendadorId = '';
  let arrendatarioId = '';
  let bienId = '';

  const politica = (soloVerificados: boolean) =>
    prisma.politicaVerificacionBien.upsert({
      where: { bienId },
      create: { bienId, soloVerificados },
      update: { soloVerificados },
    });

  const solicitud = (estado: EstadoSolicitudVerificacion, creadaEn?: Date) =>
    prisma.solicitudVerificacion.create({
      data: { usuarioId: arrendatarioId, estado, creadaEn },
      select: { id: true },
    });

  const contar = async () => ({
    politicas: await prisma.politicaVerificacionBien.count({
      where: { bienId },
    }),
    solicitudes: await prisma.solicitudVerificacion.count({
      where: { usuarioId: arrendatarioId },
    }),
  });

  beforeAll(async () => {
    prisma = new PrismaClient({
      adapter: new PrismaPg({ connectionString: process.env.DATABASE_URL! }),
    });
    await prisma.$connect();
    const db = prisma as unknown as PrismaService;
    service = new VerificacionService(
      new PoliticaVerificacionRepository(db),
      new SolicitudVerificacionRepository(db),
    );

    const sufijo = randomUUID().replaceAll('-', '').slice(0, 10);
    const usuario = (prefijo: string, rol: Rol) =>
      prisma.usuario.create({
        data: {
          nombreUsuario: `${prefijo}_${sufijo}`,
          email: `${prefijo}_${sufijo}@example.com`,
          passwordHash: 'hash-prueba',
          rol,
        },
        select: { id: true },
      });
    arrendadorId = (await usuario('verif_pr_arr', Rol.ARRENDADOR)).id;
    arrendatarioId = (await usuario('verif_pr_ten', Rol.ARRENDATARIO)).id;
    bienId = (
      await prisma.bien.create({
        data: {
          arrendadorId,
          tipo: 'PROPIEDAD',
          categoria: 'Casa',
          titulo: `Bien puedeReservar ${sufijo}`,
          descripcion: 'Bien de prueba de integración',
          precio: 50,
          unidadCobro: 'NOCHE',
          departamento: 'San Salvador',
          municipio: 'San Salvador',
        },
        select: { id: true },
      })
    ).id;
  });

  beforeEach(async () => {
    await prisma.politicaVerificacionBien.deleteMany({ where: { bienId } });
    await prisma.solicitudVerificacion.deleteMany({
      where: { usuarioId: arrendatarioId },
    });
  });

  afterAll(async () => {
    try {
      if (arrendatarioId) {
        await prisma.solicitudVerificacion.deleteMany({
          where: { usuarioId: arrendatarioId },
        });
      }
      if (bienId) await prisma.bien.delete({ where: { id: bienId } });
      const usuarios = [arrendadorId, arrendatarioId].filter(Boolean);
      if (usuarios.length > 0) {
        await prisma.usuario.deleteMany({ where: { id: { in: usuarios } } });
      }
    } finally {
      await prisma?.$disconnect();
    }
  });

  it('sin registro de política permite reservar, aunque el arrendatario no esté verificado', async () => {
    await expect(
      service.puedeReservar({ arrendatarioId, bienId }),
    ).resolves.toBe(true);
  });

  it('con la política desactivada permite reservar a un arrendatario rechazado', async () => {
    await politica(false);
    await solicitud('RECHAZADA');

    await expect(
      service.puedeReservar({ arrendatarioId, bienId }),
    ).resolves.toBe(true);
  });

  it.each([
    ['NO_VERIFICADO (sin solicitudes)', null, false],
    ['EN_REVISION', 'EN_REVISION', false],
    ['RECHAZADO', 'RECHAZADA', false],
    ['VERIFICADO', 'APROBADA', true],
  ] as const)(
    'con la política activa y el arrendatario %s devuelve %s',
    async (_estado, estadoSolicitud, esperado) => {
      await politica(true);
      if (estadoSolicitud) await solicitud(estadoSolicitud);

      await expect(
        service.puedeReservar({ arrendatarioId, bienId }),
      ).resolves.toBe(esperado);
    },
  );

  it('decide la solicitud más reciente: una RECHAZADA posterior a una APROBADA impide reservar', async () => {
    await politica(true);
    await solicitud('APROBADA', new Date('2026-11-01T10:00:00.000Z'));
    await solicitud('RECHAZADA', new Date('2026-11-10T10:00:00.000Z'));

    await expect(
      service.puedeReservar({ arrendatarioId, bienId }),
    ).resolves.toBe(false);
  });

  it('una APROBADA posterior a una RECHAZADA permite reservar', async () => {
    await politica(true);
    await solicitud('RECHAZADA', new Date('2026-11-01T10:00:00.000Z'));
    await solicitud('APROBADA', new Date('2026-11-10T10:00:00.000Z'));

    await expect(
      service.puedeReservar({ arrendatarioId, bienId }),
    ).resolves.toBe(true);
  });

  it('con la misma creadaEn desempata por id, siempre igual', async () => {
    await politica(true);
    const misma = new Date('2026-11-10T10:00:00.000Z');
    const a = await solicitud('APROBADA', misma);
    const b = await solicitud('RECHAZADA', misma);
    // PostgreSQL ordena los uuid como su texto en minúsculas.
    const ganadora = a.id > b.id ? 'APROBADA' : 'RECHAZADA';

    for (let i = 0; i < 3; i++) {
      await expect(
        service.puedeReservar({ arrendatarioId, bienId }),
      ).resolves.toBe(ganadora === 'APROBADA');
    }
  });

  it('con tx, ve lo que esa transacción escribió y todavía no confirmó', async () => {
    const antes = await contar();
    let dentro: boolean | undefined;
    let fueraDurante: boolean | undefined;

    await expect(
      prisma.$transaction(async (tx) => {
        await tx.politicaVerificacionBien.create({
          data: { bienId, soloVerificados: true },
        });
        await tx.solicitudVerificacion.create({
          data: { usuarioId: arrendatarioId, estado: 'APROBADA' },
        });

        dentro = await service.puedeReservar({ arrendatarioId, bienId }, tx);
        // Fuera de la transacción todavía no hay política: se permite.
        fueraDurante = await service.puedeReservar({ arrendatarioId, bienId });
        throw new Revertir();
      }),
    ).rejects.toBeInstanceOf(Revertir);

    expect(dentro).toBe(true);
    expect(fueraDurante).toBe(true);
    expect(await contar()).toEqual(antes);
  });

  it('con tx, una RECHAZADA escrita en la transacción ya cuenta como la más reciente', async () => {
    await politica(true);
    await solicitud('APROBADA', new Date('2026-11-01T10:00:00.000Z'));
    let dentro: boolean | undefined;

    await expect(
      prisma.$transaction(async (tx) => {
        await tx.solicitudVerificacion.create({
          data: { usuarioId: arrendatarioId, estado: 'RECHAZADA' },
        });
        dentro = await service.puedeReservar({ arrendatarioId, bienId }, tx);
        throw new Revertir();
      }),
    ).rejects.toBeInstanceOf(Revertir);

    expect(dentro).toBe(false);
    // Revertida la transacción, vuelve a contar la APROBADA.
    await expect(
      service.puedeReservar({ arrendatarioId, bienId }),
    ).resolves.toBe(true);
  });

  it('con la política activa y el arrendatario sin verificar devuelve false: cada id va a su consulta', async () => {
    // Si los ids se intercambiaran, la política se buscaría con el id del
    // arrendatario, que no tiene ninguna, y el resultado sería true.
    await politica(true);
    expect(arrendatarioId).not.toBe(bienId);
    const db = prisma as unknown as PrismaService;
    const politicaRepository = new PoliticaVerificacionRepository(db);
    const solicitudRepository = new SolicitudVerificacionRepository(db);
    const leerPolitica = vi.spyOn(politicaRepository, 'soloVerificados');
    const leerSolicitud = vi.spyOn(solicitudRepository, 'findUltimaDeUsuario');
    const conEspias = new VerificacionService(
      politicaRepository,
      solicitudRepository,
    );

    await expect(
      conEspias.puedeReservar({ arrendatarioId, bienId }),
    ).resolves.toBe(false);
    // El orden de las propiedades no cambia nada.
    await expect(
      conEspias.puedeReservar({ bienId, arrendatarioId }),
    ).resolves.toBe(false);

    for (const llamada of leerPolitica.mock.calls) {
      expect(llamada[0]).toBe(bienId);
    }
    for (const llamada of leerSolicitud.mock.calls) {
      expect(llamada[0]).toBe(arrendatarioId);
    }
    expect(leerPolitica).toHaveBeenCalledTimes(2);
    expect(leerSolicitud).toHaveBeenCalledTimes(2);
  });

  it('solo lee: no crea, cambia ni duplica registros', async () => {
    await politica(true);
    await solicitud('APROBADA');
    const antes = await contar();
    const politicaAntes = await prisma.politicaVerificacionBien.findUnique({
      where: { bienId },
    });

    for (let i = 0; i < 3; i++) {
      await service.puedeReservar({ arrendatarioId, bienId });
    }

    expect(await contar()).toEqual(antes);
    expect(
      await prisma.politicaVerificacionBien.findUnique({ where: { bienId } }),
    ).toEqual(politicaAntes);
  });
});
