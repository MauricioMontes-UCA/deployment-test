import { ConflictException } from '@nestjs/common';
import type { SolicitudVerificacionRepository } from '@Verificaciones/repositories';
import type { DocumentoSubido } from '@Verificaciones/types';
import { SolicitudesVerificacionService } from './solicitudes-verificacion.service.js';

const USUARIO_ID = '29bda5e8-e0c8-4ec2-bc7f-94c41c3c0140';

const documento: DocumentoSubido = {
  nombreArchivo: 'dui.jpg',
  contenido: Buffer.from([0xff, 0xd8, 0xff]),
  mimeType: 'image/jpeg',
  tamanoBytes: 3,
};

const solicitud = {
  id: '5d8e1f2a-7b9c-4d3e-a1b2-c3d4e5f60718',
  estado: 'EN_REVISION' as const,
  creadaEn: new Date('2026-11-16T15:00:00.000Z'),
};

function crear() {
  const crearConDocumento = vi.fn().mockResolvedValue({ solicitud });
  const service = new SolicitudesVerificacionService({
    crearConDocumento,
  } as unknown as SolicitudVerificacionRepository);
  return { service, crearConDocumento };
}

describe('SolicitudesVerificacionService.crear', () => {
  it('crea la solicitud del usuario con su documento y la devuelve', async () => {
    const { service, crearConDocumento } = crear();

    await expect(service.crear(USUARIO_ID, documento)).resolves.toEqual(
      solicitud,
    );
    expect(crearConDocumento).toHaveBeenCalledWith(USUARIO_ID, documento);
  });

  it('responde 409 si el usuario ya tiene una solicitud EN_REVISION', async () => {
    const { service, crearConDocumento } = crear();
    crearConDocumento.mockResolvedValue({ rechazo: 'EN_REVISION_EXISTENTE' });

    const error = await service.crear(USUARIO_ID, documento).catch((e) => e);

    expect(error).toBeInstanceOf(ConflictException);
    expect((error as ConflictException).message).toBe(
      'Ya tienes un documento en revisión.',
    );
  });

  it('no hace una consulta previa: la unicidad la decide la base', async () => {
    const { service, crearConDocumento } = crear();

    await service.crear(USUARIO_ID, documento);

    expect(crearConDocumento).toHaveBeenCalledTimes(1);
  });

  it('propaga un error inesperado del repositorio', async () => {
    const { service, crearConDocumento } = crear();
    const fallo = new Error('base caída');
    crearConDocumento.mockRejectedValue(fallo);

    await expect(service.crear(USUARIO_ID, documento)).rejects.toBe(fallo);
  });
});
