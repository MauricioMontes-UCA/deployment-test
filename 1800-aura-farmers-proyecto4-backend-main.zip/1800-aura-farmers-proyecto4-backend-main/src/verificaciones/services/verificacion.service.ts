import { Injectable } from '@nestjs/common';
import type { Prisma } from '@PrismaClient';
import {
  PoliticaVerificacionRepository,
  SolicitudVerificacionRepository,
} from '@Verificaciones/repositories';
import { EstadoVerificacion } from '@Verificaciones/types';
import { derivarEstadoVerificacion } from '@Verificaciones/utils';

/**
 * Datos de `puedeReservar`, con nombre.
 *
 * Los dos son UUID de tipo `string`: con argumentos posicionales, un orden
 * invertido compilaría y leería la política con el id del arrendatario, que no
 * tiene ninguna, así que dejaría reservar a cualquiera. Con un objeto, el
 * orden de las propiedades da igual y una llamada posicional no compila.
 */
export interface ConsultaPuedeReservar {
  arrendatarioId: string;
  bienId: string;
}

/**
 * Política "Solo usuarios verificados" aplicada a las reservas (H19, BE-19.2).
 *
 * `VerificacionesModule` lo exporta para el módulo de reservas, que lo usa al
 * encolar una solicitud y otra vez al procesarla: la verificación puede
 * revocarse entre ambos momentos.
 */
@Injectable()
export class VerificacionService {
  constructor(
    private readonly politicaRepository: PoliticaVerificacionRepository,
    private readonly solicitudRepository: SolicitudVerificacionRepository,
  ) {}

  /**
   * Indica si el arrendatario puede reservar el bien:
   * - si el bien no tiene la política activa (o no tiene registro), siempre;
   * - si la tiene, solo si el arrendatario está VERIFICADO, es decir, si su
   *   solicitud de verificación más reciente está APROBADA (la regla de
   *   BE-17.2, sin duplicarla).
   *
   * Con la política inactiva no consulta el estado del arrendatario. No mira si
   * el bien existe ni su estado: eso lo valida quien llama.
   *
   * `tx` es la transacción en curso de quien llama (el procesador de la cola):
   * si se pasa, las dos lecturas se hacen con ese mismo cliente; si no, con el
   * pool. Nunca abre una transacción propia.
   */
  async puedeReservar(
    { arrendatarioId, bienId }: ConsultaPuedeReservar,
    tx?: Prisma.TransactionClient,
  ): Promise<boolean> {
    if (!(await this.politicaRepository.soloVerificados(bienId, tx))) {
      return true;
    }
    const ultima = await this.solicitudRepository.findUltimaDeUsuario(
      arrendatarioId,
      tx,
    );
    return (
      derivarEstadoVerificacion(ultima).estado === EstadoVerificacion.VERIFICADO
    );
  }
}
