import type { SolicitudVerificacionRepository } from '@Verificaciones/repositories';
import { EstadoVerificacionService } from './estado-verificacion.service.js';

const USUARIO_ID = '29bda5e8-e0c8-4ec2-bc7f-94c41c3c0140';

function crear(ultima: unknown = null) {
  const findUltimaDeUsuario = vi.fn().mockResolvedValue(ultima);
  const service = new EstadoVerificacionService({
    findUltimaDeUsuario,
  } as unknown as SolicitudVerificacionRepository);
  return { service, findUltimaDeUsuario };
}

describe('EstadoVerificacionService.obtener', () => {
  it('consulta la solicitud más reciente del usuario indicado', async () => {
    const { service, findUltimaDeUsuario } = crear();

    await service.obtener(USUARIO_ID);

    expect(findUltimaDeUsuario).toHaveBeenCalledTimes(1);
    expect(findUltimaDeUsuario).toHaveBeenCalledWith(USUARIO_ID);
  });

  it('sin solicitudes devuelve NO_VERIFICADO', async () => {
    const { service } = crear(null);

    await expect(service.obtener(USUARIO_ID)).resolves.toEqual({
      estado: 'NO_VERIFICADO',
      motivo: null,
      solicitudId: null,
      revisadoEn: null,
    });
  });

  it('deriva el estado de la solicitud que devuelve el repositorio', async () => {
    const revisadoEn = new Date('2026-11-16T15:00:10.000Z');
    const { service } = crear({
      id: 'solicitud-1',
      estado: 'RECHAZADA',
      motivo: 'Documento no válido (revisión simulada).',
      revisadoEn,
    });

    await expect(service.obtener(USUARIO_ID)).resolves.toEqual({
      estado: 'RECHAZADO',
      motivo: 'Documento no válido (revisión simulada).',
      solicitudId: 'solicitud-1',
      revisadoEn,
    });
  });

  it('propaga un error del repositorio', async () => {
    const { service, findUltimaDeUsuario } = crear();
    const fallo = new Error('base caída');
    findUltimaDeUsuario.mockRejectedValue(fallo);

    await expect(service.obtener(USUARIO_ID)).rejects.toBe(fallo);
  });
});
