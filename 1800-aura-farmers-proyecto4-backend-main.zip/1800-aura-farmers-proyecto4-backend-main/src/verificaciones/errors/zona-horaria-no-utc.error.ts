/**
 * La sesión de PostgreSQL no está en UTC: la revisión simulada no puede medir
 * la espera de 10 segundos con su reloj sin desfasarse, así que no procesa
 * nada (BE-18.1).
 */
export class ZonaHorariaNoUtcError extends Error {
  constructor(readonly zonaHoraria: string) {
    super(
      `La sesión de PostgreSQL usa la zona horaria "${zonaHoraria}" y la revisión simulada de documentos requiere UTC: no se procesó ninguna solicitud. Configura PostgreSQL con timezone = 'UTC'.`,
    );
    this.name = 'ZonaHorariaNoUtcError';
  }
}
