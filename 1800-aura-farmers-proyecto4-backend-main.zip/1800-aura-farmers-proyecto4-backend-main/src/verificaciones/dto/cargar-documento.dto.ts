import { ApiProperty } from '@nestjs/swagger';
import { MAX_DOCUMENTO_MB } from '@Verificaciones/constants';

/**
 * Formulario multipart de `POST /verificaciones`, solo para Swagger.
 *
 * El archivo no pasa por el ValidationPipe: lo valida
 * `DocumentoVerificacionPipe`.
 */
export class CargarDocumentoFormDto {
  @ApiProperty({
    description: `Documento de identidad JPG, PNG o PDF de hasta ${MAX_DOCUMENTO_MB} MB. El formato se valida por el contenido del archivo, no por su extensión.`,
    type: 'string',
    format: 'binary',
  })
  documento!: unknown;
}
