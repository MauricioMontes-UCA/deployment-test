import { ApiProperty } from '@nestjs/swagger';
import { IsBoolean } from 'class-validator';

/**
 * Cuerpo de `PUT /bienes/:bienId/politica-verificacion`.
 *
 * Solo acepta un booleano JSON: "true" como texto, 1 o null responden 400
 * (el ValidationPipe global no convierte tipos implícitamente).
 */
export class ActualizarPoliticaVerificacionDto {
  @ApiProperty({
    example: true,
    description:
      'true: el bien solo acepta solicitudes de usuarios VERIFICADO. Activarla exige que el arrendador esté VERIFICADO.',
  })
  @IsBoolean({ message: 'soloVerificados debe ser true o false.' })
  soloVerificados!: boolean;
}
