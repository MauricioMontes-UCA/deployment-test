import { ApiProperty } from '@nestjs/swagger';
import type { PoliticaGuardada } from '@Verificaciones/repositories';

/** Política "Solo usuarios verificados" de un bien. */
export class PoliticaVerificacionResponseDto {
  @ApiProperty({
    format: 'uuid',
    example: '7c9e6679-7425-40de-944b-e07fc1f90ae7',
  })
  bienId!: string;

  @ApiProperty({
    example: true,
    description: 'false si el bien no tiene la política registrada.',
  })
  soloVerificados!: boolean;

  static from(politica: PoliticaGuardada): PoliticaVerificacionResponseDto {
    return {
      bienId: politica.bienId,
      soloVerificados: politica.soloVerificados,
    };
  }
}
