import { plainToInstance } from 'class-transformer';
import { validate } from 'class-validator';
import { ActualizarPoliticaVerificacionDto } from './actualizar-politica-verificacion.dto.js';

/** Igual que el ValidationPipe global: transforma, pero sin conversión implícita. */
async function errores(cuerpo: unknown): Promise<string[]> {
  const dto = plainToInstance(ActualizarPoliticaVerificacionDto, cuerpo);
  const resultado = await validate(dto as object, {
    whitelist: true,
    forbidNonWhitelisted: true,
  });
  return resultado.flatMap((e) => Object.values(e.constraints ?? {}));
}

describe('ActualizarPoliticaVerificacionDto', () => {
  it.each([true, false])('acepta %s', async (valor) => {
    expect(await errores({ soloVerificados: valor })).toEqual([]);
  });

  it.each([
    ['el texto "true"', { soloVerificados: 'true' }],
    ['1', { soloVerificados: 1 }],
    ['null', { soloVerificados: null }],
    ['un cuerpo sin el campo', {}],
  ])('rechaza %s', async (_caso, cuerpo) => {
    expect(await errores(cuerpo)).toContain(
      'soloVerificados debe ser true o false.',
    );
  });

  it('rechaza campos de más', async () => {
    expect(await errores({ soloVerificados: true, bienId: 'otro' })).toContain(
      'property bienId should not exist',
    );
  });
});
