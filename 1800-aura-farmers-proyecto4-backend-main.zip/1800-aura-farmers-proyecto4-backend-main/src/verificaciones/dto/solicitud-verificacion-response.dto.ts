import { ApiProperty } from '@nestjs/swagger';
import { EstadoSolicitudVerificacion } from '@PrismaClient';
import type { SolicitudCreada } from '@Verificaciones/repositories';

/**
 * Solicitud de verificación recién creada. No incluye el documento, su
 * nombre ni ningún otro dato del archivo.
 */
export class SolicitudVerificacionResponseDto {
  @ApiProperty({
    format: 'uuid',
    example: '5d8e1f2a-7b9c-4d3e-a1b2-c3d4e5f60718',
  })
  id!: string;

  @ApiProperty({
    enum: EstadoSolicitudVerificacion,
    example: EstadoSolicitudVerificacion.EN_REVISION,
  })
  estado!: EstadoSolicitudVerificacion;

  @ApiProperty({ type: String, format: 'date-time' })
  creadaEn!: Date;

  static from(solicitud: SolicitudCreada): SolicitudVerificacionResponseDto {
    return {
      id: solicitud.id,
      estado: solicitud.estado,
      creadaEn: solicitud.creadaEn,
    };
  }
}
