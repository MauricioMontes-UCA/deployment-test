import { ApiProperty } from '@nestjs/swagger';
import {
  EstadoVerificacion,
  type EstadoVerificacionUsuario,
} from '@Verificaciones/types';

/**
 * Estado de verificación del usuario autenticado. Las cuatro propiedades están
 * siempre presentes; las que no aplican van en `null`. Nunca incluye el
 * documento ni su nombre.
 */
export class EstadoVerificacionResponseDto {
  @ApiProperty({
    enum: Object.values(EstadoVerificacion),
    example: EstadoVerificacion.RECHAZADO,
    description:
      'Se deriva de la solicitud más reciente: sin solicitudes NO_VERIFICADO; EN_REVISION, APROBADA (VERIFICADO) o RECHAZADA (RECHAZADO).',
  })
  estado!: EstadoVerificacion;

  @ApiProperty({
    type: String,
    nullable: true,
    example: 'Documento no válido (revisión simulada).',
    description: 'Motivo del rechazo. Nulo si el estado no es RECHAZADO.',
  })
  motivo!: string | null;

  @ApiProperty({
    type: String,
    format: 'uuid',
    nullable: true,
    example: '5d8e1f2a-7b9c-4d3e-a1b2-c3d4e5f60718',
    description: 'Solicitud más reciente. Nulo si es NO_VERIFICADO.',
  })
  solicitudId!: string | null;

  @ApiProperty({
    type: String,
    format: 'date-time',
    nullable: true,
    description: 'Fecha y hora de la revisión. Nulo si aún no se revisó.',
  })
  revisadoEn!: Date | null;

  static from(
    estado: EstadoVerificacionUsuario,
  ): EstadoVerificacionResponseDto {
    return {
      estado: estado.estado,
      motivo: estado.motivo,
      solicitudId: estado.solicitudId,
      revisadoEn: estado.revisadoEn,
    };
  }
}
