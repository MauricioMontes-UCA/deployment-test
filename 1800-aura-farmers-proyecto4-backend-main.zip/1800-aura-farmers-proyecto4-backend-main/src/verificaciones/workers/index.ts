export * from './revision-simulada.worker.js';
