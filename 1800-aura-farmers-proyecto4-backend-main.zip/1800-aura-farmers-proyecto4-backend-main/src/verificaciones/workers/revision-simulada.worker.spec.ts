import { ConfigService } from '@nestjs/config';
import { SchedulerRegistry, ScheduleModule } from '@nestjs/schedule';
import { Test } from '@nestjs/testing';
import type { EnvConfig } from '@Config';
import { NOMBRE_CRON_REVISION_SIMULADA } from '@Verificaciones/constants';
import { RevisionSimuladaService } from '@Verificaciones/services';
import { RevisionSimuladaWorker } from './revision-simulada.worker.js';

function crear(activo: boolean) {
  const procesarPendientes = vi
    .fn()
    .mockResolvedValue({ resueltas: 0, sinDocumento: 0 });
  const get = vi.fn().mockReturnValue(activo);
  const worker = new RevisionSimuladaWorker(
    { procesarPendientes } as unknown as RevisionSimuladaService,
    { get } as unknown as ConfigService<EnvConfig, true>,
  );
  return { worker, procesarPendientes, get };
}

describe('RevisionSimuladaWorker', () => {
  it('con el interruptor apagado no revisa nada', async () => {
    const { worker, procesarPendientes, get } = crear(false);

    await worker.revisar();

    expect(get).toHaveBeenCalledWith('REVISION_VERIFICACION_ACTIVA', {
      infer: true,
    });
    expect(procesarPendientes).not.toHaveBeenCalled();
  });

  it('con el interruptor encendido procesa lo pendiente', async () => {
    const { worker, procesarPendientes } = crear(true);

    await worker.revisar();

    expect(procesarPendientes).toHaveBeenCalledTimes(1);
  });

  it('se registra como cron de 10 segundos que espera a que termine la corrida', async () => {
    const modulo = await Test.createTestingModule({
      imports: [ScheduleModule.forRoot()],
      providers: [
        RevisionSimuladaWorker,
        { provide: RevisionSimuladaService, useValue: {} },
        { provide: ConfigService, useValue: { get: () => false } },
      ],
    }).compile();
    await modulo.init();

    try {
      const job = modulo
        .get(SchedulerRegistry)
        .getCronJob(NOMBRE_CRON_REVISION_SIMULADA);
      expect(job.cronTime.source).toBe('*/10 * * * * *');
    } finally {
      await modulo.close();
    }
  });
});
