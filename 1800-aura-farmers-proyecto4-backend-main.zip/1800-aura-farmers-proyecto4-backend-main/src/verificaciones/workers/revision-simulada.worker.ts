import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Cron } from '@nestjs/schedule';
import type { EnvConfig } from '@Config';
import {
  CRON_REVISION_SIMULADA,
  NOMBRE_CRON_REVISION_SIMULADA,
} from '@Verificaciones/constants';
import { RevisionSimuladaService } from '@Verificaciones/services';

/**
 * Dispara la revisión simulada de documentos cada 10 segundos (BE-18.1).
 *
 * `REVISION_VERIFICACION_ACTIVA` decide si este proceso revisa: está activa
 * por defecto fuera de las pruebas, se apaga con false, y con NODE_ENV=test
 * siempre es false. La base es la fuente de verdad: tras un reinicio, el
 * primer cron toma lo que quedó pendiente.
 */
@Injectable()
export class RevisionSimuladaWorker {
  constructor(
    private readonly revisionService: RevisionSimuladaService,
    private readonly config: ConfigService<EnvConfig, true>,
  ) {}

  /** `waitForCompletion`: el cron no vuelve a dispararse mientras corre. */
  @Cron(CRON_REVISION_SIMULADA, {
    name: NOMBRE_CRON_REVISION_SIMULADA,
    waitForCompletion: true,
  })
  async revisar(): Promise<void> {
    if (!this.activo()) return;
    await this.revisionService.procesarPendientes();
  }

  private activo(): boolean {
    return this.config.get('REVISION_VERIFICACION_ACTIVA', { infer: true });
  }
}
