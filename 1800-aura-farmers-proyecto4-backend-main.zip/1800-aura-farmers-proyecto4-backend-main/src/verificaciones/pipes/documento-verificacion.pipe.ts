import {
  BadRequestException,
  Injectable,
  PayloadTooLargeException,
  UnsupportedMediaTypeException,
  type PipeTransform,
} from '@nestjs/common';
import {
  MAX_DOCUMENTO_BYTES,
  MAX_LARGO_NOMBRE_ARCHIVO,
  MENSAJES_VERIFICACION,
} from '@Verificaciones/constants';
import type { DocumentoSubido } from '@Verificaciones/types';
import {
  detectarFormatoDocumento,
  largoEnCaracteres,
  limpiarNombreArchivo,
} from '@Verificaciones/utils';

/**
 * Valida el documento que dejó `DocumentoVerificacionInterceptor` y lo
 * convierte en `DocumentoSubido`.
 *
 * Orden de las comprobaciones, todas antes de mirar si el usuario ya tiene una
 * solicitud en revisión:
 * 1. Falta el archivo: 400.
 * 2. Supera 5 MB: 413. Multer ya lo corta; se repite aquí para que el pipe no
 *    dependa de cómo se configuró el interceptor.
 * 3. Está vacío o su firma no es JPG, PNG ni PDF: 415. El formato se detecta
 *    por los primeros bytes, no por la extensión ni por el `Content-Type`.
 * 4. El nombre original, sin rutas, queda vacío o supera 255 caracteres: 400.
 */
@Injectable()
export class DocumentoVerificacionPipe implements PipeTransform<
  Express.Multer.File | undefined,
  DocumentoSubido
> {
  transform(archivo: Express.Multer.File | undefined): DocumentoSubido {
    if (!archivo) {
      throw new BadRequestException([MENSAJES_VERIFICACION.DOCUMENTO_FALTANTE]);
    }

    const contenido = archivo.buffer;
    if (contenido.length > MAX_DOCUMENTO_BYTES) {
      throw new PayloadTooLargeException(
        MENSAJES_VERIFICACION.DOCUMENTO_DEMASIADO_GRANDE,
      );
    }
    if (contenido.length === 0) {
      throw new UnsupportedMediaTypeException(
        MENSAJES_VERIFICACION.DOCUMENTO_VACIO,
      );
    }

    const mimeType = detectarFormatoDocumento(contenido);
    if (!mimeType) {
      throw new UnsupportedMediaTypeException(
        MENSAJES_VERIFICACION.FORMATO_NO_PERMITIDO,
      );
    }

    const nombreArchivo = limpiarNombreArchivo(archivo.originalname);
    if (nombreArchivo === '') {
      throw new BadRequestException([MENSAJES_VERIFICACION.NOMBRE_VACIO]);
    }
    if (largoEnCaracteres(nombreArchivo) > MAX_LARGO_NOMBRE_ARCHIVO) {
      throw new BadRequestException([
        MENSAJES_VERIFICACION.NOMBRE_DEMASIADO_LARGO,
      ]);
    }

    return {
      nombreArchivo,
      contenido,
      mimeType,
      tamanoBytes: contenido.length,
    };
  }
}
