import {
  BadRequestException,
  PayloadTooLargeException,
  UnsupportedMediaTypeException,
} from '@nestjs/common';
import { MAX_DOCUMENTO_BYTES } from '@Verificaciones/constants';
import { DocumentoVerificacionPipe } from './documento-verificacion.pipe.js';

const JPG = Buffer.from([0xff, 0xd8, 0xff, 0xe0, 0x00, 0x10]);
const PNG = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00]);
const PDF = Buffer.from('%PDF-1.7\n');
const GIF = Buffer.from('GIF89a\x00\x00', 'latin1');

/** Archivo como lo deja multer en memoria. */
function archivo(
  buffer: Buffer,
  {
    originalname = 'dui.jpg',
    mimetype = 'image/jpeg',
  }: { originalname?: string; mimetype?: string } = {},
): Express.Multer.File {
  return {
    fieldname: 'documento',
    originalname,
    encoding: '7bit',
    mimetype,
    size: buffer.length,
    buffer,
  } as Express.Multer.File;
}

const pipe = new DocumentoVerificacionPipe();

/** Ejecuta el pipe y devuelve la excepción que lanza. */
function fallo(entrada: Express.Multer.File | undefined): unknown {
  try {
    pipe.transform(entrada);
  } catch (error) {
    return error;
  }
  throw new Error('El pipe no lanzó ninguna excepción.');
}

function mensaje(error: unknown): unknown {
  return (error as BadRequestException).getResponse() as {
    message: unknown;
  };
}

describe('DocumentoVerificacionPipe', () => {
  it.each([
    ['JPG', JPG, 'image/jpeg'],
    ['PNG', PNG, 'image/png'],
    ['PDF', PDF, 'application/pdf'],
  ])('acepta un %s y devuelve el tipo detectado', (_f, buffer, mimeType) => {
    const documento = pipe.transform(
      archivo(buffer, { originalname: 'cédula.x' }),
    );

    expect(documento).toEqual({
      nombreArchivo: 'cédula.x',
      contenido: buffer,
      mimeType,
      tamanoBytes: buffer.length,
    });
  });

  it('responde 400 si falta el archivo', () => {
    const error = fallo(undefined);

    expect(error).toBeInstanceOf(BadRequestException);
    expect(mensaje(error)).toMatchObject({
      message: ['Debes adjuntar el documento en el campo documento.'],
    });
  });

  it('responde 413 si el archivo supera 5 MB', () => {
    const error = fallo(archivo(Buffer.alloc(MAX_DOCUMENTO_BYTES + 1, 0xff)));

    expect(error).toBeInstanceOf(PayloadTooLargeException);
    expect(mensaje(error)).toMatchObject({
      message: 'El archivo supera 5 MB.',
    });
  });

  it('acepta un archivo de exactamente 5 MB', () => {
    const buffer = Buffer.concat([
      JPG,
      Buffer.alloc(MAX_DOCUMENTO_BYTES - JPG.length),
    ]);

    expect(pipe.transform(archivo(buffer)).tamanoBytes).toBe(
      MAX_DOCUMENTO_BYTES,
    );
  });

  it('responde 415 si el archivo está vacío', () => {
    const error = fallo(archivo(Buffer.alloc(0)));

    expect(error).toBeInstanceOf(UnsupportedMediaTypeException);
    expect(mensaje(error)).toMatchObject({
      message: 'El archivo está vacío. Usa JPG, PNG o PDF.',
    });
  });

  it('responde 415 si la firma no es JPG, PNG ni PDF', () => {
    const error = fallo(archivo(GIF, { originalname: 'animacion.gif' }));

    expect(error).toBeInstanceOf(UnsupportedMediaTypeException);
    expect(mensaje(error)).toMatchObject({
      message: 'Formato no permitido. Usa JPG, PNG o PDF.',
    });
  });

  it('no se deja engañar por la extensión ni por el Content-Type', () => {
    const error = fallo(
      archivo(GIF, { originalname: 'dui.jpg', mimetype: 'image/jpeg' }),
    );

    expect(error).toBeInstanceOf(UnsupportedMediaTypeException);
  });

  it('guarda el tipo real aunque el cliente declare otro', () => {
    const documento = pipe.transform(
      archivo(PDF, { originalname: 'dui.png', mimetype: 'image/png' }),
    );

    expect(documento.mimeType).toBe('application/pdf');
  });

  it('guarda el nombre sin rutas', () => {
    const documento = pipe.transform(
      archivo(JPG, { originalname: 'C:\\fakepath\\dui.jpg' }),
    );

    expect(documento.nombreArchivo).toBe('dui.jpg');
  });

  it.each(['', '  ', '..', 'docs/'])(
    'responde 400 si el nombre limpio queda vacío (%j)',
    (originalname) => {
      const error = fallo(archivo(JPG, { originalname }));

      expect(error).toBeInstanceOf(BadRequestException);
      expect(mensaje(error)).toMatchObject({
        message: ['El nombre del archivo no es válido.'],
      });
    },
  );

  it('acepta un nombre de 255 caracteres y rechaza uno de 256', () => {
    const nombre = (largo: number) => `${'a'.repeat(largo - 4)}.jpg`;

    expect(
      pipe.transform(archivo(JPG, { originalname: nombre(255) })).nombreArchivo,
    ).toHaveLength(255);

    const error = fallo(archivo(JPG, { originalname: nombre(256) }));
    expect(error).toBeInstanceOf(BadRequestException);
    expect(mensaje(error)).toMatchObject({
      message: ['El nombre del archivo no puede superar 255 caracteres.'],
    });
  });

  it('cuenta los emojis del nombre como un carácter', () => {
    const nombre = `${'😀'.repeat(251)}.jpg`;

    expect(nombre.length).toBeGreaterThan(255);
    expect(
      pipe.transform(archivo(JPG, { originalname: nombre })).nombreArchivo,
    ).toBe(nombre);
  });

  it('valida el formato antes que el nombre', () => {
    expect(fallo(archivo(GIF, { originalname: '' }))).toBeInstanceOf(
      UnsupportedMediaTypeException,
    );
  });
});
