export * from './documento-verificacion.pipe.js';
