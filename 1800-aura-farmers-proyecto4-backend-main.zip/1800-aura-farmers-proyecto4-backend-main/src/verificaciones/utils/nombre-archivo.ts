/** Caracteres de control (C0 y DEL): no tienen lugar en un nombre de archivo. */
// oxlint-disable-next-line no-control-regex
const CARACTERES_DE_CONTROL = /[\u0000-\u001f\u007f]/g;

/**
 * Nombre original del archivo sin rutas, sin caracteres de control y sin
 * espacios en los extremos.
 *
 * Es el único lugar donde se quita la ruta: el interceptor usa
 * `preservePath: true` para que el nombre llegue tal como lo mandó el
 * cliente. Corta en `/` y en `\`, y un nombre que queda en `.` o `..` se trata
 * como vacío. Puede devolver `''`: decidir qué hacer con eso le toca a quien
 * llama.
 */
export function limpiarNombreArchivo(nombreOriginal: string): string {
  const sinRuta = nombreOriginal.split(/[\\/]/).pop() ?? '';
  const limpio = sinRuta.replace(CARACTERES_DE_CONTROL, '').trim();
  return limpio === '.' || limpio === '..' ? '' : limpio;
}

/**
 * Largo en caracteres, como lo cuenta PostgreSQL en un `VARCHAR`: un emoji
 * cuenta como uno, aunque en JavaScript ocupe dos unidades UTF-16.
 */
export function largoEnCaracteres(texto: string): number {
  let largo = 0;
  for (const _caracter of texto) largo++;
  return largo;
}
