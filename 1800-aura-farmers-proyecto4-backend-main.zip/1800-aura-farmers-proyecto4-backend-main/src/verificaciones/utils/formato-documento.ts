import type { MimeDocumento } from '@Verificaciones/types';

const FIRMA_JPG = Buffer.from([0xff, 0xd8, 0xff]);
const FIRMA_PNG = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);
/** `%PDF-` al inicio del archivo. */
const FIRMA_PDF = Buffer.from([0x25, 0x50, 0x44, 0x46, 0x2d]);

/**
 * Reconoce JPG, PNG y PDF por su firma (magic bytes). Cualquier otro
 * contenido, o un buffer más corto que la firma, da `null`.
 *
 * No mira la extensión ni el `Content-Type`: los decide el cliente y no
 * prueban nada sobre el contenido.
 */
export function detectarFormatoDocumento(buffer: Buffer): MimeDocumento | null {
  if (empiezaCon(buffer, FIRMA_JPG)) return 'image/jpeg';
  if (empiezaCon(buffer, FIRMA_PNG)) return 'image/png';
  if (empiezaCon(buffer, FIRMA_PDF)) return 'application/pdf';
  return null;
}

function empiezaCon(buffer: Buffer, firma: Buffer): boolean {
  return (
    buffer.length >= firma.length &&
    buffer.subarray(0, firma.length).equals(firma)
  );
}
