import type { SolicitudParaEstado } from '@Verificaciones/types';
import { derivarEstadoVerificacion } from './estado-verificacion.js';

const SOLICITUD_ID = '5d8e1f2a-7b9c-4d3e-a1b2-c3d4e5f60718';
const REVISADO_EN = new Date('2026-11-16T15:00:10.000Z');
const MOTIVO = 'Documento no válido (revisión simulada).';

const solicitud = (
  datos: Partial<SolicitudParaEstado>,
): SolicitudParaEstado => ({
  id: SOLICITUD_ID,
  estado: 'EN_REVISION',
  motivo: null,
  revisadoEn: null,
  ...datos,
});

describe('derivarEstadoVerificacion', () => {
  it('sin solicitudes es NO_VERIFICADO y todo lo demás es null', () => {
    expect(derivarEstadoVerificacion(null)).toEqual({
      estado: 'NO_VERIFICADO',
      motivo: null,
      solicitudId: null,
      revisadoEn: null,
    });
  });

  it('una solicitud EN_REVISION da EN_REVISION, sin motivo ni revisión', () => {
    expect(derivarEstadoVerificacion(solicitud({}))).toEqual({
      estado: 'EN_REVISION',
      motivo: null,
      solicitudId: SOLICITUD_ID,
      revisadoEn: null,
    });
  });

  it('una solicitud APROBADA da VERIFICADO con la fecha de revisión', () => {
    expect(
      derivarEstadoVerificacion(
        solicitud({ estado: 'APROBADA', revisadoEn: REVISADO_EN }),
      ),
    ).toEqual({
      estado: 'VERIFICADO',
      motivo: null,
      solicitudId: SOLICITUD_ID,
      revisadoEn: REVISADO_EN,
    });
  });

  it('una solicitud RECHAZADA da RECHAZADO con su motivo y la fecha de revisión', () => {
    expect(
      derivarEstadoVerificacion(
        solicitud({
          estado: 'RECHAZADA',
          motivo: MOTIVO,
          revisadoEn: REVISADO_EN,
        }),
      ),
    ).toEqual({
      estado: 'RECHAZADO',
      motivo: MOTIVO,
      solicitudId: SOLICITUD_ID,
      revisadoEn: REVISADO_EN,
    });
  });

  it('un rechazo sin motivo guardado devuelve motivo null, sin inventar texto', () => {
    expect(
      derivarEstadoVerificacion(solicitud({ estado: 'RECHAZADA' })).motivo,
    ).toBeNull();
  });

  it.each(['EN_REVISION', 'APROBADA'] as const)(
    'no expone un motivo si la solicitud está %s',
    (estado) => {
      expect(
        derivarEstadoVerificacion(solicitud({ estado, motivo: 'viejo' }))
          .motivo,
      ).toBeNull();
    },
  );
});
