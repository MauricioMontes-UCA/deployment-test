import { largoEnCaracteres, limpiarNombreArchivo } from './nombre-archivo.js';

describe('limpiarNombreArchivo', () => {
  it('conserva un nombre simple, con acentos y espacios internos', () => {
    expect(limpiarNombreArchivo('cédula de identidad.pdf')).toBe(
      'cédula de identidad.pdf',
    );
  });

  it.each([
    ['/home/ana/docs/dui.png', 'dui.png'],
    ['C:\\fakepath\\dui.png', 'dui.png'],
    ['../../etc/passwd.jpg', 'passwd.jpg'],
    ['carpeta/sub\\dui.jpg', 'dui.jpg'],
  ])('quita la ruta de %s', (original, esperado) => {
    expect(limpiarNombreArchivo(original)).toBe(esperado);
  });

  it('quita caracteres de control y espacios en los extremos', () => {
    expect(limpiarNombreArchivo('  dui\u0000\r\n.jpg\u007f  ')).toBe('dui.jpg');
  });

  it.each(['', '   ', '.', '..', 'docs/', 'C:\\fakepath\\', '\u0000\u001f'])(
    'deja vacío el nombre %j',
    (original) => {
      expect(limpiarNombreArchivo(original)).toBe('');
    },
  );
});

describe('largoEnCaracteres', () => {
  it('cuenta un emoji como un carácter, igual que PostgreSQL', () => {
    expect('😀'.length).toBe(2);
    expect(largoEnCaracteres('😀')).toBe(1);
    expect(largoEnCaracteres('dué.pdf')).toBe(7);
  });
});
