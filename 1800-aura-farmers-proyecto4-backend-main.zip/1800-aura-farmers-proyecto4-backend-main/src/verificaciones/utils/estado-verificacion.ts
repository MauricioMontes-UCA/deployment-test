import { EstadoSolicitudVerificacion } from '@PrismaClient';
import {
  EstadoVerificacion,
  type EstadoVerificacionUsuario,
  type SolicitudParaEstado,
} from '@Verificaciones/types';

/** Estado de la solicitud más reciente → estado del usuario (glosario de H17). */
const ESTADO_POR_SOLICITUD = {
  [EstadoSolicitudVerificacion.EN_REVISION]: EstadoVerificacion.EN_REVISION,
  [EstadoSolicitudVerificacion.APROBADA]: EstadoVerificacion.VERIFICADO,
  [EstadoSolicitudVerificacion.RECHAZADA]: EstadoVerificacion.RECHAZADO,
} as const satisfies Record<EstadoSolicitudVerificacion, EstadoVerificacion>;

/**
 * Deriva el estado de verificación del usuario a partir de su solicitud más
 * reciente, o de `null` si nunca envió un documento.
 *
 * - Sin solicitudes: `NO_VERIFICADO`, con todo lo demás en `null`.
 * - `EN_REVISION` → `EN_REVISION`, `APROBADA` → `VERIFICADO` y `RECHAZADA` →
 *   `RECHAZADO`. Solo cuenta la más reciente: una renovación en revisión deja
 *   al usuario `EN_REVISION` aunque antes estuviera verificado.
 * - `motivo` solo se devuelve si el estado es `RECHAZADO`, tal como está en la
 *   base; si no hay motivo guardado, queda `null`.
 *
 * Es una función pura para que la misma regla sirva en cualquier módulo.
 */
export function derivarEstadoVerificacion(
  ultima: SolicitudParaEstado | null,
): EstadoVerificacionUsuario {
  if (!ultima) {
    return {
      estado: EstadoVerificacion.NO_VERIFICADO,
      motivo: null,
      solicitudId: null,
      revisadoEn: null,
    };
  }

  const estado = ESTADO_POR_SOLICITUD[ultima.estado];
  return {
    estado,
    motivo:
      estado === EstadoVerificacion.RECHAZADO ? (ultima.motivo ?? null) : null,
    solicitudId: ultima.id,
    revisadoEn: ultima.revisadoEn,
  };
}
