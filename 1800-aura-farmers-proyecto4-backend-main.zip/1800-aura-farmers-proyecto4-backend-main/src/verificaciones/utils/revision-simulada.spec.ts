import {
  ESPERA_MINIMA_REVISION_MS,
  LOTE_REVISION_SIMULADA,
  MOTIVO_RECHAZO_SIMULADO,
  TIPO_REFERENCIA_SOLICITUD_VERIFICACION,
  TITULO_RESULTADO_VERIFICACION,
} from '@Verificaciones/constants';
import {
  mensajeResultadoVerificacion,
  revisarDocumento,
} from './revision-simulada.js';

describe('revisarDocumento', () => {
  it('cedula.jpg se aprueba, sin motivo', () => {
    expect(revisarDocumento('cedula.jpg')).toEqual({
      estado: 'APROBADA',
      motivo: null,
    });
  });

  it.each([
    'rechazar_1.png',
    'RECHAZAR.pdf',
    'mi-ReChAzAr.jpg',
    'dui rechazar',
  ])('%s se rechaza con el motivo exacto', (nombre) => {
    expect(revisarDocumento(nombre)).toEqual({
      estado: 'RECHAZADA',
      motivo: 'Documento no válido (revisión simulada).',
    });
  });

  it.each(['rechazo.jpg', 'rechaza.png', 'dui.pdf', 'reChAzA_r.jpg'])(
    '%s no contiene "rechazar" y se aprueba',
    (nombre) => {
      expect(revisarDocumento(nombre)?.estado).toBe('APROBADA');
    },
  );

  it.each([null, '', '   '])(
    'sin documento o con el nombre vacío (%j) no se aprueba ni se rechaza',
    (nombre) => {
      expect(revisarDocumento(nombre)).toBeNull();
    },
  );
});

describe('mensajeResultadoVerificacion', () => {
  it('aprobada: el mensaje exacto', () => {
    expect(
      mensajeResultadoVerificacion({ estado: 'APROBADA', motivo: null }),
    ).toBe('Tu documento fue aprobado. Ya estás verificado.');
  });

  it('rechazada: el mensaje exacto con el motivo', () => {
    expect(
      mensajeResultadoVerificacion({
        estado: 'RECHAZADA',
        motivo: MOTIVO_RECHAZO_SIMULADO,
      }),
    ).toBe(
      'Tu documento fue rechazado: Documento no válido (revisión simulada).',
    );
  });

  it('ningún mensaje supera los 300 caracteres que acepta el Módulo 8', () => {
    for (const resultado of [
      revisarDocumento('cedula.jpg')!,
      revisarDocumento('rechazar_1.png')!,
    ]) {
      expect(
        mensajeResultadoVerificacion(resultado).length,
      ).toBeLessThanOrEqual(300);
    }
  });
});

describe('constantes de la revisión simulada', () => {
  it('coinciden con BE-18.1', () => {
    expect(ESPERA_MINIMA_REVISION_MS).toBe(10_000);
    expect(LOTE_REVISION_SIMULADA).toBe(20);
    expect(TITULO_RESULTADO_VERIFICACION).toBe('Resultado de tu verificación');
    expect(TIPO_REFERENCIA_SOLICITUD_VERIFICACION).toBe(
      'SOLICITUD_VERIFICACION',
    );
    expect(MOTIVO_RECHAZO_SIMULADO).toBe(
      'Documento no válido (revisión simulada).',
    );
  });
});
