import { EstadoSolicitudVerificacion } from '@PrismaClient';
import {
  LONGITUD_MAXIMA_MENSAJE_AVISO,
  MENSAJE_VERIFICACION_APROBADA,
  MOTIVO_RECHAZO_SIMULADO,
  PALABRA_RECHAZO,
} from '@Verificaciones/constants';

/** Resultado de la revisión simulada de un documento. */
export type ResultadoRevision =
  | { estado: typeof EstadoSolicitudVerificacion.APROBADA; motivo: null }
  | {
      estado: typeof EstadoSolicitudVerificacion.RECHAZADA;
      motivo: typeof MOTIVO_RECHAZO_SIMULADO;
    };

/**
 * Regla de la revisión simulada (BE-18.1): si el nombre del archivo contiene
 * "rechazar", sin distinguir mayúsculas, el documento se rechaza con el motivo
 * definido; con cualquier otro nombre se aprueba.
 *
 * Devuelve `null` cuando no hay un nombre que revisar (solicitud sin documento
 * o con el nombre vacío): esa solicitud no se aprueba ni se rechaza.
 */
export function revisarDocumento(
  nombreArchivo: string | null,
): ResultadoRevision | null {
  if (nombreArchivo === null || nombreArchivo.trim() === '') return null;

  if (nombreArchivo.toLowerCase().includes(PALABRA_RECHAZO)) {
    return {
      estado: EstadoSolicitudVerificacion.RECHAZADA,
      motivo: MOTIVO_RECHAZO_SIMULADO,
    };
  }
  return { estado: EstadoSolicitudVerificacion.APROBADA, motivo: null };
}

/** Texto del aviso "Resultado de tu verificación" (máximo 300 caracteres). */
export function mensajeResultadoVerificacion(
  resultado: ResultadoRevision,
): string {
  const mensaje =
    resultado.estado === EstadoSolicitudVerificacion.APROBADA
      ? MENSAJE_VERIFICACION_APROBADA
      : `Tu documento fue rechazado: ${resultado.motivo}`;
  return mensaje.slice(0, LONGITUD_MAXIMA_MENSAJE_AVISO);
}
