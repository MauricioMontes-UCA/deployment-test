import { detectarFormatoDocumento } from './formato-documento.js';

const JPG = Buffer.from([0xff, 0xd8, 0xff, 0xe0, 0x00, 0x10]);
const PNG = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00]);
const PDF = Buffer.from('%PDF-1.7\n%âãÏÓ\n', 'latin1');

describe('detectarFormatoDocumento', () => {
  it('reconoce JPG, PNG y PDF por sus primeros bytes', () => {
    expect(detectarFormatoDocumento(JPG)).toBe('image/jpeg');
    expect(detectarFormatoDocumento(PNG)).toBe('image/png');
    expect(detectarFormatoDocumento(PDF)).toBe('application/pdf');
  });

  it.each([
    ['GIF', Buffer.from('GIF89a\x00\x00', 'latin1')],
    ['WEBP', Buffer.from('RIFF\x00\x00\x00\x00WEBPVP8 ', 'latin1')],
    ['texto', Buffer.from('cedula.jpg')],
    ['ZIP', Buffer.from([0x50, 0x4b, 0x03, 0x04])],
  ])('no acepta %s', (_formato, contenido) => {
    expect(detectarFormatoDocumento(contenido)).toBeNull();
  });

  it('no acepta un buffer vacío ni uno más corto que la firma', () => {
    expect(detectarFormatoDocumento(Buffer.alloc(0))).toBeNull();
    expect(detectarFormatoDocumento(Buffer.from([0xff, 0xd8]))).toBeNull();
    expect(
      detectarFormatoDocumento(Buffer.from([0x89, 0x50, 0x4e])),
    ).toBeNull();
    expect(detectarFormatoDocumento(Buffer.from('%PDF'))).toBeNull();
  });

  it('exige la firma al inicio, no en cualquier parte del archivo', () => {
    const conPdfDentro = Buffer.concat([Buffer.from('hola '), PDF]);

    expect(detectarFormatoDocumento(conPdfDentro)).toBeNull();
  });
});
