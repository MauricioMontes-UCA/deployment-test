import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ScheduleModule } from '@nestjs/schedule';
import { APP_GUARD } from '@nestjs/core';
import { EventEmitterModule } from '@nestjs/event-emitter';
import { AuthModule } from '@Auth';
import { BienesModule } from '@Bienes';
import { BloqueosModule } from '@Bloqueos';
import { JwtAuthGuard, RolesGuard } from '@Auth/guards';
import { ConversacionesModule } from '@Conversaciones';
import { DepositosModule } from '@Depositos';
import { HealthModule } from '@Health';
import { PrismaModule } from '@Prisma';
import { NotificacionesModule } from '@Notificaciones';
import { ReportesModule } from '@Reportes';
import { ResenasModule } from '@Resenas';
import { PagosModule } from '@Pagos';
import { ReservasModule } from '@Reservas';
import { UsersModule } from '@Users';
import { VerificacionesModule } from '@Verificaciones';
import { validateEnv } from '@Config';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      cache: true,
      // Si falta DATABASE_URL o JWT_SECRET, la app no arranca.
      validate: validateEnv,
    }),
    // Eventos internos entre módulos (por ejemplo "solicitud encolada").
    EventEmitterModule.forRoot(),
    // Tareas programadas con @Cron: reservas y depósitos (H10) y revisión
    // simulada de documentos (H18).
    ScheduleModule.forRoot(),
    PrismaModule,
    HealthModule,
    UsersModule,
    AuthModule,
    BienesModule,
    BloqueosModule,
    NotificacionesModule,
    ReservasModule,
    ReportesModule,
    ResenasModule,
    PagosModule,
    DepositosModule,
    ConversacionesModule,
    VerificacionesModule,
  ],
  providers: [
    {
      // Todo cerrado por defecto: las rutas públicas se abren con @Public().
      provide: APP_GUARD,
      useExisting: JwtAuthGuard,
    },
    {
      provide: APP_GUARD,
      useExisting: RolesGuard,
    },
  ],
})
export class AppModule {}
