import { Module } from '@nestjs/common';

import { BienesModule } from '@Bienes';

import {
  BandejaConversacionesController,
  ConversacionesBienController,
  CoordinacionController,
  MensajesController,
} from '@Conversaciones/controllers';

import { ConversacionRepository } from '@Conversaciones/repositories';

import {
  ConversacionesService,
  CoordinacionService,
} from '@Conversaciones/services';

import { NotificacionesModule } from '@Notificaciones';

/**
 * Mensajería entre arrendador y arrendatario (Módulo 5): la conversación
 * previa a una reserva (H13) y la de coordinación de la entrega (H14).
 *
 * Importa BienesModule para leer la publicación y su arrendador, y
 * NotificacionesModule para pedir al Módulo 8 el aviso de cada mensaje.
 *
 * La reserva de H14 la lee ConversacionRepository, sin depender de
 * ReservasModule.
 *
 * BE-13.2 incorpora la bandeja de conversaciones del usuario.
 */
@Module({
  imports: [BienesModule, NotificacionesModule],

  controllers: [
    BandejaConversacionesController,
    ConversacionesBienController,
    MensajesController,
    CoordinacionController,
  ],

  providers: [
    ConversacionesService,
    CoordinacionService,
    ConversacionRepository,
  ],
})
export class ConversacionesModule {}
