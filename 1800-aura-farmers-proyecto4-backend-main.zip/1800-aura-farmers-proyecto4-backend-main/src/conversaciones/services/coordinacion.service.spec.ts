import {
  ConflictException,
  ForbiddenException,
  Logger,
  NotFoundException,
  UnprocessableEntityException,
} from '@nestjs/common';
import { EstadoReserva, ModuloOrigen } from '@PrismaClient';
import type { ConversacionRepository } from '@Conversaciones/repositories';
import { MENSAJES_COORDINACION } from '@Conversaciones/utils';
import type { NotificacionesService } from '@Notificaciones/services';
import { CoordinacionService } from './coordinacion.service.js';

const RESERVA_ID = '3f1a2b4c-5d6e-4f70-8a91-b2c3d4e5f607';
const BIEN_ID = '7c9e6679-7425-40de-944b-e07fc1f90ae7';
const CONVERSACION_ID = '9b2f1c3e-5a4d-4e6f-8a7b-1c2d3e4f5a6b';
const ARRENDADOR = 'arrendador-1';
const ARRENDATARIO = 'arrendatario-1';
const EXTERNO = 'externo-1';

const reserva = (estado: EstadoReserva = EstadoReserva.CONFIRMADA) => ({
  id: RESERVA_ID,
  bienId: BIEN_ID,
  arrendatarioId: ARRENDATARIO,
  estado,
  fechaInicio: new Date('2026-12-20T00:00:00.000Z'),
  fechaFin: new Date('2026-12-22T00:00:00.000Z'),
  bien: { titulo: 'Salón de eventos', arrendadorId: ARRENDADOR },
});

const conversacion = {
  id: CONVERSACION_ID,
  reservaId: RESERVA_ID,
  creadaEn: new Date('2026-11-15T15:00:00.000Z'),
  arrendador: { id: ARRENDADOR, nombreUsuario: 'dueno' },
  arrendatario: { id: ARRENDATARIO, nombreUsuario: 'inquilino' },
};

const mensajeDe = (remitente: { id: string; nombreUsuario: string }) => ({
  id: 'mensaje-1',
  conversacionId: CONVERSACION_ID,
  contenido: 'Entrego el sábado a las 9',
  creadoEn: new Date('2026-11-15T15:05:00.000Z'),
  remitente,
});

function crear({
  estado = EstadoReserva.CONFIRMADA,
  existente = conversacion,
}: {
  estado?: EstadoReserva;
  existente?: typeof conversacion | null;
} = {}) {
  const conversacionRepository = {
    findReservaParaCoordinacion: vi.fn().mockResolvedValue(reserva(estado)),
    findPorReserva: vi.fn().mockResolvedValue(existente),
    crearDeReserva: vi.fn().mockResolvedValue({ conversacion }),
    crearMensaje: vi
      .fn()
      .mockResolvedValue(mensajeDe(conversacion.arrendatario)),
    listarMensajes: vi.fn().mockResolvedValue([]),
  };
  const notificacionesService = {
    crear: vi
      .fn()
      .mockResolvedValue({ creada: true, notificacionId: 'aviso-1' }),
  };
  const service = new CoordinacionService(
    conversacionRepository as unknown as ConversacionRepository,
    notificacionesService as unknown as NotificacionesService,
  );
  return { service, conversacionRepository, notificacionesService };
}

describe('CoordinacionService: acceso', () => {
  it('reserva inexistente: 404 "La reserva no existe." sin buscar conversación', async () => {
    const { service, conversacionRepository } = crear();
    conversacionRepository.findReservaParaCoordinacion.mockResolvedValue(null);

    const error = await service.abrir(RESERVA_ID, ARRENDATARIO).catch((e) => e);

    expect(error).toBeInstanceOf(NotFoundException);
    expect(error.message).toBe('La reserva no existe.');
    expect(conversacionRepository.findPorReserva).not.toHaveBeenCalled();
  });

  it('usuario que no participa: 403 sin buscar ni crear la conversación', async () => {
    const { service, conversacionRepository } = crear();

    const error = await service.abrir(RESERVA_ID, EXTERNO).catch((e) => e);

    expect(error).toBeInstanceOf(ForbiddenException);
    expect(error.message).toBe(MENSAJES_COORDINACION.NO_PARTICIPANTE);
    expect(conversacionRepository.findPorReserva).not.toHaveBeenCalled();
    expect(conversacionRepository.crearDeReserva).not.toHaveBeenCalled();
  });

  it('comprueba al participante antes que el estado: un externo recibe 403, no 422', async () => {
    const { service } = crear({ estado: EstadoReserva.CANCELADA });

    await expect(service.abrir(RESERVA_ID, EXTERNO)).rejects.toBeInstanceOf(
      ForbiddenException,
    );
  });

  it.each([
    EstadoReserva.EN_COLA,
    EstadoReserva.RECHAZADA,
    EstadoReserva.FINALIZADA,
    EstadoReserva.CANCELADA,
  ])(
    'reserva %s sin conversación: 422 con el mensaje de H14 y sin crearla',
    async (estado) => {
      const { service, conversacionRepository } = crear({
        estado,
        existente: null,
      });

      const error = await service
        .abrir(RESERVA_ID, ARRENDATARIO)
        .catch((e) => e);

      expect(error).toBeInstanceOf(UnprocessableEntityException);
      expect(error.message).toBe(
        'La coordinación está disponible cuando la reserva está confirmada o en curso',
      );
      expect(conversacionRepository.crearDeReserva).not.toHaveBeenCalled();
    },
  );

  it.each([
    ['arrendador (dueño del bien)', ARRENDADOR],
    ['arrendatario de la reserva', ARRENDATARIO],
  ])('el %s puede abrirla', async (_rol, usuarioId) => {
    const { service } = crear();

    await expect(service.abrir(RESERVA_ID, usuarioId)).resolves.toEqual({
      conversacion,
      reserva: reserva(),
    });
  });

  it.each([EstadoReserva.CONFIRMADA, EstadoReserva.EN_CURSO])(
    'con la reserva %s se puede coordinar',
    async (estado) => {
      const { service } = crear({ estado });

      await expect(
        service.abrir(RESERVA_ID, ARRENDATARIO),
      ).resolves.toMatchObject({ conversacion });
    },
  );
});

describe('CoordinacionService.abrir: una conversación por reserva', () => {
  it('si ya existe, la devuelve sin crear otra', async () => {
    const { service, conversacionRepository } = crear();

    await service.abrir(RESERVA_ID, ARRENDADOR);

    expect(conversacionRepository.findPorReserva).toHaveBeenCalledWith(
      RESERVA_ID,
    );
    expect(conversacionRepository.crearDeReserva).not.toHaveBeenCalled();
  });

  it('la primera vez la crea con el bien y los participantes leídos de la reserva', async () => {
    const { service, conversacionRepository } = crear({ existente: null });

    await expect(service.abrir(RESERVA_ID, ARRENDATARIO)).resolves.toEqual({
      conversacion,
      reserva: reserva(),
    });
    expect(conversacionRepository.crearDeReserva).toHaveBeenCalledWith({
      reservaId: RESERVA_ID,
      bienId: BIEN_ID,
      arrendadorId: ARRENDADOR,
      arrendatarioId: ARRENDATARIO,
    });
  });

  it('si otra petición la creó a la vez (P2002), devuelve la que ganó sin error', async () => {
    const { service, conversacionRepository } = crear({ existente: null });
    conversacionRepository.crearDeReserva.mockResolvedValue({
      duplicada: true,
    });
    conversacionRepository.findPorReserva
      .mockResolvedValueOnce(null)
      .mockResolvedValueOnce(conversacion);

    await expect(service.abrir(RESERVA_ID, ARRENDATARIO)).resolves.toEqual({
      conversacion,
      reserva: reserva(),
    });
    expect(conversacionRepository.findPorReserva).toHaveBeenCalledTimes(2);
  });

  it('si tras el P2002 no se puede leer la ganadora: 409', async () => {
    const { service, conversacionRepository } = crear({ existente: null });
    conversacionRepository.crearDeReserva.mockResolvedValue({
      duplicada: true,
    });

    const error = await service.abrir(RESERVA_ID, ARRENDATARIO).catch((e) => e);

    expect(error).toBeInstanceOf(ConflictException);
    expect(error.message).toBe(
      MENSAJES_COORDINACION.CONVERSACION_NO_RECUPERADA,
    );
  });

  it('propaga un error inesperado de la base', async () => {
    const { service, conversacionRepository } = crear({ existente: null });
    const fallo = new Error('base caída');
    conversacionRepository.crearDeReserva.mockRejectedValue(fallo);

    await expect(service.abrir(RESERVA_ID, ARRENDATARIO)).rejects.toBe(fallo);
  });
});

describe('CoordinacionService.enviar', () => {
  afterEach(() => vi.restoreAllMocks());

  it('guarda el mensaje con el remitente de la sesión en la conversación de la reserva', async () => {
    const { service, conversacionRepository } = crear();

    const mensaje = await service.enviar(RESERVA_ID, ARRENDATARIO, '  Hola  ');

    expect(conversacionRepository.crearMensaje).toHaveBeenCalledWith({
      conversacionId: CONVERSACION_ID,
      remitenteId: ARRENDATARIO,
      contenido: '  Hola  ',
    });
    expect(mensaje).toEqual(mensajeDe(conversacion.arrendatario));
  });

  it('crea la conversación si todavía no existe antes de guardar el mensaje', async () => {
    const { service, conversacionRepository } = crear({ existente: null });

    await service.enviar(RESERVA_ID, ARRENDADOR, 'Hola');

    expect(conversacionRepository.crearDeReserva).toHaveBeenCalledTimes(1);
    expect(conversacionRepository.crearMensaje).toHaveBeenCalledTimes(1);
  });

  it('avisa al arrendador cuando escribe el arrendatario, con el título, MENSAJERIA y el mensaje como referencia', async () => {
    const { service, notificacionesService } = crear();

    await service.enviar(RESERVA_ID, ARRENDATARIO, 'Entrego el sábado a las 9');

    expect(notificacionesService.crear).toHaveBeenCalledTimes(1);
    expect(notificacionesService.crear).toHaveBeenCalledWith(
      ARRENDADOR,
      'Mensaje sobre la entrega',
      'inquilino: Entrego el sábado a las 9',
      ModuloOrigen.MENSAJERIA,
      { tipoReferencia: 'MENSAJE', referenciaId: 'mensaje-1' },
    );
  });

  it('avisa al arrendatario cuando escribe el arrendador, nunca al remitente', async () => {
    const { service, conversacionRepository, notificacionesService } = crear();
    conversacionRepository.crearMensaje.mockResolvedValue(
      mensajeDe(conversacion.arrendador),
    );

    await service.enviar(RESERVA_ID, ARRENDADOR, 'Entrego el sábado a las 9');

    const [destinatario, , texto] = notificacionesService.crear.mock.calls[0]!;
    expect(destinatario).toBe(ARRENDATARIO);
    expect(destinatario).not.toBe(ARRENDADOR);
    expect(texto).toBe('dueno: Entrego el sábado a las 9');
  });

  it('cada mensaje usa su propio id como referencia del aviso', async () => {
    const { service, conversacionRepository, notificacionesService } = crear();
    conversacionRepository.crearMensaje
      .mockResolvedValueOnce({
        ...mensajeDe(conversacion.arrendatario),
        id: 'mensaje-1',
      })
      .mockResolvedValueOnce({
        ...mensajeDe(conversacion.arrendatario),
        id: 'mensaje-2',
      });

    await service.enviar(RESERVA_ID, ARRENDATARIO, 'Uno');
    await service.enviar(RESERVA_ID, ARRENDATARIO, 'Dos');

    expect(
      notificacionesService.crear.mock.calls.map((llamada) => llamada[4]),
    ).toEqual([
      { tipoReferencia: 'MENSAJE', referenciaId: 'mensaje-1' },
      { tipoReferencia: 'MENSAJE', referenciaId: 'mensaje-2' },
    ]);
  });

  it('el aviso recorta el texto a 300 caracteres para el Módulo 8', async () => {
    const { service, conversacionRepository, notificacionesService } = crear();
    conversacionRepository.crearMensaje.mockResolvedValue({
      ...mensajeDe(conversacion.arrendatario),
      contenido: 'a'.repeat(1000),
    });

    await service.enviar(RESERVA_ID, ARRENDATARIO, 'a'.repeat(1000));

    const texto = notificacionesService.crear.mock.calls[0]![2] as string;
    expect(texto.length).toBeLessThanOrEqual(300);
    expect(texto.endsWith('…')).toBe(true);
  });

  it('si el aviso falla, devuelve el mensaje igual, registra el error y no reintenta', async () => {
    const { service, notificacionesService } = crear();
    notificacionesService.crear.mockRejectedValue(new Error('Módulo 8 caído'));
    const log = vi
      .spyOn(Logger.prototype, 'error')
      .mockImplementation(() => {});

    await expect(
      service.enviar(RESERVA_ID, ARRENDATARIO, 'Hola'),
    ).resolves.toEqual(mensajeDe(conversacion.arrendatario));
    expect(notificacionesService.crear).toHaveBeenCalledTimes(1);
    expect(log).toHaveBeenCalledTimes(1);
    expect(log.mock.calls[0]![0]).toContain('mensaje-1');
  });

  it('un aviso que ya existía (creada: false) no es un error', async () => {
    const { service, notificacionesService } = crear();
    notificacionesService.crear.mockResolvedValue({
      creada: false,
      notificacionId: 'aviso-1',
    });

    await expect(
      service.enviar(RESERVA_ID, ARRENDATARIO, 'Hola'),
    ).resolves.toEqual(mensajeDe(conversacion.arrendatario));
  });

  it('sin acceso no guarda el mensaje ni avisa', async () => {
    const { service, conversacionRepository, notificacionesService } = crear();

    await expect(
      service.enviar(RESERVA_ID, EXTERNO, 'Hola'),
    ).rejects.toBeInstanceOf(ForbiddenException);
    expect(conversacionRepository.crearMensaje).not.toHaveBeenCalled();
    expect(notificacionesService.crear).not.toHaveBeenCalled();
  });

  it('si guardar el mensaje falla, no avisa y propaga el error', async () => {
    const { service, conversacionRepository, notificacionesService } = crear();
    const fallo = new Error('base caída');
    conversacionRepository.crearMensaje.mockRejectedValue(fallo);

    await expect(service.enviar(RESERVA_ID, ARRENDATARIO, 'Hola')).rejects.toBe(
      fallo,
    );
    expect(notificacionesService.crear).not.toHaveBeenCalled();
  });
});

describe('CoordinacionService.listar', () => {
  it.each(['asc', 'desc'] as const)(
    'lista los mensajes de la conversación de la reserva en orden %s',
    async (orden) => {
      const { service, conversacionRepository } = crear();
      const mensajes = [mensajeDe(conversacion.arrendatario)];
      conversacionRepository.listarMensajes.mockResolvedValue(mensajes);

      await expect(
        service.listar(RESERVA_ID, ARRENDADOR, orden),
      ).resolves.toEqual({ conversacionId: CONVERSACION_ID, mensajes });
      expect(conversacionRepository.listarMensajes).toHaveBeenCalledWith(
        CONVERSACION_ID,
        orden,
      );
    },
  );

  it('un externo recibe 403 y no se consulta el historial', async () => {
    const { service, conversacionRepository } = crear();

    await expect(
      service.listar(RESERVA_ID, EXTERNO, 'asc'),
    ).rejects.toBeInstanceOf(ForbiddenException);
    expect(conversacionRepository.listarMensajes).not.toHaveBeenCalled();
  });

  it('con la reserva FINALIZADA y sin conversación: 422 y no se consulta el historial', async () => {
    const { service, conversacionRepository } = crear({
      estado: EstadoReserva.FINALIZADA,
      existente: null,
    });

    await expect(
      service.listar(RESERVA_ID, ARRENDATARIO, 'asc'),
    ).rejects.toBeInstanceOf(UnprocessableEntityException);
    expect(conversacionRepository.listarMensajes).not.toHaveBeenCalled();
    expect(conversacionRepository.crearDeReserva).not.toHaveBeenCalled();
  });
});

describe('CoordinacionService: reservas cerradas (lectura del historial)', () => {
  const CERRADAS = [EstadoReserva.FINALIZADA, EstadoReserva.CANCELADA];

  it.each(CERRADAS)(
    'reserva %s con conversación: abrir la devuelve sin crear otra',
    async (estado) => {
      const { service, conversacionRepository } = crear({ estado });

      await expect(service.abrir(RESERVA_ID, ARRENDATARIO)).resolves.toEqual({
        conversacion,
        reserva: reserva(estado),
      });
      expect(conversacionRepository.crearDeReserva).not.toHaveBeenCalled();
    },
  );

  it.each(CERRADAS)(
    'reserva %s con conversación: los dos participantes leen el historial completo',
    async (estado) => {
      const { service, conversacionRepository } = crear({ estado });
      const mensajes = [
        mensajeDe(conversacion.arrendatario),
        { ...mensajeDe(conversacion.arrendador), id: 'mensaje-2' },
      ];
      conversacionRepository.listarMensajes.mockResolvedValue(mensajes);

      for (const usuarioId of [ARRENDADOR, ARRENDATARIO]) {
        await expect(
          service.listar(RESERVA_ID, usuarioId, 'desc'),
        ).resolves.toEqual({ conversacionId: CONVERSACION_ID, mensajes });
      }
      expect(conversacionRepository.listarMensajes).toHaveBeenCalledWith(
        CONVERSACION_ID,
        'desc',
      );
      expect(conversacionRepository.crearDeReserva).not.toHaveBeenCalled();
    },
  );

  it.each(CERRADAS)(
    'reserva %s: un externo recibe 403 aunque la conversación exista, sin leerla',
    async (estado) => {
      const { service, conversacionRepository } = crear({ estado });

      await expect(service.abrir(RESERVA_ID, EXTERNO)).rejects.toBeInstanceOf(
        ForbiddenException,
      );
      await expect(
        service.listar(RESERVA_ID, EXTERNO, 'asc'),
      ).rejects.toBeInstanceOf(ForbiddenException);
      expect(conversacionRepository.findPorReserva).not.toHaveBeenCalled();
      expect(conversacionRepository.listarMensajes).not.toHaveBeenCalled();
    },
  );

  it.each([
    [EstadoReserva.FINALIZADA, true],
    [EstadoReserva.FINALIZADA, false],
    [EstadoReserva.CANCELADA, true],
    [EstadoReserva.CANCELADA, false],
  ])(
    'enviar con la reserva %s (conversación existente: %s): 422 sin buscar, crear, guardar ni avisar',
    async (estado, hayConversacion) => {
      const { service, conversacionRepository, notificacionesService } = crear({
        estado,
        existente: hayConversacion ? conversacion : null,
      });

      const error = await service
        .enviar(RESERVA_ID, ARRENDATARIO, 'Hola')
        .catch((e) => e);

      expect(error).toBeInstanceOf(UnprocessableEntityException);
      expect(error.message).toBe(MENSAJES_COORDINACION.ESTADO_NO_PERMITIDO);
      expect(conversacionRepository.findPorReserva).not.toHaveBeenCalled();
      expect(conversacionRepository.crearDeReserva).not.toHaveBeenCalled();
      expect(conversacionRepository.crearMensaje).not.toHaveBeenCalled();
      expect(notificacionesService.crear).not.toHaveBeenCalled();
    },
  );

  it('enviar: un externo recibe 403 antes que el 422 de una reserva cerrada', async () => {
    const { service, conversacionRepository } = crear({
      estado: EstadoReserva.FINALIZADA,
    });

    await expect(
      service.enviar(RESERVA_ID, EXTERNO, 'Hola'),
    ).rejects.toBeInstanceOf(ForbiddenException);
    expect(conversacionRepository.crearMensaje).not.toHaveBeenCalled();
  });

  it.each([EstadoReserva.CONFIRMADA, EstadoReserva.EN_CURSO])(
    'reserva %s sin conversación: abrir, listar y enviar la crean como antes',
    async (estado) => {
      for (const operacion of ['abrir', 'listar', 'enviar'] as const) {
        const { service, conversacionRepository } = crear({
          estado,
          existente: null,
        });

        if (operacion === 'abrir') await service.abrir(RESERVA_ID, ARRENDADOR);
        if (operacion === 'listar') {
          await service.listar(RESERVA_ID, ARRENDADOR, 'asc');
        }
        if (operacion === 'enviar') {
          await service.enviar(RESERVA_ID, ARRENDADOR, 'Hola');
        }

        expect(conversacionRepository.crearDeReserva).toHaveBeenCalledTimes(1);
      }
    },
  );
});
