import {
  ConflictException,
  ForbiddenException,
  Injectable,
  Logger,
  NotFoundException,
  UnprocessableEntityException,
} from '@nestjs/common';
import { ModuloOrigen } from '@PrismaClient';
import {
  ConversacionRepository,
  type ConversacionDeReserva,
  type MensajeConRemitente,
  type ReservaParaCoordinacion,
} from '@Conversaciones/repositories';
import {
  admiteCoordinacion,
  construirMensajeNotificacion,
  MENSAJES_COORDINACION,
  REFERENCIA_AVISO_COORDINACION,
  TITULO_MENSAJE_ENTREGA,
} from '@Conversaciones/utils';
import type { OrdenMensajes } from '@Conversaciones/dto';
import { NotificacionesService } from '@Notificaciones/services';

/** La conversación de coordinación y la reserva de la que salió. */
export interface CoordinacionAbierta {
  conversacion: ConversacionDeReserva;
  reserva: ReservaParaCoordinacion;
}

/** El historial de la conversación de coordinación de una reserva. */
export interface HistorialCoordinacion {
  conversacionId: string;
  mensajes: MensajeConRemitente[];
}

/**
 * Conversación de coordinación de la entrega de una reserva (H14, BE-14.1).
 *
 * Los participantes salen siempre de la reserva guardada (el arrendatario de
 * la reserva y el arrendador dueño del bien) y el remitente, del token. Ningún
 * dato de participantes viene del cliente.
 */
@Injectable()
export class CoordinacionService {
  private readonly logger = new Logger(CoordinacionService.name);

  constructor(
    private readonly conversacionRepository: ConversacionRepository,
    private readonly notificacionesService: NotificacionesService,
  ) {}

  /**
   * Recupera la conversación de coordinación de la reserva, o la crea si
   * todavía no existe. Es idempotente: varias llamadas, también simultáneas,
   * devuelven la misma conversación.
   *
   * Una conversación que ya existe se puede leer en cualquier estado de la
   * reserva: después de finalizar o cancelar, el historial sigue siendo la
   * evidencia de lo acordado. Crearla, en cambio, solo se puede con la reserva
   * CONFIRMADA o EN_CURSO.
   *
   * @throws {NotFoundException} la reserva no existe.
   * @throws {ForbiddenException} el usuario no es participante de la reserva.
   * @throws {UnprocessableEntityException} la conversación no existe y la
   * reserva no está CONFIRMADA ni EN_CURSO, así que no se puede crear.
   * @throws {ConflictException} una creación simultánea ganó y aun así no se
   * pudo leer la conversación resultante.
   */
  async abrir(
    reservaId: string,
    usuarioId: string,
  ): Promise<CoordinacionAbierta> {
    const reserva = await this.reservaDeParticipante(reservaId, usuarioId);
    const conversacion = await this.obtenerOCrear(reserva);
    return { conversacion, reserva };
  }

  /**
   * Registra un mensaje del usuario autenticado en la conversación de la
   * reserva (la crea si hace falta).
   *
   * Escribir exige la reserva CONFIRMADA o EN_CURSO, también cuando la
   * conversación ya existe: leer el historial de una reserva cerrada no
   * habilita mensajes nuevos. El estado se comprueba antes de buscar o crear
   * la conversación.
   *
   * Una vez guardado el mensaje, pide al Módulo 8 avisar al otro participante.
   * Si el aviso falla, el mensaje no se revierte: ya quedó registrado.
   *
   * @throws {NotFoundException} la reserva no existe.
   * @throws {ForbiddenException} el usuario no es participante de la reserva.
   * @throws {UnprocessableEntityException} la reserva no está CONFIRMADA ni
   * EN_CURSO.
   * @throws {ConflictException} igual que `abrir`.
   */
  async enviar(
    reservaId: string,
    remitenteId: string,
    contenido: string,
  ): Promise<MensajeConRemitente> {
    const reserva = await this.reservaDeParticipante(reservaId, remitenteId);
    this.exigirEstadoActivo(reserva);
    const conversacion = await this.obtenerOCrear(reserva);

    const mensaje = await this.conversacionRepository.crearMensaje({
      conversacionId: conversacion.id,
      remitenteId,
      contenido,
    });

    await this.avisarDestinatario(
      this.otroParticipante(reserva, remitenteId),
      mensaje,
    );

    return mensaje;
  }

  /**
   * Historial de la conversación de la reserva, con las mismas reglas que
   * `abrir`: si la conversación existe se lee en cualquier estado de la
   * reserva; si no existe, solo se crea con la reserva CONFIRMADA o EN_CURSO.
   *
   * @throws igual que `abrir`.
   */
  async listar(
    reservaId: string,
    usuarioId: string,
    orden: OrdenMensajes,
  ): Promise<HistorialCoordinacion> {
    const { conversacion } = await this.abrir(reservaId, usuarioId);
    return {
      conversacionId: conversacion.id,
      mensajes: await this.conversacionRepository.listarMensajes(
        conversacion.id,
        orden,
      ),
    };
  }

  /**
   * La reserva, si existe y el usuario participa en ella. No mira el estado:
   * eso depende de la operación (`exigirEstadoActivo`).
   *
   * Siempre va primero: a quien no participa no se le dice nada de la
   * reserva, ni siquiera en qué estado está.
   */
  private async reservaDeParticipante(
    reservaId: string,
    usuarioId: string,
  ): Promise<ReservaParaCoordinacion> {
    const reserva =
      await this.conversacionRepository.findReservaParaCoordinacion(reservaId);
    if (!reserva) {
      throw new NotFoundException(MENSAJES_COORDINACION.RESERVA_NO_EXISTE);
    }
    if (
      usuarioId !== reserva.arrendatarioId &&
      usuarioId !== reserva.bien.arrendadorId
    ) {
      throw new ForbiddenException(MENSAJES_COORDINACION.NO_PARTICIPANTE);
    }
    return reserva;
  }

  /**
   * Para crear la conversación o escribir en ella, la reserva tiene que estar
   * CONFIRMADA o EN_CURSO.
   *
   * @throws {UnprocessableEntityException} con el mensaje de H14.
   */
  private exigirEstadoActivo(reserva: ReservaParaCoordinacion): void {
    if (!admiteCoordinacion(reserva.estado)) {
      throw new UnprocessableEntityException(
        MENSAJES_COORDINACION.ESTADO_NO_PERMITIDO,
      );
    }
  }

  /**
   * La conversación de la reserva o una nueva con su bien y sus participantes.
   *
   * La existente se devuelve en cualquier estado de la reserva; una nueva solo
   * se crea con la reserva CONFIRMADA o EN_CURSO.
   *
   * Si otra petición la creó entre la búsqueda y el insert, el índice único de
   * `reserva_id` rechaza el segundo insert y se devuelve la que ganó: el
   * cliente recibe la misma conversación, sin error.
   */
  private async obtenerOCrear(
    reserva: ReservaParaCoordinacion,
  ): Promise<ConversacionDeReserva> {
    const existente = await this.conversacionRepository.findPorReserva(
      reserva.id,
    );
    if (existente) return existente;

    this.exigirEstadoActivo(reserva);

    const resultado = await this.conversacionRepository.crearDeReserva({
      reservaId: reserva.id,
      bienId: reserva.bienId,
      arrendadorId: reserva.bien.arrendadorId,
      arrendatarioId: reserva.arrendatarioId,
    });
    if ('conversacion' in resultado) return resultado.conversacion;

    const ganadora = await this.conversacionRepository.findPorReserva(
      reserva.id,
    );
    if (!ganadora) {
      throw new ConflictException(
        MENSAJES_COORDINACION.CONVERSACION_NO_RECUPERADA,
      );
    }
    return ganadora;
  }

  /**
   * El participante de la reserva que no es `usuarioId`. Arrendador y
   * arrendatario siempre son personas distintas (la base lo exige en
   * `Conversaciones_participantes_distintos_chk`), así que nunca es el
   * remitente.
   */
  private otroParticipante(
    reserva: ReservaParaCoordinacion,
    usuarioId: string,
  ): string {
    return usuarioId === reserva.arrendatarioId
      ? reserva.bien.arrendadorId
      : reserva.arrendatarioId;
  }

  /**
   * Pide al Módulo 8 el aviso "Mensaje sobre la entrega" para el otro
   * participante, con el mensaje como referencia: cada mensaje genera su
   * propio aviso.
   *
   * Cualquier fallo se registra y no se propaga, igual que en el aviso de los
   * mensajes de H13 y en los de H22. No se reintenta.
   */
  private async avisarDestinatario(
    destinatarioId: string,
    mensaje: MensajeConRemitente,
  ): Promise<void> {
    try {
      const resultado = await this.notificacionesService.crear(
        destinatarioId,
        TITULO_MENSAJE_ENTREGA,
        construirMensajeNotificacion(
          mensaje.remitente.nombreUsuario,
          mensaje.contenido,
        ),
        ModuloOrigen.MENSAJERIA,
        {
          tipoReferencia: REFERENCIA_AVISO_COORDINACION,
          referenciaId: mensaje.id,
        },
      );
      if (!resultado.creada) {
        this.logger.debug(`El aviso del mensaje ${mensaje.id} ya existía.`);
      }
    } catch (error) {
      this.logger.error(
        `No se pudo crear el aviso del mensaje ${mensaje.id} de la conversación ${mensaje.conversacionId}.`,
        error instanceof Error ? error.stack : String(error),
      );
    }
  }
}
