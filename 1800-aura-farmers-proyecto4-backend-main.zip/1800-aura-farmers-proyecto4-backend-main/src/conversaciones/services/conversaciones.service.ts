import {
  ConflictException,
  ForbiddenException,
  Injectable,
  Logger,
  NotFoundException,
  UnprocessableEntityException,
} from '@nestjs/common';
import { ModuloOrigen } from '@PrismaClient';
import { BienRepository } from '@Bienes/repositories';
import {
  ConversacionRepository,
  type ConversacionConParticipantes,
  type MensajeConRemitente,
  type ParticipantesConversacion,
  type ResultadoBandeja,
} from '@Conversaciones/repositories';
import {
  TIPO_REFERENCIA_MENSAJE,
  TITULO_NUEVO_MENSAJE,
  construirMensajeNotificacion,
} from '@Conversaciones/utils';
import type {
  OrdenMensajes,
  ConsultarConversacionesDto,
} from '@Conversaciones/dto';
import { NotificacionesService } from '@Notificaciones/services';

export const MENSAJES_CONVERSACION = {
  PUBLICACION_NO_EXISTE: 'La publicación no existe.',
  PUBLICACION_NO_ACTIVA: 'La publicación no está ACTIVA.',
  PUBLICACION_PROPIA:
    'No puedes iniciar una conversación sobre tu propia publicación.',
  CONVERSACION_NO_RECUPERADA:
    'No se pudo recuperar la conversación. Intenta de nuevo.',
  CONVERSACION_NO_EXISTE: 'La conversación no existe.',
  NO_PARTICIPANTE: 'No participas en esta conversación.',
} as const;

/** La conversación y si se acaba de crear (201) o ya existía (200). */
export interface ResultadoAbrirConversacion {
  conversacion: ConversacionConParticipantes;
  creada: boolean;
}

/**
 * Conversaciones previas a una reserva y sus mensajes (H13, BE-13.1).
 *
 * El remitente y el arrendatario salen siempre del token; el arrendador, de la
 * publicación. Ningún dato de autoría viene del cliente.
 */
@Injectable()
export class ConversacionesService {
  private readonly logger = new Logger(ConversacionesService.name);

  constructor(
    private readonly conversacionRepository: ConversacionRepository,
    private readonly bienRepository: BienRepository,
    private readonly notificacionesService: NotificacionesService,
  ) {}

  /** Recupera la bandeja del usuario autenticado. */
  listarBandeja(
    usuarioId: string,
    { tipo, pagina }: ConsultarConversacionesDto,
  ): Promise<ResultadoBandeja> {
    return this.conversacionRepository.listarBandeja(usuarioId, tipo, pagina);
  }

  /**
   * Abre la conversación del arrendatario sobre una publicación, o recupera la
   * que ya tenía.
   *
   * @throws {NotFoundException} la publicación no existe o su arrendador está
   * desactivado.
   * @throws {UnprocessableEntityException} la publicación no está ACTIVA o es
   * del propio usuario.
   * @throws {ConflictException} una creación concurrente ganó y aun así no se
   * pudo leer la conversación resultante.
   */
  async abrir(
    bienId: string,
    arrendatarioId: string,
  ): Promise<ResultadoAbrirConversacion> {
    const bien = await this.bienRepository.findParaConversacion(bienId);
    if ('rechazo' in bien) {
      if (bien.rechazo === 'NO_EXISTE') {
        throw new NotFoundException(
          MENSAJES_CONVERSACION.PUBLICACION_NO_EXISTE,
        );
      }
      throw new UnprocessableEntityException(
        MENSAJES_CONVERSACION.PUBLICACION_NO_ACTIVA,
      );
    }
    // Con los roles actuales no puede pasar (solo un ARRENDADOR publica y solo
    // un ARRENDATARIO abre conversaciones), pero la base lo rechazaría con un
    // CHECK y aquí se responde con un error claro.
    if (bien.arrendadorId === arrendatarioId) {
      throw new UnprocessableEntityException(
        MENSAJES_CONVERSACION.PUBLICACION_PROPIA,
      );
    }

    const existente = await this.conversacionRepository.findPrevia(
      bienId,
      arrendatarioId,
    );
    if (existente) return { conversacion: existente, creada: false };

    const resultado = await this.conversacionRepository.crearPrevia({
      bienId,
      arrendadorId: bien.arrendadorId,
      arrendatarioId,
    });
    if ('conversacion' in resultado) {
      return { conversacion: resultado.conversacion, creada: true };
    }

    // Otra petición la creó entre la búsqueda y el insert: se devuelve esa.
    const ganadora = await this.conversacionRepository.findPrevia(
      bienId,
      arrendatarioId,
    );
    if (!ganadora) {
      throw new ConflictException(
        MENSAJES_CONVERSACION.CONVERSACION_NO_RECUPERADA,
      );
    }
    return { conversacion: ganadora, creada: false };
  }

  /**
   * Registra un mensaje del usuario autenticado.
   *
   * Se puede escribir aunque la publicación haya pasado a INACTIVA después de
   * abrir la conversación: el historial se conserva.
   *
   * Una vez guardado el mensaje, pide al Módulo 8 avisar al otro participante.
   * Si el aviso falla, el mensaje no se revierte: ya quedó registrado.
   *
   * El destinatario es siempre el otro participante: la base garantiza que
   * arrendador y arrendatario son personas distintas
   * (`Conversaciones_participantes_distintos_chk`), así que nadie puede
   * enviarse un mensaje a sí mismo.
   *
   * @throws {NotFoundException} la conversación no existe.
   * @throws {ForbiddenException} el usuario no participa en ella.
   */
  async enviar(
    conversacionId: string,
    remitenteId: string,
    contenido: string,
  ): Promise<MensajeConRemitente> {
    const participantes = await this.participantesDe(
      conversacionId,
      remitenteId,
    );
    const destinatarioId = this.otroParticipante(participantes, remitenteId);

    const mensaje = await this.conversacionRepository.crearMensaje({
      conversacionId,
      remitenteId,
      contenido,
    });

    await this.avisarDestinatario(destinatarioId, mensaje);

    return mensaje;
  }

  /**
   * Pide al Módulo 8 el aviso "Nuevo mensaje" para el otro participante, con
   * el mensaje como referencia: cada mensaje genera su propio aviso.
   *
   * `NotificacionesService.crear` deduplica por destinatario y referencia: si
   * ya existe el aviso de este mensaje para el destinatario (por ejemplo, en
   * un reintento), devuelve `creada: false` y no es un error. Cualquier fallo
   * se registra y no se propaga, igual que en los avisos de pagos y depósitos
   * (H22).
   */
  private async avisarDestinatario(
    destinatarioId: string,
    mensaje: MensajeConRemitente,
  ): Promise<void> {
    try {
      const resultado = await this.notificacionesService.crear(
        destinatarioId,
        TITULO_NUEVO_MENSAJE,
        construirMensajeNotificacion(
          mensaje.remitente.nombreUsuario,
          mensaje.contenido,
        ),
        ModuloOrigen.MENSAJERIA,
        {
          tipoReferencia: TIPO_REFERENCIA_MENSAJE,
          referenciaId: mensaje.id,
        },
      );
      if (!resultado.creada) {
        this.logger.debug(`El aviso del mensaje ${mensaje.id} ya existía.`);
      }
    } catch (error) {
      this.logger.error(
        `No se pudo crear el aviso del mensaje ${mensaje.id} de la conversación ${mensaje.conversacionId}.`,
        error instanceof Error ? error.stack : String(error),
      );
    }
  }

  /**
   * Historial de la conversación, si el usuario participa en ella.
   *
   * @throws {NotFoundException} la conversación no existe.
   * @throws {ForbiddenException} el usuario no participa en ella.
   */
  async listar(
    conversacionId: string,
    usuarioId: string,
    orden: OrdenMensajes,
  ): Promise<MensajeConRemitente[]> {
    await this.participantesDe(conversacionId, usuarioId);
    return this.conversacionRepository.listarMensajes(conversacionId, orden);
  }

  /**
   * Participantes de la conversación, comprobando que el usuario sea uno de
   * ellos. A quien no participa no se le dice nada más que eso: ni quiénes
   * son, ni cuántos mensajes hay.
   */
  private async participantesDe(
    conversacionId: string,
    usuarioId: string,
  ): Promise<ParticipantesConversacion> {
    const participantes =
      await this.conversacionRepository.findParticipantes(conversacionId);
    if (!participantes) {
      throw new NotFoundException(MENSAJES_CONVERSACION.CONVERSACION_NO_EXISTE);
    }
    if (
      participantes.arrendadorId !== usuarioId &&
      participantes.arrendatarioId !== usuarioId
    ) {
      throw new ForbiddenException(MENSAJES_CONVERSACION.NO_PARTICIPANTE);
    }
    return participantes;
  }

  /** El participante que no es `usuarioId`: el destinatario del mensaje. */
  private otroParticipante(
    { arrendadorId, arrendatarioId }: ParticipantesConversacion,
    usuarioId: string,
  ): string {
    return usuarioId === arrendadorId ? arrendatarioId : arrendadorId;
  }
}
