import {
  ConflictException,
  ForbiddenException,
  Logger,
  NotFoundException,
  UnprocessableEntityException,
} from '@nestjs/common';
import type { BienRepository } from '@Bienes/repositories';
import type { ConversacionRepository } from '@Conversaciones/repositories';
import type { NotificacionesService } from '@Notificaciones/services';
import {
  ConversacionesService,
  MENSAJES_CONVERSACION,
} from './conversaciones.service.js';

const BIEN_ID = '7c9e6679-7425-40de-944b-e07fc1f90ae7';
const CONVERSACION_ID = '9b2f1c3e-5a4d-4e6f-8a7b-1c2d3e4f5a6b';
const ARRENDADOR = 'arrendador-1';
const ARRENDATARIO = 'arrendatario-1';

const conversacion = {
  id: CONVERSACION_ID,
  bienId: BIEN_ID,
  creadaEn: new Date('2026-11-15T15:00:00.000Z'),
  arrendador: { id: ARRENDADOR, nombreUsuario: 'dueno' },
  arrendatario: { id: ARRENDATARIO, nombreUsuario: 'inquilino' },
};

const mensaje = {
  id: 'mensaje-1',
  conversacionId: CONVERSACION_ID,
  contenido: 'Hola',
  creadoEn: new Date('2026-11-15T15:05:00.000Z'),
  remitente: { id: ARRENDATARIO, nombreUsuario: 'inquilino' },
};

function crear() {
  const conversacionRepository = {
    findPrevia: vi.fn().mockResolvedValue(null),
    crearPrevia: vi.fn().mockResolvedValue({ conversacion }),
    findParticipantes: vi.fn().mockResolvedValue({
      arrendadorId: ARRENDADOR,
      arrendatarioId: ARRENDATARIO,
    }),
    crearMensaje: vi.fn().mockResolvedValue(mensaje),
    listarMensajes: vi.fn().mockResolvedValue([mensaje]),
  };
  const bienRepository = {
    findParaConversacion: vi
      .fn()
      .mockResolvedValue({ arrendadorId: ARRENDADOR }),
  };
  const notificacionesService = {
    crear: vi
      .fn()
      .mockResolvedValue({ creada: true, notificacionId: 'aviso-1' }),
  };
  const service = new ConversacionesService(
    conversacionRepository as unknown as ConversacionRepository,
    bienRepository as unknown as BienRepository,
    notificacionesService as unknown as NotificacionesService,
  );
  return {
    service,
    conversacionRepository,
    bienRepository,
    notificacionesService,
  };
}

describe('ConversacionesService.abrir', () => {
  it('crea la conversación con el arrendador de la publicación (201)', async () => {
    const { service, conversacionRepository } = crear();

    await expect(service.abrir(BIEN_ID, ARRENDATARIO)).resolves.toEqual({
      conversacion,
      creada: true,
    });
    expect(conversacionRepository.crearPrevia).toHaveBeenCalledWith({
      bienId: BIEN_ID,
      arrendadorId: ARRENDADOR,
      arrendatarioId: ARRENDATARIO,
    });
  });

  it('recupera la que ya existía sin crear otra (200)', async () => {
    const { service, conversacionRepository } = crear();
    conversacionRepository.findPrevia.mockResolvedValue(conversacion);

    await expect(service.abrir(BIEN_ID, ARRENDATARIO)).resolves.toEqual({
      conversacion,
      creada: false,
    });
    expect(conversacionRepository.crearPrevia).not.toHaveBeenCalled();
  });

  it('si otra petición la creó a la vez, devuelve esa (200)', async () => {
    const { service, conversacionRepository } = crear();
    conversacionRepository.findPrevia
      .mockResolvedValueOnce(null)
      .mockResolvedValueOnce(conversacion);
    conversacionRepository.crearPrevia.mockResolvedValue({ duplicada: true });

    await expect(service.abrir(BIEN_ID, ARRENDATARIO)).resolves.toEqual({
      conversacion,
      creada: false,
    });
    expect(conversacionRepository.findPrevia).toHaveBeenCalledTimes(2);
  });

  it('responde 409 si tras el duplicado no puede recuperarla', async () => {
    const { service, conversacionRepository } = crear();
    conversacionRepository.crearPrevia.mockResolvedValue({ duplicada: true });

    await expect(service.abrir(BIEN_ID, ARRENDATARIO)).rejects.toThrow(
      new ConflictException(MENSAJES_CONVERSACION.CONVERSACION_NO_RECUPERADA),
    );
  });

  it('responde 404 si la publicación no existe o su arrendador está desactivado', async () => {
    const { service, bienRepository, conversacionRepository } = crear();
    bienRepository.findParaConversacion.mockResolvedValue({
      rechazo: 'NO_EXISTE',
    });

    await expect(service.abrir(BIEN_ID, ARRENDATARIO)).rejects.toThrow(
      new NotFoundException(MENSAJES_CONVERSACION.PUBLICACION_NO_EXISTE),
    );
    expect(conversacionRepository.findPrevia).not.toHaveBeenCalled();
  });

  it('responde 422 si la publicación no está ACTIVA', async () => {
    const { service, bienRepository, conversacionRepository } = crear();
    bienRepository.findParaConversacion.mockResolvedValue({
      rechazo: 'INACTIVA',
    });

    await expect(service.abrir(BIEN_ID, ARRENDATARIO)).rejects.toThrow(
      new UnprocessableEntityException(
        MENSAJES_CONVERSACION.PUBLICACION_NO_ACTIVA,
      ),
    );
    expect(conversacionRepository.crearPrevia).not.toHaveBeenCalled();
  });

  it('responde 422 si el usuario es el dueño de la publicación', async () => {
    const { service, conversacionRepository } = crear();

    await expect(service.abrir(BIEN_ID, ARRENDADOR)).rejects.toThrow(
      new UnprocessableEntityException(
        MENSAJES_CONVERSACION.PUBLICACION_PROPIA,
      ),
    );
    expect(conversacionRepository.crearPrevia).not.toHaveBeenCalled();
  });
});

describe('ConversacionesService.enviar', () => {
  it.each([
    ['el arrendatario', ARRENDATARIO],
    ['el arrendador', ARRENDADOR],
  ])('registra el mensaje de %s con su id como remitente', async (_, id) => {
    const { service, conversacionRepository } = crear();

    await expect(
      service.enviar(CONVERSACION_ID, id, '  Hola  '),
    ).resolves.toEqual(mensaje);
    expect(conversacionRepository.crearMensaje).toHaveBeenCalledWith({
      conversacionId: CONVERSACION_ID,
      remitenteId: id,
      contenido: '  Hola  ',
    });
  });

  it('responde 404 si la conversación no existe', async () => {
    const { service, conversacionRepository } = crear();
    conversacionRepository.findParticipantes.mockResolvedValue(null);

    await expect(
      service.enviar(CONVERSACION_ID, ARRENDATARIO, 'Hola'),
    ).rejects.toThrow(
      new NotFoundException(MENSAJES_CONVERSACION.CONVERSACION_NO_EXISTE),
    );
  });

  it('responde 403 a quien no participa y no guarda nada', async () => {
    const { service, conversacionRepository } = crear();

    await expect(
      service.enviar(CONVERSACION_ID, 'ajeno', 'Hola'),
    ).rejects.toThrow(
      new ForbiddenException(MENSAJES_CONVERSACION.NO_PARTICIPANTE),
    );
    expect(conversacionRepository.crearMensaje).not.toHaveBeenCalled();
  });
});

describe('ConversacionesService.enviar: aviso al Módulo 8', () => {
  let logError: ReturnType<typeof vi.spyOn>;

  beforeEach(() => {
    // Los fallos del aviso se registran con logger.error: se silencian aquí.
    logError = vi
      .spyOn(Logger.prototype, 'error')
      .mockImplementation(() => undefined);
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it('pide el aviso después de guardar el mensaje', async () => {
    const { service, conversacionRepository, notificacionesService } = crear();

    await service.enviar(CONVERSACION_ID, ARRENDATARIO, 'Hola');

    expect(notificacionesService.crear).toHaveBeenCalledTimes(1);
    const [guardado] =
      conversacionRepository.crearMensaje.mock.invocationCallOrder;
    const [aviso] = notificacionesService.crear.mock.invocationCallOrder;
    expect(guardado).toBeLessThan(aviso!);
  });

  it('avisa al arrendador con "Nuevo mensaje", MENSAJERIA y el mensaje guardado como referencia', async () => {
    const { service, notificacionesService } = crear();

    await service.enviar(CONVERSACION_ID, ARRENDATARIO, 'Hola');

    expect(notificacionesService.crear).toHaveBeenCalledWith(
      ARRENDADOR,
      'Nuevo mensaje',
      'inquilino: Hola',
      'MENSAJERIA',
      { tipoReferencia: 'MENSAJE', referenciaId: 'mensaje-1' },
    );
  });

  it('dos mensajes distintos piden dos avisos con referencias distintas', async () => {
    const { service, conversacionRepository, notificacionesService } = crear();
    conversacionRepository.crearMensaje
      .mockResolvedValueOnce({ ...mensaje, id: 'mensaje-1' })
      .mockResolvedValueOnce({
        ...mensaje,
        id: 'mensaje-2',
        contenido: 'Otro',
      });

    await service.enviar(CONVERSACION_ID, ARRENDATARIO, 'Hola');
    await service.enviar(CONVERSACION_ID, ARRENDATARIO, 'Otro');

    const referencias = notificacionesService.crear.mock.calls.map(
      (llamada) => llamada[4] as unknown,
    );
    expect(referencias).toEqual([
      { tipoReferencia: 'MENSAJE', referenciaId: 'mensaje-1' },
      { tipoReferencia: 'MENSAJE', referenciaId: 'mensaje-2' },
    ]);
  });

  it('si escribe el arrendador, el destinatario es el arrendatario', async () => {
    const { service, conversacionRepository, notificacionesService } = crear();
    conversacionRepository.crearMensaje.mockResolvedValue({
      ...mensaje,
      contenido: 'Sí, está libre',
      remitente: { id: ARRENDADOR, nombreUsuario: 'dueno' },
    });

    await service.enviar(CONVERSACION_ID, ARRENDADOR, 'Sí, está libre');

    expect(notificacionesService.crear).toHaveBeenCalledWith(
      ARRENDATARIO,
      'Nuevo mensaje',
      'dueno: Sí, está libre',
      'MENSAJERIA',
      { tipoReferencia: 'MENSAJE', referenciaId: 'mensaje-1' },
    );
  });

  it('el texto del aviso no supera 300 caracteres aunque el mensaje tenga 1000', async () => {
    const { service, conversacionRepository, notificacionesService } = crear();
    const largo = 'a'.repeat(1000);
    conversacionRepository.crearMensaje.mockResolvedValue({
      ...mensaje,
      contenido: largo,
    });

    await service.enviar(CONVERSACION_ID, ARRENDATARIO, largo);

    const texto = notificacionesService.crear.mock.calls[0]![2] as string;
    expect(texto.length).toBeLessThanOrEqual(300);
    expect(texto.startsWith('inquilino: aaa')).toBe(true);
  });

  it('un aviso ya existente del mismo mensaje (creada: false) no es un error', async () => {
    const { service, notificacionesService } = crear();
    notificacionesService.crear.mockResolvedValue({
      creada: false,
      notificacionId: 'aviso-1',
    });

    await expect(
      service.enviar(CONVERSACION_ID, ARRENDATARIO, 'Hola'),
    ).resolves.toEqual(mensaje);
    expect(logError).not.toHaveBeenCalled();
  });

  it('si el aviso falla, devuelve el mensaje guardado y registra el error', async () => {
    const { service, conversacionRepository, notificacionesService } = crear();
    notificacionesService.crear.mockRejectedValue(
      new Error('servicio de avisos caído'),
    );

    await expect(
      service.enviar(CONVERSACION_ID, ARRENDATARIO, 'Hola'),
    ).resolves.toEqual(mensaje);
    expect(conversacionRepository.crearMensaje).toHaveBeenCalledTimes(1);
    expect(logError).toHaveBeenCalledTimes(1);
  });

  it.each([
    [
      'la conversación no existe',
      (repo: ReturnType<typeof crear>['conversacionRepository']) =>
        repo.findParticipantes.mockResolvedValue(null),
      ARRENDATARIO,
    ],
    ['el usuario no participa', () => undefined, 'ajeno'],
  ])('no pide aviso si %s', async (_, preparar, usuario) => {
    const { service, conversacionRepository, notificacionesService } = crear();
    preparar(conversacionRepository);

    await expect(
      service.enviar(CONVERSACION_ID, usuario, 'Hola'),
    ).rejects.toThrow();
    expect(notificacionesService.crear).not.toHaveBeenCalled();
  });

  it('abrir y listar no piden avisos', async () => {
    const { service, notificacionesService } = crear();

    await service.abrir(BIEN_ID, ARRENDATARIO);
    await service.listar(CONVERSACION_ID, ARRENDATARIO, 'asc');

    expect(notificacionesService.crear).not.toHaveBeenCalled();
  });
});

describe('ConversacionesService.listar', () => {
  it('devuelve el historial a un participante, en el orden pedido', async () => {
    const { service, conversacionRepository } = crear();

    await expect(
      service.listar(CONVERSACION_ID, ARRENDADOR, 'desc'),
    ).resolves.toEqual([mensaje]);
    expect(conversacionRepository.listarMensajes).toHaveBeenCalledWith(
      CONVERSACION_ID,
      'desc',
    );
  });

  it('responde 404 si la conversación no existe', async () => {
    const { service, conversacionRepository } = crear();
    conversacionRepository.findParticipantes.mockResolvedValue(null);

    await expect(
      service.listar(CONVERSACION_ID, ARRENDATARIO, 'asc'),
    ).rejects.toThrow(NotFoundException);
  });

  it('responde 403 a quien no participa sin leer los mensajes', async () => {
    const { service, conversacionRepository } = crear();

    await expect(
      service.listar(CONVERSACION_ID, 'ajeno', 'asc'),
    ).rejects.toThrow(ForbiddenException);
    expect(conversacionRepository.listarMensajes).not.toHaveBeenCalled();
  });
});
