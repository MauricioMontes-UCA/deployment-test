import type { BienRepository } from '@Bienes/repositories';

import type { ConversacionRepository } from '@Conversaciones/repositories';

import type { NotificacionesService } from '@Notificaciones/services';

import { ConversacionesService } from './conversaciones.service.js';

describe('BE-13.2 ConversacionesService.listarBandeja', () => {
  it('devuelve los datos del repositorio sin construir DTOs HTTP', async () => {
    const resultado = {
      conversaciones: [
        {
          id: 'conv-1',
        },
      ],
      total: 21,
    };

    const listarBandeja = vi.fn().mockResolvedValue(resultado);

    const service = new ConversacionesService(
      {
        listarBandeja,
      } as unknown as ConversacionRepository,

      {} as BienRepository,
      {} as NotificacionesService,
    );

    const respuesta = await service.listarBandeja('usuario-1', {
      tipo: 'CONSULTA',
      pagina: 1,
    });

    expect(listarBandeja).toHaveBeenCalledWith('usuario-1', 'CONSULTA', 1);

    expect(respuesta).toBe(resultado);

    expect(respuesta).not.toHaveProperty('items');
    expect(respuesta).not.toHaveProperty('hayMas');
  });
});
