import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsIn, IsOptional } from 'class-validator';

export const ORDENES_MENSAJES = ['asc', 'desc'] as const;

export type OrdenMensajes = (typeof ORDENES_MENSAJES)[number];

/** Query de `GET /conversaciones/:id/mensajes`. */
export class ConsultarMensajesDto {
  @ApiPropertyOptional({
    enum: ORDENES_MENSAJES,
    default: 'asc',
    description:
      'asc: del más antiguo al más reciente (cronológico). desc: al revés.',
  })
  @IsOptional()
  @IsIn(ORDENES_MENSAJES, { message: 'El orden debe ser asc o desc' })
  orden: OrdenMensajes = 'asc';
}
