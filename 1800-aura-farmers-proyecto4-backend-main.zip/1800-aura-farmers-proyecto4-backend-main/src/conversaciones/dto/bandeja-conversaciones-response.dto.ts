import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

import type { ConversacionBandeja } from '@Conversaciones/repositories';

import {
  TIPOS_CONVERSACION,
  type TipoConversacion,
} from './consultar-conversaciones.dto.js';

import { ParticipanteResponseDto } from './conversacion-response.dto.js';

export class BienConversacionResponseDto {
  @ApiProperty({ format: 'uuid' })
  id!: string;

  @ApiProperty()
  titulo!: string;

  @ApiPropertyOptional({
    type: String,
    nullable: true,
  })
  fotoPrincipalUrl!: string | null;
}

export class UltimoMensajeConversacionResponseDto {
  @ApiProperty({
    description: 'Primeros 120 caracteres del mensaje.',
  })
  contenido!: string;

  @ApiProperty({
    type: String,
    format: 'date-time',
  })
  enviadoEn!: string;

  @ApiProperty({ format: 'uuid' })
  remitenteId!: string;
}

export class ConversacionBandejaResponseDto {
  @ApiProperty({ format: 'uuid' })
  id!: string;

  @ApiProperty({ enum: TIPOS_CONVERSACION })
  tipo!: TipoConversacion;

  @ApiProperty({
    type: BienConversacionResponseDto,
  })
  bien!: BienConversacionResponseDto;

  @ApiPropertyOptional({
    format: 'uuid',
    nullable: true,
  })
  reservaId!: string | null;

  @ApiProperty({
    type: ParticipanteResponseDto,
  })
  otroParticipante!: ParticipanteResponseDto;

  @ApiPropertyOptional({
    type: UltimoMensajeConversacionResponseDto,
    nullable: true,
  })
  ultimoMensaje!: UltimoMensajeConversacionResponseDto | null;

  @ApiProperty({
    type: String,
    format: 'date-time',
  })
  actualizadaEn!: string;

  static from(
    conversacion: ConversacionBandeja,
    usuarioId: string,
  ): ConversacionBandejaResponseDto {
    const mensaje = conversacion.mensajes[0];

    return {
      id: conversacion.id,

      tipo: conversacion.reservaId === null ? 'CONSULTA' : 'COORDINACION',

      bien: {
        id: conversacion.bien.id,
        titulo: conversacion.bien.titulo,
        fotoPrincipalUrl: conversacion.bien.fotos[0]?.url ?? null,
      },

      reservaId: conversacion.reservaId,

      otroParticipante:
        conversacion.arrendadorId === usuarioId
          ? conversacion.arrendatario
          : conversacion.arrendador,

      ultimoMensaje: mensaje
        ? {
            contenido: Array.from(mensaje.contenido).slice(0, 120).join(''),
            enviadoEn: mensaje.creadoEn.toISOString(),
            remitenteId: mensaje.remitenteId,
          }
        : null,

      actualizadaEn: (mensaje?.creadoEn ?? conversacion.creadaEn).toISOString(),
    };
  }
}

export class BandejaConversacionesResponseDto {
  @ApiProperty({
    type: [ConversacionBandejaResponseDto],
  })
  items!: ConversacionBandejaResponseDto[];

  @ApiProperty({ example: 1 })
  pagina!: number;

  @ApiProperty({ example: 123 })
  total!: number;

  @ApiProperty({ example: true })
  hayMas!: boolean;
}
