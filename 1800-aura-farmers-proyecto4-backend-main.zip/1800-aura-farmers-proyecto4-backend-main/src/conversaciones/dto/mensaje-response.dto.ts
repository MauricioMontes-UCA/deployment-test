import { ApiProperty } from '@nestjs/swagger';
import type { MensajeConRemitente } from '@Conversaciones/repositories';
import {
  ORDENES_MENSAJES,
  type OrdenMensajes,
} from './consultar-mensajes.dto.js';
import { ParticipanteResponseDto } from './conversacion-response.dto.js';

/** Un mensaje con su autor y su fecha. */
export class MensajeResponseDto {
  @ApiProperty({ format: 'uuid' })
  id!: string;

  @ApiProperty({ format: 'uuid' })
  conversacionId!: string;

  @ApiProperty({
    type: ParticipanteResponseDto,
    description:
      'Autor del mensaje: siempre el usuario del token que lo envió.',
  })
  remitente!: ParticipanteResponseDto;

  @ApiProperty({
    example: 'Hola, ¿el salón está disponible el 20 de diciembre?',
  })
  contenido!: string;

  @ApiProperty({ type: String, format: 'date-time' })
  creadoEn!: Date;

  static from(mensaje: MensajeConRemitente): MensajeResponseDto {
    return {
      id: mensaje.id,
      conversacionId: mensaje.conversacionId,
      remitente: ParticipanteResponseDto.from(mensaje.remitente),
      contenido: mensaje.contenido,
      creadoEn: mensaje.creadoEn,
    };
  }
}

/** Historial de una conversación. */
export class MensajesResponseDto {
  @ApiProperty({ format: 'uuid' })
  conversacionId!: string;

  @ApiProperty({ enum: ORDENES_MENSAJES, example: 'asc' })
  orden!: OrdenMensajes;

  @ApiProperty({ type: [MensajeResponseDto] })
  mensajes!: MensajeResponseDto[];

  static from(
    conversacionId: string,
    orden: OrdenMensajes,
    mensajes: MensajeConRemitente[],
  ): MensajesResponseDto {
    return {
      conversacionId,
      orden,
      mensajes: mensajes.map((mensaje) => MensajeResponseDto.from(mensaje)),
    };
  }
}
