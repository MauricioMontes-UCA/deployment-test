import { Transform } from 'class-transformer';
import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsIn, IsInt, IsOptional, Max, Min } from 'class-validator';

import { PAGINA_MAXIMA } from '@Bienes/constants';

export const TIPOS_CONVERSACION = ['CONSULTA', 'COORDINACION'] as const;

export type TipoConversacion = (typeof TIPOS_CONVERSACION)[number];

/** Filtros de la bandeja de conversaciones. */
export class ConsultarConversacionesDto {
  @ApiPropertyOptional({
    enum: TIPOS_CONVERSACION,
  })
  @IsOptional()
  @IsIn(TIPOS_CONVERSACION)
  tipo?: TipoConversacion;

  @ApiPropertyOptional({
    type: Number,
    minimum: 1,
    maximum: PAGINA_MAXIMA,
    default: 1,
  })
  @Transform(({ value }: { value: unknown }) => {
    if (value === undefined) return 1;

    if (typeof value !== 'string' || !/^[1-9]\d*$/.test(value)) {
      return Number.NaN;
    }

    return Number(value);
  })
  @IsInt()
  @Min(1)
  @Max(PAGINA_MAXIMA)
  pagina: number = 1;
}
