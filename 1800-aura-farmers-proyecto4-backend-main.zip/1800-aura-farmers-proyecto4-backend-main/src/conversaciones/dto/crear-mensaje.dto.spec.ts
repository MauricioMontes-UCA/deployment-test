import { plainToInstance } from 'class-transformer';
import { validate } from 'class-validator';
import {
  CrearMensajeDto,
  MENSAJE_LONGITUD_INVALIDA,
} from './crear-mensaje.dto.js';
import { ConsultarMensajesDto } from './consultar-mensajes.dto.js';

async function validar(cuerpo: Record<string, unknown>) {
  const dto = plainToInstance(CrearMensajeDto, cuerpo);
  const errores = await validate(dto);
  return {
    dto,
    mensajes: errores.flatMap((error) =>
      Object.values(error.constraints ?? {}),
    ),
  };
}

describe('CrearMensajeDto', () => {
  it('acepta un mensaje de 1 carácter y uno de 1000', async () => {
    expect((await validar({ contenido: 'a' })).mensajes).toEqual([]);
    expect((await validar({ contenido: 'a'.repeat(1000) })).mensajes).toEqual(
      [],
    );
  });

  it('rechaza más de 1000 caracteres con el mensaje de la historia', async () => {
    expect((await validar({ contenido: 'a'.repeat(1001) })).mensajes).toEqual([
      MENSAJE_LONGITUD_INVALIDA,
    ]);
  });

  it.each(['', ' ', '   ', '\n\t '])(
    'rechaza un mensaje vacío o de solo espacios (%j)',
    async (contenido) => {
      expect((await validar({ contenido })).mensajes).toEqual([
        MENSAJE_LONGITUD_INVALIDA,
      ]);
    },
  );

  it('conserva el texto original, con sus espacios', async () => {
    const { dto, mensajes } = await validar({ contenido: '  Hola  \n' });

    expect(mensajes).toEqual([]);
    expect(dto.contenido).toBe('  Hola  \n');
  });

  it('cuenta caracteres y no unidades UTF-16: 1000 emojis caben', async () => {
    expect((await validar({ contenido: '😀'.repeat(1000) })).mensajes).toEqual(
      [],
    );
    expect((await validar({ contenido: '😀'.repeat(1001) })).mensajes).toEqual([
      MENSAJE_LONGITUD_INVALIDA,
    ]);
  });

  it.each([undefined, null, 5, ['hola'], { texto: 'hola' }])(
    'rechaza un contenido que no es texto (%j)',
    async (contenido) => {
      expect((await validar({ contenido })).mensajes).toContain(
        'El mensaje debe ser texto',
      );
    },
  );
});

describe('ConsultarMensajesDto', () => {
  it('usa orden asc si no se envía', async () => {
    const dto = plainToInstance(ConsultarMensajesDto, {});

    expect(await validate(dto)).toEqual([]);
    expect(dto.orden).toBe('asc');
  });

  it.each(['asc', 'desc'])('acepta orden=%s', async (orden) => {
    const dto = plainToInstance(ConsultarMensajesDto, { orden });

    expect(await validate(dto)).toEqual([]);
    expect(dto.orden).toBe(orden);
  });

  it.each(['ASC', 'fecha', ''])('rechaza orden=%j', async (orden) => {
    const errores = await validate(
      plainToInstance(ConsultarMensajesDto, { orden }),
    );

    expect(errores.map((error) => error.property)).toEqual(['orden']);
  });
});
