import { ApiProperty } from '@nestjs/swagger';
import { IsString, ValidateBy } from 'class-validator';

export const LONGITUD_MAXIMA_MENSAJE = 1000;

export const MENSAJE_LONGITUD_INVALIDA =
  'El mensaje debe contener entre 1 y 1000 caracteres';

/**
 * Indica si el contenido tiene entre 1 y 1000 caracteres y no es solo
 * espacios.
 *
 * Se cuentan caracteres y no unidades UTF-16, igual que `VARCHAR(1000)` en
 * PostgreSQL: un emoji cuenta como uno. El texto no se modifica; el recorte
 * solo sirve para descartar un mensaje vacío o de espacios.
 */
export function esContenidoValido(valor: unknown): boolean {
  return (
    typeof valor === 'string' &&
    valor.trim().length > 0 &&
    contarCaracteres(valor) <= LONGITUD_MAXIMA_MENSAJE
  );
}

/**
 * Caracteres del texto como los cuenta PostgreSQL (`char_length`): cada punto
 * de código Unicode vale uno, aunque en UTF-16 ocupe dos unidades.
 */
function contarCaracteres(texto: string): number {
  let total = 0;
  for (const _caracter of texto) total++;
  return total;
}

/**
 * Cuerpo de `POST /conversaciones/:id/mensajes`.
 *
 * El remitente no viaja en el cuerpo: sale siempre del token.
 */
export class CrearMensajeDto {
  @ApiProperty({
    minLength: 1,
    maxLength: LONGITUD_MAXIMA_MENSAJE,
    example: 'Hola, ¿el salón está disponible el 20 de diciembre?',
    description:
      'Texto del mensaje. Se guarda tal como llega; no puede estar vacío ni ser solo espacios.',
  })
  @IsString({ message: 'El mensaje debe ser texto' })
  @ValidateBy(
    {
      name: 'contenidoMensaje',
      validator: { validate: esContenidoValido },
    },
    { message: MENSAJE_LONGITUD_INVALIDA },
  )
  contenido!: string;
}
