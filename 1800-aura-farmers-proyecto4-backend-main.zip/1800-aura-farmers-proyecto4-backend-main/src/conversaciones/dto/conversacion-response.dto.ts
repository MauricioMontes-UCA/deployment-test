import { ApiProperty } from '@nestjs/swagger';
import type {
  ConversacionConParticipantes,
  Participante,
} from '@Conversaciones/repositories';

/** Usuario que participa en una conversación: nunca su email ni su rol. */
export class ParticipanteResponseDto {
  @ApiProperty({ format: 'uuid' })
  id!: string;

  @ApiProperty({ example: 'ana_m' })
  nombreUsuario!: string;

  static from(participante: Participante): ParticipanteResponseDto {
    return {
      id: participante.id,
      nombreUsuario: participante.nombreUsuario,
    };
  }
}

/** Conversación previa a una reserva entre el arrendatario y el arrendador. */
export class ConversacionResponseDto {
  @ApiProperty({ format: 'uuid' })
  id!: string;

  @ApiProperty({ format: 'uuid' })
  bienId!: string;

  @ApiProperty({
    type: ParticipanteResponseDto,
    description: 'Dueño de la publicación.',
  })
  arrendador!: ParticipanteResponseDto;

  @ApiProperty({
    type: ParticipanteResponseDto,
    description: 'Quien inició la consulta.',
  })
  arrendatario!: ParticipanteResponseDto;

  @ApiProperty({ type: String, format: 'date-time' })
  creadaEn!: Date;

  static from(
    conversacion: ConversacionConParticipantes,
  ): ConversacionResponseDto {
    return {
      id: conversacion.id,
      bienId: conversacion.bienId,
      arrendador: ParticipanteResponseDto.from(conversacion.arrendador),
      arrendatario: ParticipanteResponseDto.from(conversacion.arrendatario),
      creadaEn: conversacion.creadaEn,
    };
  }
}
