import { ApiProperty } from '@nestjs/swagger';
import { formatDia } from '@Bienes/utils';
import { EstadoReserva } from '@PrismaClient';
import type {
  ConversacionDeReserva,
  ReservaParaCoordinacion,
} from '@Conversaciones/repositories';
import { ParticipanteResponseDto } from './conversacion-response.dto.js';

/** El bien de la reserva: solo lo que se muestra en la coordinación. */
export class BienCoordinacionResponseDto {
  @ApiProperty({ format: 'uuid' })
  id!: string;

  @ApiProperty({ example: 'Salón de eventos' })
  titulo!: string;
}

/**
 * Conversación de coordinación de una reserva (H14), con el resumen de la
 * reserva que necesitan ver los dos participantes.
 *
 * No incluye correos, roles, montos ni datos internos de la reserva.
 */
export class ConversacionReservaResponseDto {
  @ApiProperty({ format: 'uuid' })
  id!: string;

  @ApiProperty({ format: 'uuid' })
  reservaId!: string;

  @ApiProperty({
    enum: Object.values(EstadoReserva),
    example: EstadoReserva.CONFIRMADA,
    description:
      'Estado actual de la reserva. Una conversación que ya existe se lee en cualquier estado (por ejemplo, FINALIZADA o CANCELADA); crearla o enviar mensajes solo se puede con la reserva CONFIRMADA o EN_CURSO.',
  })
  estado!: EstadoReserva;

  @ApiProperty({
    example: '2026-12-20',
    description: 'Primer día de la reserva, AAAA-MM-DD.',
  })
  fechaInicio!: string;

  @ApiProperty({
    example: '2026-12-22',
    description: 'Último día de la reserva, inclusive, AAAA-MM-DD.',
  })
  fechaFin!: string;

  @ApiProperty({ type: BienCoordinacionResponseDto })
  bien!: BienCoordinacionResponseDto;

  @ApiProperty({
    type: ParticipanteResponseDto,
    description: 'Dueño del bien.',
  })
  arrendador!: ParticipanteResponseDto;

  @ApiProperty({
    type: ParticipanteResponseDto,
    description: 'Quien hizo la reserva.',
  })
  arrendatario!: ParticipanteResponseDto;

  @ApiProperty({
    type: String,
    format: 'date-time',
    description: 'Cuándo se creó la conversación.',
  })
  creadaEn!: Date;

  static from(
    conversacion: ConversacionDeReserva,
    reserva: ReservaParaCoordinacion,
  ): ConversacionReservaResponseDto {
    return {
      id: conversacion.id,
      reservaId: reserva.id,
      estado: reserva.estado,
      fechaInicio: formatDia(reserva.fechaInicio),
      fechaFin: formatDia(reserva.fechaFin),
      bien: { id: reserva.bienId, titulo: reserva.bien.titulo },
      arrendador: ParticipanteResponseDto.from(conversacion.arrendador),
      arrendatario: ParticipanteResponseDto.from(conversacion.arrendatario),
      creadaEn: conversacion.creadaEn,
    };
  }
}
