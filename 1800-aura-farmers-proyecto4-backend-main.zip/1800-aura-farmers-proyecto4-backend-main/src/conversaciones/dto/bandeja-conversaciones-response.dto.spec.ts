import { plainToInstance } from 'class-transformer';
import { validate } from 'class-validator';

import type { ConversacionBandeja } from '@Conversaciones/repositories';

import { ConsultarConversacionesDto } from './consultar-conversaciones.dto.js';

import { ConversacionBandejaResponseDto } from './bandeja-conversaciones-response.dto.js';

const fecha = new Date('2026-11-19T12:00:00.000Z');

const base = {
  id: 'conv-1',
  reservaId: null,
  creadaEn: fecha,
  arrendadorId: 'dueno',

  arrendador: {
    id: 'dueno',
    nombreUsuario: 'dueno',
  },

  arrendatario: {
    id: 'inquilino',
    nombreUsuario: 'inquilino',
  },

  bien: {
    id: 'bien-1',
    titulo: 'Cámara',
    fotos: [
      {
        url: '/foto.jpg',
      },
    ],
  },

  mensajes: [
    {
      contenido: '¡'.repeat(121),
      creadoEn: new Date('2026-11-19T13:00:00.000Z'),
      remitenteId: 'inquilino',
    },
  ],
} as ConversacionBandeja;

describe('BE-13.2 DTO de bandeja', () => {
  it('expone al otro participante, foto y último mensaje', () => {
    const dto = ConversacionBandejaResponseDto.from(base, 'dueno');

    expect(dto.tipo).toBe('CONSULTA');

    expect(dto.otroParticipante.nombreUsuario).toBe('inquilino');

    expect(dto.bien.fotoPrincipalUrl).toBe('/foto.jpg');

    expect(Array.from(dto.ultimoMensaje!.contenido)).toHaveLength(120);

    expect(dto.actualizadaEn).toBe('2026-11-19T13:00:00.000Z');
  });

  it('identifica coordinación y admite conversaciones sin mensajes', () => {
    const conversacion = {
      ...base,
      reservaId: 'reserva-1',
      mensajes: [],

      bien: {
        ...base.bien,
        fotos: [],
      },
    } as ConversacionBandeja;

    const dto = ConversacionBandejaResponseDto.from(conversacion, 'inquilino');

    expect(dto.tipo).toBe('COORDINACION');

    expect(dto.otroParticipante.nombreUsuario).toBe('dueno');

    expect(dto.ultimoMensaje).toBeNull();
    expect(dto.bien.fotoPrincipalUrl).toBeNull();

    expect(dto.actualizadaEn).toBe(fecha.toISOString());
  });

  it.each(['0', '-1', '1.5', 'abc', '', '9007199254740991'])(
    'rechaza pagina=%s',
    async (pagina) => {
      const dto = plainToInstance(ConsultarConversacionesDto, { pagina });

      expect(await validate(dto)).not.toHaveLength(0);
    },
  );

  it('rechaza un tipo inválido', async () => {
    const dto = plainToInstance(ConsultarConversacionesDto, {
      tipo: 'OTRO',
    });

    expect(await validate(dto)).not.toHaveLength(0);
  });

  it('acepta filtros válidos', async () => {
    const dto = plainToInstance(ConsultarConversacionesDto, {
      tipo: 'CONSULTA',
      pagina: '2',
    });

    expect(await validate(dto)).toHaveLength(0);
    expect(dto.pagina).toBe(2);
  });
});
