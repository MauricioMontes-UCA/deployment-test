import { EstadoReserva } from '@PrismaClient';

/** Título del aviso que recibe el otro participante de la reserva (H14). */
export const TITULO_MENSAJE_ENTREGA = 'Mensaje sobre la entrega';

/**
 * Tipo de la referencia del aviso de coordinación: su `referenciaId` es el id
 * del mensaje.
 *
 * El Módulo 8 descarta un segundo aviso con el mismo destinatario y la misma
 * referencia. Con la reserva o la conversación como referencia, cada
 * participante recibiría un solo aviso en toda la reserva; con el mensaje,
 * cada mensaje genera el suyo. La conversación y la reserva se obtienen del
 * mensaje (`Mensajes.conversacion_id` y `Conversaciones.reserva_id`).
 */
export const REFERENCIA_AVISO_COORDINACION = 'MENSAJE';

/**
 * Estados de la reserva en los que se puede crear la conversación de
 * coordinación o escribir en ella. Una conversación que ya existe se lee en
 * cualquier estado.
 */
export const ESTADOS_COORDINACION: readonly EstadoReserva[] = [
  EstadoReserva.CONFIRMADA,
  EstadoReserva.EN_CURSO,
];

export const MENSAJES_COORDINACION = {
  RESERVA_NO_EXISTE: 'La reserva no existe.',
  NO_PARTICIPANTE: 'No participas en la coordinación de esta reserva.',
  ESTADO_NO_PERMITIDO:
    'La coordinación está disponible cuando la reserva está confirmada o en curso',
  CONVERSACION_NO_RECUPERADA:
    'No se pudo recuperar la conversación. Intenta de nuevo.',
} as const;

/** Si la reserva está en un estado que permite coordinar la entrega. */
export function admiteCoordinacion(estado: EstadoReserva): boolean {
  return ESTADOS_COORDINACION.includes(estado);
}
