import { EstadoReserva } from '@PrismaClient';
import {
  admiteCoordinacion,
  ESTADOS_COORDINACION,
  MENSAJES_COORDINACION,
  REFERENCIA_AVISO_COORDINACION,
  TITULO_MENSAJE_ENTREGA,
} from './coordinacion.js';

describe('coordinación de la entrega (H14)', () => {
  it('el título del aviso es exactamente el de la especificación', () => {
    expect(TITULO_MENSAJE_ENTREGA).toBe('Mensaje sobre la entrega');
  });

  it('el aviso usa el mensaje como referencia', () => {
    expect(REFERENCIA_AVISO_COORDINACION).toBe('MENSAJE');
  });

  it('el mensaje del 422 es el de la historia H14', () => {
    expect(MENSAJES_COORDINACION.ESTADO_NO_PERMITIDO).toBe(
      'La coordinación está disponible cuando la reserva está confirmada o en curso',
    );
    expect(MENSAJES_COORDINACION.RESERVA_NO_EXISTE).toBe(
      'La reserva no existe.',
    );
  });

  it('solo CONFIRMADA y EN_CURSO admiten coordinación', () => {
    expect(ESTADOS_COORDINACION).toEqual([
      EstadoReserva.CONFIRMADA,
      EstadoReserva.EN_CURSO,
    ]);
  });

  it.each([
    [EstadoReserva.CONFIRMADA, true],
    [EstadoReserva.EN_CURSO, true],
    [EstadoReserva.EN_COLA, false],
    [EstadoReserva.RECHAZADA, false],
    [EstadoReserva.FINALIZADA, false],
    [EstadoReserva.CANCELADA, false],
  ])('admiteCoordinacion(%s) es %s', (estado, esperado) => {
    expect(admiteCoordinacion(estado)).toBe(esperado);
  });

  it('cubre todos los estados de la reserva', () => {
    expect(Object.values(EstadoReserva).sort()).toEqual(
      [
        'CANCELADA',
        'CONFIRMADA',
        'EN_COLA',
        'EN_CURSO',
        'FINALIZADA',
        'RECHAZADA',
      ].sort(),
    );
  });
});
