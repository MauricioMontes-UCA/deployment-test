import {
  LONGITUD_MAXIMA_AVISO,
  TIPO_REFERENCIA_MENSAJE,
  TITULO_NUEVO_MENSAJE,
  construirMensajeNotificacion,
} from './mensaje-notificacion.js';

describe('construirMensajeNotificacion', () => {
  it('arma "<nombreUsuario>: <contenido>"', () => {
    expect(construirMensajeNotificacion('ana_m', '¿Sigue disponible?')).toBe(
      'ana_m: ¿Sigue disponible?',
    );
  });

  it('reduce saltos de línea y espacios repetidos a uno', () => {
    expect(
      construirMensajeNotificacion('ana_m', '  Hola,\n\n  ¿qué tal?  '),
    ).toBe('ana_m: Hola, ¿qué tal?');
  });

  it('no corta un texto de exactamente 300', () => {
    const contenido = 'a'.repeat(LONGITUD_MAXIMA_AVISO - 'ana_m: '.length);
    const texto = construirMensajeNotificacion('ana_m', contenido);

    expect(texto).toHaveLength(LONGITUD_MAXIMA_AVISO);
    expect(texto.endsWith('…')).toBe(false);
  });

  it('corta un mensaje largo a 300 y termina en "…"', () => {
    const texto = construirMensajeNotificacion('ana_m', 'a'.repeat(1000));

    expect(texto).toHaveLength(LONGITUD_MAXIMA_AVISO);
    expect(texto.startsWith('ana_m: aaa')).toBe(true);
    expect(texto.endsWith('…')).toBe(true);
  });

  it('nunca supera 300 unidades UTF-16 ni parte un emoji', () => {
    const texto = construirMensajeNotificacion('ana_m', '😀'.repeat(1000));

    expect(texto.length).toBeLessThanOrEqual(LONGITUD_MAXIMA_AVISO);
    expect(texto.endsWith('…')).toBe(true);
    // Sin la mitad suelta de un par sustituto antes de los puntos suspensivos.
    expect(texto.slice(0, -1)).toMatch(/^ana_m: (😀)+$/u);
  });

  it('el título y el tipo de referencia son los que pide la historia', () => {
    expect(TITULO_NUEVO_MENSAJE).toBe('Nuevo mensaje');
    expect(TIPO_REFERENCIA_MENSAJE).toBe('MENSAJE');
  });
});
