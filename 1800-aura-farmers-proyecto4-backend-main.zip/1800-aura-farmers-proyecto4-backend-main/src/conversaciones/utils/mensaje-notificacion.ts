/** Título del aviso que recibe el otro participante (H13). */
export const TITULO_NUEVO_MENSAJE = 'Nuevo mensaje';

/**
 * Tipo de la referencia del aviso: su `referenciaId` es el id del mensaje.
 *
 * Cada mensaje es un evento distinto, así que cada uno genera su propio aviso;
 * el Módulo 8 solo descarta un segundo aviso del mismo mensaje. La
 * conversación se obtiene del mensaje (`Mensajes.conversacion_id`).
 */
export const TIPO_REFERENCIA_MENSAJE = 'MENSAJE';

/** Largo máximo que acepta `NotificacionesService.crear` para el mensaje. */
export const LONGITUD_MAXIMA_AVISO = 300;

const PUNTOS_SUSPENSIVOS = '…';

/**
 * Texto del aviso de un mensaje nuevo: `"<nombreUsuario>: <contenido>"`.
 *
 * Los saltos de línea y los espacios repetidos se reducen a uno, porque el
 * aviso es una vista previa de una sola línea. Si no cabe, se corta y termina
 * en "…".
 *
 * El límite se mide en unidades UTF-16, igual que `mensaje.length` en
 * `NotificacionesService.crear`, que rechaza más de 300. El corte se hace
 * entre caracteres completos para no partir un emoji por la mitad.
 */
export function construirMensajeNotificacion(
  nombreUsuario: string,
  contenido: string,
): string {
  const texto = `${nombreUsuario}: ${contenido.replace(/\s+/g, ' ').trim()}`;
  if (texto.length <= LONGITUD_MAXIMA_AVISO) return texto;

  const limite = LONGITUD_MAXIMA_AVISO - PUNTOS_SUSPENSIVOS.length;
  let recortado = '';
  for (const caracter of texto) {
    if (recortado.length + caracter.length > limite) break;
    recortado += caracter;
  }
  return `${recortado.trimEnd()}${PUNTOS_SUSPENSIVOS}`;
}
