import { Prisma } from '@PrismaClient';
import type { PrismaService } from '@Prisma/services';
import {
  CONVERSACION_RESERVA_SELECT,
  CONVERSACION_SELECT,
  ConversacionRepository,
  MENSAJE_SELECT,
  RESERVA_COORDINACION_SELECT,
} from './conversacion.repository.js';

const BIEN_ID = '7c9e6679-7425-40de-944b-e07fc1f90ae7';
const CONVERSACION_ID = '9b2f1c3e-5a4d-4e6f-8a7b-1c2d3e4f5a6b';

function crear() {
  const prisma = {
    conversacion: {
      findFirst: vi.fn().mockResolvedValue(null),
      findUnique: vi.fn().mockResolvedValue(null),
      create: vi.fn(),
    },
    mensaje: {
      create: vi.fn(),
      findMany: vi.fn().mockResolvedValue([]),
    },
    reserva: {
      findUnique: vi.fn().mockResolvedValue(null),
    },
  };
  const repository = new ConversacionRepository(
    prisma as unknown as PrismaService,
  );
  return { repository, prisma };
}

function errorPrisma(code: string) {
  return new Prisma.PrismaClientKnownRequestError('fallo', {
    code,
    clientVersion: 'test',
  });
}

describe('ConversacionRepository', () => {
  it('busca la conversación previa: sin reserva, por bien y arrendatario', async () => {
    const { repository, prisma } = crear();

    await repository.findPrevia(BIEN_ID, 'arrendatario-1');

    expect(prisma.conversacion.findFirst).toHaveBeenCalledWith({
      where: {
        bienId: BIEN_ID,
        arrendatarioId: 'arrendatario-1',
        reservaId: null,
      },
      select: CONVERSACION_SELECT,
    });
  });

  it('de los participantes solo lee id y nombre de usuario', () => {
    const participante = { select: { id: true, nombreUsuario: true } };

    expect(CONVERSACION_SELECT.arrendador).toEqual(participante);
    expect(CONVERSACION_SELECT.arrendatario).toEqual(participante);
    expect(MENSAJE_SELECT.remitente).toEqual(participante);
  });

  it('crea la conversación previa sin reserva', async () => {
    const { repository, prisma } = crear();
    const conversacion = { id: CONVERSACION_ID };
    prisma.conversacion.create.mockResolvedValue(conversacion);

    const datos = {
      bienId: BIEN_ID,
      arrendadorId: 'arrendador-1',
      arrendatarioId: 'arrendatario-1',
    };

    await expect(repository.crearPrevia(datos)).resolves.toEqual({
      conversacion,
    });
    expect(prisma.conversacion.create).toHaveBeenCalledWith({
      data: datos,
      select: CONVERSACION_SELECT,
    });
  });

  it('devuelve duplicada si el índice único la rechaza (P2002)', async () => {
    const { repository, prisma } = crear();
    prisma.conversacion.create.mockRejectedValue(errorPrisma('P2002'));

    await expect(
      repository.crearPrevia({
        bienId: BIEN_ID,
        arrendadorId: 'arrendador-1',
        arrendatarioId: 'arrendatario-1',
      }),
    ).resolves.toEqual({ duplicada: true });
  });

  it('propaga los demás errores de la base', async () => {
    const { repository, prisma } = crear();
    const error = errorPrisma('P2003');
    prisma.conversacion.create.mockRejectedValue(error);

    await expect(
      repository.crearPrevia({
        bienId: BIEN_ID,
        arrendadorId: 'arrendador-1',
        arrendatarioId: 'arrendatario-1',
      }),
    ).rejects.toBe(error);
  });

  it('lee solo los participantes y únicamente de una conversación previa (sin reserva)', async () => {
    const { repository, prisma } = crear();

    await repository.findParticipantes(CONVERSACION_ID);

    // findFirst: Prisma no acepta reservaId: null dentro de un findUnique.
    expect(prisma.conversacion.findFirst).toHaveBeenCalledWith({
      where: { id: CONVERSACION_ID, reservaId: null },
      select: { arrendadorId: true, arrendatarioId: true },
    });
  });

  it('guarda el mensaje tal como llega', async () => {
    const { repository, prisma } = crear();
    const datos = {
      conversacionId: CONVERSACION_ID,
      remitenteId: 'arrendatario-1',
      contenido: '  Hola  ',
    };

    await repository.crearMensaje(datos);

    expect(prisma.mensaje.create).toHaveBeenCalledWith({
      data: datos,
      select: MENSAJE_SELECT,
    });
  });

  it.each(['asc', 'desc'] as const)(
    'lista los mensajes en orden %s, desempatando por id',
    async (orden) => {
      const { repository, prisma } = crear();

      await repository.listarMensajes(CONVERSACION_ID, orden);

      expect(prisma.mensaje.findMany).toHaveBeenCalledWith({
        where: { conversacionId: CONVERSACION_ID },
        orderBy: [{ creadoEn: orden }, { id: orden }],
        select: MENSAJE_SELECT,
      });
    },
  );
});

describe('ConversacionRepository: coordinación por reserva (H14)', () => {
  const RESERVA_ID = '3f1a2b4c-5d6e-4f70-8a91-b2c3d4e5f607';
  const datos = {
    reservaId: RESERVA_ID,
    bienId: BIEN_ID,
    arrendadorId: 'arrendador-1',
    arrendatarioId: 'arrendatario-1',
  };

  it('lee la reserva por id con su estado, fechas, bien y participantes', async () => {
    const { repository, prisma } = crear();

    await repository.findReservaParaCoordinacion(RESERVA_ID);

    expect(prisma.reserva.findUnique).toHaveBeenCalledWith({
      where: { id: RESERVA_ID },
      select: RESERVA_COORDINACION_SELECT,
    });
  });

  it('de la reserva solo lee lo necesario: ni montos ni datos internos', () => {
    expect(RESERVA_COORDINACION_SELECT).toEqual({
      id: true,
      bienId: true,
      arrendatarioId: true,
      estado: true,
      fechaInicio: true,
      fechaFin: true,
      bien: { select: { titulo: true, arrendadorId: true } },
    });
  });

  it('de los participantes de la conversación solo lee id y nombre de usuario', () => {
    const participante = { select: { id: true, nombreUsuario: true } };

    expect(CONVERSACION_RESERVA_SELECT).toEqual({
      id: true,
      reservaId: true,
      creadaEn: true,
      arrendador: participante,
      arrendatario: participante,
    });
  });

  it('busca la conversación por reservaId, que es único', async () => {
    const { repository, prisma } = crear();

    await repository.findPorReserva(RESERVA_ID);

    expect(prisma.conversacion.findUnique).toHaveBeenCalledWith({
      where: { reservaId: RESERVA_ID },
      select: CONVERSACION_RESERVA_SELECT,
    });
  });

  it('crea la conversación de la reserva con los datos recibidos', async () => {
    const { repository, prisma } = crear();
    const conversacion = { id: CONVERSACION_ID };
    prisma.conversacion.create.mockResolvedValue(conversacion);

    await expect(repository.crearDeReserva(datos)).resolves.toEqual({
      conversacion,
    });
    expect(prisma.conversacion.create).toHaveBeenCalledWith({
      data: datos,
      select: CONVERSACION_RESERVA_SELECT,
    });
  });

  it('devuelve duplicada si el índice único de reserva_id la rechaza (P2002)', async () => {
    const { repository, prisma } = crear();
    prisma.conversacion.create.mockRejectedValue(errorPrisma('P2002'));

    await expect(repository.crearDeReserva(datos)).resolves.toEqual({
      duplicada: true,
    });
  });

  it('propaga los demás errores, como el rechazo del trigger de consistencia', async () => {
    const { repository, prisma } = crear();
    const error = errorPrisma('P2003');
    prisma.conversacion.create.mockRejectedValue(error);

    await expect(repository.crearDeReserva(datos)).rejects.toBe(error);
  });
});
