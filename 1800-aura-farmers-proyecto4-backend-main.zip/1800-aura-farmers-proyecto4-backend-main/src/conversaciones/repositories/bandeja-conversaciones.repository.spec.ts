import type { PrismaService } from '@Prisma/services';

import {
  CONVERSACION_BANDEJA_SELECT,
  ConversacionRepository,
} from './conversacion.repository.js';

const a = { id: 'a' };
const b = { id: 'b' };

function crear() {
  const prisma = {
    conversacion: {
      findMany: vi.fn().mockResolvedValue([a, b]),
    },

    $queryRaw: vi.fn().mockResolvedValue([
      { id: 'b', total: 42 },
      { id: 'a', total: 42 },
    ]),
  };

  return {
    repository: new ConversacionRepository(prisma as unknown as PrismaService),
    prisma,
  };
}

describe('BE-13.2 ConversacionRepository.listarBandeja', () => {
  it('filtra por participante y conserva el orden SQL', async () => {
    const { repository, prisma } = crear();

    const resultado = await repository.listarBandeja(
      'usuario-1',
      'CONSULTA',
      2,
    );

    expect(resultado).toEqual({
      conversaciones: [b, a],
      total: 42,
    });

    expect(prisma.conversacion.findMany).toHaveBeenCalledWith({
      where: {
        id: {
          in: ['b', 'a'],
        },

        OR: [{ arrendadorId: 'usuario-1' }, { arrendatarioId: 'usuario-1' }],
      },

      select: CONVERSACION_BANDEJA_SELECT,
    });

    const sql = prisma.$queryRaw.mock.calls[0][0];

    expect(sql.strings.join(' ')).toContain('COUNT(*)::integer');

    expect(sql.strings.join(' ')).toContain('LEFT JOIN pagina_actual ON TRUE');

    expect(sql.values).toContain('usuario-1');
    expect(sql.values).toContain(20);
  });

  it('conserva el total cuando la página está vacía', async () => {
    const { repository, prisma } = crear();

    prisma.$queryRaw.mockResolvedValue([
      {
        id: null,
        total: 42,
      },
    ]);

    const resultado = await repository.listarBandeja(
      'usuario-1',
      'COORDINACION',
      5,
    );

    expect(resultado).toEqual({
      conversaciones: [],
      total: 42,
    });

    expect(prisma.conversacion.findMany).not.toHaveBeenCalled();
  });

  it('devuelve cero cuando no existen conversaciones', async () => {
    const { repository, prisma } = crear();

    prisma.$queryRaw.mockResolvedValue([
      {
        id: null,
        total: 0,
      },
    ]);

    const resultado = await repository.listarBandeja('usuario-1', undefined, 1);

    expect(resultado).toEqual({
      conversaciones: [],
      total: 0,
    });
  });
});
