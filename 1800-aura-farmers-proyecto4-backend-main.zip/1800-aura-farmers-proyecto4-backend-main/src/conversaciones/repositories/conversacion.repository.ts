import { Injectable } from '@nestjs/common';
import { PrismaService } from '@Prisma/services';
import { Prisma } from '@PrismaClient';
import type { OrdenMensajes, TipoConversacion } from '@Conversaciones/dto';
import { CONVERSACIONES_POR_PAGINA } from '@Conversaciones/constants';

const UNIQUE_CONSTRAINT_VIOLATION = 'P2002';

/** Datos públicos de un participante: nunca el email ni el hash. */
export const PARTICIPANTE_SELECT = { id: true, nombreUsuario: true } as const;

export const CONVERSACION_SELECT = {
  id: true,
  bienId: true,
  creadaEn: true,
  arrendador: { select: PARTICIPANTE_SELECT },
  arrendatario: { select: PARTICIPANTE_SELECT },
} satisfies Prisma.ConversacionSelect;

export const MENSAJE_SELECT = {
  id: true,
  conversacionId: true,
  contenido: true,
  creadoEn: true,
  remitente: { select: PARTICIPANTE_SELECT },
} satisfies Prisma.MensajeSelect;

export interface Participante {
  id: string;
  nombreUsuario: string;
}

export type ConversacionConParticipantes = Prisma.ConversacionGetPayload<{
  select: typeof CONVERSACION_SELECT;
}>;

export type MensajeConRemitente = Prisma.MensajeGetPayload<{
  select: typeof MENSAJE_SELECT;
}>;

/** Información pública necesaria para la bandeja. */
export const CONVERSACION_BANDEJA_SELECT = {
  id: true,
  reservaId: true,
  creadaEn: true,
  arrendadorId: true,

  arrendador: {
    select: PARTICIPANTE_SELECT,
  },

  arrendatario: {
    select: PARTICIPANTE_SELECT,
  },

  bien: {
    select: {
      id: true,
      titulo: true,

      fotos: {
        where: {
          esPrincipal: true,
        },
        select: {
          url: true,
        },
        take: 1,
      },
    },
  },

  mensajes: {
    orderBy: [{ creadoEn: 'desc' }, { id: 'desc' }],
    take: 1,
    select: {
      contenido: true,
      creadoEn: true,
      remitenteId: true,
    },
  },
} satisfies Prisma.ConversacionSelect;

export type ConversacionBandeja = Prisma.ConversacionGetPayload<{
  select: typeof CONVERSACION_BANDEJA_SELECT;
}>;

export interface ResultadoBandeja {
  conversaciones: ConversacionBandeja[];
  total: number;
}

/** Quiénes participan en una conversación. */
export interface ParticipantesConversacion {
  arrendadorId: string;
  arrendatarioId: string;
}

export interface CrearConversacionPreviaData {
  bienId: string;
  arrendadorId: string;
  arrendatarioId: string;
}

/**
 * La conversación creada, o `duplicada` si otra petición la creó primero y el
 * índice único la rechazó.
 */
export type ResultadoCrearPrevia =
  { conversacion: ConversacionConParticipantes } | { duplicada: true };

export interface CrearMensajeData {
  conversacionId: string;
  remitenteId: string;
  contenido: string;
}

/**
 * Lo que la coordinación de una reserva (H14) necesita de ella: su estado, sus
 * fechas, el bien y los dos participantes. El arrendador no está en la
 * reserva: es el dueño del bien.
 */
export const RESERVA_COORDINACION_SELECT = {
  id: true,
  bienId: true,
  arrendatarioId: true,
  estado: true,
  fechaInicio: true,
  fechaFin: true,
  bien: { select: { titulo: true, arrendadorId: true } },
} satisfies Prisma.ReservaSelect;

export type ReservaParaCoordinacion = Prisma.ReservaGetPayload<{
  select: typeof RESERVA_COORDINACION_SELECT;
}>;

/** Conversación de coordinación de una reserva, con sus participantes. */
export const CONVERSACION_RESERVA_SELECT = {
  id: true,
  reservaId: true,
  creadaEn: true,
  arrendador: { select: PARTICIPANTE_SELECT },
  arrendatario: { select: PARTICIPANTE_SELECT },
} satisfies Prisma.ConversacionSelect;

export type ConversacionDeReserva = Prisma.ConversacionGetPayload<{
  select: typeof CONVERSACION_RESERVA_SELECT;
}>;

/** Datos de la conversación de una reserva, todos leídos de la reserva. */
export interface CrearConversacionDeReservaData {
  reservaId: string;
  bienId: string;
  arrendadorId: string;
  arrendatarioId: string;
}

/**
 * La conversación creada, o `duplicada` si otra petición creó primero la de
 * esa reserva y el índice único `Conversaciones_reserva_id_key` la rechazó.
 */
export type ResultadoCrearDeReserva =
  { conversacion: ConversacionDeReserva } | { duplicada: true };

/**
 * Único punto del módulo que habla con las tablas `Conversaciones` y `Mensajes`.
 *
 * Para la coordinación de la entrega (H14) también lee `Reservas`, solo para
 * obtener los participantes, el estado, las fechas y el bien de una reserva.
 * Es una lectura propia de este módulo: no reemplaza ni modifica la lógica del
 * módulo de reservas.
 */
@Injectable()
export class ConversacionRepository {
  constructor(private readonly prisma: PrismaService) {}

  /**
   * Conversación previa (sin reserva) del arrendatario sobre el bien, o null.
   *
   * La base admite una sola por bien y arrendatario: el índice único parcial
   * `Conversaciones_previa_unica_idx` solo cubre las filas con
   * `reserva_id IS NULL`, por eso se filtra por `reservaId: null`.
   */
  findPrevia(
    bienId: string,
    arrendatarioId: string,
  ): Promise<ConversacionConParticipantes | null> {
    return this.prisma.conversacion.findFirst({
      where: { bienId, arrendatarioId, reservaId: null },
      select: CONVERSACION_SELECT,
    });
  }

  /**
   * Crea la conversación previa.
   *
   * Si dos peticiones la crean al mismo tiempo, el índice único parcial deja
   * pasar solo una; la otra recibe P2002 y aquí se devuelve como `duplicada`
   * para que el servicio recupere la que ganó.
   */
  async crearPrevia(
    datos: CrearConversacionPreviaData,
  ): Promise<ResultadoCrearPrevia> {
    try {
      const conversacion = await this.prisma.conversacion.create({
        data: datos,
        select: CONVERSACION_SELECT,
      });
      return { conversacion };
    } catch (error) {
      if (
        error instanceof Prisma.PrismaClientKnownRequestError &&
        error.code === UNIQUE_CONSTRAINT_VIOLATION
      ) {
        return { duplicada: true };
      }
      throw error;
    }
  }

  /**
   * Participantes de la conversación previa, o null si no existe o es de una
   * reserva.
   *
   * Las rutas de H13 solo operan sobre conversaciones previas: una conversación
   * vinculada a una reserva tiene sus propias reglas (H14) y aquí se trata como
   * inexistente, para que estas rutas no permitan saltárselas ni revelen que
   * existe.
   *
   * Es `findFirst` y no `findUnique` porque `reservaId` es un campo único y
   * Prisma no acepta `null` en él dentro de un `findUnique`. Como `id` es la
   * clave primaria, sigue devolviendo como máximo una fila.
   */
  findParticipantes(id: string): Promise<ParticipantesConversacion | null> {
    return this.prisma.conversacion.findFirst({
      where: { id, reservaId: null },
      select: { arrendadorId: true, arrendatarioId: true },
    });
  }

  /**
   * La reserva con lo necesario para coordinar su entrega (H14), o null si no
   * existe. Solo lee: no filtra por estado ni por participante, eso lo decide
   * el servicio.
   */
  findReservaParaCoordinacion(
    reservaId: string,
  ): Promise<ReservaParaCoordinacion | null> {
    return this.prisma.reserva.findUnique({
      where: { id: reservaId },
      select: RESERVA_COORDINACION_SELECT,
    });
  }

  /**
   * La conversación de coordinación de la reserva, o null. `reserva_id` es
   * único (DB-14.1), así que hay como máximo una.
   */
  findPorReserva(reservaId: string): Promise<ConversacionDeReserva | null> {
    return this.prisma.conversacion.findUnique({
      where: { reservaId },
      select: CONVERSACION_RESERVA_SELECT,
    });
  }

  /**
   * Crea la conversación de coordinación de la reserva.
   *
   * Si dos peticiones la crean al mismo tiempo, el índice único
   * `Conversaciones_reserva_id_key` deja pasar solo una; la otra recibe P2002 y
   * aquí se devuelve como `duplicada` para que el servicio recupere la que
   * ganó. El trigger de DB-14.1 rechaza cualquier otro error de consistencia
   * (bien o participantes distintos de los de la reserva), que se propaga.
   */
  async crearDeReserva(
    datos: CrearConversacionDeReservaData,
  ): Promise<ResultadoCrearDeReserva> {
    try {
      const conversacion = await this.prisma.conversacion.create({
        data: datos,
        select: CONVERSACION_RESERVA_SELECT,
      });
      return { conversacion };
    } catch (error) {
      if (
        error instanceof Prisma.PrismaClientKnownRequestError &&
        error.code === UNIQUE_CONSTRAINT_VIOLATION
      ) {
        return { duplicada: true };
      }
      throw error;
    }
  }

  /** Guarda el mensaje tal como llega. `creado_en` lo pone la base. */
  crearMensaje(datos: CrearMensajeData): Promise<MensajeConRemitente> {
    return this.prisma.mensaje.create({
      data: datos,
      select: MENSAJE_SELECT,
    });
  }

  /**
   * Mensajes de la conversación en orden cronológico (o inverso).
   *
   * El `id` desempata los mensajes con la misma fecha, así el orden es estable
   * entre consultas. Coincide con el índice `(conversacion_id, creado_en, id)`.
   */
  listarMensajes(
    conversacionId: string,
    orden: OrdenMensajes,
  ): Promise<MensajeConRemitente[]> {
    return this.prisma.mensaje.findMany({
      where: { conversacionId },
      orderBy: [{ creadoEn: orden }, { id: orden }],
      select: MENSAJE_SELECT,
    });
  }

  /**
   * Obtiene las conversaciones del usuario, ordenadas por última actividad.
   *
   * PostgreSQL calcula el total y los IDs de la página usando
   * el mismo filtro. Prisma carga las relaciones en bloque.
   */
  async listarBandeja(
    usuarioId: string,
    tipo: TipoConversacion | undefined,
    pagina: number,
  ): Promise<ResultadoBandeja> {
    const filtroTipo =
      tipo === 'CONSULTA'
        ? Prisma.sql`AND c.reserva_id IS NULL`
        : tipo === 'COORDINACION'
          ? Prisma.sql`AND c.reserva_id IS NOT NULL`
          : Prisma.empty;

    const desplazamiento = (pagina - 1) * CONVERSACIONES_POR_PAGINA;

    const filas = await this.prisma.$queryRaw<
      { id: string | null; total: number }[]
    >(Prisma.sql`
      WITH filtradas AS (
        SELECT
          c.id,
          COALESCE(
            ultimo.creado_en,
            c.creada_en
          ) AS ultima_actividad
        FROM "Conversaciones" AS c
        
        LEFT JOIN LATERAL (
          SELECT m.creado_en
          FROM "Mensajes" AS m
          WHERE m.conversacion_id = c.id
          ORDER BY
            m.creado_en DESC,
            m.id DESC
          LIMIT 1
        ) AS ultimo ON TRUE
        
        WHERE (
          c.arrendador_id = ${usuarioId}::uuid
          OR c.arrendatario_id = ${usuarioId}::uuid
        )
        
        ${filtroTipo}
      ),
      
      conteo AS (
        SELECT COUNT(*)::integer AS total
        FROM filtradas
      ),
      
      pagina_actual AS (
        SELECT
          id,
          ROW_NUMBER() OVER (
            ORDER BY ultima_actividad DESC, id DESC
          ) AS posicion
        FROM filtradas
        ORDER BY ultima_actividad DESC, id DESC
        LIMIT ${CONVERSACIONES_POR_PAGINA}
        OFFSET ${desplazamiento}
      )
      
      SELECT
        pagina_actual.id,
        conteo.total
      FROM conteo
      LEFT JOIN pagina_actual ON TRUE
      ORDER BY pagina_actual.posicion NULLS LAST
    `);

    const total = filas[0]?.total ?? 0;

    const ids = filas.flatMap((fila) => (fila.id === null ? [] : [fila.id]));

    if (ids.length === 0) {
      return {
        conversaciones: [],
        total,
      };
    }

    // Mantener este filtro de participante sincronizado con el WHERE del SQL
    // anterior: el total y los items deben representar el mismo conjunto.
    // El tipo se filtra únicamente en SQL; aquí se consultan los IDs paginados.
    const conversaciones = await this.prisma.conversacion.findMany({
      where: {
        id: {
          in: ids,
        },

        OR: [{ arrendadorId: usuarioId }, { arrendatarioId: usuarioId }],
      },

      select: CONVERSACION_BANDEJA_SELECT,
    });

    const porId = new Map(
      conversaciones.map((conversacion) => [conversacion.id, conversacion]),
    );

    return {
      conversaciones: ids.flatMap((id) => {
        const conversacion = porId.get(id);

        return conversacion ? [conversacion] : [];
      }),

      total,
    };
  }
}
