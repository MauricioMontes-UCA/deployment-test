import { ForbiddenException } from '@nestjs/common';
import { ROLES_KEY } from '@Auth/decorators';
import type { AuthenticatedUser } from '@Auth/types';
import { EstadoReserva } from '@PrismaClient';
import {
  ConversacionReservaResponseDto,
  MensajeResponseDto,
} from '@Conversaciones/dto';
import type { CoordinacionService } from '@Conversaciones/services';
import { CoordinacionController } from './coordinacion.controller.js';

// Clave con la que @ApiBearerAuth() guarda la seguridad para Swagger.
const API_SECURITY = 'swagger/apiSecurity';

const RESERVA_ID = '3f1a2b4c-5d6e-4f70-8a91-b2c3d4e5f607';

const usuario: AuthenticatedUser = {
  id: 'arrendador-1',
  email: 'dueno@example.com',
  nombreUsuario: 'dueno',
  rol: 'ARRENDADOR',
};

const reserva = {
  id: RESERVA_ID,
  bienId: 'bien-1',
  arrendatarioId: 'arrendatario-1',
  estado: EstadoReserva.EN_CURSO,
  fechaInicio: new Date('2026-12-20T00:00:00.000Z'),
  fechaFin: new Date('2026-12-22T00:00:00.000Z'),
  bien: { titulo: 'Salón de eventos', arrendadorId: 'arrendador-1' },
};

const conversacion = {
  id: 'conversacion-1',
  reservaId: RESERVA_ID,
  creadaEn: new Date('2026-11-15T15:00:00.000Z'),
  arrendador: { id: 'arrendador-1', nombreUsuario: 'dueno' },
  arrendatario: { id: 'arrendatario-1', nombreUsuario: 'inquilino' },
};

const mensaje = {
  id: 'mensaje-1',
  conversacionId: 'conversacion-1',
  contenido: 'Entrego el sábado',
  creadoEn: new Date('2026-11-15T15:05:00.000Z'),
  remitente: { id: 'arrendador-1', nombreUsuario: 'dueno' },
};

function crear() {
  const service = {
    abrir: vi.fn().mockResolvedValue({ conversacion, reserva }),
    enviar: vi.fn().mockResolvedValue(mensaje),
    listar: vi.fn().mockResolvedValue({
      conversacionId: 'conversacion-1',
      mensajes: [mensaje],
    }),
  };
  const controller = new CoordinacionController(
    service as unknown as CoordinacionService,
  );
  return { controller, service };
}

describe('CoordinacionController', () => {
  it('no restringe por rol: entran arrendador y arrendatario de la reserva', () => {
    expect(Reflect.getMetadata(ROLES_KEY, CoordinacionController)).toBe(
      undefined,
    );
    for (const metodo of ['abrir', 'enviar', 'listar'] as const) {
      expect(
        Reflect.getMetadata(
          ROLES_KEY,
          CoordinacionController.prototype[metodo],
        ),
      ).toBe(undefined);
    }
  });

  it('documenta el bearer', () => {
    expect(Reflect.getMetadata(API_SECURITY, CoordinacionController)).toEqual([
      { bearer: [] },
    ]);
  });

  it('GET conversación: usa el usuario de la sesión y devuelve el resumen de la reserva', async () => {
    const { controller, service } = crear();

    const dto = await controller.abrir(RESERVA_ID, usuario);

    expect(service.abrir).toHaveBeenCalledWith(RESERVA_ID, 'arrendador-1');
    expect(dto).toEqual({
      id: 'conversacion-1',
      reservaId: RESERVA_ID,
      estado: 'EN_CURSO',
      fechaInicio: '2026-12-20',
      fechaFin: '2026-12-22',
      bien: { id: 'bien-1', titulo: 'Salón de eventos' },
      arrendador: { id: 'arrendador-1', nombreUsuario: 'dueno' },
      arrendatario: { id: 'arrendatario-1', nombreUsuario: 'inquilino' },
      creadaEn: conversacion.creadaEn,
    });
  });

  it('POST mensaje: el remitente es el usuario de la sesión', async () => {
    const { controller, service } = crear();

    const dto = await controller.enviar(RESERVA_ID, usuario, {
      contenido: 'Entrego el sábado',
    });

    expect(service.enviar).toHaveBeenCalledWith(
      RESERVA_ID,
      'arrendador-1',
      'Entrego el sábado',
    );
    expect(dto).toEqual(MensajeResponseDto.from(mensaje));
  });

  it.each(['asc', 'desc'] as const)(
    'GET mensajes en orden %s',
    async (orden) => {
      const { controller, service } = crear();

      const dto = await controller.listar(RESERVA_ID, usuario, { orden });

      expect(service.listar).toHaveBeenCalledWith(
        RESERVA_ID,
        'arrendador-1',
        orden,
      );
      expect(dto).toEqual({
        conversacionId: 'conversacion-1',
        orden,
        mensajes: [MensajeResponseDto.from(mensaje)],
      });
    },
  );

  it('propaga las excepciones del servicio', async () => {
    const { controller, service } = crear();
    const error = new ForbiddenException('No participas.');
    service.abrir.mockRejectedValue(error);

    await expect(controller.abrir(RESERVA_ID, usuario)).rejects.toBe(error);
  });
});

describe('ConversacionReservaResponseDto', () => {
  it('no expone correos, roles, montos ni campos internos', () => {
    const dto = ConversacionReservaResponseDto.from(
      {
        ...conversacion,
        // Campos de más que no deben pasar a la respuesta.
        arrendador: {
          ...conversacion.arrendador,
          email: 'dueno@example.com',
          rol: 'ARRENDADOR',
        },
      } as typeof conversacion,
      {
        ...reserva,
        motivoResolucion: 'interno',
        bien: { ...reserva.bien, precio: 30 },
      } as typeof reserva,
    );

    expect(Object.keys(dto).sort()).toEqual(
      [
        'arrendador',
        'arrendatario',
        'bien',
        'creadaEn',
        'estado',
        'fechaFin',
        'fechaInicio',
        'id',
        'reservaId',
      ].sort(),
    );
    expect(dto.arrendador).toEqual({
      id: 'arrendador-1',
      nombreUsuario: 'dueno',
    });
    expect(dto.bien).toEqual({ id: 'bien-1', titulo: 'Salón de eventos' });
    expect(JSON.stringify(dto)).not.toMatch(
      /email|rol"|password|motivo|precio|arrendadorId/,
    );
  });

  it('las fechas de la reserva van como AAAA-MM-DD', () => {
    const dto = ConversacionReservaResponseDto.from(conversacion, reserva);

    expect([dto.fechaInicio, dto.fechaFin]).toEqual([
      '2026-12-20',
      '2026-12-22',
    ]);
  });
});
