import { HttpStatus } from '@nestjs/common';
import type { Response } from 'express';
import { ROLES_KEY } from '@Auth/decorators';
import type { AuthenticatedUser } from '@Auth/types';
import type { ConversacionesService } from '@Conversaciones/services';
import { ConversacionesBienController } from './conversaciones-bien.controller.js';
import { MensajesController } from './mensajes.controller.js';

// Clave con la que @ApiBearerAuth() guarda la seguridad para Swagger.
const API_SECURITY = 'swagger/apiSecurity';

const usuario: AuthenticatedUser = {
  id: 'arrendatario-1',
  email: 'inquilino@example.com',
  nombreUsuario: 'inquilino',
  rol: 'ARRENDATARIO',
};

const conversacion = {
  id: 'conversacion-1',
  bienId: 'bien-1',
  creadaEn: new Date('2026-11-15T15:00:00.000Z'),
  arrendador: { id: 'arrendador-1', nombreUsuario: 'dueno' },
  arrendatario: { id: 'arrendatario-1', nombreUsuario: 'inquilino' },
};

describe('ConversacionesBienController', () => {
  it.each([
    [true, HttpStatus.CREATED],
    [false, HttpStatus.OK],
  ])('con creada=%s responde %s', async (creada, codigo) => {
    const abrir = vi.fn().mockResolvedValue({ conversacion, creada });
    const controller = new ConversacionesBienController({
      abrir,
    } as unknown as ConversacionesService);
    const res = { status: vi.fn() };

    const dto = await controller.abrir(
      'bien-1',
      usuario,
      res as unknown as Response,
    );

    expect(abrir).toHaveBeenCalledWith('bien-1', 'arrendatario-1');
    expect(res.status).toHaveBeenCalledWith(codigo);
    expect(dto).toEqual(conversacion);
  });

  it('solo admite ARRENDATARIO y documenta el bearer', () => {
    expect(
      Reflect.getMetadata(ROLES_KEY, ConversacionesBienController),
    ).toEqual(['ARRENDATARIO']);
    expect(
      Reflect.getMetadata(API_SECURITY, ConversacionesBienController),
    ).toEqual([{ bearer: [] }]);
  });
});

describe('MensajesController', () => {
  it('admite cualquier rol: el servicio decide quién participa', () => {
    expect(Reflect.getMetadata(ROLES_KEY, MensajesController)).toBeUndefined();
    expect(Reflect.getMetadata(API_SECURITY, MensajesController)).toEqual([
      { bearer: [] },
    ]);
  });

  it('envía con el remitente del token, nunca del cuerpo', async () => {
    const mensaje = {
      id: 'mensaje-1',
      conversacionId: 'conversacion-1',
      contenido: 'Hola',
      creadoEn: new Date('2026-11-15T15:05:00.000Z'),
      remitente: { id: 'arrendatario-1', nombreUsuario: 'inquilino' },
    };
    const enviar = vi.fn().mockResolvedValue(mensaje);
    const controller = new MensajesController({
      enviar,
    } as unknown as ConversacionesService);

    const dto = await controller.enviar('conversacion-1', usuario, {
      contenido: 'Hola',
    });

    expect(enviar).toHaveBeenCalledWith(
      'conversacion-1',
      'arrendatario-1',
      'Hola',
    );
    expect(dto).toEqual(mensaje);
  });

  it('lista con el orden pedido y lo devuelve en la respuesta', async () => {
    const listar = vi.fn().mockResolvedValue([]);
    const controller = new MensajesController({
      listar,
    } as unknown as ConversacionesService);

    const dto = await controller.listar('conversacion-1', usuario, {
      orden: 'desc',
    });

    expect(listar).toHaveBeenCalledWith(
      'conversacion-1',
      'arrendatario-1',
      'desc',
    );
    expect(dto).toEqual({
      conversacionId: 'conversacion-1',
      orden: 'desc',
      mensajes: [],
    });
  });
});
