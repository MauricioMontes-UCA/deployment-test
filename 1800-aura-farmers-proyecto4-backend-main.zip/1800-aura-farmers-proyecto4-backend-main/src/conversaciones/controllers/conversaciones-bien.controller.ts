import {
  Controller,
  HttpStatus,
  Param,
  ParseUUIDPipe,
  Post,
  Res,
} from '@nestjs/common';
import {
  ApiBadRequestResponse,
  ApiBearerAuth,
  ApiConflictResponse,
  ApiCreatedResponse,
  ApiForbiddenResponse,
  ApiNotFoundResponse,
  ApiOkResponse,
  ApiOperation,
  ApiTags,
  ApiUnauthorizedResponse,
  ApiUnprocessableEntityResponse,
} from '@nestjs/swagger';
import type { Response } from 'express';
import { CurrentUser, Roles } from '@Auth/decorators';
import type { AuthenticatedUser } from '@Auth/types';
import { Rol } from '@PrismaClient';
import { ConversacionResponseDto } from '@Conversaciones/dto';
import { ConversacionesService } from '@Conversaciones/services';

/**
 * Inicio de la consulta sobre una publicación (H13). Comparte la ruta
 * `/bienes` con los controladores de bienes.
 */
@ApiTags('conversaciones')
@ApiBearerAuth()
@Roles(Rol.ARRENDATARIO)
@Controller('bienes')
export class ConversacionesBienController {
  constructor(private readonly conversacionesService: ConversacionesService) {}

  /**
   * Responde 201 si crea la conversación y 200 si ya existía, también cuando
   * otra petición simultánea la creó primero.
   */
  @Post(':bienId/conversacion')
  @ApiOperation({
    summary: 'Abre o recupera la conversación con el arrendador de un bien',
    description:
      'Solo un ARRENDATARIO. El arrendador sale de la publicación y el arrendatario del token. Hay una sola conversación previa por bien y arrendatario.',
  })
  @ApiCreatedResponse({
    type: ConversacionResponseDto,
    description: 'Conversación creada.',
  })
  @ApiOkResponse({
    type: ConversacionResponseDto,
    description: 'La conversación ya existía y se devuelve la misma.',
  })
  @ApiBadRequestResponse({ description: 'El bienId no es un UUID.' })
  @ApiUnauthorizedResponse({
    description: 'Token ausente, inválido o expirado.',
  })
  @ApiForbiddenResponse({ description: 'El usuario no es ARRENDATARIO.' })
  @ApiNotFoundResponse({
    description: 'La publicación no existe o su arrendador está desactivado.',
  })
  @ApiConflictResponse({
    description:
      'Una creación simultánea chocó y no se pudo recuperar la conversación.',
  })
  @ApiUnprocessableEntityResponse({
    description: 'La publicación no está ACTIVA o es del propio usuario.',
  })
  async abrir(
    @Param('bienId', ParseUUIDPipe) bienId: string,
    @CurrentUser() usuario: AuthenticatedUser,
    @Res({ passthrough: true }) res: Response,
  ): Promise<ConversacionResponseDto> {
    const { conversacion, creada } = await this.conversacionesService.abrir(
      bienId,
      usuario.id,
    );
    res.status(creada ? HttpStatus.CREATED : HttpStatus.OK);
    return ConversacionResponseDto.from(conversacion);
  }
}
