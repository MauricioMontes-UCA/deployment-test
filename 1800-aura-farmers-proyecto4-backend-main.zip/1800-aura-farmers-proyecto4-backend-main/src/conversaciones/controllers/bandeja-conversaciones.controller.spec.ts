import { ROLES_KEY } from '@Auth/decorators';

import type { AuthenticatedUser } from '@Auth/types';
import type { ConversacionesService } from '@Conversaciones/services';

import { BandejaConversacionesController } from './bandeja-conversaciones.controller.js';

const usuario = {
  id: 'usuario-1',
} as AuthenticatedUser;

describe('BE-13.2 BandejaConversacionesController', () => {
  it('no restringe el acceso mediante @Roles()', () => {
    expect(
      Reflect.getMetadata(ROLES_KEY, BandejaConversacionesController),
    ).toBeUndefined();

    expect(
      Reflect.getMetadata(
        'swagger/apiSecurity',
        BandejaConversacionesController,
      ),
    ).toEqual([{ bearer: [] }]);
  });

  it('mapea los datos y calcula la paginación', async () => {
    const conversacion = {
      id: 'conv-1',
      reservaId: null,
      creadaEn: new Date('2026-11-19T12:00:00Z'),
      arrendadorId: 'usuario-1',

      arrendador: {
        id: 'usuario-1',
        nombreUsuario: 'dueno',
      },

      arrendatario: {
        id: 'usuario-2',
        nombreUsuario: 'inquilino',
      },

      bien: {
        id: 'bien-1',
        titulo: 'Cámara',
        fotos: [],
      },

      mensajes: [],
    };

    const listarBandeja = vi.fn().mockResolvedValue({
      conversaciones: [conversacion],
      total: 21,
    });

    const controller = new BandejaConversacionesController({
      listarBandeja,
    } as unknown as ConversacionesService);

    const filtros = {
      tipo: 'CONSULTA' as const,
      pagina: 1,
    };

    const respuesta = await controller.listar(usuario, filtros);

    expect(listarBandeja).toHaveBeenCalledWith('usuario-1', filtros);

    expect(respuesta).toMatchObject({
      pagina: 1,
      total: 21,
      hayMas: true,
    });

    expect(respuesta.items).toHaveLength(1);

    expect(respuesta.items[0]).toMatchObject({
      id: 'conv-1',
      tipo: 'CONSULTA',

      otroParticipante: {
        id: 'usuario-2',
        nombreUsuario: 'inquilino',
      },
    });
  });

  it('conserva el total cuando la página está vacía', async () => {
    const listarBandeja = vi.fn().mockResolvedValue({
      conversaciones: [],
      total: 21,
    });

    const controller = new BandejaConversacionesController({
      listarBandeja,
    } as unknown as ConversacionesService);

    const respuesta = await controller.listar(usuario, { pagina: 2 });

    expect(respuesta).toEqual({
      items: [],
      pagina: 2,
      total: 21,
      hayMas: false,
    });
  });
});
