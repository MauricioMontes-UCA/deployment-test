import { Controller, Get, Query } from '@nestjs/common';

import {
  ApiBadRequestResponse,
  ApiBearerAuth,
  ApiOkResponse,
  ApiOperation,
  ApiTags,
  ApiUnauthorizedResponse,
} from '@nestjs/swagger';

import { CurrentUser } from '@Auth/decorators';
import type { AuthenticatedUser } from '@Auth/types';

import { CONVERSACIONES_POR_PAGINA } from '@Conversaciones/constants';

import {
  BandejaConversacionesResponseDto,
  ConversacionBandejaResponseDto,
  ConsultarConversacionesDto,
} from '@Conversaciones/dto';

import { ConversacionesService } from '@Conversaciones/services';

/**
 * Bandeja compartida por arrendador y arrendatario.
 * Exige sesión, sin restricción por rol.
 */
@ApiTags('conversaciones')
@ApiBearerAuth()
@Controller('conversaciones')
export class BandejaConversacionesController {
  constructor(private readonly conversacionesService: ConversacionesService) {}

  @Get()
  @ApiOperation({
    summary: 'Lista las conversaciones en las que participa el usuario',
    description:
      `${CONVERSACIONES_POR_PAGINA} por página. ` +
      'CONSULTA: sin reserva; COORDINACION: con reserva. ' +
      'Ordenadas por último mensaje o fecha de creación.',
  })
  @ApiOkResponse({
    type: BandejaConversacionesResponseDto,
  })
  @ApiBadRequestResponse({
    description: 'Tipo o página inválidos.',
  })
  @ApiUnauthorizedResponse({
    description: 'Se requiere autenticación.',
  })
  async listar(
    @CurrentUser() usuario: AuthenticatedUser,
    @Query() filtros: ConsultarConversacionesDto,
  ): Promise<BandejaConversacionesResponseDto> {
    const { conversaciones, total } =
      await this.conversacionesService.listarBandeja(usuario.id, filtros);

    return {
      items: conversaciones.map((conversacion) =>
        ConversacionBandejaResponseDto.from(conversacion, usuario.id),
      ),

      pagina: filtros.pagina,
      total,

      hayMas: filtros.pagina * CONVERSACIONES_POR_PAGINA < total,
    };
  }
}
