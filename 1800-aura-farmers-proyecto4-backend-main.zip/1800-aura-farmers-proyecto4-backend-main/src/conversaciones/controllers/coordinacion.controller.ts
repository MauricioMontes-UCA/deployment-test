import {
  Body,
  Controller,
  Get,
  Param,
  ParseUUIDPipe,
  Post,
  Query,
} from '@nestjs/common';
import {
  ApiBadRequestResponse,
  ApiBearerAuth,
  ApiConflictResponse,
  ApiCreatedResponse,
  ApiForbiddenResponse,
  ApiNotFoundResponse,
  ApiOkResponse,
  ApiOperation,
  ApiTags,
  ApiUnauthorizedResponse,
  ApiUnprocessableEntityResponse,
} from '@nestjs/swagger';
import { CurrentUser } from '@Auth/decorators';
import type { AuthenticatedUser } from '@Auth/types';
import {
  ConsultarMensajesDto,
  ConversacionReservaResponseDto,
  CrearMensajeDto,
  MensajeResponseDto,
  MensajesResponseDto,
} from '@Conversaciones/dto';
import { CoordinacionService } from '@Conversaciones/services';

const NO_PARTICIPANTE =
  'El usuario no es el arrendatario de la reserva ni el dueño de su bien.';
const NO_EXISTE = 'La reserva no existe.';
const MENSAJE_422 =
  '"La coordinación está disponible cuando la reserva está confirmada o en curso"';
const NO_SE_PUEDE_CREAR = `La conversación no existe y la reserva no está CONFIRMADA ni EN_CURSO, así que no se puede crear: ${MENSAJE_422}.`;
const NO_SE_PUEDE_ESCRIBIR = `La reserva no está CONFIRMADA ni EN_CURSO; no se guarda el mensaje ni se crea la conversación: ${MENSAJE_422}.`;
const SIN_SESION = 'Token ausente, inválido o expirado.';
const CONFLICTO =
  'Una creación simultánea de la conversación chocó y no se pudo recuperar.';

/**
 * Conversación de coordinación de la entrega de una reserva (H14). Comparte la
 * ruta `/reservas` con los controladores de reservas.
 *
 * Sin `@Roles()`: entran el arrendatario de la reserva y el arrendador dueño
 * del bien, sea cual sea su rol, y el servicio rechaza a los demás.
 */
@ApiTags('conversaciones')
@ApiBearerAuth()
@Controller('reservas')
export class CoordinacionController {
  constructor(private readonly coordinacionService: CoordinacionService) {}

  @Get(':reservaId/conversacion')
  @ApiOperation({
    summary: 'Recupera o crea la conversación de coordinación de una reserva',
    description:
      'Solo para el arrendatario de la reserva y el arrendador dueño del bien. Si la conversación ya existe, se devuelve en cualquier estado de la reserva (también FINALIZADA o CANCELADA, para conservar lo acordado). Si no existe, la crea con los participantes de la reserva, pero solo con la reserva CONFIRMADA o EN_CURSO. Hay una sola por reserva y siempre responde 200, también la primera vez o con peticiones simultáneas.',
  })
  @ApiOkResponse({ type: ConversacionReservaResponseDto })
  @ApiBadRequestResponse({ description: 'El reservaId no es un UUID.' })
  @ApiUnauthorizedResponse({ description: SIN_SESION })
  @ApiForbiddenResponse({ description: NO_PARTICIPANTE })
  @ApiNotFoundResponse({ description: NO_EXISTE })
  @ApiConflictResponse({ description: CONFLICTO })
  @ApiUnprocessableEntityResponse({ description: NO_SE_PUEDE_CREAR })
  async abrir(
    @Param('reservaId', ParseUUIDPipe) reservaId: string,
    @CurrentUser() usuario: AuthenticatedUser,
  ): Promise<ConversacionReservaResponseDto> {
    const { conversacion, reserva } = await this.coordinacionService.abrir(
      reservaId,
      usuario.id,
    );
    return ConversacionReservaResponseDto.from(conversacion, reserva);
  }

  @Post(':reservaId/conversacion/mensajes')
  @ApiOperation({
    summary: 'Envía un mensaje sobre la entrega de una reserva',
    description:
      'Solo con la reserva CONFIRMADA o EN_CURSO, aunque la conversación ya exista. El remitente es siempre el usuario del token. Avisa al otro participante con "Mensaje sobre la entrega" (un aviso por mensaje); si el aviso falla, el mensaje queda guardado igual.',
  })
  @ApiCreatedResponse({ type: MensajeResponseDto })
  @ApiBadRequestResponse({
    description:
      'El reservaId no es un UUID, el contenido no es texto, está vacío, es solo espacios o supera los 1000 caracteres, o se envió un campo no permitido.',
  })
  @ApiUnauthorizedResponse({ description: SIN_SESION })
  @ApiForbiddenResponse({ description: NO_PARTICIPANTE })
  @ApiNotFoundResponse({ description: NO_EXISTE })
  @ApiConflictResponse({ description: CONFLICTO })
  @ApiUnprocessableEntityResponse({ description: NO_SE_PUEDE_ESCRIBIR })
  async enviar(
    @Param('reservaId', ParseUUIDPipe) reservaId: string,
    @CurrentUser() usuario: AuthenticatedUser,
    @Body() dto: CrearMensajeDto,
  ): Promise<MensajeResponseDto> {
    const mensaje = await this.coordinacionService.enviar(
      reservaId,
      usuario.id,
      dto.contenido,
    );
    return MensajeResponseDto.from(mensaje);
  }

  @Get(':reservaId/conversacion/mensajes')
  @ApiOperation({
    summary: 'Consulta el historial de la coordinación de una reserva',
    description:
      'Mismas reglas que la conversación: si ya existe, el historial completo se lee en cualquier estado de la reserva (también FINALIZADA o CANCELADA); si no existe, solo se crea con la reserva CONFIRMADA o EN_CURSO. Por defecto en orden cronológico; la fecha y luego el id deciden el orden.',
  })
  @ApiOkResponse({ type: MensajesResponseDto })
  @ApiBadRequestResponse({
    description: 'El reservaId no es un UUID o el orden no es asc ni desc.',
  })
  @ApiUnauthorizedResponse({ description: SIN_SESION })
  @ApiForbiddenResponse({ description: NO_PARTICIPANTE })
  @ApiNotFoundResponse({ description: NO_EXISTE })
  @ApiConflictResponse({ description: CONFLICTO })
  @ApiUnprocessableEntityResponse({ description: NO_SE_PUEDE_CREAR })
  async listar(
    @Param('reservaId', ParseUUIDPipe) reservaId: string,
    @CurrentUser() usuario: AuthenticatedUser,
    @Query() { orden }: ConsultarMensajesDto,
  ): Promise<MensajesResponseDto> {
    const { conversacionId, mensajes } = await this.coordinacionService.listar(
      reservaId,
      usuario.id,
      orden,
    );
    return MensajesResponseDto.from(conversacionId, orden, mensajes);
  }
}
