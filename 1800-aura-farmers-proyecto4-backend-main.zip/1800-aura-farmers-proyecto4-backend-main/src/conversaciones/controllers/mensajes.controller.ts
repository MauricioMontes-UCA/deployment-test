import {
  Body,
  Controller,
  Get,
  Param,
  ParseUUIDPipe,
  Post,
  Query,
} from '@nestjs/common';
import {
  ApiBadRequestResponse,
  ApiBearerAuth,
  ApiCreatedResponse,
  ApiForbiddenResponse,
  ApiNotFoundResponse,
  ApiOkResponse,
  ApiOperation,
  ApiTags,
  ApiUnauthorizedResponse,
} from '@nestjs/swagger';
import { CurrentUser } from '@Auth/decorators';
import type { AuthenticatedUser } from '@Auth/types';
import {
  ConsultarMensajesDto,
  CrearMensajeDto,
  MensajeResponseDto,
  MensajesResponseDto,
} from '@Conversaciones/dto';
import { ConversacionesService } from '@Conversaciones/services';

/**
 * Mensajes de una conversación. Sin `@Roles()`: escriben y leen los dos
 * participantes, sea cual sea su rol, y el servicio rechaza a los demás.
 */
@ApiTags('conversaciones')
@ApiBearerAuth()
@Controller('conversaciones')
export class MensajesController {
  constructor(private readonly conversacionesService: ConversacionesService) {}

  @Post(':id/mensajes')
  @ApiOperation({
    summary: 'Envía un mensaje en una conversación',
    description:
      'El remitente es siempre el usuario del token. Solo pueden escribir los dos participantes.',
  })
  @ApiCreatedResponse({ type: MensajeResponseDto })
  @ApiBadRequestResponse({
    description:
      'El id no es un UUID, el contenido no es texto, está vacío, es solo espacios o supera los 1000 caracteres, o se envió un campo no permitido.',
  })
  @ApiUnauthorizedResponse({
    description: 'Token ausente, inválido o expirado.',
  })
  @ApiForbiddenResponse({
    description: 'El usuario no participa en la conversación.',
  })
  @ApiNotFoundResponse({
    description:
      'La conversación no existe o no es una conversación previa: las conversaciones vinculadas a una reserva no se atienden por esta ruta.',
  })
  async enviar(
    @Param('id', ParseUUIDPipe) conversacionId: string,
    @CurrentUser() usuario: AuthenticatedUser,
    @Body() dto: CrearMensajeDto,
  ): Promise<MensajeResponseDto> {
    const mensaje = await this.conversacionesService.enviar(
      conversacionId,
      usuario.id,
      dto.contenido,
    );
    return MensajeResponseDto.from(mensaje);
  }

  @Get(':id/mensajes')
  @ApiOperation({
    summary: 'Consulta el historial de una conversación',
    description:
      'Solo para los dos participantes. Por defecto, en orden cronológico.',
  })
  @ApiOkResponse({ type: MensajesResponseDto })
  @ApiBadRequestResponse({
    description: 'El id no es un UUID o el orden no es asc ni desc.',
  })
  @ApiUnauthorizedResponse({
    description: 'Token ausente, inválido o expirado.',
  })
  @ApiForbiddenResponse({
    description: 'El usuario no participa en la conversación.',
  })
  @ApiNotFoundResponse({
    description:
      'La conversación no existe o no es una conversación previa: las conversaciones vinculadas a una reserva no se atienden por esta ruta.',
  })
  async listar(
    @Param('id', ParseUUIDPipe) conversacionId: string,
    @CurrentUser() usuario: AuthenticatedUser,
    @Query() { orden }: ConsultarMensajesDto,
  ): Promise<MensajesResponseDto> {
    const mensajes = await this.conversacionesService.listar(
      conversacionId,
      usuario.id,
      orden,
    );
    return MensajesResponseDto.from(conversacionId, orden, mensajes);
  }
}
