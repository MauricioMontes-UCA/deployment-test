import { BadRequestException } from '@nestjs/common';
import {
  MAXIMO_DIAS_RANGO,
  MENSAJES_PERIODO,
  PeriodoReporte,
  resolverPeriodo,
} from './periodo.js';

const HOY = new Date('2026-11-15T00:00:00.000Z');
const MS_POR_DIA = 24 * 60 * 60 * 1000;

/** Días contados desde `desde` hasta `hasta`, ambos incluidos. */
const diasDelRango = (desde: string, hasta: string) =>
  Math.round(
    (new Date(`${hasta}T00:00:00.000Z`).getTime() -
      new Date(`${desde}T00:00:00.000Z`).getTime()) /
      MS_POR_DIA,
  ) + 1;

/** `hasta` a `dias` días de `desde`, contando ambos (rango de `dias` días). */
const rangoDe = (dias: number) => {
  const desde = new Date('2026-01-01T00:00:00.000Z');
  const hasta = new Date(desde.getTime() + (dias - 1) * MS_POR_DIA);
  return {
    periodo: PeriodoReporte.RANGO,
    desde: desde.toISOString().slice(0, 10),
    hasta: hasta.toISOString().slice(0, 10),
  };
};

const mensajeDe = (accion: () => unknown): string => {
  try {
    accion();
  } catch (error) {
    expect(error).toBeInstanceOf(BadRequestException);
    return (error as BadRequestException).message;
  }
  throw new Error('Se esperaba un BadRequestException.');
};

describe('resolverPeriodo', () => {
  describe('periodos fijos', () => {
    it.each([
      [PeriodoReporte.ULTIMO_MES, '2026-10-17', 30],
      [PeriodoReporte.ULTIMOS_3_MESES, '2026-08-18', 90],
      [PeriodoReporte.ULTIMO_ANIO, '2025-11-16', 365],
    ])('%s termina hoy y cubre %i días', (periodo, desde, dias) => {
      const resultado = resolverPeriodo({ periodo }, HOY);

      expect(resultado).toEqual({ desde, hasta: '2026-11-15' });
      expect(diasDelRango(resultado.desde, resultado.hasta)).toBe(dias);
    });

    it('sin periodo usa el último mes', () => {
      expect(resolverPeriodo({}, HOY)).toEqual({
        desde: '2026-10-17',
        hasta: '2026-11-15',
      });
    });

    it('cruza el fin de año sin perder días', () => {
      const hoy = new Date('2027-01-10T00:00:00.000Z');

      expect(
        resolverPeriodo({ periodo: PeriodoReporte.ULTIMO_MES }, hoy),
      ).toEqual({ desde: '2026-12-12', hasta: '2027-01-10' });
    });

    it('el último año cubre 365 días también si pasa por un 29 de febrero', () => {
      // 2028 es bisiesto: del 2027-03-02 al 2028-03-01 hay 365 días.
      const hoy = new Date('2028-03-01T00:00:00.000Z');
      const { desde, hasta } = resolverPeriodo(
        { periodo: PeriodoReporte.ULTIMO_ANIO },
        hoy,
      );

      expect(diasDelRango(desde, hasta)).toBe(365);
      expect(hasta).toBe('2028-03-01');
    });

    it.each([PeriodoReporte.ULTIMO_MES, PeriodoReporte.ULTIMO_ANIO])(
      'con %s ignora desde y hasta, aunque vengan inválidos',
      (periodo) => {
        expect(
          resolverPeriodo(
            { periodo, desde: 'basura', hasta: '2020-02-30' },
            HOY,
          ),
        ).toEqual(resolverPeriodo({ periodo }, HOY));
      },
    );
  });

  describe('RANGO', () => {
    it('devuelve las fechas recibidas', () => {
      expect(
        resolverPeriodo(
          {
            periodo: PeriodoReporte.RANGO,
            desde: '2026-10-01',
            hasta: '2026-10-31',
          },
          HOY,
        ),
      ).toEqual({ desde: '2026-10-01', hasta: '2026-10-31' });
    });

    it('acepta un rango de 1 día', () => {
      expect(
        resolverPeriodo(
          {
            periodo: PeriodoReporte.RANGO,
            desde: '2026-10-01',
            hasta: '2026-10-01',
          },
          HOY,
        ),
      ).toEqual({ desde: '2026-10-01', hasta: '2026-10-01' });
    });

    it(`acepta un rango de ${MAXIMO_DIAS_RANGO} días`, () => {
      const solicitud = rangoDe(MAXIMO_DIAS_RANGO);

      expect(resolverPeriodo(solicitud, HOY)).toEqual({
        desde: solicitud.desde,
        hasta: solicitud.hasta,
      });
    });

    it(`rechaza un rango de ${MAXIMO_DIAS_RANGO + 1} días`, () => {
      expect(
        mensajeDe(() => resolverPeriodo(rangoDe(MAXIMO_DIAS_RANGO + 1), HOY)),
      ).toBe('El rango no puede ser mayor a 365 días.');
    });

    it('permite un rango que termina en el futuro', () => {
      expect(
        resolverPeriodo(
          {
            periodo: PeriodoReporte.RANGO,
            desde: '2026-11-01',
            hasta: '2026-12-31',
          },
          HOY,
        ),
      ).toEqual({ desde: '2026-11-01', hasta: '2026-12-31' });
    });
  });

  describe('errores 400 con el mensaje exacto', () => {
    const rango = (desde?: string, hasta?: string) => ({
      periodo: PeriodoReporte.RANGO,
      desde,
      hasta,
    });

    it.each([
      ['sin desde', rango(undefined, '2026-10-31')],
      ['sin hasta', rango('2026-10-01', undefined)],
      ['sin ninguna', rango()],
      ['con desde vacío', rango('', '2026-10-31')],
    ])('RANGO %s: pide completar las fechas', (_caso, solicitud) => {
      expect(mensajeDe(() => resolverPeriodo(solicitud, HOY))).toBe(
        'Completa las fechas del rango.',
      );
    });

    it.each([
      ['otro formato', rango('01-10-2026', '2026-10-31')],
      ['con hora', rango('2026-10-01T00:00', '2026-10-31')],
      ['en hasta', rango('2026-10-01', '31/10/2026')],
      ['un día que no existe', rango('2026-02-30', '2026-03-10')],
      ['un mes que no existe', rango('2026-13-01', '2026-13-10')],
      ['29 de febrero sin año bisiesto', rango('2026-02-29', '2026-03-10')],
    ])('RANGO con %s: pide el formato', (_caso, solicitud) => {
      expect(mensajeDe(() => resolverPeriodo(solicitud, HOY))).toBe(
        'Usa el formato AAAA-MM-DD.',
      );
    });

    it('acepta el 29 de febrero de un año bisiesto', () => {
      expect(resolverPeriodo(rango('2028-02-29', '2028-03-01'), HOY)).toEqual({
        desde: '2028-02-29',
        hasta: '2028-03-01',
      });
    });

    it('RANGO con hasta anterior a desde: lo rechaza', () => {
      expect(
        mensajeDe(() =>
          resolverPeriodo(rango('2026-10-31', '2026-10-01'), HOY),
        ),
      ).toBe('La fecha final no puede ser anterior a la inicial.');
    });

    it('los mensajes coinciden con la especificación', () => {
      expect(MENSAJES_PERIODO).toEqual({
        RANGO_INCOMPLETO: 'Completa las fechas del rango.',
        FORMATO: 'Usa el formato AAAA-MM-DD.',
        FECHAS_INVERTIDAS: 'La fecha final no puede ser anterior a la inicial.',
        RANGO_MUY_LARGO: 'El rango no puede ser mayor a 365 días.',
      });
    });

    it('con varios problemas, informa primero el de fechas faltantes y luego el de formato', () => {
      expect(
        mensajeDe(() => resolverPeriodo(rango('basura', undefined), HOY)),
      ).toBe('Completa las fechas del rango.');
      expect(
        mensajeDe(() => resolverPeriodo(rango('basura', '2026-10-01'), HOY)),
      ).toBe('Usa el formato AAAA-MM-DD.');
    });
  });
});
