/** Escala de las reseñas del Módulo 6: de 1 a 5 estrellas. */
export const ESCALA_MAXIMA_CALIFICACION = 5;

/** Calificación de un bien en el periodo. */
export interface CalificacionDeBien {
  bienId: string;
  titulo: string;
  /** Promedio con un decimal, o `null` si no hay reseñas en el periodo. */
  promedio: number | null;
  totalResenas: number;
}

/**
 * Promedio de `cantidad` puntuaciones que suman `suma`, redondeado a un
 * decimal (la mitad hacia arriba: 4.45 da 4.5), o `null` si no hay reseñas.
 *
 * Se redondea `suma * 10 / cantidad` y luego se divide entre 10. Como las
 * puntuaciones son enteras, ese cociente es exacto cuando termina en .5, así
 * que el redondeo no arrastra errores de coma flotante.
 */
export function promedioConUnDecimal(
  suma: number,
  cantidad: number,
): number | null {
  if (cantidad === 0) return null;
  return Math.round((suma * 10) / cantidad) / 10;
}

const COMPARAR_TITULOS = new Intl.Collator('es', { sensitivity: 'base' });

/**
 * Orden del reporte: de la peor calificación a la mejor, los bienes sin
 * calificaciones al final y, a igual promedio, por título de la A a la Z con
 * las reglas del español (ignora mayúsculas y tildes). El `bienId` desempata
 * dos títulos iguales para que el orden sea estable.
 */
export function ordenarCalificaciones(
  bienes: readonly CalificacionDeBien[],
): CalificacionDeBien[] {
  return [...bienes].sort((a, b) => {
    if (a.promedio !== b.promedio) {
      if (a.promedio === null) return 1;
      if (b.promedio === null) return -1;
      return a.promedio - b.promedio;
    }
    return (
      COMPARAR_TITULOS.compare(a.titulo, b.titulo) ||
      a.bienId.localeCompare(b.bienId)
    );
  });
}
