import {
  calcularIngresos,
  centavosADolares,
  type BienDeReporte,
  type CentavosDeBien,
} from './ingresos.js';

const bien = (id: string, titulo: string): BienDeReporte => ({ id, titulo });
const montos = (
  bienId: string,
  ingresosCentavos: number,
  depositoRetenidoCentavos = 0,
): CentavosDeBien => ({ bienId, ingresosCentavos, depositoRetenidoCentavos });

describe('centavosADolares', () => {
  it.each([
    [0, 0],
    [1, 0.01],
    [25000, 250],
    [25025, 250.25],
    [33000, 330],
  ])('%i centavos son %d dólares', (centavos, dolares) => {
    expect(centavosADolares(centavos)).toBe(dolares);
  });
});

describe('calcularIngresos', () => {
  const salon = bien('b1', 'Salón de eventos');
  const taladro = bien('b2', 'Taladro industrial');
  const proyector = bien('b3', 'Proyector 4K');

  describe('con pagos', () => {
    it('devuelve los ingresos y el depósito retenido de cada bien', () => {
      const resumen = calcularIngresos(
        [salon, taladro],
        [montos('b1', 25000, 5000), montos('b2', 8000, 1500)],
      );

      expect(resumen.bienes).toEqual([
        {
          bienId: 'b1',
          titulo: 'Salón de eventos',
          ingresos: 250,
          depositoRetenido: 50,
        },
        {
          bienId: 'b2',
          titulo: 'Taladro industrial',
          ingresos: 80,
          depositoRetenido: 15,
        },
      ]);
    });

    it('los totales son la suma de los bienes devueltos', () => {
      const resumen = calcularIngresos(
        [salon, taladro],
        [montos('b1', 25000, 5000), montos('b2', 8000, 1500)],
      );

      expect(resumen).toMatchObject({
        totalIngresos: 330,
        totalDepositoRetenido: 65,
        totalBienes: 2,
      });
    });

    it('un bien con depósito retenido pero sin ingresos lo muestra en su línea', () => {
      const resumen = calcularIngresos([salon], [montos('b1', 0, 5000)]);

      expect(resumen.bienes[0]).toMatchObject({
        ingresos: 0,
        depositoRetenido: 50,
      });
      expect(resumen.totalIngresos).toBe(0);
      expect(resumen.totalDepositoRetenido).toBe(50);
    });
  });

  describe('sin pagos', () => {
    it('cada bien aparece con 0 en lugar de faltar', () => {
      const resumen = calcularIngresos([salon, taladro], []);

      expect(resumen.bienes).toHaveLength(2);
      for (const fila of resumen.bienes) {
        expect(fila.ingresos).toBe(0);
        expect(fila.depositoRetenido).toBe(0);
      }
      expect(resumen).toMatchObject({
        totalIngresos: 0,
        totalDepositoRetenido: 0,
        totalBienes: 2,
      });
    });

    it('sin bienes devuelve la lista vacía y los totales en 0', () => {
      expect(calcularIngresos([], [])).toEqual({
        totalIngresos: 0,
        totalDepositoRetenido: 0,
        totalBienes: 0,
        bienes: [],
      });
    });

    it('ignora lo que la base devuelva de un bien que no está en la lista', () => {
      const resumen = calcularIngresos([salon], [montos('ajeno', 50000, 9000)]);

      expect(resumen.bienes.map((fila) => fila.bienId)).toEqual(['b1']);
      expect(resumen.totalIngresos).toBe(0);
      expect(resumen.totalDepositoRetenido).toBe(0);
    });
  });

  describe('orden', () => {
    it('va de mayor a menor ingreso', () => {
      const resumen = calcularIngresos(
        [taladro, salon, proyector],
        [montos('b1', 25000), montos('b2', 8000), montos('b3', 12000)],
      );

      expect(resumen.bienes.map((fila) => fila.titulo)).toEqual([
        'Salón de eventos',
        'Proyector 4K',
        'Taladro industrial',
      ]);
    });

    it('a igual ingreso ordena por título de la A a la Z', () => {
      const resumen = calcularIngresos(
        [taladro, salon, proyector],
        [montos('b1', 1000), montos('b2', 1000), montos('b3', 1000)],
      );

      expect(resumen.bienes.map((fila) => fila.titulo)).toEqual([
        'Proyector 4K',
        'Salón de eventos',
        'Taladro industrial',
      ]);
    });

    it('con todos en 0 también ordena por título', () => {
      const resumen = calcularIngresos([taladro, salon, proyector], []);

      expect(resumen.bienes.map((fila) => fila.titulo)).toEqual([
        'Proyector 4K',
        'Salón de eventos',
        'Taladro industrial',
      ]);
    });

    it('compara los títulos en español: la Ñ va después de la N y los acentos no cambian la letra', () => {
      const resumen = calcularIngresos(
        [
          bien('b1', 'Ñandú'),
          bien('b2', 'Oso'),
          bien('b3', 'Nube'),
          bien('b4', 'Álamo'),
          bien('b5', 'Zorro'),
        ],
        [],
      );

      expect(resumen.bienes.map((fila) => fila.titulo)).toEqual([
        'Álamo',
        'Nube',
        'Ñandú',
        'Oso',
        'Zorro',
      ]);
    });

    it('con el mismo ingreso y el mismo título desempata por id, para que el orden sea estable', () => {
      const a = calcularIngresos([bien('b2', 'Casa'), bien('b1', 'Casa')], []);
      const b = calcularIngresos([bien('b1', 'Casa'), bien('b2', 'Casa')], []);

      expect(a.bienes.map((fila) => fila.bienId)).toEqual(['b1', 'b2']);
      expect(b.bienes).toEqual(a.bienes);
    });

    it('no modifica la lista de bienes recibida', () => {
      const entrada = [taladro, salon];

      calcularIngresos(entrada, [montos('b1', 100)]);

      expect(entrada).toEqual([taladro, salon]);
    });
  });

  describe('redondeo a dos decimales', () => {
    it('suma en centavos: 0.10 + 0.20 da exactamente 0.30', () => {
      const resumen = calcularIngresos(
        [salon, taladro],
        [montos('b1', 10), montos('b2', 20)],
      );

      expect(resumen.totalIngresos).toBe(0.3);
    });

    it('muchos importes pequeños no acumulan error de coma flotante', () => {
      const bienes = Array.from({ length: 100 }, (_, i) =>
        bien(`b${i}`, `Bien ${i}`),
      );
      const resumen = calcularIngresos(
        bienes,
        bienes.map(({ id }) => montos(id, 10)),
      );

      // 100 bienes con 0.10 cada uno: 10.00 exactos.
      expect(resumen.totalIngresos).toBe(10);
    });

    it('los montos salen con dos decimales exactos', () => {
      const resumen = calcularIngresos([salon], [montos('b1', 33333, 6667)]);

      expect(resumen.bienes[0]).toMatchObject({
        ingresos: 333.33,
        depositoRetenido: 66.67,
      });
      expect(resumen.totalIngresos.toFixed(2)).toBe('333.33');
    });
  });
});
