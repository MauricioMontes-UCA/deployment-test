import { parseDia } from '@Bienes/utils';
import type { PeriodoResuelto } from './periodo.js';
import type { FilaResumen } from './resumen.js';

/** `Content-Type` del archivo exportado. */
export const TIPO_CONTENIDO_CSV = 'text/csv; charset=utf-8';

/** Primera línea del CSV, en el orden de las columnas. */
export const ENCABEZADO_RESUMEN_CSV = [
  'Bien',
  'Ingresos (USD)',
  'Tasa de ocupación (%)',
  'Calificación promedio',
  'Reseñas',
] as const;

/** Texto que se escribe cuando `tasaOcupacion` es `null`. */
export const SIN_DIAS_DISPONIBLES = 'Sin días disponibles';

/** Texto que se escribe cuando `calificacionPromedio` es `null`. */
export const SIN_CALIFICACIONES = 'Sin calificaciones';

/** Marca de orden de bytes: hace que las hojas de cálculo lean el UTF-8 bien. */
const BOM = '\uFEFF';

const FIN_DE_LINEA = '\r\n';

/**
 * Caracteres iniciales con los que una hoja de cálculo puede interpretar una
 * celda como fórmula: `=`, `+`, `-` y `@` (los de BE-26.2), más el tabulador y
 * el retorno de carro, que OWASP también lista (CSV Injection).
 *
 * Por la API ningún título puede empezar con tabulador ni retorno de carro,
 * porque `CreateBienDto` lo recorta; cubrirlos es defensa en profundidad para
 * datos que lleguen por otra vía (el seed o la base directamente).
 */
const INICIO_DE_FORMULA = /^[\t\r=+\-@]/;

/** Un campo con alguno de estos caracteres va entre comillas dobles. */
const NECESITA_COMILLAS = /[",\r\n]/;

/**
 * Antepone una comilla simple si el texto empieza con `=`, `+`, `-`, `@`, un
 * tabulador o un retorno de carro, para que la hoja de cálculo lo trate como
 * texto y no lo ejecute como fórmula. Esos caracteres en medio del texto no
 * cambian nada.
 */
export function protegerFormula(texto: string): string {
  return INICIO_DE_FORMULA.test(texto) ? `'${texto}` : texto;
}

/**
 * Escapa un campo según el CSV estándar: si tiene coma, comillas o un salto de
 * línea, va entre comillas dobles y cada comilla interna se duplica.
 */
export function escaparCampoCsv(valor: string): string {
  return NECESITA_COMILLAS.test(valor)
    ? `"${valor.replaceAll('"', '""')}"`
    : valor;
}

/** Los cinco campos de una fila, ya con formato y sin escapar. */
function camposDeFila(fila: FilaResumen): string[] {
  return [
    // La protección va antes del escape: '=A,B' queda "'=A,B".
    protegerFormula(fila.titulo),
    fila.ingresos.toFixed(2),
    fila.tasaOcupacion === null
      ? SIN_DIAS_DISPONIBLES
      : fila.tasaOcupacion.toFixed(1),
    fila.calificacionPromedio === null
      ? SIN_CALIFICACIONES
      : fila.calificacionPromedio.toFixed(1),
    String(fila.totalResenas),
  ];
}

function linea(campos: readonly string[]): string {
  return campos.map(escaparCampoCsv).join(',') + FIN_DE_LINEA;
}

/**
 * Arma el CSV del resumen comparativo (H26, BE-26.2): BOM, encabezado y una
 * fila por bien, separadas por coma y con CRLF al final de cada línea, también
 * de la última.
 *
 * Recibe las filas tal como las devuelve `ResumenService.resumen()` y respeta
 * su orden: no ordena, no filtra, no recalcula y no modifica el arreglo. Los
 * números van con punto decimal: ingresos con dos decimales, tasa y promedio
 * con uno. Sin bienes, el archivo es solo el encabezado.
 */
export function generarResumenCsv(bienes: readonly FilaResumen[]): string {
  return (
    BOM +
    linea(ENCABEZADO_RESUMEN_CSV) +
    bienes.map((fila) => linea(camposDeFila(fila))).join('')
  );
}

/**
 * Nombre del archivo: `resumen-desempeno_AAAA-MM-DD_AAAA-MM-DD.csv`, con las
 * fechas del periodo ya resuelto.
 *
 * Las fechas ya vienen validadas por `resolverPeriodo`; se vuelven a comprobar
 * porque el nombre termina en una cabecera HTTP y no debe llevar otra cosa que
 * dígitos y guiones.
 *
 * @throws {Error} una fecha no es un día `AAAA-MM-DD` real (error interno).
 */
export function nombreArchivoResumen({
  desde,
  hasta,
}: PeriodoResuelto): string {
  if (!parseDia(desde) || !parseDia(hasta)) {
    throw new Error(
      `Periodo no resuelto para el nombre del archivo: ${desde} - ${hasta}`,
    );
  }
  return `resumen-desempeno_${desde}_${hasta}.csv`;
}
