import { parseDia } from '@Bienes/utils';
import type { BienDeReporte } from './ingresos.js';
import { calcularOcupacion, type Intervalo } from './ocupacion.js';
import type { PeriodoResuelto } from './periodo.js';

/** Un rango de días de una reserva o un bloqueo, con el bien al que pertenece. */
export interface IntervaloDeBien extends Intervalo {
  bienId: string;
}

/** Ocupación de un bien en el periodo. */
export interface OcupacionDeBien {
  bienId: string;
  titulo: string;
  diasDisponibles: number;
  diasOcupados: number;
  /** Porcentaje con un decimal, o `null` si no hay días disponibles. */
  tasaOcupacion: number | null;
}

/** Agrupa los intervalos por bien. */
function porBien(intervalos: IntervaloDeBien[]): Map<string, Intervalo[]> {
  const mapa = new Map<string, Intervalo[]>();
  for (const { bienId, inicio, fin } of intervalos) {
    const lista = mapa.get(bienId) ?? [];
    lista.push({ inicio, fin });
    mapa.set(bienId, lista);
  }
  return mapa;
}

/**
 * Arma el reporte de ocupación: una fila por cada bien recibido, también los
 * que no tienen reservas ni bloqueos (con tasa 0.0).
 *
 * - Los días se cuentan con `calcularOcupacion` (BE-24.1). Quien llama entrega
 *   solo las reservas que ocupan días (CONFIRMADA, EN_CURSO, FINALIZADA).
 * - Lo que llegue de un bien que no está en la lista se ignora.
 * - Orden: tasa de mayor a menor, los `null` ("Sin días disponibles") al final
 *   y, a igual tasa, título de la A a la Z comparando en español; el id
 *   desempata para que el orden sea estable.
 */
export function armarOcupacion(
  bienes: BienDeReporte[],
  { desde, hasta }: PeriodoResuelto,
  reservas: IntervaloDeBien[],
  bloqueos: IntervaloDeBien[],
): OcupacionDeBien[] {
  const periodo = { desde: parseDia(desde)!, hasta: parseDia(hasta)! };
  const reservasPorBien = porBien(reservas);
  const bloqueosPorBien = porBien(bloqueos);

  const filas = bienes.map(({ id, titulo }) => {
    const { diasDisponibles, diasOcupados, tasa } = calcularOcupacion(
      periodo,
      reservasPorBien.get(id) ?? [],
      bloqueosPorBien.get(id) ?? [],
    );
    return {
      bienId: id,
      titulo,
      diasDisponibles,
      diasOcupados,
      tasaOcupacion: tasa,
    };
  });

  return filas.sort((a, b) => {
    if (a.tasaOcupacion !== b.tasaOcupacion) {
      if (a.tasaOcupacion === null) return 1;
      if (b.tasaOcupacion === null) return -1;
      return b.tasaOcupacion - a.tasaOcupacion;
    }
    return (
      a.titulo.localeCompare(b.titulo, 'es') || a.bienId.localeCompare(b.bienId)
    );
  });
}
