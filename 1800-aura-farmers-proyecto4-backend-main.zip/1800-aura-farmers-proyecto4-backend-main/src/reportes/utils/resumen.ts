import type { CalificacionDeBien } from './calificaciones.js';
import type { IngresoDeBien } from './ingresos.js';
import type { OcupacionDeBien } from './reporte-ocupacion.js';

/** Fila del resumen comparativo: las tres métricas de un bien en el periodo. */
export interface FilaResumen {
  bienId: string;
  titulo: string;
  /** Igual que `ingresos` del reporte de ingresos, con dos decimales. */
  ingresos: number;
  /** Igual que el reporte de ocupación; `null` es "Sin días disponibles". */
  tasaOcupacion: number | null;
  /** Igual que `promedio` del reporte de calificaciones; `null` es "Sin calificaciones". */
  calificacionPromedio: number | null;
  totalResenas: number;
}

export interface ResumenDeBienes {
  totalBienes: number;
  bienes: FilaResumen[];
}

const COMPARAR_TITULOS = new Intl.Collator('es', { sensitivity: 'base' });

/**
 * Une por bien los tres reportes del mismo periodo en las filas del resumen.
 *
 * - La lista de bienes es la del reporte de ingresos, que ya trae todos los
 *   bienes ACTIVA del arrendador con su título.
 * - Los valores se copian tal como vienen de cada reporte, sin volver a
 *   redondear, para que el resumen coincida con los reportes individuales.
 * - Si un bien no aparece en la ocupación o en las calificaciones (por ejemplo,
 *   porque cambió de estado entre una consulta y otra), queda sin datos de ese
 *   reporte: tasa `null`, promedio `null` y 0 reseñas. Lo que llegue de un bien
 *   que no está en los ingresos se ignora.
 * - Orden: título de la A a la Z con las reglas del español (sin distinguir
 *   mayúsculas ni tildes); el `bienId` desempata para que el orden sea estable.
 */
export function armarResumen(
  ingresos: readonly IngresoDeBien[],
  ocupacion: readonly OcupacionDeBien[],
  calificaciones: readonly CalificacionDeBien[],
): ResumenDeBienes {
  const ocupacionPorBien = new Map(
    ocupacion.map((fila) => [fila.bienId, fila]),
  );
  const calificacionPorBien = new Map(
    calificaciones.map((fila) => [fila.bienId, fila]),
  );

  const bienes = ingresos.map(({ bienId, titulo, ingresos: monto }) => {
    const calificacion = calificacionPorBien.get(bienId);
    return {
      bienId,
      titulo,
      ingresos: monto,
      tasaOcupacion: ocupacionPorBien.get(bienId)?.tasaOcupacion ?? null,
      calificacionPromedio: calificacion?.promedio ?? null,
      totalResenas: calificacion?.totalResenas ?? 0,
    };
  });

  bienes.sort(
    (a, b) =>
      COMPARAR_TITULOS.compare(a.titulo, b.titulo) ||
      a.bienId.localeCompare(b.bienId),
  );

  return { totalBienes: bienes.length, bienes };
}
