import {
  ordenarCalificaciones,
  promedioConUnDecimal,
  type CalificacionDeBien,
} from './calificaciones.js';

const bien = (
  bienId: string,
  titulo: string,
  promedio: number | null,
): CalificacionDeBien => ({
  bienId,
  titulo,
  promedio,
  totalResenas: promedio === null ? 0 : 1,
});

const titulos = (bienes: CalificacionDeBien[]) => bienes.map((b) => b.titulo);

describe('ordenarCalificaciones', () => {
  it('va de la peor calificación a la mejor, con las nulas al final', () => {
    const orden = ordenarCalificaciones([
      bien('1', 'Salón', 4.5),
      bien('2', 'Casa', null),
      bien('3', 'Proyector', null),
      bien('4', 'Mesa de sonido', 3),
      bien('5', 'Carpa', 5),
    ]);

    expect(titulos(orden)).toEqual([
      'Mesa de sonido',
      'Salón',
      'Carpa',
      'Casa',
      'Proyector',
    ]);
  });

  it('a igual promedio ordena por título en español, sin importar tildes ni mayúsculas', () => {
    const orden = ordenarCalificaciones([
      bien('1', 'zapatos', 4),
      bien('2', 'Ñandú', 4),
      bien('3', 'Ábaco', 4),
      bien('4', 'nube', 4),
      bien('5', 'Banco', 4),
    ]);

    expect(titulos(orden)).toEqual([
      'Ábaco',
      'Banco',
      'nube',
      'Ñandú',
      'zapatos',
    ]);
  });

  it('los bienes sin calificaciones también van por título', () => {
    const orden = ordenarCalificaciones([
      bien('1', 'Proyector 4K', null),
      bien('2', 'Bocina', null),
    ]);
    expect(titulos(orden)).toEqual(['Bocina', 'Proyector 4K']);
  });

  it('desempata por id dos títulos iguales', () => {
    const orden = ordenarCalificaciones([
      bien('b', 'Casa', 4),
      bien('a', 'Casa', 4),
    ]);
    expect(orden.map((b) => b.bienId)).toEqual(['a', 'b']);
  });

  it('no modifica la lista original', () => {
    const original = [bien('1', 'B', 5), bien('2', 'A', 1)];
    ordenarCalificaciones(original);
    expect(titulos(original)).toEqual(['B', 'A']);
  });

  it('una lista vacía queda vacía', () => {
    expect(ordenarCalificaciones([])).toEqual([]);
  });
});

describe('promedioConUnDecimal', () => {
  it('sin reseñas es null, no 0', () => {
    expect(promedioConUnDecimal(0, 0)).toBeNull();
  });

  it.each([
    ['una reseña', 3, 1, 3],
    ['dos reseñas (5 y 4)', 9, 2, 4.5],
    ['todas de 5', 15, 3, 5],
    ['todas de 1', 4, 4, 1],
  ])('con %s', (_caso, suma, cantidad, esperado) => {
    expect(promedioConUnDecimal(suma, cantidad)).toBe(esperado);
  });

  it.each([
    ['4.666… sube a 4.7', 14, 3, 4.7],
    ['4.333… baja a 4.3', 13, 3, 4.3],
    ['2.333… baja a 2.3', 7, 3, 2.3],
    ['4.45 (mitad) sube a 4.5', 89, 20, 4.5],
    ['4.25 (mitad) sube a 4.3', 17, 4, 4.3],
    ['4.05 (mitad) sube a 4.1', 81, 20, 4.1],
    ['1.15 (mitad) sube a 1.2', 23, 20, 1.2],
    ['3.142857… baja a 3.1', 22, 7, 3.1],
  ])('redondea a un decimal: %s', (_caso, suma, cantidad, esperado) => {
    expect(promedioConUnDecimal(suma, cantidad)).toBe(esperado);
  });

  it('nunca da más de un decimal', () => {
    for (let cantidad = 1; cantidad <= 50; cantidad++) {
      for (let suma = cantidad; suma <= cantidad * 5; suma++) {
        const promedio = promedioConUnDecimal(suma, cantidad)!;
        expect(Math.round(promedio * 10) / 10).toBe(promedio);
        expect(promedio).toBeGreaterThanOrEqual(1);
        expect(promedio).toBeLessThanOrEqual(5);
      }
    }
  });
});
