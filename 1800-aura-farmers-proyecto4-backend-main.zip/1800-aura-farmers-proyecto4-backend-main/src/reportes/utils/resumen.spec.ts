import type { CalificacionDeBien } from './calificaciones.js';
import type { IngresoDeBien } from './ingresos.js';
import type { OcupacionDeBien } from './reporte-ocupacion.js';
import { armarResumen } from './resumen.js';

const ingreso = (
  bienId: string,
  titulo: string,
  ingresos = 0,
): IngresoDeBien => ({ bienId, titulo, ingresos, depositoRetenido: 0 });

const ocupacion = (
  bienId: string,
  tasaOcupacion: number | null,
): OcupacionDeBien => ({
  bienId,
  titulo: 'no se usa',
  diasDisponibles: 30,
  diasOcupados: 0,
  tasaOcupacion,
});

const calificacion = (
  bienId: string,
  promedio: number | null,
  totalResenas: number,
): CalificacionDeBien => ({
  bienId,
  titulo: 'no se usa',
  promedio,
  totalResenas,
});

const titulos = (ingresos: IngresoDeBien[]) =>
  armarResumen(ingresos, [], []).bienes.map((fila) => fila.titulo);

describe('armarResumen', () => {
  it('une por bien los valores de los tres reportes, tal como vienen', () => {
    const resumen = armarResumen(
      [ingreso('b1', 'Salón de eventos', 250), ingreso('b2', 'Taladro', 80.05)],
      // Las listas llegan en el orden de cada reporte, no en el del resumen.
      [ocupacion('b2', null), ocupacion('b1', 50)],
      [calificacion('b2', null, 0), calificacion('b1', 4.5, 2)],
    );

    expect(resumen).toEqual({
      totalBienes: 2,
      bienes: [
        {
          bienId: 'b1',
          titulo: 'Salón de eventos',
          ingresos: 250,
          tasaOcupacion: 50,
          calificacionPromedio: 4.5,
          totalResenas: 2,
        },
        {
          bienId: 'b2',
          titulo: 'Taladro',
          ingresos: 80.05,
          tasaOcupacion: null,
          calificacionPromedio: null,
          totalResenas: 0,
        },
      ],
    });
  });

  it('conserva una tasa de 0 y no la confunde con "Sin días disponibles"', () => {
    const [fila] = armarResumen(
      [ingreso('b1', 'Proyector')],
      [ocupacion('b1', 0)],
      [calificacion('b1', null, 0)],
    ).bienes;

    expect(fila.tasaOcupacion).toBe(0);
    expect(fila.ingresos).toBe(0);
  });

  it('un bien que falta en la ocupación o en las calificaciones queda sin esos datos', () => {
    const [fila] = armarResumen([ingreso('b1', 'Carpa', 10)], [], []).bienes;

    expect(fila).toEqual({
      bienId: 'b1',
      titulo: 'Carpa',
      ingresos: 10,
      tasaOcupacion: null,
      calificacionPromedio: null,
      totalResenas: 0,
    });
  });

  it('ignora lo que llega de un bien que no está en los ingresos', () => {
    const resumen = armarResumen(
      [ingreso('b1', 'Carpa')],
      [ocupacion('b1', 10), ocupacion('ajeno', 90)],
      [calificacion('ajeno', 5, 1)],
    );

    expect(resumen.totalBienes).toBe(1);
    expect(resumen.bienes.map((fila) => fila.bienId)).toEqual(['b1']);
  });

  it('ordena por título de la A a la Z, sin importar el ingreso', () => {
    expect(
      titulos([
        ingreso('1', 'Taladro industrial', 500),
        ingreso('2', 'Mesa de sonido', 0),
        ingreso('3', 'Proyector 4K', 100),
      ]),
    ).toEqual(['Mesa de sonido', 'Proyector 4K', 'Taladro industrial']);
  });

  it('compara en español: sin distinguir mayúsculas ni tildes, y la ñ después de la n', () => {
    expect(
      titulos([
        ingreso('1', 'ñandú'),
        ingreso('2', 'Árbol'),
        ingreso('3', 'nube'),
        ingreso('4', 'avión'),
        ingreso('5', 'Oso'),
      ]),
    ).toEqual(['Árbol', 'avión', 'nube', 'ñandú', 'Oso']);
  });

  it('a igual título, desempata por id para que el orden sea estable', () => {
    const resumen = armarResumen(
      [ingreso('b2', 'Casa'), ingreso('b1', 'casa')],
      [],
      [],
    );

    expect(resumen.bienes.map((fila) => fila.bienId)).toEqual(['b1', 'b2']);
  });

  it('sin bienes devuelve una lista vacía', () => {
    expect(armarResumen([], [], [])).toEqual({ totalBienes: 0, bienes: [] });
  });
});
