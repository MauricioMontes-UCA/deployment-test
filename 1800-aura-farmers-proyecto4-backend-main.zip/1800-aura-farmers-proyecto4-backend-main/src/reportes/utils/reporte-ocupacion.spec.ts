import { armarOcupacion, type IntervaloDeBien } from './reporte-ocupacion.js';

const d = (dia: string) => new Date(`${dia}T00:00:00.000Z`);
const intervalo = (
  bienId: string,
  inicio: string,
  fin: string,
): IntervaloDeBien => ({ bienId, inicio: d(inicio), fin: d(fin) });

// Periodo de 30 días: del 1 al 30 de noviembre.
const PERIODO = { desde: '2026-11-01', hasta: '2026-11-30' };

const resumen = (filas: ReturnType<typeof armarOcupacion>) =>
  filas.map((f) => [
    f.titulo,
    f.diasDisponibles,
    f.diasOcupados,
    f.tasaOcupacion,
  ]);

describe('armarOcupacion', () => {
  it('reproduce el escenario del seed: 100.0, 50.0, 0.0 y null, en ese orden', () => {
    const bienes = [
      { id: '1', titulo: 'Salón de eventos' },
      { id: '2', titulo: 'Taladro industrial' },
      { id: '3', titulo: 'Proyector 4K' },
      { id: '4', titulo: 'Mesa de sonido' },
    ];
    const reservas = [
      intervalo('1', '2026-11-03', '2026-11-07'), // 5 días
      intervalo('1', '2026-11-13', '2026-11-17'), // 5 días
      intervalo('4', '2026-11-01', '2026-11-18'),
      intervalo('4', '2026-11-19', '2026-11-30'),
    ];
    const bloqueos = [
      intervalo('1', '2026-11-21', '2026-11-30'), // 10 días bloqueados
      intervalo('2', '2026-11-01', '2026-11-30'), // todo el periodo
    ];

    expect(
      resumen(armarOcupacion(bienes, PERIODO, reservas, bloqueos)),
    ).toEqual([
      ['Mesa de sonido', 30, 30, 100],
      ['Salón de eventos', 20, 10, 50],
      ['Proyector 4K', 30, 0, 0],
      ['Taladro industrial', 0, 0, null],
    ]);
  });

  it('incluye los bienes sin reservas ni bloqueos con tasa 0.0', () => {
    const filas = armarOcupacion(
      [{ id: 'a', titulo: 'Casa' }],
      PERIODO,
      [],
      [],
    );
    expect(filas).toEqual([
      {
        bienId: 'a',
        titulo: 'Casa',
        diasDisponibles: 30,
        diasOcupados: 0,
        tasaOcupacion: 0,
      },
    ]);
  });

  it('ignora intervalos de bienes que no están en la lista', () => {
    const filas = armarOcupacion(
      [{ id: 'a', titulo: 'Casa' }],
      PERIODO,
      [intervalo('ajeno', '2026-11-01', '2026-11-30')],
      [intervalo('ajeno', '2026-11-01', '2026-11-30')],
    );
    expect(resumen(filas)).toEqual([['Casa', 30, 0, 0]]);
  });

  it('a igual tasa ordena por título en español y desempata por id', () => {
    const bienes = [
      { id: 'b', titulo: 'Ñandú' },
      { id: 'c', titulo: 'zapato' },
      { id: 'a', titulo: 'Ábaco' },
      { id: 'e', titulo: 'Nube' },
      { id: 'd', titulo: 'Nube' },
    ];
    const filas = armarOcupacion(bienes, PERIODO, [], []);
    expect(filas.map((f) => `${f.titulo}:${f.bienId}`)).toEqual([
      'Ábaco:a',
      'Nube:d',
      'Nube:e',
      'Ñandú:b',
      'zapato:c',
    ]);
  });

  it('los bienes sin días disponibles van al final, también ordenados por título', () => {
    const bienes = [
      { id: '1', titulo: 'Zeta' },
      { id: '2', titulo: 'Alfa' },
      { id: '3', titulo: 'Media' },
    ];
    const bloqueos = [
      intervalo('1', '2026-11-01', '2026-11-30'),
      intervalo('2', '2026-11-01', '2026-11-30'),
    ];
    const filas = armarOcupacion(bienes, PERIODO, [], bloqueos);
    expect(resumen(filas)).toEqual([
      ['Media', 30, 0, 0],
      ['Alfa', 0, 0, null],
      ['Zeta', 0, 0, null],
    ]);
  });

  it('sin bienes devuelve una lista vacía', () => {
    expect(armarOcupacion([], PERIODO, [], [])).toEqual([]);
  });
});
