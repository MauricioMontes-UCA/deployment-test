import { BadRequestException } from '@nestjs/common';
import { formatDia, parseDia } from '@Bienes/utils';

/** Periodos que el arrendador puede elegir en los reportes. */
export const PeriodoReporte = {
  ULTIMO_MES: 'ULTIMO_MES',
  ULTIMOS_3_MESES: 'ULTIMOS_3_MESES',
  ULTIMO_ANIO: 'ULTIMO_ANIO',
  RANGO: 'RANGO',
} as const;
export type PeriodoReporte =
  (typeof PeriodoReporte)[keyof typeof PeriodoReporte];

/** Periodo por defecto cuando la petición no trae `periodo`. */
export const PERIODO_POR_DEFECTO: PeriodoReporte = PeriodoReporte.ULTIMO_MES;

/** Un rango propio no puede abarcar más de esto, contando el primer y el último día. */
export const MAXIMO_DIAS_RANGO = 365;

/**
 * Cuántos días, contando hoy, cubre cada periodo fijo. "Último mes" son 30
 * días (de hoy-29 a hoy), no un mes de calendario.
 */
const DIAS_POR_PERIODO = {
  [PeriodoReporte.ULTIMO_MES]: 30,
  [PeriodoReporte.ULTIMOS_3_MESES]: 90,
  [PeriodoReporte.ULTIMO_ANIO]: 365,
} as const;

const MS_POR_DIA = 24 * 60 * 60 * 1000;

export const MENSAJES_PERIODO = {
  RANGO_INCOMPLETO: 'Completa las fechas del rango.',
  FORMATO: 'Usa el formato AAAA-MM-DD.',
  FECHAS_INVERTIDAS: 'La fecha final no puede ser anterior a la inicial.',
  RANGO_MUY_LARGO: 'El rango no puede ser mayor a 365 días.',
} as const;

/** Lo que `resolverPeriodo` necesita de la petición. */
export interface SolicitudPeriodo {
  periodo?: PeriodoReporte;
  desde?: string;
  hasta?: string;
}

/** Periodo ya resuelto: días calendario inclusivos, como `AAAA-MM-DD`. */
export interface PeriodoResuelto {
  desde: string;
  hasta: string;
}

/**
 * Convierte el periodo pedido en un rango de fechas.
 *
 * `hoy` es el día de calendario de El Salvador a medianoche UTC (`hoyEn`), y se
 * recibe de fuera para poder probar cada periodo con una fecha fija. Con un
 * periodo distinto de RANGO, `desde` y `hasta` se ignoran aunque vengan mal
 * escritos.
 *
 * @throws {BadRequestException} con RANGO: falta una fecha, no tiene el formato
 * AAAA-MM-DD o no existe en el calendario, `hasta` es anterior a `desde`, o el
 * rango pasa de 365 días. El mensaje va en `message`, tal cual está en la
 * especificación.
 */
export function resolverPeriodo(
  { periodo = PERIODO_POR_DEFECTO, desde, hasta }: SolicitudPeriodo,
  hoy: Date,
): PeriodoResuelto {
  if (periodo !== PeriodoReporte.RANGO) {
    const dias = DIAS_POR_PERIODO[periodo];
    return {
      desde: formatDia(new Date(hoy.getTime() - (dias - 1) * MS_POR_DIA)),
      hasta: formatDia(hoy),
    };
  }

  // Una cadena vacía cuenta como ausente: `?desde=` no trae fecha.
  if (!desde || !hasta) {
    throw new BadRequestException(MENSAJES_PERIODO.RANGO_INCOMPLETO);
  }
  const inicio = parseDia(desde);
  const fin = parseDia(hasta);
  if (!inicio || !fin) {
    throw new BadRequestException(MENSAJES_PERIODO.FORMATO);
  }
  if (fin < inicio) {
    throw new BadRequestException(MENSAJES_PERIODO.FECHAS_INVERTIDAS);
  }
  // Inclusivo: del día 1 al 365 son 365 días; del 1 al 366, 366.
  const dias = Math.round((fin.getTime() - inicio.getTime()) / MS_POR_DIA) + 1;
  if (dias > MAXIMO_DIAS_RANGO) {
    throw new BadRequestException(MENSAJES_PERIODO.RANGO_MUY_LARGO);
  }
  return { desde, hasta };
}
