/** Moneda de todos los importes del reporte. */
export const MONEDA_REPORTE = 'USD';

/** Bien mínimo que usan los reportes. */
export interface BienDeReporte {
  id: string;
  titulo: string;
}

/**
 * Lo que la base devuelve por bien, en centavos enteros.
 *
 * Se trabaja en centavos para que sumar y comparar no arrastre errores de
 * coma flotante (0.1 + 0.2): solo se divide entre 100 al armar la respuesta.
 */
export interface CentavosDeBien {
  bienId: string;
  ingresosCentavos: number;
  depositoRetenidoCentavos: number;
}

/** Ingresos de un bien en el periodo, con los montos en dólares y dos decimales. */
export interface IngresoDeBien {
  bienId: string;
  titulo: string;
  ingresos: number;
  depositoRetenido: number;
}

export interface ResumenIngresos {
  totalIngresos: number;
  totalDepositoRetenido: number;
  totalBienes: number;
  bienes: IngresoDeBien[];
}

/** Centavos a dólares con dos decimales exactos (25025 -> 250.25). */
export function centavosADolares(centavos: number): number {
  return Math.round(centavos) / 100;
}

/**
 * Arma el reporte de ingresos a partir de los bienes del arrendador y de lo que
 * sumó la base.
 *
 * - Incluye todos los bienes recibidos, también los que no tienen movimientos
 *   (en 0.00). Lo que la base devuelva de un bien que no está en la lista se
 *   ignora.
 * - Ordena por ingresos de mayor a menor y, a igual ingreso, por título de la A
 *   a la Z comparando en español; el id desempata para que el orden sea estable.
 * - Los totales son la suma de los bienes devueltos.
 */
export function calcularIngresos(
  bienes: BienDeReporte[],
  montos: CentavosDeBien[],
): ResumenIngresos {
  const porBien = new Map(montos.map((monto) => [monto.bienId, monto]));

  const filas = bienes.map(({ id, titulo }) => ({
    bienId: id,
    titulo,
    ingresosCentavos: porBien.get(id)?.ingresosCentavos ?? 0,
    retenidoCentavos: porBien.get(id)?.depositoRetenidoCentavos ?? 0,
  }));

  filas.sort(
    (a, b) =>
      b.ingresosCentavos - a.ingresosCentavos ||
      a.titulo.localeCompare(b.titulo, 'es') ||
      a.bienId.localeCompare(b.bienId),
  );

  const totalIngresos = filas.reduce((s, fila) => s + fila.ingresosCentavos, 0);
  const totalRetenido = filas.reduce((s, fila) => s + fila.retenidoCentavos, 0);

  return {
    totalIngresos: centavosADolares(totalIngresos),
    totalDepositoRetenido: centavosADolares(totalRetenido),
    totalBienes: filas.length,
    bienes: filas.map((fila) => ({
      bienId: fila.bienId,
      titulo: fila.titulo,
      ingresos: centavosADolares(fila.ingresosCentavos),
      depositoRetenido: centavosADolares(fila.retenidoCentavos),
    })),
  };
}
