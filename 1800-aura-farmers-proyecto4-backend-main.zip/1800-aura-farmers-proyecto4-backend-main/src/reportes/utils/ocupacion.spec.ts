import { calcularOcupacion, type Intervalo } from './ocupacion.js';

const dia = (n: number) => new Date(Date.UTC(2026, 10, n));
const rango = (inicio: number, fin: number): Intervalo => ({
  inicio: dia(inicio),
  fin: dia(fin),
});
/** Periodo del 1 al 20 de noviembre: 20 días. */
const PERIODO = { desde: dia(1), hasta: dia(20) };

describe('calcularOcupacion', () => {
  describe('sin reservas ni bloqueos', () => {
    it('todo el periodo está disponible y la tasa es 0', () => {
      expect(calcularOcupacion(PERIODO, [], [])).toEqual({
        diasPeriodo: 20,
        diasBloqueados: 0,
        diasDisponibles: 20,
        diasOcupados: 0,
        tasa: 0,
      });
    });
  });

  describe('tasa', () => {
    it('10 días ocupados de 20 disponibles da 50.0', () => {
      const r = calcularOcupacion(PERIODO, [rango(1, 10)], []);

      expect(r).toMatchObject({
        diasDisponibles: 20,
        diasOcupados: 10,
        tasa: 50,
      });
    });

    it('descuenta los bloqueos del denominador', () => {
      // 20 días, 10 bloqueados: 10 disponibles; 5 ocupados => 50 %.
      const r = calcularOcupacion(PERIODO, [rango(1, 5)], [rango(11, 20)]);

      expect(r).toMatchObject({
        diasBloqueados: 10,
        diasDisponibles: 10,
        diasOcupados: 5,
        tasa: 50,
      });
    });

    it('redondea a un decimal', () => {
      // 1 de 3 días = 33.333… => 33.3
      const r = calcularOcupacion(
        { desde: dia(1), hasta: dia(3) },
        [rango(1, 1)],
        [],
      );
      expect(r.tasa).toBe(33.3);

      // 2 de 3 días = 66.666… => 66.7
      expect(
        calcularOcupacion({ desde: dia(1), hasta: dia(3) }, [rango(1, 2)], [])
          .tasa,
      ).toBe(66.7);
    });

    it('con todos los días ocupados la tasa es 100 y nunca más', () => {
      const r = calcularOcupacion(PERIODO, [rango(1, 20)], []);

      expect(r.tasa).toBe(100);
    });

    it('nunca pasa de 100 aunque haya más reservas que días', () => {
      const r = calcularOcupacion(
        PERIODO,
        [rango(1, 20), rango(1, 20), rango(5, 30), rango(-10, 40)],
        [],
      );

      expect(r.diasOcupados).toBe(20);
      expect(r.tasa).toBe(100);
    });

    it('redondea con aritmética exacta: 23 de 80 días es 28.8, no 28.7', () => {
      // (23 / 80) * 100 * 10 da 287.4999… en coma flotante.
      const periodo = { desde: dia(1), hasta: dia(80) };
      const r = calcularOcupacion(periodo, [rango(1, 23)], []);

      expect(r.tasa).toBe(28.8);
    });

    it.each([
      [41, 80, 51.3],
      [51, 80, 63.8],
      [46, 160, 28.8],
      [1, 8, 12.5],
      [1, 16, 6.3],
    ])(
      '%i de %i días disponibles da %d (mitades hacia arriba)',
      (ocupados, total, tasa) => {
        const periodo = { desde: dia(1), hasta: dia(total) };

        expect(calcularOcupacion(periodo, [rango(1, ocupados)], []).tasa).toBe(
          tasa,
        );
      },
    );

    it('199 de 200 días da 99.5', () => {
      const periodo = { desde: dia(1), hasta: dia(200) };
      const r = calcularOcupacion(periodo, [rango(1, 199)], []);

      expect(r.tasa).toBe(99.5);
    });

    it('1999 de 2000 días (99.95) sube a 100.0 al redondear y no pasa de ahí', () => {
      const periodo = { desde: dia(1), hasta: dia(2000) };
      const r = calcularOcupacion(periodo, [rango(1, 1999)], []);

      expect(r.tasa).toBe(100);
    });
  });

  describe('recorte al periodo', () => {
    it('una reserva que empieza antes de "desde" cuenta solo los días dentro', () => {
      const r = calcularOcupacion(PERIODO, [rango(-5, 4)], []);

      expect(r.diasOcupados).toBe(4);
    });

    it('una reserva que termina después de "hasta" cuenta solo los días dentro', () => {
      const r = calcularOcupacion(PERIODO, [rango(18, 40)], []);

      expect(r.diasOcupados).toBe(3);
    });

    it('una reserva que cubre todo el periodo y más cuenta el periodo completo', () => {
      const r = calcularOcupacion(PERIODO, [rango(-30, 60)], []);

      expect(r).toMatchObject({ diasOcupados: 20, tasa: 100 });
    });

    it('descarta las reservas y bloqueos que quedan fuera', () => {
      const r = calcularOcupacion(
        { desde: dia(10), hasta: dia(20) },
        [rango(1, 9), rango(21, 30)],
        [rango(1, 9), rango(21, 30)],
      );

      expect(r).toMatchObject({
        diasPeriodo: 11,
        diasBloqueados: 0,
        diasOcupados: 0,
        tasa: 0,
      });
    });

    it('un bloqueo que cruza el límite solo resta los días dentro del periodo', () => {
      const r = calcularOcupacion(PERIODO, [], [rango(-3, 2), rango(19, 25)]);

      expect(r).toMatchObject({ diasBloqueados: 4, diasDisponibles: 16 });
    });

    it('los extremos del periodo cuentan (rangos inclusivos)', () => {
      const r = calcularOcupacion(PERIODO, [rango(1, 1), rango(20, 20)], []);

      expect(r.diasOcupados).toBe(2);
    });
  });

  describe('solapes', () => {
    it('los bloqueos solapados cuentan cada día una vez', () => {
      const r = calcularOcupacion(PERIODO, [], [rango(1, 6), rango(4, 10)]);

      expect(r.diasBloqueados).toBe(10);
      expect(r.diasDisponibles).toBe(10);
    });

    it('un bloqueo dentro de otro no suma días', () => {
      const r = calcularOcupacion(PERIODO, [], [rango(1, 10), rango(3, 5)]);

      expect(r.diasBloqueados).toBe(10);
    });

    it('bloqueos contiguos suman sus días sin perder ni repetir ninguno', () => {
      const r = calcularOcupacion(PERIODO, [], [rango(1, 5), rango(6, 10)]);

      expect(r.diasBloqueados).toBe(10);
    });

    it('bloqueos separados por un día libre no lo bloquean', () => {
      const r = calcularOcupacion(PERIODO, [], [rango(1, 5), rango(7, 10)]);

      expect(r.diasBloqueados).toBe(9);
    });

    it('las reservas solapadas cuentan cada día una vez', () => {
      const r = calcularOcupacion(PERIODO, [rango(1, 6), rango(4, 10)], []);

      expect(r.diasOcupados).toBe(10);
      expect(r.tasa).toBe(50);
    });

    it('dos reservas idénticas cuentan una sola vez', () => {
      const r = calcularOcupacion(PERIODO, [rango(3, 7), rango(3, 7)], []);

      expect(r.diasOcupados).toBe(5);
    });
  });

  describe('reserva y bloqueo en el mismo día', () => {
    it('una reserva sobre un día bloqueado no cuenta como ocupado', () => {
      // Reserva del 1 al 10; bloqueo del 6 al 10 => ocupa 5 días (1 al 5).
      const r = calcularOcupacion(PERIODO, [rango(1, 10)], [rango(6, 10)]);

      expect(r).toMatchObject({
        diasBloqueados: 5,
        diasDisponibles: 15,
        diasOcupados: 5,
      });
      expect(r.tasa).toBe(33.3);
    });

    it('un bloqueo en medio de una reserva parte sus días en dos', () => {
      // Reserva 1-10, bloqueo 4-6 => ocupados 1-3 y 7-10 = 7 días.
      const r = calcularOcupacion(PERIODO, [rango(1, 10)], [rango(4, 6)]);

      expect(r.diasOcupados).toBe(7);
    });

    it('varios bloqueos sobre una misma reserva restan cada día una vez', () => {
      // Reserva 1-10; bloqueos 2-3, 3-5 y 9-12 => bloqueados 2-5 y 9-10 (días 2,3,4,5,9,10).
      const r = calcularOcupacion(
        PERIODO,
        [rango(1, 10)],
        [rango(2, 3), rango(3, 5), rango(9, 12)],
      );

      expect(r.diasOcupados).toBe(4);
    });

    it('una reserva totalmente dentro de un bloqueo no ocupa nada', () => {
      const r = calcularOcupacion(PERIODO, [rango(5, 8)], [rango(1, 10)]);

      expect(r).toMatchObject({
        diasOcupados: 0,
        diasDisponibles: 10,
        tasa: 0,
      });
    });

    it('dos reservas solapadas sobre un bloqueo no cuentan dos veces el resto', () => {
      // Reservas 1-8 y 5-12 => 1-12; bloqueo 6-7 => ocupados 10.
      const r = calcularOcupacion(
        PERIODO,
        [rango(1, 8), rango(5, 12)],
        [rango(6, 7)],
      );

      expect(r.diasOcupados).toBe(10);
    });
  });

  describe('periodo de 1 día', () => {
    const uno = { desde: dia(5), hasta: dia(5) };

    it('sin movimientos: 1 día disponible y tasa 0', () => {
      expect(calcularOcupacion(uno, [], [])).toEqual({
        diasPeriodo: 1,
        diasBloqueados: 0,
        diasDisponibles: 1,
        diasOcupados: 0,
        tasa: 0,
      });
    });

    it('con una reserva ese día: tasa 100', () => {
      const r = calcularOcupacion(uno, [rango(3, 9)], []);

      expect(r).toMatchObject({ diasOcupados: 1, tasa: 100 });
    });

    it('con un bloqueo ese día: sin disponibles y tasa null', () => {
      const r = calcularOcupacion(uno, [rango(5, 5)], [rango(5, 5)]);

      expect(r).toEqual({
        diasPeriodo: 1,
        diasBloqueados: 1,
        diasDisponibles: 0,
        diasOcupados: 0,
        tasa: null,
      });
    });
  });

  describe('periodo completo bloqueado', () => {
    it('devuelve 0 disponibles y tasa null, sin dividir entre cero', () => {
      const r = calcularOcupacion(PERIODO, [], [rango(1, 20)]);

      expect(r).toEqual({
        diasPeriodo: 20,
        diasBloqueados: 20,
        diasDisponibles: 0,
        diasOcupados: 0,
        tasa: null,
      });
    });

    it('queda bloqueado también con bloqueos que lo cubren por partes o de sobra', () => {
      const r = calcularOcupacion(
        PERIODO,
        [rango(1, 20)],
        [rango(-5, 7), rango(8, 14), rango(10, 40)],
      );

      expect(r).toMatchObject({
        diasBloqueados: 20,
        diasDisponibles: 0,
        diasOcupados: 0,
        tasa: null,
      });
    });
  });

  describe('fechas', () => {
    it('solo cuenta el día: la hora dentro del día no cambia el resultado', () => {
      const r = calcularOcupacion(
        {
          desde: new Date('2026-11-01T00:00:00.000Z'),
          hasta: new Date('2026-11-20T00:00:00.000Z'),
        },
        [
          {
            inicio: new Date('2026-11-01T06:00:00.000Z'),
            fin: new Date('2026-11-10T23:59:59.000Z'),
          },
        ],
        [],
      );

      expect(r.diasOcupados).toBe(10);
    });

    it('cruza el fin de mes y de año sin perder días', () => {
      const r = calcularOcupacion(
        {
          desde: new Date('2026-12-28T00:00:00.000Z'),
          hasta: new Date('2027-01-03T00:00:00.000Z'),
        },
        [
          {
            inicio: new Date('2026-12-30T00:00:00.000Z'),
            fin: new Date('2027-01-02T00:00:00.000Z'),
          },
        ],
        [],
      );

      expect(r).toMatchObject({ diasPeriodo: 7, diasOcupados: 4 });
    });

    it('febrero de un año bisiesto tiene 29 días', () => {
      const r = calcularOcupacion(
        {
          desde: new Date('2028-02-01T00:00:00.000Z'),
          hasta: new Date('2028-02-29T00:00:00.000Z'),
        },
        [],
        [],
      );

      expect(r.diasPeriodo).toBe(29);
    });
  });

  describe('entradas', () => {
    it('no depende del orden de los intervalos', () => {
      const reservas = [rango(12, 15), rango(1, 4), rango(3, 8)];
      const bloqueos = [rango(10, 11), rango(2, 2)];

      const a = calcularOcupacion(PERIODO, reservas, bloqueos);
      const b = calcularOcupacion(
        PERIODO,
        [...reservas].reverse(),
        [...bloqueos].reverse(),
      );

      expect(b).toEqual(a);
    });

    it('no modifica las listas recibidas', () => {
      const reservas = [rango(12, 15), rango(1, 4)];
      const bloqueos = [rango(10, 11), rango(2, 2)];
      const copiaReservas = reservas.map((x) => ({ ...x }));
      const copiaBloqueos = bloqueos.map((x) => ({ ...x }));

      calcularOcupacion(PERIODO, reservas, bloqueos);

      expect(reservas).toEqual(copiaReservas);
      expect(bloqueos).toEqual(copiaBloqueos);
    });

    it('rechaza un periodo con "hasta" anterior a "desde"', () => {
      expect(() =>
        calcularOcupacion({ desde: dia(10), hasta: dia(9) }, [], []),
      ).toThrow('Periodo inválido');
    });

    it('rechaza una reserva con el fin antes del inicio', () => {
      expect(() => calcularOcupacion(PERIODO, [rango(9, 3)], [])).toThrow(
        'Intervalo de reserva inválido',
      );
    });

    it('rechaza un bloqueo con el fin antes del inicio', () => {
      expect(() => calcularOcupacion(PERIODO, [], [rango(9, 3)])).toThrow(
        'Intervalo de bloqueo inválido',
      );
    });

    it('rechaza una fecha no válida en el periodo con un mensaje que lo dice', () => {
      expect(() =>
        calcularOcupacion({ desde: new Date('x'), hasta: dia(9) }, [], []),
      ).toThrow('Periodo inválido: fecha no válida.');
    });

    it('rechaza una fecha no válida en una reserva o un bloqueo, sin hablar de orden', () => {
      const mala = { inicio: new Date('x'), fin: dia(3) };

      expect(() => calcularOcupacion(PERIODO, [mala], [])).toThrow(
        'Intervalo de reserva inválido: fecha no válida.',
      );
      expect(() => calcularOcupacion(PERIODO, [], [mala])).toThrow(
        'Intervalo de bloqueo inválido: fecha no válida.',
      );
    });
  });
});
