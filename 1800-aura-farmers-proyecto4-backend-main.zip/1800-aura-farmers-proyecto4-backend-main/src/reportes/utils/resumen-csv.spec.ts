import {
  ENCABEZADO_RESUMEN_CSV,
  escaparCampoCsv,
  generarResumenCsv,
  nombreArchivoResumen,
  protegerFormula,
  SIN_CALIFICACIONES,
  SIN_DIAS_DISPONIBLES,
  TIPO_CONTENIDO_CSV,
} from './resumen-csv.js';
import type { FilaResumen } from './resumen.js';

const ENCABEZADO =
  'Bien,Ingresos (USD),Tasa de ocupación (%),Calificación promedio,Reseñas';

const fila = (cambios: Partial<FilaResumen> = {}): FilaResumen => ({
  bienId: 'b1',
  titulo: 'Salón de eventos',
  ingresos: 250,
  tasaOcupacion: 50,
  calificacionPromedio: 4.5,
  totalResenas: 2,
  ...cambios,
});

/** Las líneas del CSV, sin el BOM y sin el CRLF final. */
const lineas = (csv: string) => csv.slice(1).split('\r\n').slice(0, -1);

/** La fila de datos de un único bien. */
const filaCsv = (cambios: Partial<FilaResumen>) =>
  lineas(generarResumenCsv([fila(cambios)]))[1];

describe('generarResumenCsv', () => {
  it('empieza con el BOM de UTF-8 (bytes EF BB BF)', () => {
    const bytes = Buffer.from(generarResumenCsv([fila()]), 'utf8');

    expect([...bytes.subarray(0, 3)]).toEqual([0xef, 0xbb, 0xbf]);
  });

  it('la primera línea es el encabezado exacto', () => {
    expect(ENCABEZADO_RESUMEN_CSV.join(',')).toBe(ENCABEZADO);
    expect(lineas(generarResumenCsv([fila()]))[0]).toBe(ENCABEZADO);
  });

  it('arma la fila del ejemplo de Jira, separada por comas', () => {
    expect(filaCsv({})).toBe('Salón de eventos,250.00,50.0,4.5,2');
    expect(filaCsv({}).split(',')).toHaveLength(5);
  });

  it('termina cada línea en CRLF, también la última, sin líneas en blanco', () => {
    const csv = generarResumenCsv([fila(), fila({ titulo: 'Proyector 4K' })]);

    expect(csv).toBe(
      '\uFEFF' +
        `${ENCABEZADO}\r\n` +
        'Salón de eventos,250.00,50.0,4.5,2\r\n' +
        'Proyector 4K,250.00,50.0,4.5,2\r\n',
    );
    expect(csv.endsWith('\r\n')).toBe(true);
    expect(csv).not.toMatch(/\r\n\r\n/);
    // Ningún \n suelto: todos los saltos son CRLF.
    expect(csv.replaceAll('\r\n', '')).not.toMatch(/[\r\n]/);
  });

  it.each([
    [250, '250.00'],
    [60.5, '60.50'],
    [1234.56, '1234.56'],
    [0.1, '0.10'],
  ])('ingresos %s se escriben con dos decimales: %s', (ingresos, texto) => {
    expect(filaCsv({ ingresos }).split(',')[1]).toBe(texto);
  });

  it.each([
    [50, 4.5, '50.0', '4.5'],
    [33.3, 3, '33.3', '3.0'],
    [100, 5, '100.0', '5.0'],
    [1.5, 1, '1.5', '1.0'],
  ])(
    'tasa %s y promedio %s van con un decimal y punto: %s y %s',
    (tasaOcupacion, calificacionPromedio, tasa, promedio) => {
      const campos = filaCsv({ tasaOcupacion, calificacionPromedio }).split(
        ',',
      );
      expect([campos[2], campos[3]]).toEqual([tasa, promedio]);
    },
  );

  it('escribe los ceros con sus decimales', () => {
    expect(
      filaCsv({
        titulo: 'Proyector 4K',
        ingresos: 0,
        tasaOcupacion: 0,
        calificacionPromedio: null,
        totalResenas: 0,
      }),
    ).toBe(`Proyector 4K,0.00,0.0,${SIN_CALIFICACIONES},0`);
  });

  it('una tasa null se escribe "Sin días disponibles"', () => {
    expect(SIN_DIAS_DISPONIBLES).toBe('Sin días disponibles');
    expect(filaCsv({ tasaOcupacion: null }).split(',')[2]).toBe(
      'Sin días disponibles',
    );
  });

  it('un promedio null se escribe "Sin calificaciones"', () => {
    expect(SIN_CALIFICACIONES).toBe('Sin calificaciones');
    expect(filaCsv({ calificacionPromedio: null }).split(',')[3]).toBe(
      'Sin calificaciones',
    );
  });

  it('el caso límite de Jira: sin pagos, sin días y sin reseñas', () => {
    expect(
      filaCsv({
        titulo: 'Taladro industrial',
        ingresos: 0,
        tasaOcupacion: null,
        calificacionPromedio: null,
        totalResenas: 0,
      }),
    ).toBe('Taladro industrial,0.00,Sin días disponibles,Sin calificaciones,0');
  });

  it('un título con comas va entre comillas y conserva 5 columnas', () => {
    expect(filaCsv({ titulo: 'Casa, jardín y piscina' })).toBe(
      '"Casa, jardín y piscina",250.00,50.0,4.5,2',
    );
  });

  it('un título con comillas va entre comillas, con las internas duplicadas', () => {
    expect(filaCsv({ titulo: 'Salón "El Roble"' })).toBe(
      '"Salón ""El Roble""",250.00,50.0,4.5,2',
    );
  });

  it.each([
    ['salto de línea', 'Casa\ncon patio', '"Casa\ncon patio"'],
    ['retorno de carro', 'Casa\rcon patio', '"Casa\rcon patio"'],
    ['CRLF', 'Casa\r\ncon patio', '"Casa\r\ncon patio"'],
  ])('un título con %s va entre comillas', (_caso, titulo, escrito) => {
    const csv = generarResumenCsv([fila({ titulo })]);

    expect(csv).toBe(`\uFEFF${ENCABEZADO}\r\n${escrito},250.00,50.0,4.5,2\r\n`);
  });

  it.each([
    ['=SUMA(1+1)', "'=SUMA(1+1)"],
    ['+123', "'+123"],
    ['-10', "'-10"],
    ['@usuario', "'@usuario"],
  ])(
    'un título que empieza con fórmula se protege: %s → %s',
    (titulo, escrito) => {
      expect(filaCsv({ titulo })).toBe(`${escrito},250.00,50.0,4.5,2`);
    },
  );

  it('protege antes de escapar: con comas o comillas, la comilla simple queda dentro', () => {
    expect(filaCsv({ titulo: '=HIPERVINCULO("x","y")' })).toBe(
      `"'=HIPERVINCULO(""x"",""y"")",250.00,50.0,4.5,2`,
    );
    expect(filaCsv({ titulo: '-5, oferta' })).toBe(
      `"'-5, oferta",250.00,50.0,4.5,2`,
    );
  });

  it.each(['Taladro-percutor', 'Casa 2-B', 'Equipo a=b', 'Correo x@y'])(
    'un carácter de fórmula en medio del título no lo cambia: %s',
    (titulo) => {
      expect(filaCsv({ titulo }).split(',')[0]).toBe(titulo);
    },
  );

  it('conserva tildes y eñes en UTF-8', () => {
    const csv = generarResumenCsv([fila({ titulo: 'Cañón de sonido Ñandú' })]);
    const bytes = Buffer.from(csv, 'utf8');

    expect(bytes.toString('utf8')).toBe(csv);
    expect(lineas(csv)[1]).toBe('Cañón de sonido Ñandú,250.00,50.0,4.5,2');
    expect(lineas(csv)[0]).toContain('ocupación');
    expect(lineas(csv)[0]).toContain('Reseñas');
  });

  it('sin bienes produce solo el BOM y el encabezado con su CRLF', () => {
    expect(generarResumenCsv([])).toBe(`\uFEFF${ENCABEZADO}\r\n`);
  });

  it('respeta el orden recibido: no ordena ni filtra', () => {
    const bienes = [
      fila({ bienId: 'z', titulo: 'Zeta' }),
      fila({ bienId: 'a', titulo: 'Alfa' }),
      fila({ bienId: 'm', titulo: 'Mesa', ingresos: 0 }),
    ];

    expect(
      lineas(generarResumenCsv(bienes))
        .slice(1)
        .map((l) => l.split(',')[0]),
    ).toEqual(['Zeta', 'Alfa', 'Mesa']);
  });

  it('no modifica las filas recibidas', () => {
    const bienes = [
      fila({ titulo: '=SUMA(1+1)' }),
      fila({ titulo: 'Casa, "grande"', tasaOcupacion: null }),
    ];
    const copia = structuredClone(bienes);

    generarResumenCsv(Object.freeze(bienes.map((b) => Object.freeze(b))));

    expect(bienes).toEqual(copia);
  });
});

describe('protegerFormula y escaparCampoCsv', () => {
  it('protegerFormula solo mira el primer carácter', () => {
    expect(protegerFormula('=1')).toBe("'=1");
    expect(protegerFormula(' =1')).toBe(' =1');
    expect(protegerFormula('')).toBe('');
  });

  it('escaparCampoCsv deja intacto un campo sin caracteres especiales', () => {
    expect(escaparCampoCsv('Salón de eventos')).toBe('Salón de eventos');
    expect(escaparCampoCsv("'=SUMA(1+1)")).toBe("'=SUMA(1+1)");
  });
});

/**
 * Lector CSV mínimo para las pruebas: respeta los campos entre comillas (con
 * comillas duplicadas, comas, CR o LF dentro) y separa los registros solo por
 * el CRLF que queda fuera de comillas. Recibe el CSV sin el BOM.
 */
function leerCsv(contenido: string): string[][] {
  const registros: string[][] = [];
  let campos: string[] = [];
  let campo = '';
  let entreComillas = false;
  for (let i = 0; i < contenido.length; i++) {
    const c = contenido[i];
    if (entreComillas) {
      if (c === '"' && contenido[i + 1] === '"') {
        campo += '"';
        i++;
      } else if (c === '"') {
        entreComillas = false;
      } else {
        campo += c;
      }
    } else if (c === '"') {
      entreComillas = true;
    } else if (c === ',') {
      campos.push(campo);
      campo = '';
    } else if (c === '\r' && contenido[i + 1] === '\n') {
      campos.push(campo);
      registros.push(campos);
      campos = [];
      campo = '';
      i++;
    } else {
      campo += c;
    }
  }
  if (campo !== '' || campos.length > 0) registros.push([...campos, campo]);
  return registros;
}

/** Los registros de datos (sin el encabezado) de un CSV de varias filas. */
const registros = (titulos: string[]) =>
  leerCsv(
    generarResumenCsv(titulos.map((titulo) => fila({ titulo }))).slice(1),
  ).slice(1);

describe('protección contra fórmulas: tabulador y retorno de carro (OWASP)', () => {
  it.each([
    ['tabulador', '\tSUMA(1+1)', "'\tSUMA(1+1)"],
    ['tabulador antes de un =', '\t=SUMA(1+1)', "'\t=SUMA(1+1)"],
    ['retorno de carro', '\rSUMA(1+1)', "'\rSUMA(1+1)"],
    ['retorno de carro antes de un =', '\r=SUMA(1+1)', "'\r=SUMA(1+1)"],
  ])(
    'un título que empieza con %s lleva la comilla simple',
    (_caso, titulo, protegido) => {
      expect(protegerFormula(titulo)).toBe(protegido);
      expect(registros([titulo])).toEqual([
        [protegido, '250.00', '50.0', '4.5', '2'],
      ]);
    },
  );

  it('con tabulador inicial no hacen falta comillas: el separador es la coma', () => {
    const csv = generarResumenCsv([fila({ titulo: '\tSUMA' })]);

    expect(csv).toContain(`\r\n'\tSUMA,250.00,50.0,4.5,2\r\n`);
  });

  it('con retorno de carro inicial, la comilla simple queda dentro de las comillas dobles', () => {
    const csv = generarResumenCsv([fila({ titulo: '\r=1' })]);

    expect(csv).toContain(`\r\n"'\r=1",250.00,50.0,4.5,2\r\n`);
  });

  it.each([
    ['tabulador', 'Casa\tcon patio', 'Casa\tcon patio'],
    ['retorno de carro', 'Casa\rcon patio', 'Casa\rcon patio'],
  ])(
    'un %s en medio del título no activa la protección',
    (_caso, titulo, leido) => {
      expect(protegerFormula(titulo)).toBe(titulo);
      expect(registros([titulo])).toEqual([
        [leido, '250.00', '50.0', '4.5', '2'],
      ]);
    },
  );

  it.each([
    ['solo un tabulador', '\t', "'\t"],
    ['solo un retorno de carro', '\r', "'\r"],
  ])('un título que es %s también se protege', (_caso, titulo, protegido) => {
    expect(protegerFormula(titulo)).toBe(protegido);
    expect(registros([titulo])).toEqual([
      [protegido, '250.00', '50.0', '4.5', '2'],
    ]);
  });

  it.each([
    ['=SUMA(1+1)', "'=SUMA(1+1)"],
    ['+123', "'+123"],
    ['-10', "'-10"],
    ['@usuario', "'@usuario"],
  ])('sigue protegiendo %s', (titulo, protegido) => {
    expect(protegerFormula(titulo)).toBe(protegido);
  });

  it('con títulos de todos los casos, cada registro conserva exactamente 5 columnas', () => {
    const titulos = [
      '\tSUMA',
      '\r=1',
      'Casa\rcon patio',
      'Casa\tcon patio',
      '=A,"B"',
      'Salón de eventos',
      '\t',
      '\r',
    ];

    const filas = registros(titulos);

    expect(filas).toHaveLength(titulos.length);
    for (const campos of filas) expect(campos).toHaveLength(5);
    // Los números no cambian por la protección del título.
    for (const campos of filas) {
      expect(campos.slice(1)).toEqual(['250.00', '50.0', '4.5', '2']);
    }
  });
});

describe('nombreArchivoResumen', () => {
  it('usa las fechas del periodo resuelto', () => {
    expect(
      nombreArchivoResumen({ desde: '2026-10-07', hasta: '2026-11-05' }),
    ).toBe('resumen-desempeno_2026-10-07_2026-11-05.csv');
  });

  it.each([
    ['2026-10-07"; x', '2026-11-05'],
    ['2026-02-30', '2026-03-01'],
    ['2026-10-07', '05/11/2026'],
  ])(
    'rechaza fechas que no son días AAAA-MM-DD reales (%s, %s)',
    (desde, hasta) => {
      expect(() => nombreArchivoResumen({ desde, hasta })).toThrow();
    },
  );

  it('el tipo de contenido es CSV en UTF-8', () => {
    expect(TIPO_CONTENIDO_CSV).toBe('text/csv; charset=utf-8');
  });
});
