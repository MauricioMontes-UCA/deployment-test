const MS_POR_DIA = 24 * 60 * 60 * 1000;

/** Rango de días de calendario. Ambos extremos están incluidos. */
export interface Intervalo {
  inicio: Date;
  fin: Date;
}

/** Periodo del reporte: de `desde` a `hasta`, ambos días incluidos. */
export interface PeriodoOcupacion {
  desde: Date;
  hasta: Date;
}

export interface ResultadoOcupacion {
  /** Días del periodo, contando `desde` y `hasta`. */
  diasPeriodo: number;
  /** Días del periodo cubiertos por algún bloqueo (cada día cuenta una vez). */
  diasBloqueados: number;
  /** `diasPeriodo - diasBloqueados`: los días en que el bien se podía alquilar. */
  diasDisponibles: number;
  /** Días disponibles cubiertos por alguna reserva (cada día cuenta una vez). */
  diasOcupados: number;
  /** Porcentaje de 0 a 100 con un decimal, o null si no hay días disponibles. */
  tasa: number | null;
}

/** Días enteros entre dos fechas a medianoche UTC. */
const aDia = (fecha: Date): number => Math.floor(fecha.getTime() / MS_POR_DIA);

/** Rango de días enteros, ambos extremos incluidos. */
type Rango = readonly [inicio: number, fin: number];

/** Recorta al periodo y descarta los que quedan fuera. */
function recortar(
  intervalos: Intervalo[],
  [desde, hasta]: Rango,
  nombre: string,
): Rango[] {
  const recortados: Rango[] = [];
  for (const { inicio, fin } of intervalos) {
    const i = aDia(inicio);
    const f = aDia(fin);
    if (Number.isNaN(i) || Number.isNaN(f)) {
      throw new Error(`Intervalo de ${nombre} inválido: fecha no válida.`);
    }
    if (f < i) {
      throw new Error(
        `Intervalo de ${nombre} inválido: el fin es anterior al inicio.`,
      );
    }
    const ini = Math.max(i, desde);
    const fi = Math.min(f, hasta);
    if (ini <= fi) recortados.push([ini, fi]);
  }
  return recortados;
}

/** Une los rangos que se solapan; los que solo son contiguos también se unen. */
function fusionar(rangos: Rango[]): Rango[] {
  const ordenados = [...rangos].sort((a, b) => a[0] - b[0]);
  const fusionados: [number, number][] = [];
  for (const [inicio, fin] of ordenados) {
    const ultimo = fusionados[fusionados.length - 1];
    if (ultimo && inicio <= ultimo[1] + 1) {
      ultimo[1] = Math.max(ultimo[1], fin);
    } else {
      fusionados.push([inicio, fin]);
    }
  }
  return fusionados;
}

const contar = (rangos: Rango[]): number =>
  rangos.reduce((total, [inicio, fin]) => total + (fin - inicio + 1), 0);

/** Días de `rangos` que NO caen dentro de `excluidos`. Ambas listas, fusionadas. */
function restar(rangos: Rango[], excluidos: Rango[]): Rango[] {
  const resultado: Rango[] = [];
  for (const [inicio, fin] of rangos) {
    let cursor = inicio;
    for (const [exIni, exFin] of excluidos) {
      if (exFin < cursor) continue;
      if (exIni > fin) break;
      if (exIni > cursor) resultado.push([cursor, exIni - 1]);
      cursor = Math.max(cursor, exFin + 1);
      if (cursor > fin) break;
    }
    if (cursor <= fin) resultado.push([cursor, fin]);
  }
  return resultado;
}

/**
 * Porcentaje con un decimal, calculado con enteros: `(a / b) * 100 * 10` arrastra
 * error de coma flotante (23/80 daría 28.7 en lugar de 28.8).
 */
const porcentaje1 = (parte: number, total: number): number =>
  Math.round((parte * 1000) / total) / 10;

/**
 * Calcula la ocupación de un bien en un periodo.
 *
 * Supuestos:
 * - Las fechas son días de calendario a medianoche UTC (como las columnas
 *   `@db.Date` que entrega Prisma). Solo cuenta el día, no la hora.
 * - Los extremos son inclusivos: un intervalo del 5 al 7 son 3 días, y un
 *   periodo de `desde` = `hasta` es 1 día.
 * - Cada intervalo se recorta al periodo; los que quedan fuera se descartan.
 * - Los bloqueos solapados cuentan cada día una vez. Los días bloqueados no
 *   están disponibles.
 * - Las reservas solapadas cuentan cada día una vez, y una reserva sobre un día
 *   bloqueado no cuenta como ocupado.
 * - `tasa` = ocupados / disponibles × 100, con un decimal y tope de 100. Sin
 *   días disponibles es `null` (no se divide entre cero).
 * - La función no conoce estados: quien llama entrega solo las reservas que
 *   cuentan (CONFIRMADA, EN_CURSO o FINALIZADA).
 *
 * @throws Error si el periodo o algún intervalo tiene una fecha no válida o el fin
 * antes del inicio.
 */
export function calcularOcupacion(
  periodo: PeriodoOcupacion,
  reservas: Intervalo[],
  bloqueos: Intervalo[],
): ResultadoOcupacion {
  const desde = aDia(periodo.desde);
  const hasta = aDia(periodo.hasta);
  if (Number.isNaN(desde) || Number.isNaN(hasta)) {
    throw new Error('Periodo inválido: fecha no válida.');
  }
  if (hasta < desde) {
    throw new Error('Periodo inválido: "hasta" es anterior a "desde".');
  }
  const rangoPeriodo: Rango = [desde, hasta];

  const bloqueados = fusionar(recortar(bloqueos, rangoPeriodo, 'bloqueo'));
  const ocupados = restar(
    fusionar(recortar(reservas, rangoPeriodo, 'reserva')),
    bloqueados,
  );

  const diasPeriodo = hasta - desde + 1;
  const diasBloqueados = contar(bloqueados);
  const diasDisponibles = diasPeriodo - diasBloqueados;
  const diasOcupados = contar(ocupados);
  const tasa =
    diasDisponibles === 0
      ? null
      : Math.min(100, porcentaje1(diasOcupados, diasDisponibles));

  return { diasPeriodo, diasBloqueados, diasDisponibles, diasOcupados, tasa };
}
