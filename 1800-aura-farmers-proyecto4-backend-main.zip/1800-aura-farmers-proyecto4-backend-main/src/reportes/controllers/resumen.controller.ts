import { Controller, Get, Header, Query, StreamableFile } from '@nestjs/common';
import {
  ApiBadRequestResponse,
  ApiBearerAuth,
  ApiForbiddenResponse,
  ApiOkResponse,
  ApiOperation,
  ApiProduces,
  ApiTags,
  ApiUnauthorizedResponse,
} from '@nestjs/swagger';
import { CurrentUser, Roles } from '@Auth/decorators';
import type { AuthenticatedUser } from '@Auth/types';
import { Rol } from '@PrismaClient';
import { ConsultaPeriodoDto, ResumenResponseDto } from '@Reportes/dto';
import { ResumenService } from '@Reportes/services';
import {
  generarResumenCsv,
  nombreArchivoResumen,
  TIPO_CONTENIDO_CSV,
} from '@Reportes/utils';

/**
 * Resumen comparativo de desempeño (H26). Solo para arrendadores y, como el
 * resto de los reportes, sin `arrendadorId` en la ruta: los datos son siempre
 * los de la sesión.
 */
@ApiTags('reportes')
@ApiBearerAuth()
@Roles(Rol.ARRENDADOR)
@Controller('reportes')
export class ResumenController {
  constructor(private readonly resumenService: ResumenService) {}

  @Get('resumen')
  @ApiOperation({
    summary: 'Resumen comparativo de ingresos, ocupación y calificación',
    description:
      'Una fila por bien ACTIVA del arrendador de la sesión, por título de la A a la Z, con los ingresos, la tasa de ocupación y la calificación promedio del mismo periodo. Cada valor sale del mismo servicio que su reporte individual (`/reportes/ingresos`, `/reportes/ocupacion` y `/reportes/calificaciones`), así que coinciden.',
  })
  @ApiOkResponse({ type: ResumenResponseDto })
  @ApiBadRequestResponse({
    description:
      'Con `periodo=RANGO`: "Completa las fechas del rango.", "Usa el formato AAAA-MM-DD.", "La fecha final no puede ser anterior a la inicial." o "El rango no puede ser mayor a 365 días."',
  })
  @ApiUnauthorizedResponse({
    description: 'Token ausente, inválido o expirado.',
  })
  @ApiForbiddenResponse({ description: 'El usuario no es ARRENDADOR.' })
  async resumen(
    @CurrentUser() usuario: AuthenticatedUser,
    @Query() consulta: ConsultaPeriodoDto,
  ): Promise<ResumenResponseDto> {
    return ResumenResponseDto.from(
      await this.resumenService.resumen(usuario.id, consulta),
    );
  }

  /**
   * El mismo resumen como archivo CSV (BE-26.2). Las filas, su orden y sus
   * valores son los de `GET /reportes/resumen` con el mismo periodo, porque
   * salen de la misma llamada a `ResumenService.resumen()`. El archivo se arma
   * en memoria; un 400, 401 o 403 se lanza antes y sale en JSON.
   *
   * `Cache-Control: no-store` evita que el navegador o un intermediario guarde
   * una copia del archivo, que trae los ingresos del arrendador.
   */
  @Get('resumen/exportar')
  @Header('Cache-Control', 'no-store')
  @ApiOperation({
    summary: 'Exporta el resumen comparativo a CSV',
    description:
      'Devuelve como archivo CSV las mismas filas, en el mismo orden y con los mismos valores que `GET /reportes/resumen` para el periodo elegido, solo de los bienes del arrendador de la sesión. Formato: UTF-8 con BOM, separador coma, CRLF al final de cada línea y punto decimal. Encabezado: `Bien,Ingresos (USD),Tasa de ocupación (%),Calificación promedio,Reseñas`. Los nulos se escriben "Sin días disponibles" y "Sin calificaciones". Un título que empieza con `=`, `+`, `-`, `@`, un tabulador o un retorno de carro lleva delante una comilla simple para que la hoja de cálculo no lo ejecute como fórmula. Sin bienes, el archivo tiene solo el encabezado. La respuesta lleva `Cache-Control: no-store` porque contiene ingresos. Los errores responden JSON.',
  })
  @ApiProduces('text/csv')
  @ApiOkResponse({
    description:
      'Archivo CSV (`text/csv; charset=utf-8`). Ejemplo de fila: `Salón de eventos,250.00,50.0,4.5,2`.',
    schema: { type: 'string', format: 'binary' },
    headers: {
      'Content-Disposition': {
        description:
          'Descarga con las fechas del periodo resuelto: `resumen-desempeno_AAAA-MM-DD_AAAA-MM-DD.csv`.',
        schema: {
          type: 'string',
          example:
            'attachment; filename="resumen-desempeno_2026-10-07_2026-11-05.csv"',
        },
      },
      'Cache-Control': {
        description:
          'No se guarda en caché: el archivo contiene ingresos del arrendador.',
        schema: { type: 'string', example: 'no-store' },
      },
    },
  })
  @ApiBadRequestResponse({
    description:
      'JSON. Un `periodo` fuera de la lista, un parámetro no permitido o, con `periodo=RANGO`: "Completa las fechas del rango.", "Usa el formato AAAA-MM-DD.", "La fecha final no puede ser anterior a la inicial." o "El rango no puede ser mayor a 365 días."',
  })
  @ApiUnauthorizedResponse({
    description: 'JSON. Token ausente, inválido o expirado.',
  })
  @ApiForbiddenResponse({ description: 'JSON. El usuario no es ARRENDADOR.' })
  async exportar(
    @CurrentUser() usuario: AuthenticatedUser,
    @Query() consulta: ConsultaPeriodoDto,
  ): Promise<StreamableFile> {
    const { periodo, bienes } = await this.resumenService.resumen(
      usuario.id,
      consulta,
    );
    const contenido = Buffer.from(generarResumenCsv(bienes), 'utf8');
    return new StreamableFile(contenido, {
      type: TIPO_CONTENIDO_CSV,
      disposition: `attachment; filename="${nombreArchivoResumen(periodo)}"`,
      length: contenido.length,
    });
  }
}
