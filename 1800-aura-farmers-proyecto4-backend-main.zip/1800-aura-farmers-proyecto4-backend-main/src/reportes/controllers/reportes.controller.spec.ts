import { ROLES_KEY } from '@Auth/decorators';
import type { AuthenticatedUser } from '@Auth/types';
import { Rol } from '@PrismaClient';
import { PeriodoReporte } from '@Reportes/utils';
import type {
  IngresosService,
  OcupacionService,
  ReportesService,
} from '@Reportes/services';
import { ReportesController } from './reportes.controller.js';

describe('ReportesController', () => {
  it('es solo para arrendadores: el rol está en toda la clase', () => {
    expect(Reflect.getMetadata(ROLES_KEY, ReportesController)).toEqual([
      Rol.ARRENDADOR,
    ]);
  });

  it('GET /reportes/periodo responde con el periodo y las fechas resueltas', () => {
    const resolverPeriodo = vi.fn().mockReturnValue({
      periodo: PeriodoReporte.ULTIMO_MES,
      desde: '2026-10-17',
      hasta: '2026-11-15',
    });
    const controller = new ReportesController(
      { resolverPeriodo } as unknown as ReportesService,
      {} as IngresosService,
      {} as OcupacionService,
    );
    const consulta = { periodo: PeriodoReporte.ULTIMO_MES };

    expect(controller.resolverPeriodo(consulta)).toEqual({
      periodo: 'ULTIMO_MES',
      desde: '2026-10-17',
      hasta: '2026-11-15',
    });
    expect(resolverPeriodo).toHaveBeenCalledWith(consulta);
  });

  it('GET /reportes/ingresos usa el arrendador de la sesión y arma la respuesta', async () => {
    const ingresos = vi.fn().mockResolvedValue({
      periodo: { desde: '2026-10-17', hasta: '2026-11-15' },
      totalIngresos: 250,
      totalDepositoRetenido: 50,
      totalBienes: 1,
      bienes: [
        {
          bienId: 'b1',
          titulo: 'Salón',
          ingresos: 250,
          depositoRetenido: 50,
        },
      ],
    });
    const controller = new ReportesController(
      {} as ReportesService,
      { ingresos } as unknown as IngresosService,
      {} as OcupacionService,
    );
    const consulta = { periodo: PeriodoReporte.ULTIMO_MES };

    const respuesta = await controller.ingresos(
      { id: 'arr-1' } as AuthenticatedUser,
      consulta,
    );

    expect(ingresos).toHaveBeenCalledWith('arr-1', consulta);
    expect(respuesta).toEqual({
      periodo: { desde: '2026-10-17', hasta: '2026-11-15' },
      moneda: 'USD',
      totalIngresos: 250,
      totalDepositoRetenido: 50,
      totalBienes: 1,
      bienes: [
        {
          bienId: 'b1',
          titulo: 'Salón',
          ingresos: 250,
          depositoRetenido: 50,
        },
      ],
    });
  });

  it('GET /reportes/ocupacion usa el arrendador de la sesión y arma la respuesta', async () => {
    const ocupacion = vi.fn().mockResolvedValue({
      periodo: { desde: '2026-10-17', hasta: '2026-11-15' },
      totalBienes: 1,
      bienes: [
        {
          bienId: 'b1',
          titulo: 'Salón',
          diasDisponibles: 20,
          diasOcupados: 10,
          tasaOcupacion: 50,
        },
      ],
    });
    const controller = new ReportesController(
      {} as ReportesService,
      {} as IngresosService,
      { ocupacion } as unknown as OcupacionService,
    );
    const consulta = { periodo: PeriodoReporte.ULTIMO_MES };

    const respuesta = await controller.ocupacion(
      { id: 'arr-1' } as AuthenticatedUser,
      consulta,
    );

    expect(ocupacion).toHaveBeenCalledWith('arr-1', consulta);
    expect(respuesta).toEqual({
      periodo: { desde: '2026-10-17', hasta: '2026-11-15' },
      totalBienes: 1,
      bienes: [
        {
          bienId: 'b1',
          titulo: 'Salón',
          diasDisponibles: 20,
          diasOcupados: 10,
          tasaOcupacion: 50,
        },
      ],
    });
  });
});
