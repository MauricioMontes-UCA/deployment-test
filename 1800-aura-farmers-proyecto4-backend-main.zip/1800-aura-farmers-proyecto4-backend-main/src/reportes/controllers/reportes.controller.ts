import { Controller, Get, Query } from '@nestjs/common';
import {
  ApiBadRequestResponse,
  ApiBearerAuth,
  ApiForbiddenResponse,
  ApiOkResponse,
  ApiOperation,
  ApiTags,
  ApiUnauthorizedResponse,
} from '@nestjs/swagger';
import { CurrentUser, Roles } from '@Auth/decorators';
import type { AuthenticatedUser } from '@Auth/types';
import { Rol } from '@PrismaClient';
import {
  CalificacionesResponseDto,
  ConsultaPeriodoDto,
  IngresosResponseDto,
  OcupacionResponseDto,
  PeriodoResponseDto,
} from '@Reportes/dto';
import {
  IngresosService,
  OcupacionService,
  ReportesService,
} from '@Reportes/services';

/**
 * Reportes del arrendador. Todo el módulo es solo para arrendadores y ninguna
 * ruta recibe un `arrendadorId`: los datos son siempre los de la sesión.
 */
@ApiTags('reportes')
@ApiBearerAuth()
@Roles(Rol.ARRENDADOR)
@Controller('reportes')
export class ReportesController {
  constructor(
    private readonly reportesService: ReportesService,
    private readonly ingresosService: IngresosService,
    private readonly ocupacionService: OcupacionService,
  ) {}

  @Get('periodo')
  @ApiOperation({
    summary: 'Resuelve el periodo de un reporte a un rango de fechas',
    description:
      'Devuelve las fechas que usarán los reportes para el periodo elegido, con "hoy" en la zona de El Salvador. Sirve para mostrar el rango antes de consultar un reporte.',
  })
  @ApiOkResponse({ type: PeriodoResponseDto })
  @ApiBadRequestResponse({
    description:
      'Con `periodo=RANGO`: "Completa las fechas del rango.", "Usa el formato AAAA-MM-DD.", "La fecha final no puede ser anterior a la inicial." o "El rango no puede ser mayor a 365 días."',
  })
  @ApiUnauthorizedResponse({
    description: 'Token ausente, inválido o expirado.',
  })
  @ApiForbiddenResponse({ description: 'El usuario no es ARRENDADOR.' })
  resolverPeriodo(@Query() consulta: ConsultaPeriodoDto): PeriodoResponseDto {
    const { periodo, ...fechas } =
      this.reportesService.resolverPeriodo(consulta);
    return PeriodoResponseDto.from(periodo, fechas);
  }

  @Get('ocupacion')
  @ApiOperation({
    summary: 'Tasa de ocupación de cada bien del arrendador',
    description:
      'Por cada bien ACTIVA del arrendador de la sesión: días disponibles (los del periodo menos los bloqueados), días ocupados por reservas CONFIRMADA, EN_CURSO o FINALIZADA, y su tasa con un decimal. De mayor a menor tasa, con los bienes sin días disponibles (tasa null) al final.',
  })
  @ApiOkResponse({ type: OcupacionResponseDto })
  @ApiBadRequestResponse({
    description:
      'Con `periodo=RANGO`: "Completa las fechas del rango.", "Usa el formato AAAA-MM-DD.", "La fecha final no puede ser anterior a la inicial." o "El rango no puede ser mayor a 365 días."',
  })
  @ApiUnauthorizedResponse({
    description: 'Token ausente, inválido o expirado.',
  })
  @ApiForbiddenResponse({ description: 'El usuario no es ARRENDADOR.' })
  async ocupacion(
    @CurrentUser() usuario: AuthenticatedUser,
    @Query() consulta: ConsultaPeriodoDto,
  ): Promise<OcupacionResponseDto> {
    return OcupacionResponseDto.from(
      await this.ocupacionService.ocupacion(usuario.id, consulta),
    );
  }

  @Get('ingresos')
  @ApiOperation({
    summary: 'Ingresos y depósito retenido de cada bien del arrendador',
    description:
      'Suma, por bien ACTIVA del arrendador de la sesión, el alquiler de los pagos aprobados y el depósito retenido que se resolvió dentro del periodo. El depósito de garantía no forma parte del ingreso. Los bienes sin pagos aparecen con 0, y el arrendador siempre sale del token.',
  })
  @ApiOkResponse({ type: IngresosResponseDto })
  @ApiBadRequestResponse({
    description:
      'Con `periodo=RANGO`: "Completa las fechas del rango.", "Usa el formato AAAA-MM-DD.", "La fecha final no puede ser anterior a la inicial." o "El rango no puede ser mayor a 365 días."',
  })
  @ApiUnauthorizedResponse({
    description: 'Token ausente, inválido o expirado.',
  })
  @ApiForbiddenResponse({ description: 'El usuario no es ARRENDADOR.' })
  async ingresos(
    @CurrentUser() usuario: AuthenticatedUser,
    @Query() consulta: ConsultaPeriodoDto,
  ): Promise<IngresosResponseDto> {
    return IngresosResponseDto.from(
      await this.ingresosService.ingresos(usuario.id, consulta),
    );
  }

  @Get('calificaciones')
  @ApiOperation({
    summary: 'Calificación promedio y número de reseñas de cada bien',
    description:
      'Promedio de las reseñas de tipo BIEN de reservas FINALIZADA cuya fecha de fin cae en el periodo, por cada bien ACTIVA del arrendador de la sesión. Ordenado de menor a mayor promedio, por título a igual promedio, y los bienes sin calificaciones al final.',
  })
  @ApiOkResponse({ type: CalificacionesResponseDto })
  @ApiBadRequestResponse({
    description:
      'Con `periodo=RANGO`: "Completa las fechas del rango.", "Usa el formato AAAA-MM-DD.", "La fecha final no puede ser anterior a la inicial." o "El rango no puede ser mayor a 365 días."',
  })
  @ApiUnauthorizedResponse({
    description: 'Token ausente, inválido o expirado.',
  })
  @ApiForbiddenResponse({ description: 'El usuario no es ARRENDADOR.' })
  calificaciones(
    @CurrentUser() usuario: AuthenticatedUser,
    @Query() consulta: ConsultaPeriodoDto,
  ): Promise<CalificacionesResponseDto> {
    return this.reportesService.calificaciones(usuario.id, consulta);
  }
}
