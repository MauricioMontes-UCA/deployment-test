import { BadRequestException, StreamableFile } from '@nestjs/common';
import { ROLES_KEY } from '@Auth/decorators';
import type { AuthenticatedUser } from '@Auth/types';
import { Rol } from '@PrismaClient';
import { ResumenResponseDto } from '@Reportes/dto';
import type { ResumenService } from '@Reportes/services';
import { PeriodoReporte } from '@Reportes/utils';
import { ResumenController } from './resumen.controller.js';

describe('ResumenController', () => {
  it('es solo para arrendadores: el rol está en toda la clase', () => {
    expect(Reflect.getMetadata(ROLES_KEY, ResumenController)).toEqual([
      Rol.ARRENDADOR,
    ]);
  });

  it('GET /reportes/resumen usa el arrendador de la sesión y arma la respuesta', async () => {
    const resumen = vi.fn().mockResolvedValue({
      periodo: { desde: '2026-10-17', hasta: '2026-11-15' },
      moneda: 'USD',
      escalaMaxima: 5,
      totalBienes: 1,
      bienes: [
        {
          bienId: 'b1',
          titulo: 'Salón de eventos',
          ingresos: 250,
          tasaOcupacion: 50,
          calificacionPromedio: 4.5,
          totalResenas: 2,
        },
      ],
    });
    const controller = new ResumenController({
      resumen,
    } as unknown as ResumenService);
    const consulta = { periodo: PeriodoReporte.ULTIMO_MES };

    const respuesta = await controller.resumen(
      { id: 'arr-1' } as AuthenticatedUser,
      consulta,
    );

    expect(resumen).toHaveBeenCalledWith('arr-1', consulta);
    expect(respuesta).toBeInstanceOf(ResumenResponseDto);
    expect(respuesta).toEqual({
      periodo: { desde: '2026-10-17', hasta: '2026-11-15' },
      moneda: 'USD',
      escalaMaxima: 5,
      totalBienes: 1,
      bienes: [
        {
          bienId: 'b1',
          titulo: 'Salón de eventos',
          ingresos: 250,
          tasaOcupacion: 50,
          calificacionPromedio: 4.5,
          totalResenas: 2,
        },
      ],
    });
  });

  it('propaga el 400 del periodo', async () => {
    const error = new Error('El rango no puede ser mayor a 365 días.');
    const controller = new ResumenController({
      resumen: vi.fn().mockRejectedValue(error),
    } as unknown as ResumenService);

    await expect(
      controller.resumen({ id: 'arr-1' } as AuthenticatedUser, {}),
    ).rejects.toBe(error);
  });
});

describe('ResumenController.exportar (CSV)', () => {
  const resumenDelServicio = {
    periodo: { desde: '2026-10-07', hasta: '2026-11-05' },
    moneda: 'USD',
    escalaMaxima: 5,
    totalBienes: 2,
    bienes: [
      {
        bienId: 'b1',
        titulo: 'Salón de eventos',
        ingresos: 250,
        tasaOcupacion: 50,
        calificacionPromedio: 4.5,
        totalResenas: 2,
      },
      {
        bienId: 'b2',
        titulo: '=SUMA(1+1)',
        ingresos: 0,
        tasaOcupacion: null,
        calificacionPromedio: null,
        totalResenas: 0,
      },
    ],
  };

  /** Lee todo el contenido del archivo. */
  const leer = async (archivo: StreamableFile) => {
    const partes: Buffer[] = [];
    for await (const parte of archivo.getStream()) {
      partes.push(Buffer.from(parte as Uint8Array));
    }
    return Buffer.concat(partes);
  };

  it('reutiliza ResumenService.resumen() con el arrendador de la sesión y la consulta tal cual', async () => {
    const resumen = vi.fn().mockResolvedValue(resumenDelServicio);
    const controller = new ResumenController({
      resumen,
    } as unknown as ResumenService);
    const consulta = {
      periodo: PeriodoReporte.RANGO,
      desde: '2026-10-07',
      hasta: '2026-11-05',
    };

    await controller.exportar({ id: 'arr-1' } as AuthenticatedUser, consulta);

    expect(resumen).toHaveBeenCalledTimes(1);
    expect(resumen).toHaveBeenCalledWith('arr-1', consulta);
  });

  it('devuelve un StreamableFile con el tipo, la descarga y la longitud del CSV', async () => {
    const controller = new ResumenController({
      resumen: vi.fn().mockResolvedValue(resumenDelServicio),
    } as unknown as ResumenService);

    const archivo = await controller.exportar(
      { id: 'arr-1' } as AuthenticatedUser,
      {},
    );
    const contenido = await leer(archivo);

    expect(archivo).toBeInstanceOf(StreamableFile);
    expect(archivo.getHeaders()).toEqual({
      type: 'text/csv; charset=utf-8',
      disposition:
        'attachment; filename="resumen-desempeno_2026-10-07_2026-11-05.csv"',
      length: contenido.length,
    });
    expect([...contenido.subarray(0, 3)]).toEqual([0xef, 0xbb, 0xbf]);
    expect(contenido.toString('utf8')).toBe(
      '\uFEFF' +
        'Bien,Ingresos (USD),Tasa de ocupación (%),Calificación promedio,Reseñas\r\n' +
        'Salón de eventos,250.00,50.0,4.5,2\r\n' +
        "'=SUMA(1+1),0.00,Sin días disponibles,Sin calificaciones,0\r\n",
    );
  });

  it('sin bienes devuelve solo el encabezado', async () => {
    const controller = new ResumenController({
      resumen: vi.fn().mockResolvedValue({
        ...resumenDelServicio,
        totalBienes: 0,
        bienes: [],
      }),
    } as unknown as ResumenService);

    const archivo = await controller.exportar(
      { id: 'arr-1' } as AuthenticatedUser,
      {},
    );

    expect((await leer(archivo)).toString('utf8')).toBe(
      '\uFEFFBien,Ingresos (USD),Tasa de ocupación (%),Calificación promedio,Reseñas\r\n',
    );
  });

  it('propaga el 400 del periodo sin armar ningún archivo', async () => {
    const error = new BadRequestException(
      'El rango no puede ser mayor a 365 días.',
    );
    const controller = new ResumenController({
      resumen: vi.fn().mockRejectedValue(error),
    } as unknown as ResumenService);

    await expect(
      controller.exportar({ id: 'arr-1' } as AuthenticatedUser, {
        periodo: PeriodoReporte.RANGO,
        desde: '2026-01-01',
        hasta: '2027-01-01',
      }),
    ).rejects.toBe(error);
  });

  // Clave con la que @Header() guarda las cabeceras en la función del método.
  const HEADERS_METADATA = '__headers__';
  const cabecerasDe = (metodo: 'exportar' | 'resumen'): unknown =>
    Reflect.getMetadata(
      HEADERS_METADATA,
      Object.getOwnPropertyDescriptor(ResumenController.prototype, metodo)!
        .value as object,
    );

  it('la exportación envía Cache-Control: no-store, porque el archivo trae ingresos', () => {
    expect(cabecerasDe('exportar')).toEqual([
      { name: 'Cache-Control', value: 'no-store' },
    ]);
  });

  it('GET /reportes/resumen (JSON) no cambia: no tiene cabeceras propias', () => {
    expect(cabecerasDe('resumen')).toBe(undefined);
  });
});
