import { Module } from '@nestjs/common';
import { ReportesController, ResumenController } from '@Reportes/controllers';
import { ReportesRepository } from '@Reportes/repositories';
import {
  IngresosService,
  OcupacionService,
  ReportesService,
  ResumenService,
} from '@Reportes/services';

/**
 * Base de los reportes del arrendador (ingresos, ocupación, calificaciones y
 * resumen): el periodo, el filtro por arrendador y el control de acceso.
 */
@Module({
  controllers: [ReportesController, ResumenController],
  providers: [
    ReportesService,
    IngresosService,
    OcupacionService,
    ResumenService,
    ReportesRepository,
  ],
  exports: [ReportesService],
})
export class ReportesModule {}
