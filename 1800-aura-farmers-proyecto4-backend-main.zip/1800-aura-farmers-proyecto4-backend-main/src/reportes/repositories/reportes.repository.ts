import { Injectable } from '@nestjs/common';
import { PrismaService } from '@Prisma/services';
import { EstadoBien } from '@PrismaClient';
import { ESTADOS_QUE_OCUPAN } from '@Bienes/repositories';
import { parseDia, ZONA_HORARIA } from '@Bienes/utils';
import {
  promedioConUnDecimal,
  type BienDeReporte,
  type CalificacionDeBien,
  type CentavosDeBien,
  type IntervaloDeBien,
} from '@Reportes/utils';

export type { BienDeReporte } from '@Reportes/utils';

/** Fila cruda de la consulta agregada; las sumas llegan como bigint. */
interface FilaMontos {
  bienId: string;
  ingresosCentavos: bigint;
  depositoRetenidoCentavos: bigint;
}

/** Lecturas que comparten los reportes del arrendador. */
@Injectable()
export class ReportesRepository {
  constructor(private readonly prisma: PrismaService) {}

  /**
   * Bienes ACTIVA del arrendador, por título y luego por id para que el orden
   * sea estable. No trae bienes INACTIVA ni de otros arrendadores.
   */
  bienesActivosDelArrendador(arrendadorId: string): Promise<BienDeReporte[]> {
    return this.prisma.bien.findMany({
      where: { arrendadorId, estado: EstadoBien.ACTIVA },
      select: { id: true, titulo: true },
      orderBy: [{ titulo: 'asc' }, { id: 'asc' }],
    });
  }

  /**
   * Reservas que ocupan días y bloqueos de fechas de los bienes del arrendador
   * que se cruzan con el periodo `desde`..`hasta` (días inclusivos,
   * `AAAA-MM-DD`). Son dos consultas para todos los bienes, no una por bien.
   *
   * - Reservas: solo CONFIRMADA, EN_CURSO y FINALIZADA (`ESTADOS_QUE_OCUPAN`, los
   *   mismos del calendario y de la búsqueda). EN_COLA, RECHAZADA y CANCELADA no
   *   se consultan.
   * - Bloqueos: todos los que se cruzan.
   *
   * Se cruza el rango completo, no solo lo contenido: `calcularOcupacion`
   * recorta al periodo. Además del id, se filtra por el arrendador de la sesión,
   * para que nunca entren días de bienes ajenos.
   */
  async intervalosDeOcupacion(
    arrendadorId: string,
    bienIds: string[],
    desde: string,
    hasta: string,
  ): Promise<{ reservas: IntervaloDeBien[]; bloqueos: IntervaloDeBien[] }> {
    const cruzaElPeriodo = {
      bienId: { in: bienIds },
      bien: { arrendadorId },
      fechaInicio: { lte: parseDia(hasta)! },
      fechaFin: { gte: parseDia(desde)! },
    };
    const campos = { bienId: true, fechaInicio: true, fechaFin: true } as const;

    const [reservas, bloqueos] = await Promise.all([
      this.prisma.reserva.findMany({
        where: { ...cruzaElPeriodo, estado: { in: ESTADOS_QUE_OCUPAN } },
        select: campos,
      }),
      this.prisma.bloqueoFecha.findMany({
        where: cruzaElPeriodo,
        select: campos,
      }),
    ]);

    const aIntervalo = ({
      bienId,
      fechaInicio,
      fechaFin,
    }: {
      bienId: string;
      fechaInicio: Date;
      fechaFin: Date;
    }): IntervaloDeBien => ({ bienId, inicio: fechaInicio, fin: fechaFin });

    return {
      reservas: reservas.map(aIntervalo),
      bloqueos: bloqueos.map(aIntervalo),
    };
  }

  /**
   * Ingresos y depósito retenido por bien del arrendador, en centavos, para el
   * periodo `desde`..`hasta` (días inclusivos, `AAAA-MM-DD`).
   *
   * Es una sola consulta de solo lectura. Los pagos y los depósitos van en un
   * `UNION ALL` y se agrupan por bien: cruzar `Pagos` con `Depositos` en un
   * mismo `JOIN` repetiría filas de uno por cada fila del otro.
   *
   * - Ingreso: `importe_alquiler` de los pagos SIMULADO_EXITOSO; el depósito del
   *   pago nunca se suma.
   * - Retenido: `importe_retenido` de los depósitos RETENIDO o
   *   PARCIALMENTE_RETENIDO, por su fecha de resolución.
   *
   * Los días se interpretan en la zona de El Salvador y se comparan como un
   * rango de instantes (desde la medianoche de `desde` hasta la de `hasta` + 1),
   * lo que respeta los índices parciales de pagos y depósitos. Todo valor entra
   * como parámetro; nada se concatena en el texto SQL.
   */
  async montosPorBien(
    arrendadorId: string,
    desde: string,
    hasta: string,
  ): Promise<CentavosDeBien[]> {
    const filas = await this.prisma.$queryRaw<FilaMontos[]>`
      SELECT montos.bien_id AS "bienId",
             SUM(montos.ingresos)::bigint AS "ingresosCentavos",
             SUM(montos.retenido)::bigint AS "depositoRetenidoCentavos"
      FROM (
        SELECT r.bien_id,
               ROUND(p.importe_alquiler * 100) AS ingresos,
               0 AS retenido
        FROM "Pagos" p
        JOIN "Reservas" r ON r.id = p.reserva_id
        JOIN "Bienes" b ON b.id = r.bien_id
        WHERE b.arrendador_id = ${arrendadorId}::uuid
          AND b.estado = 'ACTIVA'
          AND p.estado = 'SIMULADO_EXITOSO'
          AND p.fecha_hora >= ((${desde}::date)::timestamp AT TIME ZONE ${ZONA_HORARIA}::text)
          AND p.fecha_hora < (((${hasta}::date + 1))::timestamp AT TIME ZONE ${ZONA_HORARIA}::text)
        UNION ALL
        SELECT r.bien_id,
               0 AS ingresos,
               ROUND(d.importe_retenido * 100) AS retenido
        FROM "Depositos" d
        JOIN "Reservas" r ON r.id = d.reserva_id
        JOIN "Bienes" b ON b.id = r.bien_id
        WHERE b.arrendador_id = ${arrendadorId}::uuid
          AND b.estado = 'ACTIVA'
          AND d.estado IN ('RETENIDO', 'PARCIALMENTE_RETENIDO')
          AND d.fecha_resolucion >= ((${desde}::date)::timestamp AT TIME ZONE ${ZONA_HORARIA}::text)
          AND d.fecha_resolucion < (((${hasta}::date + 1))::timestamp AT TIME ZONE ${ZONA_HORARIA}::text)
      ) montos
      GROUP BY montos.bien_id`;

    return filas.map((fila) => ({
      bienId: fila.bienId,
      ingresosCentavos: Number(fila.ingresosCentavos),
      depositoRetenidoCentavos: Number(fila.depositoRetenidoCentavos),
    }));
  }

  /**
   * Promedio y cantidad de reseñas de tipo BIEN de cada bien ACTIVA del
   * arrendador, contando solo las reservas FINALIZADA cuya `fechaFin` cae entre
   * `desde` y `hasta` (inclusive). Las reseñas sobre el arrendador o el
   * arrendatario no entran.
   *
   * Con LEFT JOIN, un bien sin reseñas en el periodo sigue en la lista con
   * suma 0 y 0 reseñas. La base solo suma y cuenta; el promedio y su redondeo
   * los calcula `promedioConUnDecimal`, que tiene sus propias pruebas
   * unitarias.
   *
   * Las fechas entran como texto con `::date`: un `Date` llegaría como
   * timestamptz y, según la zona de la sesión, podría correr un día.
   */
  async calificacionesDeBienes(
    arrendadorId: string,
    desde: string,
    hasta: string,
  ): Promise<CalificacionDeBien[]> {
    const filas = await this.prisma.$queryRaw<FilaCalificacion[]>`
      SELECT b.id AS "bienId",
             b.titulo,
             COALESCE(SUM(r.puntuacion), 0)::int AS "sumaPuntuaciones",
             COUNT(r.id)::int AS "totalResenas"
      FROM "Bienes" b
      LEFT JOIN "Reservas" rv
        ON rv.bien_id = b.id
       AND rv.estado = 'FINALIZADA'
       AND rv.fecha_fin BETWEEN ${desde}::date AND ${hasta}::date
      LEFT JOIN "Resenas" r
        ON r.reserva_id = rv.id
       AND r.tipo = 'BIEN'
      WHERE b.arrendador_id = ${arrendadorId}::uuid
        AND b.estado = 'ACTIVA'
      GROUP BY b.id, b.titulo`;

    return filas.map((fila) => ({
      bienId: fila.bienId,
      titulo: fila.titulo,
      promedio: promedioConUnDecimal(fila.sumaPuntuaciones, fila.totalResenas),
      totalResenas: fila.totalResenas,
    }));
  }
}

/** Fila tal como la devuelve la consulta de calificaciones. */
interface FilaCalificacion {
  bienId: string;
  titulo: string;
  sumaPuntuaciones: number;
  totalResenas: number;
}
