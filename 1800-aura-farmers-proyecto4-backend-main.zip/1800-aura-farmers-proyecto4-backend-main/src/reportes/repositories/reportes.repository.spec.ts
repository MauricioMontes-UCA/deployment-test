import type { PrismaService } from '@Prisma/services';
import { ReportesRepository } from './reportes.repository.js';

describe('ReportesRepository.bienesActivosDelArrendador', () => {
  it('filtra por arrendador y por estado ACTIVA, y trae solo id y título', async () => {
    const bienes = [{ id: 'bien-1', titulo: 'Casa' }];
    const findMany = vi.fn().mockResolvedValue(bienes);
    const repository = new ReportesRepository({
      bien: { findMany },
    } as unknown as PrismaService);

    await expect(
      repository.bienesActivosDelArrendador('arrendador-1'),
    ).resolves.toBe(bienes);
    expect(findMany).toHaveBeenCalledWith({
      where: { arrendadorId: 'arrendador-1', estado: 'ACTIVA' },
      select: { id: true, titulo: true },
      orderBy: [{ titulo: 'asc' }, { id: 'asc' }],
    });
  });
});
