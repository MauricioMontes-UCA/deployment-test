import type { PrismaService } from '@Prisma/services';
import { ReportesRepository } from './reportes.repository.js';

function crear(filas: unknown[] = []) {
  const queryRaw = vi.fn().mockResolvedValue(filas);
  const repository = new ReportesRepository({
    $queryRaw: queryRaw,
  } as unknown as PrismaService);
  return { repository, queryRaw };
}

/** Texto SQL de la llamada: el `$queryRaw` etiquetado recibe las partes fijas. */
const sqlDe = (queryRaw: ReturnType<typeof vi.fn>) =>
  (queryRaw.mock.calls[0][0] as string[]).join('?');
const valoresDe = (queryRaw: ReturnType<typeof vi.fn>) =>
  (queryRaw.mock.calls[0] as unknown[]).slice(1);

describe('ReportesRepository.montosPorBien', () => {
  const arrendadorId = '11111111-1111-4111-8111-111111111111';

  it('convierte las sumas bigint de la base en números de centavos', async () => {
    const { repository } = crear([
      {
        bienId: 'b1',
        ingresosCentavos: 25000n,
        depositoRetenidoCentavos: 5000n,
      },
    ]);

    await expect(
      repository.montosPorBien(arrendadorId, '2026-10-17', '2026-11-15'),
    ).resolves.toEqual([
      { bienId: 'b1', ingresosCentavos: 25000, depositoRetenidoCentavos: 5000 },
    ]);
  });

  it('devuelve una lista vacía si no hay movimientos', async () => {
    const { repository } = crear([]);

    await expect(
      repository.montosPorBien(arrendadorId, '2026-10-17', '2026-11-15'),
    ).resolves.toEqual([]);
  });

  it('hace una sola consulta', async () => {
    const { repository, queryRaw } = crear();

    await repository.montosPorBien(arrendadorId, '2026-10-17', '2026-11-15');

    expect(queryRaw).toHaveBeenCalledOnce();
  });

  it('pasa el arrendador, las fechas y la zona como parámetros, sin concatenarlos en el SQL', async () => {
    const { repository, queryRaw } = crear();

    await repository.montosPorBien(arrendadorId, '2026-10-17', '2026-11-15');

    const sql = sqlDe(queryRaw);
    for (const valor of [arrendadorId, '2026-10-17', '2026-11-15']) {
      expect(sql).not.toContain(valor);
      expect(valoresDe(queryRaw)).toContain(valor);
    }
    expect(sql).not.toContain('America/El_Salvador');
    expect(valoresDe(queryRaw)).toContain('America/El_Salvador');
  });

  it('un valor con comillas o SQL no cambia el texto de la consulta', async () => {
    const { repository, queryRaw } = crear();
    const malicioso = '2026-10-17\'; DROP TABLE "Pagos"; --';

    await repository.montosPorBien(arrendadorId, malicioso, '2026-11-15');

    expect(sqlDe(queryRaw)).not.toContain('DROP');
    expect(valoresDe(queryRaw)).toContain(malicioso);
  });

  describe('reglas de la consulta', () => {
    it('suma solo los pagos SIMULADO_EXITOSO y solo el importe del alquiler', async () => {
      const { repository, queryRaw } = crear();

      await repository.montosPorBien(arrendadorId, '2026-10-17', '2026-11-15');

      const sql = sqlDe(queryRaw);
      expect(sql).toContain("p.estado = 'SIMULADO_EXITOSO'");
      expect(sql).toContain('p.importe_alquiler');
      expect(sql).not.toContain('importe_deposito');
      expect(sql).not.toContain('p.total');
    });

    it('suma el retenido solo de depósitos RETENIDO o PARCIALMENTE_RETENIDO', async () => {
      const { repository, queryRaw } = crear();

      await repository.montosPorBien(arrendadorId, '2026-10-17', '2026-11-15');

      const sql = sqlDe(queryRaw);
      expect(sql).toContain(
        "d.estado IN ('RETENIDO', 'PARCIALMENTE_RETENIDO')",
      );
      expect(sql).toContain('d.importe_retenido');
      expect(sql).toContain('d.fecha_resolucion');
    });

    it('filtra por el arrendador y por bienes ACTIVA en pagos y en depósitos', async () => {
      const { repository, queryRaw } = crear();

      await repository.montosPorBien(arrendadorId, '2026-10-17', '2026-11-15');

      const sql = sqlDe(queryRaw);
      expect(sql.match(/b\.arrendador_id = /g)).toHaveLength(2);
      expect(sql.match(/b\.estado = 'ACTIVA'/g)).toHaveLength(2);
    });

    it('compara las fechas como un rango semiabierto en la zona del país: incluye el último día y no el anterior al primero', async () => {
      const { repository, queryRaw } = crear();

      await repository.montosPorBien(arrendadorId, '2026-10-17', '2026-11-15');

      const sql = sqlDe(queryRaw);
      // Pagos y depósitos: >= medianoche de `desde` y < medianoche de `hasta` + 1.
      expect(sql.match(/fecha_hora >= /g)).toHaveLength(1);
      expect(sql.match(/fecha_hora < /g)).toHaveLength(1);
      expect(sql.match(/fecha_resolucion >= /g)).toHaveLength(1);
      expect(sql.match(/fecha_resolucion < /g)).toHaveLength(1);
      expect(sql.match(/::date \+ 1/g)).toHaveLength(2);
      expect(sql.match(/AT TIME ZONE/g)).toHaveLength(4);
    });

    it('es de solo lectura', async () => {
      const { repository, queryRaw } = crear();

      await repository.montosPorBien(arrendadorId, '2026-10-17', '2026-11-15');

      const sql = sqlDe(queryRaw).toUpperCase();
      for (const palabra of ['INSERT', 'UPDATE', 'DELETE', 'TRUNCATE']) {
        expect(sql).not.toContain(palabra);
      }
    });
  });
});
