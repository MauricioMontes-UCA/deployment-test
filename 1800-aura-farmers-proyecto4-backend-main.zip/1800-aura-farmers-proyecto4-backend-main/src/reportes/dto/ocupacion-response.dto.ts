import { ApiProperty } from '@nestjs/swagger';
import type { ReporteOcupacion } from '@Reportes/services';
import { PeriodoFechasDto } from './ingresos-response.dto.js';

export class OcupacionBienDto {
  @ApiProperty({ format: 'uuid' })
  bienId: string;

  @ApiProperty({ example: 'Mesa de sonido' })
  titulo: string;

  @ApiProperty({
    example: 30,
    description: 'Días del periodo que no están bloqueados.',
  })
  diasDisponibles: number;

  @ApiProperty({
    example: 30,
    description:
      'Días disponibles cubiertos por reservas CONFIRMADA, EN_CURSO o FINALIZADA. Cada día cuenta una vez.',
  })
  diasOcupados: number;

  @ApiProperty({
    type: Number,
    nullable: true,
    example: 100,
    description:
      'Días ocupados ÷ días disponibles × 100, con un decimal y sin pasar de 100. `null` significa "Sin días disponibles".',
  })
  tasaOcupacion: number | null;
}

/** Respuesta de `GET /reportes/ocupacion`. */
export class OcupacionResponseDto {
  @ApiProperty({ type: PeriodoFechasDto })
  periodo: PeriodoFechasDto;

  @ApiProperty({
    example: 4,
    description: 'Cantidad de bienes de la lista (sin paginación).',
  })
  totalBienes: number;

  @ApiProperty({
    type: [OcupacionBienDto],
    description:
      'Todos los bienes ACTIVA del arrendador. De mayor a menor tasa; a igual tasa, por título de la A a la Z; los "Sin días disponibles", al final.',
  })
  bienes: OcupacionBienDto[];

  static from(reporte: ReporteOcupacion): OcupacionResponseDto {
    const dto = new OcupacionResponseDto();
    dto.periodo = {
      desde: reporte.periodo.desde,
      hasta: reporte.periodo.hasta,
    };
    dto.totalBienes = reporte.totalBienes;
    dto.bienes = reporte.bienes.map(
      ({ bienId, titulo, diasDisponibles, diasOcupados, tasaOcupacion }) => ({
        bienId,
        titulo,
        diasDisponibles,
        diasOcupados,
        tasaOcupacion,
      }),
    );
    return dto;
  }
}
