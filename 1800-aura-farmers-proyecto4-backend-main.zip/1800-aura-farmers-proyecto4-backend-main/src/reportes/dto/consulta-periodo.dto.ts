import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsEnum, IsOptional, IsString } from 'class-validator';
import { PeriodoReporte } from '@Reportes/utils';

/**
 * Query de los reportes.
 *
 * Aquí solo se valida el tipo. Las fechas se revisan en `resolverPeriodo`
 * porque sus mensajes de error están fijados por la especificación y
 * class-validator los devolvería como un arreglo, no como un texto. Ningún
 * campo identifica al arrendador: sale siempre del token.
 */
export class ConsultaPeriodoDto {
  @ApiPropertyOptional({
    enum: Object.values(PeriodoReporte),
    default: PeriodoReporte.ULTIMO_MES,
    description:
      'Último mes son 30 días, últimos 3 meses son 90 y último año son 365, contando hoy.',
  })
  @IsOptional()
  @IsEnum(PeriodoReporte)
  periodo?: PeriodoReporte;

  @ApiPropertyOptional({
    example: '2026-10-01',
    description:
      'Primer día del rango. Obligatorio con `periodo=RANGO`; con otro periodo se ignora.',
  })
  @IsOptional()
  @IsString()
  desde?: string;

  @ApiPropertyOptional({
    example: '2026-10-31',
    description:
      'Último día del rango, inclusive. Obligatorio con `periodo=RANGO`; con otro periodo se ignora.',
  })
  @IsOptional()
  @IsString()
  hasta?: string;
}
