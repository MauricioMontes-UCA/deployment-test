import { ApiProperty } from '@nestjs/swagger';
import { ESCALA_MAXIMA_CALIFICACION, MONEDA_REPORTE } from '@Reportes/utils';
import type { ResumenDesempeno } from '@Reportes/services';
import { PeriodoFechasDto } from './ingresos-response.dto.js';

export class ResumenBienDto {
  @ApiProperty({ format: 'uuid' })
  bienId: string;

  @ApiProperty({ example: 'Salón de eventos' })
  titulo: string;

  @ApiProperty({
    example: 250,
    description:
      'Igual que `ingresos` de `GET /reportes/ingresos`: alquiler de los pagos aprobados del periodo, con dos decimales.',
  })
  ingresos: number;

  @ApiProperty({
    type: Number,
    nullable: true,
    example: 50,
    description:
      'Igual que `tasaOcupacion` de `GET /reportes/ocupacion`, con un decimal. `null` significa "Sin días disponibles".',
  })
  tasaOcupacion: number | null;

  @ApiProperty({
    type: Number,
    nullable: true,
    example: 4.5,
    description:
      'Igual que `promedio` de `GET /reportes/calificaciones`, con un decimal. `null` significa "Sin calificaciones".',
  })
  calificacionPromedio: number | null;

  @ApiProperty({
    example: 2,
    description: 'Reseñas que componen el promedio.',
  })
  totalResenas: number;
}

/** Respuesta de `GET /reportes/resumen`. */
export class ResumenResponseDto {
  @ApiProperty({ type: PeriodoFechasDto })
  periodo: PeriodoFechasDto;

  @ApiProperty({ example: MONEDA_REPORTE })
  moneda: string;

  @ApiProperty({
    example: ESCALA_MAXIMA_CALIFICACION,
    description: 'Puntuación máxima de una reseña.',
  })
  escalaMaxima: number;

  @ApiProperty({
    example: 4,
    description: 'Cantidad de bienes de la lista (sin paginación).',
  })
  totalBienes: number;

  @ApiProperty({
    type: [ResumenBienDto],
    description:
      'Una fila por bien ACTIVA del arrendador, por título de la A a la Z.',
  })
  bienes: ResumenBienDto[];

  static from(resumen: ResumenDesempeno): ResumenResponseDto {
    const dto = new ResumenResponseDto();
    dto.periodo = {
      desde: resumen.periodo.desde,
      hasta: resumen.periodo.hasta,
    };
    dto.moneda = resumen.moneda;
    dto.escalaMaxima = resumen.escalaMaxima;
    dto.totalBienes = resumen.totalBienes;
    dto.bienes = resumen.bienes.map(
      ({
        bienId,
        titulo,
        ingresos,
        tasaOcupacion,
        calificacionPromedio,
        totalResenas,
      }) => ({
        bienId,
        titulo,
        ingresos,
        tasaOcupacion,
        calificacionPromedio,
        totalResenas,
      }),
    );
    return dto;
  }
}
