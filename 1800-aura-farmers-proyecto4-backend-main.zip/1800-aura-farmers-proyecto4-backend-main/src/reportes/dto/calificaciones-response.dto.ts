import { ApiProperty } from '@nestjs/swagger';
import { ESCALA_MAXIMA_CALIFICACION } from '@Reportes/utils';

class RangoReporteDto {
  @ApiProperty({ example: '2026-10-17', description: 'Primer día, inclusive.' })
  desde!: string;

  @ApiProperty({ example: '2026-11-15', description: 'Último día, inclusive.' })
  hasta!: string;
}

export class CalificacionBienDto {
  @ApiProperty({ format: 'uuid' })
  bienId!: string;

  @ApiProperty({ example: 'Mesa de sonido' })
  titulo!: string;

  @ApiProperty({
    type: Number,
    nullable: true,
    example: 3,
    description:
      'Promedio de las reseñas de tipo BIEN del periodo, con un decimal. `null` si no hay reseñas ("Sin calificaciones").',
  })
  promedio!: number | null;

  @ApiProperty({ example: 1, description: 'Reseñas que componen el promedio.' })
  totalResenas!: number;
}

/** Respuesta de `GET /reportes/calificaciones`. */
export class CalificacionesResponseDto {
  @ApiProperty({ type: RangoReporteDto })
  periodo!: RangoReporteDto;

  @ApiProperty({ example: ESCALA_MAXIMA_CALIFICACION })
  escalaMaxima!: number;

  @ApiProperty({ example: 4, description: 'Cantidad de bienes de la lista.' })
  totalBienes!: number;

  @ApiProperty({
    type: [CalificacionBienDto],
    description:
      'Bienes ACTIVA del arrendador, de menor a mayor promedio; a igual promedio, por título; los que no tienen calificaciones, al final.',
  })
  bienes!: CalificacionBienDto[];
}
