import { ApiProperty } from '@nestjs/swagger';
import { PeriodoReporte, type PeriodoResuelto } from '@Reportes/utils';

/** Periodo efectivo de un reporte, con las fechas ya resueltas. */
export class PeriodoResponseDto {
  @ApiProperty({
    enum: Object.values(PeriodoReporte),
    example: PeriodoReporte.ULTIMO_MES,
  })
  periodo: PeriodoReporte;

  @ApiProperty({ example: '2026-10-17', description: 'Primer día, inclusive.' })
  desde: string;

  @ApiProperty({ example: '2026-11-15', description: 'Último día, inclusive.' })
  hasta: string;

  static from(
    periodo: PeriodoReporte,
    { desde, hasta }: PeriodoResuelto,
  ): PeriodoResponseDto {
    const dto = new PeriodoResponseDto();
    dto.periodo = periodo;
    dto.desde = desde;
    dto.hasta = hasta;
    return dto;
  }
}
