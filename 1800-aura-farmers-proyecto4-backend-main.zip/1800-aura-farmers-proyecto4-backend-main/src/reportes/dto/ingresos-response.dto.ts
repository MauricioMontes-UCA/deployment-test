import { ApiProperty } from '@nestjs/swagger';
import { MONEDA_REPORTE } from '@Reportes/utils';
import type { ReporteIngresos } from '@Reportes/services';

export class PeriodoFechasDto {
  @ApiProperty({ example: '2026-10-17', description: 'Primer día, inclusive.' })
  desde: string;

  @ApiProperty({ example: '2026-11-15', description: 'Último día, inclusive.' })
  hasta: string;
}

export class IngresoBienDto {
  @ApiProperty({ format: 'uuid' })
  bienId: string;

  @ApiProperty({ example: 'Salón de eventos' })
  titulo: string;

  @ApiProperty({
    example: 250,
    description:
      'Suma del importe del alquiler de los pagos aprobados del periodo, con dos decimales. No incluye el depósito de garantía.',
  })
  ingresos: number;

  @ApiProperty({
    example: 50,
    description:
      'Importe retenido de los depósitos resueltos como retenidos o parcialmente retenidos en el periodo. No se suma al ingreso.',
  })
  depositoRetenido: number;
}

export class IngresosResponseDto {
  @ApiProperty({ type: PeriodoFechasDto })
  periodo: PeriodoFechasDto;

  @ApiProperty({ example: MONEDA_REPORTE })
  moneda: string;

  @ApiProperty({
    example: 250,
    description: 'Suma de los ingresos de los bienes.',
  })
  totalIngresos: number;

  @ApiProperty({
    example: 50,
    description: 'Suma del depósito retenido de los bienes.',
  })
  totalDepositoRetenido: number;

  @ApiProperty({
    example: 4,
    description: 'Cantidad de bienes de la lista (sin paginación).',
  })
  totalBienes: number;

  @ApiProperty({
    type: [IngresoBienDto],
    description:
      'Todos los bienes ACTIVA del arrendador, también los sin pagos (con 0). De mayor a menor ingreso y, a igual ingreso, por título de la A a la Z.',
  })
  bienes: IngresoBienDto[];

  static from(reporte: ReporteIngresos): IngresosResponseDto {
    const dto = new IngresosResponseDto();
    dto.periodo = {
      desde: reporte.periodo.desde,
      hasta: reporte.periodo.hasta,
    };
    dto.moneda = MONEDA_REPORTE;
    dto.totalIngresos = reporte.totalIngresos;
    dto.totalDepositoRetenido = reporte.totalDepositoRetenido;
    dto.totalBienes = reporte.totalBienes;
    dto.bienes = reporte.bienes.map(
      ({ bienId, titulo, ingresos, depositoRetenido }) => ({
        bienId,
        titulo,
        ingresos,
        depositoRetenido,
      }),
    );
    return dto;
  }
}
