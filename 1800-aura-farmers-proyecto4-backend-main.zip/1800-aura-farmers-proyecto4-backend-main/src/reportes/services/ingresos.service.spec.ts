import { BadRequestException } from '@nestjs/common';
import type { ReportesRepository } from '@Reportes/repositories';
import { PeriodoReporte } from '@Reportes/utils';
import { IngresosService } from './ingresos.service.js';
import { ReportesService } from './reportes.service.js';

const AHORA = new Date('2026-11-15T18:00:00.000Z');

function crear(
  bienes: { id: string; titulo: string }[],
  montos: {
    bienId: string;
    ingresosCentavos: number;
    depositoRetenidoCentavos: number;
  }[] = [],
) {
  const repository = {
    bienesActivosDelArrendador: vi.fn().mockResolvedValue(bienes),
    montosPorBien: vi.fn().mockResolvedValue(montos),
  };
  const reportes = new ReportesService(
    repository as unknown as ReportesRepository,
  );
  const service = new IngresosService(
    reportes,
    repository as unknown as ReportesRepository,
  );
  return { service, repository };
}

describe('IngresosService.ingresos', () => {
  it('arma el reporte con el periodo, los bienes y los totales', async () => {
    const { service } = crear(
      [
        { id: 'b1', titulo: 'Salón' },
        { id: 'b2', titulo: 'Taladro' },
      ],
      [
        {
          bienId: 'b1',
          ingresosCentavos: 25000,
          depositoRetenidoCentavos: 5000,
        },
      ],
    );

    await expect(service.ingresos('arr-1', {}, AHORA)).resolves.toEqual({
      periodo: { desde: '2026-10-17', hasta: '2026-11-15' },
      totalIngresos: 250,
      totalDepositoRetenido: 50,
      totalBienes: 2,
      bienes: [
        { bienId: 'b1', titulo: 'Salón', ingresos: 250, depositoRetenido: 50 },
        { bienId: 'b2', titulo: 'Taladro', ingresos: 0, depositoRetenido: 0 },
      ],
    });
  });

  it('consulta con el arrendador recibido y el rango resuelto', async () => {
    const { service, repository } = crear([{ id: 'b1', titulo: 'Salón' }]);

    await service.ingresos(
      'arr-1',
      { periodo: PeriodoReporte.ULTIMO_ANIO },
      AHORA,
    );

    expect(repository.bienesActivosDelArrendador).toHaveBeenCalledWith('arr-1');
    expect(repository.montosPorBien).toHaveBeenCalledWith(
      'arr-1',
      '2025-11-16',
      '2026-11-15',
    );
  });

  it('con un RANGO propio consulta exactamente esas fechas', async () => {
    const { service, repository } = crear([{ id: 'b1', titulo: 'Salón' }]);

    const reporte = await service.ingresos(
      'arr-1',
      {
        periodo: PeriodoReporte.RANGO,
        desde: '2026-10-01',
        hasta: '2026-10-31',
      },
      AHORA,
    );

    expect(reporte.periodo).toEqual({
      desde: '2026-10-01',
      hasta: '2026-10-31',
    });
    expect(repository.montosPorBien).toHaveBeenCalledWith(
      'arr-1',
      '2026-10-01',
      '2026-10-31',
    );
  });

  it('sin bienes activos responde vacío y no ejecuta la consulta agregada', async () => {
    const { service, repository } = crear([]);

    await expect(service.ingresos('arr-1', {}, AHORA)).resolves.toEqual({
      periodo: { desde: '2026-10-17', hasta: '2026-11-15' },
      totalIngresos: 0,
      totalDepositoRetenido: 0,
      totalBienes: 0,
      bienes: [],
    });
    expect(repository.montosPorBien).not.toHaveBeenCalled();
  });

  it('un rango inválido responde 400 sin tocar la base', async () => {
    const { service, repository } = crear([{ id: 'b1', titulo: 'Salón' }]);

    await expect(
      service.ingresos('arr-1', { periodo: PeriodoReporte.RANGO }, AHORA),
    ).rejects.toThrow(
      new BadRequestException('Completa las fechas del rango.'),
    );
    expect(repository.bienesActivosDelArrendador).not.toHaveBeenCalled();
    expect(repository.montosPorBien).not.toHaveBeenCalled();
  });
});
