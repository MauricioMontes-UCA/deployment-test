import { Injectable } from '@nestjs/common';
import { ReportesRepository } from '@Reportes/repositories';
import {
  calcularIngresos,
  type PeriodoResuelto,
  type ResumenIngresos,
  type SolicitudPeriodo,
} from '@Reportes/utils';
import { ReportesService } from './reportes.service.js';

/** Ingresos del arrendador en un periodo: el reporte completo, ya calculado. */
export interface ReporteIngresos extends ResumenIngresos {
  periodo: PeriodoResuelto;
}

/** Reporte de ingresos y depósito retenido por bien (H23). */
@Injectable()
export class IngresosService {
  constructor(
    private readonly reportesService: ReportesService,
    private readonly reportesRepository: ReportesRepository,
  ) {}

  /**
   * Ingresos y depósito retenido de cada bien ACTIVA del arrendador.
   *
   * El arrendador viene siempre de la sesión. `ahora` se recibe para poder
   * probar el periodo con una fecha fija.
   *
   * @throws {BadRequestException} el rango no es válido (ver `resolverPeriodo`).
   */
  async ingresos(
    arrendadorId: string,
    solicitud: SolicitudPeriodo,
    ahora: Date = new Date(),
  ): Promise<ReporteIngresos> {
    const { desde, hasta } = this.reportesService.resolverPeriodo(
      solicitud,
      ahora,
    );
    const bienes =
      await this.reportesService.bienesActivosDelArrendador(arrendadorId);

    // Sin bienes no hay nada que sumar: se evita la consulta agregada.
    const montos =
      bienes.length === 0
        ? []
        : await this.reportesRepository.montosPorBien(
            arrendadorId,
            desde,
            hasta,
          );

    return { periodo: { desde, hasta }, ...calcularIngresos(bienes, montos) };
  }
}
