import { Injectable } from '@nestjs/common';
import { ReportesRepository } from '@Reportes/repositories';
import {
  armarOcupacion,
  type OcupacionDeBien,
  type PeriodoResuelto,
  type SolicitudPeriodo,
} from '@Reportes/utils';
import { ReportesService } from './reportes.service.js';

/** Ocupación de los bienes del arrendador en un periodo, ya calculada. */
export interface ReporteOcupacion {
  periodo: PeriodoResuelto;
  totalBienes: number;
  bienes: OcupacionDeBien[];
}

/** Reporte de tasa de ocupación por bien (H24). */
@Injectable()
export class OcupacionService {
  constructor(
    private readonly reportesService: ReportesService,
    private readonly reportesRepository: ReportesRepository,
  ) {}

  /**
   * Días disponibles, días ocupados y tasa de ocupación de cada bien ACTIVA
   * del arrendador, de la tasa más alta a la más baja y con los bienes sin días
   * disponibles al final.
   *
   * El arrendador viene siempre de la sesión. `ahora` se recibe para poder
   * probar el periodo con una fecha fija.
   *
   * @throws {BadRequestException} el rango no es válido (ver `resolverPeriodo`).
   */
  async ocupacion(
    arrendadorId: string,
    solicitud: SolicitudPeriodo,
    ahora: Date = new Date(),
  ): Promise<ReporteOcupacion> {
    const { desde, hasta } = this.reportesService.resolverPeriodo(
      solicitud,
      ahora,
    );
    const bienes =
      await this.reportesService.bienesActivosDelArrendador(arrendadorId);

    // Sin bienes no hay días que contar: se evitan las dos consultas.
    const { reservas, bloqueos } =
      bienes.length === 0
        ? { reservas: [], bloqueos: [] }
        : await this.reportesRepository.intervalosDeOcupacion(
            arrendadorId,
            bienes.map((bien) => bien.id),
            desde,
            hasta,
          );

    const filas = armarOcupacion(bienes, { desde, hasta }, reservas, bloqueos);
    return {
      periodo: { desde, hasta },
      totalBienes: filas.length,
      bienes: filas,
    };
  }
}
