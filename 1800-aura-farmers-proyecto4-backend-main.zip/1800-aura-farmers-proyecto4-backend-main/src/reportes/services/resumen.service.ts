import { Injectable } from '@nestjs/common';
import {
  armarResumen,
  ESCALA_MAXIMA_CALIFICACION,
  MONEDA_REPORTE,
  type PeriodoResuelto,
  type ResumenDeBienes,
  type SolicitudPeriodo,
} from '@Reportes/utils';
import { IngresosService } from './ingresos.service.js';
import { OcupacionService } from './ocupacion.service.js';
import { ReportesService } from './reportes.service.js';

/** Resumen comparativo del arrendador en un periodo, ya armado y ordenado. */
export interface ResumenDesempeno extends ResumenDeBienes {
  periodo: PeriodoResuelto;
  moneda: typeof MONEDA_REPORTE;
  escalaMaxima: number;
}

/**
 * Resumen comparativo de desempeño (H26): ingresos, ocupación y calificación de
 * cada bien en una sola respuesta.
 *
 * No calcula nada por su cuenta: llama a los servicios de los reportes de
 * ingresos, ocupación y calificaciones y une sus filas, así que cada valor es
 * el mismo que devuelve su reporte individual.
 */
@Injectable()
export class ResumenService {
  constructor(
    private readonly reportesService: ReportesService,
    private readonly ingresosService: IngresosService,
    private readonly ocupacionService: OcupacionService,
  ) {}

  /**
   * Una fila por bien ACTIVA del arrendador, por título de la A a la Z.
   *
   * `ahora` se fija una sola vez y se pasa a los tres reportes, junto con la
   * misma solicitud, para que los tres resuelvan el mismo periodo aunque la
   * consulta cruce la medianoche. El periodo se valida antes de consultar la
   * base. El arrendador viene siempre de la sesión.
   *
   * @throws {BadRequestException} el rango no es válido (ver `resolverPeriodo`).
   */
  async resumen(
    arrendadorId: string,
    solicitud: SolicitudPeriodo,
    ahora: Date = new Date(),
  ): Promise<ResumenDesempeno> {
    const { desde, hasta } = this.reportesService.resolverPeriodo(
      solicitud,
      ahora,
    );

    const [ingresos, ocupacion, calificaciones] = await Promise.all([
      this.ingresosService.ingresos(arrendadorId, solicitud, ahora),
      this.ocupacionService.ocupacion(arrendadorId, solicitud, ahora),
      this.reportesService.calificaciones(arrendadorId, solicitud, ahora),
    ]);

    return {
      periodo: { desde, hasta },
      moneda: MONEDA_REPORTE,
      escalaMaxima: ESCALA_MAXIMA_CALIFICACION,
      ...armarResumen(ingresos.bienes, ocupacion.bienes, calificaciones.bienes),
    };
  }
}
