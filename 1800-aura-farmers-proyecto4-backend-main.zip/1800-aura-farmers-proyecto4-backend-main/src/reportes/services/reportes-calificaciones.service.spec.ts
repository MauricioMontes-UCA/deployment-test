import { BadRequestException } from '@nestjs/common';
import type { ReportesRepository } from '@Reportes/repositories';
import { PeriodoReporte } from '@Reportes/utils';
import { ReportesService } from './reportes.service.js';

const ARRENDADOR_ID = '22222222-2222-4222-8222-222222222222';
const AHORA = new Date('2026-11-15T18:00:00.000Z');

function crear(filas: unknown[] = []) {
  const calificacionesDeBienes = vi.fn().mockResolvedValue(filas);
  const service = new ReportesService({
    calificacionesDeBienes,
  } as unknown as ReportesRepository);
  return { service, calificacionesDeBienes };
}

describe('ReportesService.calificaciones', () => {
  it('consulta el periodo resuelto con el arrendador de la sesión', async () => {
    const { service, calificacionesDeBienes } = crear();

    const reporte = await service.calificaciones(ARRENDADOR_ID, {}, AHORA);

    expect(calificacionesDeBienes).toHaveBeenCalledWith(
      ARRENDADOR_ID,
      '2026-10-17',
      '2026-11-15',
    );
    expect(reporte).toEqual({
      periodo: { desde: '2026-10-17', hasta: '2026-11-15' },
      escalaMaxima: 5,
      totalBienes: 0,
      bienes: [],
    });
  });

  it('ordena los bienes y los cuenta', async () => {
    const { service } = crear([
      { bienId: '1', titulo: 'Bien 1', promedio: 4.5, totalResenas: 2 },
      { bienId: '3', titulo: 'Bien 3', promedio: null, totalResenas: 0 },
      { bienId: '4', titulo: 'Bien 4', promedio: 3, totalResenas: 1 },
      { bienId: '2', titulo: 'Bien 2', promedio: null, totalResenas: 0 },
    ]);

    const reporte = await service.calificaciones(ARRENDADOR_ID, {}, AHORA);

    expect(reporte.totalBienes).toBe(4);
    expect(reporte.bienes.map((b) => b.titulo)).toEqual([
      'Bien 4',
      'Bien 1',
      'Bien 2',
      'Bien 3',
    ]);
  });

  it('con RANGO usa las fechas recibidas', async () => {
    const { service, calificacionesDeBienes } = crear();

    await service.calificaciones(
      ARRENDADOR_ID,
      {
        periodo: PeriodoReporte.RANGO,
        desde: '2026-01-01',
        hasta: '2026-12-31',
      },
      AHORA,
    );

    expect(calificacionesDeBienes).toHaveBeenCalledWith(
      ARRENDADOR_ID,
      '2026-01-01',
      '2026-12-31',
    );
  });

  it('un rango inválido da 400 sin consultar la base', async () => {
    const { service, calificacionesDeBienes } = crear();

    await expect(
      service.calificaciones(
        ARRENDADOR_ID,
        { periodo: PeriodoReporte.RANGO, desde: '2026-01-01' },
        AHORA,
      ),
    ).rejects.toThrow(BadRequestException);
    expect(calificacionesDeBienes).not.toHaveBeenCalled();
  });
});
