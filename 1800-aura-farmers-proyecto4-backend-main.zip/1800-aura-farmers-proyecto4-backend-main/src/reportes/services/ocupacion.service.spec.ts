import { BadRequestException } from '@nestjs/common';
import type { ReportesRepository } from '@Reportes/repositories';
import { PeriodoReporte } from '@Reportes/utils';
import { OcupacionService } from './ocupacion.service.js';
import { ReportesService } from './reportes.service.js';

const ARRENDADOR_ID = '22222222-2222-4222-8222-222222222222';
const AHORA = new Date('2026-11-15T18:00:00.000Z');

function crear(bienes: { id: string; titulo: string }[]) {
  const bienesActivosDelArrendador = vi.fn().mockResolvedValue(bienes);
  const intervalosDeOcupacion = vi
    .fn()
    .mockResolvedValue({ reservas: [], bloqueos: [] });
  const repositorio = {
    bienesActivosDelArrendador,
    intervalosDeOcupacion,
  } as unknown as ReportesRepository;
  const service = new OcupacionService(
    new ReportesService(repositorio),
    repositorio,
  );
  return { service, bienesActivosDelArrendador, intervalosDeOcupacion };
}

describe('OcupacionService.ocupacion', () => {
  it('consulta los días de los bienes del arrendador en el periodo resuelto', async () => {
    const { service, bienesActivosDelArrendador, intervalosDeOcupacion } =
      crear([
        { id: 'b1', titulo: 'Salón' },
        { id: 'b2', titulo: 'Casa' },
      ]);

    const reporte = await service.ocupacion(ARRENDADOR_ID, {}, AHORA);

    expect(bienesActivosDelArrendador).toHaveBeenCalledWith(ARRENDADOR_ID);
    expect(intervalosDeOcupacion).toHaveBeenCalledWith(
      ARRENDADOR_ID,
      ['b1', 'b2'],
      '2026-10-17',
      '2026-11-15',
    );
    expect(reporte.periodo).toEqual({
      desde: '2026-10-17',
      hasta: '2026-11-15',
    });
    expect(reporte.totalBienes).toBe(2);
    expect(reporte.bienes.every((b) => b.tasaOcupacion === 0)).toBe(true);
  });

  it('sin bienes no consulta reservas ni bloqueos', async () => {
    const { service, intervalosDeOcupacion } = crear([]);

    const reporte = await service.ocupacion(ARRENDADOR_ID, {}, AHORA);

    expect(intervalosDeOcupacion).not.toHaveBeenCalled();
    expect(reporte).toEqual({
      periodo: { desde: '2026-10-17', hasta: '2026-11-15' },
      totalBienes: 0,
      bienes: [],
    });
  });

  it('un rango inválido da 400 sin consultar la base', async () => {
    const { service, bienesActivosDelArrendador } = crear([]);

    await expect(
      service.ocupacion(
        ARRENDADOR_ID,
        {
          periodo: PeriodoReporte.RANGO,
          desde: '2026-01-01',
          hasta: '2027-01-01',
        },
        AHORA,
      ),
    ).rejects.toThrow(BadRequestException);
    expect(bienesActivosDelArrendador).not.toHaveBeenCalled();
  });
});
