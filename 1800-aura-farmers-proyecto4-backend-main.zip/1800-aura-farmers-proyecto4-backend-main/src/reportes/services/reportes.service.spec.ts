import { BadRequestException } from '@nestjs/common';
import type { ReportesRepository } from '@Reportes/repositories';
import { PeriodoReporte } from '@Reportes/utils';
import { ReportesService } from './reportes.service.js';

function crear() {
  const bienesActivosDelArrendador = vi.fn().mockResolvedValue([]);
  const service = new ReportesService({
    bienesActivosDelArrendador,
  } as unknown as ReportesRepository);
  return { service, bienesActivosDelArrendador };
}

describe('ReportesService.resolverPeriodo', () => {
  it('usa el último mes por defecto y lo informa', () => {
    const { service } = crear();

    expect(
      service.resolverPeriodo({}, new Date('2026-11-15T18:00:00.000Z')),
    ).toEqual({
      periodo: PeriodoReporte.ULTIMO_MES,
      desde: '2026-10-17',
      hasta: '2026-11-15',
    });
  });

  it('devuelve el periodo pedido', () => {
    const { service } = crear();

    expect(
      service.resolverPeriodo(
        { periodo: PeriodoReporte.ULTIMOS_3_MESES },
        new Date('2026-11-15T18:00:00.000Z'),
      ),
    ).toMatchObject({
      periodo: PeriodoReporte.ULTIMOS_3_MESES,
      desde: '2026-08-18',
      hasta: '2026-11-15',
    });
  });

  it('calcula "hoy" en El Salvador, no en UTC', () => {
    const { service } = crear();

    // 03:00 UTC del 16 todavía es 21:00 del 15 en El Salvador (UTC-6).
    const antesDeMedianoche = service.resolverPeriodo(
      {},
      new Date('2026-11-16T03:00:00.000Z'),
    );
    // 06:00 UTC del 16 ya es medianoche del 16 en El Salvador.
    const despues = service.resolverPeriodo(
      {},
      new Date('2026-11-16T06:00:00.000Z'),
    );

    expect(antesDeMedianoche.hasta).toBe('2026-11-15');
    expect(despues.hasta).toBe('2026-11-16');
  });

  it('propaga el 400 de un rango inválido', () => {
    const { service } = crear();

    expect(() =>
      service.resolverPeriodo({ periodo: PeriodoReporte.RANGO }),
    ).toThrow(new BadRequestException('Completa las fechas del rango.'));
  });
});

describe('ReportesService.bienesActivosDelArrendador', () => {
  it('delega en el repositorio con el id del arrendador', async () => {
    const { service, bienesActivosDelArrendador } = crear();
    const bienes = [{ id: 'bien-1', titulo: 'Casa' }];
    bienesActivosDelArrendador.mockResolvedValue(bienes);

    await expect(
      service.bienesActivosDelArrendador('arrendador-1'),
    ).resolves.toBe(bienes);
    expect(bienesActivosDelArrendador).toHaveBeenCalledWith('arrendador-1');
  });

  it('devuelve una lista vacía si el arrendador no tiene bienes activos', async () => {
    const { service } = crear();

    await expect(
      service.bienesActivosDelArrendador('arrendador-1'),
    ).resolves.toEqual([]);
  });
});
