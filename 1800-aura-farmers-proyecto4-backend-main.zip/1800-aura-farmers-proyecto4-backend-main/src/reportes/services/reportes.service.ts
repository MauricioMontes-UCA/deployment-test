import { Injectable } from '@nestjs/common';
import { hoyEn, ZONA_HORARIA } from '@Bienes/utils';
import { ReportesRepository, type BienDeReporte } from '@Reportes/repositories';
import {
  ESCALA_MAXIMA_CALIFICACION,
  ordenarCalificaciones,
  PERIODO_POR_DEFECTO,
  type CalificacionDeBien,
  resolverPeriodo,
  type PeriodoReporte,
  type PeriodoResuelto,
  type SolicitudPeriodo,
} from '@Reportes/utils';

/**
 * Reglas comunes de los reportes del arrendador: el periodo y sus bienes.
 *
 * Los reportes de ingresos, ocupación, calificaciones y resumen parten de aquí
 * para compartir las mismas fechas y el mismo filtro por arrendador.
 */
@Injectable()
export class ReportesService {
  constructor(private readonly reportesRepository: ReportesRepository) {}

  /**
   * Convierte el periodo pedido en fechas, con "hoy" en la zona de El Salvador.
   * `ahora` se recibe para poder probar el cambio de día.
   *
   * @throws {BadRequestException} el rango no es válido (ver `resolverPeriodo`).
   */
  resolverPeriodo(
    solicitud: SolicitudPeriodo,
    ahora: Date = new Date(),
  ): PeriodoResuelto & { periodo: PeriodoReporte } {
    return {
      periodo: solicitud.periodo ?? PERIODO_POR_DEFECTO,
      ...resolverPeriodo(solicitud, hoyEn(ZONA_HORARIA, ahora)),
    };
  }

  /** Bienes ACTIVA del arrendador de la sesión; lista vacía si no tiene. */
  bienesActivosDelArrendador(arrendadorId: string): Promise<BienDeReporte[]> {
    return this.reportesRepository.bienesActivosDelArrendador(arrendadorId);
  }

  /**
   * Reporte de calificaciones (H25): promedio y número de reseñas de cada bien
   * ACTIVA del arrendador en el periodo, de la peor calificación a la mejor y
   * con los bienes sin calificaciones al final.
   *
   * @throws {BadRequestException} el rango no es válido (ver `resolverPeriodo`).
   */
  async calificaciones(
    arrendadorId: string,
    solicitud: SolicitudPeriodo,
    ahora: Date = new Date(),
  ): Promise<ReporteCalificaciones> {
    const { desde, hasta } = this.resolverPeriodo(solicitud, ahora);
    const bienes = ordenarCalificaciones(
      await this.reportesRepository.calificacionesDeBienes(
        arrendadorId,
        desde,
        hasta,
      ),
    );
    return {
      periodo: { desde, hasta },
      escalaMaxima: ESCALA_MAXIMA_CALIFICACION,
      totalBienes: bienes.length,
      bienes,
    };
  }
}

export interface ReporteCalificaciones {
  periodo: PeriodoResuelto;
  escalaMaxima: number;
  totalBienes: number;
  bienes: CalificacionDeBien[];
}
