import { BadRequestException } from '@nestjs/common';
import type { ReportesRepository } from '@Reportes/repositories';
import { PeriodoReporte } from '@Reportes/utils';
import type { IngresosService } from './ingresos.service.js';
import type { OcupacionService } from './ocupacion.service.js';
import { ReportesService } from './reportes.service.js';
import { ResumenService } from './resumen.service.js';

const AHORA = new Date('2026-11-15T18:00:00.000Z');
const PERIODO = { desde: '2026-10-17', hasta: '2026-11-15' };

/**
 * El periodo se resuelve con el `ReportesService` real; los tres reportes son
 * dobles para ver con qué se llaman y qué se une.
 */
function crear() {
  const reportes = new ReportesService({} as ReportesRepository);
  const calificaciones = vi
    .spyOn(reportes, 'calificaciones')
    .mockResolvedValue({
      periodo: PERIODO,
      escalaMaxima: 5,
      totalBienes: 2,
      bienes: [
        { bienId: 'b2', titulo: 'Taladro', promedio: null, totalResenas: 0 },
        { bienId: 'b1', titulo: 'Salón', promedio: 4.5, totalResenas: 2 },
      ],
    });
  const ingresos = vi.fn().mockResolvedValue({
    periodo: PERIODO,
    totalIngresos: 250,
    totalDepositoRetenido: 50,
    totalBienes: 2,
    bienes: [
      { bienId: 'b1', titulo: 'Salón', ingresos: 250, depositoRetenido: 50 },
      { bienId: 'b2', titulo: 'Taladro', ingresos: 0, depositoRetenido: 0 },
    ],
  });
  const ocupacion = vi.fn().mockResolvedValue({
    periodo: PERIODO,
    totalBienes: 2,
    bienes: [
      {
        bienId: 'b1',
        titulo: 'Salón',
        diasDisponibles: 30,
        diasOcupados: 15,
        tasaOcupacion: 50,
      },
      {
        bienId: 'b2',
        titulo: 'Taladro',
        diasDisponibles: 0,
        diasOcupados: 0,
        tasaOcupacion: null,
      },
    ],
  });
  const service = new ResumenService(
    reportes,
    { ingresos } as unknown as IngresosService,
    { ocupacion } as unknown as OcupacionService,
  );
  return { service, ingresos, ocupacion, calificaciones };
}

describe('ResumenService.resumen', () => {
  it('arma el resumen con el periodo, la moneda, la escala y una fila por bien', async () => {
    const { service } = crear();

    await expect(service.resumen('arr-1', {}, AHORA)).resolves.toEqual({
      periodo: PERIODO,
      moneda: 'USD',
      escalaMaxima: 5,
      totalBienes: 2,
      bienes: [
        {
          bienId: 'b1',
          titulo: 'Salón',
          ingresos: 250,
          tasaOcupacion: 50,
          calificacionPromedio: 4.5,
          totalResenas: 2,
        },
        {
          bienId: 'b2',
          titulo: 'Taladro',
          ingresos: 0,
          tasaOcupacion: null,
          calificacionPromedio: null,
          totalResenas: 0,
        },
      ],
    });
  });

  it('pide los tres reportes con el mismo arrendador, la misma solicitud y el mismo instante', async () => {
    const { service, ingresos, ocupacion, calificaciones } = crear();
    const solicitud = {
      periodo: PeriodoReporte.RANGO,
      desde: '2026-01-01',
      hasta: '2026-03-31',
    };

    const resumen = await service.resumen('arr-1', solicitud, AHORA);

    for (const reporte of [ingresos, ocupacion, calificaciones]) {
      expect(reporte).toHaveBeenCalledTimes(1);
      expect(reporte).toHaveBeenCalledWith('arr-1', solicitud, AHORA);
    }
    expect(resumen.periodo).toEqual({
      desde: '2026-01-01',
      hasta: '2026-03-31',
    });
  });

  it('sin `ahora` usa un único instante para los tres reportes', async () => {
    const { service, ingresos, ocupacion, calificaciones } = crear();

    await service.resumen('arr-1', {});

    const instante = ingresos.mock.calls[0][2] as Date;
    expect(instante).toBeInstanceOf(Date);
    expect(ocupacion.mock.calls[0][2]).toBe(instante);
    expect(calificaciones.mock.calls[0][2]).toBe(instante);
  });

  it('con un rango inválido responde 400 sin consultar ningún reporte', async () => {
    const { service, ingresos, ocupacion, calificaciones } = crear();

    await expect(
      service.resumen(
        'arr-1',
        {
          periodo: PeriodoReporte.RANGO,
          desde: '2025-01-01',
          hasta: '2026-01-01',
        },
        AHORA,
      ),
    ).rejects.toThrow(
      new BadRequestException('El rango no puede ser mayor a 365 días.'),
    );
    expect(ingresos).not.toHaveBeenCalled();
    expect(ocupacion).not.toHaveBeenCalled();
    expect(calificaciones).not.toHaveBeenCalled();
  });
});
