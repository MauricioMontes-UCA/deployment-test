/**
 * Ruta pública desde la que se sirven los archivos de `UPLOADS_DIR`.
 *
 * Queda fuera del prefijo /api/v1 porque no es parte de la API: son archivos
 * estáticos. Una foto guardada en `<UPLOADS_DIR>/bienes/<id>/1.jpg` se pide en
 * `/uploads/bienes/<id>/1.jpg`.
 */
export const UPLOADS_URL_PREFIX = '/uploads';
