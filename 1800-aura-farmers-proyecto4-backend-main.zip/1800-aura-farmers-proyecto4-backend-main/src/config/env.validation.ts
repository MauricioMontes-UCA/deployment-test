/**
 * Validación de variables de entorno.
 *
 * Se ejecuta durante el arranque de ConfigModule: si falta algo o tiene un
 * valor inválido, la aplicación falla de inmediato con un mensaje claro en
 * lugar de reventar más tarde con un error críptico en la primera request.
 */

export interface EnvConfig {
  NODE_ENV: string;
  PORT: number;
  DATABASE_URL: string;
  JWT_SECRET: string;
  JWT_EXPIRES_IN: string;
  REFRESH_TOKEN_EXPIRES_IN_DAYS: number;
  BCRYPT_SALT_ROUNDS: number;
  /** Carpeta donde se guardan los archivos subidos, como las fotos de los bienes. */
  UPLOADS_DIR: string;
  /** Milisegundos que tarda la pasarela simulada en responder (H8). */
  PAGO_SIMULADO_DEMORA_MS: number;
  /** Si este proceso consume la cola de solicitudes de reserva (BE-6.2). */
  COLA_RESERVAS_ACTIVA: boolean;
  /** Cada cuántos milisegundos se revisa la cola, además de al encolar. */
  COLA_RESERVAS_INTERVALO_MS: number;
  PLAZO_DEVOLUCION_DIAS: number;
  PLAZO_DEPOSITO_DIAS: number;
  TAREA_RESERVAS_ACTIVA: boolean;
  /**
   * Si este proceso ejecuta la revisión simulada de documentos (BE-18.1).
   * Activa por defecto fuera de las pruebas; se apaga con "false". Siempre es
   * false con NODE_ENV=test.
   */
  REVISION_VERIFICACION_ACTIVA: boolean;
  /**
   * Orígenes que el navegador puede usar para llamar a la API (CORS), por
   * ejemplo la URL del frontend desplegado (H28).
   */
  CORS_ORIGINS: string[];
}

/** Origen del frontend local (`npm run dev -- -p 5173`). */
export const CORS_ORIGIN_DESARROLLO = 'http://localhost:5173';

const requiredVars = ['DATABASE_URL', 'JWT_SECRET'] as const;

/**
 * Lee una variable como string. process.env siempre entrega strings, pero el
 * objeto llega tipado como `unknown`, así que se valida en vez de castear.
 */
function readString(
  raw: Record<string, unknown>,
  key: string,
  fallback: string,
): string {
  const value = raw[key];
  if (value === undefined || value === '') return fallback;

  if (typeof value !== 'string') {
    throw new Error(`La variable de entorno ${key} debe ser un string.`);
  }
  return value;
}

function readInt(
  raw: Record<string, unknown>,
  key: string,
  fallback: number,
  { permitirCero = false }: { permitirCero?: boolean } = {},
): number {
  const value = raw[key];
  if (value === undefined || value === '') return fallback;

  const parsed = Number(value);
  const minimo = permitirCero ? 0 : 1;
  if (!Number.isInteger(parsed) || parsed < minimo) {
    throw new Error(
      permitirCero
        ? `La variable de entorno ${key} debe ser un entero mayor o igual a 0.`
        : `La variable de entorno ${key} debe ser un entero positivo.`,
    );
  }
  return parsed;
}

function readBool(
  raw: Record<string, unknown>,
  key: string,
  fallback: boolean,
): boolean {
  const value = raw[key];
  if (value === undefined || value === '') return fallback;
  if (value === 'true') return true;
  if (value === 'false') return false;
  throw new Error(`La variable de entorno ${key} debe ser true o false.`);
}

/**
 * Lee CORS_ORIGINS: una lista de orígenes separados por coma. Cada uno se
 * recorta y pierde la barra final, porque el navegador envía el encabezado
 * Origin sin ella y la comparación es exacta.
 *
 * Solo acepta orígenes http(s) sin ruta: `*` abriría la API a cualquier sitio
 * y un valor con ruta nunca coincidiría con el Origin del navegador.
 */
function readOrigenes(
  raw: Record<string, unknown>,
  key: string,
  nodeEnv: string,
): string[] {
  const value = readString(raw, key, '');
  const origenes = value
    .split(',')
    .map((origen) => origen.trim().replace(/\/+$/, ''))
    .filter((origen) => origen !== '');

  if (origenes.length === 0) {
    if (nodeEnv === 'production') {
      throw new Error(
        `La variable de entorno ${key} es obligatoria en producción. ` +
          'Indicá la URL del frontend desplegado, por ejemplo https://mi-frontend.com',
      );
    }
    return [CORS_ORIGIN_DESARROLLO];
  }

  for (const origen of origenes) {
    if (!esOrigenValido(origen)) {
      throw new Error(
        `La variable de entorno ${key} tiene un origen inválido: "${origen}". ` +
          'Cada origen debe ser una URL http(s) sin ruta, por ejemplo https://mi-frontend.com',
      );
    }
  }
  return [...new Set(origenes)];
}

function esOrigenValido(origen: string): boolean {
  let url: URL;
  try {
    url = new URL(origen);
  } catch {
    return false;
  }
  // URL.origin es protocolo, host y puerto: si difiere del valor, el valor
  // traía ruta, query, credenciales o mayúsculas que el navegador no envía.
  return (
    (url.protocol === 'http:' || url.protocol === 'https:') &&
    url.origin === origen
  );
}

export function validateEnv(raw: Record<string, unknown>): EnvConfig {
  const missing = requiredVars.filter((key) => !raw[key]);
  if (missing.length > 0) {
    throw new Error(
      `Faltan variables de entorno obligatorias: ${missing.join(', ')}. ` +
        'Copiá .env.example a .env y completalas.',
    );
  }

  const jwtSecret = readString(raw, 'JWT_SECRET', '');
  if (jwtSecret.length < 32) {
    throw new Error(
      'JWT_SECRET debe tener al menos 32 caracteres. Generá uno con: openssl rand -base64 32',
    );
  }

  const nodeEnv = readString(raw, 'NODE_ENV', 'development');

  return {
    NODE_ENV: nodeEnv,
    PORT: readInt(raw, 'PORT', 3000),
    DATABASE_URL: readString(raw, 'DATABASE_URL', ''),
    JWT_SECRET: jwtSecret,
    JWT_EXPIRES_IN: readString(raw, 'JWT_EXPIRES_IN', '15m'),
    REFRESH_TOKEN_EXPIRES_IN_DAYS: readInt(raw, 'REFRESH_TOKEN_EXPIRES_IN_DAYS', 7),
    BCRYPT_SALT_ROUNDS: readInt(raw, 'BCRYPT_SALT_ROUNDS', 12),
    UPLOADS_DIR: readString(raw, 'UPLOADS_DIR', 'uploads'),
    // 0 desactiva la espera, por ejemplo en las pruebas.
    PAGO_SIMULADO_DEMORA_MS: readInt(raw, 'PAGO_SIMULADO_DEMORA_MS', 2000, {
      permitirCero: true,
    }),
    // Apagada por defecto en las pruebas, para que el barrido no procese las
    // solicitudes que otras pruebas dejan en cola a propósito.
    COLA_RESERVAS_ACTIVA: readBool(
      raw,
      'COLA_RESERVAS_ACTIVA',
      nodeEnv !== 'test',
    ),
    COLA_RESERVAS_INTERVALO_MS: readInt(
      raw,
      'COLA_RESERVAS_INTERVALO_MS',
      30_000,
    ),
    PLAZO_DEVOLUCION_DIAS: readInt(raw, 'PLAZO_DEVOLUCION_DIAS', 3),
    PLAZO_DEPOSITO_DIAS: readInt(raw, 'PLAZO_DEPOSITO_DIAS', 3),
    TAREA_RESERVAS_ACTIVA: readBool(raw, 'TAREA_RESERVAS_ACTIVA', nodeEnv !== 'test'),
    // Activa por defecto fuera de las pruebas, como la cola y la tarea de
    // reservas: sin ella, los documentos quedarían EN_REVISION. Se apaga con
    // false. Con NODE_ENV=test queda apagada aunque la variable diga true: la
    // revisión resolvería las solicitudes que las pruebas dejan EN_REVISION a
    // propósito. El valor se valida igual.
    REVISION_VERIFICACION_ACTIVA:
      readBool(raw, 'REVISION_VERIFICACION_ACTIVA', nodeEnv !== 'test') &&
      nodeEnv !== 'test',
    CORS_ORIGINS: readOrigenes(raw, 'CORS_ORIGINS', nodeEnv),
  };
}
