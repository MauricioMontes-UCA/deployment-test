import { CORS_ORIGIN_DESARROLLO, validateEnv } from './env.validation.js';

/** Lo mínimo que exige validateEnv. */
const base = {
  DATABASE_URL: 'postgresql://u:p@localhost:5432/db',
  JWT_SECRET: 'x'.repeat(32),
};

const origenes = (raw: Record<string, unknown>) =>
  validateEnv({ ...base, ...raw }).CORS_ORIGINS;

describe('validateEnv: CORS_ORIGINS', () => {
  it('sin definir o vacía usa el frontend local fuera de producción', () => {
    expect(origenes({})).toEqual([CORS_ORIGIN_DESARROLLO]);
    expect(origenes({ NODE_ENV: 'development' })).toEqual([
      CORS_ORIGIN_DESARROLLO,
    ]);
    expect(origenes({ NODE_ENV: 'test', CORS_ORIGINS: '' })).toEqual([
      CORS_ORIGIN_DESARROLLO,
    ]);
    expect(origenes({ NODE_ENV: 'development', CORS_ORIGINS: ' , ' })).toEqual([
      CORS_ORIGIN_DESARROLLO,
    ]);
  });

  it('en producción es obligatoria', () => {
    expect(() => origenes({ NODE_ENV: 'production' })).toThrow(
      /CORS_ORIGINS es obligatoria en producción/,
    );
    expect(() =>
      origenes({ NODE_ENV: 'production', CORS_ORIGINS: '  ' }),
    ).toThrow(/CORS_ORIGINS es obligatoria en producción/);
  });

  it('acepta un origen en producción', () => {
    expect(
      origenes({
        NODE_ENV: 'production',
        CORS_ORIGINS: 'https://aura-farmers.example.com',
      }),
    ).toEqual(['https://aura-farmers.example.com']);
  });

  it('separa por coma, recorta, quita la barra final y los duplicados', () => {
    expect(
      origenes({
        CORS_ORIGINS:
          ' https://app.example.com/ ,http://localhost:5173,, https://app.example.com',
      }),
    ).toEqual(['https://app.example.com', 'http://localhost:5173']);
  });

  it('acepta un puerto explícito', () => {
    expect(origenes({ CORS_ORIGINS: 'http://127.0.0.1:8080' })).toEqual([
      'http://127.0.0.1:8080',
    ]);
  });

  it.each([
    ['comodín', '*'],
    ['sin protocolo', 'app.example.com'],
    ['protocolo que no es http(s)', 'ftp://app.example.com'],
    ['con ruta', 'https://app.example.com/inicio'],
    ['con query', 'https://app.example.com?x=1'],
    ['con credenciales', 'https://user:pass@app.example.com'],
    ['con mayúsculas', 'https://App.example.com'],
    ['uno válido y uno inválido', 'https://app.example.com,nope'],
  ])('rechaza un origen %s', (_caso, valor) => {
    expect(() => origenes({ CORS_ORIGINS: valor })).toThrow(
      /CORS_ORIGINS tiene un origen inválido/,
    );
  });

  it('rechaza un valor que no es string', () => {
    expect(() => origenes({ CORS_ORIGINS: 123 })).toThrow(
      /CORS_ORIGINS debe ser un string/,
    );
  });
});
