import { validateEnv } from './env.validation.js';

/** Lo mínimo que exige validateEnv, también con NODE_ENV=production. */
const base = {
  DATABASE_URL: 'postgresql://u:p@localhost:5432/db',
  JWT_SECRET: 'x'.repeat(32),
  CORS_ORIGINS: 'https://app.example.com',
};

const activa = (raw: Record<string, unknown>) =>
  validateEnv({ ...base, ...raw }).REVISION_VERIFICACION_ACTIVA;

describe('validateEnv: REVISION_VERIFICACION_ACTIVA', () => {
  it('sin definir queda activa fuera de las pruebas', () => {
    expect(activa({ NODE_ENV: 'development' })).toBe(true);
    expect(activa({ NODE_ENV: 'production' })).toBe(true);
    // Sin NODE_ENV se toma development.
    expect(activa({})).toBe(true);
  });

  it('vacía queda activa fuera de las pruebas', () => {
    expect(
      activa({ NODE_ENV: 'development', REVISION_VERIFICACION_ACTIVA: '' }),
    ).toBe(true);
    expect(
      activa({ NODE_ENV: 'production', REVISION_VERIFICACION_ACTIVA: '' }),
    ).toBe(true);
  });

  it('con NODE_ENV=test queda apagada sin definir o vacía', () => {
    expect(activa({ NODE_ENV: 'test' })).toBe(false);
    expect(activa({ NODE_ENV: 'test', REVISION_VERIFICACION_ACTIVA: '' })).toBe(
      false,
    );
  });

  it('con false queda apagada', () => {
    expect(
      activa({ NODE_ENV: 'production', REVISION_VERIFICACION_ACTIVA: 'false' }),
    ).toBe(false);
    expect(
      activa({
        NODE_ENV: 'development',
        REVISION_VERIFICACION_ACTIVA: 'false',
      }),
    ).toBe(false);
  });

  it('con true fuera de las pruebas queda activa', () => {
    expect(
      activa({ NODE_ENV: 'development', REVISION_VERIFICACION_ACTIVA: 'true' }),
    ).toBe(true);
    expect(
      activa({ NODE_ENV: 'production', REVISION_VERIFICACION_ACTIVA: 'true' }),
    ).toBe(true);
    // Sin NODE_ENV se toma development.
    expect(activa({ REVISION_VERIFICACION_ACTIVA: 'true' })).toBe(true);
  });

  it('con NODE_ENV=test queda apagada aunque la variable diga true', () => {
    expect(
      activa({ NODE_ENV: 'test', REVISION_VERIFICACION_ACTIVA: 'true' }),
    ).toBe(false);
  });

  it.each(['si', 'TRUE', '1', 'yes'])(
    'rechaza un valor que no sea true o false (%s)',
    (valor) => {
      expect(() => activa({ REVISION_VERIFICACION_ACTIVA: valor })).toThrow(
        'REVISION_VERIFICACION_ACTIVA debe ser true o false.',
      );
    },
  );

  it('rechaza un valor inválido también con NODE_ENV=test', () => {
    expect(() =>
      activa({ NODE_ENV: 'test', REVISION_VERIFICACION_ACTIVA: 'si' }),
    ).toThrow('REVISION_VERIFICACION_ACTIVA debe ser true o false.');
  });

  it('no cambia la configuración de la cola de reservas', () => {
    expect(
      validateEnv({ ...base, NODE_ENV: 'test' }).COLA_RESERVAS_ACTIVA,
    ).toBe(false);
    expect(
      validateEnv({ ...base, NODE_ENV: 'development' }).COLA_RESERVAS_ACTIVA,
    ).toBe(true);
  });

  it('no cambia la configuración de la tarea diaria de reservas (H10)', () => {
    expect(
      validateEnv({ ...base, NODE_ENV: 'test' }).TAREA_RESERVAS_ACTIVA,
    ).toBe(false);
    expect(
      validateEnv({ ...base, NODE_ENV: 'production' }).TAREA_RESERVAS_ACTIVA,
    ).toBe(true);
    expect(
      validateEnv({
        ...base,
        NODE_ENV: 'production',
        REVISION_VERIFICACION_ACTIVA: 'false',
      }).TAREA_RESERVAS_ACTIVA,
    ).toBe(true);
  });
});
