import {
  EstadoNotificacion,
  ModuloOrigen,
} from '@PrismaClient';
import type { NotificacionesRepository } from '@Notificaciones/repositories';
import { NotificacionesService } from './notificaciones.service.js';

const usuarioId = '11111111-1111-4111-8111-111111111111';

const crearNotificacion = (
  id: string,
  estado: EstadoNotificacion,
  fecha: string,
) => ({
  id,
  titulo: `Notificación ${id}`,
  mensaje: 'Mensaje de prueba',
  estado,
  moduloOrigen: ModuloOrigen.RESERVAS,
  creadaEn: new Date(fecha),
});

const crearRepositorio = () => ({
  listarPorUsuario: vi.fn(),
});

describe('BE-21.1 - NotificacionesService.listarMias', () => {
  it('utiliza la página 1 y tamaño fijo de 20 por defecto', async () => {
    const repo = crearRepositorio();

    repo.listarPorUsuario.mockResolvedValue({
      notificaciones: [],
      total: 0,
      noLeidas: 0,
    });

    const servicio = new NotificacionesService(
      repo as unknown as NotificacionesRepository,
    );

    const resultado = await servicio.listarMias(usuarioId);

    expect(repo.listarPorUsuario).toHaveBeenCalledWith(
      usuarioId,
      1,
      20,
    );

    expect(resultado).toEqual({
      noLeidas: 0,
      total: 0,
      pagina: 1,
      tamanoPagina: 20,
      notificaciones: [],
    });
  });

  it('mantiene el conteo global de no leídas', async () => {
    const repo = crearRepositorio();

    repo.listarPorUsuario.mockResolvedValue({
      notificaciones: [
        crearNotificacion(
          'aviso-1',
          EstadoNotificacion.LEIDA,
          '2026-11-14T10:00:00.000Z',
        ),
      ],
      total: 25,
      noLeidas: 3,
    });

    const servicio = new NotificacionesService(
      repo as unknown as NotificacionesRepository,
    );

    const resultado = await servicio.listarMias(
      usuarioId,
      2,
    );

    expect(resultado.noLeidas).toBe(3);
    expect(resultado.total).toBe(25);
    expect(resultado.pagina).toBe(2);
    expect(resultado.tamanoPagina).toBe(20);

    expect(repo.listarPorUsuario).toHaveBeenCalledWith(
      usuarioId,
      2,
      20,
    );
  });

  it('conserva el orden recibido y convierte las fechas a ISO 8601', async () => {
    const repo = crearRepositorio();

    repo.listarPorUsuario.mockResolvedValue({
      notificaciones: [
        crearNotificacion(
          'aviso-reciente',
          EstadoNotificacion.NO_LEIDA,
          '2026-11-14T18:00:00.000Z',
        ),
        crearNotificacion(
          'aviso-antiguo',
          EstadoNotificacion.LEIDA,
          '2026-11-13T18:00:00.000Z',
        ),
      ],
      total: 2,
      noLeidas: 1,
    });

    const servicio = new NotificacionesService(
      repo as unknown as NotificacionesRepository,
    );

    const resultado = await servicio.listarMias(
      usuarioId,
      1,
    );

    expect(
      resultado.notificaciones.map((aviso) => aviso.id),
    ).toEqual([
      'aviso-reciente',
      'aviso-antiguo',
    ]);

    expect(resultado.notificaciones[0].creadaEn).toBe(
      '2026-11-14T18:00:00.000Z',
    );

    expect(resultado.notificaciones[0].estado).toBe(
      EstadoNotificacion.NO_LEIDA,
    );
  });

  it('no expone campos internos de las notificaciones', async () => {
    const repo = crearRepositorio();

    repo.listarPorUsuario.mockResolvedValue({
      notificaciones: [
        {
          ...crearNotificacion(
            'aviso-1',
            EstadoNotificacion.NO_LEIDA,
            '2026-11-14T18:00:00.000Z',
          ),
          destinatarioId: usuarioId,
          tipoReferencia: 'RESERVA',
          referenciaId: 'referencia-privada',
        },
      ],
      total: 1,
      noLeidas: 1,
    });

    const servicio = new NotificacionesService(
      repo as unknown as NotificacionesRepository,
    );

    const resultado = await servicio.listarMias(usuarioId);

    expect(Object.keys(resultado.notificaciones[0]).sort())
      .toEqual([
        'creadaEn',
        'estado',
        'id',
        'mensaje',
        'moduloOrigen',
        'titulo',
      ]);

    expect(resultado.notificaciones[0])
      .not.toHaveProperty('destinatarioId');

    expect(resultado.notificaciones[0])
      .not.toHaveProperty('referenciaId');
  });
});
