import { ModuloOrigen } from '@PrismaClient';
import { NotificacionDomainError } from '@Notificaciones/errors';
import type { NotificacionesRepository } from '@Notificaciones/repositories';
import { NotificacionesService } from './notificaciones.service.js';

const destinatarioId = '11111111-1111-4111-8111-111111111111';
const crearRepo = () => ({
  destinatarioActivo: vi.fn().mockResolvedValue(true),
  crear: vi.fn().mockResolvedValue({ creada: true, notificacionId: 'aviso-1' }),
});
const parametros = [destinatarioId, 'Título', 'Mensaje', ModuloOrigen.RESERVAS] as const;

describe('NotificacionesService.crear', () => {
  it('crea aviso NO_LEIDA mediante repositorio y retorna id', async () => {
    const repo = crearRepo();
    const resultado = await new NotificacionesService(repo as unknown as NotificacionesRepository).crear(...parametros);
    expect(resultado).toEqual({ creada: true, notificacionId: 'aviso-1' });
    expect(repo.crear).toHaveBeenCalledWith(expect.objectContaining({ destinatarioId, moduloOrigen: ModuloOrigen.RESERVAS }));
  });

  it.each([
    ['DESTINATARIO_REQUERIDO', '', 'Título', 'Mensaje', ModuloOrigen.RESERVAS, undefined],
    ['TITULO_REQUERIDO', destinatarioId, '  ', 'Mensaje', ModuloOrigen.RESERVAS, undefined],
    ['TITULO_MUY_LARGO', destinatarioId, 'a'.repeat(101), 'Mensaje', ModuloOrigen.RESERVAS, undefined],
    ['MENSAJE_MUY_LARGO', destinatarioId, 'Título', 'a'.repeat(301), ModuloOrigen.RESERVAS, undefined],
    ['MODULO_ORIGEN_INVALIDO', destinatarioId, 'Título', 'Mensaje', 'OTRO', undefined],
    ['REFERENCIA_INCOMPLETA', destinatarioId, 'Título', 'Mensaje', ModuloOrigen.RESERVAS, { tipoReferencia: 'RESERVA', referenciaId: '' }],
    ['REFERENCIA_INCOMPLETA', destinatarioId, 'Título', 'Mensaje', ModuloOrigen.RESERVAS, { tipoReferencia: '', referenciaId: 'abc' }],
  ])('rechaza %s sin escribir', async (codigo, id, titulo, mensaje, modulo, referencia) => {
    const repo = crearRepo();
    const servicio = new NotificacionesService(repo as unknown as NotificacionesRepository);
    await expect(servicio.crear(id as string, titulo as string, mensaje as string, modulo as ModuloOrigen, referencia as { tipoReferencia: string; referenciaId: string } | undefined))
      .rejects.toMatchObject({ codigo });
    expect(repo.crear).not.toHaveBeenCalled();
  });

  it('rechaza destinatario inexistente o inactivo sin escritura', async () => {
    const repo = crearRepo();
    repo.destinatarioActivo.mockResolvedValue(false);
    await expect(new NotificacionesService(repo as unknown as NotificacionesRepository).crear(...parametros))
      .rejects.toEqual(new NotificacionDomainError('DESTINATARIO_INEXISTENTE'));
    expect(repo.crear).not.toHaveBeenCalled();
  });

  it('retorna el id existente si el repositorio detecta duplicado', async () => {
    const repo = crearRepo();
    repo.crear.mockResolvedValue({ creada: false, notificacionId: 'aviso-existente' });
    const service = new NotificacionesService(repo as unknown as NotificacionesRepository);
    expect(await service.crear(...parametros, { tipoReferencia: 'RESERVA', referenciaId: 'abc' }))
      .toEqual({ creada: false, notificacionId: 'aviso-existente' });
  });
});
