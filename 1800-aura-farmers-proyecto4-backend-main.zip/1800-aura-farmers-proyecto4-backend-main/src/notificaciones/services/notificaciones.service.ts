import { Injectable, NotFoundException } from '@nestjs/common';
import { ModuloOrigen } from '@PrismaClient';
import { NotificacionDomainError } from '@Notificaciones/errors';
import { NotificacionesRepository } from '@Notificaciones/repositories';
import {
  ListadoNotificacionesResponseDto,
  MarcarNotificacionLeidaResponseDto,
  NotificacionResponseDto,
} from '@Notificaciones/dto';
import type {
  ReferenciaNotificacion,
  ResultadoCrearNotificacion,
} from '@Notificaciones/types';

@Injectable()
export class NotificacionesService {
  private readonly TAMANO_PAGINA = 20;

  constructor(
    private readonly repository: NotificacionesRepository,
  ) {}

  /**
   * BE-20.1
   * Registro interno de notificaciones.
   */
  async crear(
    destinatarioId: string,
    titulo: string,
    mensaje: string,
    moduloOrigen: ModuloOrigen,
    referencia?: ReferenciaNotificacion,
  ): Promise<ResultadoCrearNotificacion> {
    if (
      typeof destinatarioId !== 'string' ||
      !destinatarioId.trim()
    ) {
      throw new NotificacionDomainError(
        'DESTINATARIO_REQUERIDO',
      );
    }

    if (
      typeof titulo !== 'string' ||
      !titulo.trim()
    ) {
      throw new NotificacionDomainError(
        'TITULO_REQUERIDO',
      );
    }

    if (titulo.length > 100) {
      throw new NotificacionDomainError(
        'TITULO_MUY_LARGO',
      );
    }

    if (
      typeof mensaje !== 'string' ||
      mensaje.length > 300
    ) {
      throw new NotificacionDomainError(
        'MENSAJE_MUY_LARGO',
      );
    }

    if (
      !Object.values(ModuloOrigen).includes(moduloOrigen)
    ) {
      throw new NotificacionDomainError(
        'MODULO_ORIGEN_INVALIDO',
      );
    }

    const tieneReferencia =
      referencia !== undefined && referencia !== null;

    if (
      tieneReferencia &&
      (
        typeof referencia.tipoReferencia !== 'string' ||
        !referencia.tipoReferencia.trim() ||
        typeof referencia.referenciaId !== 'string' ||
        !referencia.referenciaId.trim() ||
        referencia.tipoReferencia.length > 40 ||
        referencia.referenciaId.length > 36
      )
    ) {
      throw new NotificacionDomainError(
        'REFERENCIA_INCOMPLETA',
      );
    }

    const id = destinatarioId.trim();

    if (!(await this.repository.destinatarioActivo(id))) {
      throw new NotificacionDomainError(
        'DESTINATARIO_INEXISTENTE',
      );
    }

    return this.repository.crear({
      destinatarioId: id,
      titulo: titulo.trim(),
      mensaje,
      moduloOrigen,
      ...(tieneReferencia
        ? {
            referencia: {
              tipoReferencia:
                referencia.tipoReferencia.trim(),
              referenciaId:
                referencia.referenciaId.trim(),
            },
          }
        : {}),
    });
  }

  /**
   * BE-21.2
   * Marca como leída una notificación del usuario autenticado.
   */
  async marcarComoLeida(
    notificacionId: string,
    usuarioId: string,
  ): Promise<MarcarNotificacionLeidaResponseDto> {
    const resultado = await this.repository.marcarComoLeida(
      notificacionId,
      usuarioId,
    );

    if (!resultado) {
      throw new NotFoundException(
        'No encontramos esa notificación.',
      );
    }

    return {
      id: resultado.id,
      estado: resultado.estado,
      leidaEn: resultado.leidaEn.toISOString(),
      noLeidas: resultado.noLeidas,
    };
  }

  /**
   * BE-21.1
   * Lista notificaciones del usuario autenticado.
   */
  async listarMias(
    usuarioId: string,
    pagina = 1,
  ): Promise<ListadoNotificacionesResponseDto> {
    const resultado =
      await this.repository.listarPorUsuario(
        usuarioId,
        pagina,
        this.TAMANO_PAGINA,
      );

    return {
      noLeidas: resultado.noLeidas,
      total: resultado.total,
      pagina,
      tamanoPagina: this.TAMANO_PAGINA,
      notificaciones: resultado.notificaciones.map(
        (notificacion) =>
          NotificacionResponseDto.fromEntity(
            notificacion,
          ),
      ),
    };
  }
}
