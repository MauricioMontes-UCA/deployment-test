import { NotFoundException } from '@nestjs/common';
import { EstadoNotificacion } from '@PrismaClient';
import type { NotificacionesRepository } from '../repositories/notificaciones.repository.js';
import { NotificacionesService } from './notificaciones.service.js';

const usuarioId = '11111111-1111-4111-8111-111111111111';
const notificacionId = '22222222-2222-4222-8222-222222222222';
const fechaLectura = new Date('2026-11-15T12:00:00.000Z');

function crearServicio() {
  const repository = {
    marcarComoLeida: vi.fn(),
  };

  const service = new NotificacionesService(
    repository as unknown as NotificacionesRepository,
  );

  return { service, repository };
}

describe('BE-21.2 - NotificacionesService.marcarComoLeida', () => {
  it('marca una notificación y devuelve el contador actualizado', async () => {
    const { service, repository } = crearServicio();

    repository.marcarComoLeida.mockResolvedValue({
      id: notificacionId,
      estado: EstadoNotificacion.LEIDA,
      leidaEn: fechaLectura,
      noLeidas: 2,
    });

    const resultado = await service.marcarComoLeida(
      notificacionId,
      usuarioId,
    );

    expect(repository.marcarComoLeida).toHaveBeenCalledWith(
      notificacionId,
      usuarioId,
    );

    expect(resultado).toEqual({
      id: notificacionId,
      estado: EstadoNotificacion.LEIDA,
      leidaEn: '2026-11-15T12:00:00.000Z',
      noLeidas: 2,
    });
  });

  it('devuelve la misma fecha cuando la notificación ya estaba leída', async () => {
    const { service, repository } = crearServicio();

    repository.marcarComoLeida.mockResolvedValue({
      id: notificacionId,
      estado: EstadoNotificacion.LEIDA,
      leidaEn: fechaLectura,
      noLeidas: 2,
    });

    const primera = await service.marcarComoLeida(
      notificacionId,
      usuarioId,
    );

    const segunda = await service.marcarComoLeida(
      notificacionId,
      usuarioId,
    );

    expect(segunda).toEqual(primera);
    expect(segunda.noLeidas).toBe(2);
    expect(segunda.leidaEn).toBe(primera.leidaEn);
  });

  it('devuelve 404 cuando la notificación no pertenece al usuario', async () => {
    const { service, repository } = crearServicio();

    repository.marcarComoLeida.mockResolvedValue(null);

    await expect(
      service.marcarComoLeida(notificacionId, usuarioId),
    ).rejects.toThrow(NotFoundException);
  });

  it('devuelve 404 cuando la notificación no existe', async () => {
    const { service, repository } = crearServicio();

    repository.marcarComoLeida.mockResolvedValue(null);

    await expect(
      service.marcarComoLeida(notificacionId, usuarioId),
    ).rejects.toMatchObject({
      status: 404,
      message: 'No encontramos esa notificación.',
    });
  });
});