import {
  Controller,
  Get,
  Param,
  ParseUUIDPipe,
  Patch,
  Query,
} from '@nestjs/common';
import {
  ApiBadRequestResponse,
  ApiBearerAuth,
  ApiNotFoundResponse,
  ApiOkResponse,
  ApiOperation,
  ApiParam,
  ApiTags,
  ApiUnauthorizedResponse,
} from '@nestjs/swagger';
import {
  CurrentUser,
  Roles,
} from '@Auth/decorators';
import type { AuthenticatedUser } from '@Auth/types';
import { Rol } from '@PrismaClient';
import {
  ConsultarNotificacionesDto,
  ListadoNotificacionesResponseDto,
  MarcarNotificacionLeidaResponseDto,
} from '@Notificaciones/dto';
import { NotificacionesService } from '@Notificaciones/services';

@ApiTags('notificaciones')
@ApiBearerAuth()
@Roles(Rol.ARRENDADOR, Rol.ARRENDATARIO)
@Controller('notificaciones')
export class NotificacionesController {
  constructor(
    private readonly notificacionesService:
      NotificacionesService,
  ) {}

  @Get()
  @ApiOperation({
    summary:
      'Lista las notificaciones del usuario autenticado',
    description:
      'Devuelve hasta 20 notificaciones por página, ordenadas de la más reciente a la más antigua, junto con el total y el contador global de no leídas.',
  })
  @ApiOkResponse({
    description:
      'Notificaciones del usuario obtenidas correctamente.',
    type: ListadoNotificacionesResponseDto,
  })
  @ApiBadRequestResponse({
    description:
      'El parámetro pagina debe ser un entero mayor o igual a 1.',
  })
  @ApiUnauthorizedResponse({
    description:
      'Token ausente, inválido o expirado.',
  })
  async listarMias(
    @CurrentUser() usuario: AuthenticatedUser,
    @Query() query: ConsultarNotificacionesDto,
  ): Promise<ListadoNotificacionesResponseDto> {
    return this.notificacionesService.listarMias(
      usuario.id,
      query.pagina,
    );
  }

  @Patch(':id/leida')
  @ApiOperation({
    summary: 'Marcar una notificación como leída',
    description:
      'Marca como leída una notificación del usuario autenticado. ' +
      'Es idempotente: si ya estaba leída, conserva la fecha de lectura.',
  })
  @ApiParam({
    name: 'id',
    description: 'UUID de la notificación',
    format: 'uuid',
  })
  @ApiOkResponse({
    description: 'Notificación marcada o previamente leída.',
    type: MarcarNotificacionLeidaResponseDto,
  })
  @ApiBadRequestResponse({
    description: 'El identificador no es un UUID válido.',
  })
  @ApiUnauthorizedResponse({
    description: 'Token ausente, inválido o expirado.',
  })
  @ApiNotFoundResponse({
    description: 'La notificación no existe o pertenece a otro usuario.',
  })
  async marcarComoLeida(
    @Param('id', new ParseUUIDPipe({ version: '4' })) id: string,
    @CurrentUser() usuario: AuthenticatedUser,
  ): Promise<MarcarNotificacionLeidaResponseDto> {
    return this.notificacionesService.marcarComoLeida(id, usuario.id);
  }
}
