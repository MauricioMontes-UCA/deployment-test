import type { ModuloOrigen } from '@PrismaClient';

export interface ReferenciaNotificacion {
  tipoReferencia: string;
  referenciaId: string;
}

export interface ResultadoCrearNotificacion {
  creada: boolean;
  notificacionId: string | null;
}

export type OrigenNotificacion = ModuloOrigen;
