import { Module } from '@nestjs/common';
import { NotificacionesController } from '@Notificaciones/controllers';
import { NotificacionesRepository } from '@Notificaciones/repositories';
import { NotificacionesService } from '@Notificaciones/services';

@Module({
  controllers: [NotificacionesController],
  providers: [NotificacionesRepository, NotificacionesService],
  exports: [NotificacionesService],
})
export class NotificacionesModule {}
