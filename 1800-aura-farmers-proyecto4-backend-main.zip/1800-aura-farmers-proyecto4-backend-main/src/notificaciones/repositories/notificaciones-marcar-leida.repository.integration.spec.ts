import { randomUUID } from 'node:crypto';
import { PrismaPg } from '@prisma/adapter-pg';
import {
  PrismaClient,
  EstadoNotificacion,
  ModuloOrigen,
  Rol,
} from '@PrismaClient';
import type { PrismaService } from '@Prisma/services';
import { NotificacionesRepository } from './notificaciones.repository.js';

const habilitada =
  process.env.RUN_DB_INTEGRATION === '1';

if (habilitada && !process.env.DATABASE_URL) {
  throw new Error(
    'RUN_DB_INTEGRATION=1 requiere DATABASE_URL.',
  );
}

describe.skipIf(!habilitada)(
  'BE-21.2 - Integración PostgreSQL',
  () => {
    let prisma: PrismaClient;
    let repository: NotificacionesRepository;

    let usuarioAId = '';
    let usuarioBId = '';

    beforeAll(async () => {
      prisma = new PrismaClient({
        adapter: new PrismaPg({
          connectionString: process.env.DATABASE_URL!,
        }),
      });

      await prisma.$connect();

      repository = new NotificacionesRepository(
        prisma as unknown as PrismaService,
      );

      const sufijo = randomUUID().replaceAll('-', '').slice(0, 12);

      const usuarioA = await prisma.usuario.create({
        data: {
          nombreUsuario: `nt212a_${sufijo}`,
          email: `nt212a_${sufijo}@example.com`,
          passwordHash: 'hash-prueba',
          rol: Rol.ARRENDADOR,
        },
      });

      usuarioAId = usuarioA.id;

      const usuarioB = await prisma.usuario.create({
        data: {
          nombreUsuario: `nt212b_${sufijo}`,
          email: `nt212b_${sufijo}@example.com`,
          passwordHash: 'hash-prueba',
          rol: Rol.ARRENDATARIO,
        },
      });

      usuarioBId = usuarioB.id;
    });

    afterAll(async () => {
      if (prisma) {
        const ids = [usuarioAId, usuarioBId].filter(Boolean);

        if (ids.length > 0) {
          await prisma.notificacion.deleteMany({
            where: { destinatarioId: { in: ids } },
          });

          await prisma.usuario.deleteMany({
            where: { id: { in: ids } },
          });
        }

        await prisma.$disconnect();
      }
    });

    it('reduce de 3 a 2 las no leídas y conserva leidaEn al repetir', async () => {
      const avisos = await Promise.all(
        Array.from({ length: 3 }, (_, i) =>
          prisma.notificacion.create({
            data: {
              destinatarioId: usuarioAId,
              titulo: `Aviso ${i + 1}`,
              mensaje: 'Mensaje de prueba',
              moduloOrigen: ModuloOrigen.RESERVAS,
            },
          }),
        ),
      );

      const primera = await repository.marcarComoLeida(
        avisos[0].id,
        usuarioAId,
      );

      expect(primera).not.toBeNull();
      expect(primera?.estado).toBe(EstadoNotificacion.LEIDA);
      expect(primera?.noLeidas).toBe(2);
      expect(primera?.leidaEn).toBeInstanceOf(Date);

      const registroPrimera = await prisma.notificacion.findUniqueOrThrow({
        where: { id: avisos[0].id },
      });

      const segunda = await repository.marcarComoLeida(
        avisos[0].id,
        usuarioAId,
      );

      const registroSegunda = await prisma.notificacion.findUniqueOrThrow({
        where: { id: avisos[0].id },
      });

      expect(segunda?.noLeidas).toBe(2);
      expect(segunda?.leidaEn.getTime()).toBe(
        primera?.leidaEn.getTime(),
      );

      expect(registroSegunda.updatedAt.getTime()).toBe(
        registroPrimera.updatedAt.getTime(),
      );
    });

    it('no modifica una notificación de otro usuario', async () => {
      const aviso = await prisma.notificacion.create({
        data: {
          destinatarioId: usuarioBId,
          titulo: 'Aviso privado',
          mensaje: 'Solo pertenece al usuario B',
          moduloOrigen: ModuloOrigen.RESERVAS,
        },
      });

      const resultado = await repository.marcarComoLeida(
        aviso.id,
        usuarioAId,
      );

      expect(resultado).toBeNull();

      const guardado = await prisma.notificacion.findUniqueOrThrow({
        where: { id: aviso.id },
      });

      expect(guardado.estado).toBe(
        EstadoNotificacion.NO_LEIDA,
      );
      expect(guardado.leidaEn).toBeNull();
    });

    it('devuelve null para un identificador inexistente', async () => {
      const resultado = await repository.marcarComoLeida(
        randomUUID(),
        usuarioAId,
      );

      expect(resultado).toBeNull();
    });
  },
);