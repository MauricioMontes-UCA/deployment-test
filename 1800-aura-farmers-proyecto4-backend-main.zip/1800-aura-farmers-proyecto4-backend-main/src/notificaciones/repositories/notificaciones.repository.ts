import { Injectable } from '@nestjs/common';
import {
  Prisma,
  EstadoNotificacion,
  type ModuloOrigen,
  type Notificacion,
} from '@PrismaClient';
import { PrismaService } from '@Prisma/services';
import type {
  ReferenciaNotificacion,
  ResultadoCrearNotificacion,
} from '@Notificaciones/types';

export interface DatosNuevaNotificacion {
  destinatarioId: string;
  titulo: string;
  mensaje: string;
  moduloOrigen: ModuloOrigen;
  referencia?: ReferenciaNotificacion;
}

export type NotificacionListado = Pick<
  Notificacion,
  | 'id'
  | 'titulo'
  | 'mensaje'
  | 'estado'
  | 'moduloOrigen'
  | 'creadaEn'
>;

export interface ResultadoListadoNotificaciones {
  notificaciones: NotificacionListado[];
  total: number;
  noLeidas: number;
}

@Injectable()
export class NotificacionesRepository {
  constructor(private readonly prisma: PrismaService) {}

  async destinatarioActivo(id: string): Promise<boolean> {
    const usuario = await this.prisma.usuario.findFirst({
      where: { id, isActive: true },
      select: { id: true },
    });

    return usuario !== null;
  }

  async crear(
    datos: DatosNuevaNotificacion,
  ): Promise<ResultadoCrearNotificacion> {
    const {
      destinatarioId,
      titulo,
      mensaje,
      moduloOrigen,
      referencia,
    } = datos;

    try {
      const aviso = await this.prisma.notificacion.create({
        data: {
          destinatarioId,
          titulo,
          mensaje,
          moduloOrigen,
          estado: EstadoNotificacion.NO_LEIDA,
          ...(referencia
            ? {
                tipoReferencia: referencia.tipoReferencia,
                referenciaId: referencia.referenciaId,
              }
            : {}),
        },
        select: { id: true },
      });

      return {
        creada: true,
        notificacionId: aviso.id,
      };
    } catch (error) {
      // Se conserva el comportamiento de BE-20.1.
      if (
        referencia &&
        error instanceof Prisma.PrismaClientKnownRequestError &&
        error.code === 'P2002'
      ) {
        const existente =
          await this.prisma.notificacion.findFirst({
            where: {
              destinatarioId,
              tipoReferencia: referencia.tipoReferencia,
              referenciaId: referencia.referenciaId,
            },
            select: { id: true },
          });

        if (existente) {
          return {
            creada: false,
            notificacionId: existente.id,
          };
        }
      }

      throw error;
    }
  }

  async marcarComoLeida(
    notificacionId: string,
    destinatarioId: string,
  ): Promise<{
    id: string;
    estado: EstadoNotificacion;
    leidaEn: Date;
    noLeidas: number;
  } | null> {
    const resultado = await this.prisma.$transaction(async (tx) => {
      // Solo se actualiza una notificación NO_LEIDA
      // perteneciente al usuario autenticado.
      await tx.notificacion.updateMany({
        where: {
          id: notificacionId,
          destinatarioId,
          estado: EstadoNotificacion.NO_LEIDA,
        },
        data: {
          estado: EstadoNotificacion.LEIDA,
          leidaEn: new Date(),
        },
      });

      // También recupera una notificación previamente leída.
      const notificacion = await tx.notificacion.findFirst({
        where: {
          id: notificacionId,
          destinatarioId,
        },
        select: {
          id: true,
          estado: true,
          leidaEn: true,
        },
      });

      if (!notificacion) {
        return null;
      }

      const noLeidas = await tx.notificacion.count({
        where: {
          destinatarioId,
          estado: EstadoNotificacion.NO_LEIDA,
        },
      });

      return {
        notificacion,
        noLeidas,
      };
    });

    if (!resultado) {
      return null;
    }

    const { notificacion, noLeidas } = resultado;

    if (!notificacion.leidaEn) {
      throw new Error(
        'Inconsistencia: notificación leída sin fecha de lectura.',
      );
    }

    return {
      id: notificacion.id,
      estado: notificacion.estado,
      leidaEn: notificacion.leidaEn,
      noLeidas,
    };
  }

  /**
   * BE-21.1
   * Lista y cuenta exclusivamente las notificaciones
   * del usuario autenticado.
   */
  async listarPorUsuario(
    destinatarioId: string,
    pagina: number,
    tamanoPagina: number,
  ): Promise<ResultadoListadoNotificaciones> {
    const skip = (pagina - 1) * tamanoPagina;

    const where = { destinatarioId };

    const [notificaciones, total, noLeidas] =
      await Promise.all([
        this.prisma.notificacion.findMany({
          where,
          select: {
            id: true,
            titulo: true,
            mensaje: true,
            estado: true,
            moduloOrigen: true,
            creadaEn: true,
          },
          orderBy: [
            { creadaEn: 'desc' },
            { id: 'desc' },
          ],
          skip,
          take: tamanoPagina,
        }),

        this.prisma.notificacion.count({
          where,
        }),

        this.prisma.notificacion.count({
          where: {
            destinatarioId,
            estado: EstadoNotificacion.NO_LEIDA,
          },
        }),
      ]);

    return {
      notificaciones,
      total,
      noLeidas,
    };
  }
}
