import { PrismaPg } from '@prisma/adapter-pg';
import { PrismaClient, ModuloOrigen, Rol, EstadoNotificacion } from '@PrismaClient';
import { NotificacionesRepository } from './notificaciones.repository.js';
import { NotificacionesService } from '@Notificaciones/services';
import type { PrismaService } from '@Prisma/services';

// Ejecución explícita con PostgreSQL real: RUN_DB_INTEGRATION=1 npm test -- ...
const habilitada = process.env.RUN_DB_INTEGRATION === '1' && !!process.env.DATABASE_URL;

describe.skipIf(!habilitada)('BE-20.1 integración PostgreSQL', () => {
  let prisma: PrismaClient;
  let usuarioId: string;
  beforeAll(async () => {
    prisma = new PrismaClient({ adapter: new PrismaPg({ connectionString: process.env.DATABASE_URL! }) });
    await prisma.$connect();
    const sufijo = crypto.randomUUID().replaceAll('-', '').slice(0, 12);
    const usuario = await prisma.usuario.create({
      data: {
        nombreUsuario: `nt_${sufijo}`,
        email: `nt_${sufijo}@example.com`,
        passwordHash: 'hash-para-pruebas',
        rol: Rol.ARRENDATARIO,
      },
    });
    usuarioId = usuario.id;
  });
  afterAll(async () => {
    if (prisma) {
      if (usuarioId) {
        await prisma.notificacion.deleteMany({ where: { destinatarioId: usuarioId } });
        await prisma.usuario.delete({ where: { id: usuarioId } });
      }
      await prisma.$disconnect();
    }
  });
  it('persiste NO_LEIDA, deduplica por referencia y admite avisos sin referencia', async () => {
    const repo = new NotificacionesRepository(prisma as unknown as PrismaService);
    const servicio = new NotificacionesService(repo);
    const ref = { tipoReferencia: 'RESERVA', referenciaId: crypto.randomUUID() };
    const primero = await servicio.crear(usuarioId, 'Reserva', 'Confirmada', ModuloOrigen.RESERVAS, ref);
    const segundo = await servicio.crear(usuarioId, 'Reserva', 'Confirmada', ModuloOrigen.RESERVAS, ref);
    expect(primero.creada).toBe(true);
    expect(segundo).toEqual({ creada: false, notificacionId: primero.notificacionId });
    expect(await prisma.notificacion.count({ where: { destinatarioId: usuarioId, tipoReferencia: ref.tipoReferencia, referenciaId: ref.referenciaId } })).toBe(1);
    const aviso = await prisma.notificacion.findUniqueOrThrow({ where: { id: primero.notificacionId! } });
    expect(aviso.estado).toBe(EstadoNotificacion.NO_LEIDA);
    await servicio.crear(usuarioId, 'Otro', 'Sin referencia', ModuloOrigen.PAGOS);
    await servicio.crear(usuarioId, 'Otro', 'Sin referencia', ModuloOrigen.PAGOS);
    expect(await prisma.notificacion.count({ where: { destinatarioId: usuarioId } })).toBe(3);
  });
});
