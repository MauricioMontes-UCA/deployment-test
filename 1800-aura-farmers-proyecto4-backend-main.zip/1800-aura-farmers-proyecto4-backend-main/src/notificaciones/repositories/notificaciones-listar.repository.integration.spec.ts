import { randomUUID } from 'node:crypto';
import { PrismaPg } from '@prisma/adapter-pg';
import {
  PrismaClient,
  EstadoNotificacion,
  ModuloOrigen,
  Rol,
} from '@PrismaClient';
import type { PrismaService } from '@Prisma/services';
import { NotificacionesRepository } from './notificaciones.repository.js';

const habilitada =
  process.env.RUN_DB_INTEGRATION === '1' &&
  !!process.env.DATABASE_URL;

describe.skipIf(!habilitada)(
  'BE-21.1 - Integración PostgreSQL',
  () => {
    let prisma: PrismaClient;
    let repository: NotificacionesRepository;

    let usuarioAId = '';
    let usuarioBId = '';
    
    beforeAll(async () => {
      prisma = new PrismaClient({
        adapter: new PrismaPg({
          connectionString: process.env.DATABASE_URL!,
        }),
      });

      await prisma.$connect();

      repository = new NotificacionesRepository(
        prisma as unknown as PrismaService,
      );

      const sufijo = randomUUID().replaceAll('-', '').slice(0, 12);

      const usuarioA = await prisma.usuario.create({
        data: {
          nombreUsuario: `nt21_a_${sufijo}`,
          email: `nt21_a_${sufijo}@example.com`,
          passwordHash: 'hash-para-pruebas',
          rol: Rol.ARRENDADOR,
        },
      });

      usuarioAId = usuarioA.id;

      const usuarioB = await prisma.usuario.create({
        data: {
          nombreUsuario: `nt21_b_${sufijo}`,
          email: `nt21_b_${sufijo}@example.com`,
          passwordHash: 'hash-para-pruebas',
          rol: Rol.ARRENDATARIO,
        },
      });

      usuarioBId = usuarioB.id;
    });

    afterAll(async () => {
      if (prisma) {
        const ids = [usuarioAId, usuarioBId].filter(Boolean);

        if (ids.length > 0) {
          await prisma.notificacion.deleteMany({
            where: {
              destinatarioId: { in: ids },
            },
          });

          await prisma.usuario.deleteMany({
            where: {
              id: { in: ids },
            },
          });
        }

        await prisma.$disconnect();
      }
    });

    it('aísla las notificaciones de dos usuarios y cuenta todas las no leídas', async () => {
      const fechaBase = new Date('2026-11-01T12:00:00.000Z');

      const avisosA = Array.from({ length: 25 }, (_, i) => ({
        destinatarioId: usuarioAId,
        titulo: `Aviso A ${i + 1}`,
        mensaje: `Mensaje ${i + 1}`,
        moduloOrigen: ModuloOrigen.RESERVAS,
        estado:
          [0, 12, 24].includes(i)
            ? EstadoNotificacion.NO_LEIDA
            : EstadoNotificacion.LEIDA,
        creadaEn: new Date(
          fechaBase.getTime() + i * 60_000,
        ),
      }));

      await prisma.notificacion.createMany({
        data: [
          ...avisosA,
          {
            destinatarioId: usuarioBId,
            titulo: 'Aviso privado B',
            mensaje: 'No debe aparecer al usuario A',
            moduloOrigen: ModuloOrigen.PAGOS,
            estado: EstadoNotificacion.NO_LEIDA,
            creadaEn: new Date('2026-11-15T12:00:00.000Z'),
          },
        ],
      });

      const pagina1 = await repository.listarPorUsuario(
        usuarioAId,
        1,
        20,
      );

      const pagina2 = await repository.listarPorUsuario(
        usuarioAId,
        2,
        20,
      );

      const paginaB = await repository.listarPorUsuario(
        usuarioBId,
        1,
        20,
      );

      expect(pagina1.notificaciones).toHaveLength(20);
      expect(pagina2.notificaciones).toHaveLength(5);

      expect(pagina1.total).toBe(25);
      expect(pagina1.noLeidas).toBe(3);

      expect(pagina2.total).toBe(25);
      expect(pagina2.noLeidas).toBe(3);

      expect(paginaB.total).toBe(1);
      expect(paginaB.noLeidas).toBe(1);
      expect(paginaB.notificaciones[0].titulo)
        .toBe('Aviso privado B');

      const todosA = [
        ...pagina1.notificaciones,
        ...pagina2.notificaciones,
      ];

      expect(
        todosA.some(
          (aviso) => aviso.titulo === 'Aviso privado B',
        ),
      ).toBe(false);

      const fechas = todosA.map(
        (aviso) => aviso.creadaEn.getTime(),
      );

      expect(fechas).toEqual(
        [...fechas].sort((a, b) => b - a),
      );

      expect(new Set(todosA.map((aviso) => aviso.id)).size)
        .toBe(25);
    });

    it('devuelve lista y contadores vacíos para un usuario sin avisos', async () => {
      const sufijo = randomUUID().replaceAll('-', '').slice(0, 12);

      const usuario = await prisma.usuario.create({
        data: {
          nombreUsuario: `nt21_v_${sufijo}`,
          email: `nt21_v_${sufijo}@example.com`,
          passwordHash: 'hash-para-pruebas',
          rol: Rol.ARRENDATARIO,
        },
      });

      try {
        const resultado = await repository.listarPorUsuario(
          usuario.id,
          1,
          20,
        );

        expect(resultado).toEqual({
          notificaciones: [],
          total: 0,
          noLeidas: 0,
        });
      } finally {
        await prisma.usuario.delete({
          where: { id: usuario.id },
        });
      }
    });

    it('consulta 500 avisos en menos de 2 segundos', async () => {
      const sufijo = randomUUID().replaceAll('-', '').slice(0, 12);

      const usuario = await prisma.usuario.create({
        data: {
          nombreUsuario: `nt21_p_${sufijo}`,
          email: `nt21_p_${sufijo}@example.com`,
          passwordHash: 'hash-para-pruebas',
          rol: Rol.ARRENDATARIO,
        },
      });

      try {
        await prisma.notificacion.createMany({
          data: Array.from({ length: 500 }, (_, i) => ({
            destinatarioId: usuario.id,
            titulo: `Aviso ${i + 1}`,
            mensaje: 'Prueba de rendimiento',
            moduloOrigen: ModuloOrigen.RESERVAS,
            estado:
              i % 2 === 0
                ? EstadoNotificacion.NO_LEIDA
                : EstadoNotificacion.LEIDA,
          })),
        });

        // Calentamiento de la conexión y la consulta.
        await repository.listarPorUsuario(usuario.id, 1, 20);

        const inicio = performance.now();

        const resultado = await repository.listarPorUsuario(
          usuario.id,
          1,
          20,
        );

        const duracion = performance.now() - inicio;

        expect(resultado.total).toBe(500);
        expect(resultado.noLeidas).toBe(250);
        expect(resultado.notificaciones).toHaveLength(20);

        expect(duracion).toBeLessThan(2000);
      } finally {
        await prisma.notificacion.deleteMany({
          where: { destinatarioId: usuario.id },
        });

        await prisma.usuario.delete({
          where: { id: usuario.id },
        });
      }
    });
  },
);
