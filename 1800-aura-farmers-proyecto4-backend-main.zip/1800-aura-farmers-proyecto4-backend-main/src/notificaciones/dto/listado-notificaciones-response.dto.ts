import { ApiProperty } from '@nestjs/swagger';
import { NotificacionResponseDto } from './notificacion-response.dto.js';

export class ListadoNotificacionesResponseDto {
  @ApiProperty({
    example: 3,
    description:
      'Total de notificaciones no leídas del usuario.',
  })
  noLeidas: number;

  @ApiProperty({
    example: 25,
    description:
      'Total de notificaciones del usuario.',
  })
  total: number;

  @ApiProperty({
    example: 1,
    description: 'Página solicitada.',
  })
  pagina: number;

  @ApiProperty({
    example: 20,
    description: 'Tamaño fijo de página.',
  })
  tamanoPagina: number;

  @ApiProperty({
    type: () => NotificacionResponseDto,
    isArray: true,
  })
  notificaciones: NotificacionResponseDto[];
}
