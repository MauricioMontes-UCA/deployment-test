import { ApiProperty } from '@nestjs/swagger';
import {
  EstadoNotificacion,
  ModuloOrigen,
  type Notificacion,
} from '@PrismaClient';

export class NotificacionResponseDto {
  @ApiProperty({
    format: 'uuid',
    description: 'Identificador de la notificación.',
  })
  id: string;

  @ApiProperty({
    example: 'Nueva solicitud de reserva',
  })
  titulo: string;

  @ApiProperty({
    example: 'Tienes una nueva solicitud de reserva.',
  })
  mensaje: string;

  @ApiProperty({
    enum: EstadoNotificacion,
    example: EstadoNotificacion.NO_LEIDA,
  })
  estado: EstadoNotificacion;

  @ApiProperty({
    enum: ModuloOrigen,
    example: ModuloOrigen.RESERVAS,
  })
  moduloOrigen: ModuloOrigen;

  @ApiProperty({
    type: String,
    format: 'date-time',
    example: '2026-11-14T20:30:00.000Z',
  })
  creadaEn: string;

  static fromEntity(
    notificacion: Pick<
      Notificacion,
      | 'id'
      | 'titulo'
      | 'mensaje'
      | 'estado'
      | 'moduloOrigen'
      | 'creadaEn'
    >,
  ): NotificacionResponseDto {
    return {
      id: notificacion.id,
      titulo: notificacion.titulo,
      mensaje: notificacion.mensaje,
      estado: notificacion.estado,
      moduloOrigen: notificacion.moduloOrigen,
      creadaEn: notificacion.creadaEn.toISOString(),
    };
  }
}
