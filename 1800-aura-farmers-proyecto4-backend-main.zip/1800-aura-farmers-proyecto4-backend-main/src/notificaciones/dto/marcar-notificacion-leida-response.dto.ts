import { ApiProperty } from '@nestjs/swagger';
import { EstadoNotificacion } from '@PrismaClient';

export class MarcarNotificacionLeidaResponseDto {
  @ApiProperty({ format: 'uuid' })
  id: string;

  @ApiProperty({
    enum: EstadoNotificacion,
    example: EstadoNotificacion.LEIDA,
  })
  estado: EstadoNotificacion;

  @ApiProperty({
    type: String,
    format: 'date-time',
  })
  leidaEn: string;

  @ApiProperty({
    example: 2,
    description: 'Total de notificaciones no leídas del usuario.',
  })
  noLeidas: number;
}