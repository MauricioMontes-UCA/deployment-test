import { Transform } from 'class-transformer';
import { IsInt, Max, Min } from 'class-validator';
import { ApiPropertyOptional } from '@nestjs/swagger';

export class ConsultarNotificacionesDto {
  @ApiPropertyOptional({
    description:
      'Número de página. Entero positivo; por defecto 1.',
    example: 1,
    default: 1,
    minimum: 1,
    type: Number,
  })
  @Transform(({ value }: { value: unknown }) => {
    if (value === undefined) return 1;

    if (
      typeof value !== 'string' ||
      !/^[1-9]\d*$/.test(value)
    ) {
      return Number.NaN;
    }

    return Number(value);
  })
  @IsInt()
  @Min(1)
  @Max(Math.floor(Number.MAX_SAFE_INTEGER / 20))
  pagina: number = 1;
}
