export type CodigoErrorNotificacion =
  | 'DESTINATARIO_REQUERIDO'
  | 'DESTINATARIO_INEXISTENTE'
  | 'TITULO_REQUERIDO'
  | 'TITULO_MUY_LARGO'
  | 'MENSAJE_MUY_LARGO'
  | 'MODULO_ORIGEN_INVALIDO'
  | 'REFERENCIA_INCOMPLETA';

export class NotificacionDomainError extends Error {
  constructor(public readonly codigo: CodigoErrorNotificacion) {
    super(codigo);
    this.name = 'NotificacionDomainError';
  }
}
