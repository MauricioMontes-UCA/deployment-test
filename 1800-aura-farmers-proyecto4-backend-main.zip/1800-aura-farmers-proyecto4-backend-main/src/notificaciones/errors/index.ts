export * from './notificacion-domain.error.js';
