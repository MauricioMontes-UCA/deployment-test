/**
 * Arranca `next dev` o `next start` en el puerto de la variable PORT.
 *
 * Next no lee PORT desde `.env` (levanta el servidor antes de cargarlo), así
 * que este script carga los `.env` con el mismo cargador de Next y le pasa el
 * puerto con `-p`. Por defecto usa 3001, porque el backend ocupa el 3000.
 *
 * Uso: node scripts/next-con-puerto.mjs <dev|start> [más opciones de next]
 */
import { spawn } from "node:child_process";
import { createRequire } from "node:module";

const PUERTO_POR_DEFECTO = "3001";

const [comando, ...resto] = process.argv.slice(2);
if (comando !== "dev" && comando !== "start") {
  console.error("Uso: node scripts/next-con-puerto.mjs <dev|start> [opciones]");
  process.exit(1);
}

// @next/env es dependencia de next: se resuelve desde next para no depender
// de cómo npm acomode node_modules.
const requerirDesdeNext = createRequire(createRequire(import.meta.url).resolve("next/package.json"));
const { loadEnvConfig } = requerirDesdeNext("@next/env");
loadEnvConfig(process.cwd(), comando === "dev", { info() {}, error: console.error });

const puerto = process.env.PORT || PUERTO_POR_DEFECTO;
const binarioNext = requerirDesdeNext.resolve("./dist/bin/next");

const proceso = spawn(process.execPath, [binarioNext, comando, "-p", puerto, ...resto], {
  stdio: "inherit",
});

// Reenvía Ctrl+C y la terminación para no dejar Next corriendo en segundo plano.
for (const senal of ["SIGINT", "SIGTERM"]) {
  process.on(senal, () => proceso.kill(senal));
}
proceso.on("exit", (codigo, senal) => process.exit(codigo ?? (senal ? 1 : 0)));
