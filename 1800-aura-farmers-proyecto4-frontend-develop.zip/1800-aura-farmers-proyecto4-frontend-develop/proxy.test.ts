// @vitest-environment node
import { NextRequest } from "next/server";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { tokenDePrueba } from "@/pruebas/tokens";
import { reiniciarRenovaciones } from "@/lib/sesion-vigente";
import { proxy } from "./proxy";

const fetchFalso = vi.fn();
const vigente = () => tokenDePrueba({ exp: Math.floor(Date.now() / 1000) + 600 });
const vencido = () => tokenDePrueba({ exp: Math.floor(Date.now() / 1000) - 60 });

function peticion(ruta: string, cookies: Record<string, string> = {}) {
  const cabecera = Object.entries(cookies)
    .map(([nombre, valor]) => `${nombre}=${valor}`)
    .join("; ");
  return new NextRequest(new URL(ruta, "http://localhost:3001"), {
    headers: cabecera ? { cookie: cabecera } : {},
  });
}

beforeEach(() => {
  reiniciarRenovaciones();
  vi.stubEnv("API_URL", "http://api.test/api/v1");
  vi.stubEnv("REFRESH_TOKEN_EXPIRES_IN_DAYS", "7");
  vi.stubGlobal("fetch", fetchFalso);
});

afterEach(() => {
  vi.unstubAllEnvs();
  vi.unstubAllGlobals();
  fetchFalso.mockReset();
});

describe("proxy", () => {
  it("sin sesión deja ver el registro y manda las rutas privadas al login", async () => {
    expect((await proxy(peticion("/registro"))).headers.get("location")).toBeNull();
    expect((await proxy(peticion("/reportes"))).headers.get("location")).toBe("http://localhost:3001/login");
  });

  it("con sesión vigente manda /registro y /login al inicio", async () => {
    const cookies = { access_token: vigente(), refresh_token: "r" };
    expect((await proxy(peticion("/registro", cookies))).headers.get("location")).toBe("http://localhost:3001/");
    expect((await proxy(peticion("/login", cookies))).headers.get("location")).toBe("http://localhost:3001/");
    expect(fetchFalso).not.toHaveBeenCalled();
  });

  it("renueva una vez el token vencido y escribe las cookies nuevas", async () => {
    const nuevo = vigente();
    fetchFalso.mockResolvedValueOnce(
      new Response(JSON.stringify({ accessToken: nuevo, refreshToken: "r2", expiresIn: 900 }), { status: 200 }),
    );

    const respuesta = await proxy(peticion("/reportes", { access_token: vencido(), refresh_token: "r1" }));

    expect(fetchFalso).toHaveBeenCalledOnce();
    expect(JSON.parse(fetchFalso.mock.calls[0][1].body)).toEqual({ refreshToken: "r1" });
    expect(respuesta.headers.get("location")).toBeNull();
    expect(respuesta.cookies.get("access_token")).toMatchObject({ value: nuevo, httpOnly: true, maxAge: 900 });
    expect(respuesta.cookies.get("refresh_token")).toMatchObject({ value: "r2", maxAge: 7 * 24 * 60 * 60 });
  });

  it("si el backend rechaza el refresh, borra las cookies y manda al login", async () => {
    fetchFalso.mockResolvedValueOnce(
      new Response(JSON.stringify({ message: "Refresh token expirado.", statusCode: 401 }), { status: 401 }),
    );
    const respuesta = await proxy(peticion("/reportes", { access_token: vencido(), refresh_token: "r1" }));
    expect(respuesta.headers.get("location")).toBe("http://localhost:3001/login");
    expect(respuesta.cookies.get("access_token")?.value).toBe("");
    expect(respuesta.cookies.get("refresh_token")?.value).toBe("");
  });

  it("si el backend no responde, conserva el refresh para reintentar", async () => {
    fetchFalso.mockRejectedValueOnce(new TypeError("fetch failed"));
    const respuesta = await proxy(peticion("/reportes", { access_token: vencido(), refresh_token: "r1" }));
    expect(respuesta.headers.get("location")).toBe("http://localhost:3001/login");
    expect(respuesta.cookies.get("refresh_token")).toBeUndefined();
  });

  it("solo deja entrar a /publicar con rol ARRENDADOR", async () => {
    const exp = Math.floor(Date.now() / 1000) + 600;
    const arrendatario = { access_token: tokenDePrueba({ exp, rol: "ARRENDATARIO" }), refresh_token: "r" };
    const arrendador = { access_token: tokenDePrueba({ exp, rol: "ARRENDADOR" }), refresh_token: "r" };

    expect((await proxy(peticion("/publicar", arrendatario))).headers.get("location")).toBe("http://localhost:3001/");
    expect((await proxy(peticion("/publicar", arrendador))).headers.get("location")).toBeNull();
    expect((await proxy(peticion("/publicar"))).headers.get("location")).toBe("http://localhost:3001/login");
  });

  it("en la portada renueva el token vencido pero nunca redirige", async () => {
    const nuevo = vigente();
    fetchFalso.mockResolvedValueOnce(
      new Response(JSON.stringify({ accessToken: nuevo, refreshToken: "r2", expiresIn: 900 }), { status: 200 }),
    );
    const respuesta = await proxy(peticion("/", { access_token: vencido(), refresh_token: "r1" }));
    expect(respuesta.headers.get("location")).toBeNull();
    expect(respuesta.cookies.get("refresh_token")?.value).toBe("r2");

    fetchFalso.mockResolvedValueOnce(new Response(JSON.stringify({ statusCode: 401 }), { status: 401 }));
    const sinRefresh = await proxy(peticion("/buscar", { access_token: vencido(), refresh_token: "r2" }));
    expect(sinRefresh.headers.get("location")).toBeNull();
    expect(sinRefresh.cookies.get("refresh_token")?.value).toBe("");
  });

  it("deja pasar el catálogo y el cierre de sesión expirada sin revisar cookies", async () => {
    expect((await proxy(peticion("/design-system"))).headers.get("location")).toBeNull();
    expect((await proxy(peticion("/design-system/formularios"))).headers.get("location")).toBeNull();
    expect((await proxy(peticion("/sesion-vencida"))).headers.get("location")).toBeNull();
  });
});
