This is a [Next.js](https://nextjs.org) project bootstrapped with [`create-next-app`](https://nextjs.org/docs/app/api-reference/cli/create-next-app).

## Getting Started

First, run the development server:

```bash
npm run dev
# or
yarn dev
# or
pnpm dev
# or
bun dev
```

Open [http://localhost:3001](http://localhost:3001) with your browser to see the result (the port comes from `PORT`, see below).

You can start editing the page by modifying `app/page.tsx`. The page auto-updates as you edit the file.

This project uses [`next/font`](https://nextjs.org/docs/app/building-your-application/optimizing/fonts) to automatically optimize and load [Geist](https://vercel.com/font), a new font family for Vercel.

## Learn More

To learn more about Next.js, take a look at the following resources:

- [Next.js Documentation](https://nextjs.org/docs) - learn about Next.js features and API.
- [Learn Next.js](https://nextjs.org/learn) - an interactive Next.js tutorial.

You can check out [the Next.js GitHub repository](https://github.com/vercel/next.js) - your feedback and contributions are welcome!

## Deploy on Vercel

The easiest way to deploy your Next.js app is to use the [Vercel Platform](https://vercel.com/new?utm_medium=default-template&filter=next.js&utm_source=create-next-app&utm_campaign=create-next-app-readme) from the creators of Next.js.

Check out our [Next.js deployment documentation](https://nextjs.org/docs/app/building-your-application/deploying) for more details.

## Configuración y cómo correrlo con el backend

1. Copia `.env.example` a `.env` y llena las variables (`.env` no se sube al repo):

   | Variable | Valor en desarrollo | Para qué |
   | --- | --- | --- |
   | `API_URL` | `http://localhost:3000/api/v1` | URL base de la API, con el prefijo `/api/v1` |
   | `REFRESH_TOKEN_EXPIRES_IN_DAYS` | `7` | Vigencia del refresh token; debe coincidir con la del backend. Vacía usa 7 |
   | `PORT` | `3001` | Puerto del frontend. Vacío usa 3001, porque el backend ocupa el 3000 |

2. Levanta el backend (`1800-aura-farmers-proyecto4-backend`), que usa el puerto 3000.
3. Corre el frontend con `npm run dev` y abre `http://localhost:3001` (o el puerto de `PORT`).

   Next no lee `PORT` desde `.env`, así que `npm run dev` y `npm start` pasan por `scripts/next-con-puerto.mjs`, que carga el `.env` y arranca Next con ese puerto. Para cambiarlo una sola vez: `PORT=4000 npm run dev`.

## Correrlo con Docker

El [`Dockerfile`](Dockerfile) construye una imagen de producción (Node 24 Alpine, servidor `standalone` de Next). Corre como `node`, sin permiso de escritura sobre la app (solo sobre `.next/cache`), y trae un `HEALTHCHECK` que pide `/icon.svg`: `docker ps` muestra `healthy` cuando Next responde. El [`docker-compose.yml`](docker-compose.yml) levanta solo el frontend y se une a la red del backend (`si-be-boilerplate_default`), así que el backend debe estar corriendo antes (`docker compose up -d` en `1800-aura-farmers-proyecto4-backend`).

```bash
docker compose up -d --build
```

Abre `http://localhost:3001` (o el `PORT` de tu `.env`).

| Variable | Por defecto | Para qué |
| --- | --- | --- |
| `DOCKER_API_URL` | `http://si_be_api:3000/api/v1` | URL de la API **vista desde el contenedor**. No se usa `API_URL` para que el `.env` de desarrollo (`localhost`) no la pise: dentro del contenedor, `localhost` no es el backend |
| `REFRESH_TOKEN_EXPIRES_IN_DAYS` | `7` | Igual que en el backend |
| `PORT` | `3001` | Puerto publicado en el host |

- `API_URL` se fija **al construir** la imagen (el rewrite de `/uploads` de `next.config.ts` se evalúa en el build), así que si la cambias hay que volver a construir con `--build`.
- Con `NODE_ENV=production` las cookies de sesión llevan `Secure`: funcionan en `http://localhost` con Chrome y Firefox, pero Safari puede rechazarlas. En un despliegue real, sirve el frontend por HTTPS.

## CI/CD

El workflow [`.github/workflows/ci-cd.yml`](.github/workflows/ci-cd.yml) corre en cada PR a `develop` o `main` y en cada push a `main`:

- **PR a `develop` o `main`:** solo el job `test` (`npm ci`, `npm run lint`, `npm test` y `npm run build` con `API_URL=http://api:3000/api/v1`).
- **Push a `main`:** además, `publish` construye la imagen con el build arg `API_URL=http://api:3000/api/v1` y la sube a `ghcr.io/erickgomezuca/aura-farmers-frontend` con los tags `latest` y el SHA del commit. Después, `deploy` entra por SSH al VPS, hace `docker compose pull web` y `docker compose up -d --no-deps web` en `/opt/arre` (sin tocar `api` ni `postgres`) y verifica que `https://arre.live/login` responda.
- Usa los secrets `VPS_HOST`, `VPS_PORT`, `VPS_USER`, `VPS_SSH_KEY` y `VPS_KNOWN_HOSTS`. Cada job recibe solo los permisos del `GITHUB_TOKEN` que necesita.
- Para volver a una versión anterior en el VPS: `WEB_TAG=<sha> docker compose up -d --no-deps web` en `/opt/arre`.

## Sesión y autenticación

El backend es la fuente de verdad: el frontend usa su contrato tal cual (`/users`, `/auth/login`, `/auth/refresh`, `/auth/logout`, `/auth/me`).

- **Cookies**: `access_token` y `refresh_token`, las dos httpOnly. Cada cookie dura lo que dura su token (15 min el access, 7 días el refresh), así que nunca queda una sesión «zombi».
- **Renovación**: el proxy (`proxy.ts`) revisa el `exp` del access token en cada navegación. Si venció, lo renueva con `/auth/refresh` y escribe las cookies nuevas; si el backend rechaza el refresh, borra las cookies y manda al login.
  - La renovación es **compartida** (`lib/sesion-vigente.ts`): peticiones simultáneas con el mismo refresh token esperan una sola llamada, y quien llega en los 30 s siguientes con el token viejo recibe el mismo par nuevo. El backend trata un refresh usado dos veces como robado y cerraría todas las sesiones. Funciona dentro de un mismo proceso de Next; con varias instancias haría falta un almacén compartido.
  - Las rutas `/api` no pasan por el proxy: renuevan con `obtenerAccesoVigente(request.cookies)` y escriben las cookies con `aplicarCambiosDeSesion` (ver `app/api/bienes/[bienId]/disponibilidad/route.ts`).
- **Llamar a endpoints protegidos**: desde server components o server actions, con `apiFetch` de `lib/api.ts`. Envía `Authorization: Bearer` y, con un 401, manda a `/sesion-vencida`. Si necesitas decidir qué hacer con cada código, usa `llamarApi`, que devuelve `{ status, datos, mensajes }` sin redirigir. Las llamadas al backend tienen un tiempo límite de 5 s.

  ```ts
  import { apiFetch } from "@/lib/api";
  const reservas = await apiFetch<Reserva[]>("reservas/mias");
  ```

- **Usuario actual**: `obtenerUsuarioActual()` de `lib/usuario-actual.ts` (GET `/auth/me`, una vez por request). Devuelve `ok` (con `id`, `nombreUsuario`, `email`, `rol` y `createdAt`), `sin-sesion` o `error`, y el rol que trae es el vigente en la base.
- **Sesión rechazada**: `/sesion-vencida` comprueba la sesión con `/auth/me` antes de cerrarla. Solo con un 401 revoca el refresh token y borra las cookies; si la sesión sigue viva, lleva a `/`, así un enlace de otro sitio no puede cerrarla.
- **Rutas**: `/login` y `/registro` son solo sin sesión (con sesión llevan al inicio). `/`, `/buscar` y `/bienes/:id` se ven con o sin sesión. El resto pide sesión.
- **Configuración**: `instrumentation.ts` valida `API_URL` y `REFRESH_TOKEN_EXPIRES_IN_DAYS` al arrancar; si están mal, el servidor no levanta.

## Publicar un bien

`/publicar` (solo arrendadores) arma el formulario de H1 y sube todo a `POST /api/v1/bienes` en una sola petición multipart.

- **Subida con progreso**: el navegador sube con `XMLHttpRequest` a `app/api/bienes/route.ts`, que reenvía el cuerpo al backend con el JWT de la cookie. Así la barra muestra el avance real sin exponer el token. Si el access token venció mientras se llenaba el formulario, la ruta lo renueva antes de reenviar.
- **Catálogos** en `lib/catalogos/bienes.ts`: tipos, categorías y unidades de cobro iguales a los del backend. Los departamentos y municipios salen de `lib/ubicaciones.ts`, el mismo catálogo de la búsqueda, para que los valores coincidan.
- **Validaciones** en `lib/validaciones/bien.ts`, con las reglas y mensajes de `CreateBienDto`. Las fotos se validan en el navegador (JPG o PNG, hasta 5 MB, de 1 a 10) y el backend las vuelve a validar por contenido.

Las decisiones sobre las pruebas están en [`docs/pruebas.md`](docs/pruebas.md).

## Design System «Arre»

Todo el sistema visual de Figma (archivo «Design-System») está implementado en el repo. Antes de crear un componente nuevo, revisa si ya existe aquí.

### Dónde está cada cosa

| Qué | Dónde |
| --- | --- |
| Colores, espaciado y estilos de texto | `app/globals.css` |
| Tipografías (DM Sans, Cormorant Garamond, Great Vibes) | `app/layout.tsx` |
| Componentes y patrones | `components/ui/` (se importan desde `@/components/ui`) |
| Íconos (39 SVG exportados de Figma) | `public/iconos/` |
| Catálogo con todas las variantes | `/design-system` (solo en desarrollo) |

### Reglas de Arre

- **Esquinas rectas**: nada usa `rounded-*` (las utilidades están desactivadas).
- **Colores sólidos**: sin sombras ni gradientes; la profundidad se marca con bordes de 1 px.
- **Tipografía**: Cormorant Garamond en títulos y precios, DM Sans en el resto, Great Vibes solo en el logo.
- **Layout**: `Contenedor` da 1312 px con márgenes de 64 en escritorio y márgenes de 16 en móvil. Espaciado en múltiplos de 4.

### Cómo usar los tokens

Los nombres coinciden con las variables de Figma, así que se usan directo como clases de Tailwind:

```tsx
<div className="border border-borde-default bg-fondo-superficie p-espacio-4 text-texto-primario">
  <h2 className="texto-h3">Título</h2>
  <p className="texto-cuerpo-pequeno text-texto-secundario">Detalle</p>
</div>
```

- Colores: `fondo-*`, `borde-*`, `texto-*`, `estado-*` (por ejemplo `bg-fondo-acento`, `text-estado-error`). No uses los hex de la paleta base.
- Espaciado: `espacio-1` … `espacio-9` = 4, 8, 12, 16, 24, 32, 48, 64 y 96 px (`gap-espacio-3`, `px-espacio-5`).
- Texto: `texto-display`, `texto-h1` … `texto-h4`, `texto-precio`, `texto-precio-grande`, `texto-cuerpo-grande`, `texto-cuerpo`, `texto-cuerpo-medio`, `texto-cuerpo-pequeno`, `texto-etiqueta`, `texto-etiqueta-pequena`, `texto-boton`, `texto-sobretitulo`, `texto-logo`. Display y H1 ya cambian de tamaño en móvil.

### Cómo usar los componentes

```tsx
import { Boton, CampoDeTexto, InsigniaDeEstado, TONO_POR_ESTADO } from "@/components/ui";

<CampoDeTexto etiqueta="Nombre de usuario" contador maxLength={30} error={errores.nombreUsuario} />
<Boton cargando={enviando}>Crear cuenta</Boton>
<InsigniaDeEstado texto="Confirmada" tono={TONO_POR_ESTADO[reserva.estado]} />
```

- Los componentes son **solo visuales**: reciben datos y callbacks por props, y la regla de negocio (qué días están bloqueados, cómo se valida un periodo) la decide cada pantalla.
- Un enlace con estilo de botón se arma con `clasesBoton`: `<Link href="/registro" className={clasesBoton({ jerarquia: "terciario" })}>`.
- Los íconos se pintan con el color del texto: `<Icono nombre="alerta" className="text-estado-error" />`.
- Las rutas de `NavegacionSuperior` y `PieDePagina` son una propuesta (`ENLACES_POR_ROL`): ajústalas cuando crees la página correspondiente.
- **Fotos del backend**: la API devuelve rutas relativas (`/uploads/bienes/…`). `next.config.ts` reenvía `/uploads/*` al origen de `API_URL`, así que se pasan tal cual a `Imagen` o `TarjetaDeBien`. Las rewrites se calculan al compilar: `API_URL` tiene que estar definida al correr `npm run build`.
- **Pestañas con contenido**: une cada `Pestana` (`id`, `panel`) con su `PanelDePestana` (`id`, `pestana`) para que el lector de pantalla sepa qué controla cada una.
- **Calificación de solo lectura**: acepta decimales (promedios) y los dibuja con media estrella.

## Calendario de disponibilidad (FE-5.1)

`CalendarioDeDisponibilidad` (`components/calendario-de-disponibilidad.tsx`) muestra 12 meses desde hoy con el estado de cada día (disponible, reservado, bloqueado o pasado) y deja elegir un rango. Se monta en el detalle del bien (`/bienes/[id]`, solo con sesión) y, con `modo="gestion"`, en el bloqueo de fechas del arrendador (FE-7.1).

```tsx
import { CalendarioDeDisponibilidad } from "@/components/calendario-de-disponibilidad";

<CalendarioDeDisponibilidad
  bienId={bien.id}
  modo="seleccion" // o "gestion"
  onRangoSeleccionado={(inicio, fin) => setFechas(inicio && fin ? { inicio, fin } : null)} // AAAA-MM-DD
/>
```

- **Selección:** primer clic = inicio, segundo = fin, un tercero empieza de nuevo. Un segundo clic anterior al inicio lo reemplaza. Si el rango incluye un día reservado, bloqueado o pasado se descarta y se muestra «El rango incluye fechas no disponibles.».
- **Estados:** cargando (esqueleto), listo y error. El error distingue tres casos: sesión vencida (401, con botón para volver a iniciar sesión), publicación inexistente (404) y cualquier otro fallo (red, 5xx), con «Reintentar».
- **Datos:** consulta `GET /api/bienes/[bienId]/disponibilidad` del propio Next (`app/api/bienes/[bienId]/disponibilidad/route.ts`), que reenvía a `GET {API_URL}/bienes/:bienId/disponibilidad` del backend con el token de la cookie `httpOnly`. Necesita una sesión iniciada y `API_URL` con el prefijo de la API (por ejemplo `http://localhost:3000/api/v1`), igual que el login.
- **Fechas:** «hoy» es el día de El Salvador (`America/El_Salvador`), igual que en el backend. Las reglas están en `lib/disponibilidad.ts`.
- `onRangoSeleccionado` se llama con `(inicio, fin)` cuando el rango es válido y con `(null, null)` cuando ese rango deja de estar vigente (por ejemplo, al empezar una selección nueva); úsalo para habilitar o deshabilitar la acción del padre. La solicitud de reserva y el panel «Tu selección» son de FE-6.1.

## Portada (FE-3.2)

Página pública `/` (`app/page.tsx`, server component). Se ve con o sin sesión: el proxy la deja pasar siempre, y la barra superior es la del rol de `GET /auth/me` (`obtenerUsuarioActual()` de `lib/usuario-actual.ts`) o la de visitante. Si el access token venció, el proxy lo renueva antes de mostrar la portada, pero nunca redirige. Si `GET /auth/me` responde 401 aunque haya token, la portada redirige a `/sesion-vencida`, que revoca el refresh token, borra las cookies y lleva a `/login`.

- **Barra de búsqueda** (`components/busqueda/barra-de-busqueda.tsx`, cliente, la misma de `/buscar`): texto, departamento y municipio. «Buscar» (o Enter) lleva a `/buscar?q=…&departamento=…&municipio=…` (FE-3.1) y omite los criterios vacíos. El municipio queda deshabilitado hasta elegir departamento y se vacía al cambiarlo.
- **Categorías:** cada una abre `/buscar?categoria=…` (FE-4.1). Las destacadas están en `CATEGORIAS_DESTACADAS` de `lib/busqueda.ts`, junto con `urlDeBusqueda()`, que arma la URL de /buscar.
- **Publicados recientemente** (`components/inicio/publicados-recientemente.tsx`, server component): `GET {API_URL}/bienes?tamano=4`, sin término y sin token, que el backend ordena del más nuevo al más viejo. Mientras carga, un `<Suspense>` muestra esqueletos de `TarjetaDeBien`. Sin bienes muestra un estado vacío, y si la API falla, un error con «Reintentar». En móvil se ven las dos primeras tarjetas.
- **Cómo funciona** y **CTA para arrendadores** («¿Tienes algo que rentar?» → `/registro`).
- **Ubicaciones:** `lib/ubicaciones.ts` tiene los 14 departamentos con sus 262 municipios tradicionales, escritos igual que los guarda el backend (la búsqueda compara el texto exacto). Úsalo también en los formularios que pidan ubicación.

```ts
import { DEPARTAMENTOS, municipiosDe } from "@/lib/ubicaciones";
import { urlDeBusqueda } from "@/lib/busqueda";

municipiosDe("La Libertad"); // ["Antiguo Cuscatlán", …, "Santa Tecla", …]
urlDeBusqueda({ q: "salón", departamento: "La Libertad" }); // "/buscar?q=sal%C3%B3n&departamento=La+Libertad"
```

## Detalle del bien (FE-2.1)

Página pública `/bienes/[id]` (`app/bienes/[id]/page.tsx`, server component). Consulta `GET {API_URL}/bienes/:bienId` sin token (`obtenerBienDetalle()` de `lib/bienes.ts`) y sin caché, para que un bien desactivado deje de verse de inmediato. El título de la pestaña es el del bien (`generateMetadata`; el `fetch` se memoiza, así que se pide una sola vez).

- **Marco:** `app/bienes/[id]/layout.tsx` pone la barra superior según la sesión (igual que la portada, con el mismo paso por `/sesion-vencida` si el token venció) y el pie. Está en el layout para que también envuelva la carga, el «no disponible» y el error.
- **Contenido** (`components/bienes/detalle-del-bien.tsx`): tipo y categoría, título, ubicación, precio con su unidad («$80.00 / día»), depósito con dos decimales o «Sin depósito de garantía» si es 0 (`formatearDeposito()`), capacidad solo si existe, descripción, condiciones, dirección de referencia y el nombre de usuario del arrendador. En escritorio el resumen (precio, depósito, capacidad y arrendador) va en una columna de 400 px; en móvil, debajo de la galería.
- **Galería** (`components/bienes/galeria-de-fotos.tsx`, cliente): carrusel que empieza en la foto principal y se recorre deslizando (umbral de 50 px), con las flechas, con los puntos (móvil), con las miniaturas (escritorio) o con ← y → del teclado. Cada foto usa `Imagen`, que muestra «Foto no disponible» si la URL no carga o si el bien no tiene fotos. Las fotos llegan como `/uploads/…` y las sirve la rewrite de `next.config.ts`, así que no hace falta `remotePatterns`.
- **Disponibilidad:** con sesión se monta `CalendarioDeDisponibilidad`. Sin sesión se invita a iniciar sesión, porque el endpoint de disponibilidad pide token.
- **Estados:** `loading.tsx` (esqueleto), `not-found.tsx` («Esta publicación ya no está disponible.» con enlace a `/buscar`) y `error.tsx` («No pudimos cargar la publicación. Intenta de nuevo.» con «Reintentar», que llama a `retry()`). Un id que no es uuid y el 404 del backend (bien inexistente o inactivo) van a `not-found`; cualquier otro fallo, a `error`.
- Con `loading.tsx` la respuesta empieza a transmitirse antes de saber si el bien existe, así que la página de no disponible llega con HTTP 200. Next le agrega `<meta name="robots" content="noindex">`.

## Búsqueda (FE-3.1)

Página pública `/buscar` (`app/buscar/page.tsx`). El layout (`app/buscar/layout.tsx`) pone la barra superior según la sesión, igual que la portada.

- **Criterios en la URL:** `/buscar?q=salon&departamento=…&municipio=…` (y `categoria`, que llega desde la portada). `criteriosDesdeUrl()` de `lib/busqueda.ts` los lee de `searchParams` (en Next 16 es una Promise): descarta los vacíos, ignora el municipio sin departamento y corta `q` a 100 caracteres, el máximo del backend. Recargar o compartir el enlace conserva la búsqueda.
- **Barra de búsqueda:** arranca con los criterios de la URL (`variante="resultados"`) y, al buscar de nuevo, conserva la categoría.
- **Resultados** (`components/busqueda/resultados-de-busqueda.tsx`, cliente): pide páginas de 20 con `buscarBienes()`. Un `IntersectionObserver` sobre el final de la lista pide la siguiente mientras `hayMas` sea verdadero, y nunca hay dos peticiones a la vez. Estados: esqueletos, vacío («No encontramos bienes que coincidan con «{q}».»), error («No pudimos cargar los resultados.» con «Reintentar»), «Cargando más resultados…» y «No hay más resultados.». Si falla una página siguiente, se conserva lo cargado y se puede reintentar.
- **Puente `/api/bienes`** (`app/api/bienes/route.ts`): la URL del backend solo existe en el servidor, así que el navegador pide aquí y el handler reenvía a `GET {API_URL}/bienes`, sin token y solo con los parámetros de `PARAMETROS_DE_BUSQUEDA` más `pagina` y `tamano`. Devuelve el mismo código del backend, o 502 si no responde.

### Filtros (FE-4.1)

- **En la URL:** `precioMin`, `precioMax`, `tipo` (`PROPIEDAD` o `EQUIPO`), `categoria`, `capacidadMin`, `fechaInicio` y `fechaFin` (AAAA-MM-DD). `criteriosDesdeUrl()` ignora los valores con forma inválida (un precio que no es número, un tipo inventado), escribe la categoría como en el catálogo (`lib/catalogos/bienes.ts`) y descarta la capacidad si el tipo no es Propiedad. Las combinaciones inválidas que llegan en una URL editada a mano (mínimo mayor que el máximo) se envían igual: el backend responde 400.
- **Panel** (`components/busqueda/panel-de-filtros.tsx`): lateral desde `lg`. En pantallas menores, el botón «Filtros (n)» lo abre como hoja a pantalla completa (`filtros-de-busqueda.tsx`), que se cierra con la X, con Escape o al aplicar. Es un `<dialog>` abierto con `showModal()`: atrapa el foco, bloquea el scroll del fondo, devuelve el foco a «Filtros» al cerrarse y se cierra sola si la pantalla crece hasta `lg`. El tipo tiene tres opciones: «Todos» (marcada por defecto, no envía `tipo`), «Propiedad» y «Equipo». La categoría ofrece las del tipo elegido (con «Todos», todas) y la capacidad mínima se muestra solo con «Propiedad». Quitar el chip «Propiedad» también quita la capacidad.
- **Aplicar:** valida antes de enviar (`validarFiltros()` de `lib/validaciones/filtros.ts`: precio mínimo ≤ máximo, fin ≥ inicio, sin fechas pasadas, las dos fechas juntas) y muestra el mensaje bajo el campo. Si todo está bien, escribe los filtros con `router.replace` y la lista vuelve a la página 1. **Limpiar filtros** conserva `q` y la ubicación.
- **Chips** (`chips-de-filtros.tsx`): uno por filtro activo, en el orden del diseño (el rango de precio y el de fechas son un chip cada uno). La X quita ese filtro de la URL.
- **Errores:** con filtros, un 400 muestra «Revisa los filtros marcados.» con el mensaje del backend y «Limpiar filtros»; un 500 o la red caída, «No pudimos aplicar los filtros. Intenta de nuevo.» con «Reintentar».

## Panel de reportes (FE-23.1)

Panel del arrendador en `/reportes`, con un selector de periodo y pestañas que comparten las cuatro secciones. `/reportes` redirige a `/reportes/ingresos`.

| Ruta | Sección | Se completa en |
| --- | --- | --- |
| `/reportes/ingresos` | Ingresos | H23 (FE-23.2) |
| `/reportes/ocupacion` | Ocupación | H24 (FE-24.1) |
| `/reportes/calificaciones` | Calificaciones | H25 (FE-25.1) |
| `/reportes/resumen` | Resumen | H26 (FE-26.1 y FE-26.2) |

Mientras una sección no está conectada a su endpoint, muestra un aviso provisional (`components/reportes/seccion-pendiente.tsx`).

- **Acceso:** `app/reportes/layout.tsx` (server component) lee el usuario con `GET /auth/me` (`obtenerUsuarioActual()` de `lib/usuario-actual.ts`, memorizado por request). Solo entra el rol `ARRENDADOR`. El `ARRENDATARIO` ve «No tienes acceso a este panel.» con «Ir al inicio» y las secciones no se montan, así que no se llama a ningún endpoint de reportes. Sin sesión, o con un 401 de `/auth/me` (sesión vencida), se redirige a `/sesion-vencida` (`app/sesion-vencida/route.ts`), que revoca el refresh token en el backend, borra las cookies `access_token` y `refresh_token` y lleva a `/login`. `apiFetch` usa la misma ruta cuando recibe un 401. Si `/auth/me` falla por otra causa, se muestra el error con «Reintentar».
- **Selector de periodo:** `PanelDeReportes` (`components/reportes/panel-de-reportes.tsx`, cliente) usa el `SelectorDePeriodo` del design system. Último mes (30 días), Últimos 3 meses (90 días) y Último año (365 días) cambian el periodo al elegirlos. Con «Rango de fechas», «Aplicar» valida el rango en el navegador y solo entonces cambia el periodo. Si el rango no sirve, muestra el error y no consulta al servidor:
  - falta una fecha: «Completa las fechas del rango.»;
  - el formato no es AAAA-MM-DD o la fecha no existe: «Usa el formato AAAA-MM-DD.»;
  - Hasta es anterior a Desde: «La fecha final no puede ser anterior a la inicial.»;
  - el rango pasa de 365 días: «El rango no puede ser mayor a 365 días.».
- **Periodo compartido:** el periodo vive en el layout, que no se desmonta al cambiar de pestaña, así que se conserva entre secciones. Cada sección lo lee con `usePeriodoReporte()` y lo convierte en la consulta del endpoint con `consultaDePeriodo()`:

```tsx
"use client";
import { usePeriodoReporte } from "@/components/reportes/periodo-compartido";
import { consultaDePeriodo } from "@/lib/periodo-reporte";

const periodo = usePeriodoReporte(); // { periodo: "ULTIMO_MES" } o { periodo: "RANGO", desde, hasta }
const consulta = consultaDePeriodo(periodo).toString(); // "periodo=RANGO&desde=…&hasta=…"
```

- **El periodo no va en la URL:** vive solo en el estado de React, así que al recargar o compartir el enlace vuelve a «Último mes». Es intencional (la tarjeta no pide persistirlo); si más adelante se necesita, habría que llevarlo a los `searchParams`.
- **Rango inválido:** el selector queda en «Rango de fechas» con el error, pero las secciones siguen mostrando el último periodo válido hasta que se aplique un rango correcto. Es intencional: no se consulta al servidor con fechas que va a rechazar.
- Las reglas del periodo y los textos de error están en `lib/periodo-reporte.ts`. Son los mismos que usa el backend (`MENSAJES_PERIODO`).

### Consultar los reportes desde el navegador (H23 a H26)

El token vive en cookies httpOnly que el navegador no puede leer. Por eso las secciones consultan un puente de Next, `app/api/reportes/[reporte]/route.ts` (`ingresos`, `ocupacion`, `calificaciones` o `resumen`), que reenvía `periodo`, `desde` y `hasta` a `GET {API_URL}/reportes/:reporte` con el token. Antes de llamar al backend renueva el access token vencido con `obtenerAccesoVigente` y escribe las cookies nuevas con `aplicarCambiosDeSesion` en cada respuesta, errores incluidos (igual que `app/api/bienes/[bienId]/disponibilidad`). Los 400 y 403 del backend se devuelven tal cual; sin sesión responde 401.

- `lib/reportes/cliente.ts`: `consultarReporte()` pide el reporte con el periodo compartido y traduce la respuesta (401 sesión vencida, 403 sin acceso, 400 con el texto del servidor y cualquier otro error como fallo general).
- `components/reportes/use-reporte.ts`: `useReporte(reporte)` consulta al abrir la sección y cada vez que cambia el periodo. Si el periodo cambia con una consulta en curso, la cancela y solo cuenta la del último. Conserva la última respuesta exitosa si una consulta nueva falla. Con 401 lleva a `/sesion-vencida`.
- `components/reportes/marco-de-reporte.tsx`: los estados que comparten las secciones: cargando (con la tabla anterior atenuada), «Aún no tienes bienes publicados.», 400 (texto del servidor), 403 («No tienes acceso a este panel.») y red o 500 («No pudimos cargar el reporte. Intenta de nuevo.» con «Reintentar»). Con un error y una tabla anterior, el mensaje va encima y la tabla se conserva.
- `lib/reportes/formato.ts`: `$1,250.00`, `50.0 %`, `4.5 / 5`, «1 reseña» / «N reseñas» y los textos «Sin días disponibles» y «Sin calificaciones».

**Ingresos (`/reportes/ingresos`)**: dos tarjetas (ingreso total y depósito retenido), una tabla Bien · Ingresos · Depósito retenido y la fila Total que devuelve el servicio. El depósito retenido va en su propia columna y nunca se suma al ingreso; un valor 0 se muestra `$0.00`.

**Ocupación (`/reportes/ocupacion`)**: tabla Bien · Días disponibles · Días ocupados · Tasa de ocupación (`50.0 %`; `null` es «Sin días disponibles»). El encabezado de la tasa es un botón que alterna de mayor a menor (por defecto) y de menor a mayor, con indicador y `aria-sort`. El orden se aplica en el cliente (`components/reportes/orden-ocupacion.ts`): los bienes sin tasa quedan al final en los dos sentidos y, a igual tasa, se ordena por título de la A a la Z. El orden elegido se conserva al cambiar de periodo.

**Calificaciones (`/reportes/calificaciones`)**: tabla Bien · Calificación promedio (`4.5 / 5`, con la `escalaMaxima` de la respuesta) · Reseñas («1 reseña» en singular, «N reseñas» en plural), en el orden del servicio (de menor a mayor calificación). Un `promedio` `null` se muestra «Sin calificaciones» y nunca 0.

## Solo usuarios verificados (H19, AF-105)

El arrendador decide si su bien exige usuarios verificados y el detalle del bien lo muestra con una etiqueta. Están hechas las piezas; **falta montarlas** porque las páginas `/mis-bienes/[id]` y `/bienes/[id]` son del Módulo 1.

| Pieza | Dónde |
| --- | --- |
| Capa de datos (`consultarPolitica`, `actualizarPolitica`, errores 401/403/404/general) | `lib/politica-verificacion.ts` |
| Puente a la API (`GET` y `PUT /api/bienes/[bienId]/politica-verificacion`) | `app/api/bienes/[bienId]/politica-verificacion/route.ts` |
| Acceso a la sesión de las rutas `app/api/**` (renueva el token y escribe las cookies en cada respuesta) | `lib/api-backend.ts` |
| Tarjeta «Quién puede reservar» con el interruptor | `components/politica-verificacion/interruptor-politica-verificacion.tsx` |
| Etiqueta «Solo usuarios verificados» | `components/politica-verificacion/etiqueta-solo-verificados.tsx` |

Cómo montarlas:

```tsx
// /mis-bienes/[id] (servidor): trae la política y el estado del arrendador y pásalos.
<InterruptorPoliticaVerificacion
  bienId={bien.id}
  soloVerificadosInicial={politica.soloVerificados}   // GET /bienes/:id/politica-verificacion
  arrendadorVerificado={estado === "VERIFICADO"}       // GET /verificaciones/mi-estado
  hrefVerificacion="/perfil"                           // carga del documento (FE-17.1)
/>

// /bienes/[id]: la etiqueta solo se pinta si el bien exige verificados.
{politica.soloVerificados && <EtiquetaSoloVerificados />}
```

- Si falla el guardado, el interruptor vuelve a su valor anterior y el error aparece debajo; el 401 cierra la sesión con `cerrarSesion` (se cambia con `alSesionVencida`).
- Activar la opción exige arrendador VERIFICADO (403 del backend). Sin verificar, el interruptor va deshabilitado con el aviso y el enlace, salvo que la opción ya estuviera activa (se puede apagar).
- `arrendadorVerificado` y `soloVerificadosInicial` los resuelve la página; el componente solo guarda con `PUT`.

## Perfil y verificación de identidad (`/perfil`, H17)

Pantalla para enviar el documento de identidad y ver el estado de verificación (`NO_VERIFICADO`, `EN_REVISION`, `VERIFICADO`, `RECHAZADO`).

- **Dónde**: `app/perfil/` (página y panel), `lib/verificacion/` (reglas, validación y llamadas del navegador) y `app/api/verificaciones/` (puentes a la API).
- **Puentes**: el token vive en la cookie httpOnly `access_token`, así que el navegador llama a `/api/verificaciones` (POST multipart, campo `documento`) y a `/api/verificaciones/mi-estado` (GET), y el servidor agrega el token. El POST reenvía el cuerpo sin leerlo entero. Las rutas `/api` no pasan por el proxy: `sesionDeRuta` (`lib/api-servidor.ts`) renueva el access token con la renovación compartida y `conSesion` envuelve cada respuesta para escribir o borrar las cookies, como en la ruta de disponibilidad.
- **Validación**: JPG, PNG o PDF de hasta 5 MB, también en el cliente (el servidor valida de nuevo por el contenido). La subida usa `XMLHttpRequest` para mostrar el avance.
- **Revisión**: con `EN_REVISION` el formulario queda deshabilitado y se consulta el estado cada 5 s, hasta 60 s; después se avisa «Seguimos revisando tu documento» y hay un botón para consultar de nuevo. `RECHAZADO` muestra el motivo y habilita una carga nueva.
- **Sesión vencida (401)**: al cargar `/perfil`, un 401 de `/auth/me` o de `mi-estado` lleva a `/sesion-vencida`. Si vence con la pantalla abierta, el panel muestra el aviso con la acción `cerrarSesion` para volver a entrar.
- **Datos de la cuenta**: la API no tiene un endpoint de perfil: nombre, correo, rol y fecha de alta salen de `GET /auth/me` (`obtenerUsuarioActual()`); la pantalla no lee el token. «Miembro desde» es `createdAt` escrito como «19 de noviembre de 2026», en la zona horaria de El Salvador (`app/perfil/miembro-desde.ts`); si la fecha no es válida, la fila no se muestra.

## Solicitud de reserva con estado «en cola» (FE-6.1)

`SolicitudDeReserva` (`components/solicitud-de-reserva.tsx`) junta el calendario en modo `seleccion` con el panel «Tu selección»: resumen del rango (duración, alquiler estimado y depósito), botón «Solicitar reserva» y el indicador de estado. Hoy se ve en `/bienes/[bienId]/reservar`; cuando exista el detalle del bien (FE-2.1) se puede montar ahí tal cual: `<SolicitudDeReserva bien={{ id, titulo, precio, unidadCobro, deposito }} />`.

- **Estados** (`lib/solicitud/use-solicitud-de-reserva.ts`): libre → enviando (botón en «Procesando…», calendario bloqueado, un segundo envío se ignora) → en cola → confirmada, rechazada (con el motivo) o sin respuesta. Si el envío falla, no llega a encolarse y se muestra el error.
- **En cola:** tras el 202 consulta la solicitud cada 2 s, hasta 30 s. Se detiene al llegar a un estado final, al pasar los 30 s («Tu solicitud sigue en proceso. Revisa Mis reservas.») o al salir de la página. Un fallo suelto de red al consultar no corta la espera.
- **Errores al enviar:** 409 «Esas fechas ya no están disponibles.»; 403 `VERIFICACION_REQUERIDA` con enlace a `/perfil` (FE-17.1); 422 con el mensaje del servicio; 401 con botón «Iniciar sesión» (acción `cerrarSesion`); red o 5xx «No pudimos enviar tu solicitud. Intenta de nuevo.» con reintento.
- **Datos:** el navegador llama a `POST /api/reservas` y `GET /api/reservas/[reservaId]` del propio Next (`app/api/reservas/`), que reenvían a `POST {API_URL}/reservas` y `GET {API_URL}/reservas/:id` con el token de la cookie `httpOnly`. La página lee el título, el precio y el depósito del bien en `GET {API_URL}/bienes/:bienId` (público).
- **Sesión:** las rutas `app/api/reservas` renuevan el access token con `obtenerAccesoVigente` y escriben las cookies con `aplicarCambiosDeSesion` en cada respuesta, errores incluidos (`lib/solicitud/servidor.ts`); la llamada al backend usa `llamarApi` de `lib/api.ts`.
- **Enlaces a otras pantallas** (constantes al inicio del componente): `/reservas` (Mis reservas, FE-6.2), `/reservas/[id]/pago` (pago, FE-8.1) y `/perfil`. Mientras esas pantallas no estén en la rama, esos enlaces dan 404; el flujo no depende de ellas. El panel no enlaza a `/reservas/[id]` (FE-6.2/FE-6.3).
- **Alquiler estimado** (`lib/solicitud/formato.ts`): replica `unidadesACobrar` del backend (`src/pagos/utils/calcular-cargos.ts`, BE-8.1) para que coincida con el cobro: `DIA` → días; `NOCHE` → `max(días − 1, 1)`; `SEMANA` → `ceil(días / 7)`; `HORA` → `días × 24`; redondeado a dos decimales. La API no calcula el monto en la solicitud, así que es una referencia: si el backend cambia esa regla, hay que cambiar también `unidadesACobrar` aquí.

## Gestión de bloqueos de fechas (FE-7.1)

`GestionDeBloqueos` (`components/gestion-de-bloqueos.tsx`) es la vista del arrendador para bloquear fechas de un bien: reutiliza `CalendarioDeDisponibilidad` en `modo="gestion"`, bloquea el rango elegido, lista los bloqueos vigentes con «Eliminar» (con confirmación) y muestra las reservas confirmadas en solo lectura. Está montada en `/mis-bienes/[id]/bloqueos` (`app/mis-bienes/[id]/bloqueos/page.tsx`), la ruta del flujo de Figma, con la barra de navegación del arrendador y el pie de página. La página pasa por `/sesion-vencida` sin sesión, muestra «sin permiso» al arrendatario y un error con «Reintentar» si `/auth/me` falla; el sobretítulo muestra «Mis bienes · <título del bien>» (de `GET /bienes/:id`) o solo «Mis bienes» si esa consulta falla. La barra no marca «Mis bienes» como activo porque solo compara la ruta exacta (`/mis-bienes`). Cuando exista `/mis-bienes/[id]` (Módulo 1), enlaza allí «Bloquear fechas»; para usarla en otra página basta `<GestionDeBloqueos bienId={id} />` dentro de un `Contenedor`.

- **Datos:** rutas de Next que reenvían al backend con el access token de la cookie `httpOnly`: `GET` y `POST /api/bienes/[bienId]/bloqueos`, y `DELETE /api/bienes/[bienId]/bloqueos/[id]`. Usan `llamarBackend` (`lib/api-backend.ts`), el puente común de las rutas `/api`: renueva el token, llama al backend y escribe las cookies nuevas en cada respuesta, errores incluidos; un 204 (DELETE) se devuelve sin cuerpo.
- **Requiere BE-7.3:** usa `GET /bienes/:bienId/bloqueos` (`[{ id, fechaInicio, fechaFin, creadoEn }]`) del backend; sin él la lista muestra «No pudimos cargar los bloqueos» y no se puede eliminar. `GET /disponibilidad` no trae el id de los bloqueos.
- **Errores** (`lib/bloqueos.ts`, `mensajeDeError`): 409 con reserva «Hay una reserva confirmada en ese rango.»; 409 con otro bloqueo «El rango se solapa con otro bloqueo de este bien.»; 403 «No puedes modificar este bien.»; 422 el mensaje del servicio. Un error solo muestra su aviso: no recarga ni borra la selección. Un 401 muestra «Tu sesión expiró.» con el botón que ejecuta `cerrarSesion`. Si el bloqueo ya no existe (404) al eliminar, se avisa y se actualiza la lista.
- **Refresco:** tras bloquear o eliminar se vuelve a consultar el calendario y la lista. Para eso `CalendarioDeDisponibilidad` acepta `actualizacion` (al cambiar, recarga y descarta la selección) y `onDisponibilidad` (recibe la disponibilidad cargada).
- **Pendiente:** Figma muestra el usuario de cada reserva y los campos Desde/Hasta; la API de disponibilidad solo devuelve rangos, así que las reservas se listan sin usuario, y Desde/Hasta reflejan el rango elegido en el calendario (solo lectura).

## Mis reservas (`/reservas`, AF-63)

Pantalla del arrendatario con sus solicitudes y reservas: filtro por estado (Todas, En cola, Confirmadas, En curso, Finalizadas, Rechazadas y Canceladas), motivo de rechazo y estados de carga, vacío y error con reintento.

- **Datos**: `app/reservas/mis-reservas.tsx` (cliente) consulta `GET /api/reservas/mias?estado=`, un route handler que agrega el token de la cookie `access_token` (renovándolo si venció, con la renovación compartida de `lib/sesion-vigente.ts`) y llama a `GET {API_URL}/reservas/mias`. El listado del backend (BE-6.3) solo trae `bienId`, así que `lib/reservas/servidor.ts` completa título, foto y arrendador con el detalle público `GET /bienes/:id` (un fallo ahí no rompe la fila). Cuando exista BE-6.5 basta con quitar ese paso.
- **Sesión**: el route handler renueva el access token con `obtenerAccesoVigente` y escribe o borra las cookies en cada respuesta con `aplicarCambiosDeSesion`, como la ruta de disponibilidad. La página `/reservas` toma el nombre de `obtenerUsuarioActual()` y, sin sesión, lleva a `/sesion-vencida`. Un 401 con la pantalla abierta muestra «Tu sesión venció» con un botón que ejecuta la acción `cerrarSesion`.
- **Acciones por estado** (Figma FE-6.2): Confirmada → «Pagar ahora», En curso → «Coordinar entrega», Finalizada → «Calificar», el resto → «Ver detalle». Sus destinos (`/reservas/:id/pago`, `/entrega`, `/calificar`, `/reservas/:id`) aún no existen; los crean FE-8.1, FE-14.1, FE-15.1 y el detalle.
- **Probarla**: `API_URL=http://localhost:3000/api/v1` en `.env.local`, iniciar sesión con un arrendatario del seed (`demo@example.com`) y abrir `/reservas`.

## Reservas recibidas (`/reservas-recibidas`, AF-173)

Pantalla del arrendador con las solicitudes y reservas de sus bienes: filtro por estado (Todas, En cola, Confirmadas, En curso, Finalizadas y Rechazadas), paginación de 20 en 20 con «Cargar más», y estados de carga, vacío y error con reintento.

- **Datos**: `app/reservas-recibidas/reservas-recibidas.tsx` (cliente) consulta `GET /api/reservas/recibidas?estado=&pagina=`, un route handler que valida el filtro y la página (el backend rechaza `CANCELADA` y páginas que no sean enteros positivos escritos solo con dígitos) y reenvía con `reenviarAApi` a `GET {API_URL}/reservas/recibidas` (BE-27.1). Cada elemento ya trae bien, arrendatario, pago y depósito (BE-6.5), así que no hace falta consultar nada más. Tipos y textos en `lib/reservas/recibidas.ts`.
- **Paginación**: el backend responde `{ items, pagina, total, hayMas }`; «Cargar más» pide la página siguiente y la agrega. Cuando `hayMas` es `false` se muestra «No hay más reservas.». Si cambia el filtro, se vuelve a la página 1.
- **Acceso**: `app/reservas-recibidas/page.tsx` toma el rol de `obtenerUsuarioActual()`: sin sesión lleva a `/sesion-vencida` y un ARRENDATARIO ve «sin permiso» (la lista no se monta ni llama a la API).
- **Acción de cada fila**: «Gestionar» abre `/reservas/:id` (FE-6.3, aún no existe).
- **Probarla**: `API_URL=http://localhost:3000/api/v1` en `.env.local`, iniciar sesión con un arrendador del seed (`arrendador@example.com`) y abrir `/reservas-recibidas`.

## Detalle de una reserva (`/reservas/[reservaId]`, FE-6.3)

Pantalla que ven el arrendatario de la reserva y el arrendador dueño del bien: bien, línea de estados, fechas, participantes, pago, depósito y las acciones que cada rol tiene según el estado. A ella enlazan la lista de reservas, la conversación y las calificaciones.

- **Datos**: `app/reservas/[reservaId]/datos.ts` (servidor) pide en paralelo `GET /auth/me` y `GET /reservas/:id` (enriquecido por BE-6.5, abierto al arrendador por BE-27.2) con `llamarApi`. `lib/reservas/detalle.ts` valida la respuesta (`leerDetalle`), decide el rol (`rolEnReserva`) y las acciones. Sin sesión, `/sesion-vencida`.
- **No encontrada**: una reserva inexistente, un id que no es UUID, un 404/403 del backend o un usuario que no es ni el arrendatario ni el arrendador muestran «No encontramos esa reserva.» sin ningún dato de la reserva.
- **Carga y error**: `loading.tsx` y `error.tsx` (con «Reintentar») en la misma carpeta.
- **Acciones**: arrendatario → «Pagar ahora» (confirmada y sin pago exitoso, `/pago`) y «Calificar» (finalizada, `/calificar`); ambos → «Abrir conversación» (confirmada o en curso, `/conversacion`); arrendador → «Registrar devolución» (en curso, `/devolucion`), «Resolver depósito» (finalizada con depósito pendiente, `/deposito/resolver`) y «Calificar arrendatario» (finalizada, `/calificar-arrendatario`). Las que aún no aplican se muestran deshabilitadas. El backend vuelve a validar cada una.
- **Pago y depósito**: con un pago exitoso, el alquiler es el total menos el depósito. Con un pago rechazado o pendiente solo se muestran el total y el estado, porque el backend no devuelve el depósito aunque el total lo incluya. El enlace «Ver comprobante» (`/pagos/:id/comprobante`) aparece solo al arrendatario con un pago exitoso: el backend no deja al arrendador consultarlo.
- **Lo que Figma trae y la API no expone**: el código «RSV-…», la ubicación del bien, la modalidad de pago («Tarjeta •••• 4242») y la pantalla «Ver detalle del depósito». No se muestran. «Resolver depósito» enlaza a `/reservas/:id/deposito/resolver` (FE-11.1, ya integrada). La API no dice si hay una devolución registrada, así que en una reserva cerrada automáticamente sin devolución el botón puede estar habilitado y el backend responde 422 y la pantalla de resolución muestra su mensaje.
- **Probarla**: con `API_URL` apuntando al backend, iniciar sesión con `arrendador@example.com` o `demo@example.com` (clave `Demo1234!`) y abrir `/reservas/<id>` de una reserva propia.

## Mis bienes (`/mis-bienes`, FE-1.2)

Pantalla del arrendador con sus publicaciones: foto, estado (Activa o Inactiva), título, precio, ubicación, el interruptor «Solo usuarios verificados», las acciones «Bloquear fechas» y «Ver publicación», paginación de 20 en 20 con «Cargar más» y estados de carga, vacío y error con reintento.

- **Datos**: `app/mis-bienes/mis-bienes.tsx` (cliente) consulta `GET /api/bienes/mios?pagina=`, un route handler que valida la página y reenvía con `reenviarAApi` a `GET {API_URL}/bienes/mios` (BE-1.3). Tipos y textos en `lib/mis-bienes.ts`.
- **Interruptor**: `components/mis-bienes/fila-de-bien.tsx` reutiliza `actualizarPolitica` de H19. Se aplica de inmediato y, si falla, vuelve al valor anterior y muestra el error bajo la fila. Si el arrendador no está VERIFICADO (`GET /verificaciones/mi-estado`, leído en `page.tsx`) no puede activarlo, solo apagarlo, y se le enlaza a `/perfil`.
- **Acceso**: `page.tsx` toma el rol de `obtenerUsuarioActual()`: sin sesión lleva a `/sesion-vencida` y un ARRENDATARIO ve «sin permiso».
- **Publicar**: el encabezado lleva el botón «Publicar un bien» hacia `/publicar` (FE-1.1). La barra superior y el pie de página enlazaban a `/mis-bienes/nuevo`, que no existe; ahora apuntan a `/publicar`.
- **Enlaces**: «Bloquear fechas» abre `/mis-bienes/:id/bloqueos` (FE-7.1) y «Ver publicación» abre `/bienes/:id` (FE-2.1; da 404 hasta que entre).
- **Probarla**: `API_URL=http://localhost:3000/api/v1` en `.env.local`, iniciar sesión con un arrendador del seed (`arrendador@example.com`) y abrir `/mis-bienes`.
**Resumen (`/reportes/resumen`)**: una fila por bien con Bien · Ingresos · Tasa de ocupación · Calificación promedio (`4.5 / 5 (2 reseñas)` o «Sin calificaciones»), del mismo periodo compartido y en el orden del servicio; no hay otro selector de periodo. Sobre la tabla muestra el periodo resuelto por el servicio (`Periodo: 2026-10-17 a 2026-11-15`). Con un 400 o una caída de red o 500 se conserva la última tabla exitosa y el mensaje aparece encima.

**Exportar CSV (FE-26.2)**: el botón «Exportar CSV» (sobre la tabla del resumen) descarga el mismo resumen del periodo en pantalla. Pide `GET /reportes/resumen/exportar` por el puente `app/api/reportes/resumen/exportar/route.ts`, que reenvía el archivo sin decodificarlo (conserva el BOM UTF-8) con su `Content-Disposition` y `Cache-Control: no-store`; el navegador lo guarda con el nombre del servidor (`resumen-desempeno_AAAA-MM-DD_AAAA-MM-DD.csv`).

- Queda deshabilitado sin filas, si la última consulta falló y mientras la descarga está en curso (con «Procesando…», sin permitir un segundo clic). También lo está mientras se actualiza la tabla, para que el archivo nunca sea de otro periodo que el que se ve.
- Errores (no cambian la tabla): 400 muestra el texto del servidor, 403 «No tienes acceso a este panel.» y red o 500 «No pudimos exportar el archivo. Intenta de nuevo.». El mensaje se quita al volver a intentar o al cambiar de periodo.
- `lib/reportes/exportar.ts` (`exportarResumen()`, `nombreDeArchivo()`), `lib/reportes/descarga.ts` (guarda el archivo) y `components/reportes/use-exportar-resumen.ts`.

## Pruebas

```bash
npm test            # una corrida (Vitest + React Testing Library)
npm run test:watch  # modo observación
```

Las pruebas viven junto al código, en archivos `*.test.ts(x)`.

Las pruebas con jsdom necesitan Node 22.22 o superior (`jsdom` 31); con Node 20 Vitest no arranca.

## FE-8.1 — Resumen y pago simulado

### Ruta

`/reservas/{reservaId}/pago`

La pantalla está disponible únicamente para el arrendatario
propietario de la reserva.

### Endpoints utilizados

- `GET /api/v1/reservas/{reservaId}`:
  información de la reserva y del bien.
- `GET /api/v1/reservas/{reservaId}/resumen-pago`:
  cargos calculados por el backend.
- `POST /api/v1/reservas/{reservaId}/pagos`:
  procesamiento del pago simulado.

### Autenticación

La implementación reutiliza el sistema existente de cookies
httpOnly y renovación de tokens.

Las rutas internas de Next.js obtienen la sesión mediante
`sesionDeRuta()` y se comunican con NestJS utilizando el
access token vigente.

El navegador no accede directamente a los tokens.

### Modalidades

#### Tarjeta

- Número: entre 12 y 19 dígitos.
- Vencimiento: MM/AA, no vencido.
- CVV: 3 o 4 dígitos.

Tarjetas de prueba:

- Terminación 4242: aprobación.
- Terminación 0002: rechazo.

#### Transferencia bancaria

- Referencia: entre 6 y 20 caracteres.
- Caracteres permitidos: letras, números y guiones.
- `SIM-APRUEBA`: aprobación simulada.

### Seguridad

- Los importes provienen del backend.
- No se envían importes calculados por el navegador.
- El arrendatario se identifica mediante JWT.
- No se almacenan PAN ni CVV en cookies,
  localStorage o sessionStorage.
- El formulario bloquea envíos simultáneos.
- El backend valida nuevamente los datos y permisos.

### Estados de interfaz

- Cargando.
- Error de conexión.
- Sin permiso.
- Reserva no disponible.
- Reserva ya pagada: con el pago que trae `GET /reservas/{reservaId}` se muestra el total pagado y el enlace «Ver comprobante» (`/pagos/{pagoId}/comprobante`), sin pedir el resumen (el backend responde 422 en ese caso).
- Pago rechazado.
- Pago aprobado.

El backend devuelve HTTP 201 tanto para aprobación como
para rechazo. El frontend interpreta el campo `estado`.

### Pruebas

```bash
npm run lint
npx tsc --noEmit
npm run test
npm run build
```
## Comprobante de pago (FE-9.1 / H9)

- Página protegida: `/pagos/[pagoId]/comprobante`. Solo lectura, compatible con móvil y escritorio.
- Puente autenticado: `GET /api/pagos/[pagoId]/comprobante` → `GET {API_URL}/pagos/:pagoId/comprobante`. Usa el mecanismo compartido de renovación de cookies; el navegador nunca recibe el JWT.
- Un `200` solo se presenta como comprobante si el DTO coincide con el contrato y `estado === SIMULADO_EXITOSO`. `409`: pago sin comprobante de éxito; `403`: sin permiso; `404`: no encontrado; `401`: sesión vencida; errores de red: reintento.
- El botón «Descargar o imprimir» abre el diálogo de impresión del navegador, desde donde puede guardarse como PDF. La navegación de regreso utiliza `/reservas/:reservaId` según Figma.
- Ejecutar: `npx next typegen && npx tsc --noEmit && npm run lint && npm test && npm run build`.
- BE-9.1 devuelve únicamente identificadores, fecha, importes, modalidad y estado. El título del bien, nombre legible de reserva y últimos cuatro dígitos de tarjeta mostrados en el ejemplo de Figma **no pertenecen a ese DTO** y no se inventan ni consultan sin un contrato adicional.

## Registrar devolución ()

Ruta: `/reservas/{reservaId}/devolucion`. 

Acceso: arrendador propietario; el servidor comprueba el rol y la titularidad. 

El formulario solicita fecha/hora local (se envía ISO 8601 con zona), estado final obligatorio y observaciones opcionales (máximo 500 caracteres). Se confirma antes de enviar y se bloquean solicitudes duplicadas. 

El proxy POST `/api/reservas/{reservaId}/devolucion` reenvía la sesión de cookie `httpOnly` al backend `POST /api/v1/reservas/{reservaId}/devolucion`. 

El éxito exige `estadoReserva: FINALIZADA`. Errores 401/403/409/422 y red se muestran sin simular éxito. 

Ejecutar `npx vitest run lib/devoluciones.test.ts`, `npm test`, `npm run lint`, `npm run build`.

Ejecutar `npx vitest run lib/devoluciones.test.ts`, `npm test`, `npm run lint`, `npm run build`.

## FE-11.1 — Resolución del depósito de garantía

- Ruta: `/reservas/{reservaId}/deposito/resolver` (solo ARRENDADOR propietario).
- Consulta autenticada: `GET /api/reservas/{reservaId}/deposito` → backend `GET /api/v1/reservas/{reservaId}/deposito`.
- Resolución autenticada: `POST /api/reservas/{reservaId}/deposito/resolver` → backend `POST /api/v1/reservas/{reservaId}/deposito/resolver`.
- Acciones: `LIBERAR` sin campos adicionales y `RETENER` con importe positivo de hasta dos decimales y justificación de 1–500 caracteres.
- Confirmación previa, prevención de envíos duplicados, bloqueo tras resolución y presentación de los importes devueltos por la API.
- Pruebas: `npx vitest run lib/depositos.test.ts`; verificaciones generales: `npx next typegen && npx tsc --noEmit && npm run lint && npm test && npm run build`.
