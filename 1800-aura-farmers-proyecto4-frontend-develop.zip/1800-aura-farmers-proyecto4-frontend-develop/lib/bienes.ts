/** Unidad de cobro de un bien, igual que el enum `UnidadCobro` del backend. */
export type UnidadCobro = "HORA" | "DIA" | "NOCHE" | "SEMANA";

/** Un resultado de `GET /bienes`. */
export type BienEncontrado = {
  id: string;
  titulo: string;
  precio: number;
  unidadCobro: UnidadCobro;
  departamento: string;
  municipio: string;
  /** Ruta relativa (`/uploads/bienes/…`) o null si el bien no tiene fotos. */
  fotoPrincipal: string | null;
};

const UNIDAD = { HORA: "hora", DIA: "día", NOCHE: "noche", SEMANA: "semana" } as const;

const DOLARES = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD",
  minimumFractionDigits: 2,
});

/** «$80.00 / día»: el precio en USD con dos decimales y su unidad de cobro. */
export function formatearPrecio(precio: number, unidad: UnidadCobro): string {
  return `${DOLARES.format(precio)} / ${UNIDAD[unidad]}`;
}

/** Segundos que la portada reutiliza la lista de recientes antes de pedirla de nuevo. */
export const REVALIDAR_RECIENTES_SEGUNDOS = 60;

/** Cuántos bienes muestra «Publicados recientemente». */
export const CANTIDAD_RECIENTES = 4;

/**
 * Bienes publicados más recientes: `GET {API_URL}/bienes` sin término de
 * búsqueda, que el backend ordena del más nuevo al más viejo. Es público, así
 * que no envía token. La respuesta se reutiliza
 * `REVALIDAR_RECIENTES_SEGUNDOS`: la portada es pública y no necesita un pedido al
 * backend por visita. Lanza si la API no responde o responde con error.
 */
export async function obtenerBienesRecientes(): Promise<BienEncontrado[]> {
  const apiUrl = process.env.API_URL;
  if (!apiUrl) throw new Error("Falta la variable de entorno API_URL.");

  const destino = new URL("bienes", apiUrl.replace(/\/?$/, "/"));
  destino.searchParams.set("tamano", String(CANTIDAD_RECIENTES));
  const respuesta = await fetch(destino, { next: { revalidate: REVALIDAR_RECIENTES_SEGUNDOS } });
  if (!respuesta.ok) throw new Error(`GET /bienes respondió ${respuesta.status}`);

  const { resultados } = (await respuesta.json()) as { resultados: BienEncontrado[] };
  return resultados;
}

/** Tipo de bien, igual que el enum `TipoBien` del backend. */
export type TipoBien = "PROPIEDAD" | "EQUIPO";

/** Una foto del detalle. `url` es una ruta relativa (`/uploads/bienes/…`). */
export type FotoDetalle = {
  url: string;
  orden: number;
  esPrincipal: boolean;
};

/** Respuesta de `GET /bienes/:bienId` (BE-2.1). */
export type BienDetalle = {
  id: string;
  tipo: TipoBien;
  categoria: string;
  titulo: string;
  descripcion: string;
  precio: number;
  unidadCobro: UnidadCobro;
  /** 0 cuando el bien no pide depósito. */
  deposito: number;
  capacidad: number | null;
  condiciones: string | null;
  departamento: string;
  municipio: string;
  direccionReferencia: string | null;
  arrendador: { id: string; nombreUsuario: string };
  /** La principal primero; las demás por orden ascendente. */
  fotos: FotoDetalle[];
  creadoEn: string;
  /**
   * Promedio de las reseñas de tipo BIEN (BE-15.2), con un decimal, o `null`
   * si todavía no tiene. Opcional: un backend anterior a BE-15.2 no lo manda.
   */
  calificacion?: CalificacionBien;
};

export type CalificacionBien = { promedio: number | null; totalResenas: number };

/** Una reseña pública de un bien (`GET /bienes/:bienId/resenas`). */
export type ResenaDeBien = {
  id: string;
  puntuacion: number;
  /** El backend omite la clave cuando la reseña no tiene comentario. */
  comentario?: string;
  autor: { nombreUsuario: string };
  creadaEn: string;
};

export type PaginaResenas = {
  items: ResenaDeBien[];
  pagina: number;
  total: number;
  hayMas: boolean;
};

/** «4.5»: el promedio con un decimal, como lo redondea el backend. */
export function formatearPromedio(promedio: number): string {
  return promedio.toFixed(1);
}

/** «1 reseña», «12 reseñas». */
export function contarResenas(total: number): string {
  return `${total} ${total === 1 ? "reseña" : "reseñas"}`;
}

/** Nombre visible de cada `TipoBien`. */
export const NOMBRE_TIPO: Record<TipoBien, string> = {
  PROPIEDAD: "Propiedad",
  EQUIPO: "Equipo",
};

export const SIN_DEPOSITO = "Sin depósito de garantía";

/** «$150.00», o «Sin depósito de garantía» cuando el depósito es 0 (H2). */
export function formatearDeposito(deposito: number): string {
  return deposito > 0 ? DOLARES.format(deposito) : SIN_DEPOSITO;
}

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Detalle público de un bien: `GET {API_URL}/bienes/:bienId`, sin token.
 * Devuelve `null` si el bien no existe o está inactivo (404) y también si el
 * id no es un uuid: el backend respondería 400, pero para quien abre el enlace
 * es la misma publicación inexistente. Lanza ante cualquier otro error.
 *
 * No se cachea: un bien que el arrendador desactiva debe dejar de verse de
 * inmediato. `fetch` se memoiza por request, así que la página y
 * `generateMetadata` lo piden una sola vez.
 */
export async function obtenerBienDetalle(bienId: string): Promise<BienDetalle | null> {
  if (!UUID.test(bienId)) return null;

  const apiUrl = process.env.API_URL;
  if (!apiUrl) throw new Error("Falta la variable de entorno API_URL.");

  const destino = new URL(`bienes/${bienId}`, apiUrl.replace(/\/?$/, "/"));
  const respuesta = await fetch(destino, { cache: "no-store" });
  if (respuesta.status === 404 || respuesta.status === 400) return null;
  if (!respuesta.ok) throw new Error(`GET /bienes/${bienId} respondió ${respuesta.status}`);

  return (await respuesta.json()) as BienDetalle;
}

/**
 * Primera página de reseñas de un bien (BE-15.2), en el servidor: es pública,
 * así que va sin token. Si falla, el detalle se muestra igual y la sección de
 * reseñas avisa que no pudo cargarlas: por eso devuelve `null` en lugar de lanzar.
 */
export async function obtenerResenasDeBien(bienId: string): Promise<PaginaResenas | null> {
  const apiUrl = process.env.API_URL;
  if (!apiUrl || !UUID.test(bienId)) return null;
  const destino = new URL(`bienes/${bienId}/resenas?pagina=1`, apiUrl.replace(/\/?$/, "/"));
  try {
    const respuesta = await fetch(destino, { cache: "no-store", signal: AbortSignal.timeout(5000) });
    if (!respuesta.ok) return null;
    return (await respuesta.json()) as PaginaResenas;
  } catch {
    return null;
  }
}
