import type { Rol } from "../jwt";

/**
 * Reglas del registro, iguales a las de `CreateUserDto` del backend. Se usan
 * en el formulario (para habilitar el botón) y en la server action (para no
 * llamar a la API con datos que el backend va a rechazar).
 */

export const NOMBRE_USUARIO_MIN = 3;
export const NOMBRE_USUARIO_MAX = 30;
export const EMAIL_MAX = 254;
export const PASSWORD_MIN = 8;
// bcrypt trunca en 72 bytes; el backend rechaza contraseñas más largas.
export const PASSWORD_MAX = 72;
export const ROLES: readonly Rol[] = ["ARRENDADOR", "ARRENDATARIO"];

const PATRON_NOMBRE_USUARIO = /^[A-Za-z0-9._-]+$/;
const PATRON_EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const PATRON_PASSWORD = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).+$/;

export type CampoRegistro = "nombreUsuario" | "email" | "password" | "rol";

export type ValoresRegistro = {
  nombreUsuario: string;
  email: string;
  password: string;
  rol: string;
};

export type ErroresRegistro = Partial<Record<CampoRegistro, string>>;

// Los mensajes son los del backend, para que el usuario vea lo mismo venga
// el error del formulario o de la API.
export function validarNombreUsuario(valor: string): string | undefined {
  const limpio = valor.trim();
  if (!limpio) return "El nombre de usuario es obligatorio.";
  if (limpio.length < NOMBRE_USUARIO_MIN)
    return `El nombre de usuario debe tener al menos ${NOMBRE_USUARIO_MIN} caracteres.`;
  if (limpio.length > NOMBRE_USUARIO_MAX)
    return `El nombre de usuario no puede superar los ${NOMBRE_USUARIO_MAX} caracteres.`;
  if (!PATRON_NOMBRE_USUARIO.test(limpio))
    return "El nombre de usuario solo puede incluir letras, números, punto, guion y guion bajo.";
}

export function validarEmail(valor: string): string | undefined {
  const limpio = valor.trim();
  if (!limpio) return "El email es obligatorio.";
  if (limpio.length > EMAIL_MAX) return `El email no puede superar los ${EMAIL_MAX} caracteres.`;
  if (!PATRON_EMAIL.test(limpio)) return "El email no tiene un formato válido.";
}

export function validarPassword(valor: string): string | undefined {
  if (!valor) return "La contraseña es obligatoria.";
  if (valor.length < PASSWORD_MIN)
    return `La contraseña debe tener al menos ${PASSWORD_MIN} caracteres.`;
  if (valor.length > PASSWORD_MAX)
    return `La contraseña no puede superar los ${PASSWORD_MAX} caracteres.`;
  if (!PATRON_PASSWORD.test(valor))
    return "La contraseña debe incluir al menos una minúscula, una mayúscula y un número.";
}

export function validarRol(valor: string): string | undefined {
  if (!ROLES.includes(valor as Rol)) return "Elige cómo vas a usar Arre.";
}

export function validarRegistro(valores: ValoresRegistro): ErroresRegistro {
  const errores: ErroresRegistro = {
    nombreUsuario: validarNombreUsuario(valores.nombreUsuario),
    email: validarEmail(valores.email),
    password: validarPassword(valores.password),
    rol: validarRol(valores.rol),
  };
  return Object.fromEntries(
    Object.entries(errores).filter(([, mensaje]) => mensaje),
  ) as ErroresRegistro;
}

/**
 * Campo al que pertenece un mensaje 400 del backend, según cómo empieza.
 * Los mensajes de class-validator del DTO siempre nombran el campo al inicio.
 */
export function campoDeMensaje(mensaje: string): CampoRegistro | undefined {
  if (mensaje.startsWith("El nombre de usuario")) return "nombreUsuario";
  if (mensaje.startsWith("El email")) return "email";
  if (mensaje.startsWith("La contraseña")) return "password";
  if (mensaje.startsWith("El rol")) return "rol";
}
