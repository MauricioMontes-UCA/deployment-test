import type { FiltrosBusqueda } from "@/lib/busqueda";

/** Errores del panel de filtros, uno por grupo de campos. */
export type ErroresFiltros = {
  precio?: string;
  capacidad?: string;
  fechas?: string;
};

const PRECIO = /^\d+(\.\d{1,2})?$/;
const ENTERO_POSITIVO = /^[1-9]\d*$/;

/**
 * Validación previa del panel de filtros (FE-4.1), con las mismas reglas que
 * el backend: precios no negativos con hasta 2 decimales y el mínimo no mayor
 * que el máximo, capacidad entera desde 1, las dos fechas juntas, la de fin no
 * anterior a la de inicio y ninguna antes de `hoy` (AAAA-MM-DD, El Salvador).
 * Devuelve un objeto vacío si todo está bien.
 */
export function validarFiltros(filtros: FiltrosBusqueda, hoy: string): ErroresFiltros {
  const errores: ErroresFiltros = {};
  const { precioMin, precioMax, capacidadMin, fechaInicio, fechaFin } = filtros;

  if ((precioMin && !PRECIO.test(precioMin)) || (precioMax && !PRECIO.test(precioMax))) {
    errores.precio = "Escribe precios de 0 o más, con hasta 2 decimales.";
  } else if (precioMin && precioMax && Number(precioMin) > Number(precioMax)) {
    errores.precio = "El precio mínimo no puede ser mayor que el máximo.";
  }

  if (capacidadMin && !ENTERO_POSITIVO.test(capacidadMin)) {
    errores.capacidad = "La capacidad mínima debe ser un número entero de 1 o más.";
  }

  if (Boolean(fechaInicio) !== Boolean(fechaFin)) {
    errores.fechas = "Elige la fecha de inicio y la de fin.";
  } else if (fechaInicio && fechaFin) {
    if (fechaInicio < hoy) errores.fechas = "La fecha de inicio no puede ser anterior a hoy.";
    else if (fechaFin < fechaInicio) {
      errores.fechas = "La fecha de fin no puede ser anterior a la de inicio.";
    }
  }

  return errores;
}
