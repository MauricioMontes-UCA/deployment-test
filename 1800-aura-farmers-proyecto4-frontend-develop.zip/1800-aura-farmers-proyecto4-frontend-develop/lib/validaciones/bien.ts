import { CATEGORIAS_POR_TIPO, UNIDADES_COBRO, esTipoBien } from "../catalogos/bienes";
import { municipiosDe } from "../ubicaciones";

/**
 * Reglas del formulario de publicación, iguales a `CreateBienDto` del backend
 * (H1). Los mensajes también son los del backend, salvo los de las listas,
 * donde el usuario elige en vez de escribir.
 */

export const TITULO_MIN = 5;
export const TITULO_MAX = 100;
export const DESCRIPCION_MAX = 2000;
export const CONDICIONES_MAX = 1000;
export const DIRECCION_MAX = 200;
/** Mayor monto que cabe en la columna DECIMAL(12, 2) del backend. */
export const MONTO_MAXIMO = 9_999_999_999.99;
const ENTERO_MAXIMO = 2_147_483_647;

export const MIN_FOTOS = 1;
export const MAX_FOTOS = 10;
export const MAX_FOTO_MB = 5;
export const MAX_FOTO_BYTES = MAX_FOTO_MB * 1024 * 1024;
/** H1 pide JPG o PNG (el backend además acepta WEBP). */
export const TIPOS_FOTO = ["image/jpeg", "image/png"] as const;
export const ACEPTAR_FOTOS = ".jpg,.jpeg,.png,image/jpeg,image/png";

export type CampoBien =
  | "tipo"
  | "categoria"
  | "titulo"
  | "descripcion"
  | "precio"
  | "unidadCobro"
  | "deposito"
  | "capacidad"
  | "condiciones"
  | "departamento"
  | "municipio"
  | "direccionReferencia"
  | "fotos";

/** Valores del formulario tal como se escriben (todo texto). */
export type ValoresBien = Record<Exclude<CampoBien, "fotos">, string>;

export type ErroresBien = Partial<Record<CampoBien, string>>;

export const VALORES_BIEN_VACIOS: ValoresBien = {
  tipo: "",
  categoria: "",
  titulo: "",
  descripcion: "",
  precio: "",
  unidadCobro: "",
  deposito: "",
  capacidad: "",
  condiciones: "",
  departamento: "",
  municipio: "",
  direccionReferencia: "",
};

/** Acepta coma o punto decimal: «80,50» se envía como «80.50». */
export function normalizarMonto(valor: string): string {
  return valor.trim().replace(",", ".");
}

const PATRON_MONTO = /^\d+(\.\d{1,2})?$/;

function validarMonto(
  valor: string,
  nombre: { articulo: "El" | "La"; campo: string },
  { obligatorio, positivo }: { obligatorio: boolean; positivo: boolean },
): string | undefined {
  const { articulo, campo } = nombre;
  const limpio = normalizarMonto(valor);
  if (!limpio) return obligatorio ? `${articulo} ${campo} es obligatorio.` : undefined;
  if (!PATRON_MONTO.test(limpio))
    return `${articulo} ${campo} debe ser un número con hasta dos decimales.`;
  const numero = Number(limpio);
  if (positivo && numero <= 0) return `${articulo} ${campo} debe ser mayor que 0.`;
  if (numero > MONTO_MAXIMO) return `${articulo} ${campo} es demasiado alto.`;
}

export function validarBien(valores: ValoresBien, cantidadFotos: number): ErroresBien {
  const errores: ErroresBien = {};
  const tipo = valores.tipo;

  if (!esTipoBien(tipo)) errores.tipo = "Elige el tipo de bien.";
  if (!valores.categoria) errores.categoria = "Elige una categoría.";
  else if (esTipoBien(tipo) && !CATEGORIAS_POR_TIPO[tipo].includes(valores.categoria))
    errores.categoria = "La categoría no pertenece al tipo elegido.";

  const titulo = valores.titulo.trim();
  if (!titulo) errores.titulo = "El título es obligatorio.";
  else if (titulo.length < TITULO_MIN)
    errores.titulo = `El título debe tener al menos ${TITULO_MIN} caracteres.`;
  else if (titulo.length > TITULO_MAX)
    errores.titulo = `El título no puede superar los ${TITULO_MAX} caracteres.`;

  const descripcion = valores.descripcion.trim();
  if (!descripcion) errores.descripcion = "La descripción es obligatoria.";
  else if (descripcion.length > DESCRIPCION_MAX)
    errores.descripcion = `La descripción no puede superar los ${DESCRIPCION_MAX} caracteres.`;

  errores.precio = validarMonto(
    valores.precio,
    { articulo: "El", campo: "precio" },
    { obligatorio: true, positivo: true },
  );
  if (!UNIDADES_COBRO.some((unidad) => unidad.valor === valores.unidadCobro))
    errores.unidadCobro = "Elige la unidad de cobro.";
  const errorDeposito = validarMonto(
    valores.deposito,
    { articulo: "El", campo: "depósito" },
    { obligatorio: false, positivo: false },
  );
  if (errorDeposito) errores.deposito = errorDeposito;

  // La capacidad solo se pide para propiedades y es opcional.
  const capacidad = valores.capacidad.trim();
  if (tipo === "PROPIEDAD" && capacidad) {
    if (!/^\d+$/.test(capacidad)) errores.capacidad = "La capacidad debe ser un número entero.";
    else if (Number(capacidad) < 1) errores.capacidad = "La capacidad debe ser mayor que 0.";
    else if (Number(capacidad) > ENTERO_MAXIMO) errores.capacidad = "La capacidad es demasiado alta.";
  }

  if (valores.condiciones.trim().length > CONDICIONES_MAX)
    errores.condiciones = `Las condiciones no pueden superar los ${CONDICIONES_MAX} caracteres.`;

  if (!valores.departamento) errores.departamento = "Elige el departamento.";
  if (!valores.municipio) errores.municipio = "Elige el municipio.";
  else if (valores.departamento && !municipiosDe(valores.departamento).includes(valores.municipio))
    errores.municipio = "El municipio no pertenece al departamento elegido.";

  if (valores.direccionReferencia.trim().length > DIRECCION_MAX)
    errores.direccionReferencia = `La dirección de referencia no puede superar los ${DIRECCION_MAX} caracteres.`;

  if (cantidadFotos < MIN_FOTOS) errores.fotos = "Debes subir al menos una foto.";
  else if (cantidadFotos > MAX_FOTOS)
    errores.fotos = `Se pueden subir como máximo ${MAX_FOTOS} fotos.`;

  return Object.fromEntries(
    Object.entries(errores).filter(([, mensaje]) => mensaje),
  ) as ErroresBien;
}

/**
 * Valida una foto antes de agregarla. Revisa el tipo que informa el navegador
 * y, si viene vacío, la extensión. El backend vuelve a validar por contenido.
 */
export function validarFoto(archivo: File): string | undefined {
  const tipoValido =
    (TIPOS_FOTO as readonly string[]).includes(archivo.type) ||
    (!archivo.type && /\.(jpe?g|png)$/i.test(archivo.name));
  if (!tipoValido) return `«${archivo.name}» no es JPG ni PNG.`;
  if (archivo.size > MAX_FOTO_BYTES) return `«${archivo.name}» pesa más de ${MAX_FOTO_MB} MB.`;
}

/**
 * Campo al que pertenece un mensaje 400 del backend, según cómo empieza. Los
 * de las fotos («La foto 2 (x.png)…», «Debes subir…», «Cada foto…») van al
 * cargador.
 */
export function campoDeMensajeBien(mensaje: string): CampoBien | undefined {
  const prefijos: [string, CampoBien][] = [
    ["El tipo", "tipo"],
    ["La categoría", "categoria"],
    ["El título", "titulo"],
    ["La descripción", "descripcion"],
    ["El precio", "precio"],
    ["La unidad de cobro", "unidadCobro"],
    ["El depósito", "deposito"],
    ["La capacidad", "capacidad"],
    ["Las condiciones", "condiciones"],
    ["El departamento", "departamento"],
    ["El municipio", "municipio"],
    ["La dirección de referencia", "direccionReferencia"],
    ["La foto", "fotos"],
    ["Debes subir", "fotos"],
    ["Se pueden subir", "fotos"],
    ["Cada foto", "fotos"],
    ["El índice de la foto principal", "fotos"],
  ];
  return prefijos.find(([prefijo]) => mensaje.startsWith(prefijo))?.[1];
}
