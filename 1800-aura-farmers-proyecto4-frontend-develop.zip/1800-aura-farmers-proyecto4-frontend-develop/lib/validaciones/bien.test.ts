import { describe, expect, it } from "vitest";
import {
  VALORES_BIEN_VACIOS,
  campoDeMensajeBien,
  normalizarMonto,
  validarBien,
  validarFoto,
  type ValoresBien,
} from "./bien";

const validos: ValoresBien = {
  ...VALORES_BIEN_VACIOS,
  tipo: "PROPIEDAD",
  categoria: "Salón de eventos",
  titulo: "Salón de eventos Las Palmas",
  descripcion: "Salón climatizado con cocina.",
  precio: "80",
  unidadCobro: "DIA",
  departamento: "La Libertad",
  municipio: "Santa Tecla",
};

describe("validarBien", () => {
  it("acepta un bien completo con al menos una foto", () => {
    expect(validarBien(validos, 1)).toEqual({});
  });

  it("exige al menos una foto y no más de 10", () => {
    expect(validarBien(validos, 0).fotos).toBe("Debes subir al menos una foto.");
    expect(validarBien(validos, 11).fotos).toBe("Se pueden subir como máximo 10 fotos.");
  });

  it.each([
    ["0", "El precio debe ser mayor que 0."],
    ["-5", "El precio debe ser un número con hasta dos decimales."],
    ["12.345", "El precio debe ser un número con hasta dos decimales."],
    ["", "El precio es obligatorio."],
  ])("rechaza el precio %j", (precio, mensaje) => {
    expect(validarBien({ ...validos, precio }, 1).precio).toBe(mensaje);
  });

  it("acepta precio con coma decimal", () => {
    expect(validarBien({ ...validos, precio: "80,50" }, 1)).toEqual({});
    expect(normalizarMonto(" 80,50 ")).toBe("80.50");
  });

  it("limita el título a 5–100 caracteres", () => {
    expect(validarBien({ ...validos, titulo: "a".repeat(101) }, 1).titulo).toBe(
      "El título no puede superar los 100 caracteres.",
    );
    expect(validarBien({ ...validos, titulo: "Sala" }, 1).titulo).toBe(
      "El título debe tener al menos 5 caracteres.",
    );
    expect(validarBien({ ...validos, titulo: "a".repeat(100) }, 1)).toEqual({});
  });

  it("no acepta una categoría de otro tipo ni un municipio de otro departamento", () => {
    expect(validarBien({ ...validos, categoria: "Herramientas" }, 1).categoria).toBe(
      "La categoría no pertenece al tipo elegido.",
    );
    expect(validarBien({ ...validos, municipio: "Soyapango" }, 1).municipio).toBe(
      "El municipio no pertenece al departamento elegido.",
    );
  });

  it("valida la capacidad solo para propiedades", () => {
    expect(validarBien({ ...validos, capacidad: "0" }, 1).capacidad).toBe("La capacidad debe ser mayor que 0.");
    expect(validarBien({ ...validos, capacidad: "1.5" }, 1).capacidad).toBe("La capacidad debe ser un número entero.");
    expect(
      validarBien({ ...validos, tipo: "EQUIPO", categoria: "Herramientas", capacidad: "abc" }, 1),
    ).toEqual({});
  });

  it("acepta depósito vacío o cero y rechaza uno negativo", () => {
    expect(validarBien({ ...validos, deposito: "0" }, 1)).toEqual({});
    expect(validarBien({ ...validos, deposito: "-1" }, 1).deposito).toBeDefined();
  });
});

describe("validarFoto", () => {
  const archivo = (nombre: string, tipo: string, bytes = 10) => {
    const file = new File(["x"], nombre, { type: tipo });
    Object.defineProperty(file, "size", { value: bytes });
    return file;
  };

  it("acepta JPG y PNG de hasta 5 MB", () => {
    expect(validarFoto(archivo("a.jpg", "image/jpeg"))).toBeUndefined();
    expect(validarFoto(archivo("a.png", "image/png", 5 * 1024 * 1024))).toBeUndefined();
  });

  it("rechaza otros formatos y fotos de más de 5 MB", () => {
    expect(validarFoto(archivo("doc.pdf", "application/pdf"))).toBe("«doc.pdf» no es JPG ni PNG.");
    expect(validarFoto(archivo("a.webp", "image/webp"))).toBe("«a.webp» no es JPG ni PNG.");
    expect(validarFoto(archivo("grande.jpg", "image/jpeg", 5 * 1024 * 1024 + 1))).toBe(
      "«grande.jpg» pesa más de 5 MB.",
    );
  });

  it("usa la extensión cuando el navegador no informa el tipo", () => {
    expect(validarFoto(archivo("foto.JPEG", ""))).toBeUndefined();
    expect(validarFoto(archivo("foto.gif", ""))).toBeDefined();
  });
});

describe("campoDeMensajeBien", () => {
  it("lleva los mensajes del backend a su campo", () => {
    expect(campoDeMensajeBien("El título no puede superar los 100 caracteres.")).toBe("titulo");
    expect(campoDeMensajeBien("La categoría no pertenece al tipo elegido.")).toBe("categoria");
    expect(campoDeMensajeBien("La foto 2 (x.png) pesa más de 5 MB.")).toBe("fotos");
    expect(campoDeMensajeBien("Debes subir al menos una foto.")).toBe("fotos");
    expect(campoDeMensajeBien("property foo should not exist")).toBeUndefined();
  });
});
