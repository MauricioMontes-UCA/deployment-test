import { describe, expect, it } from "vitest";
import { campoDeMensaje, validarRegistro } from "./registro";

const validos = {
  nombreUsuario: "ana_m",
  email: "ana@example.com",
  password: "Str0ngPass",
  rol: "ARRENDADOR",
};

describe("validarRegistro", () => {
  it("acepta datos válidos con cualquiera de los dos roles", () => {
    expect(validarRegistro(validos)).toEqual({});
    expect(validarRegistro({ ...validos, rol: "ARRENDATARIO" })).toEqual({});
  });

  it.each([
    ["ab", "El nombre de usuario debe tener al menos 3 caracteres."],
    ["a".repeat(31), "El nombre de usuario no puede superar los 30 caracteres."],
    ["ana m", "El nombre de usuario solo puede incluir letras, números, punto, guion y guion bajo."],
    ["", "El nombre de usuario es obligatorio."],
  ])("rechaza el nombre de usuario %j", (nombreUsuario, mensaje) => {
    expect(validarRegistro({ ...validos, nombreUsuario }).nombreUsuario).toBe(mensaje);
  });

  it("acepta los límites de 3 y 30 caracteres", () => {
    expect(validarRegistro({ ...validos, nombreUsuario: "abc" })).toEqual({});
    expect(validarRegistro({ ...validos, nombreUsuario: "a".repeat(30) })).toEqual({});
  });

  it("rechaza un correo sin formato", () => {
    expect(validarRegistro({ ...validos, email: "ana@" }).email).toBe(
      "El email no tiene un formato válido.",
    );
  });

  it.each([
    ["Corta1", "La contraseña debe tener al menos 8 caracteres."],
    ["sinmayuscula1", "La contraseña debe incluir al menos una minúscula, una mayúscula y un número."],
    ["SinNumeroAqui", "La contraseña debe incluir al menos una minúscula, una mayúscula y un número."],
    ["Aa1" + "x".repeat(70), "La contraseña no puede superar los 72 caracteres."],
  ])("rechaza la contraseña %j", (password, mensaje) => {
    expect(validarRegistro({ ...validos, password }).password).toBe(mensaje);
  });

  it("exige elegir un rol y no acepta otros valores", () => {
    expect(validarRegistro({ ...validos, rol: "" }).rol).toBeDefined();
    expect(validarRegistro({ ...validos, rol: "ADMIN" }).rol).toBeDefined();
  });
});

describe("campoDeMensaje", () => {
  it("asigna cada mensaje del backend a su campo", () => {
    expect(campoDeMensaje("El nombre de usuario debe tener al menos 3 caracteres.")).toBe("nombreUsuario");
    expect(campoDeMensaje("El email no tiene un formato válido.")).toBe("email");
    expect(campoDeMensaje("La contraseña debe tener al menos 8 caracteres.")).toBe("password");
    expect(campoDeMensaje("El rol debe ser uno de: ARRENDADOR, ARRENDATARIO.")).toBe("rol");
    expect(campoDeMensaje("property foo should not exist")).toBeUndefined();
  });
});
