import { describe, expect, it } from "vitest";
import { validarFiltros } from "./filtros";

const HOY = "2026-11-19";

describe("validarFiltros", () => {
  it("sin filtros o con filtros válidos no hay errores", () => {
    expect(validarFiltros({}, HOY)).toEqual({});
    expect(
      validarFiltros(
        {
          precioMin: "20",
          precioMax: "100.50",
          capacidadMin: "80",
          fechaInicio: HOY,
          fechaFin: HOY,
        },
        HOY,
      ),
    ).toEqual({});
  });

  it("el precio mínimo no puede ser mayor que el máximo", () => {
    expect(validarFiltros({ precioMin: "120", precioMax: "100" }, HOY)).toEqual({
      precio: "El precio mínimo no puede ser mayor que el máximo.",
    });
    expect(validarFiltros({ precioMin: "100", precioMax: "100" }, HOY)).toEqual({});
  });

  it("rechaza precios negativos o con más de 2 decimales", () => {
    expect(validarFiltros({ precioMin: "-1" }, HOY).precio).toBeDefined();
    expect(validarFiltros({ precioMax: "10.999" }, HOY).precio).toBeDefined();
  });

  it("la fecha de fin no puede ser anterior a la de inicio", () => {
    expect(validarFiltros({ fechaInicio: "2026-11-20", fechaFin: "2026-11-18" }, HOY)).toEqual({
      fechas: "La fecha de fin no puede ser anterior a la de inicio.",
    });
  });

  it("no permite fechas pasadas y pide las dos fechas", () => {
    expect(validarFiltros({ fechaInicio: "2026-11-18", fechaFin: "2026-11-20" }, HOY).fechas).toBe(
      "La fecha de inicio no puede ser anterior a hoy.",
    );
    expect(validarFiltros({ fechaInicio: "2026-11-20" }, HOY).fechas).toBe(
      "Elige la fecha de inicio y la de fin.",
    );
  });

  it("la capacidad mínima es un entero de 1 o más", () => {
    expect(validarFiltros({ capacidadMin: "0" }, HOY).capacidad).toBeDefined();
    expect(validarFiltros({ capacidadMin: "2.5" }, HOY).capacidad).toBeDefined();
  });
});
