import { describe, expect, it } from "vitest";
import {
  ID_RESERVA,
  leerDeposito,
  estadoDeposito,
  esPendiente,
} from "./deposito-consulta";

const deposito = {
  estado: "PARCIALMENTE_RETENIDO",
  importeOriginal: 40,
  importeRetenido: 15,
  importeLiberado: 25,
  justificacion: "Daños",
  fechaResolucion: "2026-11-01T12:00:00Z",
  resolucionAutomatica: false,
};

describe("FE-12.1: consulta de depósito", () => {
  it("valida UUID", () => {
    expect(ID_RESERVA.test("11111111-1111-4111-8111-111111111111")).toBe(true);
    expect(ID_RESERVA.test("invalido")).toBe(false);
  });

  it("lee los importes y la resolución del DTO", () => {
    expect(leerDeposito(deposito)).toMatchObject({
      importeOriginal: 40,
      importeRetenido: 15,
      importeLiberado: 25,
      justificacion: "Daños",
      resolucionAutomatica: false,
    });
  });

  it("omite justificación y fecha ausentes", () => {
    const resultado = leerDeposito({
      ...deposito,
      estado: "PENDIENTE",
      justificacion: null,
      fechaResolucion: null,
    });

    expect(resultado).not.toHaveProperty("justificacion");
    expect(resultado).not.toHaveProperty("fechaResolucion");
  });

  it("detecta liberación automática informada por el backend", () => {
    const resultado = leerDeposito({
      ...deposito,
      estado: "LIBERADO",
      importeRetenido: 0,
      importeLiberado: 40,
      justificacion: null,
      resolucionAutomatica: true,
    });

    expect(resultado?.resolucionAutomatica).toBe(true);
  });

  it("no deduce liberación automática cuando el backend indica false", () => {
    const resultado = leerDeposito({
      ...deposito,
      estado: "LIBERADO",
      importeRetenido: 0,
      importeLiberado: 40,
      resolucionAutomatica: false,
    });

    expect(resultado?.resolucionAutomatica).toBe(false);
  });

  it("no inventa importes faltantes ni acepta envoltorios especulativos", () => {
    expect(
      leerDeposito({
        estado: "PENDIENTE",
        importeOriginal: 40,
      }),
    ).toBeNull();

    expect(leerDeposito({ data: deposito })).toBeNull();
  });

  it("presenta estados", () => {
    expect(estadoDeposito("PARCIALMENTE_RETENIDO")).toBe(
      "Parcialmente retenido",
    );

    expect(esPendiente("PENDIENTE")).toBe(true);
  });
});