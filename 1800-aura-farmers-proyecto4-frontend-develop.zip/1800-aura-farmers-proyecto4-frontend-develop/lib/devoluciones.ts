export const ESTADOS_FINALES = ["BUEN_ESTADO", "DANADO", "INCOMPLETO"] as const;
export type EstadoFinalBien = (typeof ESTADOS_FINALES)[number];
export type RegistroDevolucion = {
  fechaDevolucion: string;
  estadoFinalBien: EstadoFinalBien;
  observaciones?: string;
};
export type ResumenDevolucion = {
  reservaId: string;
  titulo: string;
  foto: string | null;
  arrendatario: string;
  fechaInicio: string;
  fechaFin: string;
  estado: string;
  deposito: number | null;
};
export const ID_RESERVA =
  /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
export const contarObservaciones = (texto: string) => texto.trim().length;
export function validarDevolucion(
  fecha: string,
  estado: string,
  observaciones: string,
  ahora = new Date(),
) {
  const errores: { fecha?: string; estado?: string; observaciones?: string } =
    {};
  const instante = new Date(fecha);
  if (!fecha || !Number.isFinite(instante.getTime()))
    errores.fecha = "La fecha de devolución es obligatoria.";
  else if (instante.getTime() > ahora.getTime())
    errores.fecha = "La fecha de devolución no puede ser futura.";
  if (!ESTADOS_FINALES.includes(estado as EstadoFinalBien))
    errores.estado = "Elige el estado en que recibiste el bien.";
  if (contarObservaciones(observaciones) > 500)
    errores.observaciones =
      "Las observaciones no pueden superar los 500 caracteres.";
  return errores;
}
export function fechaLocalActual(ahora = new Date()) {
  const local = new Date(ahora.getTime() - ahora.getTimezoneOffset() * 60000);
  return local.toISOString().slice(0, 16);
}
export function fechaIso(fechaLocal: string) {
  return new Date(fechaLocal).toISOString();
}
export function leerResumen(
  valor: unknown,
  reservaId: string,
): ResumenDevolucion | null {
  if (!valor || typeof valor !== "object") return null;
  const r = valor as Record<string, unknown>;
  const bien =
    r.bien && typeof r.bien === "object"
      ? (r.bien as Record<string, unknown>)
      : {};
  const arrendatario =
    r.arrendatario && typeof r.arrendatario === "object"
      ? (r.arrendatario as Record<string, unknown>)
      : {};
  if (
    typeof r.estado !== "string" ||
    typeof r.fechaInicio !== "string" ||
    typeof r.fechaFin !== "string" ||
    typeof bien.titulo !== "string"
  )
    return null;
  const dep =
    r.deposito && typeof r.deposito === "object"
      ? (r.deposito as Record<string, unknown>)
      : {};
  const importe = dep.importeOriginal ?? dep.monto ?? dep.importe ?? dep.total;
  return {
    reservaId,
    titulo: bien.titulo,
    foto:
      typeof bien.fotoPrincipalUrl === "string" ? bien.fotoPrincipalUrl : null,
    arrendatario:
      typeof arrendatario.nombreUsuario === "string"
        ? arrendatario.nombreUsuario
        : "Arrendatario",
    fechaInicio: r.fechaInicio,
    fechaFin: r.fechaFin,
    estado: r.estado,
    deposito: typeof importe === "number" ? importe : null,
  };
}
