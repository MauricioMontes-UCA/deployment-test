// lib/deposito-consulta.ts

import { dinero, ID_RESERVA, numero, objeto } from "@/lib/depositos";

export { ID_RESERVA, dinero };

/** Campos de DepositoConsultaResponseDto (BE-11.1). */
export type Deposito = {
  estado: string;
  importeOriginal: number;
  importeRetenido: number;
  importeLiberado: number;
  justificacion?: string;
  fechaResolucion?: string;
  resolucionAutomatica: boolean;
};

export function leerDeposito(datos: unknown): Deposito | null {
  const d = objeto(datos);

  const original = numero(d.importeOriginal);
  const retenido = numero(d.importeRetenido);
  const liberado = numero(d.importeLiberado);

  if (
    typeof d.estado !== "string" ||
    original === null ||
    original < 0 ||
    retenido === null ||
    retenido < 0 ||
    liberado === null ||
    liberado < 0
  ) {
    return null;
  }

  return {
    estado: d.estado,
    importeOriginal: original,
    importeRetenido: retenido,
    importeLiberado: liberado,
    ...(typeof d.justificacion === "string" && d.justificacion.trim()
      ? { justificacion: d.justificacion }
      : {}),
    ...(typeof d.fechaResolucion === "string" && d.fechaResolucion
      ? { fechaResolucion: d.fechaResolucion }
      : {}),
    resolucionAutomatica: d.resolucionAutomatica === true,
  };
}

export function fecha(dato: string): string {
  const valor = new Date(dato);

  return Number.isNaN(valor.getTime())
    ? dato
    : new Intl.DateTimeFormat("es-SV", {
        day: "2-digit",
        month: "2-digit",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        hour12: false,
        timeZone: "America/El_Salvador",
      }).format(valor);
}

export function estadoDeposito(estado: string): string {
  if (estado === "PARCIALMENTE_RETENIDO") return "Parcialmente retenido";
  if (estado === "RETENIDO") return "Retenido";
  if (estado === "LIBERADO") return "Liberado";
  if (estado === "PENDIENTE") return "Pendiente";

  return estado.replaceAll("_", " ").toLowerCase();
}

export function esPendiente(estado: string): boolean {
  return estado === "PENDIENTE";
}