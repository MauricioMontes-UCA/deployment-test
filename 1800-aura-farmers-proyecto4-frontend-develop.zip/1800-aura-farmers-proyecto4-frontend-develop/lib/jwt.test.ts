import { describe, expect, it } from "vitest";
import { tokenDePrueba } from "@/pruebas/tokens";
import { accesoVigente, leerPayload } from "./jwt";


describe("leerPayload", () => {
  it("lee sub, email, rol y exp, incluso con caracteres fuera de ASCII", () => {
    const token = tokenDePrueba({ sub: "1", email: "ñandú@example.com", rol: "ARRENDADOR", iat: 1, exp: 2 });
    expect(leerPayload(token)).toMatchObject({ email: "ñandú@example.com", rol: "ARRENDADOR", exp: 2 });
  });

  it("devuelve null con tokens mal formados", () => {
    expect(leerPayload(undefined)).toBeNull();
    expect(leerPayload("no-es-un-jwt")).toBeNull();
    expect(leerPayload("a.%%%.c")).toBeNull();
  });
});

describe("accesoVigente", () => {
  const ahora = 1_800_000_000_000;
  const conExp = (segundos: number) => tokenDePrueba({ exp: Math.floor(ahora / 1000) + segundos });

  it("es vigente si faltan más de 30 segundos", () => {
    expect(accesoVigente(conExp(600), ahora)).toBe(true);
  });

  it("no es vigente si venció o vence en menos de 30 segundos", () => {
    expect(accesoVigente(conExp(-1), ahora)).toBe(false);
    expect(accesoVigente(conExp(20), ahora)).toBe(false);
    expect(accesoVigente(undefined, ahora)).toBe(false);
  });
});
