import { diasDelRango, esFechaValida, type RangoFechas } from "@/lib/disponibilidad";

/** Bloqueo de `GET /bienes/:bienId/bloqueos` (BE-7.3). */
export type Bloqueo = RangoFechas & {
  id: string;
  creadoEn?: string;
};

/** Identificador (UUID) de un bien o de un bloqueo. */
export const ID_UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export const ERROR_RESERVA = "Hay una reserva confirmada en ese rango.";
export const ERROR_BLOQUEO_SOLAPADO = "El rango se solapa con otro bloqueo de este bien.";
export const ERROR_SIN_PERMISO = "No puedes modificar este bien.";
export const ERROR_BLOQUEO_INEXISTENTE = "Ese bloqueo ya no existe.";
export const ERROR_GENERAL = "No pudimos completar la acción. Intenta de nuevo.";

/** Valida la forma de la lista de bloqueos antes de usarla. */
export function esListaDeBloqueos(valor: unknown): valor is Bloqueo[] {
  return (
    Array.isArray(valor) &&
    valor.every(
      (item) =>
        typeof item === "object" &&
        item !== null &&
        typeof (item as Bloqueo).id === "string" &&
        esFechaValida((item as Bloqueo).fechaInicio) &&
        esFechaValida((item as Bloqueo).fechaFin),
    )
  );
}

/** AAAA-MM-DD → DD/MM/AAAA, el formato de las pantallas. */
export function formatearFecha(fecha: string): string {
  const [anio, mes, dia] = fecha.split("-");
  return `${dia}/${mes}/${anio}`;
}

export function textoDelRango({ fechaInicio, fechaFin }: RangoFechas): string {
  return `${formatearFecha(fechaInicio)} → ${formatearFecha(fechaFin)}`;
}

export function textoDeDias({ fechaInicio, fechaFin }: RangoFechas): string {
  const dias = diasDelRango(fechaInicio, fechaFin).length;
  return dias === 1 ? "1 día" : `${dias} días`;
}

/** Los bloqueos en orden de fecha, sin modificar la lista original. */
export function ordenarPorInicio<T extends RangoFechas>(rangos: T[]): T[] {
  return [...rangos].sort((a, b) => a.fechaInicio.localeCompare(b.fechaInicio));
}

/**
 * Mensaje para el usuario según la respuesta de la API (acepta el `message` de
 * Nest, texto o lista). Un 409 con `reservaId` es una reserva; con `bloqueoId`,
 * otro bloqueo. El 422 muestra el mensaje del servicio.
 */
export function mensajeDeError(estado: number, cuerpo: unknown): string {
  const datos = (typeof cuerpo === "object" && cuerpo !== null ? cuerpo : {}) as Record<string, unknown>;
  if (estado === 403) return ERROR_SIN_PERMISO;
  if (estado === 404) return ERROR_BLOQUEO_INEXISTENTE;
  if (estado === 409) return "bloqueoId" in datos ? ERROR_BLOQUEO_SOLAPADO : ERROR_RESERVA;
  if (estado === 422 || estado === 400) {
    const mensaje = Array.isArray(datos.message) ? datos.message.join(" ") : datos.message;
    if (typeof mensaje === "string" && mensaje) return mensaje;
  }
  return ERROR_GENERAL;
}
