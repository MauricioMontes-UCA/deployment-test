import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { tokenDePrueba } from "@/pruebas/tokens";
import { obtenerAccesoVigente, reiniciarRenovaciones, renovarSesionCompartida } from "./sesion-vigente";

const fetchFalso = vi.fn();
const parNuevo = { accessToken: "a2", refreshToken: "r2", expiresIn: 900, user: {} };

function responderRenovacion(status = 200, cuerpo: unknown = parNuevo) {
  fetchFalso.mockResolvedValueOnce(new Response(JSON.stringify(cuerpo), { status }));
}

const cookies = (valores: Record<string, string>) => ({
  get: (nombre: string) => (nombre in valores ? { value: valores[nombre] } : undefined),
});

beforeEach(() => {
  reiniciarRenovaciones();
  vi.stubEnv("API_URL", "http://api.test/api/v1");
  vi.stubGlobal("fetch", fetchFalso);
});

afterEach(() => {
  vi.useRealTimers();
  vi.unstubAllEnvs();
  vi.unstubAllGlobals();
  fetchFalso.mockReset();
});

describe("renovarSesionCompartida", () => {
  it("dos renovaciones simultáneas con el mismo refresh hacen una sola llamada", async () => {
    responderRenovacion();
    const [una, otra] = await Promise.all([renovarSesionCompartida("r1"), renovarSesionCompartida("r1")]);
    expect(fetchFalso).toHaveBeenCalledOnce();
    expect(una).toMatchObject({ ok: true, datos: { refreshToken: "r2" } });
    expect(otra).toMatchObject({ ok: true, datos: { refreshToken: "r2" } });
  });

  it("quien llega poco después con el refresh viejo recibe el mismo par, con la vigencia restante", async () => {
    vi.useFakeTimers({ now: new Date("2026-11-19T12:00:00Z") });
    responderRenovacion();
    await renovarSesionCompartida("r1");

    vi.setSystemTime(new Date("2026-11-19T12:00:10Z"));
    const tarde = await renovarSesionCompartida("r1");
    expect(fetchFalso).toHaveBeenCalledOnce();
    expect(tarde).toMatchObject({ ok: true, datos: { refreshToken: "r2", expiresIn: 890 } });
  });

  it("pasados 30 s vuelve a preguntar al backend", async () => {
    vi.useFakeTimers({ now: new Date("2026-11-19T12:00:00Z") });
    responderRenovacion();
    await renovarSesionCompartida("r1");
    vi.setSystemTime(new Date("2026-11-19T12:00:31Z"));
    responderRenovacion(401, { message: "Refresh token ya utilizado.", statusCode: 401 });
    expect(await renovarSesionCompartida("r1")).toMatchObject({ ok: false, status: 401 });
    expect(fetchFalso).toHaveBeenCalledTimes(2);
  });

  it("no recuerda un fallo: el siguiente intento vuelve a preguntar", async () => {
    fetchFalso.mockRejectedValueOnce(new TypeError("fetch failed"));
    expect(await renovarSesionCompartida("r1")).toMatchObject({ ok: false, status: 0 });
    responderRenovacion();
    expect(await renovarSesionCompartida("r1")).toMatchObject({ ok: true });
    expect(fetchFalso).toHaveBeenCalledTimes(2);
  });

  it("refresh tokens distintos no comparten resultado", async () => {
    responderRenovacion();
    responderRenovacion(200, { ...parNuevo, refreshToken: "otro" });
    await renovarSesionCompartida("r1");
    expect(await renovarSesionCompartida("r9")).toMatchObject({ datos: { refreshToken: "otro" } });
    expect(fetchFalso).toHaveBeenCalledTimes(2);
  });
});

describe("obtenerAccesoVigente", () => {
  const vigente = () => tokenDePrueba({ exp: Math.floor(Date.now() / 1000) + 600 });
  const vencido = () => tokenDePrueba({ exp: Math.floor(Date.now() / 1000) - 60 });

  it("usa el access token de la cookie si sigue vigente", async () => {
    const acceso = vigente();
    expect(await obtenerAccesoVigente(cookies({ access_token: acceso, refresh_token: "r1" }))).toEqual({
      acceso,
      sesionNueva: null,
      refreshRechazado: false,
    });
    expect(fetchFalso).not.toHaveBeenCalled();
  });

  it("renueva el vencido y avisa si el backend rechaza el refresh", async () => {
    responderRenovacion();
    expect(await obtenerAccesoVigente(cookies({ access_token: vencido(), refresh_token: "r1" }))).toMatchObject({
      acceso: "a2",
      sesionNueva: { refreshToken: "r2" },
    });
    responderRenovacion(401, { message: "Refresh token expirado.", statusCode: 401 });
    expect(await obtenerAccesoVigente(cookies({ refresh_token: "r7" }))).toEqual({
      acceso: undefined,
      sesionNueva: null,
      refreshRechazado: true,
    });
  });
});
