import { leerListado, leerMarcada, type ListadoNotificaciones, type NotificacionMarcada } from "./reglas";

// Llamadas desde el navegador a los puentes `/api/notificaciones/*`. El token
// vive en una cookie httpOnly: estos puentes son los que lo agregan.

export type ResultadoListado =
  | { tipo: "ok"; listado: ListadoNotificaciones }
  /** 401: la sesión ya no sirve. */
  | { tipo: "sesion" }
  /** Red, tiempo agotado, 5xx o una respuesta que no se pudo leer. */
  | { tipo: "error" };

export type ResultadoMarcar =
  | { tipo: "ok"; marcada: NotificacionMarcada }
  | { tipo: "sesion" }
  /** 404: no existe o es de otro usuario. */
  | { tipo: "no-encontrada" }
  | { tipo: "error" };

/** `GET /api/notificaciones?pagina=N` (BE-21.1). */
export async function consultarPagina(pagina: number): Promise<ResultadoListado> {
  try {
    const respuesta = await fetch(`/api/notificaciones?pagina=${pagina}`, { cache: "no-store" });
    if (respuesta.status === 401) return { tipo: "sesion" };
    if (!respuesta.ok) return { tipo: "error" };
    const listado = leerListado(await respuesta.json());
    return listado ? { tipo: "ok", listado } : { tipo: "error" };
  } catch {
    return { tipo: "error" };
  }
}

/** `PATCH /api/notificaciones/:id/leida` (BE-21.2). */
export async function marcarLeida(id: string): Promise<ResultadoMarcar> {
  try {
    const respuesta = await fetch(`/api/notificaciones/${encodeURIComponent(id)}/leida`, {
      method: "PATCH",
      cache: "no-store",
    });
    if (respuesta.status === 401) return { tipo: "sesion" };
    if (respuesta.status === 404) return { tipo: "no-encontrada" };
    if (!respuesta.ok) return { tipo: "error" };
    const marcada = leerMarcada(await respuesta.json());
    return marcada ? { tipo: "ok", marcada } : { tipo: "error" };
  } catch {
    return { tipo: "error" };
  }
}
