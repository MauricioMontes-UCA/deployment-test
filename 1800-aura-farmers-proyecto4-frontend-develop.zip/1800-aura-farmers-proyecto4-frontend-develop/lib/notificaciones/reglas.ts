/**
 * Reglas del centro de notificaciones (H21, FE-21.1) y lectura de los
 * contratos reales del backend:
 *
 * - BE-21.1 `GET /notificaciones?pagina=N`: 20 por página, de la más reciente a
 *   la más antigua, con `noLeidas` global del usuario (no solo de la página).
 * - BE-21.2 `PATCH /notificaciones/:id/leida`: idempotente; devuelve el nuevo
 *   `noLeidas`. 404 si no existe o es de otro usuario.
 *
 * Sin dependencias de servidor ni de navegador: lo usan los puentes, el
 * contador global y la pantalla.
 */

/** Tamaño fijo de página del backend. */
export const TAMANO_PAGINA = 20;

/** Cada cuánto se consulta el contador mientras la pestaña está visible. */
export const INTERVALO_CONSULTA_MS = 30_000;

export const MENSAJES_NOTIFICACIONES = {
  vacioTitulo: "No tienes notificaciones.",
  vacioMensaje: "Aquí verás los avisos de reservas, pagos, depósitos, mensajes y verificación.",
  errorCarga: "No pudimos cargar tus notificaciones. Intenta de nuevo.",
  errorCargaDetalle: "Revisa tu conexión.",
  noEncontrada: "No encontramos esa notificación.",
  errorMarcar: "No pudimos marcar la notificación como leída. Intenta de nuevo.",
} as const;

export type EstadoNotificacion = "NO_LEIDA" | "LEIDA";
export type ModuloOrigen = "RESERVAS" | "PAGOS" | "MENSAJERIA" | "RESENAS" | "VERIFICACION";

/** Etiqueta visible del módulo de origen (Figma: «Reservas», «Pagos», «Mensajería», «Verificación»). */
export const ETIQUETA_MODULO: Record<ModuloOrigen, string> = {
  RESERVAS: "Reservas",
  PAGOS: "Pagos",
  MENSAJERIA: "Mensajería",
  RESENAS: "Reseñas",
  VERIFICACION: "Verificación",
};

export type NotificacionApi = {
  id: string;
  titulo: string;
  mensaje: string;
  estado: EstadoNotificacion;
  moduloOrigen: ModuloOrigen;
  /** ISO 8601. */
  creadaEn: string;
};

export type ListadoNotificaciones = {
  noLeidas: number;
  total: number;
  pagina: number;
  tamanoPagina: number;
  notificaciones: NotificacionApi[];
};

export type NotificacionMarcada = {
  id: string;
  estado: EstadoNotificacion;
  leidaEn: string;
  noLeidas: number;
};

export const ID_NOTIFICACION = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/** `pagina` como la acepta el backend: entero positivo sin signos ni ceros a la izquierda. */
export const PAGINA_VALIDA = /^[1-9]\d{0,9}$/;

const esObjeto = (valor: unknown): valor is Record<string, unknown> =>
  typeof valor === "object" && valor !== null;
const esConteo = (valor: unknown): valor is number =>
  typeof valor === "number" && Number.isInteger(valor) && valor >= 0;
const ESTADOS: readonly string[] = ["NO_LEIDA", "LEIDA"];
const esFechaIso = (valor: unknown): valor is string =>
  typeof valor === "string" && !Number.isNaN(Date.parse(valor));

/** Un aviso del backend, o `null` si le falta algo o trae un tipo distinto. */
export function leerNotificacion(valor: unknown): NotificacionApi | null {
  if (!esObjeto(valor)) return null;
  const { id, titulo, mensaje, estado, moduloOrigen, creadaEn } = valor;
  if (
    typeof id !== "string" ||
    typeof titulo !== "string" ||
    typeof mensaje !== "string" ||
    typeof estado !== "string" ||
    !ESTADOS.includes(estado) ||
    typeof moduloOrigen !== "string" ||
    !(moduloOrigen in ETIQUETA_MODULO) ||
    !esFechaIso(creadaEn)
  ) {
    return null;
  }
  return {
    id,
    titulo,
    mensaje,
    estado: estado as EstadoNotificacion,
    moduloOrigen: moduloOrigen as ModuloOrigen,
    creadaEn,
  };
}

/**
 * Respuesta de BE-21.1. Si un solo aviso no se puede leer devuelve `null`:
 * mostrar una página incompleta escondería avisos sin decirlo.
 */
export function leerListado(datos: unknown): ListadoNotificaciones | null {
  if (!esObjeto(datos) || !Array.isArray(datos.notificaciones)) return null;
  const { noLeidas, total, pagina, tamanoPagina } = datos;
  if (!esConteo(noLeidas) || !esConteo(total) || !esConteo(pagina) || pagina < 1 || !esConteo(tamanoPagina)) {
    return null;
  }
  const notificaciones: NotificacionApi[] = [];
  for (const valor of datos.notificaciones) {
    const notificacion = leerNotificacion(valor);
    if (!notificacion) return null;
    notificaciones.push(notificacion);
  }
  return { noLeidas, total, pagina, tamanoPagina, notificaciones };
}

/** Respuesta de BE-21.2, o `null` si no tiene la forma esperada. */
export function leerMarcada(datos: unknown): NotificacionMarcada | null {
  if (!esObjeto(datos)) return null;
  const { id, estado, leidaEn, noLeidas } = datos;
  if (typeof id !== "string" || estado !== "LEIDA" || !esFechaIso(leidaEn) || !esConteo(noLeidas)) {
    return null;
  }
  return { id, estado, leidaEn, noLeidas };
}

/** ¿Quedan avisos por pedir después de la página `pagina`? */
export function hayMasPaginas(pagina: number, total: number, tamanoPagina = TAMANO_PAGINA): boolean {
  return pagina * tamanoPagina < total;
}

/**
 * Agrega una página a la lista sin repetir avisos: la paginación es por
 * desplazamiento y un aviso nuevo entre dos consultas corre una posición la
 * página siguiente.
 */
export function unirPaginas(actuales: NotificacionApi[], nuevas: NotificacionApi[]): NotificacionApi[] {
  const vistos = new Set(actuales.map((notificacion) => notificacion.id));
  return [...actuales, ...nuevas.filter((notificacion) => !vistos.has(notificacion.id))];
}

const PARTES_FECHA = new Intl.DateTimeFormat("en-GB", {
  timeZone: "America/El_Salvador",
  day: "2-digit",
  month: "2-digit",
  year: "numeric",
  hour: "2-digit",
  minute: "2-digit",
  hourCycle: "h23",
});

/** ISO → «dd/mm/aaaa hh:mm» en hora de El Salvador, con reloj de 24 h (00:05, nunca 24:05). */
export function formatearFechaHora(iso: string): string {
  const partes = Object.fromEntries(
    PARTES_FECHA.formatToParts(new Date(iso)).map(({ type, value }) => [type, value]),
  );
  return `${partes.day}/${partes.month}/${partes.year} ${partes.hour}:${partes.minute}`;
}
