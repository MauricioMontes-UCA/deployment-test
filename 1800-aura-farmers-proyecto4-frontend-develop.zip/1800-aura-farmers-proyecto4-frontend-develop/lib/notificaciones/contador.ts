"use client";

import { useEffect, useSyncExternalStore } from "react";
import { consultarPagina, type ResultadoListado } from "./cliente";
import { INTERVALO_CONSULTA_MS } from "./reglas";

/**
 * Contador global de notificaciones no leídas (H21, FE-21.1).
 *
 * Vive en la memoria del módulo, fuera de React, y se lee con
 * `useSyncExternalStore`: la campana de la barra superior (en todas las
 * pantallas) y el centro de notificaciones ven siempre el mismo número, y el
 * valor se conserva al navegar entre pantallas.
 *
 * - **Una consulta a la vez:** si ya hay una en curso para el mismo usuario se
 *   reutiliza (salvo que el contador haya cambiado después de lanzarla).
 * - **Un solo temporizador por pestaña:** arranca con el primer componente que
 *   usa el contador y se detiene con el último. Consulta cada 30 s.
 * - **Pestaña oculta:** se pausa; al volver a verse consulta de inmediato.
 * - **Respuestas viejas:** cada escritura sube una versión; una consulta que
 *   empezó antes de otra escritura (por ejemplo, de marcar como leída) se
 *   descarta al llegar.
 * - **Por usuario:** el valor pertenece a un usuario (`clave`). Si cambia (otra
 *   cuenta tras cerrar sesión), se vacía y se descarta lo pendiente. Un 401
 *   detiene las consultas y oculta la insignia.
 */

type Estado = {
  /** Usuario al que pertenece el valor (su nombre de usuario, único). */
  clave: string | null;
  /** No leídas, o `null` mientras no se conoce. */
  noLeidas: number | null;
};

let estado: Estado = { clave: null, noLeidas: null };
const oyentes = new Set<() => void>();
let suscritos = 0;
let temporizador: ReturnType<typeof setTimeout> | null = null;
let enCurso: { clave: string; version: number; promesa: Promise<ResultadoListado> } | null = null;
/** Sube con cada valor aplicado o reinicio: invalida las consultas anteriores. */
let version = 0;
let ultimaConsulta = 0;
let sesionCaida = false;

function cambiar(siguiente: Estado) {
  if (siguiente.clave === estado.clave && siguiente.noLeidas === estado.noLeidas) return;
  estado = siguiente;
  for (const oyente of oyentes) oyente();
}

const pestanaVisible = () => typeof document === "undefined" || document.visibilityState !== "hidden";

function detenerTemporizador() {
  if (temporizador !== null) clearTimeout(temporizador);
  temporizador = null;
}

/** Programa la siguiente consulta. Siempre hay como máximo un temporizador. */
function programar(espera = INTERVALO_CONSULTA_MS) {
  detenerTemporizador();
  if (suscritos === 0 || sesionCaida || !estado.clave || !pestanaVisible()) return;
  temporizador = setTimeout(() => {
    temporizador = null;
    void consultar(estado.clave);
  }, espera);
}

/** Cambia de usuario: vacía el valor y descarta consultas pendientes. */
function usarClave(clave: string) {
  if (estado.clave === clave) return;
  version += 1;
  enCurso = null;
  sesionCaida = false;
  ultimaConsulta = 0;
  detenerTemporizador();
  cambiar({ clave, noLeidas: null });
}

/**
 * Consulta la página 1 (que trae el contador global) y aplica el resultado.
 * Comparte la consulta en curso y devuelve su resultado, para que el centro de
 * notificaciones use la misma respuesta en lugar de pedir otra.
 */
function consultar(clave: string | null): Promise<ResultadoListado> {
  if (!clave || clave !== estado.clave) return Promise.resolve({ tipo: "error" });
  if (sesionCaida) return Promise.resolve({ tipo: "sesion" });
  if (enCurso && enCurso.clave === clave && enCurso.version === version) return enCurso.promesa;

  const versionInicial = version;
  const promesa = consultarPagina(1).then((resultado) => {
    if (enCurso?.promesa === promesa) enCurso = null;
    // Otro usuario o un valor más nuevo (marcar como leída, otra consulta):
    // esta respuesta ya no sirve para el contador.
    const vigente = estado.clave === clave && version === versionInicial;
    if (vigente) {
      ultimaConsulta = Date.now();
      if (resultado.tipo === "ok") {
        version += 1;
        cambiar({ clave, noLeidas: resultado.listado.noLeidas });
      } else if (resultado.tipo === "sesion") {
        version += 1;
        sesionCaida = true;
        detenerTemporizador();
        cambiar({ clave, noLeidas: null });
        return resultado;
      }
      // Un error deja el último valor conocido y se reintenta en el próximo ciclo.
      programar();
    }
    return resultado;
  });
  enCurso = { clave, version: versionInicial, promesa };
  return promesa;
}

function alCambiarVisibilidad() {
  if (!pestanaVisible()) {
    detenerTemporizador();
    return;
  }
  // Al volver a la pestaña se consulta de inmediato y se reanuda el ciclo.
  void consultar(estado.clave);
}

/** Empieza a usar el contador del usuario `clave`. Devuelve la función para dejar de usarlo. */
function activar(clave: string): () => void {
  usarClave(clave);
  // Sin ningún componente montado (por ejemplo, al pasar por /login) una sesión
  // caída deja de bloquear: el usuario pudo volver a iniciar sesión.
  if (suscritos === 0) sesionCaida = false;
  suscritos += 1;
  if (suscritos === 1 && typeof document !== "undefined") {
    document.addEventListener("visibilitychange", alCambiarVisibilidad);
  }
  if (!sesionCaida && pestanaVisible() && temporizador === null && !enCurso) {
    const transcurrido = Date.now() - ultimaConsulta;
    // La primera consulta va en el mismo temporizador, sin espera, para que
    // salga cuando la pantalla terminó de montarse y no compita con sus propias
    // peticiones. Al navegar entre pantallas no se repite si la última
    // respuesta es reciente: se respeta lo que falta del ciclo de 30 s.
    programar(estado.noLeidas === null ? 0 : Math.max(0, INTERVALO_CONSULTA_MS - transcurrido));
  }
  let activo = true;
  return () => {
    if (!activo) return;
    activo = false;
    suscritos -= 1;
    if (suscritos === 0) {
      detenerTemporizador();
      if (typeof document !== "undefined") document.removeEventListener("visibilitychange", alCambiarVisibilidad);
    }
  };
}

function suscribir(oyente: () => void) {
  oyentes.add(oyente);
  return () => {
    oyentes.delete(oyente);
  };
}

/**
 * No leídas del usuario `clave` (su nombre de usuario), o `null` mientras no se
 * conocen, para visitantes (`clave` nula) o con la sesión vencida. Mientras el
 * componente está montado, el contador se consulta cada 30 s.
 */
export function useNoLeidas(clave: string | null): number | null {
  useEffect(() => (clave ? activar(clave) : undefined), [clave]);
  return useSyncExternalStore(
    suscribir,
    () => (clave !== null && estado.clave === clave ? estado.noLeidas : null),
    () => null,
  );
}

/** Vuelve a consultar ahora («Actualizar» y carga del centro). Reinicia el ciclo de 30 s. */
export function refrescarNoLeidas(clave: string): Promise<ResultadoListado> {
  usarClave(clave);
  detenerTemporizador();
  return consultar(clave);
}

/** Aplica el contador que devolvió el backend al marcar un aviso como leído (BE-21.2). */
export function establecerNoLeidas(clave: string, noLeidas: number) {
  if (estado.clave !== clave) return;
  version += 1;
  ultimaConsulta = Date.now();
  cambiar({ clave, noLeidas });
  programar();
}

/** Solo para pruebas: vuelve al estado inicial. */
export function reiniciarContador() {
  detenerTemporizador();
  if (typeof document !== "undefined") document.removeEventListener("visibilitychange", alCambiarVisibilidad);
  estado = { clave: null, noLeidas: null };
  oyentes.clear();
  suscritos = 0;
  enCurso = null;
  version = 0;
  ultimaConsulta = 0;
  sesionCaida = false;
}
