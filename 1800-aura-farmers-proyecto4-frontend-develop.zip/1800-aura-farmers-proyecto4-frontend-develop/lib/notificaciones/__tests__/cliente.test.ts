import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { consultarPagina, marcarLeida } from "../cliente";

const fetchSimulado = vi.fn();
const respuesta = (status: number, cuerpo: unknown = {}) =>
  new Response(JSON.stringify(cuerpo), { status, headers: { "Content-Type": "application/json" } });

const listado = {
  noLeidas: 1,
  total: 1,
  pagina: 2,
  tamanoPagina: 20,
  notificaciones: [
    {
      id: "a1b2c3d4-0000-4000-8000-000000000001",
      titulo: "Pago recibido",
      mensaje: "Se aprobó el pago.",
      estado: "NO_LEIDA",
      moduloOrigen: "PAGOS",
      creadaEn: "2026-11-18T20:28:00.000Z",
    },
  ],
};
const ID = "a1b2c3d4-0000-4000-8000-000000000001";

beforeEach(() => vi.stubGlobal("fetch", fetchSimulado));
afterEach(() => {
  vi.unstubAllGlobals();
  fetchSimulado.mockReset();
});

describe("consultarPagina", () => {
  it("pide la página al puente, sin caché, y lee el listado", async () => {
    fetchSimulado.mockResolvedValue(respuesta(200, listado));
    expect(await consultarPagina(2)).toEqual({ tipo: "ok", listado });
    expect(fetchSimulado).toHaveBeenCalledWith("/api/notificaciones?pagina=2", { cache: "no-store" });
  });

  it("401 → sesion", async () => {
    fetchSimulado.mockResolvedValue(respuesta(401));
    expect(await consultarPagina(1)).toEqual({ tipo: "sesion" });
  });

  it.each([
    ["500", () => fetchSimulado.mockResolvedValue(respuesta(500))],
    ["502 (backend caído)", () => fetchSimulado.mockResolvedValue(respuesta(502))],
    ["400", () => fetchSimulado.mockResolvedValue(respuesta(400))],
    ["cuerpo inesperado", () => fetchSimulado.mockResolvedValue(respuesta(200, { raro: true }))],
    ["JSON inválido", () => fetchSimulado.mockResolvedValue(new Response("{x", { status: 200 }))],
    ["red caída", () => fetchSimulado.mockRejectedValue(new TypeError("Failed to fetch"))],
  ])("%s → error", async (_caso, preparar) => {
    preparar();
    expect(await consultarPagina(1)).toEqual({ tipo: "error" });
  });
});

describe("marcarLeida", () => {
  it("hace PATCH al puente y lee el nuevo contador", async () => {
    const marcada = { id: ID, estado: "LEIDA", leidaEn: "2026-11-18T21:00:00.000Z", noLeidas: 2 };
    fetchSimulado.mockResolvedValue(respuesta(200, marcada));
    expect(await marcarLeida(ID)).toEqual({ tipo: "ok", marcada });
    expect(fetchSimulado).toHaveBeenCalledWith(`/api/notificaciones/${ID}/leida`, { method: "PATCH", cache: "no-store" });
  });

  it("codifica el id en la ruta", async () => {
    fetchSimulado.mockResolvedValue(respuesta(404));
    await marcarLeida("a/b");
    expect(fetchSimulado.mock.calls[0][0]).toBe("/api/notificaciones/a%2Fb/leida");
  });

  it.each([
    [401, "sesion"],
    [404, "no-encontrada"],
    [400, "error"],
    [500, "error"],
  ])("%i → %s", async (status, tipo) => {
    fetchSimulado.mockResolvedValue(respuesta(status, { message: "x" }));
    expect((await marcarLeida(ID)).tipo).toBe(tipo);
  });

  it("200 con cuerpo inesperado o red caída → error", async () => {
    fetchSimulado.mockResolvedValue(respuesta(200, { id: ID }));
    expect((await marcarLeida(ID)).tipo).toBe("error");
    fetchSimulado.mockRejectedValue(new TypeError("Failed to fetch"));
    expect((await marcarLeida(ID)).tipo).toBe("error");
  });
});
