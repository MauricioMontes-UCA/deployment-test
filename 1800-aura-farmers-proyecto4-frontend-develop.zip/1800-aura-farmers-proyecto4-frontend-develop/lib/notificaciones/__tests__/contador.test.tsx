import { act, render, screen } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { establecerNoLeidas, refrescarNoLeidas, reiniciarContador, useNoLeidas } from "../contador";

const fetchSimulado = vi.fn();

const listado = (noLeidas: number) =>
  new Response(JSON.stringify({ noLeidas, total: 0, pagina: 1, tamanoPagina: 20, notificaciones: [] }), {
    status: 200,
    headers: { "Content-Type": "application/json" },
  });

/** Respuesta que la prueba entrega cuando quiere. */
function diferida() {
  let entregar!: (respuesta: Response) => void;
  const promesa = new Promise<Response>((r) => (entregar = r));
  return { promesa, entregar };
}

function Sonda({ clave, id = "n" }: { clave: string | null; id?: string }) {
  const noLeidas = useNoLeidas(clave);
  return <p data-testid={id}>{noLeidas === null ? "nulo" : noLeidas}</p>;
}
const valor = (id = "n") => screen.getByTestId(id).textContent;
const avanzar = (ms: number) => act(() => vi.advanceTimersByTimeAsync(ms));

let visibilidad: DocumentVisibilityState = "visible";
function cambiarVisibilidad(nueva: DocumentVisibilityState) {
  visibilidad = nueva;
  return act(async () => {
    document.dispatchEvent(new Event("visibilitychange"));
    await vi.advanceTimersByTimeAsync(0);
  });
}

beforeEach(() => {
  vi.useFakeTimers();
  reiniciarContador();
  visibilidad = "visible";
  Object.defineProperty(document, "visibilityState", { configurable: true, get: () => visibilidad });
  fetchSimulado.mockReset();
  fetchSimulado.mockImplementation(async () => listado(3));
  vi.stubGlobal("fetch", fetchSimulado);
});

afterEach(() => {
  vi.useRealTimers();
  vi.unstubAllGlobals();
});

describe("contador global de no leídas", () => {
  it("visitante (sin clave): no consulta nada y no hay valor", async () => {
    render(<Sonda clave={null} />);
    await avanzar(60_000);
    expect(fetchSimulado).not.toHaveBeenCalled();
    expect(valor()).toBe("nulo");
  });

  it("la primera consulta sale cuando el componente ya se montó, no durante el render", async () => {
    render(<Sonda clave="ana_m" />);
    expect(fetchSimulado).not.toHaveBeenCalled();
    expect(valor()).toBe("nulo");
    await avanzar(0);
    expect(fetchSimulado).toHaveBeenCalledTimes(1);
    expect(fetchSimulado).toHaveBeenCalledWith("/api/notificaciones?pagina=1", { cache: "no-store" });
    expect(valor()).toBe("3");
  });

  it("consulta cada 30 s: no antes, y el valor se actualiza", async () => {
    render(<Sonda clave="ana_m" />);
    await avanzar(0);
    fetchSimulado.mockImplementation(async () => listado(5));
    await avanzar(29_999);
    expect(fetchSimulado).toHaveBeenCalledTimes(1);
    await avanzar(1);
    expect(fetchSimulado).toHaveBeenCalledTimes(2);
    expect(valor()).toBe("5");
    await avanzar(30_000);
    expect(fetchSimulado).toHaveBeenCalledTimes(3);
  });

  it("un solo temporizador aunque varios componentes usen el contador", async () => {
    render(
      <>
        <Sonda clave="ana_m" id="a" />
        <Sonda clave="ana_m" id="b" />
        <Sonda clave="ana_m" id="c" />
      </>,
    );
    await avanzar(0);
    expect(fetchSimulado).toHaveBeenCalledTimes(1);
    await avanzar(30_000);
    expect(fetchSimulado).toHaveBeenCalledTimes(2);
    expect([valor("a"), valor("b"), valor("c")]).toEqual(["3", "3", "3"]);
  });

  it("al desmontarse el último componente se detienen las consultas", async () => {
    const { unmount } = render(<Sonda clave="ana_m" />);
    await avanzar(0);
    unmount();
    await avanzar(120_000);
    expect(fetchSimulado).toHaveBeenCalledTimes(1);
  });

  it("al navegar entre pantallas no repite la consulta si la última es reciente", async () => {
    const primera = render(<Sonda clave="ana_m" />);
    await avanzar(10_000);
    primera.unmount();
    render(<Sonda clave="ana_m" />);
    await avanzar(0);
    expect(fetchSimulado).toHaveBeenCalledTimes(1);
    expect(valor()).toBe("3");
    // Respeta lo que faltaba del ciclo: 20 s más.
    await avanzar(19_999);
    expect(fetchSimulado).toHaveBeenCalledTimes(1);
    await avanzar(1);
    expect(fetchSimulado).toHaveBeenCalledTimes(2);
  });

  it("con la pestaña oculta se pausa; al volver consulta de inmediato y reanuda el ciclo", async () => {
    render(<Sonda clave="ana_m" />);
    await avanzar(0);
    await cambiarVisibilidad("hidden");
    await avanzar(120_000);
    expect(fetchSimulado).toHaveBeenCalledTimes(1);

    fetchSimulado.mockImplementation(async () => listado(8));
    await cambiarVisibilidad("visible");
    expect(fetchSimulado).toHaveBeenCalledTimes(2);
    expect(valor()).toBe("8");
    await avanzar(30_000);
    expect(fetchSimulado).toHaveBeenCalledTimes(3);
  });

  it("un 401 oculta el valor y detiene las consultas", async () => {
    fetchSimulado.mockImplementation(async () => new Response("{}", { status: 401 }));
    render(<Sonda clave="ana_m" />);
    await avanzar(0);
    expect(valor()).toBe("nulo");
    await avanzar(120_000);
    await cambiarVisibilidad("visible");
    expect(fetchSimulado).toHaveBeenCalledTimes(1);
  });

  it("tras un 401, al volver a iniciar sesión (sin componentes montados entre medio) consulta otra vez", async () => {
    fetchSimulado.mockImplementationOnce(async () => new Response("{}", { status: 401 }));
    const antes = render(<Sonda clave="ana_m" />);
    await avanzar(0);
    antes.unmount();
    render(<Sonda clave="ana_m" />);
    await avanzar(0);
    expect(fetchSimulado).toHaveBeenCalledTimes(2);
    expect(valor()).toBe("3");
  });

  it("un error de red conserva el último valor y reintenta en el siguiente ciclo", async () => {
    render(<Sonda clave="ana_m" />);
    await avanzar(0);
    fetchSimulado.mockImplementationOnce(async () => {
      throw new TypeError("Failed to fetch");
    });
    await avanzar(30_000);
    expect(valor()).toBe("3");
    fetchSimulado.mockImplementation(async () => listado(4));
    await avanzar(30_000);
    expect(valor()).toBe("4");
  });

  it("al cambiar de usuario se vacía el valor y se descarta la respuesta pendiente del anterior", async () => {
    const pendienteAna = diferida();
    fetchSimulado.mockImplementationOnce(() => pendienteAna.promesa);
    const { rerender } = render(<Sonda clave="ana_m" />);
    await avanzar(0);

    fetchSimulado.mockImplementation(async () => listado(1));
    rerender(<Sonda clave="luis" />);
    expect(valor()).toBe("nulo");
    // Llega tarde la respuesta de ana_m: no se aplica a luis.
    await act(async () => pendienteAna.entregar(listado(7)));
    expect(valor()).toBe("nulo");
    await avanzar(0);
    expect(valor()).toBe("1");
  });

  it("tras cambiar de usuario, ningún componente ve el número del anterior mientras llega el nuevo", async () => {
    const { rerender } = render(<Sonda clave="ana_m" />);
    await avanzar(0);
    expect(valor()).toBe("3");

    const pendienteLuis = diferida();
    fetchSimulado.mockImplementationOnce(() => pendienteLuis.promesa);
    rerender(<Sonda clave="luis" />);
    await avanzar(0);
    // Otra pantalla (por ejemplo, el centro) se monta antes de la respuesta de luis.
    rerender(
      <>
        <Sonda clave="luis" />
        <Sonda clave="luis" id="otro" />
      </>,
    );
    expect(valor()).toBe("nulo");
    expect(valor("otro")).toBe("nulo");
    await act(async () => pendienteLuis.entregar(listado(1)));
    expect(valor("otro")).toBe("1");
  });

  it("una consulta que empezó antes de marcar como leída no pisa el valor nuevo", async () => {
    render(<Sonda clave="ana_m" />);
    await avanzar(0);
    const tardia = diferida();
    fetchSimulado.mockImplementationOnce(() => tardia.promesa);
    await avanzar(30_000); // sale la consulta del ciclo y queda en curso

    act(() => establecerNoLeidas("ana_m", 2));
    expect(valor()).toBe("2");
    await act(async () => tardia.entregar(listado(3)));
    expect(valor()).toBe("2");
  });

  it("establecerNoLeidas de otro usuario se ignora", async () => {
    render(<Sonda clave="ana_m" />);
    await avanzar(0);
    act(() => establecerNoLeidas("luis", 0));
    expect(valor()).toBe("3");
  });

  it("refrescar comparte la consulta en curso: una sola petición", async () => {
    render(<Sonda clave="ana_m" />);
    await avanzar(0);
    const pendiente = diferida();
    fetchSimulado.mockImplementationOnce(() => pendiente.promesa);
    let a!: Promise<unknown>;
    let b!: Promise<unknown>;
    act(() => {
      a = refrescarNoLeidas("ana_m");
      b = refrescarNoLeidas("ana_m");
    });
    await act(async () => pendiente.entregar(listado(6)));
    expect(await a).toEqual(await b);
    expect(fetchSimulado).toHaveBeenCalledTimes(2);
    expect(valor()).toBe("6");
  });

  it("refrescar reinicia el ciclo de 30 s", async () => {
    render(<Sonda clave="ana_m" />);
    await avanzar(20_000);
    await act(async () => {
      await refrescarNoLeidas("ana_m");
    });
    expect(fetchSimulado).toHaveBeenCalledTimes(2);
    await avanzar(29_999);
    expect(fetchSimulado).toHaveBeenCalledTimes(2);
    await avanzar(1);
    expect(fetchSimulado).toHaveBeenCalledTimes(3);
  });
});
