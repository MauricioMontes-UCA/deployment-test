import { describe, expect, it } from "vitest";
import {
  ETIQUETA_MODULO,
  ID_NOTIFICACION,
  INTERVALO_CONSULTA_MS,
  MENSAJES_NOTIFICACIONES,
  PAGINA_VALIDA,
  TAMANO_PAGINA,
  formatearFechaHora,
  hayMasPaginas,
  leerListado,
  leerMarcada,
  leerNotificacion,
  unirPaginas,
  type NotificacionApi,
} from "../reglas";

// Acepta cualquier valor: las pruebas también arman avisos inválidos.
const aviso = (cambios: Record<string, unknown> = {}) => ({
  id: "a1b2c3d4-0000-4000-8000-000000000001",
  titulo: "Nueva solicitud de reserva",
  mensaje: "ana_m solicitó Taladro industrial.",
  estado: "NO_LEIDA",
  moduloOrigen: "RESERVAS",
  creadaEn: "2026-11-18T20:32:00.000Z",
  ...cambios,
});

const listado = (cambios: Record<string, unknown> = {}) => ({
  noLeidas: 3,
  total: 5,
  pagina: 1,
  tamanoPagina: 20,
  notificaciones: [aviso()],
  ...cambios,
});

describe("constantes del contrato", () => {
  it("20 por página, consulta cada 30 s y los textos de Figma", () => {
    expect(TAMANO_PAGINA).toBe(20);
    expect(INTERVALO_CONSULTA_MS).toBe(30_000);
    expect(MENSAJES_NOTIFICACIONES).toMatchObject({
      vacioTitulo: "No tienes notificaciones.",
      errorCarga: "No pudimos cargar tus notificaciones. Intenta de nuevo.",
      noEncontrada: "No encontramos esa notificación.",
    });
  });

  it("etiqueta de los cinco módulos del backend", () => {
    expect(ETIQUETA_MODULO).toEqual({
      RESERVAS: "Reservas",
      PAGOS: "Pagos",
      MENSAJERIA: "Mensajería",
      RESENAS: "Reseñas",
      VERIFICACION: "Verificación",
    });
  });

  it("valida la página y el id como los acepta el backend", () => {
    for (const valida of ["1", "2", "20", "1234567890"]) expect(PAGINA_VALIDA.test(valida)).toBe(true);
    for (const invalida of ["0", "-1", "01", "1.5", "a", "", " 1", "12345678901"]) expect(PAGINA_VALIDA.test(invalida)).toBe(false);
    expect(ID_NOTIFICACION.test("a1b2c3d4-0000-4000-8000-000000000001")).toBe(true);
    expect(ID_NOTIFICACION.test("../auth/me")).toBe(false);
  });
});

describe("leerNotificacion", () => {
  it("lee un aviso válido", () => {
    expect(leerNotificacion(aviso())).toEqual(aviso());
  });

  it.each([
    ["no es objeto", null],
    ["id numérico", aviso({ id: 1 })],
    ["sin título", aviso({ titulo: undefined })],
    ["estado desconocido", aviso({ estado: "ARCHIVADA" })],
    ["módulo desconocido", aviso({ moduloOrigen: "OTRO" })],
    ["fecha inválida", aviso({ creadaEn: "ayer" })],
  ])("%s → null", (_caso, valor) => {
    expect(leerNotificacion(valor)).toBeNull();
  });
});

describe("leerListado", () => {
  it("lee la respuesta de BE-21.1", () => {
    expect(leerListado(listado())).toEqual(listado());
  });

  it("lista vacía con total 0", () => {
    expect(leerListado(listado({ noLeidas: 0, total: 0, notificaciones: [] }))?.notificaciones).toEqual([]);
  });

  it.each([
    ["sin lista", listado({ notificaciones: null })],
    ["noLeidas negativo", listado({ noLeidas: -1 })],
    ["total decimal", listado({ total: 1.5 })],
    ["página 0", listado({ pagina: 0 })],
    ["un aviso ilegible", listado({ notificaciones: [aviso(), { id: "roto" }] })],
  ])("%s → null (no se muestra una página incompleta)", (_caso, valor) => {
    expect(leerListado(valor)).toBeNull();
  });
});

describe("leerMarcada", () => {
  it("lee la respuesta de BE-21.2", () => {
    const marcada = { id: "x", estado: "LEIDA", leidaEn: "2026-11-18T21:00:00.000Z", noLeidas: 2 };
    expect(leerMarcada(marcada)).toEqual(marcada);
  });

  it.each([
    ["estado no LEIDA", { id: "x", estado: "NO_LEIDA", leidaEn: "2026-11-18T21:00:00.000Z", noLeidas: 2 }],
    ["sin leidaEn", { id: "x", estado: "LEIDA", noLeidas: 2 }],
    ["noLeidas texto", { id: "x", estado: "LEIDA", leidaEn: "2026-11-18T21:00:00.000Z", noLeidas: "2" }],
  ])("%s → null", (_caso, valor) => {
    expect(leerMarcada(valor)).toBeNull();
  });
});

describe("paginación", () => {
  it("hay más páginas solo mientras lo cargado sea menor que el total", () => {
    expect(hayMasPaginas(1, 5)).toBe(false);
    expect(hayMasPaginas(1, 20)).toBe(false);
    expect(hayMasPaginas(1, 21)).toBe(true);
    expect(hayMasPaginas(2, 40)).toBe(false);
    expect(hayMasPaginas(2, 41)).toBe(true);
    expect(hayMasPaginas(1, 0)).toBe(false);
  });

  it("unirPaginas descarta los avisos repetidos y conserva el orden", () => {
    const a = aviso({ id: "a" }) as NotificacionApi;
    const b = aviso({ id: "b" }) as NotificacionApi;
    const c = aviso({ id: "c" }) as NotificacionApi;
    expect(unirPaginas([a, b], [b, c]).map((n) => n.id)).toEqual(["a", "b", "c"]);
  });
});

describe("formatearFechaHora", () => {
  it("dd/mm/aaaa hh:mm en hora de El Salvador (UTC-6)", () => {
    expect(formatearFechaHora("2026-11-18T20:32:00.000Z")).toBe("18/11/2026 14:32");
  });

  it("medianoche como 00, nunca 24, y el día local", () => {
    expect(formatearFechaHora("2026-11-19T06:05:00.000Z")).toBe("19/11/2026 00:05");
    expect(formatearFechaHora("2026-11-19T03:15:00.000Z")).toBe("18/11/2026 21:15");
  });
});
