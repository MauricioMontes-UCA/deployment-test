/**
 * Une clases de CSS ignorando los valores falsos, para escribir clases
 * condicionales sin plantillas largas: `unirClases("a", activo && "b")`.
 *
 * No resuelve conflictos entre utilidades de Tailwind: si se pasa una clase
 * que pisa a otra del componente, gana la que aparezca después en el CSS.
 */
export function unirClases(
  ...clases: Array<string | false | null | undefined>
): string {
  return clases.filter(Boolean).join(" ");
}
