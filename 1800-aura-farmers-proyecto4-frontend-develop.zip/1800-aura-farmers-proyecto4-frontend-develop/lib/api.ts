import "server-only";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { TIEMPO_LIMITE_MS, mensajesDe } from "./auth-api";
import { obtenerApiUrl } from "./config";
import { COOKIE_ACCESO } from "./cookies-sesion";

/** Error de la API con el código y los mensajes que devolvió el backend. */
export class ApiError extends Error {
  constructor(
    public readonly status: number,
    public readonly mensajes: string[],
  ) {
    super(mensajes[0] ?? (status === 0 ? "La API no respondió." : `La API respondió ${status}.`));
    this.name = "ApiError";
  }
}

/** Respuesta de la API sin interpretar. `status` 0: no hubo respuesta. */
export type RespuestaApiCruda = {
  status: number;
  datos: unknown;
  mensajes: string[];
};

/**
 * Llama a un endpoint del backend con el access token y devuelve el código y
 * el cuerpo, sin redirigir ni lanzar. Es la base de `apiFetch` y de quien
 * necesita decidir qué hacer con cada código (por ejemplo, el usuario actual).
 *
 * El token sale de la cookie, salvo que se pase `acceso` (en un route handler
 * que ya lo renovó). Tiene el mismo tiempo límite que las llamadas de auth.
 */
export async function llamarApi(
  ruta: string,
  init: RequestInit = {},
  acceso?: string,
): Promise<RespuestaApiCruda> {
  const token = acceso ?? (await cookies()).get(COOKIE_ACCESO)?.value;
  const headers: Record<string, string> = { ...(init.headers as Record<string, string> | undefined) };
  if (token) headers.Authorization = `Bearer ${token}`;
  if (init.body && !(init.body instanceof FormData) && !headers["Content-Type"]) {
    headers["Content-Type"] = "application/json";
  }

  let respuesta: Response;
  try {
    respuesta = await fetch(new URL(ruta, obtenerApiUrl()), {
      cache: "no-store",
      signal: AbortSignal.timeout(TIEMPO_LIMITE_MS),
      ...init,
      headers,
    });
  } catch {
    return { status: 0, datos: null, mensajes: [] };
  }

  const texto = await respuesta.text();
  let datos: unknown = null;
  try {
    datos = texto ? JSON.parse(texto) : null;
  } catch {
    datos = null;
  }
  return { status: respuesta.status, datos, mensajes: respuesta.ok ? [] : mensajesDe(datos) };
}

/**
 * Cliente HTTP para los endpoints protegidos. Toma el access token de la
 * cookie y lo envía como `Authorization: Bearer`.
 *
 * No renueva el token: eso lo hace el proxy antes de cada navegación, con la
 * renovación compartida de `lib/sesion-vigente.ts`.
 *
 * Un 401 significa que la sesión ya no sirve (token revocado o cuenta
 * inactiva): se manda a `/sesion-vencida`, que borra las cookies y lleva al
 * login. Los demás errores, incluida la falta de respuesta, se lanzan como
 * `ApiError`.
 */
export async function apiFetch<T>(ruta: string, init: RequestInit = {}): Promise<T> {
  const { status, datos, mensajes } = await llamarApi(ruta, init);
  if (status === 401) redirect("/sesion-vencida");
  if (status === 0 || status >= 400) throw new ApiError(status, mensajes);
  return datos as T;
}
