/**
 * Bandeja de mensajes (H13, FE-13.2): contrato de `GET /conversaciones`
 * (BE-13.2), filtros, rutas y formato de las tarjetas. Sin dependencias de
 * servidor: la usan la bandeja (cliente), el puente `/api/conversaciones` y
 * las páginas.
 */
/** Tipo de conversación del backend: CONSULTA no tiene reserva; COORDINACION sí. */
export type TipoConversacion = "CONSULTA" | "COORDINACION";

/** Conversaciones por página (`CONVERSACIONES_POR_PAGINA` de BE-13.2). */
export const CONVERSACIONES_POR_PAGINA = 20;

export const esTipoConversacion = (valor: unknown): valor is TipoConversacion =>
  valor === "CONSULTA" || valor === "COORDINACION";

/** Pestañas de Jira: «Todas», «Consultas» y «Coordinación». `tipo` es el filtro del backend. */
export const FILTROS_BANDEJA = [
  { tipo: null, texto: "Todas" },
  { tipo: "CONSULTA", texto: "Consultas" },
  { tipo: "COORDINACION", texto: "Coordinación" },
] as const satisfies readonly { tipo: TipoConversacion | null; texto: string }[];

export type FiltroBandeja = TipoConversacion | null;

export type Participante = { id: string; nombreUsuario: string };

/** Una conversación de la bandeja (`ConversacionBandejaResponseDto`). */
export type ConversacionBandeja = {
  id: string;
  tipo: TipoConversacion;
  bien: { id: string; titulo: string; foto: string | null };
  /** Solo en COORDINACION. */
  reservaId: string | null;
  /** El participante que no es el usuario de la sesión. */
  otroParticipante: Participante;
  /** `null` si la conversación aún no tiene mensajes. El contenido llega recortado a 120 caracteres. */
  ultimoMensaje: { contenido: string; enviadoEn: string; remitenteId: string } | null;
  /** Fecha del último mensaje o, sin mensajes, de creación. */
  actualizadaEn: string;
};

export type PaginaBandeja = {
  items: ConversacionBandeja[];
  pagina: number;
  total: number;
  hayMas: boolean;
};

const esObjeto = (valor: unknown): valor is Record<string, unknown> =>
  typeof valor === "object" && valor !== null;
const esTexto = (valor: unknown): valor is string => typeof valor === "string";
const esFecha = (valor: unknown): valor is string => esTexto(valor) && !Number.isNaN(Date.parse(valor));
const esParticipante = (valor: unknown): valor is Participante =>
  esObjeto(valor) && esTexto(valor.id) && esTexto(valor.nombreUsuario);

/** Lee una conversación de la bandeja. `null` si falta algo o el tipo no cuadra con la reserva. */
export function leerConversacionBandeja(valor: unknown): ConversacionBandeja | null {
  if (!esObjeto(valor) || !esObjeto(valor.bien)) return null;
  const { id, tipo, reservaId, otroParticipante, ultimoMensaje, actualizadaEn, bien } = valor;
  const foto = bien.fotoPrincipalUrl ?? null;
  if (
    !esTexto(id) ||
    !esTipoConversacion(tipo) ||
    !esTexto(bien.id) ||
    !esTexto(bien.titulo) ||
    (foto !== null && !esTexto(foto)) ||
    !esParticipante(otroParticipante) ||
    !esFecha(actualizadaEn)
  ) {
    return null;
  }
  // Una coordinación siempre trae su reserva y una consulta nunca: sin eso no hay a dónde enlazar.
  if (tipo === "COORDINACION" ? !esTexto(reservaId) : reservaId != null) return null;

  let ultimo: ConversacionBandeja["ultimoMensaje"] = null;
  if (ultimoMensaje != null) {
    if (
      !esObjeto(ultimoMensaje) ||
      !esTexto(ultimoMensaje.contenido) ||
      !esFecha(ultimoMensaje.enviadoEn) ||
      !esTexto(ultimoMensaje.remitenteId)
    ) {
      return null;
    }
    const { contenido, enviadoEn, remitenteId } = ultimoMensaje;
    ultimo = { contenido, enviadoEn, remitenteId };
  }

  return {
    id,
    tipo,
    bien: { id: bien.id, titulo: bien.titulo, foto },
    reservaId: tipo === "COORDINACION" ? (reservaId as string) : null,
    otroParticipante: { id: otroParticipante.id, nombreUsuario: otroParticipante.nombreUsuario },
    ultimoMensaje: ultimo,
    actualizadaEn,
  };
}

/**
 * Lee una página de `GET /conversaciones`. Si una sola conversación no se
 * puede leer devuelve `null`: una bandeja incompleta escondería
 * conversaciones sin avisar. El orden es el del backend (más reciente primero).
 */
export function leerPaginaBandeja(datos: unknown): PaginaBandeja | null {
  if (!esObjeto(datos) || !Array.isArray(datos.items)) return null;
  const { pagina, total, hayMas } = datos;
  if (!Number.isInteger(pagina) || !Number.isInteger(total) || typeof hayMas !== "boolean") return null;
  const items: ConversacionBandeja[] = [];
  for (const valor of datos.items) {
    const item = leerConversacionBandeja(valor);
    if (!item) return null;
    items.push(item);
  }
  return { items, pagina: pagina as number, total: total as number, hayMas };
}

/**
 * Agrega una página nueva a la lista sin repetir conversaciones: si entre una
 * página y otra llega un mensaje, una conversación sube y puede aparecer de
 * nuevo; se conserva la primera vez que apareció.
 */
export function unirPaginas(
  actuales: readonly ConversacionBandeja[],
  nuevas: readonly ConversacionBandeja[],
): ConversacionBandeja[] {
  const vistas = new Set(actuales.map(({ id }) => id));
  return [...actuales, ...nuevas.filter(({ id }) => !vistas.has(id) && vistas.add(id))];
}

/** Ruta del puente con el filtro y la página (sin `tipo`, todas). */
export function rutaPuenteBandeja(tipo: FiltroBandeja, pagina: number): string {
  const consulta = new URLSearchParams();
  if (tipo) consulta.set("tipo", tipo);
  consulta.set("pagina", String(pagina));
  return `/api/conversaciones?${consulta}`;
}

/**
 * Dónde apareció una consulta en la bandeja: pestaña («Todas» o «Consultas») y
 * página. Solo es una pista para encontrar el bien y el otro participante sin
 * recorrer la bandeja (el backend no tiene `GET /conversaciones/:id`): el
 * servidor pide esa página con el token del usuario y usa los datos solo si la
 * conversación está ahí. Una pista falsa o vieja solo hace que no se encuentre.
 */
export type PistaBandeja = { filtro: "CONSULTA" | null; pagina: number };

const PISTA = /^(TODAS|CONSULTA)-([1-9]\d{0,5})$/;

/** «TODAS-3» o «CONSULTA-2». */
export const escribirPista = ({ filtro, pagina }: PistaBandeja) => `${filtro ?? "TODAS"}-${pagina}`;

export function leerPista(valor: unknown): PistaBandeja | null {
  const partes = typeof valor === "string" ? PISTA.exec(valor) : null;
  return partes ? { filtro: partes[1] === "CONSULTA" ? "CONSULTA" : null, pagina: Number(partes[2]) } : null;
}

/** Pista de una consulta cargada en la pestaña `filtro`, página `pagina`. En «Coordinación» no hay consultas. */
export function pistaDe(filtro: FiltroBandeja, pagina: number | undefined): PistaBandeja | undefined {
  if (pagina === undefined || filtro === "COORDINACION") return undefined;
  return { filtro, pagina };
}

/**
 * Pantalla propia de la conversación (móvil, y quien llega sin la bandeja):
 * - Coordinación: FE-14.1, por reserva.
 * - Consulta, para los dos roles: por id de conversación. Solo lee y responde
 *   (`GET`/`POST /conversaciones/:id/mensajes`): no abre una conversación
 *   nueva y no depende de que la publicación siga ACTIVA.
 */
export function rutaConversacion(conversacion: ConversacionBandeja, pista?: PistaBandeja): string {
  if (conversacion.tipo === "COORDINACION") return `/reservas/${conversacion.reservaId}/conversacion`;
  return pista ? `/mensajes/${conversacion.id}?pista=${escribirPista(pista)}` : `/mensajes/${conversacion.id}`;
}

/** Selección de la bandeja en escritorio: la conversación se abre al lado de la lista. */
export type SeleccionBandeja =
  | { tipo: "consulta"; conversacionId: string; pista?: PistaBandeja }
  | { tipo: "reserva"; reservaId: string };

export function seleccionDe(conversacion: ConversacionBandeja, pista?: PistaBandeja): SeleccionBandeja {
  if (conversacion.tipo === "COORDINACION") return { tipo: "reserva", reservaId: conversacion.reservaId as string };
  return pista ? { tipo: "consulta", conversacionId: conversacion.id, pista } : { tipo: "consulta", conversacionId: conversacion.id };
}

export function esSeleccionada(conversacion: ConversacionBandeja, seleccion: SeleccionBandeja | null): boolean {
  if (!seleccion) return false;
  return seleccion.tipo === "reserva"
    ? conversacion.reservaId === seleccion.reservaId
    : conversacion.tipo === "CONSULTA" && conversacion.id === seleccion.conversacionId;
}

/** `/mensajes?tipo=…&consulta=…&pista=…` o `&reserva=…`: conserva la pestaña al cambiar de conversación. */
export function rutaBandeja(tipo: FiltroBandeja, seleccion: SeleccionBandeja | null): string {
  const consulta = new URLSearchParams();
  if (tipo) consulta.set("tipo", tipo);
  if (seleccion?.tipo === "consulta") {
    consulta.set("consulta", seleccion.conversacionId);
    if (seleccion.pista) consulta.set("pista", escribirPista(seleccion.pista));
  }
  if (seleccion?.tipo === "reserva") consulta.set("reserva", seleccion.reservaId);
  const texto = consulta.toString();
  return texto ? `/mensajes?${texto}` : "/mensajes";
}

const ID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
export const esId = (valor: unknown): valor is string => typeof valor === "string" && ID.test(valor);

export const primerValor = (valor: string | string[] | undefined) => (Array.isArray(valor) ? valor[0] : valor);

/** Pestaña y selección desde la URL. Un valor inválido se ignora (pestaña «Todas», sin selección ni pista). */
export function leerParametrosBandeja(parametros: Record<string, string | string[] | undefined>): {
  tipo: FiltroBandeja;
  seleccion: SeleccionBandeja | null;
} {
  const tipo = primerValor(parametros.tipo);
  const consulta = primerValor(parametros.consulta);
  const reserva = primerValor(parametros.reserva);
  const pista = leerPista(primerValor(parametros.pista));
  const seleccion: SeleccionBandeja | null = esId(consulta)
    ? pista
      ? { tipo: "consulta", conversacionId: consulta, pista }
      : { tipo: "consulta", conversacionId: consulta }
    : esId(reserva)
      ? { tipo: "reserva", reservaId: reserva }
      : null;
  return { tipo: esTipoConversacion(tipo) ? tipo : null, seleccion };
}

/** «Salón de eventos Las Palmas · Consulta» o «… · Entrega», como en Figma. */
export function etiquetaBien(conversacion: ConversacionBandeja): string {
  return `${conversacion.bien.titulo} · ${conversacion.tipo === "CONSULTA" ? "Consulta" : "Entrega"}`;
}

/** Vista previa del último mensaje; sin mensajes no se inventa ninguno. */
export function vistaPrevia(conversacion: ConversacionBandeja): string {
  return conversacion.ultimoMensaje?.contenido ?? "Aún no hay mensajes";
}

const PARTES_DIA = new Intl.DateTimeFormat("en-GB", {
  timeZone: "America/El_Salvador",
  day: "2-digit",
  month: "2-digit",
  year: "numeric",
  hour: "2-digit",
  minute: "2-digit",
  hourCycle: "h23",
});

function partes(instante: Date) {
  const p = Object.fromEntries(PARTES_DIA.formatToParts(instante).map(({ type, value }) => [type, value]));
  return {
    ...p,
    // Días desde la época del calendario de El Salvador, para comparar «hoy» y «ayer».
    dia: Date.UTC(Number(p.year), Number(p.month) - 1, Number(p.day)) / 86_400_000,
  } as { day: string; month: string; year: string; hour: string; minute: string; dia: number };
}

/**
 * Fecha relativa de la tarjeta, en hora de El Salvador (Figma 30:1271):
 * hoy «10:42», ayer «Ayer», este año «16/11» y antes «16/11/2025».
 */
export function formatearFechaBandeja(iso: string, ahora: Date = new Date()): string {
  const fecha = partes(new Date(iso));
  const hoy = partes(ahora);
  if (fecha.dia === hoy.dia) return `${fecha.hour}:${fecha.minute}`;
  if (fecha.dia === hoy.dia - 1) return "Ayer";
  if (fecha.year === hoy.year) return `${fecha.day}/${fecha.month}`;
  return `${fecha.day}/${fecha.month}/${fecha.year}`;
}
