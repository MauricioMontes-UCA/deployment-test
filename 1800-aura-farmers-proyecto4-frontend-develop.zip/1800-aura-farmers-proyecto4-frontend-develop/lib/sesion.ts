import "server-only";
import { cookies } from "next/headers";
import type { SesionApi } from "./auth-api";
import { COOKIE_ACCESO, COOKIE_REFRESH, borrarCookiesSesion, escribirSesion } from "./cookies-sesion";

/** Guarda la sesión que devolvió el login. Solo en server actions o route handlers. */
export async function guardarSesion(sesion: SesionApi) {
  escribirSesion(await cookies(), sesion);
}

/** Borra la sesión. Solo en server actions o route handlers. */
export async function borrarSesion() {
  borrarCookiesSesion(await cookies());
}

export async function obtenerTokens() {
  const almacen = await cookies();
  return {
    acceso: almacen.get(COOKIE_ACCESO)?.value,
    refresh: almacen.get(COOKIE_REFRESH)?.value,
  };
}
