import type { TonoInsignia } from "@/components/ui";
import type { EstadoReserva } from "./tipos";

const DIA = /^(\d{4})-(\d{2})-(\d{2})$/;
const MS_POR_DIA = 24 * 60 * 60 * 1000;

function aUtc(dia: string) {
  const partes = DIA.exec(dia);
  if (!partes) return null;
  return Date.UTC(Number(partes[1]), Number(partes[2]) - 1, Number(partes[3]));
}

/** «2026-11-24» → «24/11/2026». Si el formato no es válido, lo devuelve igual. */
export function formatearDia(dia: string) {
  const partes = DIA.exec(dia);
  return partes ? `${partes[3]}/${partes[2]}/${partes[1]}` : dia;
}

/** «24/11/2026 → 25/11/2026 · 2 días» (el día de inicio y el de fin cuentan). */
export function formatearFechas(inicio: string, fin: string) {
  const desde = aUtc(inicio);
  const hasta = aUtc(fin);
  const rango = `${formatearDia(inicio)} → ${formatearDia(fin)}`;
  if (desde === null || hasta === null || hasta < desde) return rango;
  const dias = Math.round((hasta - desde) / MS_POR_DIA) + 1;
  return `${rango} · ${dias} ${dias === 1 ? "día" : "días"}`;
}

const MOTIVOS: Record<string, string> = {
  FECHAS_NO_DISPONIBLES: "fechas no disponibles",
  VERIFICACION_REQUERIDA: "verificación requerida",
  ERROR_DE_PROCESAMIENTO: "error de procesamiento",
};

/** «Motivo: fechas no disponibles», o null si la reserva no trae motivo. */
export function textoMotivo(motivo: string | null) {
  if (!motivo) return null;
  const legible = MOTIVOS[motivo] ?? motivo.toLowerCase().replaceAll("_", " ");
  return `Motivo: ${legible}`;
}

/** Texto y tono de la insignia. CANCELADA no está en Figma: usa advertencia para distinguirse. */
export const ESTADO_VISUAL: Record<EstadoReserva, { texto: string; tono: TonoInsignia }> = {
  EN_COLA: { texto: "En cola", tono: "neutro" },
  CONFIRMADA: { texto: "Confirmada", tono: "exito" },
  EN_CURSO: { texto: "En curso", tono: "marca" },
  FINALIZADA: { texto: "Finalizada", tono: "neutro" },
  RECHAZADA: { texto: "Rechazada", tono: "error" },
  CANCELADA: { texto: "Cancelada", tono: "advertencia" },
};

/** Acción de la fila según el estado (Figma FE-6.2). */
export function accionDeReserva(estado: EstadoReserva, id: string) {
  switch (estado) {
    case "CONFIRMADA":
      return { texto: "Pagar ahora", href: `/reservas/${id}/pago`, destacada: true };
    case "EN_CURSO":
      return { texto: "Coordinar entrega", href: `/reservas/${id}/entrega`, destacada: false };
    case "FINALIZADA":
      return { texto: "Calificar", href: `/reservas/${id}/calificar`, destacada: true };
    default:
      return { texto: "Ver detalle", href: `/reservas/${id}`, destacada: false };
  }
}

export const FILTROS: { valor: EstadoReserva | "TODAS"; texto: string }[] = [
  { valor: "TODAS", texto: "Todas" },
  { valor: "EN_COLA", texto: "En cola" },
  { valor: "CONFIRMADA", texto: "Confirmadas" },
  { valor: "EN_CURSO", texto: "En curso" },
  { valor: "FINALIZADA", texto: "Finalizadas" },
  { valor: "RECHAZADA", texto: "Rechazadas" },
  { valor: "CANCELADA", texto: "Canceladas" },
];
