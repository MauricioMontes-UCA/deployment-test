import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { esEstadoReserva, listarReservasMias } from "./servidor";

const reserva = {
  id: "r1",
  bienId: "b1",
  arrendatarioId: "u1",
  fechaInicio: "2026-11-24",
  fechaFin: "2026-11-25",
  estado: "CONFIRMADA",
  motivoResolucion: null,
  creadaEn: "2026-11-01T00:00:00.000Z",
  procesadaEn: null,
};

function json(cuerpo: unknown, status = 200) {
  return new Response(JSON.stringify(cuerpo), { status });
}

beforeEach(() => vi.stubEnv("API_URL", "http://api.test/api/v1"));
afterEach(() => {
  vi.unstubAllGlobals();
  vi.unstubAllEnvs();
});

describe("listarReservasMias", () => {
  it("envía el token y el filtro, y suma los datos del bien", async () => {
    const fetchMock = vi.fn(async (url: URL) =>
      url.pathname.endsWith("/reservas/mias")
        ? json([reserva, { ...reserva, id: "r2" }])
        : json({ titulo: "Salón", fotos: [{ url: "/uploads/a.jpg" }], arrendador: { nombreUsuario: "mariana" } }),
    );
    vi.stubGlobal("fetch", fetchMock);

    const resultado = await listarReservasMias("tok", "CONFIRMADA");

    const [primera, init] = fetchMock.mock.calls[0] as unknown as [URL, RequestInit];
    expect(primera.toString()).toBe("http://api.test/api/v1/reservas/mias?estado=CONFIRMADA");
    expect((init.headers as Record<string, string>).Authorization).toBe("Bearer tok");
    expect(init.signal).toBeInstanceOf(AbortSignal);
    // Un solo detalle por bien repetido: 1 listado + 1 bien.
    expect(fetchMock).toHaveBeenCalledTimes(2);
    expect(resultado).toMatchObject({
      ok: true,
      reservas: [
        { id: "r1", titulo: "Salón", foto: "/uploads/a.jpg", arrendador: "mariana" },
        { id: "r2", titulo: "Salón" },
      ],
    });
  });

  it("muestra la reserva aunque falle el detalle del bien", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn(async (url: URL) =>
        url.pathname.endsWith("/reservas/mias") ? json([reserva]) : json({}, 404),
      ),
    );
    const resultado = await listarReservasMias("tok");
    expect(resultado).toMatchObject({ ok: true, reservas: [{ titulo: null, foto: null, arrendador: null }] });
  });

  it("propaga el 401 y los fallos de red", async () => {
    vi.stubGlobal("fetch", vi.fn(async () => json({}, 401)));
    expect(await listarReservasMias("tok")).toEqual({ ok: false, status: 401 });

    vi.stubGlobal("fetch", vi.fn(async () => Promise.reject(new Error("red"))));
    expect(await listarReservasMias("tok")).toEqual({ ok: false, status: 502 });
  });
});

describe("tiempo límite", () => {
  const sinRespuesta = () => Promise.reject(new DOMException("tiempo agotado", "TimeoutError"));

  it("responde 502 si el listado no contesta a tiempo", async () => {
    vi.stubGlobal("fetch", vi.fn(sinRespuesta));
    expect(await listarReservasMias("tok")).toEqual({ ok: false, status: 502 });
  });

  it("muestra la reserva si el detalle del bien no contesta a tiempo", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn(async (url: URL) =>
        url.pathname.endsWith("/reservas/mias") ? json([reserva]) : sinRespuesta(),
      ),
    );
    const resultado = await listarReservasMias("tok");
    expect(resultado).toMatchObject({ ok: true, reservas: [{ titulo: null, foto: null, arrendador: null }] });
  });
});

describe("esEstadoReserva", () => {
  it("acepta solo los estados del backend", () => {
    expect(esEstadoReserva("EN_COLA")).toBe(true);
    expect(esEstadoReserva("PAGADA")).toBe(false);
  });
});
