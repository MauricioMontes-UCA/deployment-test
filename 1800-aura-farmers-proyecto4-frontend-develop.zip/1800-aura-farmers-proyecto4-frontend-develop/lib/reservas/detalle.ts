import { formatearDia } from "./formato";
import { ESTADOS_RESERVA, type EstadoReserva } from "./tipos";

/** Estados del depósito de garantía, tal como los devuelve el backend. */
export type EstadoDeposito = "PENDIENTE" | "LIBERADO" | "RETENIDO" | "PARCIALMENTE_RETENIDO";
const ESTADOS_DEPOSITO: readonly string[] = ["PENDIENTE", "LIBERADO", "RETENIDO", "PARCIALMENTE_RETENIDO"];

export const TEXTO_DEPOSITO: Record<EstadoDeposito, string> = {
  PENDIENTE: "Pendiente",
  LIBERADO: "Liberado",
  RETENIDO: "Retenido",
  PARCIALMENTE_RETENIDO: "Parcialmente retenido",
};

/** Estados del pago simulado (`EstadoPago` del backend). */
export type EstadoPago = "PENDIENTE" | "SIMULADO_EXITOSO" | "SIMULADO_RECHAZADO";
const ESTADOS_PAGO: readonly string[] = ["PENDIENTE", "SIMULADO_EXITOSO", "SIMULADO_RECHAZADO"];

export const TEXTO_PAGO: Record<EstadoPago, string> = {
  PENDIENTE: "Pendiente",
  SIMULADO_EXITOSO: "Pagado",
  SIMULADO_RECHAZADO: "Rechazado",
};

type Participante = { id: string; nombreUsuario: string };

/** Lo que muestra el detalle, tomado de `GET /reservas/:id` (BE-6.5 y BE-27.2). */
export type DetalleReserva = {
  id: string;
  estado: EstadoReserva;
  fechaInicio: string;
  fechaFin: string;
  motivoResolucion: string | null;
  bien: { id: string; titulo: string; foto: string | null };
  arrendatario: Participante;
  arrendador: Participante;
  pago: { id: string; estado: EstadoPago; total: number } | null;
  deposito: { estado: EstadoDeposito; importe: number } | null;
};

const esObjeto = (valor: unknown): valor is Record<string, unknown> =>
  typeof valor === "object" && valor !== null;

function leerParticipante(valor: unknown): Participante | null {
  if (!esObjeto(valor)) return null;
  const { id, nombreUsuario } = valor;
  return typeof id === "string" && typeof nombreUsuario === "string" ? { id, nombreUsuario } : null;
}

/**
 * Valida el cuerpo de `GET /reservas/:id`. `pago` y `deposito` son opcionales
 * (una reserva sin pagar no los tiene); lo demás es obligatorio y, si falta o
 * cambia de forma, devuelve `null` para que la pantalla muestre el error.
 */
export function leerDetalle(datos: unknown): DetalleReserva | null {
  if (!esObjeto(datos) || !esObjeto(datos.bien)) return null;
  const { id, estado, fechaInicio, fechaFin, motivoResolucion, pago, deposito } = datos;
  const { id: bienId, titulo, fotoPrincipalUrl } = datos.bien;
  const arrendatario = leerParticipante(datos.arrendatario);
  const arrendador = leerParticipante(datos.arrendador);
  if (
    typeof id !== "string" ||
    typeof estado !== "string" ||
    !(ESTADOS_RESERVA as readonly string[]).includes(estado) ||
    typeof fechaInicio !== "string" ||
    typeof fechaFin !== "string" ||
    typeof bienId !== "string" ||
    typeof titulo !== "string" ||
    !arrendatario ||
    !arrendador
  ) {
    return null;
  }

  let pagoLeido: DetalleReserva["pago"] = null;
  if (esObjeto(pago) && typeof pago.id === "string" && ESTADOS_PAGO.includes(pago.estado as string)) {
    const total = Number(pago.total);
    if (Number.isFinite(total)) pagoLeido = { id: pago.id, estado: pago.estado as EstadoPago, total };
  }

  let depositoLeido: DetalleReserva["deposito"] = null;
  if (esObjeto(deposito) && ESTADOS_DEPOSITO.includes(deposito.estado as string)) {
    const importe = Number(deposito.importeOriginal);
    if (Number.isFinite(importe)) depositoLeido = { estado: deposito.estado as EstadoDeposito, importe };
  }

  return {
    id,
    estado: estado as EstadoReserva,
    fechaInicio,
    fechaFin,
    motivoResolucion: typeof motivoResolucion === "string" ? motivoResolucion : null,
    bien: { id: bienId, titulo, foto: typeof fotoPrincipalUrl === "string" ? fotoPrincipalUrl : null },
    arrendatario,
    arrendador,
    pago: pagoLeido,
    deposito: depositoLeido,
  };
}

/** «25» → «$25.00». */
export const formatearDinero = (importe: number) => `$${importe.toFixed(2)}`;

/** Días de la reserva, contando el de inicio y el de fin; `null` si las fechas no son válidas. */
export function diasDeReserva(inicio: string, fin: string): number | null {
  const desde = Date.parse(`${inicio}T00:00:00Z`);
  const hasta = Date.parse(`${fin}T00:00:00Z`);
  if (Number.isNaN(desde) || Number.isNaN(hasta) || hasta < desde) return null;
  return Math.round((hasta - desde) / (24 * 60 * 60 * 1000)) + 1;
}

export const textoDuracion = (inicio: string, fin: string) => {
  const dias = diasDeReserva(inicio, fin);
  if (dias === null) return `${formatearDia(inicio)} → ${formatearDia(fin)}`;
  return `${dias} ${dias === 1 ? "día" : "días"}`;
};

/** Pasos de la línea de estados de Figma. RECHAZADA y CANCELADA salen del flujo y no la usan. */
export const PASOS_LINEA = [
  { estado: "EN_COLA", texto: "En cola" },
  { estado: "CONFIRMADA", texto: "Confirmada" },
  { estado: "EN_CURSO", texto: "En curso" },
  { estado: "FINALIZADA", texto: "Finalizada" },
] as const;

/** Cuántos pasos de la línea están alcanzados; 0 si la reserva salió del flujo. */
export function pasosAlcanzados(estado: EstadoReserva): number {
  const indice = PASOS_LINEA.findIndex((paso) => paso.estado === estado);
  return indice + 1;
}

/**
 * Importe del alquiler: el total del pago menos el depósito, que se cobra
 * junto. Solo se puede desglosar con un pago exitoso: si el pago fue
 * rechazado o sigue pendiente, el backend no devuelve el depósito aunque el
 * total lo incluya, y la resta daría un alquiler inflado.
 */
export function importeAlquiler(detalle: DetalleReserva): number | null {
  if (!detalle.pago || detalle.pago.estado !== "SIMULADO_EXITOSO") return null;
  return Math.max(0, detalle.pago.total - (detalle.deposito?.importe ?? 0));
}

export type RolEnReserva = "ARRENDATARIO" | "ARRENDADOR";

/** Rol del usuario en la reserva, o `null` si no participa (se trata como no encontrada). */
export function rolEnReserva(detalle: DetalleReserva, usuarioId: string): RolEnReserva | null {
  if (detalle.arrendatario.id === usuarioId) return "ARRENDATARIO";
  if (detalle.arrendador.id === usuarioId) return "ARRENDADOR";
  return null;
}

export type AccionDeDetalle = {
  clave: "pagar" | "conversacion" | "calificar" | "devolucion" | "resolver-deposito" | "calificar-arrendatario";
  texto: string;
  href: string;
  /** Una acción deshabilitada se muestra, pero sin enlace, hasta que el estado la permita. */
  habilitada: boolean;
};

/**
 * El comprobante (`GET /pagos/:id/comprobante`) es solo del arrendatario: el
 * backend responde 403 al arrendador, así que a él no se le ofrece el enlace.
 */
export const puedeVerComprobante = (detalle: DetalleReserva, rol: RolEnReserva) =>
  rol === "ARRENDATARIO" && detalle.pago?.estado === "SIMULADO_EXITOSO";

export const pagoExitoso = (detalle: DetalleReserva) => detalle.pago?.estado === "SIMULADO_EXITOSO";

/** Se puede coordinar la entrega mientras la reserva está confirmada o en curso. */
export const puedeCoordinar = (estado: EstadoReserva) => estado === "CONFIRMADA" || estado === "EN_CURSO";

/**
 * Acciones del arrendatario según el estado (Figma FE-6.3): pagar una reserva
 * confirmada que aún no tiene pago exitoso y, al finalizar, calificar. La
 * coordinación de entrega es de ambos y la resuelve `accionesDeCoordinacion`.
 */
export function accionesDelArrendatario(detalle: DetalleReserva): AccionDeDetalle[] {
  const acciones: AccionDeDetalle[] = [];
  if (detalle.estado === "CONFIRMADA" && !pagoExitoso(detalle)) {
    acciones.push({ clave: "pagar", texto: "Pagar ahora", href: `/reservas/${detalle.id}/pago`, habilitada: true });
  }
  if (detalle.estado === "FINALIZADA") {
    acciones.push({ clave: "calificar", texto: "Calificar", href: `/reservas/${detalle.id}/calificar`, habilitada: true });
  }
  return acciones;
}

/**
 * Acciones del arrendador (Figma, «Acciones del arrendador»): siempre se
 * muestran las tres y se habilitan según el estado. Registrar la devolución
 * exige la reserva en curso; resolver el depósito y calificar, finalizada, y
 * resolver además un depósito todavía pendiente. El backend vuelve a validar.
 */
export function accionesDelArrendador(detalle: DetalleReserva): AccionDeDetalle[] {
  const finalizada = detalle.estado === "FINALIZADA";
  return [
    {
      clave: "devolucion",
      texto: "Registrar devolución",
      href: `/reservas/${detalle.id}/devolucion`,
      habilitada: detalle.estado === "EN_CURSO",
    },
    {
      clave: "resolver-deposito",
      texto: "Resolver depósito",
      href: `/reservas/${detalle.id}/deposito/resolver`,
      habilitada: finalizada && detalle.deposito?.estado === "PENDIENTE",
    },
    {
      clave: "calificar-arrendatario",
      texto: "Calificar arrendatario",
      href: `/reservas/${detalle.id}/calificar-arrendatario`,
      habilitada: finalizada,
    },
  ];
}

export const hrefConversacion = (id: string) => `/reservas/${id}/conversacion`;
