import { formatearMoneda } from "@/lib/solicitud/formato";
import type { EstadoReserva } from "./tipos";

/**
 * Estados por los que se filtra «Reservas recibidas» (BE-27.1). CANCELADA no
 * es filtro válido en el backend, aunque sin filtro sí aparecen las canceladas.
 */
export const ESTADOS_FILTRO_RECIBIDAS = [
  "EN_COLA",
  "CONFIRMADA",
  "RECHAZADA",
  "EN_CURSO",
  "FINALIZADA",
] as const;

export type EstadoFiltroRecibidas = (typeof ESTADOS_FILTRO_RECIBIDAS)[number];

export function esEstadoFiltroRecibidas(valor: string): valor is EstadoFiltroRecibidas {
  return (ESTADOS_FILTRO_RECIBIDAS as readonly string[]).includes(valor);
}

export const FILTROS_RECIBIDAS: { valor: EstadoFiltroRecibidas | "TODAS"; texto: string }[] = [
  { valor: "TODAS", texto: "Todas" },
  { valor: "EN_COLA", texto: "En cola" },
  { valor: "CONFIRMADA", texto: "Confirmadas" },
  { valor: "EN_CURSO", texto: "En curso" },
  { valor: "FINALIZADA", texto: "Finalizadas" },
  { valor: "RECHAZADA", texto: "Rechazadas" },
];

/** Reservas por página de `GET /reservas/recibidas`. */
export const RESERVAS_POR_PAGINA = 20;

export type PagoRecibido = {
  id: string;
  estado: "PENDIENTE" | "SIMULADO_EXITOSO" | "SIMULADO_RECHAZADO";
  total: number;
};

export type DepositoRecibido = {
  estado: "PENDIENTE" | "LIBERADO" | "RETENIDO" | "PARCIALMENTE_RETENIDO";
  importeOriginal: number;
};

/** Elemento de `GET /reservas/recibidas` (`ReservaResponseDto` enriquecido, BE-6.5). */
export type ReservaRecibida = {
  id: string;
  bienId: string;
  arrendatarioId: string;
  fechaInicio: string;
  fechaFin: string;
  estado: EstadoReserva;
  motivoResolucion: string | null;
  creadaEn: string;
  procesadaEn: string | null;
  bien?: { id: string; titulo: string; fotoPrincipalUrl: string | null };
  arrendatario?: { id: string; nombreUsuario: string };
  pago?: PagoRecibido | null;
  deposito?: DepositoRecibido | null;
};

/** Página de `GET /reservas/recibidas`. */
export type PaginaRecibidas = {
  items: ReservaRecibida[];
  pagina: number;
  total: number;
  hayMas: boolean;
};

const ESTADO_PAGO: Record<PagoRecibido["estado"], string> = {
  PENDIENTE: "pendiente",
  SIMULADO_EXITOSO: "pagado",
  SIMULADO_RECHAZADO: "rechazado",
};

const ESTADO_DEPOSITO: Record<DepositoRecibido["estado"], string> = {
  PENDIENTE: "pendiente",
  LIBERADO: "liberado",
  RETENIDO: "retenido",
  PARCIALMENTE_RETENIDO: "parcialmente retenido",
};

/**
 * «Pago: $75.00 (pagado) · Depósito: $100.00 (retenido)». Solo incluye lo que
 * existe; null si la reserva aún no tiene pago ni depósito.
 */
export function textoPagoYDeposito(
  pago: PagoRecibido | null | undefined,
  deposito: DepositoRecibido | null | undefined,
) {
  const partes: string[] = [];
  if (pago) partes.push(`Pago: ${formatearMoneda(pago.total)} (${ESTADO_PAGO[pago.estado] ?? "—"})`);
  if (deposito) {
    partes.push(
      `Depósito: ${formatearMoneda(deposito.importeOriginal)} (${ESTADO_DEPOSITO[deposito.estado] ?? "—"})`,
    );
  }
  return partes.length > 0 ? partes.join(" · ") : null;
}
