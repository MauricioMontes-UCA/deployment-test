import { describe, expect, it } from "vitest";
import {
  accionesDelArrendador,
  accionesDelArrendatario,
  diasDeReserva,
  importeAlquiler,
  leerDetalle,
  pasosAlcanzados,
  puedeVerComprobante,
  rolEnReserva,
  textoDuracion,
  type DetalleReserva,
} from "./detalle";

const ID = "5a3f2c10-8d4e-4b1a-9c7e-1f2a3b4c5d6e";
const api = {
  id: ID,
  bienId: "b1",
  arrendatarioId: "u1",
  fechaInicio: "2026-11-14",
  fechaFin: "2026-11-16",
  estado: "EN_CURSO",
  motivoResolucion: null,
  bien: { id: "b1", titulo: "Salón", fotoPrincipalUrl: "/uploads/s.jpg", precio: 80, unidadCobro: "DIA" },
  arrendatario: { id: "u1", nombreUsuario: "luis.perez" },
  arrendador: { id: "u2", nombreUsuario: "mariana_rivas" },
  pago: { id: "p1", estado: "SIMULADO_EXITOSO", total: 265 },
  deposito: { estado: "PENDIENTE", importeOriginal: 25 },
};
const detalle = (cambios: Partial<DetalleReserva> = {}): DetalleReserva => ({ ...leerDetalle(api)!, ...cambios });

describe("leerDetalle", () => {
  it("lee la reserva enriquecida de BE-6.5", () => {
    expect(leerDetalle(api)).toEqual({
      id: ID,
      estado: "EN_CURSO",
      fechaInicio: "2026-11-14",
      fechaFin: "2026-11-16",
      motivoResolucion: null,
      bien: { id: "b1", titulo: "Salón", foto: "/uploads/s.jpg" },
      arrendatario: { id: "u1", nombreUsuario: "luis.perez" },
      arrendador: { id: "u2", nombreUsuario: "mariana_rivas" },
      pago: { id: "p1", estado: "SIMULADO_EXITOSO", total: 265 },
      deposito: { estado: "PENDIENTE", importe: 25 },
    });
  });

  it("pago, depósito y foto son opcionales", () => {
    const lectura = leerDetalle({ ...api, pago: null, deposito: undefined, bien: { ...api.bien, fotoPrincipalUrl: null } });
    expect(lectura).toMatchObject({ pago: null, deposito: null, bien: { foto: null } });
  });

  it("ignora un pago o depósito con forma inválida en lugar de inventar importes", () => {
    const lectura = leerDetalle({ ...api, pago: { id: "p1", estado: "OTRO", total: 1 }, deposito: { estado: "PENDIENTE", importeOriginal: "x" } });
    expect(lectura).toMatchObject({ pago: null, deposito: null });
  });

  it.each([
    ["no es objeto", null],
    ["sin bien", { ...api, bien: undefined }],
    ["estado desconocido", { ...api, estado: "NUEVO" }],
    ["sin arrendador", { ...api, arrendador: {} }],
    ["fechas ausentes", { ...api, fechaFin: undefined }],
  ])("devuelve null si %s", (_caso, datos) => {
    expect(leerDetalle(datos)).toBeNull();
  });
});

describe("fechas, línea de estados e importes", () => {
  it("cuenta el día de inicio y el de fin", () => {
    expect(diasDeReserva("2026-11-14", "2026-11-16")).toBe(3);
    expect(textoDuracion("2026-11-14", "2026-11-14")).toBe("1 día");
    expect(textoDuracion("2026-11-14", "2026-11-16")).toBe("3 días");
    expect(diasDeReserva("2026-11-16", "2026-11-14")).toBeNull();
  });

  it("avanza por la línea y RECHAZADA/CANCELADA salen de ella", () => {
    expect(pasosAlcanzados("EN_COLA")).toBe(1);
    expect(pasosAlcanzados("EN_CURSO")).toBe(3);
    expect(pasosAlcanzados("FINALIZADA")).toBe(4);
    expect(pasosAlcanzados("RECHAZADA")).toBe(0);
    expect(pasosAlcanzados("CANCELADA")).toBe(0);
  });

  it("con un pago exitoso, el alquiler es el total menos el depósito", () => {
    expect(importeAlquiler(detalle())).toBe(240);
    expect(importeAlquiler(detalle({ deposito: null }))).toBe(265);
    expect(importeAlquiler(detalle({ pago: null }))).toBeNull();
  });

  it.each(["SIMULADO_RECHAZADO", "PENDIENTE"] as const)(
    "con un pago %s no se desglosa: el backend no trae el depósito pero el total lo incluye",
    (estado) => {
      const pago = { id: "p1", estado, total: 73 };
      expect(importeAlquiler(detalle({ pago, deposito: null }))).toBeNull();
      expect(importeAlquiler(detalle({ pago }))).toBeNull();
    },
  );
});

describe("comprobante", () => {
  it("solo el arrendatario con un pago exitoso puede verlo", () => {
    expect(puedeVerComprobante(detalle(), "ARRENDATARIO")).toBe(true);
    expect(puedeVerComprobante(detalle(), "ARRENDADOR")).toBe(false);
    const rechazado = { id: "p1", estado: "SIMULADO_RECHAZADO" as const, total: 73 };
    expect(puedeVerComprobante(detalle({ pago: rechazado }), "ARRENDATARIO")).toBe(false);
    expect(puedeVerComprobante(detalle({ pago: null }), "ARRENDATARIO")).toBe(false);
  });
});

describe("rol en la reserva", () => {
  it("reconoce al arrendatario y al arrendador, y a nadie más", () => {
    expect(rolEnReserva(detalle(), "u1")).toBe("ARRENDATARIO");
    expect(rolEnReserva(detalle(), "u2")).toBe("ARRENDADOR");
    expect(rolEnReserva(detalle(), "u3")).toBeNull();
  });
});

describe("acciones según rol y estado", () => {
  const claves = (acciones: { clave: string }[]) => acciones.map((a) => a.clave);

  it("arrendatario: paga una reserva confirmada sin pago exitoso", () => {
    const acciones = accionesDelArrendatario(detalle({ estado: "CONFIRMADA", pago: null, deposito: null }));
    expect(acciones).toEqual([{ clave: "pagar", texto: "Pagar ahora", href: `/reservas/${ID}/pago`, habilitada: true }]);
  });

  it("arrendatario: con el pago exitoso ya no se ofrece pagar", () => {
    expect(accionesDelArrendatario(detalle({ estado: "CONFIRMADA" }))).toEqual([]);
  });

  it("arrendatario: califica al finalizar y no antes", () => {
    expect(claves(accionesDelArrendatario(detalle({ estado: "FINALIZADA" })))).toEqual(["calificar"]);
    expect(accionesDelArrendatario(detalle({ estado: "EN_CURSO" }))).toEqual([]);
    expect(accionesDelArrendatario(detalle({ estado: "RECHAZADA", pago: null }))).toEqual([]);
  });

  it("arrendador: en curso solo puede registrar la devolución", () => {
    const acciones = accionesDelArrendador(detalle({ estado: "EN_CURSO" }));
    expect(acciones.map((a) => [a.clave, a.habilitada])).toEqual([
      ["devolucion", true],
      ["resolver-deposito", false],
      ["calificar-arrendatario", false],
    ]);
  });

  it("arrendador: finalizada con depósito pendiente habilita resolver y calificar", () => {
    const acciones = accionesDelArrendador(detalle({ estado: "FINALIZADA" }));
    expect(acciones.map((a) => [a.clave, a.habilitada])).toEqual([
      ["devolucion", false],
      ["resolver-deposito", true],
      ["calificar-arrendatario", true],
    ]);
  });

  it("arrendador: con el depósito ya resuelto o sin depósito no ofrece resolverlo", () => {
    const resuelto = accionesDelArrendador(detalle({ estado: "FINALIZADA", deposito: { estado: "LIBERADO", importe: 25 } }));
    expect(resuelto.find((a) => a.clave === "resolver-deposito")?.habilitada).toBe(false);
    const sinDeposito = accionesDelArrendador(detalle({ estado: "FINALIZADA", deposito: null }));
    expect(sinDeposito.find((a) => a.clave === "resolver-deposito")?.habilitada).toBe(false);
  });
});
