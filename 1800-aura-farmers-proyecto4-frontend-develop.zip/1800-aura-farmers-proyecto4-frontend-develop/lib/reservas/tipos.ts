/** Estados de una solicitud de reserva, tal como los devuelve el backend. */
export const ESTADOS_RESERVA = [
  "EN_COLA",
  "CONFIRMADA",
  "EN_CURSO",
  "FINALIZADA",
  "RECHAZADA",
  "CANCELADA",
] as const;

export type EstadoReserva = (typeof ESTADOS_RESERVA)[number];

/** Respuesta de `GET /reservas/mias` (BE-6.3). */
export type ReservaApi = {
  id: string;
  bienId: string;
  arrendatarioId: string;
  fechaInicio: string;
  fechaFin: string;
  estado: EstadoReserva;
  motivoResolucion: string | null;
  creadaEn: string;
  procesadaEn: string | null;
};

/**
 * Reserva lista para pintar: la de la API más los datos del bien (título,
 * foto y arrendador) que el listado todavía no trae.
 */
export type ReservaVista = ReservaApi & {
  titulo: string | null;
  foto: string | null;
  arrendador: string | null;
};
