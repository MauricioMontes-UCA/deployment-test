import { llamarApi } from "@/lib/api";
import { ESTADOS_RESERVA, type EstadoReserva, type ReservaApi, type ReservaVista } from "./tipos";

export type ResultadoListado =
  | { ok: true; reservas: ReservaVista[] }
  | { ok: false; status: number };

export function esEstadoReserva(valor: string): valor is EstadoReserva {
  return (ESTADOS_RESERVA as readonly string[]).includes(valor);
}

type DatosBien = { titulo: string; foto: string | null; arrendador: string | null };

/** Título, foto principal y arrendador del bien. Si falla, la reserva se muestra sin ellos. */
async function consultarBien(bienId: string, token: string): Promise<DatosBien | null> {
  const { status, datos } = await llamarApi(`bienes/${bienId}`, {}, token);
  if (status !== 200 || !datos || typeof datos !== "object") return null;
  const bien = datos as {
    titulo?: unknown;
    fotos?: { url?: string }[];
    arrendador?: { nombreUsuario?: string };
  };
  return {
    titulo: typeof bien.titulo === "string" ? bien.titulo : "",
    foto: bien.fotos?.[0]?.url ?? null,
    arrendador: bien.arrendador?.nombreUsuario ?? null,
  };
}

/**
 * Pide a la API las reservas del arrendatario (`GET reservas/mias`) y les suma
 * los datos de cada bien. Las llamadas van por `llamarApi` (tiempo límite de
 * 5 s): si el backend no responde, el listado falla con 502 y el detalle de
 * un bien se omite. `API_URL` ya incluye `/api/v1`.
 *
 * El listado de BE-6.3 solo trae `bienId`; mientras no exista BE-6.5 (listado
 * con título, foto y arrendador) se consulta el detalle público de cada bien.
 */
export async function listarReservasMias(
  token: string,
  estado?: EstadoReserva,
): Promise<ResultadoListado> {
  const ruta = estado ? `reservas/mias?estado=${encodeURIComponent(estado)}` : "reservas/mias";
  const { status, datos } = await llamarApi(ruta, {}, token);
  if (status === 0) return { ok: false, status: 502 };
  if (status !== 200) return { ok: false, status };

  const reservas = datos as ReservaApi[] | null;
  if (!Array.isArray(reservas)) return { ok: false, status: 502 };

  const ids = [...new Set(reservas.map((reserva) => reserva.bienId))];
  const bienes = new Map(
    await Promise.all(ids.map(async (id) => [id, await consultarBien(id, token)] as const)),
  );

  return {
    ok: true,
    reservas: reservas.map((reserva) => {
      const bien = bienes.get(reserva.bienId);
      return {
        ...reserva,
        titulo: bien?.titulo || null,
        foto: bien?.foto ?? null,
        arrendador: bien?.arrendador ?? null,
      };
    }),
  };
}
