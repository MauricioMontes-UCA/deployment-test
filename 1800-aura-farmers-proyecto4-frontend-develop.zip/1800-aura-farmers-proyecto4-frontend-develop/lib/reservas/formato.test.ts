import { describe, expect, it } from "vitest";
import { accionDeReserva, ESTADO_VISUAL, formatearFechas, textoMotivo } from "./formato";
import { ESTADOS_RESERVA } from "./tipos";

describe("formatearFechas", () => {
  it("cuenta el día de inicio y el de fin", () => {
    expect(formatearFechas("2026-11-24", "2026-11-25")).toBe("24/11/2026 → 25/11/2026 · 2 días");
    expect(formatearFechas("2026-11-28", "2026-11-30")).toContain("3 días");
  });

  it("usa singular para un solo día", () => {
    expect(formatearFechas("2026-11-24", "2026-11-24")).toBe("24/11/2026 → 24/11/2026 · 1 día");
  });

  it("cruza el cambio de mes", () => {
    expect(formatearFechas("2026-11-30", "2026-12-02")).toContain("3 días");
  });
});

describe("textoMotivo", () => {
  it("traduce los motivos conocidos", () => {
    expect(textoMotivo("FECHAS_NO_DISPONIBLES")).toBe("Motivo: fechas no disponibles");
  });
  it("devuelve null sin motivo y legibiliza los desconocidos", () => {
    expect(textoMotivo(null)).toBeNull();
    expect(textoMotivo("OTRO_MOTIVO")).toBe("Motivo: otro motivo");
  });
});

describe("estados", () => {
  it("cada estado tiene insignia y los seis son distintos en texto", () => {
    const textos = ESTADOS_RESERVA.map((estado) => ESTADO_VISUAL[estado].texto);
    expect(new Set(textos).size).toBe(6);
  });

  it("elige la acción según el estado", () => {
    expect(accionDeReserva("CONFIRMADA", "x").texto).toBe("Pagar ahora");
    expect(accionDeReserva("EN_CURSO", "x").texto).toBe("Coordinar entrega");
    expect(accionDeReserva("FINALIZADA", "x").texto).toBe("Calificar");
    expect(accionDeReserva("RECHAZADA", "x").texto).toBe("Ver detalle");
  });
});
