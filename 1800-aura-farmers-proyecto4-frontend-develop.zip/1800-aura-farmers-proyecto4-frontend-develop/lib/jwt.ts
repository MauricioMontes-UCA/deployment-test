/** Rol de una cuenta, igual que el enum `Rol` del backend. */
export type Rol = "ARRENDADOR" | "ARRENDATARIO";

/** Payload del access token que firma el backend. */
export type PayloadAcceso = {
  sub: string;
  email: string;
  rol: Rol;
  iat: number;
  exp: number;
};

/**
 * Lee el payload de un JWT **sin verificar la firma**. El frontend no tiene
 * JWT_SECRET; el backend verifica el token en cada petición. Este valor solo
 * sirve para decisiones optimistas (si vale la pena renovar, qué mostrar).
 */
export function leerPayload(token: string | undefined | null): PayloadAcceso | null {
  if (!token) return null;
  const partes = token.split(".");
  if (partes.length !== 3) return null;
  try {
    const base64 = partes[1].replace(/-/g, "+").replace(/_/g, "/");
    const json = new TextDecoder().decode(
      Uint8Array.from(atob(base64.padEnd(Math.ceil(base64.length / 4) * 4, "=")), (c) =>
        c.charCodeAt(0),
      ),
    );
    const payload = JSON.parse(json);
    return typeof payload?.exp === "number" ? (payload as PayloadAcceso) : null;
  } catch {
    return null;
  }
}

/** Margen para renovar antes de que el token venza en pleno request. */
const MARGEN_MS = 30_000;

/** Indica si el access token sigue vigente (con 30 s de margen). */
export function accesoVigente(token: string | undefined | null, ahora = Date.now()): boolean {
  const payload = leerPayload(token);
  return payload !== null && payload.exp * 1000 - MARGEN_MS > ahora;
}
