/** Política «Solo usuarios verificados» de un bien (H19, BE-19.1). */
export type PoliticaVerificacion = {
  bienId: string;
  soloVerificados: boolean;
};

/**
 * Por qué falló una llamada:
 * - `sesion`: 401, la sesión venció.
 * - `prohibido`: 403, el bien no es del usuario o no está verificado.
 * - `no-encontrado`: 404, el bien no existe.
 * - `general`: cualquier otro fallo (400, 5xx, red).
 */
export type TipoDeError = "sesion" | "prohibido" | "no-encontrado" | "general";

export const MENSAJES_POLITICA: Record<Exclude<TipoDeError, "sesion">, string> = {
  prohibido: "No puedes modificar este bien. El interruptor volvió a su estado anterior.",
  "no-encontrado": "Este bien ya no existe. El interruptor volvió a su estado anterior.",
  general: "No pudimos guardar el cambio. Intenta de nuevo.",
};

export type ResultadoPolitica =
  | { ok: true; politica: PoliticaVerificacion }
  | { ok: false; tipo: TipoDeError; mensaje: string };

export function clasificarEstado(status: number): TipoDeError {
  if (status === 401) return "sesion";
  if (status === 403) return "prohibido";
  if (status === 404) return "no-encontrado";
  return "general";
}

function esPolitica(dato: unknown): dato is PoliticaVerificacion {
  const d = dato as Partial<PoliticaVerificacion> | null;
  return typeof d?.bienId === "string" && typeof d.soloVerificados === "boolean";
}

async function leerMensaje(respuesta: Response): Promise<string | null> {
  const cuerpo = (await respuesta.json().catch(() => null)) as { message?: unknown } | null;
  return typeof cuerpo?.message === "string" && cuerpo.message.trim() ? cuerpo.message : null;
}

async function pedir(bienId: string, init?: RequestInit): Promise<ResultadoPolitica> {
  try {
    const respuesta = await fetch(`/api/bienes/${encodeURIComponent(bienId)}/politica-verificacion`, {
      ...init,
      cache: "no-store",
    });
    if (!respuesta.ok) {
      const tipo = clasificarEstado(respuesta.status);
      if (tipo === "sesion") return { ok: false, tipo, mensaje: "" };
      // En 403 el backend explica el motivo (no es tuyo / no estás verificado).
      const motivo = tipo === "prohibido" ? await leerMensaje(respuesta) : null;
      return { ok: false, tipo, mensaje: motivo ?? MENSAJES_POLITICA[tipo] };
    }
    const dato: unknown = await respuesta.json().catch(() => null);
    if (!esPolitica(dato)) {
      return { ok: false, tipo: "general", mensaje: MENSAJES_POLITICA.general };
    }
    return { ok: true, politica: dato };
  } catch {
    return { ok: false, tipo: "general", mensaje: MENSAJES_POLITICA.general };
  }
}

/** Consulta si el bien exige usuarios verificados (`GET`). */
export function consultarPolitica(bienId: string): Promise<ResultadoPolitica> {
  return pedir(bienId);
}

/** Activa o desactiva la política del bien (`PUT`). Activarla exige arrendador verificado. */
export function actualizarPolitica(bienId: string, soloVerificados: boolean): Promise<ResultadoPolitica> {
  return pedir(bienId, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ soloVerificados }),
  });
}
