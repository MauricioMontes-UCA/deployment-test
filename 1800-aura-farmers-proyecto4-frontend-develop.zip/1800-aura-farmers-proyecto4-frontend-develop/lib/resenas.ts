/**
 * Reglas de la calificación de una reserva finalizada (H15, FE-15.1).
 *
 * Funciones puras: no hacen peticiones ni conocen React. La pantalla las usa
 * para validar el formulario y la server action para armar el cuerpo de
 * `POST /reservas/:reservaId/resenas` (BE-15.1) y traducir sus errores.
 */

import { hoyEnElSalvador } from "@/lib/disponibilidad";

/** Días completos, desde la finalización, para calificar (igual que `PLAZO_RESENA_DIAS` del backend). */
export const PLAZO_RESENA_DIAS = 14;

const MS_POR_DIA = 24 * 60 * 60 * 1000;

/**
 * Días de calendario de El Salvador entre `finalizadaEn` (ISO 8601) y `ahora`.
 * El mismo día de la finalización es el día 0. Misma regla que
 * `diasDesdeFinalizacion` del backend (`src/resenas/utils/plazo-resena.ts`).
 */
export function diasDesdeFinalizacion(finalizadaEn: string, ahora: Date = new Date()): number {
  const desde = Date.parse(`${hoyEnElSalvador(new Date(finalizadaEn))}T00:00:00Z`);
  const hasta = Date.parse(`${hoyEnElSalvador(ahora)}T00:00:00Z`);
  return Math.round((hasta - desde) / MS_POR_DIA);
}

/**
 * Si la reserva todavía se puede calificar, con las mismas condiciones que el
 * backend: estado FINALIZADA, con `finalizadaEn`, y como mucho 14 días desde
 * ese día (el 14 se permite, el 15 no). Es una ayuda para no mostrar un
 * formulario que el backend rechazaría con 422; el backend sigue decidiendo.
 */
export function puedeCalificarse(
  { estado, finalizadaEn }: { estado: string; finalizadaEn: string | null },
  ahora: Date = new Date(),
): boolean {
  if (estado !== "FINALIZADA" || !finalizadaEn || Number.isNaN(Date.parse(finalizadaEn))) {
    return false;
  }
  return diasDesdeFinalizacion(finalizadaEn, ahora) <= PLAZO_RESENA_DIAS;
}

/** Máximo de caracteres de cada comentario (`@MaxLength(500)` y `VARCHAR(500)`). */
export const LIMITE_COMENTARIO = 500;

export const PUNTUACION_MINIMA = 1;
export const PUNTUACION_MAXIMA = 5;

/** Puntuación válida: entero de 1 a 5. */
export type Puntuacion = 1 | 2 | 3 | 4 | 5;

/** Una de las dos reseñas tal como la recibe el backend. */
export type CalificacionPayload = {
  puntuacion: Puntuacion;
  /** Ya recortado; se omite cuando queda vacío. */
  comentario?: string;
};

/** Cuerpo exacto de `POST /reservas/:reservaId/resenas`: no admite campos extra. */
export type CrearResenasPayload = {
  bien: CalificacionPayload;
  arrendador: CalificacionPayload;
};

/** Respuesta 201 de `POST /reservas/:reservaId/resenas`. */
export type RespuestaResenas = {
  reservaId: string;
  resenaBienId: string;
  resenaArrendadorId: string;
  /** Fecha ISO 8601. */
  creadaEn: string;
};

/** Valores de una reseña en el formulario. `puntuacion` 0 es «sin selección». */
export type CalificacionFormulario = {
  puntuacion: number;
  comentario: string;
};

export type FormularioResenas = {
  bien: CalificacionFormulario;
  arrendador: CalificacionFormulario;
};

/** Lo mínimo que decide si «Enviar reseña» está habilitado. */
export type EstadoEnvio = {
  formulario: FormularioResenas;
  /** Hay una solicitud en curso. */
  enviando: boolean;
  /** El servidor ya respondió 409 o 422: reintentar no cambia el resultado. */
  bloqueado: boolean;
};

export function esPuntuacionValida(valor: unknown): valor is Puntuacion {
  return (
    typeof valor === "number" &&
    Number.isInteger(valor) &&
    valor >= PUNTUACION_MINIMA &&
    valor <= PUNTUACION_MAXIMA
  );
}

/** Comentario como lo guarda el backend: sin espacios al inicio ni al final. */
export function normalizarComentario(texto: string): string {
  return texto.trim();
}

/**
 * Caracteres de `texto` contados por code point (un emoji como 😀 cuenta 1, no
 * 2 como en `String.length`).
 *
 * Es el criterio de PostgreSQL para `VARCHAR(500)`. El `@MaxLength` del backend
 * (validator.isLength) cuenta igual salvo que descuenta los selectores de
 * variación (U+FE0E/U+FE0F): «❤️» le cuenta 1 y a la base 2. Contar code
 * points nunca da menos que el validador, así que no deja pasar un texto que
 * la base rechazaría.
 */
export function contarCaracteres(texto: string): number {
  return Array.from(texto).length;
}

/**
 * Cuántos caracteres sobran en el comentario, ya recortado como lo valida el
 * backend. 0 si cabe.
 */
export function excesoComentario(texto: string): number {
  return Math.max(0, contarCaracteres(normalizarComentario(texto)) - LIMITE_COMENTARIO);
}

/** «Tu comentario supera los 500 caracteres por {n}.» */
export function mensajeExceso(exceso: number): string {
  return `Tu comentario supera los ${LIMITE_COMENTARIO} caracteres por ${exceso}.`;
}

/** Mensaje de error del comentario, o `null` si cabe. */
export function errorComentario(texto: string): string | null {
  const exceso = excesoComentario(texto);
  return exceso > 0 ? mensajeExceso(exceso) : null;
}

function calificacionValida({ puntuacion, comentario }: CalificacionFormulario): boolean {
  return esPuntuacionValida(puntuacion) && excesoComentario(comentario) === 0;
}

/** Las dos puntuaciones elegidas y ningún comentario pasado del límite. */
export function formularioValido(formulario: FormularioResenas): boolean {
  return calificacionValida(formulario.bien) && calificacionValida(formulario.arrendador);
}

/** «Enviar reseña» se habilita solo con un formulario válido, sin envío en curso ni bloqueo. */
export function puedeEnviar({ formulario, enviando, bloqueado }: EstadoEnvio): boolean {
  return !enviando && !bloqueado && formularioValido(formulario);
}

function armarCalificacion({ puntuacion, comentario }: CalificacionFormulario): CalificacionPayload {
  const recortado = normalizarComentario(comentario);
  return recortado === ""
    ? { puntuacion: puntuacion as Puntuacion }
    : { puntuacion: puntuacion as Puntuacion, comentario: recortado };
}

/**
 * Cuerpo de la solicitud con solo los campos que acepta el backend: recorta
 * los comentarios y omite los vacíos. Devuelve `null` si el formulario no es
 * válido. No modifica el objeto recibido.
 */
export function armarPayload(formulario: FormularioResenas): CrearResenasPayload | null {
  if (!formularioValido(formulario)) return null;
  return {
    bien: armarCalificacion(formulario.bien),
    arrendador: armarCalificacion(formulario.arrendador),
  };
}

export type TipoErrorResenas =
  | "validacion"
  | "sin-permiso"
  | "no-encontrada"
  | "ya-calificada"
  | "fuera-de-plazo"
  | "servidor";

export type ErrorResenas = {
  tipo: TipoErrorResenas;
  mensaje: string;
  /** 409 y 422: el formulario queda bloqueado porque reintentar no sirve. */
  bloqueante: boolean;
};

export const MENSAJES_ERROR_RESENAS: Record<TipoErrorResenas, string> = {
  validacion: "Revisa la puntuación y el comentario.",
  "sin-permiso": "No tienes permiso para calificar esta reserva.",
  "no-encontrada": "No encontramos esa reserva.",
  "ya-calificada": "Ya calificaste esta reserva.",
  "fuera-de-plazo":
    "Solo puedes calificar reservas finalizadas dentro de los 14 días posteriores a la devolución.",
  servidor: "No pudimos enviar tu reseña. Intenta de nuevo.",
};

const TIPO_POR_ESTADO: Partial<Record<number, TipoErrorResenas>> = {
  400: "validacion",
  403: "sin-permiso",
  404: "no-encontrada",
  409: "ya-calificada",
  422: "fuera-de-plazo",
};

const TIPOS_BLOQUEANTES: ReadonlySet<TipoErrorResenas> = new Set(["ya-calificada", "fuera-de-plazo"]);

/**
 * Traduce la respuesta fallida de `POST /reservas/:reservaId/resenas` al
 * mensaje de la pantalla. `status` es `null` cuando falló la red. Cualquier
 * otro código (500, 502, 401…) cae en el mensaje genérico: el 401 lo resuelve
 * antes la capa de sesión.
 */
export function clasificarErrorResenas(status: number | null): ErrorResenas {
  const tipo = (status !== null && TIPO_POR_ESTADO[status]) || "servidor";
  return { tipo, mensaje: MENSAJES_ERROR_RESENAS[tipo], bloqueante: TIPOS_BLOQUEANTES.has(tipo) };
}
