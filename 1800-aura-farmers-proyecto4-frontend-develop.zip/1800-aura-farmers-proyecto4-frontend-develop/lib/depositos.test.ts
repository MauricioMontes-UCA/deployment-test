import { describe, expect, it } from "vitest";
import { validarRetencion, dinero, numero, ID_RESERVA } from "./depositos";

describe("FE-11.1 validaciones de depósito", () => {
 it("exige importe mayor que cero", () => { expect(validarRetencion("0", "Motivo", 40)).not.toBeNull(); expect(validarRetencion("", "Motivo", 40)).not.toBeNull(); });
 it("rechaza importes superiores al saldo", () => expect(validarRetencion("40.01", "Motivo", 40)).not.toBeNull());
 it("exige máximo dos decimales", () => expect(validarRetencion("15.001", "Motivo", 40)).not.toBeNull());
 it("exige justificación de 1 a 500", () => { expect(validarRetencion("15", "  ", 40)).not.toBeNull(); expect(validarRetencion("15", "x".repeat(501), 40)).not.toBeNull(); });
 it("acepta retención válida", () => expect(validarRetencion("15.50", "Falta un accesorio", 40)).toBeNull());
 it("formatea importes", () => expect(dinero(25)).toContain("25.00"));
 it("valida identificadores", () => expect(ID_RESERVA.test("123")).toBe(false));
 it("rechaza números no finitos", () => expect(numero("abc")).toBeNull());
});
