/**
 * Variables de entorno del frontend. Se leen en el servidor (server actions,
 * server components, route handlers y proxy); ninguna lleva NEXT_PUBLIC_.
 *
 * `validarEntorno()` corre al arrancar (instrumentation.ts): con la
 * configuración mal hecha el servidor no levanta, en vez de fallar a mitad de
 * una petición.
 */

/** Igual al valor por defecto de REFRESH_TOKEN_EXPIRES_IN_DAYS en el backend. */
export const DIAS_REFRESH_POR_DEFECTO = 7;

/** URL base de la API, con el prefijo `/api/v1` y terminada en `/`. */
export function obtenerApiUrl(): string {
  const apiUrl = process.env.API_URL;
  if (!apiUrl) {
    throw new Error("Falta la variable de entorno API_URL (por ejemplo http://localhost:3000/api/v1).");
  }
  return apiUrl.replace(/\/?$/, "/");
}

function leerDiasRefresh(): number | null {
  const valor = process.env.REFRESH_TOKEN_EXPIRES_IN_DAYS;
  if (!valor) return null;
  const dias = Number(valor);
  return Number.isFinite(dias) && dias > 0 ? dias : null;
}

/**
 * Vigencia del refresh token en días. El backend no la devuelve en la
 * respuesta del login, así que se configura igual que en el backend.
 *
 * Nunca lanza: se llama después de que el backend ya emitió o rotó el
 * refresh token, y un error en ese punto haría perder la sesión. Si la
 * variable falta, usa el mismo valor por defecto que el backend.
 */
export function obtenerDiasRefresh(): number {
  return leerDiasRefresh() ?? DIAS_REFRESH_POR_DEFECTO;
}

/**
 * Revisa la configuración al arrancar el servidor y lanza un error con todo
 * lo que falta. REFRESH_TOKEN_EXPIRES_IN_DAYS es opcional, pero si viene debe
 * ser un número mayor que 0.
 */
export function validarEntorno(): void {
  const problemas: string[] = [];

  const apiUrl = process.env.API_URL;
  if (!apiUrl) problemas.push("Falta API_URL (por ejemplo http://localhost:3000/api/v1).");
  else if (!URL.canParse(apiUrl)) problemas.push(`API_URL no es una URL válida: «${apiUrl}».`);

  if (process.env.REFRESH_TOKEN_EXPIRES_IN_DAYS && leerDiasRefresh() === null) {
    problemas.push("REFRESH_TOKEN_EXPIRES_IN_DAYS debe ser un número de días mayor que 0.");
  }

  if (problemas.length > 0) {
    throw new Error(`Configuración del frontend incompleta:\n- ${problemas.join("\n- ")}`);
  }
}
