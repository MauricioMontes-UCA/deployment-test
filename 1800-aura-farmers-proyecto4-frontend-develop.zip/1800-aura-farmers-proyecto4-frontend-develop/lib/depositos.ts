export const ID_RESERVA =
  /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
export type AccionDeposito = "LIBERAR" | "RETENER";

export function objeto(valor: unknown): Record<string, unknown> {
  return valor !== null && typeof valor === "object" && !Array.isArray(valor)
    ? (valor as Record<string, unknown>)
    : {};
}

export function numero(valor: unknown): number | null {
  const n =
    typeof valor === "number"
      ? valor
      : typeof valor === "string" && valor.trim()
        ? Number(valor)
        : NaN;
  return Number.isFinite(n) ? n : null;
}

export function dinero(valor: unknown): string {
  return (numero(valor) ?? 0).toLocaleString("en-US", {
    style: "currency",
    currency: "USD",
  });
}

export function validarRetencion(
  importe: string,
  justificacion: string,
  saldo: number,
): string | null {
  if (!/^(?:0|[1-9]\d*)(?:\.\d{1,2})?$/.test(importe) || Number(importe) <= 0) {
    return "Ingresa un importe válido mayor que $0.00, con hasta 2 decimales.";
  }
  if (Math.round(Number(importe) * 100) > Math.round(saldo * 100)) {
    return `La retención no puede superar el saldo disponible (${dinero(saldo)}).`;
  }
  if (!justificacion.trim() || justificacion.trim().length > 500) {
    return "La justificación es obligatoria y debe tener entre 1 y 500 caracteres.";
  }
  return null;
}

export function mensajeError(datos: unknown, defecto: string): string {
  const d = objeto(datos);
  const m = d.message ?? d.mensaje;
  return typeof m === "string"
    ? m
    : Array.isArray(m) && typeof m[0] === "string"
      ? m[0]
      : defecto;
}
