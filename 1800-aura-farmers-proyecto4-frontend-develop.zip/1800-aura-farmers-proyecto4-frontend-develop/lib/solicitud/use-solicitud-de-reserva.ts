"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { consultarReserva, solicitarReserva, type CausaDeFallo } from "./cliente";
import type { ReservaApi } from "./tipos";

/** Cada cuánto se consulta la solicitud en cola y cuánto se espera en total (FE-6.1). */
export const INTERVALO_DE_CONSULTA_MS = 2_000;
export const LIMITE_DE_ESPERA_MS = 30_000;

export type Rango = { inicio: string; fin: string };

/**
 * Estados del flujo: libre (sin enviar, con o sin rango elegido), enviando,
 * en cola (consultando), confirmada, rechazada, sin respuesta tras 30 s y fallo
 * (la solicitud no llegó a encolarse).
 */
export type Fase =
  | { tipo: "libre" }
  | { tipo: "enviando"; rango: Rango }
  | { tipo: "en-cola"; rango: Rango; reservaId: string; consultas: number }
  | { tipo: "confirmada"; rango: Rango; reservaId: string }
  | { tipo: "rechazada"; rango: Rango; reservaId: string; motivo: string | null }
  | { tipo: "sin-respuesta"; rango: Rango; reservaId: string }
  | { tipo: "fallo"; rango: Rango; causa: CausaDeFallo; mensaje?: string };

/**
 * Envía la solicitud y consulta su estado cada 2 s, hasta 30 s, hasta que
 * llega a un estado final. Un segundo envío mientras hay uno en curso se ignora.
 */
export function useSolicitudDeReserva(bienId: string) {
  const [fase, setFase] = useState<Fase>({ tipo: "libre" });
  const enCurso = useRef(false);
  const detenerActual = useRef<(() => void) | null>(null);

  const detener = useCallback(() => {
    detenerActual.current?.();
    detenerActual.current = null;
  }, []);

  // Al desmontar se cancela cualquier consulta o temporizador pendiente.
  useEffect(
    () => () => {
      detener();
      enCurso.current = false; // un envío en vuelo no debe iniciar consultas después
    },
    [detener],
  );

  const reiniciar = useCallback(() => {
    detener();
    enCurso.current = false;
    setFase({ tipo: "libre" });
  }, [detener]);

  const terminar = useCallback(
    (siguiente: Fase) => {
      detener();
      enCurso.current = false;
      setFase(siguiente);
    },
    [detener],
  );

  const consultarHastaResultado = useCallback(
    (reserva: ReservaApi, rango: Rango) => {
      const control = new AbortController();
      const reservaId = reserva.id;
      let consultas = 0;
      let temporizador: ReturnType<typeof setTimeout>;

      const limite = setTimeout(
        () => terminar({ tipo: "sin-respuesta", rango, reservaId }),
        LIMITE_DE_ESPERA_MS,
      );
      detenerActual.current = () => {
        control.abort();
        clearTimeout(temporizador);
        clearTimeout(limite);
      };

      const programar = () => {
        temporizador = setTimeout(consultar, INTERVALO_DE_CONSULTA_MS);
      };

      async function consultar() {
        const resultado = await consultarReserva(reservaId, control.signal);
        if (control.signal.aborted) return;

        if (resultado.ok) {
          const { estado, motivoResolucion } = resultado.reserva;
          if (estado !== "EN_COLA") {
            const rechazada = estado === "RECHAZADA" || estado === "CANCELADA";
            terminar(
              rechazada
                ? { tipo: "rechazada", rango, reservaId, motivo: motivoResolucion }
                : { tipo: "confirmada", rango, reservaId },
            );
            return;
          }
        } else if (resultado.sesion) {
          terminar({ tipo: "fallo", rango, causa: "sesion" });
          return;
        }
        // Un fallo suelto de red no corta la espera: se reintenta hasta el límite.
        consultas += 1;
        setFase({ tipo: "en-cola", rango, reservaId, consultas });
        programar();
      }

      programar();
    },
    [terminar],
  );

  const solicitar = useCallback(
    async (rango: Rango) => {
      if (enCurso.current) return;
      enCurso.current = true;
      setFase({ tipo: "enviando", rango });

      const resultado = await solicitarReserva(bienId, rango.inicio, rango.fin);
      if (!enCurso.current) return; // se reinició o se desmontó mientras se enviaba

      if (!resultado.ok) {
        terminar({ tipo: "fallo", rango, causa: resultado.causa, mensaje: resultado.mensaje });
        return;
      }

      const { reserva } = resultado;
      if (reserva.estado !== "EN_COLA") {
        // Si el procesador ya la resolvió, no hay nada que consultar.
        const rechazada = reserva.estado === "RECHAZADA" || reserva.estado === "CANCELADA";
        terminar(
          rechazada
            ? { tipo: "rechazada", rango, reservaId: reserva.id, motivo: reserva.motivoResolucion }
            : { tipo: "confirmada", rango, reservaId: reserva.id },
        );
        return;
      }
      setFase({ tipo: "en-cola", rango, reservaId: reserva.id, consultas: 0 });
      consultarHastaResultado(reserva, rango);
    },
    [bienId, consultarHastaResultado, terminar],
  );

  return { fase, solicitar, reiniciar };
}
