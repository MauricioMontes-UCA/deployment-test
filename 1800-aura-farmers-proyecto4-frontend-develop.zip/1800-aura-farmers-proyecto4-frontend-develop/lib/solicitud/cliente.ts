import { esReservaApi, type ReservaApi } from "./tipos";

/** Por qué no se pudo enviar la solicitud. */
export type CausaDeFallo =
  | "sesion" // 401
  | "verificacion" // 403 VERIFICACION_REQUERIDA
  | "conflicto" // 409
  | "validacion" // 422: `mensaje` trae el texto del servicio
  | "general"; // red, 5xx y cualquier otro

export type ResultadoDeEnvio =
  | { ok: true; reserva: ReservaApi }
  | { ok: false; causa: CausaDeFallo; mensaje?: string };

export type ResultadoDeConsulta =
  | { ok: true; reserva: ReservaApi }
  | { ok: false; sesion: boolean };

export const MENSAJE_CONFLICTO = "Esas fechas ya no están disponibles.";
export const MENSAJE_ERROR_DE_ENVIO = "No pudimos enviar tu solicitud. Intenta de nuevo.";

function mensajeDelServicio(cuerpo: unknown): string | undefined {
  const mensaje = (cuerpo as { message?: unknown } | null)?.message;
  if (typeof mensaje === "string" && mensaje.trim()) return mensaje;
  if (Array.isArray(mensaje)) {
    const textos = mensaje.filter((m): m is string => typeof m === "string");
    if (textos.length > 0) return textos.join(" ");
  }
  return undefined;
}

/** `POST /api/reservas` (puente de BE-6.1). Nunca lanza: devuelve la causa del fallo. */
export async function solicitarReserva(
  bienId: string,
  fechaInicio: string,
  fechaFin: string,
  senal?: AbortSignal,
): Promise<ResultadoDeEnvio> {
  try {
    const respuesta = await fetch("/api/reservas", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ bienId, fechaInicio, fechaFin }),
      cache: "no-store",
      signal: senal,
    });
    const cuerpo: unknown = await respuesta.json().catch(() => null);

    if (respuesta.ok) {
      return esReservaApi(cuerpo) ? { ok: true, reserva: cuerpo } : { ok: false, causa: "general" };
    }
    switch (respuesta.status) {
      case 401:
        return { ok: false, causa: "sesion" };
      case 403:
        return (cuerpo as { codigo?: unknown } | null)?.codigo === "VERIFICACION_REQUERIDA"
          ? { ok: false, causa: "verificacion" }
          : { ok: false, causa: "general" };
      case 409:
        return { ok: false, causa: "conflicto" };
      case 422: {
        const mensaje = mensajeDelServicio(cuerpo);
        return mensaje ? { ok: false, causa: "validacion", mensaje } : { ok: false, causa: "general" };
      }
      default:
        return { ok: false, causa: "general" };
    }
  } catch {
    return { ok: false, causa: "general" };
  }
}

/** `GET /api/reservas/:id` (puente de BE-6.3). Nunca lanza. */
export async function consultarReserva(reservaId: string, senal?: AbortSignal): Promise<ResultadoDeConsulta> {
  try {
    const respuesta = await fetch(`/api/reservas/${encodeURIComponent(reservaId)}`, {
      cache: "no-store",
      signal: senal,
    });
    if (!respuesta.ok) return { ok: false, sesion: respuesta.status === 401 };
    const cuerpo: unknown = await respuesta.json().catch(() => null);
    return esReservaApi(cuerpo) ? { ok: true, reserva: cuerpo } : { ok: false, sesion: false };
  } catch {
    return { ok: false, sesion: false };
  }
}
