/** Estados de una reserva en la API (`EstadoReserva` del backend). */
export type EstadoReserva =
  | "EN_COLA"
  | "CONFIRMADA"
  | "RECHAZADA"
  | "EN_CURSO"
  | "FINALIZADA"
  | "CANCELADA";

/** Respuesta de `POST /reservas` (202) y de `GET /reservas/:id` (BE-6.1 y BE-6.3). */
export type ReservaApi = {
  id: string;
  bienId: string;
  arrendatarioId: string;
  fechaInicio: string;
  fechaFin: string;
  estado: EstadoReserva;
  motivoResolucion: string | null;
  creadaEn: string;
  procesadaEn: string | null;
};

const ESTADOS: readonly string[] = [
  "EN_COLA",
  "CONFIRMADA",
  "RECHAZADA",
  "EN_CURSO",
  "FINALIZADA",
  "CANCELADA",
];

export function esReservaApi(valor: unknown): valor is ReservaApi {
  if (typeof valor !== "object" || valor === null) return false;
  const v = valor as Record<string, unknown>;
  return (
    typeof v.id === "string" &&
    typeof v.fechaInicio === "string" &&
    typeof v.fechaFin === "string" &&
    typeof v.estado === "string" &&
    ESTADOS.includes(v.estado)
  );
}

/** Datos del bien que necesita el panel (de `GET /bienes/:bienId`, público). */
export type BienParaSolicitud = {
  id: string;
  titulo: string;
  precio: number;
  unidadCobro: "HORA" | "DIA" | "NOCHE" | "SEMANA";
  deposito: number;
};
