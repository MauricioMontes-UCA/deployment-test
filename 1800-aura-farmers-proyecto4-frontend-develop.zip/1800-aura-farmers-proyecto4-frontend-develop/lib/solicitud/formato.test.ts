import { describe, expect, it } from "vitest";
import { alquilerEstimado, diasDelRango, formatearDia, formatearMoneda, textoDuracion, textoMotivo } from "./formato";

describe("formato de la solicitud", () => {
  it("formatea el día como DD/MM/AAAA", () => {
    expect(formatearDia("2026-11-24")).toBe("24/11/2026");
    expect(formatearDia("mañana")).toBe("mañana");
  });

  it("cuenta el día de inicio y el de fin", () => {
    expect(diasDelRango("2026-11-24", "2026-11-24")).toBe(1);
    expect(diasDelRango("2026-11-24", "2026-11-25")).toBe(2);
    expect(diasDelRango("2026-11-25", "2026-11-24")).toBeNull();
    expect(diasDelRango("x", "2026-11-24")).toBeNull();
    expect(textoDuracion(1)).toBe("1 día");
    expect(textoDuracion(2)).toBe("2 días");
  });

  it("estima el alquiler con las mismas unidades que cobra el backend", () => {
    expect(alquilerEstimado({ precio: 80, unidadCobro: "DIA" }, 2)).toBe(160);
    expect(alquilerEstimado({ precio: 300, unidadCobro: "SEMANA" }, 8)).toBe(600);
    expect(formatearMoneda(160)).toBe("$160.00");
  });

  it("por noche cobra las noches entre el primer y el último día, con mínimo una", () => {
    expect(alquilerEstimado({ precio: 80, unidadCobro: "NOCHE" }, 1)).toBe(80);
    expect(alquilerEstimado({ precio: 80, unidadCobro: "NOCHE" }, 2)).toBe(80);
    expect(alquilerEstimado({ precio: 80, unidadCobro: "NOCHE" }, 3)).toBe(160);
  });

  it("por hora cobra 24 horas por cada día", () => {
    expect(alquilerEstimado({ precio: 10, unidadCobro: "HORA" }, 1)).toBe(240);
    expect(alquilerEstimado({ precio: 10, unidadCobro: "HORA" }, 2)).toBe(480);
  });

  it("redondea a dos decimales como el backend", () => {
    expect(alquilerEstimado({ precio: 12.35, unidadCobro: "DIA" }, 3)).toBe(37.05);
    expect(alquilerEstimado({ precio: 0.1, unidadCobro: "HORA" }, 3)).toBe(7.2);
  });

  it("traduce el motivo de resolución", () => {
    expect(textoMotivo("FECHAS_NO_DISPONIBLES")).toBe("fechas no disponibles");
    expect(textoMotivo("VERIFICACION_REQUERIDA")).toBe("verificación requerida");
    expect(textoMotivo("OTRO_MOTIVO")).toBe("otro motivo");
    expect(textoMotivo(null)).toBeNull();
  });
});
