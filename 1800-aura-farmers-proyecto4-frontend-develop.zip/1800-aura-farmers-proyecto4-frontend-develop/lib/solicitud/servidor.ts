import { NextResponse, type NextRequest } from "next/server";
import { llamarApi } from "@/lib/api";
import { aplicarCambiosDeSesion, obtenerAccesoVigente } from "@/lib/sesion-vigente";
import type { BienParaSolicitud } from "./tipos";

export const ID_UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Puente de las rutas de `app/api/reservas`: renueva el access token si
 * venció (las rutas /api no pasan por el proxy), reenvía la llamada al
 * backend y devuelve su estado y cuerpo. Toda respuesta, errores incluidos,
 * lleva las cookies de sesión nuevas.
 */
export async function reenviarAApi(
  request: NextRequest,
  ruta: string,
  init: { method: "GET" | "POST"; cuerpo?: unknown },
) {
  const sesion = await obtenerAccesoVigente(request.cookies);
  const responder = (cuerpo: unknown, status: number) =>
    aplicarCambiosDeSesion(NextResponse.json(cuerpo, { status }), sesion);

  if (!sesion.acceso) return responder({ message: "No autenticado." }, 401);
  if (!process.env.API_URL) return responder({ message: "Falta API_URL." }, 500);

  const { status, datos } = await llamarApi(
    ruta,
    {
      method: init.method,
      body: init.cuerpo !== undefined ? JSON.stringify(init.cuerpo) : undefined,
    },
    sesion.acceso,
  );
  if (status === 0) return responder({ message: "No se pudo contactar a la API." }, 502);
  return responder(datos ?? {}, status);
}

/**
 * Datos del bien para el panel (`GET /bienes/:bienId`, público). `null` si no
 * existe; lanza si la API falla, para que la página muestre el error.
 */
export async function obtenerBien(bienId: string): Promise<BienParaSolicitud | null> {
  const { status, datos } = await llamarApi(`bienes/${bienId}`);
  if (status === 404) return null;
  if (status !== 200) throw new Error(`bienes/${bienId} respondió ${status}`);

  const bien = (datos ?? {}) as Partial<BienParaSolicitud>;
  if (typeof bien.titulo !== "string" || typeof bien.precio !== "number") {
    throw new Error("La respuesta de bienes/:id no tiene el formato esperado.");
  }
  return {
    id: bienId,
    titulo: bien.titulo,
    precio: bien.precio,
    unidadCobro: bien.unidadCobro ?? "DIA",
    deposito: typeof bien.deposito === "number" ? bien.deposito : 0,
  };
}
