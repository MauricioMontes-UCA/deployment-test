import type { BienParaSolicitud } from "./tipos";

const DIA = /^(\d{4})-(\d{2})-(\d{2})$/;
const MS_POR_DIA = 24 * 60 * 60 * 1000;

function aUtc(dia: string) {
  const partes = DIA.exec(dia);
  if (!partes) return null;
  return Date.UTC(Number(partes[1]), Number(partes[2]) - 1, Number(partes[3]));
}

/** «2026-11-24» → «24/11/2026». Si el formato no es válido, lo devuelve igual. */
export function formatearDia(dia: string) {
  const partes = DIA.exec(dia);
  return partes ? `${partes[3]}/${partes[2]}/${partes[1]}` : dia;
}

/** Días del rango, contando el de inicio y el de fin; null si no es un rango válido. */
export function diasDelRango(inicio: string, fin: string) {
  const desde = aUtc(inicio);
  const hasta = aUtc(fin);
  if (desde === null || hasta === null || hasta < desde) return null;
  return Math.round((hasta - desde) / MS_POR_DIA) + 1;
}

export function textoDuracion(dias: number) {
  return `${dias} ${dias === 1 ? "día" : "días"}`;
}

const MONEDA = new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" });

export function formatearMoneda(monto: number) {
  return MONEDA.format(monto);
}

/**
 * Unidades de cobro que el backend aplica a una reserva de `dias` días
 * (`unidadesACobrar` en `src/pagos/utils/calcular-cargos.ts`, decisión técnica
 * de BE-8.1). Si esa regla cambia allá, hay que cambiarla también aquí:
 * - DIA: un cobro por día.
 * - NOCHE: las noches entre el primer y el último día, mínimo una.
 * - SEMANA: semanas iniciadas, redondeando hacia arriba.
 * - HORA: 24 horas por día.
 */
export function unidadesACobrar(unidadCobro: BienParaSolicitud["unidadCobro"], dias: number) {
  switch (unidadCobro) {
    case "DIA":
      return dias;
    case "NOCHE":
      return Math.max(dias - 1, 1);
    case "SEMANA":
      return Math.ceil(dias / 7);
    case "HORA":
      return dias * 24;
  }
}

/**
 * Alquiler estimado: precio por las unidades que cobra el backend, redondeado a
 * dos decimales como él. Es una referencia para el panel: la API no calcula ni
 * guarda el monto en la solicitud; el cobro real lo calcula al generar el pago.
 */
export function alquilerEstimado(
  bien: Pick<BienParaSolicitud, "precio" | "unidadCobro">,
  dias: number,
) {
  return Math.round(bien.precio * unidadesACobrar(bien.unidadCobro, dias) * 100) / 100;
}

const MOTIVOS: Record<string, string> = {
  FECHAS_NO_DISPONIBLES: "fechas no disponibles",
  VERIFICACION_REQUERIDA: "verificación requerida",
  ERROR_DE_PROCESAMIENTO: "error de procesamiento",
};

/** Texto legible de `motivoResolucion` (código de la API en mayúsculas). */
export function textoMotivo(motivo: string | null) {
  if (!motivo) return null;
  return MOTIVOS[motivo] ?? motivo.toLowerCase().replaceAll("_", " ");
}
