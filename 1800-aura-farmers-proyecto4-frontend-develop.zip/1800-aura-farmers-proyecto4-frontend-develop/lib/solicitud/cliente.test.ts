import { afterEach, describe, expect, it, vi } from "vitest";
import { consultarReserva, solicitarReserva } from "./cliente";

const RESERVA = {
  id: "20000000-0000-4000-8000-000000000001",
  bienId: "10000000-0000-4000-8000-000000000001",
  arrendatarioId: "30000000-0000-4000-8000-000000000001",
  fechaInicio: "2026-12-10",
  fechaFin: "2026-12-12",
  estado: "EN_COLA",
  motivoResolucion: null,
  creadaEn: "2026-11-19T10:00:00.000Z",
  procesadaEn: null,
};

function responder(cuerpo: unknown, estado: number) {
  vi.stubGlobal("fetch", vi.fn(() => Promise.resolve(new Response(JSON.stringify(cuerpo), { status: estado }))));
}

afterEach(() => vi.unstubAllGlobals());

describe("solicitarReserva", () => {
  const enviar = () => solicitarReserva(RESERVA.bienId, "2026-12-10", "2026-12-12");

  it("envía el rango a /api/reservas y devuelve la reserva con 202", async () => {
    responder(RESERVA, 202);
    expect(await enviar()).toEqual({ ok: true, reserva: RESERVA });

    const [url, opciones] = vi.mocked(fetch).mock.calls[0];
    expect(url).toBe("/api/reservas");
    expect(opciones?.method).toBe("POST");
    expect(JSON.parse(opciones?.body as string)).toEqual({
      bienId: RESERVA.bienId,
      fechaInicio: "2026-12-10",
      fechaFin: "2026-12-12",
    });
  });

  it("un 202 con un cuerpo inesperado es un fallo general", async () => {
    responder({ algo: "raro" }, 202);
    expect(await enviar()).toEqual({ ok: false, causa: "general" });
  });

  it.each([
    [401, { message: "Unauthorized" }, { ok: false, causa: "sesion" }],
    [403, { codigo: "VERIFICACION_REQUERIDA", mensaje: "x" }, { ok: false, causa: "verificacion" }],
    [403, { message: "Forbidden resource" }, { ok: false, causa: "general" }],
    [409, { message: "Las fechas se solapan" }, { ok: false, causa: "conflicto" }],
    [422, { message: "No puedes reservar un bien propio." }, { ok: false, causa: "validacion", mensaje: "No puedes reservar un bien propio." }],
    [422, { message: ["a", "b"] }, { ok: false, causa: "validacion", mensaje: "a b" }],
    [422, {}, { ok: false, causa: "general" }],
    [500, {}, { ok: false, causa: "general" }],
    [502, { message: "No se pudo contactar a la API." }, { ok: false, causa: "general" }],
  ])("traduce el estado %i a la causa del fallo", async (estado, cuerpo, esperado) => {
    responder(cuerpo, estado);
    expect(await enviar()).toEqual(esperado);
  });

  it("un error de red es un fallo general y no lanza", async () => {
    vi.stubGlobal("fetch", vi.fn(() => Promise.reject(new TypeError("network"))));
    expect(await enviar()).toEqual({ ok: false, causa: "general" });
  });
});

describe("consultarReserva", () => {
  it("devuelve la reserva", async () => {
    responder({ ...RESERVA, estado: "CONFIRMADA" }, 200);
    const resultado = await consultarReserva(RESERVA.id);
    expect(resultado).toMatchObject({ ok: true, reserva: { estado: "CONFIRMADA" } });
    expect(vi.mocked(fetch).mock.calls[0][0]).toBe(`/api/reservas/${RESERVA.id}`);
  });

  it("distingue la sesión vencida de otros fallos", async () => {
    responder({}, 401);
    expect(await consultarReserva(RESERVA.id)).toEqual({ ok: false, sesion: true });
    responder({}, 500);
    expect(await consultarReserva(RESERVA.id)).toEqual({ ok: false, sesion: false });
    vi.stubGlobal("fetch", vi.fn(() => Promise.reject(new TypeError("network"))));
    expect(await consultarReserva(RESERVA.id)).toEqual({ ok: false, sesion: false });
  });
});
