import type { EstadoDia } from "@/components/ui/dia-de-calendario";

/** Rango inclusivo de días completos, en formato AAAA-MM-DD. */
export type RangoFechas = {
  fechaInicio: string;
  fechaFin: string;
};

/** Respuesta de `GET /bienes/:bienId/disponibilidad` (BE-5.1). */
export type Disponibilidad = {
  bienId: string;
  reservados: RangoFechas[];
  bloqueados: RangoFechas[];
};

/** Ventana de consulta del calendario, en meses (el máximo que acepta la API). */
export const MESES_DE_VENTANA = 12;

/** Zona horaria de los bienes: «hoy» es el día de El Salvador, no el del navegador. */
export const ZONA_HORARIA = "America/El_Salvador";

export const MENSAJE_RANGO_NO_DISPONIBLE = "El rango incluye fechas no disponibles.";

const FORMATO_DIA = /^\d{4}-\d{2}-\d{2}$/;

/** AAAA-MM-DD del día de calendario de `ahora` en la zona horaria de los bienes. */
export function hoyEnElSalvador(ahora: Date = new Date()): string {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: ZONA_HORARIA,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(ahora);
}

/** Convierte AAAA-MM-DD en año, mes (0–11) y día. */
function partes(fecha: string): { anio: number; mes: number; dia: number } {
  const [anio, mes, dia] = fecha.split("-").map(Number);
  return { anio, mes: mes - 1, dia };
}

function aISO(anio: number, mes: number, dia: number): string {
  return new Date(Date.UTC(anio, mes, dia)).toISOString().slice(0, 10);
}

/**
 * Último día de la ventana de `meses` meses que empieza en `desde`, inclusive.
 * Igual que el backend: desde 2026-11-18, 12 meses terminan el 2027-11-17.
 */
export function ultimoDiaDeVentana(desde: string, meses: number = MESES_DE_VENTANA): string {
  const { anio, mes, dia } = partes(desde);
  return aISO(anio, mes + meses, dia - 1);
}

/** Primer día del mes que está `desplazamiento` meses después del de `fecha`. */
export function mesDesplazado(fecha: string, desplazamiento: number): { anio: number; mes: number } {
  const { anio, mes } = partes(fecha);
  const total = anio * 12 + mes + desplazamiento;
  return { anio: Math.floor(total / 12), mes: ((total % 12) + 12) % 12 };
}

/** Meses de calendario que separan el mes de `desde` del de `hasta`. */
export function mesesEntre(desde: string, hasta: string): number {
  const a = partes(desde);
  const b = partes(hasta);
  return (b.anio - a.anio) * 12 + (b.mes - a.mes);
}

/** Valida que `valor` sea una fecha AAAA-MM-DD real (rechaza «2026-02-30»). */
export function esFechaValida(valor: unknown): valor is string {
  if (typeof valor !== "string" || !FORMATO_DIA.test(valor)) return false;
  const { anio, mes, dia } = partes(valor);
  return aISO(anio, mes, dia) === valor;
}

function estaEnAlgunRango(fecha: string, rangos: RangoFechas[]): boolean {
  return rangos.some((rango) => fecha >= rango.fechaInicio && fecha <= rango.fechaFin);
}

/** Estados de un día que no se pueden elegir. */
export function esSeleccionable(estado: EstadoDia): boolean {
  return estado !== "reservado" && estado !== "bloqueado" && estado !== "pasado";
}

type ContextoDelDia = {
  hoy: string;
  /** Último día que cubre la consulta; después de él no hay datos. */
  ultimoDia: string;
  disponibilidad: Disponibilidad;
  inicio?: string | null;
  fin?: string | null;
};

/**
 * Estado con el que se pinta un día. Los días pasados y los que quedan fuera
 * de la ventana de 12 meses no son seleccionables; entre reservado y
 * bloqueado gana reservado.
 */
export function estadoDelDia(fecha: string, contexto: ContextoDelDia): EstadoDia {
  const { hoy, ultimoDia, disponibilidad, inicio, fin } = contexto;
  if (fecha < hoy || fecha > ultimoDia) return "pasado";
  if (estaEnAlgunRango(fecha, disponibilidad.reservados)) return "reservado";
  if (estaEnAlgunRango(fecha, disponibilidad.bloqueados)) return "bloqueado";
  if (fecha === inicio || fecha === fin) return "seleccionado";
  if (inicio && fin && fecha > inicio && fecha < fin) return "en-rango";
  if (fecha === hoy) return "hoy";
  return "disponible";
}

/** Todos los días entre `inicio` y `fin`, ambos incluidos. */
export function diasDelRango(inicio: string, fin: string): string[] {
  const dias: string[] = [];
  const { anio, mes, dia } = partes(inicio);
  for (let i = 0; ; i += 1) {
    const actual = aISO(anio, mes, dia + i);
    if (actual > fin) return dias;
    dias.push(actual);
  }
}

/**
 * Un rango solo es válido si todos sus días se pueden elegir. Se calcula sin
 * contar la selección, que no cambia si un día es reservado o bloqueado.
 */
export function rangoEsValido(
  inicio: string,
  fin: string,
  contexto: Omit<ContextoDelDia, "inicio" | "fin">,
): boolean {
  if (fin < inicio) return false;
  return diasDelRango(inicio, fin).every((dia) => esSeleccionable(estadoDelDia(dia, contexto)));
}

/** Valida la forma de la respuesta de la API antes de usarla. */
export function esDisponibilidad(valor: unknown): valor is Disponibilidad {
  if (typeof valor !== "object" || valor === null) return false;
  const { bienId, reservados, bloqueados } = valor as Record<string, unknown>;
  const sonRangos = (lista: unknown) =>
    Array.isArray(lista) &&
    lista.every(
      (rango) =>
        typeof rango === "object" &&
        rango !== null &&
        esFechaValida((rango as RangoFechas).fechaInicio) &&
        esFechaValida((rango as RangoFechas).fechaFin),
    );
  return typeof bienId === "string" && sonRangos(reservados) && sonRangos(bloqueados);
}
