import { obtenerApiUrl } from "./config";
import type { Rol } from "./jwt";

/**
 * Llamadas a los endpoints de autenticación del backend. No tocan cookies:
 * devuelven el resultado por código de estado para que cada llamador (server
 * action o proxy) decida qué hacer.
 */

/** `UserResponseDto` del backend. */
export type UsuarioApi = {
  id: string;
  nombreUsuario: string;
  email: string;
  rol: Rol;
  isActive: boolean;
  createdAt: string;
};

/** `AuthResponseDto` del backend (login y refresh). */
export type SesionApi = {
  accessToken: string;
  refreshToken: string;
  /** Vigencia del access token, en segundos. */
  expiresIn: number;
  user: UsuarioApi;
};

export type DatosRegistro = {
  nombreUsuario: string;
  email: string;
  password: string;
  rol: Rol;
};

/** Respuesta de la API. `status` 0 significa que no hubo respuesta (red caída). */
export type RespuestaApi<T> =
  | { ok: true; status: number; datos: T }
  | { ok: false; status: number; mensajes: string[] };

/**
 * Mensajes de un error del backend (`{ message, error, statusCode }`). El
 * ValidationPipe devuelve `message` como arreglo; las demás excepciones, como
 * texto.
 */
export function mensajesDe(cuerpo: unknown): string[] {
  const mensaje = (cuerpo as { message?: unknown } | null)?.message;
  if (Array.isArray(mensaje)) return mensaje.filter((m): m is string => typeof m === "string");
  return typeof mensaje === "string" ? [mensaje] : [];
}

/**
 * Tiempo máximo de espera al backend. El proxy renueva el token antes de cada
 * navegación: sin límite, un backend colgado dejaría esperando cada página.
 */
export const TIEMPO_LIMITE_MS = 5_000;

async function llamar<T>(ruta: string, cuerpo: unknown): Promise<RespuestaApi<T>> {
  let respuesta: Response;
  try {
    respuesta = await fetch(new URL(ruta, obtenerApiUrl()), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(cuerpo),
      cache: "no-store",
      signal: AbortSignal.timeout(TIEMPO_LIMITE_MS),
    });
  } catch {
    // Red caída o tiempo agotado: se trata como «sin respuesta».
    return { ok: false, status: 0, mensajes: [] };
  }

  const texto = await respuesta.text();
  let json: unknown = null;
  try {
    json = texto ? JSON.parse(texto) : null;
  } catch {
    json = null;
  }

  return respuesta.ok
    ? { ok: true, status: respuesta.status, datos: json as T }
    : { ok: false, status: respuesta.status, mensajes: mensajesDe(json) };
}

/** POST /users. El cuerpo lleva solo los cuatro campos del contrato. */
export function registrarUsuarioApi({ nombreUsuario, email, password, rol }: DatosRegistro) {
  return llamar<UsuarioApi>("users", { nombreUsuario, email, password, rol });
}

/** POST /auth/login. */
export function iniciarSesionApi(email: string, password: string) {
  return llamar<SesionApi>("auth/login", { email, password });
}

/** POST /auth/refresh. Rota el refresh token: el anterior queda revocado. */
export function renovarSesionApi(refreshToken: string) {
  return llamar<SesionApi>("auth/refresh", { refreshToken });
}

/** POST /auth/logout. Es idempotente: responde 204 aunque el token ya no sirva. */
export function cerrarSesionApi(refreshToken: string) {
  return llamar<null>("auth/logout", { refreshToken });
}
