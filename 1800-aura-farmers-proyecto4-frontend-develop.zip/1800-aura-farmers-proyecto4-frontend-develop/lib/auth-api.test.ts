import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import {
  cerrarSesionApi,
  iniciarSesionApi,
  registrarUsuarioApi,
  renovarSesionApi,
} from "./auth-api";

const fetchFalso = vi.fn();

function responder(status: number, cuerpo?: unknown) {
  fetchFalso.mockResolvedValueOnce(
    new Response(cuerpo === undefined ? null : JSON.stringify(cuerpo), { status }),
  );
}

beforeEach(() => {
  vi.stubEnv("API_URL", "http://api.test/api/v1");
  vi.stubGlobal("fetch", fetchFalso);
});

afterEach(() => {
  vi.unstubAllEnvs();
  vi.unstubAllGlobals();
  fetchFalso.mockReset();
});

const datos = {
  nombreUsuario: "ana_m",
  email: "ana@example.com",
  password: "Str0ngPass",
  rol: "ARRENDADOR" as const,
};

describe("registrarUsuarioApi", () => {
  it("hace POST a /api/v1/users con solo los cuatro campos del contrato", async () => {
    responder(201, { id: "1", ...datos });
    await registrarUsuarioApi({ ...datos, extra: "no va" } as typeof datos);

    const [url, init] = fetchFalso.mock.calls[0];
    expect(String(url)).toBe("http://api.test/api/v1/users");
    expect(init.method).toBe("POST");
    expect(JSON.parse(init.body)).toEqual(datos);
  });

  it("devuelve los mensajes de un 400 como arreglo", async () => {
    responder(400, { message: ["El rol debe ser uno de: ARRENDADOR, ARRENDATARIO."], statusCode: 400 });
    expect(await registrarUsuarioApi(datos)).toEqual({
      ok: false,
      status: 400,
      mensajes: ["El rol debe ser uno de: ARRENDADOR, ARRENDATARIO."],
    });
  });

  it("devuelve el mensaje de un 409", async () => {
    responder(409, { message: "El email ya está registrado.", statusCode: 409 });
    expect(await registrarUsuarioApi(datos)).toMatchObject({
      ok: false,
      status: 409,
      mensajes: ["El email ya está registrado."],
    });
  });

  it("devuelve status 0 si no hay respuesta", async () => {
    fetchFalso.mockRejectedValueOnce(new TypeError("fetch failed"));
    expect(await registrarUsuarioApi(datos)).toEqual({ ok: false, status: 0, mensajes: [] });
  });

  it("tolera un 500 sin cuerpo JSON", async () => {
    fetchFalso.mockResolvedValueOnce(new Response("Internal Server Error", { status: 500 }));
    expect(await registrarUsuarioApi(datos)).toEqual({ ok: false, status: 500, mensajes: [] });
  });
});

describe("login, refresh y logout", () => {
  it("envían los cuerpos del contrato a sus rutas", async () => {
    responder(200, { accessToken: "a", refreshToken: "r", expiresIn: 900 });
    responder(200, { accessToken: "a2", refreshToken: "r2", expiresIn: 900 });
    responder(204);

    const login = await iniciarSesionApi("ana@example.com", "Str0ngPass");
    await renovarSesionApi("r");
    const logout = await cerrarSesionApi("r2");

    const llamadas = fetchFalso.mock.calls.map(([url, init]) => [String(url), JSON.parse(init.body)]);
    expect(llamadas).toEqual([
      ["http://api.test/api/v1/auth/login", { email: "ana@example.com", password: "Str0ngPass" }],
      ["http://api.test/api/v1/auth/refresh", { refreshToken: "r" }],
      ["http://api.test/api/v1/auth/logout", { refreshToken: "r2" }],
    ]);
    expect(login).toMatchObject({ ok: true, datos: { accessToken: "a" } });
    expect(logout).toEqual({ ok: true, status: 204, datos: null });
  });

  it("devuelve el 401 del login con el mensaje del backend", async () => {
    responder(401, { message: "Credenciales inválidas.", statusCode: 401 });
    expect(await iniciarSesionApi("ana@example.com", "mala")).toMatchObject({
      ok: false,
      status: 401,
      mensajes: ["Credenciales inválidas."],
    });
  });
});

describe("tiempo límite", () => {
  it("pide al fetch un límite de 5 s y, si se agota, responde como sin respuesta", async () => {
    // AbortSignal.timeout usa un temporizador nativo: se reemplaza por una
    // señal que la prueba aborta a mano.
    const controlador = new AbortController();
    const espia = vi.spyOn(AbortSignal, "timeout").mockReturnValue(controlador.signal);
    fetchFalso.mockImplementationOnce(
      (_url: unknown, init: RequestInit) =>
        new Promise((_resolver, rechazar) =>
          init.signal?.addEventListener("abort", () => rechazar(new DOMException("timeout", "TimeoutError"))),
        ),
    );
    try {
      const resultado = renovarSesionApi("r");
      expect(espia).toHaveBeenCalledWith(5_000);
      controlador.abort();
      expect(await resultado).toEqual({ ok: false, status: 0, mensajes: [] });
    } finally {
      espia.mockRestore();
    }
  });
});
