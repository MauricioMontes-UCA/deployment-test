import { renovarSesionApi, type RespuestaApi, type SesionApi } from "./auth-api";
import {
  COOKIE_ACCESO,
  COOKIE_REFRESH,
  borrarCookiesSesion,
  escribirSesion,
} from "./cookies-sesion";
import { accesoVigente } from "./jwt";

/**
 * Renovación del access token compartida por el proxy y las rutas /api.
 *
 * El backend trata un refresh token usado dos veces como robado y cierra todas
 * las sesiones del usuario. Por eso no basta con renovar en un solo lugar:
 * dos pestañas, un `router.refresh()` o una server action durante una
 * navegación pueden llegar a la vez con el mismo token vencido. Y una petición
 * que llega justo después de la renovación todavía trae la cookie vieja,
 * porque el navegador aún no aplicó la nueva.
 *
 * - Si ya hay una renovación en curso para ese refresh token, se espera la
 *   misma promesa en vez de lanzar otra.
 * - Una renovación exitosa se recuerda 30 s: quien llegue con el token viejo
 *   en esa ventana recibe el mismo par nuevo, sin llamar al backend.
 *
 * Las claves son el SHA-256 del token, nunca el token en claro. El estado vive
 * en la memoria del proceso: con varias instancias de Next detrás de un
 * balanceador haría falta un almacén compartido (o un margen de gracia en el
 * backend).
 */

const VENTANA_MS = 30_000;

type Renovacion = RespuestaApi<SesionApi>;

const enCurso = new Map<string, Promise<Renovacion>>();
const recientes = new Map<string, { sesion: SesionApi; emitida: number }>();

async function huella(token: string): Promise<string> {
  const resumen = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(token));
  return Array.from(new Uint8Array(resumen), (byte) => byte.toString(16).padStart(2, "0")).join("");
}

function olvidarVencidas(ahora: number) {
  for (const [clave, { emitida }] of recientes) {
    if (ahora - emitida >= VENTANA_MS) recientes.delete(clave);
  }
}

/** El mismo par, con la vigencia que le queda al access token. */
function conVigenciaRestante(sesion: SesionApi, emitida: number, ahora: number): SesionApi {
  const transcurridos = Math.floor((ahora - emitida) / 1000);
  return { ...sesion, expiresIn: Math.max(1, sesion.expiresIn - transcurridos) };
}

/** Renueva la sesión con /auth/refresh una sola vez por refresh token. */
export async function renovarSesionCompartida(refresh: string): Promise<Renovacion> {
  const clave = await huella(refresh);
  const ahora = Date.now();
  olvidarVencidas(ahora);

  const reciente = recientes.get(clave);
  if (reciente) {
    return { ok: true, status: 200, datos: conVigenciaRestante(reciente.sesion, reciente.emitida, ahora) };
  }

  let pendiente = enCurso.get(clave);
  if (!pendiente) {
    pendiente = renovarSesionApi(refresh)
      .then((resultado) => {
        if (resultado.ok) recientes.set(clave, { sesion: resultado.datos, emitida: Date.now() });
        return resultado;
      })
      .finally(() => enCurso.delete(clave));
    enCurso.set(clave, pendiente);
  }
  return pendiente;
}

/** Olvida las renovaciones guardadas. Solo para pruebas. */
export function reiniciarRenovaciones() {
  enCurso.clear();
  recientes.clear();
}

export type EstadoAcceso = {
  /** Access token vigente, o `undefined` si no hay sesión utilizable. */
  acceso: string | undefined;
  /** Par nuevo si hubo que renovar: hay que escribirlo en la respuesta. */
  sesionNueva: SesionApi | null;
  /** El backend rechazó el refresh token (401): hay que borrar las cookies. */
  refreshRechazado: boolean;
};

type LectorDeCookies = { get(nombre: string): { value: string } | undefined };

/**
 * Devuelve un access token vigente: el de la cookie, o uno nuevo si venció y
 * hay refresh token. Si el backend no responde, no borra nada: se reintenta en
 * la siguiente petición.
 */
export async function obtenerAccesoVigente(cookies: LectorDeCookies): Promise<EstadoAcceso> {
  const acceso = cookies.get(COOKIE_ACCESO)?.value;
  const refresh = cookies.get(COOKIE_REFRESH)?.value;

  if (accesoVigente(acceso)) return { acceso, sesionNueva: null, refreshRechazado: false };
  if (!refresh) return { acceso: undefined, sesionNueva: null, refreshRechazado: false };

  const resultado = await renovarSesionCompartida(refresh);
  if (resultado.ok) {
    return { acceso: resultado.datos.accessToken, sesionNueva: resultado.datos, refreshRechazado: false };
  }
  return { acceso: undefined, sesionNueva: null, refreshRechazado: resultado.status === 401 };
}

type EscritorDeCookies = Parameters<typeof escribirSesion>[0];

/** Escribe en la respuesta las cookies nuevas o las borra, según el estado. */
export function aplicarCambiosDeSesion<T extends { cookies: EscritorDeCookies }>(
  respuesta: T,
  estado: EstadoAcceso,
): T {
  if (estado.sesionNueva) escribirSesion(respuesta.cookies, estado.sesionNueva);
  else if (estado.refreshRechazado) borrarCookiesSesion(respuesta.cookies);
  return respuesta;
}
