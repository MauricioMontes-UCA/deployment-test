import { NextResponse, type NextRequest } from "next/server";
import { llamarApi } from "@/lib/api";
import { aplicarCambiosDeSesion, obtenerAccesoVigente } from "@/lib/sesion-vigente";

/**
 * Puente de las rutas `app/api/**` hacia el backend (`API_URL` ya incluye
 * `/api/v1`). Estas rutas no pasan por el proxy: renuevan el access token aquí
 * (renovación compartida de `lib/sesion-vigente.ts`) y cada respuesta, errores
 * incluidos, lleva las cookies nuevas o las borra, igual que
 * `app/api/bienes/[bienId]/disponibilidad/route.ts`. La llamada usa `llamarApi`
 * (tiempo límite de 5 s): si el backend no responde, devuelve 502. Un 204 del
 * backend se devuelve sin cuerpo.
 */
export async function llamarBackend(
  request: NextRequest,
  ruta: string,
  init: { method?: string; body?: unknown } = {},
) {
  const sesion = await obtenerAccesoVigente(request.cookies);
  const conSesion = (respuesta: NextResponse) => aplicarCambiosDeSesion(respuesta, sesion);

  const token = sesion.acceso;
  if (!token) {
    return conSesion(NextResponse.json({ message: "No autenticado." }, { status: 401 }));
  }

  const apiUrl = process.env.API_URL;
  if (!apiUrl) {
    return conSesion(NextResponse.json({ message: "Falta API_URL." }, { status: 500 }));
  }

  const { status, datos } = await llamarApi(
    ruta,
    {
      method: init.method ?? "GET",
      body: init.body !== undefined ? JSON.stringify(init.body) : undefined,
    },
    token,
  );
  if (status === 0) {
    return conSesion(
      NextResponse.json({ message: "No se pudo contactar a la API." }, { status: 502 }),
    );
  }
  // 204 no admite cuerpo (`NextResponse.json` lanzaría): se responde vacío.
  if (status === 204) return conSesion(new NextResponse(null, { status }));
  return conSesion(NextResponse.json(datos ?? {}, { status }));
}
