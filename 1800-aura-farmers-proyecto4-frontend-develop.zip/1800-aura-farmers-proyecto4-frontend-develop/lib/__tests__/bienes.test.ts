// @vitest-environment node
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import {
  formatearDeposito,
  formatearPrecio,
  obtenerBienDetalle,
  obtenerBienesRecientes,
} from "@/lib/bienes";

const API = "http://api.test/api/v1";
const fetchSimulado = vi.fn();

beforeEach(() => {
  vi.stubEnv("API_URL", API);
  fetchSimulado.mockReset();
  vi.stubGlobal("fetch", fetchSimulado);
});

afterEach(() => {
  vi.unstubAllEnvs();
  vi.unstubAllGlobals();
});

describe("formatearPrecio", () => {
  it.each([
    [80, "DIA", "$80.00 / día"],
    [45.5, "NOCHE", "$45.50 / noche"],
    [1250, "SEMANA", "$1,250.00 / semana"],
    [0, "HORA", "$0.00 / hora"],
  ] as const)("%s por %s es «%s»", (precio, unidad, texto) => {
    expect(formatearPrecio(precio, unidad)).toBe(texto);
  });
});

describe("obtenerBienesRecientes", () => {
  it("pide GET /bienes sin término ni token y devuelve los resultados", async () => {
    const resultados = [
      {
        id: "1",
        titulo: "Cámara 360",
        precio: 40,
        unidadCobro: "DIA",
        departamento: "San Salvador",
        municipio: "San Salvador",
        fotoPrincipal: null,
      },
    ];
    fetchSimulado.mockResolvedValue(
      new Response(JSON.stringify({ pagina: 1, total: 1, hayMas: false, tamanoPagina: 4, resultados })),
    );

    expect(await obtenerBienesRecientes()).toEqual(resultados);
    const [destino, opciones] = fetchSimulado.mock.calls[0];
    expect(String(destino)).toBe(`${API}/bienes?tamano=4`);
    expect(opciones.headers).toBeUndefined();
    expect(opciones.next).toEqual({ revalidate: 60 });
    expect(opciones.cache).toBeUndefined();
  });

  it("lanza si la API responde con error", async () => {
    fetchSimulado.mockResolvedValue(new Response("{}", { status: 500 }));
    await expect(obtenerBienesRecientes()).rejects.toThrow("GET /bienes respondió 500");
  });
});

describe("formatearDeposito", () => {
  it("muestra el monto con dos decimales", () => {
    expect(formatearDeposito(150)).toBe("$150.00");
    expect(formatearDeposito(25.5)).toBe("$25.50");
  });

  it("con depósito 0 dice «Sin depósito de garantía»", () => {
    expect(formatearDeposito(0)).toBe("Sin depósito de garantía");
  });
});

describe("obtenerBienDetalle", () => {
  const ID = "7c9e6679-7425-40de-944b-e07fc1f90ae7";

  it("pide GET /bienes/:bienId sin token ni caché y devuelve el bien", async () => {
    const bien = { id: ID, titulo: "Salón" };
    fetchSimulado.mockResolvedValue(new Response(JSON.stringify(bien)));

    expect(await obtenerBienDetalle(ID)).toEqual(bien);
    const [destino, opciones] = fetchSimulado.mock.calls[0];
    expect(String(destino)).toBe(`${API}/bienes/${ID}`);
    expect(opciones.headers).toBeUndefined();
    expect(opciones.cache).toBe("no-store");
  });

  it.each([404, 400])("con %s devuelve null", async (estado) => {
    fetchSimulado.mockResolvedValue(new Response("{}", { status: estado }));
    expect(await obtenerBienDetalle(ID)).toBeNull();
  });

  it("con un id que no es uuid devuelve null sin llamar a la API", async () => {
    expect(await obtenerBienDetalle("no-es-un-uuid")).toBeNull();
    expect(await obtenerBienDetalle("../auth/me")).toBeNull();
    expect(fetchSimulado).not.toHaveBeenCalled();
  });

  it("lanza si la API responde con otro error", async () => {
    fetchSimulado.mockResolvedValue(new Response("{}", { status: 500 }));
    await expect(obtenerBienDetalle(ID)).rejects.toThrow(`GET /bienes/${ID} respondió 500`);
  });
});
