import { describe, expect, it } from "vitest";
import {
  LIMITE_MENSAJE,
  MENSAJE_ERROR_ENVIO,
  MENSAJE_LONGITUD_INVALIDA,
  contarCaracteresMensaje,
  formatearFechaHora,
  leerHistorial,
  leerMensaje,
  validarMensaje,
} from "../mensajes";

const mensajeApi = (cambios: Record<string, unknown> = {}) => ({
  id: "m1",
  conversacionId: "c1",
  remitente: { id: "u1", nombreUsuario: "ana_m" },
  contenido: "Hola",
  creadoEn: "2026-11-05T16:32:00.000Z",
  ...cambios,
});

describe("textos fijos", () => {
  it("son los de FE-13.1 y BE-13.1", () => {
    expect(LIMITE_MENSAJE).toBe(1000);
    expect(MENSAJE_LONGITUD_INVALIDA).toBe("El mensaje debe contener entre 1 y 1000 caracteres");
    expect(MENSAJE_ERROR_ENVIO).toBe("No se pudo enviar el mensaje");
  });
});

describe("contarCaracteresMensaje", () => {
  it("cuenta por punto de código, como el backend", () => {
    expect(contarCaracteresMensaje("")).toBe(0);
    expect(contarCaracteresMensaje("ñandú")).toBe(5);
    expect(contarCaracteresMensaje("😀")).toBe(1);
    expect("😀".length).toBe(2);
    expect(contarCaracteresMensaje("Hola 👋🏽")).toBe(7); // 👋 + modificador de tono
  });
});

describe("validarMensaje", () => {
  it("rechaza el vacío", () => {
    expect(validarMensaje("")).toBe(MENSAJE_LONGITUD_INVALIDA);
  });

  it("rechaza solo espacios, tabulaciones y saltos de línea", () => {
    expect(validarMensaje("   ")).toBe(MENSAJE_LONGITUD_INVALIDA);
    expect(validarMensaje("\n\t  \n")).toBe(MENSAJE_LONGITUD_INVALIDA);
  });

  it("acepta 1 y 1000 caracteres, y rechaza 1001", () => {
    expect(validarMensaje("a")).toBeNull();
    expect(validarMensaje("a".repeat(1000))).toBeNull();
    expect(validarMensaje("a".repeat(1001))).toBe(MENSAJE_LONGITUD_INVALIDA);
  });

  it("1000 emojis caben (2000 unidades UTF-16) y 1001 no", () => {
    expect(validarMensaje("😀".repeat(1000))).toBeNull();
    expect(validarMensaje("😀".repeat(1001))).toBe(MENSAJE_LONGITUD_INVALIDA);
  });

  it("los espacios alrededor cuentan para el límite: no se recortan", () => {
    expect(validarMensaje(` ${"a".repeat(999)}`)).toBeNull();
    expect(validarMensaje(` ${"a".repeat(1000)}`)).toBe(MENSAJE_LONGITUD_INVALIDA);
  });
});

describe("leerMensaje", () => {
  it("lee un mensaje válido", () => {
    expect(leerMensaje(mensajeApi())).toEqual({
      id: "m1",
      remitente: { id: "u1", nombreUsuario: "ana_m" },
      contenido: "Hola",
      creadoEn: "2026-11-05T16:32:00.000Z",
    });
  });

  it.each([
    ["no es objeto", null],
    ["sin remitente", mensajeApi({ remitente: null })],
    ["id numérico", mensajeApi({ id: 1 })],
    ["contenido nulo", mensajeApi({ contenido: null })],
    ["fecha inválida", mensajeApi({ creadoEn: "ayer" })],
    ["remitente sin nombre", mensajeApi({ remitente: { id: "u1" } })],
  ])("%s → null", (_caso, valor) => {
    expect(leerMensaje(valor)).toBeNull();
  });
});

describe("leerHistorial", () => {
  it("historial vacío", () => {
    expect(leerHistorial({ conversacionId: "c1", orden: "asc", mensajes: [] })).toEqual([]);
  });

  it("ordena cronológicamente aunque lleguen desordenados, estable en empates", () => {
    const historial = leerHistorial({
      mensajes: [
        mensajeApi({ id: "c", creadoEn: "2026-11-05T16:45:00.000Z" }),
        mensajeApi({ id: "a", creadoEn: "2026-11-05T16:32:00.000Z" }),
        mensajeApi({ id: "b1", creadoEn: "2026-11-05T16:40:00.000Z" }),
        mensajeApi({ id: "b2", creadoEn: "2026-11-05T16:40:00.000Z" }),
      ],
    });
    expect(historial?.map((m) => m.id)).toEqual(["a", "b1", "b2", "c"]);
  });

  it("respuesta sin lista o con un mensaje ilegible → null (no se muestra un historial incompleto)", () => {
    expect(leerHistorial(null)).toBeNull();
    expect(leerHistorial({ mensajes: "x" })).toBeNull();
    expect(leerHistorial({ mensajes: [mensajeApi(), { id: "roto" }] })).toBeNull();
  });
});

describe("formatearFechaHora", () => {
  it("usa dd/mm/aaaa hh:mm en hora de El Salvador (UTC-6)", () => {
    expect(formatearFechaHora("2026-11-05T16:32:00.000Z")).toBe("05/11/2026 10:32");
  });

  it("cambia de día según la hora local, no la UTC, y usa 24 horas", () => {
    expect(formatearFechaHora("2026-11-06T03:15:00.000Z")).toBe("05/11/2026 21:15");
    expect(formatearFechaHora("2026-11-06T06:05:00.000Z")).toBe("06/11/2026 00:05");
  });
});
