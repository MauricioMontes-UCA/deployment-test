import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import {
  ErrorDeBusqueda,
  buscarBienes,
  chipsDeFiltros,
  criteriosDesdeUrl,
  esPaginaDeBienes,
  hayFiltros,
  sinFiltros,
  urlDeBusqueda,
} from "@/lib/busqueda";

describe("urlDeBusqueda", () => {
  it("sin criterios abre /buscar sin parámetros", () => {
    expect(urlDeBusqueda({})).toBe("/buscar");
    expect(urlDeBusqueda({ q: "   ", departamento: "", municipio: "" })).toBe("/buscar");
  });

  it("lleva texto, departamento y municipio en la URL", () => {
    expect(
      urlDeBusqueda({ q: " salón ", departamento: "La Libertad", municipio: "Santa Tecla" }),
    ).toBe("/buscar?q=sal%C3%B3n&departamento=La+Libertad&municipio=Santa+Tecla");
  });

  it("no envía un municipio sin departamento", () => {
    expect(urlDeBusqueda({ municipio: "Santa Tecla" })).toBe("/buscar");
  });

  it("aplica el filtro de categoría", () => {
    expect(urlDeBusqueda({ categoria: "Salón de eventos" })).toBe(
      "/buscar?categoria=Sal%C3%B3n+de+eventos",
    );
  });
});

describe("criteriosDesdeUrl", () => {
  it("lee el texto, la ubicación y la categoría", () => {
    expect(
      criteriosDesdeUrl({
        q: " salón ",
        departamento: "San Salvador",
        municipio: "Soyapango",
        categoria: "Casa",
      }),
    ).toEqual({ q: "salón", departamento: "San Salvador", municipio: "Soyapango", categoria: "Casa" });
  });

  it("descarta los vacíos y el municipio sin departamento", () => {
    expect(criteriosDesdeUrl({ q: "   ", departamento: "", municipio: "Soyapango" })).toEqual({});
  });

  it("con un parámetro repetido toma el primero", () => {
    expect(criteriosDesdeUrl({ q: ["salón", "casa"] })).toEqual({ q: "salón" });
  });

  it("corta el texto a 100 caracteres, el máximo del backend", () => {
    expect(criteriosDesdeUrl({ q: "a".repeat(150) }).q).toHaveLength(100);
  });

  it("ida y vuelta con urlDeBusqueda conserva los criterios", () => {
    const criterios = { q: "salón", departamento: "La Libertad", municipio: "Santa Tecla" };
    const parametros = new URL(urlDeBusqueda(criterios), "http://localhost").searchParams;
    expect(criteriosDesdeUrl(Object.fromEntries(parametros))).toEqual(criterios);
  });
});

describe("esPaginaDeBienes", () => {
  it("acepta la respuesta del backend y rechaza otras formas", () => {
    expect(
      esPaginaDeBienes({ pagina: 1, tamanoPagina: 20, total: 0, hayMas: false, resultados: [] }),
    ).toBe(true);
    expect(esPaginaDeBienes({ resultados: [] })).toBe(false);
    expect(esPaginaDeBienes(null)).toBe(false);
  });
});

describe("buscarBienes", () => {
  const fetchSimulado = vi.fn();

  beforeEach(() => {
    fetchSimulado.mockReset();
    vi.stubGlobal("fetch", fetchSimulado);
  });

  afterEach(() => vi.unstubAllGlobals());

  it("pide la página al puente /api/bienes con los criterios y el tamaño 20", async () => {
    const pagina = { pagina: 2, tamanoPagina: 20, total: 45, hayMas: true, resultados: [] };
    fetchSimulado.mockResolvedValue(Response.json(pagina));

    await expect(buscarBienes({ q: "salón", departamento: "San Salvador" }, 2)).resolves.toEqual(
      pagina,
    );
    expect(fetchSimulado.mock.calls[0][0]).toBe(
      "/api/bienes?q=sal%C3%B3n&departamento=San+Salvador&pagina=2&tamano=20",
    );
  });

  it("lanza si la respuesta no es 2xx o no tiene la forma esperada", async () => {
    fetchSimulado.mockResolvedValueOnce(Response.json({}, { status: 500 }));
    await expect(buscarBienes({}, 1)).rejects.toMatchObject({ status: 500, mensajes: [] });

    fetchSimulado.mockResolvedValueOnce(Response.json({ hola: "mundo" }));
    await expect(buscarBienes({}, 1)).rejects.toBeInstanceOf(ErrorDeBusqueda);
  });
});

describe("filtros en la URL (FE-4.1)", () => {
  const conFiltros = {
    q: "salón",
    departamento: "San Salvador",
    precioMin: "20",
    precioMax: "100",
    tipo: "PROPIEDAD",
    categoria: "Salón de eventos",
    capacidadMin: "80",
    fechaInicio: "2026-11-20",
    fechaFin: "2026-11-22",
  } as const;

  it("ida y vuelta con urlDeBusqueda conserva todos los filtros", () => {
    const url = urlDeBusqueda(conFiltros);
    expect(url).toBe(
      "/buscar?q=sal%C3%B3n&departamento=San+Salvador&precioMin=20&precioMax=100&tipo=PROPIEDAD" +
        "&categoria=Sal%C3%B3n+de+eventos&capacidadMin=80&fechaInicio=2026-11-20&fechaFin=2026-11-22",
    );
    const parametros = new URL(url, "http://localhost").searchParams;
    expect(criteriosDesdeUrl(Object.fromEntries(parametros))).toEqual(conFiltros);
  });

  it("ignora los valores con forma inválida", () => {
    expect(
      criteriosDesdeUrl({
        precioMin: "-5",
        precioMax: "abc",
        tipo: "BARCO",
        categoria: "Naves espaciales",
        capacidadMin: "2.5",
        fechaInicio: "20/11/2026",
      }),
    ).toEqual({});
  });

  it("escribe la categoría como en el catálogo, igual que el backend", () => {
    expect(criteriosDesdeUrl({ categoria: "salon de EVENTOS" }).categoria).toBe("Salón de eventos");
  });

  it("la capacidad solo se lee con tipo Propiedad", () => {
    expect(criteriosDesdeUrl({ tipo: "EQUIPO", capacidadMin: "50" })).toEqual({ tipo: "EQUIPO" });
    expect(criteriosDesdeUrl({ capacidadMin: "50" })).toEqual({});
    expect(criteriosDesdeUrl({ tipo: "PROPIEDAD", capacidadMin: "50" })).toEqual({
      tipo: "PROPIEDAD",
      capacidadMin: "50",
    });
  });

  it("deja pasar combinaciones inválidas para que el backend responda 400", () => {
    expect(criteriosDesdeUrl({ precioMin: "100", precioMax: "20" })).toEqual({
      precioMin: "100",
      precioMax: "20",
    });
  });

  it("sinFiltros conserva el texto y la ubicación", () => {
    expect(urlDeBusqueda(sinFiltros(conFiltros))).toBe("/buscar?q=sal%C3%B3n&departamento=San+Salvador");
    expect(hayFiltros(conFiltros)).toBe(true);
    expect(hayFiltros(sinFiltros(conFiltros))).toBe(false);
  });

  it("arma los chips en el orden del diseño", () => {
    expect(chipsDeFiltros(conFiltros)).toEqual([
      // Quitar «Propiedad» también quita la capacidad, que solo aplica a ese tipo.
      { texto: "Propiedad", campos: ["tipo", "capacidadMin"] },
      { texto: "Salón de eventos", campos: ["categoria"] },
      { texto: "$20 a $100", campos: ["precioMin", "precioMax"] },
      { texto: "80+ personas", campos: ["capacidadMin"] },
      { texto: "20/11 a 22/11", campos: ["fechaInicio", "fechaFin"] },
    ]);
  });

  it("un precio suelto es «Desde» o «Hasta»", () => {
    expect(chipsDeFiltros({ precioMin: "20" })[0].texto).toBe("Desde $20");
    expect(chipsDeFiltros({ precioMax: "99.5" })[0].texto).toBe("Hasta $99.5");
  });
});

describe("buscarBienes con un 400", () => {
  afterEach(() => vi.unstubAllGlobals());

  it("lleva los mensajes del backend", async () => {
    const cuerpo = { message: ["El precio mínimo no puede ser mayor que el máximo."], statusCode: 400 };
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue(Response.json(cuerpo, { status: 400 })));

    await expect(buscarBienes({ precioMin: "100", precioMax: "20" }, 1)).rejects.toMatchObject({
      status: 400,
      mensajes: ["El precio mínimo no puede ser mayor que el máximo."],
    });
  });
});
