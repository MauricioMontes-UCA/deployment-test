import { describe, expect, it } from "vitest";
import {
  diasDelRango,
  esDisponibilidad,
  esFechaValida,
  estadoDelDia,
  hoyEnElSalvador,
  mesDesplazado,
  mesesEntre,
  rangoEsValido,
  ultimoDiaDeVentana,
  type Disponibilidad,
} from "@/lib/disponibilidad";

const disponibilidad: Disponibilidad = {
  bienId: "5a3f2c10-8d4e-4b1a-9c7e-1f2a3b4c5d6e",
  reservados: [{ fechaInicio: "2026-11-20", fechaFin: "2026-11-22" }],
  bloqueados: [
    { fechaInicio: "2026-11-26", fechaFin: "2026-11-27" },
    { fechaInicio: "2026-11-22", fechaFin: "2026-11-23" },
  ],
};
const contexto = { hoy: "2026-11-18", ultimoDia: "2027-11-17", disponibilidad };

describe("fechas", () => {
  it("hoy es el día de El Salvador, no el de UTC", () => {
    // 01:00 UTC del 19 todavía es 18 en El Salvador (UTC-6).
    expect(hoyEnElSalvador(new Date("2026-11-19T01:00:00Z"))).toBe("2026-11-18");
    expect(hoyEnElSalvador(new Date("2026-11-19T07:00:00Z"))).toBe("2026-11-19");
  });

  it("la ventana de 12 meses termina un día antes del aniversario", () => {
    expect(ultimoDiaDeVentana("2026-11-18")).toBe("2027-11-17");
    expect(ultimoDiaDeVentana("2026-11-01")).toBe("2027-10-31");
    expect(ultimoDiaDeVentana("2026-01-01")).toBe("2026-12-31");
  });

  it("mesDesplazado cruza el cambio de año", () => {
    expect(mesDesplazado("2026-11-18", 0)).toEqual({ anio: 2026, mes: 10 });
    expect(mesDesplazado("2026-11-18", 2)).toEqual({ anio: 2027, mes: 0 });
    expect(mesDesplazado("2026-11-18", 12)).toEqual({ anio: 2027, mes: 10 });
  });

  it("mesesEntre cuenta meses de calendario", () => {
    expect(mesesEntre("2026-11-18", "2027-11-17")).toBe(12);
    expect(mesesEntre("2026-11-01", "2027-10-31")).toBe(11);
  });

  it("esFechaValida rechaza días que no existen", () => {
    expect(esFechaValida("2026-11-18")).toBe(true);
    expect(esFechaValida("2026-02-30")).toBe(false);
    expect(esFechaValida("18/11/2026")).toBe(false);
    expect(esFechaValida(20261118)).toBe(false);
  });

  it("diasDelRango incluye ambos extremos", () => {
    expect(diasDelRango("2026-11-29", "2026-12-02")).toEqual([
      "2026-11-29",
      "2026-11-30",
      "2026-12-01",
      "2026-12-02",
    ]);
    expect(diasDelRango("2026-11-18", "2026-11-18")).toEqual(["2026-11-18"]);
  });
});

describe("estadoDelDia", () => {
  it("pinta cada estado", () => {
    expect(estadoDelDia("2026-11-17", contexto)).toBe("pasado");
    expect(estadoDelDia("2026-11-18", contexto)).toBe("hoy");
    expect(estadoDelDia("2026-11-19", contexto)).toBe("disponible");
    expect(estadoDelDia("2026-11-21", contexto)).toBe("reservado");
    expect(estadoDelDia("2026-11-26", contexto)).toBe("bloqueado");
  });

  it("reservado gana sobre bloqueado cuando se solapan", () => {
    expect(estadoDelDia("2026-11-22", contexto)).toBe("reservado");
    expect(estadoDelDia("2026-11-23", contexto)).toBe("bloqueado");
  });

  it("los días fuera de la ventana no se pueden elegir", () => {
    expect(estadoDelDia("2027-11-18", contexto)).toBe("pasado");
    expect(estadoDelDia("2027-11-17", contexto)).toBe("disponible");
  });

  it("marca inicio, fin y días intermedios", () => {
    const rango = { ...contexto, inicio: "2026-12-01", fin: "2026-12-03" };
    expect(estadoDelDia("2026-12-01", rango)).toBe("seleccionado");
    expect(estadoDelDia("2026-12-02", rango)).toBe("en-rango");
    expect(estadoDelDia("2026-12-03", rango)).toBe("seleccionado");
    expect(estadoDelDia("2026-12-04", rango)).toBe("disponible");
  });

  it("solo inicio: el resto no se pinta como rango", () => {
    const parcial = { ...contexto, inicio: "2026-12-01" };
    expect(estadoDelDia("2026-12-01", parcial)).toBe("seleccionado");
    expect(estadoDelDia("2026-12-02", parcial)).toBe("disponible");
  });
});

describe("rangoEsValido", () => {
  it("acepta un rango de días libres, incluso de un solo día", () => {
    expect(rangoEsValido("2026-11-24", "2026-11-25", contexto)).toBe(true);
    expect(rangoEsValido("2026-11-24", "2026-11-24", contexto)).toBe(true);
  });

  it("rechaza rangos que incluyen días reservados, bloqueados o pasados", () => {
    expect(rangoEsValido("2026-11-19", "2026-11-21", contexto)).toBe(false);
    expect(rangoEsValido("2026-11-25", "2026-11-27", contexto)).toBe(false);
    expect(rangoEsValido("2026-11-16", "2026-11-19", contexto)).toBe(false);
  });

  it("rechaza un rango que cruza completo sobre una reserva", () => {
    expect(rangoEsValido("2026-11-19", "2026-11-30", contexto)).toBe(false);
  });

  it("rechaza un rango al revés", () => {
    expect(rangoEsValido("2026-11-25", "2026-11-24", contexto)).toBe(false);
  });
});

describe("esDisponibilidad", () => {
  it("acepta la forma de la API", () => {
    expect(esDisponibilidad(disponibilidad)).toBe(true);
    expect(esDisponibilidad({ bienId: "x", reservados: [], bloqueados: [] })).toBe(true);
  });

  it("rechaza respuestas con otra forma", () => {
    expect(esDisponibilidad(null)).toBe(false);
    expect(esDisponibilidad({ message: "No autenticado." })).toBe(false);
    expect(esDisponibilidad({ bienId: "x", reservados: [{ fechaInicio: "ayer" }], bloqueados: [] })).toBe(false);
  });
});
