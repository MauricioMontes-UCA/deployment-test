import { describe, expect, it } from "vitest";
import {
  ESTADOS_COORDINACION,
  ESTADO_VISUAL,
  TEXTOS_COORDINACION,
  admiteCoordinacion,
  esEstadoReserva,
  formatearFechasReserva,
  leerConversacionReserva,
  otroParticipante,
  regresoPorRol,
  type EstadoReserva,
} from "../coordinacion";

const conversacionApi = (cambios: Record<string, unknown> = {}) => ({
  id: "c1",
  reservaId: "r1",
  estado: "CONFIRMADA",
  fechaInicio: "2026-11-24",
  fechaFin: "2026-11-25",
  bien: { id: "b1", titulo: "Salón de eventos Las Palmas" },
  arrendador: { id: "u2", nombreUsuario: "mariana_rivas" },
  arrendatario: { id: "u1", nombreUsuario: "luis.perez" },
  creadaEn: "2026-11-20T15:00:00.000Z",
  ...cambios,
});

describe("estados de la reserva", () => {
  it("solo CONFIRMADA y EN_CURSO admiten coordinación (Jira FE-14.1)", () => {
    expect(ESTADOS_COORDINACION).toEqual(["CONFIRMADA", "EN_CURSO"]);
    const admitidos = (["EN_COLA", "CONFIRMADA", "RECHAZADA", "EN_CURSO", "FINALIZADA", "CANCELADA"] as EstadoReserva[]).filter(
      admiteCoordinacion,
    );
    expect(admitidos).toEqual(["CONFIRMADA", "EN_CURSO"]);
  });

  it("reconoce los seis estados del backend", () => {
    for (const estado of ["EN_COLA", "CONFIRMADA", "RECHAZADA", "EN_CURSO", "FINALIZADA", "CANCELADA"]) {
      expect(esEstadoReserva(estado)).toBe(true);
    }
    expect(esEstadoReserva("PENDIENTE")).toBe(false);
    expect(esEstadoReserva(null)).toBe(false);
  });

  it("insignia con el texto y tono de Figma (CONFIRMADA éxito, EN_CURSO marca)", () => {
    expect(ESTADO_VISUAL.CONFIRMADA).toEqual({ texto: "Confirmada", tono: "exito" });
    expect(ESTADO_VISUAL.EN_CURSO).toEqual({ texto: "En curso", tono: "marca" });
    expect(ESTADO_VISUAL.FINALIZADA.texto).toBe("Finalizada");
    expect(ESTADO_VISUAL.CANCELADA.texto).toBe("Cancelada");
  });

  it("texto de «Reserva no permitida» igual al de H14 y Figma 30:1167", () => {
    expect(TEXTOS_COORDINACION.noPermitida).toBe(
      "La coordinación está disponible cuando la reserva está confirmada o en curso.",
    );
  });
});

describe("formatearFechasReserva", () => {
  it("«24/11/2026 → 25/11/2026 · 2 días» como Figma (cuentan inicio y fin)", () => {
    expect(formatearFechasReserva("2026-11-24", "2026-11-25")).toBe("24/11/2026 → 25/11/2026 · 2 días");
  });

  it("un solo día en singular y cruce de mes", () => {
    expect(formatearFechasReserva("2026-11-24", "2026-11-24")).toBe("24/11/2026 → 24/11/2026 · 1 día");
    expect(formatearFechasReserva("2026-11-30", "2026-12-02")).toBe("30/11/2026 → 02/12/2026 · 3 días");
  });

  it("fechas inválidas o invertidas: solo el rango, sin inventar días", () => {
    expect(formatearFechasReserva("2026-11-25", "2026-11-24")).toBe("25/11/2026 → 24/11/2026");
    expect(formatearFechasReserva("ayer", "2026-11-24")).toBe("ayer → 24/11/2026");
  });
});

describe("leerConversacionReserva", () => {
  it("lee la respuesta de BE-14.1", () => {
    // `creadaEn` no se usa en la pantalla y no se conserva.
    const esperado: Record<string, unknown> = conversacionApi();
    delete esperado.creadaEn;
    expect(leerConversacionReserva(conversacionApi())).toEqual(esperado);
  });

  it.each([
    ["sin bien", conversacionApi({ bien: null })],
    ["estado desconocido", conversacionApi({ estado: "PENDIENTE" })],
    ["fecha con hora", conversacionApi({ fechaInicio: "2026-11-24T00:00:00Z" })],
    ["arrendador sin nombre", conversacionApi({ arrendador: { id: "u2" } })],
    ["arrendatario ausente", conversacionApi({ arrendatario: undefined })],
    ["id numérico", conversacionApi({ id: 1 })],
    ["no es objeto", "x"],
  ])("%s → null", (_caso, valor) => {
    expect(leerConversacionReserva(valor)).toBeNull();
  });
});

describe("otroParticipante y regreso", () => {
  const conversacion = leerConversacionReserva(conversacionApi())!;

  it("para el arrendador es el arrendatario, y al revés", () => {
    expect(otroParticipante(conversacion, "u2").nombreUsuario).toBe("luis.perez");
    expect(otroParticipante(conversacion, "u1").nombreUsuario).toBe("mariana_rivas");
  });

  it("el regreso depende del rol mientras no exista /reservas/[id]", () => {
    expect(regresoPorRol("ARRENDADOR")).toEqual({ href: "/reservas-recibidas", texto: "Volver a reservas recibidas" });
    expect(regresoPorRol("ARRENDATARIO")).toEqual({ href: "/reservas", texto: "Volver a mis reservas" });
  });
});
