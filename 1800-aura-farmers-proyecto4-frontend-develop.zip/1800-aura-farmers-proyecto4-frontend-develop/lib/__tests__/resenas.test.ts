import { describe, expect, it } from "vitest";
import {
  LIMITE_COMENTARIO,
  armarPayload,
  clasificarErrorResenas,
  contarCaracteres,
  errorComentario,
  esPuntuacionValida,
  excesoComentario,
  formularioValido,
  mensajeExceso,
  normalizarComentario,
  PLAZO_RESENA_DIAS,
  diasDesdeFinalizacion,
  puedeCalificarse,
  puedeEnviar,
  type FormularioResenas,
} from "@/lib/resenas";

// El Salvador es UTC-6 todo el año (sin horario de verano).
const FINALIZADA_EN = "2026-11-04T16:00:00.000Z"; // 04/11/2026, 10:00 en El Salvador

describe("diasDesdeFinalizacion", () => {
  it("el mismo día de la finalización es el día 0", () => {
    expect(diasDesdeFinalizacion(FINALIZADA_EN, new Date("2026-11-05T05:59:00Z"))).toBe(0);
  });

  it("cuenta días de calendario de El Salvador, no de UTC", () => {
    // 05/11 03:00 UTC todavía es 04/11 (21:00) en El Salvador.
    const deNoche = "2026-11-05T03:00:00.000Z";
    // 19/11 12:00 en El Salvador: 15 días desde el 04/11 (en UTC serían 14).
    expect(diasDesdeFinalizacion(deNoche, new Date("2026-11-19T18:00:00Z"))).toBe(15);
  });

  it("cambia de día a la medianoche de El Salvador (06:00 UTC)", () => {
    expect(diasDesdeFinalizacion(FINALIZADA_EN, new Date("2026-11-19T05:59:59Z"))).toBe(14);
    expect(diasDesdeFinalizacion(FINALIZADA_EN, new Date("2026-11-19T06:00:00Z"))).toBe(15);
  });
});

describe("puedeCalificarse", () => {
  const finalizada = { estado: "FINALIZADA", finalizadaEn: FINALIZADA_EN };

  it("el plazo es de 14 días", () => {
    expect(PLAZO_RESENA_DIAS).toBe(14);
  });

  it("una reserva FINALIZADA se puede calificar desde el día 0 hasta el día 14", () => {
    expect(puedeCalificarse(finalizada, new Date("2026-11-04T20:00:00Z"))).toBe(true);
    expect(puedeCalificarse(finalizada, new Date("2026-11-10T18:00:00Z"))).toBe(true);
    // Día 14: último minuto del 18/11 en El Salvador.
    expect(puedeCalificarse(finalizada, new Date("2026-11-19T05:59:59Z"))).toBe(true);
  });

  it("el día 15 ya no se puede (desde la medianoche de El Salvador)", () => {
    expect(puedeCalificarse(finalizada, new Date("2026-11-19T06:00:00Z"))).toBe(false);
    expect(puedeCalificarse(finalizada, new Date("2026-12-01T18:00:00Z"))).toBe(false);
  });

  it.each(["EN_COLA", "CONFIRMADA", "RECHAZADA", "EN_CURSO", "CANCELADA"])(
    "una reserva %s no se puede calificar",
    (estado) => {
      expect(puedeCalificarse({ estado, finalizadaEn: FINALIZADA_EN }, new Date("2026-11-05T18:00:00Z"))).toBe(false);
    },
  );

  it("una reserva FINALIZADA sin fecha de finalización no se puede (igual que el backend)", () => {
    expect(puedeCalificarse({ estado: "FINALIZADA", finalizadaEn: null }, new Date("2026-11-05T18:00:00Z"))).toBe(false);
  });

  it("una fecha de finalización inválida no se toma como válida", () => {
    expect(puedeCalificarse({ estado: "FINALIZADA", finalizadaEn: "ayer" }, new Date("2026-11-05T18:00:00Z"))).toBe(false);
  });
});

const texto = (longitud: number) => "a".repeat(longitud);

/** Congela en profundidad para que cualquier mutación lance un error. */
function congelar<T extends object>(objeto: T): T {
  for (const valor of Object.values(objeto)) {
    if (typeof valor === "object" && valor !== null) congelar(valor);
  }
  return Object.freeze(objeto);
}

const formulario = (
  bien: Partial<FormularioResenas["bien"]> = {},
  arrendador: Partial<FormularioResenas["arrendador"]> = {},
): FormularioResenas => ({
  bien: { puntuacion: 4, comentario: "", ...bien },
  arrendador: { puntuacion: 5, comentario: "", ...arrendador },
});

describe("esPuntuacionValida", () => {
  it("acepta los enteros de 1 a 5", () => {
    expect([1, 2, 3, 4, 5].map(esPuntuacionValida)).toEqual([true, true, true, true, true]);
  });

  it("rechaza 0 (sin selección), 6 y negativos", () => {
    expect(esPuntuacionValida(0)).toBe(false);
    expect(esPuntuacionValida(6)).toBe(false);
    expect(esPuntuacionValida(-1)).toBe(false);
  });

  it("rechaza decimales, NaN e infinitos", () => {
    expect(esPuntuacionValida(3.5)).toBe(false);
    expect(esPuntuacionValida(4.0000001)).toBe(false);
    expect(esPuntuacionValida(Number.NaN)).toBe(false);
    expect(esPuntuacionValida(Number.POSITIVE_INFINITY)).toBe(false);
  });

  it("rechaza lo que no es número, aunque lo parezca", () => {
    expect(esPuntuacionValida("4")).toBe(false);
    expect(esPuntuacionValida(null)).toBe(false);
    expect(esPuntuacionValida(undefined)).toBe(false);
    expect(esPuntuacionValida(true)).toBe(false);
  });
});

describe("contarCaracteres", () => {
  // Valores medidos con validator.isLength (v13.15.35, el que usa el backend)
  // para documentar por qué se cuenta por code point.
  it.each([
    ["ASCII", "hola", 4],
    ["acentuado precompuesto (é = U+00E9)", "éxito", 5],
    ["acento combinado (e + U+0301)", "é", 2],
    ["emoji 😀 (par sustituto)", "😀", 1],
    ["emoji con tono de piel 👍🏽", "👍🏽", 2],
    ["familia con ZWJ 👨‍👩‍👧", "👨‍👩‍👧", 5],
    ["bandera 🇸🇻", "🇸🇻", 2],
    ["❤️ con selector de variación", "❤️", 2],
  ])("%s", (_caso, valor, esperado) => {
    expect(contarCaracteres(valor)).toBe(esperado);
  });

  it("un emoji cuenta 1, no 2 como en String.length", () => {
    expect("😀".length).toBe(2);
    expect(contarCaracteres("😀".repeat(500))).toBe(500);
  });

  it("cuenta el texto tal cual, con espacios", () => {
    expect(contarCaracteres("  hola  ")).toBe(8);
    expect(contarCaracteres("")).toBe(0);
  });
});

describe("excesoComentario y mensajeExceso", () => {
  it("499 y 500 caracteres caben; 501 se pasa por 1", () => {
    expect(excesoComentario(texto(499))).toBe(0);
    expect(excesoComentario(texto(500))).toBe(0);
    expect(excesoComentario(texto(501))).toBe(1);
  });

  it("cuenta después de recortar, como el backend", () => {
    expect(excesoComentario(`   ${texto(500)}\n\n`)).toBe(0);
    expect(excesoComentario(`  ${texto(512)}  `)).toBe(12);
  });

  it("500 emojis caben aunque String.length dé 1000", () => {
    expect(excesoComentario("😀".repeat(500))).toBe(0);
    expect(excesoComentario("😀".repeat(501))).toBe(1);
  });

  it("es conservador con los selectores de variación: 300 × ❤️ son 600 para la base", () => {
    // validator.isLength los cuenta 300 y los dejaría pasar, pero VARCHAR(500) no.
    expect(excesoComentario("❤️".repeat(300))).toBe(100);
  });

  it("arma el mensaje exacto con lo que sobra", () => {
    expect(mensajeExceso(12)).toBe("Tu comentario supera los 500 caracteres por 12.");
    expect(mensajeExceso(1)).toBe("Tu comentario supera los 500 caracteres por 1.");
  });

  it("errorComentario devuelve el mensaje solo si se pasa", () => {
    expect(errorComentario(texto(500))).toBeNull();
    expect(errorComentario("")).toBeNull();
    expect(errorComentario(texto(512))).toBe("Tu comentario supera los 500 caracteres por 12.");
  });

  it("el límite es 500", () => {
    expect(LIMITE_COMENTARIO).toBe(500);
  });
});

describe("normalizarComentario", () => {
  it("quita espacios, tabs y saltos de línea de los extremos y conserva los internos", () => {
    expect(normalizarComentario("  Muy\tpuntual \n y amable.\n ")).toBe("Muy\tpuntual \n y amable.");
    expect(normalizarComentario(" \n\t ")).toBe("");
  });
});

describe("formularioValido y puedeEnviar", () => {
  const listo = { enviando: false, bloqueado: false };

  it("con las dos puntuaciones y sin comentarios se puede enviar", () => {
    expect(formularioValido(formulario())).toBe(true);
    expect(puedeEnviar({ formulario: formulario(), ...listo })).toBe(true);
  });

  it("las dos puntuaciones son obligatorias", () => {
    expect(puedeEnviar({ formulario: formulario({ puntuacion: 0 }), ...listo })).toBe(false);
    expect(puedeEnviar({ formulario: formulario({}, { puntuacion: 0 }), ...listo })).toBe(false);
    expect(puedeEnviar({ formulario: formulario({ puntuacion: 0 }, { puntuacion: 0 }), ...listo })).toBe(false);
  });

  it("una puntuación fuera de rango o decimal bloquea el envío", () => {
    expect(puedeEnviar({ formulario: formulario({ puntuacion: 6 }), ...listo })).toBe(false);
    expect(puedeEnviar({ formulario: formulario({}, { puntuacion: 2.5 }), ...listo })).toBe(false);
  });

  it("un comentario de 501 caracteres en cualquiera de las dos bloquea el envío", () => {
    expect(puedeEnviar({ formulario: formulario({ comentario: texto(500) }), ...listo })).toBe(true);
    expect(puedeEnviar({ formulario: formulario({ comentario: texto(501) }), ...listo })).toBe(false);
    expect(puedeEnviar({ formulario: formulario({}, { comentario: texto(501) }), ...listo })).toBe(false);
  });

  it("no se puede enviar mientras hay una solicitud en curso", () => {
    expect(puedeEnviar({ formulario: formulario(), enviando: true, bloqueado: false })).toBe(false);
  });

  it("no se puede enviar si el servidor ya respondió 409 o 422", () => {
    expect(puedeEnviar({ formulario: formulario(), enviando: false, bloqueado: true })).toBe(false);
  });
});

describe("armarPayload", () => {
  it("arma exactamente el cuerpo del backend, con los comentarios recortados", () => {
    expect(
      armarPayload(
        formulario(
          { puntuacion: 4, comentario: "  Funcionó perfecto y venía con su maletín y brocas. " },
          { puntuacion: 5, comentario: "\nMuy puntual y amable en la entrega.\n" },
        ),
      ),
    ).toStrictEqual({
      bien: { puntuacion: 4, comentario: "Funcionó perfecto y venía con su maletín y brocas." },
      arrendador: { puntuacion: 5, comentario: "Muy puntual y amable en la entrega." },
    });
  });

  it("omite los comentarios vacíos o de solo espacios (sin la propiedad, no con undefined)", () => {
    const payload = armarPayload(formulario({ comentario: "" }, { comentario: "   \n " }));
    expect(payload).toStrictEqual({ bien: { puntuacion: 4 }, arrendador: { puntuacion: 5 } });
    expect(Object.keys(payload!.bien)).toEqual(["puntuacion"]);
    expect(Object.keys(payload!.arrendador)).toEqual(["puntuacion"]);
  });

  it("no envía propiedades que el backend no acepta", () => {
    const conExtras = {
      bien: { puntuacion: 3, comentario: "Bien", id: "x" },
      arrendador: { puntuacion: 2, comentario: "", tipo: "ARRENDADOR" },
      reservaId: "5a3f2c10-8d4e-4b1a-9c7e-1f2a3b4c5d6e",
    } as unknown as FormularioResenas;
    const payload = armarPayload(conExtras);
    expect(payload).toStrictEqual({
      bien: { puntuacion: 3, comentario: "Bien" },
      arrendador: { puntuacion: 2 },
    });
    expect(Object.keys(payload!)).toEqual(["bien", "arrendador"]);
  });

  it("devuelve null si el formulario no es válido", () => {
    expect(armarPayload(formulario({ puntuacion: 0 }))).toBeNull();
    expect(armarPayload(formulario({}, { comentario: texto(501) }))).toBeNull();
  });

  it("acepta un comentario de 500 caracteres con espacios alrededor y lo envía recortado", () => {
    const payload = armarPayload(formulario({ comentario: `  ${texto(500)}  ` }));
    expect(payload?.bien.comentario).toBe(texto(500));
  });

  it("no modifica el formulario recibido", () => {
    const entrada = congelar(formulario({ comentario: "  Hola  " }, { comentario: " " }));
    const copia = structuredClone(entrada);
    const payload = armarPayload(entrada);
    expect(entrada).toStrictEqual(copia);
    expect(payload?.bien).not.toBe(entrada.bien);
    expect(payload?.arrendador).not.toBe(entrada.arrendador);
  });
});

describe("clasificarErrorResenas", () => {
  it.each([
    [400, "validacion", "Revisa la puntuación y el comentario.", false],
    [403, "sin-permiso", "No tienes permiso para calificar esta reserva.", false],
    [404, "no-encontrada", "No encontramos esa reserva.", false],
    [409, "ya-calificada", "Ya calificaste esta reserva.", true],
    [
      422,
      "fuera-de-plazo",
      "Solo puedes calificar reservas finalizadas dentro de los 14 días posteriores a la devolución.",
      true,
    ],
    [500, "servidor", "No pudimos enviar tu reseña. Intenta de nuevo.", false],
  ] as const)("%i → %s", (status, tipo, mensaje, bloqueante) => {
    expect(clasificarErrorResenas(status)).toStrictEqual({ tipo, mensaje, bloqueante });
  });

  it("un fallo de red (sin código) es el error genérico y no bloquea", () => {
    expect(clasificarErrorResenas(null)).toStrictEqual({
      tipo: "servidor",
      mensaje: "No pudimos enviar tu reseña. Intenta de nuevo.",
      bloqueante: false,
    });
  });

  it("los códigos desconocidos caen en el genérico", () => {
    for (const status of [401, 405, 418, 429, 502, 503, 0]) {
      expect(clasificarErrorResenas(status)).toStrictEqual({
        tipo: "servidor",
        mensaje: "No pudimos enviar tu reseña. Intenta de nuevo.",
        bloqueante: false,
      });
    }
  });

  it("solo 409 y 422 bloquean el formulario", () => {
    const bloqueantes = [400, 403, 404, 409, 422, 500, null].filter(
      (status) => clasificarErrorResenas(status).bloqueante,
    );
    expect(bloqueantes).toEqual([409, 422]);
  });
});
