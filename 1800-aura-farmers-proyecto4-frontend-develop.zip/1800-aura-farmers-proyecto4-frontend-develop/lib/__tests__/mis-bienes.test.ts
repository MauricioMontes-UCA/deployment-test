import { describe, expect, it } from "vitest";
import {
  ESTADO_BIEN,
  PAGINA_VALIDA,
  hrefBloqueos,
  hrefPublicacion,
  textoCantidad,
  ubicacionDelBien,
} from "../mis-bienes";

describe("mis-bienes", () => {
  it("la insignia: Activa en éxito e Inactiva en neutro", () => {
    expect(ESTADO_BIEN.ACTIVA).toEqual({ texto: "Activa", tono: "exito" });
    expect(ESTADO_BIEN.INACTIVA).toEqual({ texto: "Inactiva", tono: "neutro" });
  });

  it("valida la página como el backend", () => {
    for (const ok of ["1", "2", "20"]) expect(PAGINA_VALIDA.test(ok)).toBe(true);
    for (const mal of ["0", "01", "-1", "1e2", "", "1.5", "1234567890123456"]) {
      expect(PAGINA_VALIDA.test(mal)).toBe(false);
    }
  });

  it("arma ubicación, cantidad y enlaces", () => {
    expect(ubicacionDelBien({ municipio: "Santa Tecla", departamento: "La Libertad" })).toBe(
      "Santa Tecla, La Libertad",
    );
    expect(textoCantidad(1)).toBe("1 bien publicado");
    expect(textoCantidad(3)).toBe("3 bienes publicados");
    expect(hrefBloqueos("b1")).toBe("/mis-bienes/b1/bloqueos");
    expect(hrefPublicacion("b1")).toBe("/bienes/b1");
  });
});
