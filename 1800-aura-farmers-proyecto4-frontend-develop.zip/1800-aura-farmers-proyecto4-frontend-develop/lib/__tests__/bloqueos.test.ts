import { describe, expect, it } from "vitest";
import {
  ERROR_BLOQUEO_INEXISTENTE,
  ERROR_BLOQUEO_SOLAPADO,
  ERROR_GENERAL,
  ERROR_RESERVA,
  ERROR_SIN_PERMISO,
  esListaDeBloqueos,
  formatearFecha,
  mensajeDeError,
  ordenarPorInicio,
  textoDeDias,
  textoDelRango,
} from "../bloqueos";

const ID = "10000000-0000-4000-8000-000000000001";

describe("formato", () => {
  it("convierte AAAA-MM-DD en DD/MM/AAAA", () => {
    expect(formatearFecha("2026-12-24")).toBe("24/12/2026");
    expect(textoDelRango({ fechaInicio: "2026-12-24", fechaFin: "2026-12-26" })).toBe("24/12/2026 → 26/12/2026");
  });

  it("cuenta los días del rango, ambos extremos incluidos", () => {
    expect(textoDeDias({ fechaInicio: "2026-12-24", fechaFin: "2026-12-26" })).toBe("3 días");
    expect(textoDeDias({ fechaInicio: "2026-12-24", fechaFin: "2026-12-24" })).toBe("1 día");
  });

  it("ordena por inicio sin mutar la lista", () => {
    const lista = [
      { fechaInicio: "2026-12-24", fechaFin: "2026-12-26" },
      { fechaInicio: "2026-11-26", fechaFin: "2026-11-27" },
    ];
    expect(ordenarPorInicio(lista)[0].fechaInicio).toBe("2026-11-26");
    expect(lista[0].fechaInicio).toBe("2026-12-24");
  });
});

describe("esListaDeBloqueos", () => {
  it("acepta la lista de BE-7.3", () => {
    expect(esListaDeBloqueos([{ id: ID, fechaInicio: "2026-12-24", fechaFin: "2026-12-26", creadoEn: "x" }])).toBe(true);
    expect(esListaDeBloqueos([])).toBe(true);
  });

  it.each([null, {}, [{ fechaInicio: "2026-12-24", fechaFin: "2026-12-26" }], [{ id: ID, fechaInicio: "x", fechaFin: "y" }]])(
    "rechaza %j",
    (valor) => expect(esListaDeBloqueos(valor)).toBe(false),
  );
});

describe("mensajeDeError", () => {
  it("409 con reserva y 409 con otro bloqueo se distinguen", () => {
    expect(mensajeDeError(409, { reservaId: ID })).toBe(ERROR_RESERVA);
    expect(mensajeDeError(409, { bloqueoId: ID })).toBe(ERROR_BLOQUEO_SOLAPADO);
    expect(mensajeDeError(409, null)).toBe(ERROR_RESERVA);
  });

  it("403 y 404 usan los mensajes definidos", () => {
    expect(mensajeDeError(403, {})).toBe(ERROR_SIN_PERMISO);
    expect(mensajeDeError(404, {})).toBe(ERROR_BLOQUEO_INEXISTENTE);
  });

  it("422 muestra el mensaje del servicio, también si es una lista", () => {
    expect(mensajeDeError(422, { message: "La fecha de inicio no puede ser anterior a hoy." })).toBe(
      "La fecha de inicio no puede ser anterior a hoy.",
    );
    expect(mensajeDeError(400, { message: ["a", "b"] })).toBe("a b");
  });

  it("cualquier otro caso usa el mensaje general", () => {
    expect(mensajeDeError(500, {})).toBe(ERROR_GENERAL);
    expect(mensajeDeError(422, {})).toBe(ERROR_GENERAL);
  });
});
