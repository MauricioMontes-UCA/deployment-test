import { describe, expect, it } from "vitest";
import {
  CONVERSACIONES_POR_PAGINA,
  FILTROS_BANDEJA,
  esSeleccionada,
  escribirPista,
  etiquetaBien,
  formatearFechaBandeja,
  leerConversacionBandeja,
  leerPaginaBandeja,
  leerParametrosBandeja,
  leerPista,
  pistaDe,
  rutaBandeja,
  rutaConversacion,
  rutaPuenteBandeja,
  seleccionDe,
  unirPaginas,
  vistaPrevia,
  type ConversacionBandeja,
} from "../bandeja";

const CONV = "11111111-1111-4111-8111-111111111111";
const RESERVA = "22222222-2222-4222-8222-222222222222";
const BIEN = "33333333-3333-4333-8333-333333333333";

/** Una conversación tal como la devuelve `GET /conversaciones` (BE-13.2). */
const itemApi = (cambios: Record<string, unknown> = {}) => ({
  id: CONV,
  tipo: "CONSULTA",
  bien: { id: BIEN, titulo: "Salón de eventos Las Palmas", fotoPrincipalUrl: "/uploads/bienes/salon.jpg" },
  reservaId: null,
  otroParticipante: { id: "u1", nombreUsuario: "ana_m" },
  ultimoMensaje: { contenido: "Perfecto. ¿Se puede entrar desde las 2:00 p. m.?", enviadoEn: "2026-11-20T16:42:00.000Z", remitenteId: "u1" },
  actualizadaEn: "2026-11-20T16:42:00.000Z",
  ...cambios,
});
const paginaApi = (items: unknown[], cambios: Record<string, unknown> = {}) => ({ items, pagina: 1, total: items.length, hayMas: false, ...cambios });
const leer = (cambios: Record<string, unknown> = {}) => leerConversacionBandeja(itemApi(cambios)) as ConversacionBandeja;

describe("contrato de GET /conversaciones", () => {
  it("lee una consulta con todos sus campos y descarta los que no usa", () => {
    expect(leerConversacionBandeja({ ...itemApi(), extra: "x" })).toEqual({
      id: CONV,
      tipo: "CONSULTA",
      bien: { id: BIEN, titulo: "Salón de eventos Las Palmas", foto: "/uploads/bienes/salon.jpg" },
      reservaId: null,
      otroParticipante: { id: "u1", nombreUsuario: "ana_m" },
      ultimoMensaje: { contenido: "Perfecto. ¿Se puede entrar desde las 2:00 p. m.?", enviadoEn: "2026-11-20T16:42:00.000Z", remitenteId: "u1" },
      actualizadaEn: "2026-11-20T16:42:00.000Z",
    });
  });

  it("lee una coordinación con su reserva, sin foto y sin mensajes", () => {
    const item = leerConversacionBandeja(
      itemApi({ tipo: "COORDINACION", reservaId: RESERVA, ultimoMensaje: null, bien: { id: BIEN, titulo: "Cámara", fotoPrincipalUrl: null } }),
    );
    expect(item).toMatchObject({ tipo: "COORDINACION", reservaId: RESERVA, ultimoMensaje: null, bien: { foto: null } });
  });

  it.each([
    ["sin id", { id: 1 }],
    ["tipo desconocido", { tipo: "OTRO" }],
    ["coordinación sin reserva", { tipo: "COORDINACION", reservaId: null }],
    ["consulta con reserva", { reservaId: RESERVA }],
    ["sin otro participante", { otroParticipante: { id: "u1" } }],
    ["fecha inválida", { actualizadaEn: "ayer" }],
    ["último mensaje incompleto", { ultimoMensaje: { contenido: "Hola" } }],
    ["bien sin título", { bien: { id: BIEN } }],
    ["foto que no es texto", { bien: { id: BIEN, titulo: "x", fotoPrincipalUrl: 3 } }],
  ])("rechaza una conversación con %s", (_caso, cambios) => {
    expect(leerConversacionBandeja(itemApi(cambios))).toBeNull();
  });

  it("lee la página conservando el orden del backend (más reciente primero)", () => {
    const pagina = leerPaginaBandeja(
      paginaApi(
        [itemApi({ id: "a" }), itemApi({ id: "b", actualizadaEn: "2026-11-19T10:00:00.000Z" })],
        { pagina: 2, total: 22, hayMas: false },
      ),
    );
    expect(pagina?.items.map(({ id }) => id)).toEqual(["a", "b"]);
    expect(pagina).toMatchObject({ pagina: 2, total: 22, hayMas: false });
  });

  it("una sola conversación ilegible invalida la página (no se esconde nada sin avisar)", () => {
    expect(leerPaginaBandeja(paginaApi([itemApi(), itemApi({ tipo: "OTRO" })]))).toBeNull();
  });

  it.each([
    ["sin items", { pagina: 1, total: 0, hayMas: false }],
    ["sin hayMas", { items: [], pagina: 1, total: 0 }],
    ["página no entera", { items: [], pagina: "1", total: 0, hayMas: false }],
    ["nulo", null],
  ])("rechaza una página %s", (_caso, datos) => {
    expect(leerPaginaBandeja(datos)).toBeNull();
  });

  it("20 por página, como CONVERSACIONES_POR_PAGINA del backend", () => {
    expect(CONVERSACIONES_POR_PAGINA).toBe(20);
  });
});

describe("filtros y paginación", () => {
  it("pestañas de Jira con su filtro: Todas (sin tipo), Consultas y Coordinación", () => {
    expect(FILTROS_BANDEJA).toEqual([
      { tipo: null, texto: "Todas" },
      { tipo: "CONSULTA", texto: "Consultas" },
      { tipo: "COORDINACION", texto: "Coordinación" },
    ]);
  });

  it("la ruta del puente lleva el tipo solo cuando hay filtro y la página desde 1", () => {
    expect(rutaPuenteBandeja(null, 1)).toBe("/api/conversaciones?pagina=1");
    expect(rutaPuenteBandeja("CONSULTA", 1)).toBe("/api/conversaciones?tipo=CONSULTA&pagina=1");
    expect(rutaPuenteBandeja("COORDINACION", 3)).toBe("/api/conversaciones?tipo=COORDINACION&pagina=3");
  });

  it("une páginas sin repetir conversaciones y conserva la primera aparición", () => {
    const [a, b, c] = ["a", "b", "c"].map((id) => leer({ id }));
    const unidas = unirPaginas([a, b], [{ ...b, ultimoMensaje: null }, c, c]);
    expect(unidas.map(({ id }) => id)).toEqual(["a", "b", "c"]);
    expect(unidas[1]).toBe(b);
  });
});

describe("rutas y selección", () => {
  const consulta = leer();
  const coordinacion = leer({ id: "c2", tipo: "COORDINACION", reservaId: RESERVA });

  it("móvil: coordinación por reserva (FE-14.1), sin pista", () => {
    expect(rutaConversacion(coordinacion)).toBe(`/reservas/${RESERVA}/conversacion`);
    expect(rutaConversacion(coordinacion, { filtro: null, pagina: 2 })).toBe(`/reservas/${RESERVA}/conversacion`);
  });

  it("móvil: la consulta, para los dos roles, por id de conversación (nunca por bien) con su pista", () => {
    expect(rutaConversacion(consulta)).toBe(`/mensajes/${CONV}`);
    expect(rutaConversacion(consulta, { filtro: null, pagina: 7 })).toBe(`/mensajes/${CONV}?pista=TODAS-7`);
    expect(rutaConversacion(consulta, { filtro: "CONSULTA", pagina: 2 })).toBe(`/mensajes/${CONV}?pista=CONSULTA-2`);
    expect(rutaConversacion(consulta)).not.toContain(BIEN);
  });

  it("pista: solo «Todas» o «Consultas» y una página válida; en «Coordinación» no hay", () => {
    expect(leerPista("TODAS-3")).toEqual({ filtro: null, pagina: 3 });
    expect(leerPista("CONSULTA-120")).toEqual({ filtro: "CONSULTA", pagina: 120 });
    for (const malo of ["COORDINACION-1", "TODAS-0", "TODAS--1", "TODAS-1&x=1", "consulta-1", "TODAS-1234567", undefined, 3]) {
      expect(leerPista(malo)).toBeNull();
    }
    expect(escribirPista({ filtro: null, pagina: 4 })).toBe("TODAS-4");
    expect(pistaDe("COORDINACION", 2)).toBeUndefined();
    expect(pistaDe("CONSULTA", undefined)).toBeUndefined();
    expect(pistaDe(null, 5)).toEqual({ filtro: null, pagina: 5 });
  });

  it("escritorio: la selección va en la URL y conserva la pestaña", () => {
    expect(rutaBandeja(null, null)).toBe("/mensajes");
    expect(rutaBandeja("CONSULTA", seleccionDe(consulta))).toBe(`/mensajes?tipo=CONSULTA&consulta=${CONV}`);
    expect(rutaBandeja(null, seleccionDe(coordinacion))).toBe(`/mensajes?reserva=${RESERVA}`);
    expect(rutaBandeja("CONSULTA", seleccionDe(consulta, { filtro: "CONSULTA", pagina: 6 }))).toBe(
      `/mensajes?tipo=CONSULTA&consulta=${CONV}&pista=CONSULTA-6`,
    );
  });

  it("marca como seleccionada solo la conversación de la URL", () => {
    expect(esSeleccionada(consulta, { tipo: "consulta", conversacionId: CONV })).toBe(true);
    expect(esSeleccionada(coordinacion, { tipo: "reserva", reservaId: RESERVA })).toBe(true);
    // Mismo id pero distinto tipo: no.
    expect(esSeleccionada({ ...coordinacion, id: CONV }, { tipo: "consulta", conversacionId: CONV })).toBe(false);
    expect(esSeleccionada(consulta, null)).toBe(false);
  });

  it("lee pestaña y selección de la URL; ignora valores inválidos", () => {
    expect(leerParametrosBandeja({ tipo: "COORDINACION", reserva: RESERVA })).toEqual({
      tipo: "COORDINACION",
      seleccion: { tipo: "reserva", reservaId: RESERVA },
    });
    expect(leerParametrosBandeja({ consulta: [CONV, "otro"] })).toEqual({
      tipo: null,
      seleccion: { tipo: "consulta", conversacionId: CONV },
    });
    expect(leerParametrosBandeja({ tipo: "otro", consulta: "../x", reserva: "1" })).toEqual({ tipo: null, seleccion: null });
    expect(leerParametrosBandeja({ tipo: "COORDINACION", consulta: CONV, pista: "TODAS-9" })).toEqual({
      tipo: "COORDINACION",
      seleccion: { tipo: "consulta", conversacionId: CONV, pista: { filtro: null, pagina: 9 } },
    });
    // Una pista inválida se ignora sin perder la selección.
    expect(leerParametrosBandeja({ consulta: CONV, pista: "TODAS-x" }).seleccion).toEqual({ tipo: "consulta", conversacionId: CONV });
  });
});

describe("tarjeta", () => {
  it("bien con el tipo de Figma: «· Consulta» o «· Entrega»", () => {
    expect(etiquetaBien(leer())).toBe("Salón de eventos Las Palmas · Consulta");
    expect(etiquetaBien(leer({ tipo: "COORDINACION", reservaId: RESERVA }))).toBe("Salón de eventos Las Palmas · Entrega");
  });

  it("último mensaje o, sin mensajes, un aviso (no se inventa contenido)", () => {
    expect(vistaPrevia(leer())).toBe("Perfecto. ¿Se puede entrar desde las 2:00 p. m.?");
    expect(vistaPrevia(leer({ ultimoMensaje: null }))).toBe("Aún no hay mensajes");
  });

  // 20/11/2026 12:00 en El Salvador (UTC-6) = 18:00 UTC.
  const AHORA = new Date("2026-11-20T18:00:00.000Z");
  it.each([
    ["hoy: hora", "2026-11-20T16:42:00.000Z", "10:42"],
    ["hoy, temprano en El Salvador aunque en UTC sea el mismo día", "2026-11-20T06:05:00.000Z", "00:05"],
    ["ayer en El Salvador aunque en UTC ya sea hoy", "2026-11-20T05:59:00.000Z", "Ayer"],
    ["ayer", "2026-11-19T15:00:00.000Z", "Ayer"],
    ["este año: día y mes", "2026-11-16T15:00:00.000Z", "16/11"],
    ["año anterior: fecha completa", "2025-12-31T15:00:00.000Z", "31/12/2025"],
  ])("fecha relativa (%s)", (_caso, iso, esperado) => {
    expect(formatearFechaBandeja(iso, AHORA)).toBe(esperado);
  });

  it("«Ayer» también cruza el cambio de mes y de año", () => {
    expect(formatearFechaBandeja("2026-12-31T18:00:00.000Z", new Date("2027-01-01T18:00:00.000Z"))).toBe("Ayer");
  });
});
