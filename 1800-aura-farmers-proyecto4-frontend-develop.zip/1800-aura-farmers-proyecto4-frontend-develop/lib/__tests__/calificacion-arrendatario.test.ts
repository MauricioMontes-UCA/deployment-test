import { describe, expect, it } from "vitest";
import {
  MENSAJES_ERROR_ARRENDATARIO,
  armarPayloadArrendatario,
  calificacionValida,
  clasificarErrorArrendatario,
  formatearPromedio,
  leerConsultaCalificacion,
  leerResumenCalificacion,
  textoTotalCalificaciones,
} from "@/lib/calificacion-arrendatario";

const texto = (n: number) => "a".repeat(n);

describe("calificacionValida", () => {
  it("acepta enteros de 1 a 5 y rechaza 0, 6, negativos, decimales y no números", () => {
    expect([1, 2, 3, 4, 5].every((p) => calificacionValida({ puntuacion: p, comentario: "" }))).toBe(true);
    for (const p of [0, 6, -1, 3.5, Number.NaN]) {
      expect(calificacionValida({ puntuacion: p, comentario: "" })).toBe(false);
    }
    expect(calificacionValida({ puntuacion: "4" as unknown as number, comentario: "" })).toBe(false);
  });

  it("el comentario es opcional y cuenta hasta 500 caracteres tras recortar", () => {
    expect(calificacionValida({ puntuacion: 4, comentario: texto(500) })).toBe(true);
    expect(calificacionValida({ puntuacion: 4, comentario: `  ${texto(500)}  ` })).toBe(true);
    expect(calificacionValida({ puntuacion: 4, comentario: texto(501) })).toBe(false);
    // Por code point, como el backend: 500 emojis caben.
    expect(calificacionValida({ puntuacion: 4, comentario: "😀".repeat(500) })).toBe(true);
    expect(calificacionValida({ puntuacion: 4, comentario: "😀".repeat(501) })).toBe(false);
  });
});

describe("armarPayloadArrendatario", () => {
  it("arma exactamente { puntuacion, comentario } con el comentario recortado", () => {
    expect(armarPayloadArrendatario({ puntuacion: 5, comentario: "  Cuidó muy bien la cámara.  " })).toStrictEqual({
      puntuacion: 5,
      comentario: "Cuidó muy bien la cámara.",
    });
  });

  it("omite el comentario vacío o de solo espacios (sin la propiedad)", () => {
    for (const comentario of ["", "   \n "]) {
      const payload = armarPayloadArrendatario({ puntuacion: 3, comentario });
      expect(payload).toStrictEqual({ puntuacion: 3 });
      expect(Object.keys(payload!)).toEqual(["puntuacion"]);
    }
  });

  it("no envía propiedades extra", () => {
    const conExtras = { puntuacion: 2, comentario: "Ok", tipo: "ARRENDATARIO", autorId: "x" } as unknown as {
      puntuacion: number;
      comentario: string;
    };
    expect(armarPayloadArrendatario(conExtras)).toStrictEqual({ puntuacion: 2, comentario: "Ok" });
  });

  it("devuelve null si la calificación no es válida y no modifica la entrada", () => {
    expect(armarPayloadArrendatario({ puntuacion: 0, comentario: "" })).toBeNull();
    expect(armarPayloadArrendatario({ puntuacion: 4, comentario: texto(501) })).toBeNull();
    const entrada = Object.freeze({ puntuacion: 4, comentario: "  Hola  " });
    armarPayloadArrendatario(entrada);
    expect(entrada).toStrictEqual({ puntuacion: 4, comentario: "  Hola  " });
  });
});

describe("clasificarErrorArrendatario", () => {
  it.each([
    [400, "Revisa la puntuación y el comentario.", false],
    [403, "No tienes permiso para calificar esta reserva.", false],
    [404, "No encontramos esa reserva.", false],
    [409, "Ya calificaste al arrendatario en esta reserva.", true],
    [422, "Solo puedes calificar reservas finalizadas dentro de los 14 días posteriores a la devolución.", true],
    [500, "No pudimos enviar la calificación. Intenta de nuevo.", false],
  ] as const)("%i → mensaje exacto de FE-16.1", (status, mensaje, bloqueante) => {
    const error = clasificarErrorArrendatario(status);
    expect(error.mensaje).toBe(mensaje);
    expect(error.bloqueante).toBe(bloqueante);
  });

  it("red (null) y códigos desconocidos usan el genérico de FE-16.1, no el de H15", () => {
    for (const status of [null, 0, 401, 502, 503]) {
      expect(clasificarErrorArrendatario(status).mensaje).toBe(
        "No pudimos enviar la calificación. Intenta de nuevo.",
      );
    }
    expect(MENSAJES_ERROR_ARRENDATARIO.servidor).not.toBe("No pudimos enviar tu reseña. Intenta de nuevo.");
  });
});

describe("leerResumenCalificacion", () => {
  it("lee promedio y total de la respuesta 201", () => {
    expect(
      leerResumenCalificacion({ resenaId: "r1", promedioArrendatario: 4.6, totalCalificaciones: 7, creadaEn: "…" }),
    ).toEqual({ promedioArrendatario: 4.6, totalCalificaciones: 7 });
  });

  it("no inventa datos: lo que no viene como número válido queda en null", () => {
    expect(leerResumenCalificacion(null)).toEqual({ promedioArrendatario: null, totalCalificaciones: null });
    expect(leerResumenCalificacion({ promedioArrendatario: "4.6", totalCalificaciones: 2.5 })).toEqual({
      promedioArrendatario: null,
      totalCalificaciones: null,
    });
    expect(leerResumenCalificacion({ promedioArrendatario: Number.NaN, totalCalificaciones: -1 })).toEqual({
      promedioArrendatario: null,
      totalCalificaciones: null,
    });
  });
});

describe("leerConsultaCalificacion (GET de BE-16.2)", () => {
  const resena = {
    resenaId: "9b1c2d3e-4f50-4a6b-8c7d-0e1f2a3b4c5d",
    puntuacion: 4,
    comentario: "Buen comportamiento",
    creadaEn: "2026-11-20T15:00:00.000Z",
  };
  const conResena = { resena, promedioArrendatario: 4.5, totalCalificaciones: 2 };

  it("con calificación: la reseña, el promedio y el total, tal cual", () => {
    expect(leerConsultaCalificacion(conResena)).toEqual(conResena);
  });

  it("sin calificación ni historial: reseña null, promedio null y total 0", () => {
    expect(leerConsultaCalificacion({ resena: null, promedioArrendatario: null, totalCalificaciones: 0 })).toEqual({
      resena: null,
      promedioArrendatario: null,
      totalCalificaciones: 0,
    });
  });

  it("sin reseña en esta reserva conserva el promedio y el total de otras reservas", () => {
    expect(leerConsultaCalificacion({ resena: null, promedioArrendatario: 3.7, totalCalificaciones: 3 })).toEqual({
      resena: null,
      promedioArrendatario: 3.7,
      totalCalificaciones: 3,
    });
  });

  it("comentario null se conserva como null", () => {
    expect(leerConsultaCalificacion({ ...conResena, resena: { ...resena, comentario: null } })?.resena?.comentario).toBeNull();
  });

  it("no copia campos extra del backend", () => {
    const leida = leerConsultaCalificacion({ ...conResena, autorId: "u2", resena: { ...resena, autorId: "u2" } });
    expect(leida).toEqual(conResena);
  });

  it.each([
    ["null", null],
    ["un arreglo", []],
    ["sin la clave resena", { promedioArrendatario: null, totalCalificaciones: 0 }],
    ["resena undefined", { resena: undefined, promedioArrendatario: null, totalCalificaciones: 0 }],
    ["total ausente", { resena: null, promedioArrendatario: null }],
    ["total negativo", { resena: null, promedioArrendatario: null, totalCalificaciones: -1 }],
    ["total decimal", { resena: null, promedioArrendatario: 4, totalCalificaciones: 1.5 }],
    ["total como texto", { resena: null, promedioArrendatario: 4, totalCalificaciones: "2" }],
    ["promedio con total 0", { resena: null, promedioArrendatario: 0, totalCalificaciones: 0 }],
    ["promedio null con total 2", { resena: null, promedioArrendatario: null, totalCalificaciones: 2 }],
    ["promedio fuera de 1 a 5", { resena: null, promedioArrendatario: 5.5, totalCalificaciones: 2 }],
    ["promedio NaN", { resena: null, promedioArrendatario: Number.NaN, totalCalificaciones: 2 }],
    ["reseña con total 0", { resena, promedioArrendatario: null, totalCalificaciones: 0 }],
    ["reseña sin id", { ...conResena, resena: { ...resena, resenaId: "" } }],
    ["puntuación 0", { ...conResena, resena: { ...resena, puntuacion: 0 } }],
    ["puntuación decimal", { ...conResena, resena: { ...resena, puntuacion: 4.5 } }],
    ["comentario numérico", { ...conResena, resena: { ...resena, comentario: 3 } }],
    ["fecha inválida", { ...conResena, resena: { ...resena, creadaEn: "ayer" } }],
    ["reseña como texto", { ...conResena, resena: "sí" }],
  ])("respuesta inválida (%s): null", (_caso, datos) => {
    expect(leerConsultaCalificacion(datos)).toBeNull();
  });
});

describe("formato", () => {
  it("el promedio siempre lleva un decimal y punto", () => {
    expect(formatearPromedio(4)).toBe("4.0");
    expect(formatearPromedio(4.6)).toBe("4.6");
    expect(formatearPromedio(5)).toBe("5.0");
    expect(formatearPromedio(1)).toBe("1.0");
    expect(formatearPromedio(0)).toBe("0.0");
  });

  it("total de calificaciones en singular y plural", () => {
    expect(textoTotalCalificaciones(1)).toBe("1 calificación");
    expect(textoTotalCalificaciones(7)).toBe("7 calificaciones");
    expect(textoTotalCalificaciones(0)).toBe("0 calificaciones");
  });
});
