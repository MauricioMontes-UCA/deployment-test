import { describe, expect, it } from "vitest";
import {
  MENSAJES_RANGO,
  consultaDePeriodo,
  periodoFijo,
  validarRango,
} from "@/lib/periodo-reporte";

describe("periodoFijo", () => {
  it.each([
    ["ultimo-mes", "ULTIMO_MES"],
    ["ultimos-3-meses", "ULTIMOS_3_MESES"],
    ["ultimo-anio", "ULTIMO_ANIO"],
  ] as const)("%s se envía como %s", (opcion, periodo) => {
    expect(periodoFijo(opcion)).toEqual({ periodo });
  });
});

describe("validarRango", () => {
  it("acepta un rango válido", () => {
    expect(validarRango("2026-08-01", "2026-10-31")).toBeNull();
  });

  it("acepta un solo día y un rango de exactamente 365 días", () => {
    expect(validarRango("2026-11-18", "2026-11-18")).toBeNull();
    expect(validarRango("2025-11-19", "2026-11-18")).toBeNull();
  });

  it.each([
    ["", "2026-10-31"],
    ["2026-08-01", ""],
    ["   ", "  "],
  ])("pide completar las fechas (desde «%s», hasta «%s»)", (desde, hasta) => {
    expect(validarRango(desde, hasta)).toBe(MENSAJES_RANGO.incompleto);
  });

  it.each([
    ["01/08/2026", "2026-10-31"],
    ["2026-08-01", "mañana"],
    ["2026-02-30", "2026-03-10"],
  ])("rechaza el formato (desde «%s», hasta «%s»)", (desde, hasta) => {
    expect(validarRango(desde, hasta)).toBe(MENSAJES_RANGO.formato);
  });

  it("rechaza una fecha final anterior a la inicial", () => {
    expect(validarRango("2026-08-01", "2026-07-01")).toBe(
      "La fecha final no puede ser anterior a la inicial.",
    );
  });

  it("rechaza un rango de más de 365 días", () => {
    expect(validarRango("2025-11-18", "2026-11-18")).toBe(
      "El rango no puede ser mayor a 365 días.",
    );
  });
});

describe("consultaDePeriodo", () => {
  it("un periodo fijo solo envía `periodo`", () => {
    expect(consultaDePeriodo({ periodo: "ULTIMOS_3_MESES" }).toString()).toBe(
      "periodo=ULTIMOS_3_MESES",
    );
  });

  it("un rango envía también `desde` y `hasta`", () => {
    expect(
      consultaDePeriodo({ periodo: "RANGO", desde: "2026-08-01", hasta: "2026-10-31" }).toString(),
    ).toBe("periodo=RANGO&desde=2026-08-01&hasta=2026-10-31");
  });
});
