// @vitest-environment node
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { obtenerTokens } from "@/lib/sesion";
import { obtenerUsuarioActual } from "@/lib/usuario-actual";

vi.mock("@/lib/sesion", () => ({ obtenerTokens: vi.fn() }));
// `cache` de React solo memoriza dentro de un render de servidor; aquí cada
// llamada debe ir a la API.
vi.mock("react", async (original) => ({
  ...(await original<typeof import("react")>()),
  cache: <T,>(fn: T) => fn,
}));

const API = "http://api.test/api/v1";
const fetchSimulado = vi.fn();

const usuarioApi = {
  id: "10000000-0000-4000-8000-000000000001",
  nombreUsuario: "mariana_rivas",
  email: "mariana@example.com",
  rol: "ARRENDADOR",
  isActive: true,
  createdAt: "2026-11-01T00:00:00.000Z",
};

beforeEach(() => {
  vi.stubEnv("API_URL", API);
  vi.mocked(obtenerTokens).mockResolvedValue({ acceso: "token-de-prueba", refresh: undefined });
  fetchSimulado.mockReset();
  vi.stubGlobal("fetch", fetchSimulado);
});

afterEach(() => {
  vi.unstubAllEnvs();
  vi.unstubAllGlobals();
});

describe("obtenerUsuarioActual", () => {
  it("pide /auth/me con el token y devuelve solo lo que usa la interfaz", async () => {
    fetchSimulado.mockResolvedValue(new Response(JSON.stringify(usuarioApi), { status: 200 }));

    expect(await obtenerUsuarioActual()).toEqual({
      estado: "ok",
      usuario: {
        id: usuarioApi.id,
        nombreUsuario: "mariana_rivas",
        email: "mariana@example.com",
        rol: "ARRENDADOR",
        createdAt: "2026-11-01T00:00:00.000Z",
      },
    });
    const [destino, opciones] = fetchSimulado.mock.calls[0];
    expect(String(destino)).toBe(`${API}/auth/me`);
    expect(opciones.headers).toEqual({ Authorization: "Bearer token-de-prueba" });
  });

  it("sin cookie de sesión no llama a la API", async () => {
    vi.mocked(obtenerTokens).mockResolvedValue({ acceso: undefined, refresh: undefined });
    expect(await obtenerUsuarioActual()).toEqual({ estado: "sin-sesion" });
    expect(fetchSimulado).not.toHaveBeenCalled();
  });

  it("con 401 trata la sesión como vencida", async () => {
    fetchSimulado.mockResolvedValue(new Response("{}", { status: 401 }));
    expect(await obtenerUsuarioActual()).toEqual({ estado: "sin-sesion" });
  });

  it.each([
    ["un 500", () => fetchSimulado.mockResolvedValue(new Response("{}", { status: 500 }))],
    ["la red caída", () => fetchSimulado.mockRejectedValue(new TypeError("fetch failed"))],
  ])("con %s devuelve error", async (_caso, preparar) => {
    preparar();
    expect(await obtenerUsuarioActual()).toEqual({ estado: "error" });
  });
});
