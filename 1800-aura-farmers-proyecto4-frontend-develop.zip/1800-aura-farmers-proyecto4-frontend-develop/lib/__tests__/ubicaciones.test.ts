import { describe, expect, it } from "vitest";
import {
  DEPARTAMENTOS,
  MUNICIPIOS_POR_DEPARTAMENTO,
  esDepartamento,
  municipiosDe,
} from "@/lib/ubicaciones";

describe("ubicaciones", () => {
  it("tiene los 14 departamentos y los 262 municipios tradicionales", () => {
    expect(DEPARTAMENTOS).toHaveLength(14);
    const total = Object.values(MUNICIPIOS_POR_DEPARTAMENTO).reduce((suma, lista) => suma + lista.length, 0);
    expect(total).toBe(262);
  });

  it("no repite municipios dentro de un departamento", () => {
    for (const lista of Object.values(MUNICIPIOS_POR_DEPARTAMENTO)) {
      expect(new Set(lista).size).toBe(lista.length);
    }
  });

  it.each([
    ["San Salvador", "Soyapango"],
    ["La Libertad", "Antiguo Cuscatlán"],
    ["La Libertad", "Santa Tecla"],
    ["Cuscatlán", "Suchitoto"],
    ["Morazán", "Perquín"],
    ["Santa Ana", "Metapán"],
  ])("escribe %s › %s igual que los bienes del backend", (departamento, municipio) => {
    expect(municipiosDe(departamento)).toContain(municipio);
  });

  it("un texto que no es departamento no tiene municipios", () => {
    expect(esDepartamento("Guatemala")).toBe(false);
    expect(esDepartamento("toString")).toBe(false);
    expect(municipiosDe("Guatemala")).toEqual([]);
  });
});
