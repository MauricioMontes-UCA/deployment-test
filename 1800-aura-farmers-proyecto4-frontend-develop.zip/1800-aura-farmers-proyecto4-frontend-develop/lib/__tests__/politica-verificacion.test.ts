import { afterEach, describe, expect, it, vi } from "vitest";
import {
  MENSAJES_POLITICA,
  actualizarPolitica,
  clasificarEstado,
  consultarPolitica,
} from "@/lib/politica-verificacion";

const BIEN = "10000000-0000-4000-8000-000000000001";

function responder(status: number, cuerpo: unknown = {}) {
  const fetchSimulado = vi.fn().mockResolvedValue(
    new Response(JSON.stringify(cuerpo), { status, headers: { "Content-Type": "application/json" } }),
  );
  vi.stubGlobal("fetch", fetchSimulado);
  return fetchSimulado;
}

afterEach(() => vi.unstubAllGlobals());

describe("clasificarEstado", () => {
  it.each([
    [401, "sesion"],
    [403, "prohibido"],
    [404, "no-encontrado"],
    [400, "general"],
    [500, "general"],
    [502, "general"],
  ])("%i es %s", (status, tipo) => {
    expect(clasificarEstado(status)).toBe(tipo);
  });
});

describe("consultarPolitica", () => {
  it("devuelve la política del bien", async () => {
    const fetchSimulado = responder(200, { bienId: BIEN, soloVerificados: true });
    expect(await consultarPolitica(BIEN)).toEqual({
      ok: true,
      politica: { bienId: BIEN, soloVerificados: true },
    });
    expect(fetchSimulado.mock.calls[0][0]).toBe(`/api/bienes/${BIEN}/politica-verificacion`);
  });

  it("trata una respuesta sin el formato esperado como fallo general", async () => {
    responder(200, { otra: "cosa" });
    expect(await consultarPolitica(BIEN)).toEqual({
      ok: false,
      tipo: "general",
      mensaje: MENSAJES_POLITICA.general,
    });
  });

  it("marca el 401 como sesión vencida", async () => {
    responder(401);
    expect(await consultarPolitica(BIEN)).toMatchObject({ ok: false, tipo: "sesion" });
  });

  it("marca el 404", async () => {
    responder(404);
    expect(await consultarPolitica(BIEN)).toMatchObject({ ok: false, tipo: "no-encontrado" });
  });
});

describe("actualizarPolitica", () => {
  it("envía PUT con soloVerificados", async () => {
    const fetchSimulado = responder(200, { bienId: BIEN, soloVerificados: false });
    const resultado = await actualizarPolitica(BIEN, false);
    expect(resultado).toMatchObject({ ok: true, politica: { soloVerificados: false } });
    const init = fetchSimulado.mock.calls[0][1];
    expect(init.method).toBe("PUT");
    expect(JSON.parse(init.body)).toEqual({ soloVerificados: false });
  });

  it.each([
    "El bien no es tuyo.",
    "Debes estar verificado para exigir usuarios verificados.",
    "No tienes permiso para realizar esta acción.",
  ])("muestra el motivo del 403: %s", async (message) => {
    responder(403, { message });
    expect(await actualizarPolitica(BIEN, true)).toEqual({ ok: false, tipo: "prohibido", mensaje: message });
  });

  it("usa el texto de respaldo si el 403 no trae motivo", async () => {
    responder(403, { statusCode: 403 });
    expect(await actualizarPolitica(BIEN, true)).toEqual({
      ok: false,
      tipo: "prohibido",
      mensaje: MENSAJES_POLITICA.prohibido,
    });
  });

  it("explica el fallo de red", async () => {
    vi.stubGlobal("fetch", vi.fn().mockRejectedValue(new TypeError("red")));
    expect(await actualizarPolitica(BIEN, true)).toMatchObject({
      ok: false,
      tipo: "general",
      mensaje: MENSAJES_POLITICA.general,
    });
  });
});
