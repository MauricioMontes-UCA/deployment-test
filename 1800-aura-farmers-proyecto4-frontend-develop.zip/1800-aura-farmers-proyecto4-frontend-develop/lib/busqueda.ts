import type { BienEncontrado } from "./bienes";
import { CATEGORIAS_POR_TIPO, esTipoBien, type TipoBien } from "./catalogos/bienes";

/**
 * Filtros de la búsqueda (FE-4.1). Los números y las fechas se guardan como
 * el texto de la URL, para que ir y volver de la URL no los cambie.
 */
export type FiltrosBusqueda = {
  precioMin?: string;
  precioMax?: string;
  tipo?: TipoBien;
  categoria?: string;
  /** Solo con tipo Propiedad. */
  capacidadMin?: string;
  /** AAAA-MM-DD; va junto con `fechaFin`. */
  fechaInicio?: string;
  fechaFin?: string;
};

/** Criterios de la búsqueda que viven en la URL de /buscar (FE-3.1 y FE-4.1). */
export type CriteriosBusqueda = FiltrosBusqueda & {
  q?: string;
  departamento?: string;
  municipio?: string;
};

/** Largo máximo del texto de búsqueda: el backend responde 400 si es mayor. */
export const MAX_LARGO_TEXTO_BUSQUEDA = 100;

/** Resultados por página, el tamaño por defecto del backend. */
export const TAMANO_PAGINA = 20;

/** Los filtros, en el orden en que van en la URL y en los chips. */
export const CAMPOS_DE_FILTRO = [
  "precioMin",
  "precioMax",
  "tipo",
  "categoria",
  "capacidadMin",
  "fechaInicio",
  "fechaFin",
] as const satisfies readonly (keyof FiltrosBusqueda)[];

/**
 * Parámetros de búsqueda que el puente `/api/bienes` reenvía al backend, en el
 * orden en que van en la URL.
 */
export const PARAMETROS_DE_BUSQUEDA = [
  "q",
  "departamento",
  "municipio",
  ...CAMPOS_DE_FILTRO,
] as const satisfies readonly (keyof CriteriosBusqueda)[];

/**
 * Criterios como parámetros de URL, en el orden de `PARAMETROS_DE_BUSQUEDA`.
 * Los vacíos se omiten y el texto se recorta. Un municipio sin departamento
 * no se envía.
 */
function parametrosDeBusqueda(criterios: CriteriosBusqueda) {
  const consulta = new URLSearchParams();
  for (const campo of PARAMETROS_DE_BUSQUEDA) {
    const valor = criterios[campo]?.trim();
    if (!valor) continue;
    if (campo === "municipio" && !criterios.departamento) continue;
    consulta.set(campo, valor);
  }
  return consulta;
}

/** URL de /buscar con los criterios como parámetros. */
export function urlDeBusqueda(criterios: CriteriosBusqueda): string {
  const cadena = parametrosDeBusqueda(criterios).toString();
  return cadena ? `/buscar?${cadena}` : "/buscar";
}

/** `searchParams` de una página: un parámetro repetido llega como lista. */
export type ParametrosDeUrl = Record<string, string | string[] | undefined>;

const PRECIO = /^\d+(\.\d{1,2})?$/;
const ENTERO_POSITIVO = /^[1-9]\d*$/;
const FORMATO_DIA = /^\d{4}-\d{2}-\d{2}$/;

/** Sin tildes ni mayúsculas, para comparar categorías igual que el backend. */
const normalizar = (texto: string) =>
  texto.normalize("NFD").replace(/\p{Diacritic}/gu, "").toLowerCase();

const TODAS_LAS_CATEGORIAS = [...CATEGORIAS_POR_TIPO.PROPIEDAD, ...CATEGORIAS_POR_TIPO.EQUIPO];

/** Categorías que se ofrecen para un tipo; sin tipo, todas. */
export function categoriasDe(tipo?: TipoBien): readonly string[] {
  return tipo ? CATEGORIAS_POR_TIPO[tipo] : TODAS_LAS_CATEGORIAS;
}

/**
 * La categoría escrita como en el catálogo («salon de eventos» → «Salón de
 * eventos»), igual que la normaliza el backend, o `undefined` si no existe.
 */
export function categoriaDelCatalogo(valor: string): string | undefined {
  const clave = normalizar(valor);
  return TODAS_LAS_CATEGORIAS.find((categoria) => normalizar(categoria) === clave);
}

/**
 * Criterios a partir de los `searchParams` de /buscar. Un parámetro repetido
 * toma su primer valor y los vacíos se descartan. Los valores que el backend
 * rechazaría por su forma (un precio que no es número, un tipo inventado, una
 * fecha mal escrita) se ignoran, para que una URL editada a mano siga
 * mostrando resultados. Las combinaciones inválidas (mínimo mayor que el
 * máximo, una sola fecha) se dejan pasar: el backend responde 400 y la página
 * muestra «Revisa los filtros marcados.».
 */
export function criteriosDesdeUrl(parametros: ParametrosDeUrl): CriteriosBusqueda {
  const leer = (campo: string) => {
    const valor = parametros[campo];
    return (Array.isArray(valor) ? valor[0] : valor)?.trim() || undefined;
  };

  const criterios: CriteriosBusqueda = {};
  const q = leer("q")?.slice(0, MAX_LARGO_TEXTO_BUSQUEDA).trim();
  if (q) criterios.q = q;
  const departamento = leer("departamento");
  if (departamento) {
    criterios.departamento = departamento;
    const municipio = leer("municipio");
    if (municipio) criterios.municipio = municipio;
  }

  for (const campo of ["precioMin", "precioMax"] as const) {
    const valor = leer(campo);
    if (valor && PRECIO.test(valor)) criterios[campo] = valor;
  }
  const tipo = leer("tipo");
  if (tipo && esTipoBien(tipo)) criterios.tipo = tipo;
  const categoria = leer("categoria");
  const delCatalogo = categoria && categoriaDelCatalogo(categoria);
  if (delCatalogo) criterios.categoria = delCatalogo;
  // La capacidad es solo de propiedades, igual que en el panel: sin tipo
  // descartaría en silencio los equipos y con Equipo no dejaría ningún bien.
  const capacidadMin = leer("capacidadMin");
  if (capacidadMin && ENTERO_POSITIVO.test(capacidadMin) && criterios.tipo === "PROPIEDAD") {
    criterios.capacidadMin = capacidadMin;
  }
  for (const campo of ["fechaInicio", "fechaFin"] as const) {
    const valor = leer(campo);
    if (valor && FORMATO_DIA.test(valor)) criterios[campo] = valor;
  }
  return criterios;
}

/** Los criterios sin filtros: conserva el texto y la ubicación. */
export function sinFiltros({ q, departamento, municipio }: CriteriosBusqueda): CriteriosBusqueda {
  return { q, departamento, municipio };
}

/** Un filtro activo, como chip: su texto y los campos que quita. */
export type ChipDeBusqueda = {
  texto: string;
  campos: (keyof FiltrosBusqueda)[];
};

const PRECIO_CHIP = (valor: string) => `$${Number(valor).toLocaleString("en-US")}`;

/** «20/11» a partir de «2026-11-20». */
const DIA_CHIP = (fecha: string) => `${fecha.slice(8, 10)}/${fecha.slice(5, 7)}`;

const NOMBRE_TIPO: Record<TipoBien, string> = { PROPIEDAD: "Propiedad", EQUIPO: "Equipo" };

/**
 * Chips de los filtros activos, en el orden del diseño: tipo, categoría,
 * precio, capacidad y fechas. El rango de precio y el de fechas son un chip
 * cada uno.
 */
export function chipsDeFiltros(criterios: CriteriosBusqueda): ChipDeBusqueda[] {
  const { precioMin, precioMax, tipo, categoria, capacidadMin, fechaInicio, fechaFin } = criterios;
  const chips: ChipDeBusqueda[] = [];
  if (tipo) {
    // Quitar «Propiedad» también quita la capacidad, que solo aplica a ese tipo.
    const campos: ChipDeBusqueda["campos"] =
      tipo === "PROPIEDAD" && capacidadMin ? ["tipo", "capacidadMin"] : ["tipo"];
    chips.push({ texto: NOMBRE_TIPO[tipo], campos });
  }
  if (categoria) chips.push({ texto: categoria, campos: ["categoria"] });
  if (precioMin && precioMax) {
    chips.push({
      texto: `${PRECIO_CHIP(precioMin)} a ${PRECIO_CHIP(precioMax)}`,
      campos: ["precioMin", "precioMax"],
    });
  } else if (precioMin) {
    chips.push({ texto: `Desde ${PRECIO_CHIP(precioMin)}`, campos: ["precioMin"] });
  } else if (precioMax) {
    chips.push({ texto: `Hasta ${PRECIO_CHIP(precioMax)}`, campos: ["precioMax"] });
  }
  if (capacidadMin) chips.push({ texto: `${capacidadMin}+ personas`, campos: ["capacidadMin"] });
  if (fechaInicio && fechaFin) {
    chips.push({
      texto: `${DIA_CHIP(fechaInicio)} a ${DIA_CHIP(fechaFin)}`,
      campos: ["fechaInicio", "fechaFin"],
    });
  } else if (fechaInicio || fechaFin) {
    // Una sola fecha llega solo en una URL editada a mano (el backend la
    // rechaza); el chip deja quitarla.
    const fecha = (fechaInicio ?? fechaFin)!;
    chips.push({
      texto: `${fechaInicio ? "Desde" : "Hasta"} ${DIA_CHIP(fecha)}`,
      campos: [fechaInicio ? "fechaInicio" : "fechaFin"],
    });
  }
  return chips;
}

/** Indica si la búsqueda tiene algún filtro activo. */
export function hayFiltros(criterios: CriteriosBusqueda): boolean {
  return CAMPOS_DE_FILTRO.some((campo) => criterios[campo]);
}

/** Respuesta de `GET /bienes` (BE-3.1). */
export type PaginaDeBienes = {
  pagina: number;
  tamanoPagina: number;
  total: number;
  hayMas: boolean;
  resultados: BienEncontrado[];
};

/** Valida la forma de la respuesta antes de usarla. */
export function esPaginaDeBienes(valor: unknown): valor is PaginaDeBienes {
  if (typeof valor !== "object" || valor === null) return false;
  const { pagina, total, hayMas, resultados } = valor as Record<string, unknown>;
  return (
    typeof pagina === "number" &&
    typeof total === "number" &&
    typeof hayMas === "boolean" &&
    Array.isArray(resultados)
  );
}

/**
 * La búsqueda falló. `status` es el código de la respuesta (0 si no hubo) y
 * `mensajes`, los del backend en un 400.
 */
export class ErrorDeBusqueda extends Error {
  constructor(
    public readonly status: number,
    public readonly mensajes: string[] = [],
  ) {
    super(mensajes[0] ?? `La búsqueda respondió ${status}.`);
    this.name = "ErrorDeBusqueda";
  }
}

/** `message` del backend: un texto o una lista (errores de validación). */
function mensajesDe(datos: unknown): string[] {
  const mensaje = (datos as { message?: unknown } | null)?.message;
  if (typeof mensaje === "string") return [mensaje];
  return Array.isArray(mensaje) ? mensaje.filter((m): m is string => typeof m === "string") : [];
}

/**
 * Una página de resultados, desde el navegador. Pasa por el puente
 * `/api/bienes` porque la URL del backend solo existe en el servidor. Lanza
 * `ErrorDeBusqueda` si la respuesta no es 2xx o no tiene la forma esperada.
 */
export async function buscarBienes(
  criterios: CriteriosBusqueda,
  pagina: number,
  signal?: AbortSignal,
): Promise<PaginaDeBienes> {
  const consulta = parametrosDeBusqueda(criterios);
  consulta.set("pagina", String(pagina));
  consulta.set("tamano", String(TAMANO_PAGINA));

  const respuesta = await fetch(`/api/bienes?${consulta}`, { signal });
  const datos: unknown = await respuesta.json().catch(() => null);
  if (!respuesta.ok) throw new ErrorDeBusqueda(respuesta.status, mensajesDe(datos));
  if (!esPaginaDeBienes(datos)) throw new ErrorDeBusqueda(respuesta.status);
  return datos;
}

/** Categorías destacadas en la portada, en el orden del diseño. */
export const CATEGORIAS_DESTACADAS = [
  "Salón de eventos",
  "Casa",
  "Apartamento",
  "Oficina",
  "Video y fotografía",
  "Audio y sonido",
  "Herramientas",
  "Mobiliario para eventos",
] as const;
