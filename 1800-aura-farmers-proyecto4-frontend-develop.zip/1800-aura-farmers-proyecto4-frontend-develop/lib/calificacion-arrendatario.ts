/**
 * Reglas de la calificación que el arrendador da al arrendatario de una reserva
 * finalizada (H16, FE-16.1).
 *
 * Reutiliza las reglas de reseñas de H15 (`lib/resenas.ts`): misma puntuación,
 * mismo límite de comentario contado igual que el backend y misma
 * clasificación de códigos HTTP. Aquí solo va lo propio de H16: una sola
 * calificación, sus mensajes (409 y 500 cambian) y la respuesta 201 con el
 * promedio del arrendatario.
 */

import {
  clasificarErrorResenas,
  esPuntuacionValida,
  excesoComentario,
  normalizarComentario,
  type CalificacionFormulario,
  type ErrorResenas,
  type Puntuacion,
  type TipoErrorResenas,
} from "@/lib/resenas";

/** Cuerpo exacto de `POST /reservas/:reservaId/resenas/arrendatario`: no admite campos extra. */
export type CalificarArrendatarioPayload = {
  puntuacion: Puntuacion;
  /** Ya recortado; se omite cuando queda vacío. */
  comentario?: string;
};

/**
 * Lo que la pantalla usa de la respuesta 201. `null` si el backend no lo
 * devolvió con la forma esperada: nunca se inventa un promedio ni un total.
 */
export type ResumenCalificacion = {
  promedioArrendatario: number | null;
  totalCalificaciones: number | null;
};

/** Resultado de enviar la calificación. `status` es `null` si falló la red o se agotó el tiempo. */
export type ResultadoCalificacion =
  | ({ ok: true } & ResumenCalificacion)
  | { ok: false; status: number | null };

/** Si la calificación está lista para enviarse: puntuación de 1 a 5 y comentario dentro del límite. */
export function calificacionValida({ puntuacion, comentario }: CalificacionFormulario): boolean {
  return esPuntuacionValida(puntuacion) && excesoComentario(comentario) === 0;
}

/**
 * Cuerpo de la solicitud con solo los campos que acepta el backend: recorta el
 * comentario y lo omite si queda vacío. Devuelve `null` si no es válido. No
 * modifica el objeto recibido.
 */
export function armarPayloadArrendatario(
  calificacion: CalificacionFormulario,
): CalificarArrendatarioPayload | null {
  if (!calificacionValida(calificacion)) return null;
  const puntuacion = calificacion.puntuacion as Puntuacion;
  const comentario = normalizarComentario(calificacion.comentario);
  return comentario === "" ? { puntuacion } : { puntuacion, comentario };
}

/** Mensajes de FE-16.1. Solo 409 y 500 difieren de los de H15. */
export const MENSAJES_ERROR_ARRENDATARIO: Record<TipoErrorResenas, string> = {
  validacion: "Revisa la puntuación y el comentario.",
  "sin-permiso": "No tienes permiso para calificar esta reserva.",
  "no-encontrada": "No encontramos esa reserva.",
  "ya-calificada": "Ya calificaste al arrendatario en esta reserva.",
  "fuera-de-plazo":
    "Solo puedes calificar reservas finalizadas dentro de los 14 días posteriores a la devolución.",
  servidor: "No pudimos enviar la calificación. Intenta de nuevo.",
};

/**
 * Traduce la respuesta fallida al mensaje de FE-16.1. Misma clasificación que
 * H15 (409 y 422 bloquean; red, 500 y códigos desconocidos son genéricos).
 */
export function clasificarErrorArrendatario(status: number | null): ErrorResenas {
  const error = clasificarErrorResenas(status);
  return { ...error, mensaje: MENSAJES_ERROR_ARRENDATARIO[error.tipo] };
}

/**
 * Lee `promedioArrendatario` y `totalCalificaciones` de la respuesta 201. Lo
 * que no venga como número válido queda en `null`.
 */
export function leerResumenCalificacion(datos: unknown): ResumenCalificacion {
  const registro = typeof datos === "object" && datos !== null ? (datos as Record<string, unknown>) : {};
  const { promedioArrendatario, totalCalificaciones } = registro;
  return {
    promedioArrendatario:
      typeof promedioArrendatario === "number" && Number.isFinite(promedioArrendatario)
        ? promedioArrendatario
        : null,
    totalCalificaciones:
      typeof totalCalificaciones === "number" &&
      Number.isInteger(totalCalificaciones) &&
      totalCalificaciones >= 0
        ? totalCalificaciones
        : null,
  };
}

/** Calificación ya registrada, tal como la devuelve `GET /reservas/:reservaId/resenas/arrendatario`. */
export type ResenaArrendatario = {
  resenaId: string;
  puntuacion: Puntuacion;
  /** `null` si se guardó sin comentario. */
  comentario: string | null;
  /** Fecha ISO de creación. */
  creadaEn: string;
};

/**
 * Respuesta 200 del GET (BE-16.2). El promedio y el total son los del
 * arrendatario en todas sus reservas, así que pueden existir aunque esta
 * reserva todavía no tenga reseña.
 */
export type ConsultaCalificacionArrendatario = {
  /** `null` si el arrendador todavía no calificó esta reserva. */
  resena: ResenaArrendatario | null;
  /** `null` solo si el arrendatario no tiene ninguna calificación. */
  promedioArrendatario: number | null;
  totalCalificaciones: number;
};

const esRegistro = (valor: unknown): valor is Record<string, unknown> =>
  typeof valor === "object" && valor !== null && !Array.isArray(valor);

function leerResena(datos: unknown): ResenaArrendatario | null {
  if (!esRegistro(datos)) return null;
  const { resenaId, puntuacion, comentario, creadaEn } = datos;
  if (
    typeof resenaId !== "string" ||
    resenaId === "" ||
    !esPuntuacionValida(puntuacion) ||
    (comentario !== null && typeof comentario !== "string") ||
    typeof creadaEn !== "string" ||
    Number.isNaN(Date.parse(creadaEn))
  ) {
    return null;
  }
  return { resenaId, puntuacion, comentario, creadaEn };
}

/**
 * Lee la respuesta 200 del GET de la calificación con el contrato de BE-16.2.
 * Devuelve `null` si la forma no es la esperada o es incoherente (un total
 * de 0 con promedio, una reseña sin calificaciones…): en ese caso la pantalla
 * no sabe si la reserva ya se calificó y no debe mostrar el formulario.
 */
export function leerConsultaCalificacion(datos: unknown): ConsultaCalificacionArrendatario | null {
  if (!esRegistro(datos) || !("resena" in datos)) return null;
  const { promedioArrendatario, totalCalificaciones: total } = datos;
  if (typeof total !== "number" || !Number.isInteger(total) || total < 0) return null;
  // Sin calificaciones no hay promedio; con alguna, es un número de 1 a 5.
  let promedio: number | null = null;
  if (total === 0) {
    if (promedioArrendatario !== null) return null;
  } else {
    if (typeof promedioArrendatario !== "number" || !(promedioArrendatario >= 1 && promedioArrendatario <= 5)) {
      return null;
    }
    promedio = promedioArrendatario;
  }
  const resena = datos.resena === null ? null : leerResena(datos.resena);
  if (datos.resena !== null && (!resena || total === 0)) return null;
  return { resena, promedioArrendatario: promedio, totalCalificaciones: total };
}

/**
 * Promedio siempre con un decimal y punto («4.0», «4.6»), como pide H16 y
 * muestra Figma. El backend ya lo redondea a un decimal y envía 4.0 como `4`.
 */
export function formatearPromedio(promedio: number): string {
  return promedio.toFixed(1);
}

/** «1 calificación» o «7 calificaciones». */
export function textoTotalCalificaciones(total: number): string {
  return `${total} ${total === 1 ? "calificación" : "calificaciones"}`;
}
