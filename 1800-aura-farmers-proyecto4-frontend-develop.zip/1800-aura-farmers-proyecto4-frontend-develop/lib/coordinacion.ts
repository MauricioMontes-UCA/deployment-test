import type { TonoInsignia } from "@/components/ui";
import type { Rol } from "@/lib/jwt";

/**
 * Coordinación de la entrega por reserva (H14, FE-14.1) y lectura del
 * contrato real de BE-14.1:
 *
 * - `GET /reservas/:id/conversacion` recupera o crea la conversación y trae el
 *   resumen de la reserva (estado, fechas, bien y participantes).
 * - `GET|POST /reservas/:id/conversacion/mensajes`: historial y envío.
 * - Solo se coordina con la reserva CONFIRMADA o EN_CURSO (422 en otro estado).
 */

export type EstadoReserva = "EN_COLA" | "CONFIRMADA" | "RECHAZADA" | "EN_CURSO" | "FINALIZADA" | "CANCELADA";

const ESTADOS: readonly string[] = ["EN_COLA", "CONFIRMADA", "RECHAZADA", "EN_CURSO", "FINALIZADA", "CANCELADA"];

/** Estados en los que la conversación se muestra y admite mensajes (Jira FE-14.1). */
export const ESTADOS_COORDINACION: readonly EstadoReserva[] = ["CONFIRMADA", "EN_CURSO"];

export const admiteCoordinacion = (estado: EstadoReserva) => ESTADOS_COORDINACION.includes(estado);

export const TEXTOS_COORDINACION = {
  /** Texto de H14 y del 422 del backend (Figma 30:1167 lo usa con punto final). */
  noPermitida: "La coordinación está disponible cuando la reserva está confirmada o en curso.",
  sinPermisoTitulo: "No tienes acceso a esta conversación.",
  sinPermisoMensaje: "Solo participan el arrendador y el arrendatario.",
  noEncontradaTitulo: "No encontramos esa reserva.",
  noEncontradaMensaje: "Revisa el enlace e intenta de nuevo.",
  vacioTitulo: "Aún no hay mensajes",
  vacioMensaje: "Acuerda aquí la fecha, la hora y el lugar de la entrega.",
} as const;

/**
 * Texto y tono de la insignia de estado. Mismos valores que `ESTADO_VISUAL` de
 * `lib/reservas/formato.ts` en develop (H6); al integrar AF-88 con develop
 * conviene usar ese.
 */
export const ESTADO_VISUAL: Record<EstadoReserva, { texto: string; tono: TonoInsignia }> = {
  EN_COLA: { texto: "En cola", tono: "neutro" },
  CONFIRMADA: { texto: "Confirmada", tono: "exito" },
  EN_CURSO: { texto: "En curso", tono: "marca" },
  FINALIZADA: { texto: "Finalizada", tono: "neutro" },
  RECHAZADA: { texto: "Rechazada", tono: "error" },
  CANCELADA: { texto: "Cancelada", tono: "advertencia" },
};

export const esEstadoReserva = (valor: unknown): valor is EstadoReserva =>
  typeof valor === "string" && ESTADOS.includes(valor);

const DIA = /^(\d{4})-(\d{2})-(\d{2})$/;
const MS_POR_DIA = 24 * 60 * 60 * 1000;
const aUtc = (dia: string) => {
  const p = DIA.exec(dia);
  return p ? Date.UTC(Number(p[1]), Number(p[2]) - 1, Number(p[3])) : null;
};
const formatearDia = (dia: string) => {
  const p = DIA.exec(dia);
  return p ? `${p[3]}/${p[2]}/${p[1]}` : dia;
};

/**
 * «24/11/2026 → 25/11/2026 · 2 días» (cuentan el día de inicio y el de fin),
 * como Figma 30:1048. Igual que `formatearFechas` de `lib/reservas/formato.ts`
 * en develop.
 */
export function formatearFechasReserva(inicio: string, fin: string): string {
  const desde = aUtc(inicio);
  const hasta = aUtc(fin);
  const rango = `${formatearDia(inicio)} → ${formatearDia(fin)}`;
  if (desde === null || hasta === null || hasta < desde) return rango;
  const dias = Math.round((hasta - desde) / MS_POR_DIA) + 1;
  return `${rango} · ${dias} ${dias === 1 ? "día" : "días"}`;
}

export type Participante = { id: string; nombreUsuario: string };

/** Respuesta de `GET /reservas/:id/conversacion` (`ConversacionReservaResponseDto`). */
export type ConversacionReserva = {
  id: string;
  reservaId: string;
  estado: EstadoReserva;
  /** AAAA-MM-DD. */
  fechaInicio: string;
  fechaFin: string;
  bien: { id: string; titulo: string };
  arrendador: Participante;
  arrendatario: Participante;
};

const esObjeto = (valor: unknown): valor is Record<string, unknown> =>
  typeof valor === "object" && valor !== null;
const leerParticipante = (valor: unknown): Participante | null =>
  esObjeto(valor) && typeof valor.id === "string" && typeof valor.nombreUsuario === "string"
    ? { id: valor.id, nombreUsuario: valor.nombreUsuario }
    : null;

/** Lee la conversación de la reserva, o `null` si le falta algo o algún campo tiene otro tipo. */
export function leerConversacionReserva(datos: unknown): ConversacionReserva | null {
  if (!esObjeto(datos) || !esObjeto(datos.bien)) return null;
  const { id, reservaId, estado, fechaInicio, fechaFin } = datos;
  const { id: bienId, titulo } = datos.bien;
  const arrendador = leerParticipante(datos.arrendador);
  const arrendatario = leerParticipante(datos.arrendatario);
  if (
    typeof id !== "string" ||
    typeof reservaId !== "string" ||
    !esEstadoReserva(estado) ||
    typeof fechaInicio !== "string" ||
    !DIA.test(fechaInicio) ||
    typeof fechaFin !== "string" ||
    !DIA.test(fechaFin) ||
    typeof bienId !== "string" ||
    typeof titulo !== "string" ||
    !arrendador ||
    !arrendatario
  ) {
    return null;
  }
  return { id, reservaId, estado, fechaInicio, fechaFin, bien: { id: bienId, titulo }, arrendador, arrendatario };
}

/** El participante que no es el usuario de la sesión (título «…con luis.perez»). */
export function otroParticipante(conversacion: ConversacionReserva, usuarioId: string): Participante {
  return conversacion.arrendador.id === usuarioId ? conversacion.arrendatario : conversacion.arrendador;
}

/**
 * Regreso mientras no exista `/reservas/[reservaId]`: la lista de reservas
 * que corresponde a cada rol.
 */
export function regresoPorRol(rol: Rol): { href: string; texto: string } {
  return rol === "ARRENDADOR"
    ? { href: "/reservas-recibidas", texto: "Volver a reservas recibidas" }
    : { href: "/reservas", texto: "Volver a mis reservas" };
}
