import { MENSAJES_VERIFICACION, esMiEstado, type MiEstado } from "./documento";

// Llamadas desde el navegador a los puentes `/api/verificaciones/*`. El token
// vive en una cookie httpOnly: estas rutas son las que lo agregan.

export type ResultadoConsulta =
  | { tipo: "ok"; estado: MiEstado }
  | { tipo: "sesion" }
  | { tipo: "error" };

export type ResultadoEnvio =
  | { tipo: "ok" }
  | { tipo: "sesion" }
  /** 400, 413 y 415: el mensaje viene del servicio. */
  | { tipo: "validacion"; mensaje: string }
  | { tipo: "conflicto"; mensaje: string }
  | { tipo: "error"; mensaje: string };

export async function consultarEstado(): Promise<ResultadoConsulta> {
  try {
    const respuesta = await fetch("/api/verificaciones/mi-estado", { cache: "no-store" });
    if (respuesta.status === 401) return { tipo: "sesion" };
    if (!respuesta.ok) return { tipo: "error" };
    const dato: unknown = await respuesta.json();
    return esMiEstado(dato) ? { tipo: "ok", estado: dato } : { tipo: "error" };
  } catch {
    return { tipo: "error" };
  }
}

/** Mensaje del servicio: Nest manda un texto o una lista de textos. */
function mensajeDelServicio(cuerpo: unknown): string | null {
  const mensaje = (cuerpo as { message?: unknown } | null)?.message;
  if (typeof mensaje === "string" && mensaje) return mensaje;
  if (Array.isArray(mensaje)) {
    const textos = mensaje.filter((m): m is string => typeof m === "string" && m !== "");
    if (textos.length) return textos.join(" ");
  }
  return null;
}

/** Traduce la respuesta del POST a lo que la pantalla necesita mostrar. */
export function resultadoDeEnvio(status: number, cuerpo: unknown): ResultadoEnvio {
  if (status >= 200 && status < 300) return { tipo: "ok" };
  if (status === 401) return { tipo: "sesion" };
  if (status === 409) return { tipo: "conflicto", mensaje: MENSAJES_VERIFICACION.enRevision };
  if (status === 400 || status === 413 || status === 415) {
    return {
      tipo: "validacion",
      mensaje: mensajeDelServicio(cuerpo) ?? MENSAJES_VERIFICACION.fallo,
    };
  }
  return { tipo: "error", mensaje: MENSAJES_VERIFICACION.fallo };
}

/**
 * Envía el documento como multipart (campo `documento`). Usa XMLHttpRequest
 * porque `fetch` no informa el avance de la subida.
 */
export function enviarDocumento(
  archivo: File,
  alAvanzar: (porcentaje: number) => void,
): Promise<ResultadoEnvio> {
  return new Promise((resolver) => {
    const peticion = new XMLHttpRequest();
    peticion.open("POST", "/api/verificaciones");
    peticion.upload.onprogress = (evento) => {
      if (evento.lengthComputable && evento.total > 0) {
        alAvanzar(Math.round((evento.loaded / evento.total) * 100));
      }
    };
    peticion.onload = () => {
      let cuerpo: unknown = null;
      try {
        cuerpo = JSON.parse(peticion.responseText);
      } catch {
        // Sin cuerpo JSON: se decide solo por el código.
      }
      resolver(resultadoDeEnvio(peticion.status, cuerpo));
    };
    peticion.onerror = () => resolver({ tipo: "error", mensaje: MENSAJES_VERIFICACION.fallo });
    peticion.ontimeout = peticion.onerror;
    const formulario = new FormData();
    formulario.append("documento", archivo);
    peticion.send(formulario);
  });
}
