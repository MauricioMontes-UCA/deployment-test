import { afterEach, describe, expect, it, vi } from "vitest";
import { consultarEstado, enviarDocumento, resultadoDeEnvio } from "./cliente";

describe("resultadoDeEnvio", () => {
  it("mapea cada código a lo que la pantalla muestra", () => {
    expect(resultadoDeEnvio(201, {})).toEqual({ tipo: "ok" });
    expect(resultadoDeEnvio(401, {})).toEqual({ tipo: "sesion" });
    expect(resultadoDeEnvio(409, {})).toEqual({
      tipo: "conflicto",
      mensaje: "Ya tienes un documento en revisión.",
    });
    expect(resultadoDeEnvio(413, { message: "El archivo supera 5 MB." })).toEqual({
      tipo: "validacion",
      mensaje: "El archivo supera 5 MB.",
    });
    expect(resultadoDeEnvio(415, { message: ["Formato no permitido. Usa JPG, PNG o PDF."] })).toEqual({
      tipo: "validacion",
      mensaje: "Formato no permitido. Usa JPG, PNG o PDF.",
    });
    expect(resultadoDeEnvio(500, {})).toEqual({
      tipo: "error",
      mensaje: "No pudimos enviar el documento. Intenta de nuevo.",
    });
  });

  it("usa el mensaje general si un 4xx de validación no trae texto", () => {
    expect(resultadoDeEnvio(400, null)).toMatchObject({ tipo: "validacion", mensaje: /No pudimos/ });
  });
});

describe("consultarEstado", () => {
  afterEach(() => vi.unstubAllGlobals());

  it("devuelve el estado, la sesión vencida o el error", async () => {
    const fetchMock = vi.fn();
    vi.stubGlobal("fetch", fetchMock);

    fetchMock.mockResolvedValueOnce(Response.json({ estado: "VERIFICADO", motivo: null }));
    expect(await consultarEstado()).toMatchObject({ tipo: "ok", estado: { estado: "VERIFICADO" } });

    fetchMock.mockResolvedValueOnce(new Response("{}", { status: 401 }));
    expect(await consultarEstado()).toEqual({ tipo: "sesion" });

    fetchMock.mockResolvedValueOnce(new Response("{}", { status: 500 }));
    expect(await consultarEstado()).toEqual({ tipo: "error" });

    fetchMock.mockRejectedValueOnce(new Error("red"));
    expect(await consultarEstado()).toEqual({ tipo: "error" });
  });
});

describe("enviarDocumento", () => {
  afterEach(() => vi.unstubAllGlobals());

  class XhrFalso {
    static ultimo: XhrFalso;
    status = 0;
    responseText = "";
    upload: { onprogress?: (e: { lengthComputable: boolean; loaded: number; total: number }) => void } = {};
    onload?: () => void;
    onerror?: () => void;
    ontimeout?: () => void;
    abierta?: [string, string];
    cuerpo?: FormData;
    constructor() {
      XhrFalso.ultimo = this;
    }
    open(metodo: string, url: string) {
      this.abierta = [metodo, url];
    }
    send(cuerpo: FormData) {
      this.cuerpo = cuerpo;
    }
  }

  it("sube el archivo en el campo documento e informa el avance", async () => {
    vi.stubGlobal("XMLHttpRequest", XhrFalso);
    const avances: number[] = [];
    const archivo = new File(["x"], "dui.png", { type: "image/png" });
    const promesa = enviarDocumento(archivo, (p) => avances.push(p));
    const xhr = XhrFalso.ultimo;

    expect(xhr.abierta).toEqual(["POST", "/api/verificaciones"]);
    expect((xhr.cuerpo?.get("documento") as File).name).toBe("dui.png");

    xhr.upload.onprogress?.({ lengthComputable: true, loaded: 60, total: 100 });
    xhr.status = 201;
    xhr.responseText = JSON.stringify({ estado: "EN_REVISION" });
    xhr.onload?.();

    expect(await promesa).toEqual({ tipo: "ok" });
    expect(avances).toEqual([60]);
  });

  it("falla con el mensaje general si la red se cae", async () => {
    vi.stubGlobal("XMLHttpRequest", XhrFalso);
    const promesa = enviarDocumento(new File(["x"], "a.png", { type: "image/png" }), () => {});
    XhrFalso.ultimo.onerror?.();
    expect(await promesa).toMatchObject({ tipo: "error", mensaje: /No pudimos enviar/ });
  });
});
