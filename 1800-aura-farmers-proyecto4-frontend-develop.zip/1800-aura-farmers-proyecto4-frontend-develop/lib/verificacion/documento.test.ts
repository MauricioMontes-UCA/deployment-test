import { describe, expect, it } from "vitest";
import {
  MAX_DOCUMENTO_BYTES,
  esMiEstado,
  formatearFecha,
  formatearTamano,
  validarDocumento,
} from "./documento";

describe("validarDocumento", () => {
  it("acepta JPG, PNG y PDF", () => {
    for (const type of ["image/jpeg", "image/png", "application/pdf"]) {
      expect(validarDocumento({ name: "dui", size: 1000, type })).toBeNull();
    }
  });

  it("rechaza otros formatos con el mensaje de la historia", () => {
    expect(validarDocumento({ name: "a.gif", size: 1000, type: "image/gif" })).toBe(
      "Formato no permitido. Usa JPG, PNG o PDF.",
    );
  });

  it("usa la extensión cuando el navegador no informa el tipo", () => {
    expect(validarDocumento({ name: "dui.PDF", size: 10, type: "" })).toBeNull();
    expect(validarDocumento({ name: "dui.exe", size: 10, type: "" })).toMatch(/Formato/);
  });

  it("acepta exactamente 5 MB y rechaza un byte más", () => {
    expect(validarDocumento({ name: "a.png", size: MAX_DOCUMENTO_BYTES, type: "image/png" })).toBeNull();
    expect(validarDocumento({ name: "a.png", size: MAX_DOCUMENTO_BYTES + 1, type: "image/png" })).toBe(
      "El archivo supera 5 MB.",
    );
  });

  it("rechaza archivos vacíos", () => {
    expect(validarDocumento({ name: "a.png", size: 0, type: "image/png" })).toMatch(/vacío/);
  });
});

describe("helpers", () => {
  it("reconoce la respuesta de mi-estado", () => {
    expect(esMiEstado({ estado: "RECHAZADO", motivo: "x" })).toBe(true);
    expect(esMiEstado({ estado: "OTRO" })).toBe(false);
    expect(esMiEstado(null)).toBe(false);
  });

  it("formatea la fecha en hora de El Salvador", () => {
    expect(formatearFecha("2026-11-18T21:12:00.000Z")).toBe("18/11/2026 15:12");
    expect(formatearFecha("no es fecha")).toBe("");
  });

  it("formatea el tamaño", () => {
    expect(formatearTamano(500)).toBe("500 B");
    expect(formatearTamano(2048)).toBe("2 KB");
    expect(formatearTamano(3 * 1024 * 1024)).toBe("3.0 MB");
  });
});
