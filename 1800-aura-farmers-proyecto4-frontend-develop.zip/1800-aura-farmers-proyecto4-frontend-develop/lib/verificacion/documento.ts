// Reglas de BE-17.1 que el cliente aplica antes de llamar al servicio.

export const MAX_DOCUMENTO_MB = 5;
export const MAX_DOCUMENTO_BYTES = MAX_DOCUMENTO_MB * 1024 * 1024;

const TIPOS_PERMITIDOS = ["image/jpeg", "image/png", "application/pdf"];
const EXTENSIONES_PERMITIDAS = /\.(jpe?g|png|pdf)$/i;

export const MENSAJES_VERIFICACION = {
  formato: "Formato no permitido. Usa JPG, PNG o PDF.",
  tamano: `El archivo supera ${MAX_DOCUMENTO_MB} MB.`,
  vacio: "El archivo está vacío. Usa JPG, PNG o PDF.",
  enviado: "Documento enviado. Está en revisión.",
  enRevision: "Ya tienes un documento en revisión.",
  fallo: "No pudimos enviar el documento. Intenta de nuevo.",
  consulta: "No pudimos consultar tu estado de verificación. Intenta de nuevo.",
  demorado: "Seguimos revisando tu documento. Vuelve en unos minutos.",
} as const;

/**
 * Devuelve el mensaje de error si el archivo no se puede enviar, o `null` si
 * es válido. El servidor vuelve a validar por el contenido real del archivo.
 */
export function validarDocumento(archivo: Pick<File, "name" | "size" | "type">): string | null {
  const formatoValido = archivo.type
    ? TIPOS_PERMITIDOS.includes(archivo.type)
    : EXTENSIONES_PERMITIDAS.test(archivo.name);
  if (!formatoValido) return MENSAJES_VERIFICACION.formato;
  if (archivo.size === 0) return MENSAJES_VERIFICACION.vacio;
  if (archivo.size > MAX_DOCUMENTO_BYTES) return MENSAJES_VERIFICACION.tamano;
  return null;
}

export const ESTADOS_VERIFICACION = ["NO_VERIFICADO", "EN_REVISION", "VERIFICADO", "RECHAZADO"] as const;
export type EstadoVerificacion = (typeof ESTADOS_VERIFICACION)[number];

/** Respuesta de `GET /verificaciones/mi-estado`. */
export type MiEstado = {
  estado: EstadoVerificacion;
  motivo: string | null;
  solicitudId: string | null;
  revisadoEn: string | null;
};

export function esMiEstado(dato: unknown): dato is MiEstado {
  if (typeof dato !== "object" || dato === null) return false;
  const { estado } = dato as { estado?: unknown };
  return ESTADOS_VERIFICACION.some((e) => e === estado);
}

export const TEXTO_ESTADO: Record<EstadoVerificacion, string> = {
  NO_VERIFICADO: "No verificado",
  EN_REVISION: "En revisión",
  VERIFICADO: "Verificado",
  RECHAZADO: "Rechazado",
};

// El backend y la interfaz trabajan en hora de El Salvador; fijar la zona evita
// que el servidor y el navegador pinten horas distintas.
const FORMATO_FECHA = new Intl.DateTimeFormat("es", {
  timeZone: "America/El_Salvador",
  day: "2-digit",
  month: "2-digit",
  year: "numeric",
  hour: "2-digit",
  minute: "2-digit",
  hour12: false,
});

/** «18/11/2026 15:12». */
export function formatearFecha(iso: string): string {
  const fecha = new Date(iso);
  if (Number.isNaN(fecha.getTime())) return "";
  return FORMATO_FECHA.format(fecha).replace(",", "");
}

export function formatearTamano(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}
