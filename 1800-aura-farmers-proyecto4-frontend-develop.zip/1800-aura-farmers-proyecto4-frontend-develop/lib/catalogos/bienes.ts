/**
 * Catálogos de bienes, iguales a los del backend (`src/bienes/constants`).
 * Las categorías se envían con el mismo texto que ve el usuario («Salón de
 * eventos»), que es como las guarda y las valida el backend.
 */

import type { UnidadCobro } from "@/lib/bienes";

export type { UnidadCobro };
export type TipoBien = "PROPIEDAD" | "EQUIPO";

export const TIPOS_BIEN: { valor: TipoBien; etiqueta: string }[] = [
  { valor: "PROPIEDAD", etiqueta: "Propiedad" },
  { valor: "EQUIPO", etiqueta: "Equipo" },
];

export const CATEGORIAS_POR_TIPO: Record<TipoBien, readonly string[]> = {
  PROPIEDAD: [
    "Casa",
    "Apartamento",
    "Habitación",
    "Salón de eventos",
    "Oficina",
    "Local comercial",
    "Bodega",
    "Terreno",
  ],
  EQUIPO: [
    "Herramientas",
    "Maquinaria de construcción",
    "Audio y sonido",
    "Video y fotografía",
    "Cómputo",
    "Mobiliario para eventos",
    "Deportes y recreación",
    "Jardinería",
  ],
};

export const UNIDADES_COBRO: { valor: UnidadCobro; etiqueta: string }[] = [
  { valor: "HORA", etiqueta: "Por hora" },
  { valor: "DIA", etiqueta: "Por día" },
  { valor: "NOCHE", etiqueta: "Por noche" },
  { valor: "SEMANA", etiqueta: "Por semana" },
];

export function esTipoBien(valor: string): valor is TipoBien {
  return valor === "PROPIEDAD" || valor === "EQUIPO";
}
