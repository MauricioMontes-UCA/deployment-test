import type { TonoInsignia } from "@/components/ui";
import type { UnidadCobro } from "@/lib/bienes";

/** Estado de una publicación, igual que el enum `EstadoBien` del backend. */
export type EstadoBien = "ACTIVA" | "INACTIVA";

/** Un elemento de `GET /bienes/mios` (BE-1.3). */
export type MiBien = {
  id: string;
  titulo: string;
  tipo: string;
  categoria: string;
  estado: EstadoBien;
  precio: number;
  unidadCobro: UnidadCobro;
  deposito: number;
  departamento: string;
  municipio: string;
  /** Ruta relativa (`/uploads/bienes/…`) o null si el bien no tiene fotos. */
  fotoPrincipalUrl: string | null;
  /** Política «Solo usuarios verificados» (H19); false si nunca se configuró. */
  soloVerificados: boolean;
  creadoEn: string;
};

/** Respuesta paginada de `GET /bienes/mios`: 20 bienes por página. */
export type PaginaMisBienes = {
  items: MiBien[];
  pagina: number;
  total: number;
  hayMas: boolean;
};

/** Texto y tono de la insignia según Figma: Activa en éxito, Inactiva en neutro. */
export const ESTADO_BIEN: Record<EstadoBien, { texto: string; tono: TonoInsignia }> = {
  ACTIVA: { texto: "Activa", tono: "exito" },
  INACTIVA: { texto: "Inactiva", tono: "neutro" },
};

/** Misma regla que el backend: entero positivo solo con dígitos, sin ceros a la izquierda. */
export const PAGINA_VALIDA = /^[1-9]\d{0,14}$/;

/** «Municipio, Departamento». */
export function ubicacionDelBien(bien: Pick<MiBien, "municipio" | "departamento">): string {
  return `${bien.municipio}, ${bien.departamento}`;
}

/** «1 bien publicado» / «3 bienes publicados». */
export function textoCantidad(total: number): string {
  return `${total} ${total === 1 ? "bien publicado" : "bienes publicados"}`;
}

/** Ruta de la vista de bloqueos de fechas de un bien (FE-7.1). */
export function hrefBloqueos(bienId: string): string {
  return `/mis-bienes/${bienId}/bloqueos`;
}

/** Ruta pública del bien (FE-2.1). */
export function hrefPublicacion(bienId: string): string {
  return `/bienes/${bienId}`;
}
