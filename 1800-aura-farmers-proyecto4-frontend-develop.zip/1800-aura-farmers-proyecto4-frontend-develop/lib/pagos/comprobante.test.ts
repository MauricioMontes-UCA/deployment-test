import { describe, expect, it } from "vitest";
import { dinero, esComprobantePago, fechaComprobante } from "./comprobante";
const valido = {
  pagoId: "11111111-1111-4111-8111-111111111111",
  comprobanteId: "22222222-2222-4222-8222-222222222222",
  reservaId: "33333333-3333-4333-8333-333333333333",
  fechaHora: "2026-11-18T21:42:00.000Z",
  importeAlquiler: 160, importeDeposito: 25, total: 185,
  modalidad: "TARJETA", estado: "SIMULADO_EXITOSO",
};
describe("FE-9.1 contrato de comprobante", () => {
  it("valida respuesta exitosa persistida", () => expect(esComprobantePago(valido)).toBe(true));
  it("no acepta pago rechazado ni pendiente", () => {
    expect(esComprobantePago({ ...valido, estado: "SIMULADO_RECHAZADO" })).toBe(false);
    expect(esComprobantePago({ ...valido, estado: "PENDIENTE" })).toBe(false);
  });
  it("rechaza datos incompletos", () => expect(esComprobantePago({ ...valido, total: "185" })).toBe(false));
  it("formatea montos y fechas", () => {
    expect(dinero(185)).toContain("185.00");
    expect(fechaComprobante(valido.fechaHora)).toContain("18/11/2026");
  });
});
