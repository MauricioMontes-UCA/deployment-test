import {
  describe,
  expect,
  it,
} from "vitest";

import {
  esResultadoPago,
  esResumenPago,
  formatearDinero,
  mensajeError,
  validarReferencia,
  validarTarjeta,
} from "./tipos";

describe("FE-8.1 - Validaciones de pago", () => {
  it("acepta una tarjeta de prueba válida", () => {
    expect(
      validarTarjeta(
        "4242424242424242",
        "12/28",
        "123",
        new Date("2026-11-19"),
      ),
    ).toBeNull();
  });

  it("rechaza un número de tarjeta inválido", () => {
    expect(
      validarTarjeta(
        "123",
        "12/28",
        "123",
        new Date("2026-11-19"),
      ),
    ).not.toBeNull();
  });

  it("rechaza un vencimiento incorrecto", () => {
    expect(
      validarTarjeta(
        "4242424242424242",
        "13/28",
        "123",
        new Date("2026-11-19"),
      ),
    ).not.toBeNull();
  });

  it("rechaza tarjetas vencidas", () => {
    expect(
      validarTarjeta(
        "4242424242424242",
        "10/26",
        "123",
        new Date("2026-11-19"),
      ),
    ).toBe("La tarjeta está vencida.");
  });

  it("acepta CVV de tres o cuatro dígitos", () => {
    expect(
      validarTarjeta(
        "4242424242424242",
        "12/28",
        "1234",
        new Date("2026-11-19"),
      ),
    ).toBeNull();
  });

  it("rechaza CVV inválido", () => {
    expect(
      validarTarjeta(
        "4242424242424242",
        "12/28",
        "12",
        new Date("2026-11-19"),
      ),
    ).not.toBeNull();
  });

  it("acepta una referencia de transferencia válida", () => {
    expect(
      validarReferencia("SIM-APRUEBA"),
    ).toBeNull();
  });

  it("rechaza referencias con caracteres no permitidos", () => {
    expect(
      validarReferencia("SIM_APRUEBA"),
    ).not.toBeNull();
  });

  it("rechaza referencias demasiado cortas", () => {
    expect(
      validarReferencia("ABC"),
    ).not.toBeNull();
  });

  it("reconoce un resumen de pago válido", () => {
    expect(
      esResumenPago({
        reservaId: "reserva-1",
        importeAlquiler: 150,
        importeDeposito: 25,
        total: 175,
        moneda: "USD",
      }),
    ).toBe(true);
  });

  it("rechaza importes recibidos como texto", () => {
    expect(
      esResumenPago({
        reservaId: "reserva-1",
        importeAlquiler: "150",
        importeDeposito: 25,
        total: 175,
        moneda: "USD",
      }),
    ).toBe(false);
  });

  it("reconoce un pago aprobado", () => {
    expect(
      esResultadoPago({
        pagoId: "pago-1",
        reservaId: "reserva-1",
        fechaHora: "2026-11-19T12:00:00.000Z",
        importeAlquiler: 150,
        importeDeposito: 25,
        total: 175,
        modalidad: "TARJETA",
        estado: "SIMULADO_EXITOSO",
        comprobanteId: "comprobante-1",
      }),
    ).toBe(true);
  });

  it("reconoce un pago rechazado", () => {
    expect(
      esResultadoPago({
        pagoId: "pago-2",
        reservaId: "reserva-1",
        fechaHora: "2026-11-19T12:00:00.000Z",
        importeAlquiler: 150,
        importeDeposito: 25,
        total: 175,
        modalidad: "TRANSFERENCIA_BANCARIA",
        estado: "SIMULADO_RECHAZADO",
        motivoRechazo: "Referencia rechazada.",
      }),
    ).toBe(true);
  });

  it("obtiene el mensaje de error del backend", () => {
    expect(
      mensajeError({
        message: ["Campo inválido.", "Revisa el pago."],
      }),
    ).toBe(
      "Campo inválido. Revisa el pago.",
    );
  });

  it("formatea importes en dólares", () => {
    expect(
      formatearDinero(175),
    ).toContain("175");
  });
});