export type ModalidadPago =
  | "TARJETA"
  | "TRANSFERENCIA_BANCARIA";

export type ResumenPago = {
  reservaId: string;
  importeAlquiler: number;
  importeDeposito: number;
  total: number;
  moneda: "USD";
};

export type CrearPago =
  | {
      modalidad: "TARJETA";
      numeroTarjeta: string;
      vencimiento: string;
      codigoSeguridad: string;
    }
  | {
      modalidad: "TRANSFERENCIA_BANCARIA";
      referenciaSimulada: string;
    };

export type ResultadoPago = {
  pagoId: string;
  reservaId: string;
  fechaHora: string;
  importeAlquiler: number;
  importeDeposito: number;
  total: number;
  modalidad: ModalidadPago;
  estado: "SIMULADO_EXITOSO" | "SIMULADO_RECHAZADO";
  motivoRechazo?: string;
  comprobanteId?: string;
};

export type ErrorPago = {
  message?: string | string[];
  statusCode?: number;
};

export const ID_RESERVA =
  /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export function formatearDinero(
  cantidad: number,
): string {
  return new Intl.NumberFormat("es-SV", {
    style: "currency",
    currency: "USD",
  }).format(cantidad);
}

export function validarTarjeta(
  numero: string,
  vencimiento: string,
  cvv: string,
  ahora: Date = new Date(),
): string | null {
  if (!/^\d{12,19}$/.test(numero)) {
    return "El número debe contener entre 12 y 19 dígitos.";
  }

  if (!/^(0[1-9]|1[0-2])\/\d{2}$/.test(vencimiento)) {
    return "El vencimiento debe tener el formato MM/AA.";
  }

  const [mesTexto, anioTexto] = vencimiento.split("/");
  const mes = Number(mesTexto);
  const anio = 2000 + Number(anioTexto);

  const anioActual = ahora.getFullYear();
  const mesActual = ahora.getMonth() + 1;

  if (
    anio < anioActual ||
    (anio === anioActual && mes < mesActual)
  ) {
    return "La tarjeta está vencida.";
  }

  if (!/^\d{3,4}$/.test(cvv)) {
    return "El CVV debe contener 3 o 4 dígitos.";
  }

  return null;
}

export function validarReferencia(
  referencia: string,
): string | null {
  if (!/^[A-Za-z0-9-]{6,20}$/.test(referencia)) {
    return (
      "La referencia debe contener entre 6 y 20 " +
      "letras, números o guiones."
    );
  }

  return null;
}

export function mensajeError(
  datos: unknown,
  alternativa = "No pudimos completar la operación.",
): string {
  if (
    typeof datos !== "object" ||
    datos === null ||
    !("message" in datos)
  ) {
    return alternativa;
  }

  const mensaje = datos.message;

  if (typeof mensaje === "string") {
    return mensaje;
  }

  if (
    Array.isArray(mensaje) &&
    mensaje.every(
      (elemento) => typeof elemento === "string",
    )
  ) {
    return mensaje.join(" ");
  }

  return alternativa;
}

export function esResumenPago(
  valor: unknown,
): valor is ResumenPago {
  if (
    typeof valor !== "object" ||
    valor === null
  ) {
    return false;
  }

  const datos = valor as Record<string, unknown>;

  return (
    typeof datos.reservaId === "string" &&
    typeof datos.importeAlquiler === "number" &&
    Number.isFinite(datos.importeAlquiler) &&
    typeof datos.importeDeposito === "number" &&
    Number.isFinite(datos.importeDeposito) &&
    typeof datos.total === "number" &&
    Number.isFinite(datos.total) &&
    datos.moneda === "USD"
  );
}

export function esResultadoPago(
  valor: unknown,
): valor is ResultadoPago {
  if (
    typeof valor !== "object" ||
    valor === null
  ) {
    return false;
  }

  const datos = valor as Record<string, unknown>;

  return (
    typeof datos.pagoId === "string" &&
    typeof datos.reservaId === "string" &&
    typeof datos.fechaHora === "string" &&
    typeof datos.total === "number" &&
    (datos.modalidad === "TARJETA" ||
      datos.modalidad === "TRANSFERENCIA_BANCARIA") &&
    (datos.estado === "SIMULADO_EXITOSO" ||
      datos.estado === "SIMULADO_RECHAZADO")
  );
}