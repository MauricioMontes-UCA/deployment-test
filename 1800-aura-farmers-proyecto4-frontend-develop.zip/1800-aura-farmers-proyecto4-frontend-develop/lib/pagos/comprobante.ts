/** Contrato de BE-9.1: GET /pagos/:pagoId/comprobante. */
export type ComprobantePago = {
  pagoId: string;
  comprobanteId: string;
  reservaId: string;
  fechaHora: string;
  importeAlquiler: number;
  importeDeposito: number;
  total: number;
  modalidad: "TARJETA" | "TRANSFERENCIA_BANCARIA";
  estado: "SIMULADO_EXITOSO";
};

export function esComprobantePago(valor: unknown): valor is ComprobantePago {
  if (!valor || typeof valor !== "object") return false;
  const c = valor as Record<string, unknown>;
  return ["pagoId", "comprobanteId", "reservaId", "fechaHora"].every(
    (campo) => typeof c[campo] === "string" && Boolean(c[campo]),
  ) && ["importeAlquiler", "importeDeposito", "total"].every(
    (campo) => typeof c[campo] === "number" && Number.isFinite(c[campo]),
  ) && ["TARJETA", "TRANSFERENCIA_BANCARIA"].includes(String(c.modalidad))
    && c.estado === "SIMULADO_EXITOSO"
    && !Number.isNaN(Date.parse(c.fechaHora as string));
}

export function dinero(importe: number): string {
  return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(importe);
}

export function fechaComprobante(iso: string): string {
  return new Intl.DateTimeFormat("es-SV", {
    day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit", hour12: false,
    timeZone: "America/El_Salvador",
  }).format(new Date(iso));
}
