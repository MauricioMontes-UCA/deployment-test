import { cache } from "react";
import { llamarApi } from "@/lib/api";
import type { Rol } from "@/lib/jwt";
import { obtenerTokens } from "@/lib/sesion";

export type { Rol };

/** Lo que la interfaz necesita de `GET /auth/me`. */
export type UsuarioActual = {
  id: string;
  nombreUsuario: string;
  email: string;
  rol: Rol;
  /** Fecha de alta de la cuenta, ISO 8601. */
  createdAt: string;
};

/**
 * Resultado de pedir el usuario de la sesión:
 * - `sin-sesion`: no hay cookie o el backend rechazó el token (401).
 * - `error`: el backend no respondió o respondió con otro error.
 */
export type ResultadoUsuario =
  | { estado: "ok"; usuario: UsuarioActual }
  | { estado: "sin-sesion" }
  | { estado: "error" };

/**
 * Usuario autenticado según `GET {API_URL}/auth/me`, con el token de la cookie
 * httpOnly. El rol que trae es el vigente en la base, no el del token. Se
 * memoriza por request: el layout y las páginas lo piden una sola vez.
 *
 * Solo para el servidor (server components, route handlers y acciones).
 */
export const obtenerUsuarioActual = cache(async (): Promise<ResultadoUsuario> => {
  const { acceso: token } = await obtenerTokens();
  if (!token) return { estado: "sin-sesion" };

  const { status, datos } = await llamarApi("auth/me", {}, token);
  if (status === 401) return { estado: "sin-sesion" };
  // 0: el backend no respondió (o se agotó el tiempo).
  if (status !== 200) return { estado: "error" };

  const { id, nombreUsuario, email, rol, createdAt } = datos as UsuarioActual;
  return { estado: "ok", usuario: { id, nombreUsuario, email, rol, createdAt } };
});
