import { obtenerDiasRefresh } from "./config";
import type { SesionApi } from "./auth-api";

/**
 * Cookies de la sesión. Las dos son httpOnly: el JavaScript del navegador no
 * las lee, así que los tokens solo se usan desde el servidor de Next.
 *
 * Este módulo no importa `next/headers` para que también lo use el proxy.
 */
export const COOKIE_ACCESO = "access_token";
export const COOKIE_REFRESH = "refresh_token";

type OpcionesCookie = {
  httpOnly: true;
  secure: boolean;
  sameSite: "lax";
  path: "/";
  maxAge: number;
};

function opciones(maxAge: number): OpcionesCookie {
  return {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge,
  };
}

/** Cualquier almacén de cookies con `set` y `delete` (de `cookies()` o de NextResponse). */
type AlmacenCookies = {
  set(nombre: string, valor: string, opciones: OpcionesCookie): unknown;
  delete(nombre: string): unknown;
};

/**
 * Guarda el par de tokens. El access token dura lo que dice `expiresIn` y el
 * refresh lo que dura en el backend: así la cookie nunca sobrevive al token.
 */
export function escribirSesion(almacen: AlmacenCookies, sesion: SesionApi) {
  almacen.set(COOKIE_ACCESO, sesion.accessToken, opciones(sesion.expiresIn));
  almacen.set(COOKIE_REFRESH, sesion.refreshToken, opciones(obtenerDiasRefresh() * 24 * 60 * 60));
}

export function borrarCookiesSesion(almacen: AlmacenCookies) {
  almacen.delete(COOKIE_ACCESO);
  almacen.delete(COOKIE_REFRESH);
}
