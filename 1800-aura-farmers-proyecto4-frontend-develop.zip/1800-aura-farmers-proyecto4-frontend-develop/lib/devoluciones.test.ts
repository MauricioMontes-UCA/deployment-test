import { describe, expect, it } from "vitest";
import {
  contarObservaciones,
  fechaIso,
  leerResumen,
  validarDevolucion,
} from "./devoluciones";
describe("FE-10.1 validaciones", () => {
  const ahora = new Date("2026-11-20T18:00:00Z");
  it("exige fecha y estado", () => {
    expect(validarDevolucion("", "", "", ahora)).toMatchObject({
      fecha: expect.any(String),
      estado: expect.any(String),
    });
  });
  it("rechaza fechas futuras", () => {
    expect(
      validarDevolucion("2026-11-21T18:00", "BUEN_ESTADO", "", ahora).fecha,
    ).toBeDefined();
  });
  it("acepta tres estados", () => {
    for (const e of ["BUEN_ESTADO", "DANADO", "INCOMPLETO"])
      expect(validarDevolucion("2026-11-19T18:00", e, "", ahora)).toEqual({});
  });
  it("rechaza estados no permitidos", () => {
    expect(
      validarDevolucion("2026-11-19", "OTRO", "", ahora).estado,
    ).toBeDefined();
  });
  it("permite 500 caracteres y rechaza 501", () => {
    expect(contarObservaciones("a".repeat(500))).toBe(500);
    expect(
      validarDevolucion("2026-11-19", "DANADO", "a".repeat(501), ahora)
        .observaciones,
    ).toBeDefined();
  });
  it("convierte la fecha local a ISO", () => {
    expect(fechaIso("2026-11-19T15:30")).toMatch(
      /^2026-11-19T\d{2}:30:00\.000Z$/,
    );
  });
  it("cuenta emojis como unidades UTF-16", () => {
    expect(contarObservaciones("😀")).toBe(2);
  });
  it("lee importeOriginal del depósito", () => {
    const resumen = leerResumen(
      {
        estado: "EN_CURSO",
        fechaInicio: "2026-11-19",
        fechaFin: "2026-11-20",
        bien: { titulo: "Cámara" },
        deposito: { estado: "PENDIENTE", importeOriginal: 125.5 },
      },
      "id",
    );
    expect(resumen?.deposito).toBe(125.5);
  });
  it("extrae el resumen", () => {
    expect(
      leerResumen(
        {
          estado: "EN_CURSO",
          fechaInicio: "2026-11-19",
          fechaFin: "2026-11-20",
          bien: { titulo: "Cámara" },
          arrendatario: { nombreUsuario: "ana" },
        },
        "id",
      )?.titulo,
    ).toBe("Cámara");
  });
});
