/**
 * Reglas de los mensajes de una conversación previa a la reserva (H13,
 * FE-13.1), alineadas con BE-13.1 (`CrearMensajeDto`): el contenido no puede
 * estar vacío ni ser solo espacios y tiene como máximo 1000 caracteres,
 * contados por punto de código (un emoji cuenta como 1, igual que en el
 * backend y en el VARCHAR de Postgres). El texto se envía tal cual, sin
 * recortarlo.
 */

/** Máximo de caracteres de un mensaje (BE-13.1). */
export const LIMITE_MENSAJE = 1000;

/** Mensaje de validación, el mismo que devuelve el backend. */
export const MENSAJE_LONGITUD_INVALIDA = "El mensaje debe contener entre 1 y 1000 caracteres";

/** Aviso cuando el envío falla por cualquier motivo que no sea la sesión. */
export const MENSAJE_ERROR_ENVIO = "No se pudo enviar el mensaje";

/** Caracteres del texto por punto de código: un emoji o una letra con tilde cuentan como 1. */
export function contarCaracteresMensaje(texto: string): number {
  return Array.from(texto).length;
}

/** Error de validación del texto, o `null` si se puede enviar. */
export function validarMensaje(texto: string): string | null {
  if (texto.trim().length === 0) return MENSAJE_LONGITUD_INVALIDA;
  if (contarCaracteresMensaje(texto) > LIMITE_MENSAJE) return MENSAJE_LONGITUD_INVALIDA;
  return null;
}

/** Un mensaje como lo devuelve el backend (`MensajeResponseDto`). */
export type MensajeConversacion = {
  id: string;
  remitente: { id: string; nombreUsuario: string };
  contenido: string;
  /** Fecha ISO 8601 del backend. */
  creadoEn: string;
};

/**
 * Resultado de enviar un mensaje (consulta previa o coordinación):
 * - `ok` con el mensaje real del 201; `mensaje: null` si el backend lo guardó
 *   pero su respuesta no se pudo leer.
 * - Sin `ok`: el código del backend, o `null` si no respondió.
 */
export type ResultadoEnvioMensaje =
  | { ok: true; mensaje: MensajeConversacion | null }
  | { ok: false; status: number | null };

const esObjeto = (valor: unknown): valor is Record<string, unknown> =>
  typeof valor === "object" && valor !== null;

/** Lee un mensaje del backend. `null` si le falta algo o algún campo tiene otro tipo. */
export function leerMensaje(valor: unknown): MensajeConversacion | null {
  if (!esObjeto(valor) || !esObjeto(valor.remitente)) return null;
  const { id, contenido, creadoEn } = valor;
  const { id: remitenteId, nombreUsuario } = valor.remitente;
  if (
    typeof id !== "string" ||
    typeof contenido !== "string" ||
    typeof creadoEn !== "string" ||
    Number.isNaN(Date.parse(creadoEn)) ||
    typeof remitenteId !== "string" ||
    typeof nombreUsuario !== "string"
  ) {
    return null;
  }
  return { id, remitente: { id: remitenteId, nombreUsuario }, contenido, creadoEn };
}

/**
 * Lee el historial de `GET /conversaciones/:id/mensajes`. Si un solo mensaje
 * no se puede leer, devuelve `null`: mostrar un historial incompleto
 * escondería mensajes sin avisar.
 *
 * Se ordena por fecha (del más viejo al más nuevo) aunque se pida `orden=asc`,
 * con un orden estable para mensajes del mismo instante.
 */
export function leerHistorial(datos: unknown): MensajeConversacion[] | null {
  if (!esObjeto(datos) || !Array.isArray(datos.mensajes)) return null;
  const mensajes: MensajeConversacion[] = [];
  for (const valor of datos.mensajes) {
    const mensaje = leerMensaje(valor);
    if (!mensaje) return null;
    mensajes.push(mensaje);
  }
  return mensajes
    .map((mensaje, posicion) => ({ mensaje, posicion, instante: Date.parse(mensaje.creadoEn) }))
    .sort((a, b) => a.instante - b.instante || a.posicion - b.posicion)
    .map(({ mensaje }) => mensaje);
}

const PARTES_FECHA = new Intl.DateTimeFormat("en-GB", {
  timeZone: "America/El_Salvador",
  day: "2-digit",
  month: "2-digit",
  year: "numeric",
  hour: "2-digit",
  minute: "2-digit",
  hourCycle: "h23",
});

/** Fecha ISO → «dd/mm/aaaa hh:mm» en hora de El Salvador, como en Figma. */
export function formatearFechaHora(iso: string): string {
  const partes = Object.fromEntries(
    PARTES_FECHA.formatToParts(new Date(iso)).map(({ type, value }) => [type, value]),
  );
  return `${partes.day}/${partes.month}/${partes.year} ${partes.hour}:${partes.minute}`;
}
