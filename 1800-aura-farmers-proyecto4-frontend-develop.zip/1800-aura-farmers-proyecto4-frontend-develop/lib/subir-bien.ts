/**
 * Sube el formulario de publicación a /api/bienes con XMLHttpRequest. Se usa
 * XHR y no fetch porque solo XHR informa el avance de la subida.
 */

export type ResultadoSubida = {
  /** 0 si no hubo respuesta (red caída o petición cancelada). */
  status: number;
  cuerpo: unknown;
};

export function subirBien(
  datos: FormData,
  alAvanzar: (proporcion: number) => void,
): Promise<ResultadoSubida> {
  return new Promise((resolver) => {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "/api/bienes");
    xhr.upload.onprogress = (evento) => {
      if (evento.lengthComputable) alAvanzar(evento.loaded / evento.total);
    };
    xhr.onload = () => {
      let cuerpo: unknown = null;
      try {
        cuerpo = xhr.responseText ? JSON.parse(xhr.responseText) : null;
      } catch {
        cuerpo = null;
      }
      resolver({ status: xhr.status, cuerpo });
    };
    xhr.onerror = () => resolver({ status: 0, cuerpo: null });
    xhr.onabort = () => resolver({ status: 0, cuerpo: null });
    xhr.send(datos);
  });
}
