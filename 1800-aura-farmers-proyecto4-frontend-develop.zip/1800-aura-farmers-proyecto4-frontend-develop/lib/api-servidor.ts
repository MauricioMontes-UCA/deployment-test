import { aplicarCambiosDeSesion, obtenerAccesoVigente } from "@/lib/sesion-vigente";

// Punto único de la verificación para la sesión de las rutas `/api`. Estas
// rutas no pasan por el proxy: renuevan el access token aquí (renovación
// compartida de `lib/sesion-vigente.ts`) y escriben las cookies nuevas en cada
// respuesta, como `app/api/bienes/[bienId]/disponibilidad/route.ts`.

type LectorDeCookies = Parameters<typeof obtenerAccesoVigente>[0];
type EscritorDeCookies = Parameters<typeof aplicarCambiosDeSesion>[0];

/**
 * Access token vigente de la petición (`undefined` si no hay sesión) y
 * `conSesion`, que debe envolver **toda** respuesta de la ruta, errores
 * incluidos, para que lleve las cookies renovadas o las borre.
 */
export async function sesionDeRuta(cookies: LectorDeCookies) {
  const estado = await obtenerAccesoVigente(cookies);
  return {
    token: estado.acceso,
    conSesion: <T extends EscritorDeCookies>(respuesta: T): T =>
      aplicarCambiosDeSesion(respuesta, estado),
  };
}

/** URL de un recurso de la API (`API_URL` ya incluye `/api/v1`). */
export function urlApi(ruta: string): URL | null {
  const base = process.env.API_URL;
  if (!base) return null;
  return new URL(ruta, base.replace(/\/?$/, "/"));
}
