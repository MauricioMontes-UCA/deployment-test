/**
 * Hace que el navegador guarde un archivo en memoria con el nombre dado. Va
 * aparte para poder simularlo en las pruebas (jsdom no descarga nada).
 */
export function descargarArchivo(archivo: Blob, nombre: string): void {
  const url = URL.createObjectURL(archivo);
  const enlace = document.createElement("a");
  enlace.href = url;
  enlace.download = nombre;
  document.body.append(enlace);
  enlace.click();
  enlace.remove();
  URL.revokeObjectURL(url);
}
