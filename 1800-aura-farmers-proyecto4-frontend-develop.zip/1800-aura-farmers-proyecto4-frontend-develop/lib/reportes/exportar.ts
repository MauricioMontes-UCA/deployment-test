import { consultaDePeriodo, type PeriodoAplicado } from "@/lib/periodo-reporte";
import { errorDeRespuesta, MENSAJES_REPORTE } from "./cliente";

export const MENSAJES_EXPORTACION = {
  sinAcceso: MENSAJES_REPORTE.sinAcceso,
  fallo: "No pudimos exportar el archivo. Intenta de nuevo.",
} as const;

const NOMBRE_POR_DEFECTO = "resumen-desempeno.csv";

export type ResultadoExportacion =
  | { tipo: "ok"; archivo: Blob; nombre: string }
  | { tipo: "sesion" }
  /** Lo que se muestra al usuario: el texto del 400, el del 403 o el general. */
  | { tipo: "error"; mensaje: string };

/**
 * Nombre del archivo según `Content-Disposition` (`filename="…"` o
 * `filename*=UTF-8''…`). Sin cabecera utilizable, un nombre genérico.
 */
export function nombreDeArchivo(disposicion: string | null): string {
  if (!disposicion) return NOMBRE_POR_DEFECTO;
  const extendido = /filename\*\s*=\s*UTF-8''([^;]+)/i.exec(disposicion)?.[1];
  if (extendido) {
    try {
      return decodeURIComponent(extendido.trim());
    } catch {
      // Cae al nombre simple.
    }
  }
  const simple = /filename\s*=\s*"([^"]+)"/i.exec(disposicion)?.[1] ??
    /filename\s*=\s*([^;]+)/i.exec(disposicion)?.[1];
  const nombre = simple?.trim().replace(/[\\/]/g, "_");
  return nombre || NOMBRE_POR_DEFECTO;
}

/**
 * Pide el CSV del resumen por el puente `/api/reportes/resumen/exportar` con
 * el mismo periodo de la tabla. Nunca lanza: una caída de red es el error
 * general. No modifica nada en pantalla; el llamador decide qué mostrar.
 */
export async function exportarResumen(periodo: PeriodoAplicado): Promise<ResultadoExportacion> {
  try {
    const respuesta = await fetch(`/api/reportes/resumen/exportar?${consultaDePeriodo(periodo)}`, {
      cache: "no-store",
    });

    if (!respuesta.ok) {
      const cuerpo: unknown = await respuesta.json().catch(() => null);
      const error = errorDeRespuesta(respuesta.status, cuerpo);
      if (error.tipo === "sesion") return { tipo: "sesion" };
      if (error.tipo === "acceso") return { tipo: "error", mensaje: MENSAJES_EXPORTACION.sinAcceso };
      if (error.tipo === "validacion") return { tipo: "error", mensaje: error.mensaje };
      return { tipo: "error", mensaje: MENSAJES_EXPORTACION.fallo };
    }

    return {
      tipo: "ok",
      archivo: await respuesta.blob(),
      nombre: nombreDeArchivo(respuesta.headers.get("content-disposition")),
    };
  } catch {
    return { tipo: "error", mensaje: MENSAJES_EXPORTACION.fallo };
  }
}
