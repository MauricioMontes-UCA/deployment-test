import { describe, expect, it } from "vitest";
import {
  formatearMoneda,
  formatearPromedio,
  formatearResenas,
  formatearTasa,
} from "@/lib/reportes/formato";

describe("formatearMoneda", () => {
  it.each([
    [1250, "$1,250.00"],
    [1721, "$1,721.00"],
    [0, "$0.00"],
    [96.5, "$96.50"],
    [0.1 + 0.2, "$0.30"],
  ])("%s → %s", (valor, esperado) => {
    expect(formatearMoneda(valor)).toBe(esperado);
  });
});

describe("formatearTasa", () => {
  it("lleva un decimal y el signo con espacio", () => {
    expect(formatearTasa(50)).toBe("50.0 %");
    expect(formatearTasa(0)).toBe("0.0 %");
    expect(formatearTasa(100)).toBe("100.0 %");
    expect(formatearTasa(15.6)).toBe("15.6 %");
  });

  it("null es «Sin días disponibles»", () => {
    expect(formatearTasa(null)).toBe("Sin días disponibles");
  });
});

describe("formatearPromedio", () => {
  it("usa la escala máxima de la respuesta", () => {
    expect(formatearPromedio(4.5, 5)).toBe("4.5 / 5");
    expect(formatearPromedio(3, 5)).toBe("3.0 / 5");
    expect(formatearPromedio(4.5, 10)).toBe("4.5 / 10");
  });

  it("null es «Sin calificaciones» y nunca 0", () => {
    expect(formatearPromedio(null, 5)).toBe("Sin calificaciones");
  });
});

describe("formatearResenas", () => {
  it("singular con 1 y plural en el resto, incluido 0", () => {
    expect(formatearResenas(1)).toBe("1 reseña");
    expect(formatearResenas(2)).toBe("2 reseñas");
    expect(formatearResenas(0)).toBe("0 reseñas");
    expect(formatearResenas(12)).toBe("12 reseñas");
  });
});
