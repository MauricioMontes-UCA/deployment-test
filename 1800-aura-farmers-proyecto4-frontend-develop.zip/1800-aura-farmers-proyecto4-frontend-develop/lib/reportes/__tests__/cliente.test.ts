import { afterEach, describe, expect, it, vi } from "vitest";
import { consultarReporte, errorDeRespuesta, mensajeDelServicio } from "@/lib/reportes/cliente";

afterEach(() => vi.unstubAllGlobals());

describe("mensajeDelServicio", () => {
  it("lee un texto o une una lista de textos", () => {
    expect(mensajeDelServicio({ message: "Usa el formato AAAA-MM-DD." })).toBe(
      "Usa el formato AAAA-MM-DD.",
    );
    expect(mensajeDelServicio({ message: ["a", "b"] })).toBe("a b");
  });

  it("devuelve null sin mensaje utilizable", () => {
    expect(mensajeDelServicio(null)).toBeNull();
    expect(mensajeDelServicio({ message: "" })).toBeNull();
    expect(mensajeDelServicio({ message: [1] })).toBeNull();
  });
});

describe("errorDeRespuesta", () => {
  it("traduce cada código", () => {
    expect(errorDeRespuesta(401, null)).toEqual({ tipo: "sesion" });
    expect(errorDeRespuesta(403, { message: "Forbidden" })).toEqual({ tipo: "acceso" });
    expect(errorDeRespuesta(400, { message: "El rango no puede ser mayor a 365 días." })).toEqual({
      tipo: "validacion",
      mensaje: "El rango no puede ser mayor a 365 días.",
    });
    expect(errorDeRespuesta(500, { message: "boom" })).toEqual({ tipo: "fallo" });
    expect(errorDeRespuesta(502, null)).toEqual({ tipo: "fallo" });
  });

  it("un 400 sin texto es un fallo general", () => {
    expect(errorDeRespuesta(400, {})).toEqual({ tipo: "fallo" });
  });
});

describe("consultarReporte", () => {
  it("pide el reporte al puente con el periodo", async () => {
    const fetchFalso = vi.fn().mockResolvedValue(new Response(JSON.stringify({ bienes: [] })));
    vi.stubGlobal("fetch", fetchFalso);

    const resultado = await consultarReporte("ocupacion", {
      periodo: "RANGO",
      desde: "2026-11-01",
      hasta: "2026-11-15",
    });

    expect(resultado).toEqual({ tipo: "ok", datos: { bienes: [] } });
    expect(fetchFalso.mock.calls[0][0]).toBe(
      "/api/reportes/ocupacion?periodo=RANGO&desde=2026-11-01&hasta=2026-11-15",
    );
  });

  it("una respuesta de error se traduce y una red caída es un fallo", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValueOnce(
        new Response(JSON.stringify({ message: "Usa el formato AAAA-MM-DD." }), { status: 400 }),
      ),
    );
    expect(await consultarReporte("ingresos", { periodo: "ULTIMO_MES" })).toEqual({
      tipo: "validacion",
      mensaje: "Usa el formato AAAA-MM-DD.",
    });

    vi.stubGlobal("fetch", vi.fn().mockRejectedValue(new TypeError("fetch failed")));
    expect(await consultarReporte("ingresos", { periodo: "ULTIMO_MES" })).toEqual({ tipo: "fallo" });
  });
});
