import { afterEach, describe, expect, it, vi } from "vitest";
import { exportarResumen, nombreDeArchivo } from "@/lib/reportes/exportar";

afterEach(() => vi.unstubAllGlobals());

describe("nombreDeArchivo", () => {
  it("lee el nombre entre comillas, sin comillas o con filename*", () => {
    expect(
      nombreDeArchivo('attachment; filename="resumen-desempeno_2026-10-07_2026-11-05.csv"'),
    ).toBe("resumen-desempeno_2026-10-07_2026-11-05.csv");
    expect(nombreDeArchivo("attachment; filename=resumen.csv")).toBe("resumen.csv");
    expect(nombreDeArchivo("attachment; filename*=UTF-8''resumen%20ni%C3%B1o.csv")).toBe(
      "resumen niño.csv",
    );
  });

  it("sin cabecera utilizable usa un nombre genérico y no deja pasar rutas", () => {
    expect(nombreDeArchivo(null)).toBe("resumen-desempeno.csv");
    expect(nombreDeArchivo("attachment")).toBe("resumen-desempeno.csv");
    expect(nombreDeArchivo('attachment; filename="../../etc/x.csv"')).toBe(".._.._etc_x.csv");
  });
});

describe("exportarResumen", () => {
  const periodo = { periodo: "RANGO", desde: "2026-10-07", hasta: "2026-11-05" } as const;

  it("pide el CSV con el periodo y devuelve el archivo con su nombre", async () => {
    const fetchFalso = vi.fn().mockResolvedValue(
      new Response("Bien\r\n", {
        headers: { "Content-Disposition": 'attachment; filename="resumen-desempeno_a_b.csv"' },
      }),
    );
    vi.stubGlobal("fetch", fetchFalso);

    const resultado = await exportarResumen(periodo);

    expect(fetchFalso.mock.calls[0][0]).toBe(
      "/api/reportes/resumen/exportar?periodo=RANGO&desde=2026-10-07&hasta=2026-11-05",
    );
    expect(resultado.tipo).toBe("ok");
    if (resultado.tipo === "ok") {
      expect(resultado.nombre).toBe("resumen-desempeno_a_b.csv");
      expect(await resultado.archivo.text()).toBe("Bien\r\n");
    }
  });

  it.each([
    [400, { message: "El rango no puede ser mayor a 365 días." }, "El rango no puede ser mayor a 365 días."],
    [403, { message: "Forbidden" }, "No tienes acceso a este panel."],
    [500, { message: "boom" }, "No pudimos exportar el archivo. Intenta de nuevo."],
    [502, null, "No pudimos exportar el archivo. Intenta de nuevo."],
  ])("con %s devuelve el mensaje definido", async (estado, cuerpo, mensaje) => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue(new Response(JSON.stringify(cuerpo), { status: estado })),
    );
    expect(await exportarResumen(periodo)).toEqual({ tipo: "error", mensaje });
  });

  it("con 401 pide la sesión vencida y con la red caída da el error general", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValueOnce(new Response("{}", { status: 401 })));
    expect(await exportarResumen(periodo)).toEqual({ tipo: "sesion" });

    vi.stubGlobal("fetch", vi.fn().mockRejectedValue(new TypeError("fetch failed")));
    expect(await exportarResumen(periodo)).toEqual({
      tipo: "error",
      mensaje: "No pudimos exportar el archivo. Intenta de nuevo.",
    });
  });
});
