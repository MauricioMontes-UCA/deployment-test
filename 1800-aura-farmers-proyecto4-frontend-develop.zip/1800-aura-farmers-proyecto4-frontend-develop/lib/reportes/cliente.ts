import { consultaDePeriodo, type PeriodoAplicado } from "@/lib/periodo-reporte";

/** Reportes del arrendador que consulta el panel (`GET /api/v1/reportes/*`). */
export const REPORTES = ["ingresos", "ocupacion", "calificaciones", "resumen"] as const;
export type Reporte = (typeof REPORTES)[number];

export const MENSAJES_REPORTE = {
  sinAcceso: "No tienes acceso a este panel.",
  fallo: "No pudimos cargar el reporte. Intenta de nuevo.",
  sinBienes: "Aún no tienes bienes publicados.",
} as const;

/** Por qué no se pudo obtener un reporte, ya traducido a lo que se muestra. */
export type ErrorReporte =
  | { tipo: "sesion" }
  | { tipo: "acceso" }
  | { tipo: "validacion"; mensaje: string }
  | { tipo: "fallo" };

export type ResultadoReporte<T> = { tipo: "ok"; datos: T } | ErrorReporte;

/** Mensaje del servicio: Nest manda un texto o una lista de textos. */
export function mensajeDelServicio(cuerpo: unknown): string | null {
  const mensaje = (cuerpo as { message?: unknown } | null)?.message;
  if (typeof mensaje === "string" && mensaje) return mensaje;
  if (Array.isArray(mensaje)) {
    const textos = mensaje.filter((m): m is string => typeof m === "string" && m !== "");
    if (textos.length) return textos.join(" ");
  }
  return null;
}

/**
 * Traduce un estado HTTP de error: 401 sesión vencida, 403 sin acceso, 400 el
 * texto del servidor y cualquier otro (500, 502…) el mensaje general.
 */
export function errorDeRespuesta(status: number, cuerpo: unknown): ErrorReporte {
  if (status === 401) return { tipo: "sesion" };
  if (status === 403) return { tipo: "acceso" };
  if (status === 400) {
    const mensaje = mensajeDelServicio(cuerpo);
    if (mensaje) return { tipo: "validacion", mensaje };
  }
  return { tipo: "fallo" };
}

/**
 * Consulta un reporte por el puente `/api/reportes/:reporte` (el token está en
 * una cookie httpOnly que el navegador no lee). Nunca lanza: una caída de red
 * o una respuesta ilegible es `fallo`. Si se cancela con `signal`, el llamador
 * debe descartar el resultado.
 */
export async function consultarReporte<T>(
  reporte: Reporte,
  periodo: PeriodoAplicado,
  signal?: AbortSignal,
): Promise<ResultadoReporte<T>> {
  try {
    const respuesta = await fetch(`/api/reportes/${reporte}?${consultaDePeriodo(periodo)}`, {
      cache: "no-store",
      signal,
    });
    if (!respuesta.ok) {
      const cuerpo: unknown = await respuesta.json().catch(() => null);
      return errorDeRespuesta(respuesta.status, cuerpo);
    }
    return { tipo: "ok", datos: (await respuesta.json()) as T };
  } catch {
    return { tipo: "fallo" };
  }
}
