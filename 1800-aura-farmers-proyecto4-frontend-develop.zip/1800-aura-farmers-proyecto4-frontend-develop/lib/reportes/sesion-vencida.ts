/**
 * Lleva a `/sesion-vencida`, que borra la cookie y envía al login. Se usa
 * cuando el backend responde 401 a una consulta de reportes hecha desde el
 * navegador. Va aparte para poder simularla en las pruebas.
 *
 * Es una navegación completa a propósito: `/sesion-vencida` es un route
 * handler que responde con una redirección y borra una cookie, no una página
 * de Next, así que no sirve `router.push`.
 */
export function irASesionVencida(): void {
  // eslint-disable-next-line @next/next/no-location-assign-relative-destination
  window.location.href = "/sesion-vencida";
}
