/** Formatos de los reportes del arrendador (H23 a H26). */

const MONEDA = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD",
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
});

/** `1250` → «$1,250.00». El cero se muestra «$0.00», nunca vacío ni un guion. */
export function formatearMoneda(valor: number): string {
  return MONEDA.format(valor);
}

export const SIN_DIAS_DISPONIBLES = "Sin días disponibles";
export const SIN_CALIFICACIONES = "Sin calificaciones";

/** `50` → «50.0 %». `null` es «Sin días disponibles». */
export function formatearTasa(tasa: number | null): string {
  return tasa === null ? SIN_DIAS_DISPONIBLES : `${tasa.toFixed(1)} %`;
}

/** `4.5` y escala `5` → «4.5 / 5». `null` es «Sin calificaciones», nunca 0. */
export function formatearPromedio(promedio: number | null, escalaMaxima: number): string {
  return promedio === null ? SIN_CALIFICACIONES : `${promedio.toFixed(1)} / ${escalaMaxima}`;
}

/** «1 reseña» en singular y «N reseñas» en plural (también «0 reseñas»). */
export function formatearResenas(total: number): string {
  return total === 1 ? "1 reseña" : `${total} reseñas`;
}
