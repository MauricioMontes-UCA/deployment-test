import type { PeriodoReporte } from "@/components/ui";

/**
 * Periodo de los reportes ya elegido (y validado), tal como lo esperan los
 * endpoints `GET /api/v1/reportes/*` en `periodo`, `desde` y `hasta`.
 */
export type PeriodoAplicado =
  | { periodo: "ULTIMO_MES" | "ULTIMOS_3_MESES" | "ULTIMO_ANIO" }
  | { periodo: "RANGO"; desde: string; hasta: string };

/** El periodo por defecto del panel: «Último mes (30 días)». */
export const PERIODO_INICIAL: PeriodoAplicado = { periodo: "ULTIMO_MES" };

/** Opción del selector (valor del design system) → valor de la API. */
const PERIODO_API = {
  "ultimo-mes": "ULTIMO_MES",
  "ultimos-3-meses": "ULTIMOS_3_MESES",
  "ultimo-anio": "ULTIMO_ANIO",
} as const satisfies Record<Exclude<PeriodoReporte, "rango">, string>;

/** Periodo de una opción fija del selector (todas menos «Rango de fechas»). */
export function periodoFijo(opcion: Exclude<PeriodoReporte, "rango">): PeriodoAplicado {
  return { periodo: PERIODO_API[opcion] };
}

/** Un rango propio no puede abarcar más de esto, contando el primer y el último día. */
export const MAXIMO_DIAS_RANGO = 365;

/** Los mismos textos que devuelve el backend (`MENSAJES_PERIODO`). */
export const MENSAJES_RANGO = {
  incompleto: "Completa las fechas del rango.",
  formato: "Usa el formato AAAA-MM-DD.",
  invertido: "La fecha final no puede ser anterior a la inicial.",
  muyLargo: "El rango no puede ser mayor a 365 días.",
} as const;

const FORMATO_DIA = /^\d{4}-\d{2}-\d{2}$/;
const MS_POR_DIA = 24 * 60 * 60 * 1000;

/** Día AAAA-MM-DD a medianoche UTC, o null si no existe en el calendario (2026-02-30). */
function leerDia(texto: string): Date | null {
  if (!FORMATO_DIA.test(texto)) return null;
  const fecha = new Date(`${texto}T00:00:00Z`);
  return Number.isNaN(fecha.getTime()) || fecha.toISOString().slice(0, 10) !== texto
    ? null
    : fecha;
}

/**
 * Valida un rango de fechas en el navegador, con las mismas reglas que el
 * backend, para no consultar al servidor con un rango que va a rechazar.
 * Devuelve el mensaje del primer error o null si el rango sirve.
 */
export function validarRango(desde: string, hasta: string): string | null {
  const inicioTexto = desde.trim();
  const finTexto = hasta.trim();
  if (!inicioTexto || !finTexto) return MENSAJES_RANGO.incompleto;

  const inicio = leerDia(inicioTexto);
  const fin = leerDia(finTexto);
  if (!inicio || !fin) return MENSAJES_RANGO.formato;
  if (fin < inicio) return MENSAJES_RANGO.invertido;

  // Inclusivo: del día 1 al 365 son 365 días; del 1 al 366, 366.
  const dias = Math.round((fin.getTime() - inicio.getTime()) / MS_POR_DIA) + 1;
  return dias > MAXIMO_DIAS_RANGO ? MENSAJES_RANGO.muyLargo : null;
}

/** Parámetros de búsqueda de un reporte: `periodo=RANGO&desde=…&hasta=…`. */
export function consultaDePeriodo(periodo: PeriodoAplicado): URLSearchParams {
  const consulta = new URLSearchParams({ periodo: periodo.periodo });
  if (periodo.periodo === "RANGO") {
    consulta.set("desde", periodo.desde);
    consulta.set("hasta", periodo.hasta);
  }
  return consulta;
}
