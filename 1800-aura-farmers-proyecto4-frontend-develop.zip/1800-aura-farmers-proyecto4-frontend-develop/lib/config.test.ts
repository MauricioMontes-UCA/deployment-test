import { afterEach, describe, expect, it, vi } from "vitest";
import { DIAS_REFRESH_POR_DEFECTO, obtenerDiasRefresh, validarEntorno } from "./config";

afterEach(() => vi.unstubAllEnvs());

describe("obtenerDiasRefresh", () => {
  it("usa el valor configurado", () => {
    vi.stubEnv("REFRESH_TOKEN_EXPIRES_IN_DAYS", "14");
    expect(obtenerDiasRefresh()).toBe(14);
  });

  it("si falta o no es válido, usa el valor por defecto del backend sin lanzar", () => {
    vi.stubEnv("REFRESH_TOKEN_EXPIRES_IN_DAYS", "");
    expect(obtenerDiasRefresh()).toBe(DIAS_REFRESH_POR_DEFECTO);
    vi.stubEnv("REFRESH_TOKEN_EXPIRES_IN_DAYS", "siete");
    expect(obtenerDiasRefresh()).toBe(7);
  });
});

describe("validarEntorno", () => {
  it("pasa con API_URL válida y los días opcionales", () => {
    vi.stubEnv("API_URL", "http://localhost:3000/api/v1");
    vi.stubEnv("REFRESH_TOKEN_EXPIRES_IN_DAYS", "");
    expect(() => validarEntorno()).not.toThrow();
  });

  it("lanza con todo lo que falta o está mal", () => {
    vi.stubEnv("API_URL", "");
    vi.stubEnv("REFRESH_TOKEN_EXPIRES_IN_DAYS", "0");
    expect(() => validarEntorno()).toThrow(/Falta API_URL[\s\S]*REFRESH_TOKEN_EXPIRES_IN_DAYS/);
  });

  it("lanza si API_URL no es una URL", () => {
    vi.stubEnv("API_URL", "localhost-sin-esquema");
    expect(() => validarEntorno()).toThrow(/no es una URL válida/);
  });
});
