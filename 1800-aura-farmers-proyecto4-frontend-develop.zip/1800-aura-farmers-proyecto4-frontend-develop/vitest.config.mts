import react from "@vitejs/plugin-react";
import { configDefaults, defineConfig } from "vitest/config";

export default defineConfig({
  plugins: [react()],
  // Vite resuelve los alias de tsconfig (`@/…`) sin plugin.
  resolve: { tsconfigPaths: true },
  test: {
    environment: "jsdom",
    setupFiles: ["./vitest.setup.ts"],
    include: ["**/*.test.{ts,tsx}"],
    // .claude guarda worktrees locales de otras ramas: sus pruebas no son de esta.
    exclude: [...configDefaults.exclude, ".next/**", ".claude/**"],
  },
});
