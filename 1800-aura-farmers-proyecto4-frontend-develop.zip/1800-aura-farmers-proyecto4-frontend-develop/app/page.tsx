import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { Suspense } from "react";
import { cerrarSesion } from "@/app/actions/auth";
import { BarraDeBusqueda } from "@/components/busqueda/barra-de-busqueda";
import {
  PublicadosRecientemente,
  PublicadosRecientementeCargando,
} from "@/components/inicio/publicados-recientemente";
import {
  Contenedor,
  Icono,
  NavegacionSuperior,
  PieDePagina,
  clasesBoton,
  type IconoNombre,
} from "@/components/ui";
import { CATEGORIAS_DESTACADAS, urlDeBusqueda } from "@/lib/busqueda";
import { obtenerTokens } from "@/lib/sesion";
import { obtenerUsuarioActual } from "@/lib/usuario-actual";

export const metadata: Metadata = {
  title: "Arre · Renta espacios y equipo cerca de ti",
};

const PASOS: { icono: IconoNombre; titulo: string; texto: string }[] = [
  { icono: "buscar", titulo: "1. Busca", texto: "Filtra por precio, tipo, capacidad y fechas disponibles." },
  {
    icono: "calendario",
    titulo: "2. Solicita",
    texto: "Elige tus fechas en el calendario; la respuesta es automática.",
  },
  {
    icono: "tarjeta",
    titulo: "3. Paga y recibe",
    texto: "Paga con tarjeta o transferencia de prueba y coordina la entrega.",
  },
];

/**
 * Portada pública (FE-3.2). Se ve con o sin sesión: la barra superior cambia
 * según el rol de GET /auth/me (o la de visitante si no hay sesión).
 */
export default async function Inicio() {
  const sesion = await obtenerUsuarioActual();
  // Hay token pero el backend lo rechazó (401): sesión vencida. Se borran las
  // cookies antes de seguir; si no, `/login` rebotaría de vuelta a `/`.
  if (sesion.estado === "sin-sesion" && (await obtenerTokens()).acceso) {
    redirect("/sesion-vencida");
  }
  const usuario = sesion.estado === "ok" ? sesion.usuario : null;

  return (
    <>
      {usuario ? (
        <NavegacionSuperior
          rol={usuario.rol === "ARRENDADOR" ? "arrendador" : "arrendatario"}
          nombreUsuario={usuario.nombreUsuario}
          onCerrarSesion={cerrarSesion}
        />
      ) : (
        <NavegacionSuperior rol="visitante" />
      )}

      <main className="flex-1 bg-fondo-base">
        <section aria-labelledby="titulo-portada" className="bg-fondo-sutil">
          <Contenedor className="flex flex-col gap-5 pt-10 pb-espacio-7 md:gap-espacio-6 md:pt-espacio-9 md:pb-20">
            <p className="texto-sobretitulo text-texto-acento">Renta de espacios y equipo</p>
            <h1 id="titulo-portada" className="texto-display max-w-190 text-texto-primario">
              Renta lo que necesitas, de personas cerca de ti.
            </h1>
            <p className="texto-cuerpo-grande max-w-160 text-texto-secundario">
              Salones, casas, cámaras, herramientas y más, con disponibilidad real, pagos de prueba y
              depósitos claros.
            </p>
            <BarraDeBusqueda />
          </Contenedor>
        </section>

        <section aria-labelledby="titulo-categorias">
          <Contenedor className="flex flex-col gap-espacio-4 pt-10 md:pt-espacio-8">
            <h2 id="titulo-categorias" className="texto-h3 text-texto-primario md:texto-h2">
              Explora por categoría
            </h2>
            <ul className="flex flex-wrap gap-espacio-3">
              {CATEGORIAS_DESTACADAS.map((categoria) => (
                <li key={categoria}>
                  <Link
                    href={urlDeBusqueda({ categoria })}
                    className="texto-etiqueta inline-flex border border-borde-default bg-fondo-superficie px-espacio-3 py-2.5 whitespace-nowrap text-texto-primario hover:bg-fondo-sutil"
                  >
                    {categoria}
                  </Link>
                </li>
              ))}
            </ul>
          </Contenedor>
        </section>

        <section aria-labelledby="titulo-recientes">
          <Contenedor className="flex flex-col gap-espacio-5 pt-10 md:pt-espacio-8">
            <div className="flex items-center justify-between gap-espacio-3">
              <h2 id="titulo-recientes" className="texto-h3 text-texto-primario md:texto-h2">
                Publicados recientemente
              </h2>
              <Link href="/buscar" className={clasesBoton({ jerarquia: "terciario" })}>
                Ver todo
              </Link>
            </div>
            <Suspense fallback={<PublicadosRecientementeCargando />}>
              <PublicadosRecientemente />
            </Suspense>
          </Contenedor>
        </section>

        <section aria-label="Cómo funciona">
          <Contenedor className="pt-10 md:pt-20">
            <ul className="grid grid-cols-1 gap-espacio-4 md:grid-cols-3 md:gap-espacio-5">
              {PASOS.map((paso) => (
                <li
                  key={paso.titulo}
                  className="flex flex-col gap-espacio-3 border border-borde-default bg-fondo-superficie p-espacio-5"
                >
                  <Icono nombre={paso.icono} tamano={28} className="text-texto-primario" />
                  <h3 className="texto-h3 text-texto-primario">{paso.titulo}</h3>
                  <p className="texto-cuerpo text-texto-secundario">{paso.texto}</p>
                </li>
              ))}
            </ul>
          </Contenedor>
        </section>

        <section aria-labelledby="titulo-cta">
          <Contenedor className="pt-10 pb-espacio-7 md:pt-20 md:pb-espacio-9">
            <div className="flex flex-col gap-espacio-5 border border-borde-default bg-fondo-acento p-espacio-5 md:flex-row md:items-center md:justify-between md:p-espacio-7">
              <div className="flex max-w-160 flex-col gap-espacio-2">
                <h2 id="titulo-cta" className="texto-h3 text-texto-primario md:texto-h2">
                  ¿Tienes algo que rentar?
                </h2>
                <p className="texto-cuerpo text-texto-secundario">
                  Publica tu espacio o equipo con fotos, precio, depósito y condiciones. Tú decides si
                  solo aceptas usuarios verificados.
                </p>
              </div>
              <Link href="/registro" className={clasesBoton({ className: "w-full md:w-auto" })}>
                Crear cuenta de arrendador
              </Link>
            </div>
          </Contenedor>
        </section>
      </main>

      <PieDePagina />
    </>
  );
}
