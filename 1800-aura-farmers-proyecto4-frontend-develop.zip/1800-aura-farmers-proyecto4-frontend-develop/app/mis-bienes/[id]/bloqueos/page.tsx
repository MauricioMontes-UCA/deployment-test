import type { Metadata } from "next";
import type { ReactNode } from "react";
import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { cerrarSesion } from "@/app/actions/auth";
import { GestionDeBloqueos } from "@/components/gestion-de-bloqueos";
import {
  Contenedor,
  EncabezadoDePagina,
  EstadoDePagina,
  NavegacionSuperior,
  PieDePagina,
  clasesBoton,
} from "@/components/ui";
import { ID_UUID } from "@/lib/bloqueos";
import { obtenerBien } from "@/lib/solicitud/servidor";
import { obtenerUsuarioActual } from "@/lib/usuario-actual";

export const metadata: Metadata = {
  title: "Bloquear fechas · Arre",
};

/** Título del bien para el sobretítulo; si la consulta falla, la página sigue sin él. */
async function tituloDelBien(bienId: string): Promise<string | null> {
  try {
    return (await obtenerBien(bienId))?.titulo ?? null;
  } catch {
    return null;
  }
}

/**
 * Gestión de bloqueos de fechas de un bien (FE-7.1, H7). Sin sesión pasa por
 * `/sesion-vencida`, que borra las cookies y lleva al login; el ARRENDATARIO ve
 * «sin permiso». Que el arrendador sea el dueño del bien lo decide la API
 * (403). Cuando exista `/mis-bienes/[id]` (Módulo 1), enlázala desde allí.
 */
export default async function BloqueosPage({ params }: PageProps<"/mis-bienes/[id]/bloqueos">) {
  const { id } = await params;
  if (!ID_UUID.test(id)) notFound();

  const resultado = await obtenerUsuarioActual();
  if (resultado.estado === "sin-sesion") redirect("/sesion-vencida");

  if (resultado.estado === "error") {
    return (
      <Pagina>
        <EstadoDePagina
          tipo="error"
          accion={
            <Link href={`/mis-bienes/${id}/bloqueos`} className={clasesBoton({ jerarquia: "secundario" })}>
              Reintentar
            </Link>
          }
        />
      </Pagina>
    );
  }

  const { usuario } = resultado;
  const arrendador = usuario.rol === "ARRENDADOR";
  const navegacion = (
    <NavegacionSuperior
      rol={arrendador ? "arrendador" : "arrendatario"}
      nombreUsuario={usuario.nombreUsuario}
      onCerrarSesion={cerrarSesion}
    />
  );

  if (!arrendador) {
    return (
      <Pagina navegacion={navegacion}>
        <EstadoDePagina
          tipo="sin-permiso"
          accion={
            <Link href="/" className={clasesBoton({ jerarquia: "secundario" })}>
              Ir al inicio
            </Link>
          }
        />
      </Pagina>
    );
  }

  const titulo = await tituloDelBien(id);
  return (
    <Pagina navegacion={navegacion}>
      <EncabezadoDePagina
        sobretitulo={titulo ? `Mis bienes · ${titulo}` : "Mis bienes"}
        titulo="Bloquear fechas"
        descripcion="Marca los días en los que tu bien no está disponible. Las reservas confirmadas se muestran, pero no se pueden modificar aquí."
      />
      <GestionDeBloqueos bienId={id} />
    </Pagina>
  );
}

function Pagina({ navegacion, children }: { navegacion?: ReactNode; children: ReactNode }) {
  return (
    <>
      {navegacion}
      <main className="flex-1 bg-fondo-base">
        <Contenedor className="flex flex-col gap-espacio-5 pt-espacio-6 pb-espacio-8 md:pt-espacio-7 md:pb-espacio-9">
          {children}
        </Contenedor>
      </main>
      <PieDePagina />
    </>
  );
}
