import { render, screen } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { usuarioDePrueba } from "@/pruebas/usuario";
import PaginaBloqueos from "./page";

const BIEN = "10000000-0000-4000-8000-000000000001";

const { obtenerUsuarioActual, obtenerBien, redirect, notFound } = vi.hoisted(() => ({
  obtenerUsuarioActual: vi.fn(),
  obtenerBien: vi.fn(),
  redirect: vi.fn(),
  notFound: vi.fn(),
}));
vi.mock("@/lib/usuario-actual", () => ({ obtenerUsuarioActual }));
vi.mock("@/lib/solicitud/servidor", () => ({ obtenerBien }));
vi.mock("@/app/actions/auth", () => ({ cerrarSesion: vi.fn() }));
vi.mock("@/components/gestion-de-bloqueos", () => ({
  GestionDeBloqueos: ({ bienId }: { bienId: string }) => <div>Gestión del bien {bienId}</div>,
}));
vi.mock("next/navigation", () => ({ usePathname: () => "/mis-bienes", redirect, notFound }));

const props = (id: string = BIEN) => ({ params: Promise.resolve({ id }) }) as never;
const arrendador = { estado: "ok", usuario: usuarioDePrueba({ rol: "ARRENDADOR", nombreUsuario: "carlos" }) };

beforeEach(() => {
  obtenerUsuarioActual.mockReset();
  obtenerBien.mockReset();
  redirect.mockReset();
  notFound.mockReset();
  redirect.mockImplementation(() => {
    throw new Error("NEXT_REDIRECT");
  });
  notFound.mockImplementation(() => {
    throw new Error("NEXT_NOT_FOUND");
  });
});

describe("/mis-bienes/[id]/bloqueos", () => {
  it("al arrendador le muestra la barra, el título del bien, la gestión y el pie", async () => {
    obtenerUsuarioActual.mockResolvedValue(arrendador);
    obtenerBien.mockResolvedValue({ titulo: "Salón de eventos Las Palmas" });

    render(await PaginaBloqueos(props()));

    expect(screen.getByRole("heading", { level: 1, name: "Bloquear fechas" })).toBeInTheDocument();
    expect(screen.getByText("Mis bienes · Salón de eventos Las Palmas")).toBeInTheDocument();
    expect(screen.getByText(`Gestión del bien ${BIEN}`)).toBeInTheDocument();
    expect(screen.getByText("carlos")).toBeInTheDocument();
    expect(screen.getByRole("contentinfo")).toBeInTheDocument();
  });

  it.each([
    ["no existe", null],
    ["falla", new Error("API caída")],
  ])("si el título del bien %s, el sobretítulo queda en «Mis bienes»", async (_caso, resultado) => {
    obtenerUsuarioActual.mockResolvedValue(arrendador);
    if (resultado instanceof Error) obtenerBien.mockRejectedValue(resultado);
    else obtenerBien.mockResolvedValue(resultado);

    render(await PaginaBloqueos(props()));

    expect(screen.getByText("Mis bienes", { selector: "p" })).toBeInTheDocument();
    expect(screen.getByText(`Gestión del bien ${BIEN}`)).toBeInTheDocument();
  });

  it("al arrendatario le muestra «sin permiso» sin montar la gestión ni pedir el bien", async () => {
    obtenerUsuarioActual.mockResolvedValue({ estado: "ok", usuario: usuarioDePrueba() });

    render(await PaginaBloqueos(props()));

    expect(screen.getByRole("link", { name: "Ir al inicio" })).toHaveAttribute("href", "/");
    expect(screen.queryByText(/Gestión del bien/)).not.toBeInTheDocument();
    expect(obtenerBien).not.toHaveBeenCalled();
  });

  it("si /auth/me falla muestra el error con «Reintentar» a la misma página", async () => {
    obtenerUsuarioActual.mockResolvedValue({ estado: "error" });

    render(await PaginaBloqueos(props()));

    expect(screen.getByRole("link", { name: "Reintentar" })).toHaveAttribute(
      "href",
      `/mis-bienes/${BIEN}/bloqueos`,
    );
    expect(screen.queryByText(/Gestión del bien/)).not.toBeInTheDocument();
  });

  it("sin sesión pasa por /sesion-vencida", async () => {
    obtenerUsuarioActual.mockResolvedValue({ estado: "sin-sesion" });

    await expect(PaginaBloqueos(props())).rejects.toThrow("NEXT_REDIRECT");
    expect(redirect).toHaveBeenCalledWith("/sesion-vencida");
  });

  it("un id que no es UUID da 404 sin consultar nada", async () => {
    await expect(PaginaBloqueos(props("no-es-un-uuid"))).rejects.toThrow("NEXT_NOT_FOUND");
    expect(obtenerUsuarioActual).not.toHaveBeenCalled();
  });
});
