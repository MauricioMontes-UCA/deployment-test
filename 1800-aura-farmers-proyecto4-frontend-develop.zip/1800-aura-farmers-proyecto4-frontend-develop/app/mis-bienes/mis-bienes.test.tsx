import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, describe, expect, it, vi } from "vitest";
import type { MiBien } from "@/lib/mis-bienes";
import { MisBienes } from "./mis-bienes";

vi.mock("@/app/actions/auth", () => ({ cerrarSesion: vi.fn() }));
vi.mock("next/navigation", () => ({ usePathname: () => "/mis-bienes" }));

function bien(id: string, cambios: Partial<MiBien> = {}): MiBien {
  return {
    id,
    titulo: `Bien ${id}`,
    tipo: "SALON",
    categoria: "Eventos",
    estado: "ACTIVA",
    precio: 100,
    unidadCobro: "DIA",
    deposito: 0,
    departamento: "San Salvador",
    municipio: "Soyapango",
    fotoPrincipalUrl: null,
    soloVerificados: false,
    creadoEn: "2026-11-01T00:00:00.000Z",
    ...cambios,
  };
}

function pagina(items: MiBien[], extra: Partial<{ pagina: number; total: number; hayMas: boolean }> = {}) {
  return { items, pagina: 1, total: items.length, hayMas: false, ...extra };
}

const json = (cuerpo: unknown, status = 200) =>
  Promise.resolve(new Response(JSON.stringify(cuerpo), { status }));

afterEach(() => vi.unstubAllGlobals());

describe("MisBienes", () => {
  it("ofrece «Publicar un bien» en el encabezado, también mientras carga", () => {
    vi.stubGlobal("fetch", vi.fn(() => new Promise(() => {})));
    render(<MisBienes arrendadorVerificado />);

    const botones = screen.getAllByRole("link", { name: "Publicar un bien" });
    expect(botones.some((b) => b.closest("main"))).toBe(true);
    for (const b of botones) expect(b).toHaveAttribute("href", "/publicar");
    expect(
      screen.getByText("Administra tus publicaciones, bloquea fechas y decide si solo aceptas usuarios verificados."),
    ).toBeInTheDocument();
  });

  it("lista los bienes con su cantidad", async () => {
    vi.stubGlobal("fetch", vi.fn(() => json(pagina([bien("1"), bien("2", { estado: "INACTIVA" })]))));
    render(<MisBienes nombreUsuario="carlos" arrendadorVerificado />);

    expect(await screen.findByText("Bien 1")).toBeInTheDocument();
    expect(screen.getByText("Bien 2")).toBeInTheDocument();
    expect(screen.getByText("2 bienes publicados")).toBeInTheDocument();
    expect(screen.getByText("Inactiva")).toBeInTheDocument();
    expect(screen.getByText("No hay más bienes.")).toBeInTheDocument();
  });

  it("carga la siguiente página de 20 en 20", async () => {
    const fetchSimulado = vi.fn((url: string) =>
      url.endsWith("pagina=2")
        ? json(pagina([bien("21")], { pagina: 2, total: 21 }))
        : json(pagina([bien("1")], { total: 21, hayMas: true })),
    );
    vi.stubGlobal("fetch", fetchSimulado);
    render(<MisBienes arrendadorVerificado />);
    await screen.findByText("Bien 1");

    await userEvent.click(screen.getByRole("button", { name: "Cargar más" }));

    expect(await screen.findByText("Bien 21")).toBeInTheDocument();
    expect(screen.getByText("Bien 1")).toBeInTheDocument();
    expect(fetchSimulado.mock.calls.at(-1)?.[0]).toBe("/api/bienes/mios?pagina=2");
    expect(screen.queryByRole("button", { name: "Cargar más" })).not.toBeInTheDocument();
  });

  it("si falla cargar más conserva la lista y deja reintentar", async () => {
    let fallar = true;
    vi.stubGlobal(
      "fetch",
      vi.fn((url: string) => {
        if (!url.endsWith("pagina=2")) return json(pagina([bien("1")], { total: 21, hayMas: true }));
        return fallar ? json({}, 500) : json(pagina([bien("21")], { pagina: 2, total: 21 }));
      }),
    );
    render(<MisBienes arrendadorVerificado />);
    await screen.findByText("Bien 1");

    await userEvent.click(screen.getByRole("button", { name: "Cargar más" }));
    expect(await screen.findByRole("alert")).toHaveTextContent("No pudimos cargar más bienes");

    fallar = false;
    await userEvent.click(screen.getByRole("button", { name: "Cargar más" }));
    expect(await screen.findByText("Bien 21")).toBeInTheDocument();
    expect(screen.queryByRole("alert")).not.toBeInTheDocument();
  });

  it("muestra carga, error con reintento y estado vacío", async () => {
    const respuestas = [json({}, 500), json(pagina([]))];
    vi.stubGlobal("fetch", vi.fn(() => respuestas.shift()!));
    render(<MisBienes arrendadorVerificado />);

    expect(screen.getByRole("status", { name: "Cargando bienes" })).toBeInTheDocument();
    await userEvent.click(await screen.findByRole("button", { name: "Reintentar" }));
    expect(await screen.findByText("Aún no tienes bienes publicados")).toBeInTheDocument();
  });

  it("con 401 muestra que la sesión venció", async () => {
    vi.stubGlobal("fetch", vi.fn(() => json({}, 401)));
    render(<MisBienes arrendadorVerificado />);
    expect(await screen.findByText("Tu sesión venció")).toBeInTheDocument();
    await waitFor(() => expect(screen.getByRole("button", { name: "Iniciar sesión" })).toBeInTheDocument());
  });
});
