"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { cerrarSesion } from "@/app/actions/auth";
import { FilaDeBien } from "@/components/mis-bienes/fila-de-bien";
import {
  Boton,
  Contenedor,
  EncabezadoDePagina,
  EstadoDePagina,
  Icono,
  NavegacionSuperior,
  PieDePagina,
  clasesBoton,
} from "@/components/ui";
import { textoCantidad, type MiBien, type PaginaMisBienes } from "@/lib/mis-bienes";

type Carga =
  | { tipo: "cargando" }
  | { tipo: "listo"; bienes: MiBien[]; pagina: number; total: number; hayMas: boolean }
  | { tipo: "sesion" }
  | { tipo: "error" };

function Esqueleto() {
  return (
    <div role="status" aria-label="Cargando bienes" className="flex flex-col gap-espacio-4">
      {[0, 1, 2].map((n) => (
        <div key={n} className="h-36 animate-pulse border border-borde-sutil bg-fondo-sutil" />
      ))}
    </div>
  );
}

const url = (pagina: number) => `/api/bienes/mios?pagina=${pagina}`;

type Props = {
  nombreUsuario?: string;
  /** Si el arrendador está VERIFICADO: sin esto no puede activar «Solo usuarios verificados». */
  arrendadorVerificado: boolean;
};

export function MisBienes({ nombreUsuario, arrendadorVerificado }: Props) {
  const [carga, setCarga] = useState<Carga>({ tipo: "cargando" });
  const [intento, setIntento] = useState(0);
  const [cargandoMas, setCargandoMas] = useState(false);
  const [errorMas, setErrorMas] = useState(false);

  useEffect(() => {
    const control = new AbortController();
    fetch(url(1), { signal: control.signal, cache: "no-store" })
      .then(async (respuesta) => {
        if (respuesta.status === 401) return setCarga({ tipo: "sesion" });
        if (!respuesta.ok) return setCarga({ tipo: "error" });
        const datos: PaginaMisBienes = await respuesta.json();
        setCarga({
          tipo: "listo",
          bienes: datos.items,
          pagina: datos.pagina,
          total: datos.total,
          hayMas: datos.hayMas,
        });
      })
      .catch((error) => {
        if (error?.name !== "AbortError") setCarga({ tipo: "error" });
      });
    return () => control.abort();
  }, [intento]);

  function reintentar() {
    setCarga({ tipo: "cargando" });
    setIntento((n) => n + 1);
  }

  async function cargarMas() {
    if (carga.tipo !== "listo" || cargandoMas) return;
    setCargandoMas(true);
    setErrorMas(false);
    try {
      const respuesta = await fetch(url(carga.pagina + 1), { cache: "no-store" });
      if (respuesta.status === 401) return setCarga({ tipo: "sesion" });
      if (!respuesta.ok) return setErrorMas(true);
      const datos: PaginaMisBienes = await respuesta.json();
      setCarga((actual) =>
        actual.tipo === "listo"
          ? {
              tipo: "listo",
              bienes: [...actual.bienes, ...datos.items],
              pagina: datos.pagina,
              total: datos.total,
              hayMas: datos.hayMas,
            }
          : actual,
      );
    } catch {
      setErrorMas(true);
    } finally {
      setCargandoMas(false);
    }
  }

  return (
    <>
      <NavegacionSuperior
        rol="arrendador"
        nombreUsuario={nombreUsuario}
        onCerrarSesion={() => void cerrarSesion()}
      />
      <main className="flex-1">
        <Contenedor className="flex flex-col gap-espacio-5 pt-espacio-5 pb-espacio-8 md:pt-espacio-7 md:pb-espacio-9">
          <div className="flex flex-col gap-espacio-4 md:flex-row md:items-end md:justify-between">
            <EncabezadoDePagina
              sobretitulo="Arrendador"
              titulo="Mis bienes"
              descripcion="Administra tus publicaciones, bloquea fechas y decide si solo aceptas usuarios verificados."
            />
            <Link href="/publicar" className={clasesBoton({ className: "w-full md:w-auto md:shrink-0" })}>
              <Icono nombre="mas" tamano={20} />
              Publicar un bien
            </Link>
          </div>

          {carga.tipo === "cargando" && <Esqueleto />}

          {carga.tipo === "error" && (
            <EstadoDePagina
              tipo="error"
              accion={
                <Boton jerarquia="secundario" onClick={reintentar}>
                  Reintentar
                </Boton>
              }
            />
          )}

          {carga.tipo === "sesion" && (
            <EstadoDePagina
              tipo="error"
              titulo="Tu sesión venció"
              mensaje="Inicia sesión de nuevo para ver tus bienes."
              accion={
                <form action={cerrarSesion}>
                  <Boton type="submit">Iniciar sesión</Boton>
                </form>
              }
            />
          )}

          {carga.tipo === "listo" && carga.bienes.length === 0 && (
            <EstadoDePagina
              tipo="vacio"
              titulo="Aún no tienes bienes publicados"
              mensaje="Cuando publiques un bien, lo verás aquí para gestionarlo."
            />
          )}

          {carga.tipo === "listo" && carga.bienes.length > 0 && (
            <>
              <p aria-live="polite" className="texto-etiqueta text-texto-secundario">
                {textoCantidad(carga.total)}
              </p>
              <div className="flex flex-col gap-espacio-4">
                {carga.bienes.map((bien) => (
                  <FilaDeBien
                    key={bien.id}
                    bien={bien}
                    arrendadorVerificado={arrendadorVerificado}
                    alSesionVencida={() => setCarga({ tipo: "sesion" })}
                  />
                ))}
              </div>

              {errorMas && (
                <p role="alert" className="texto-cuerpo-pequeno text-texto-error">
                  No pudimos cargar más bienes. Intenta de nuevo.
                </p>
              )}
              {carga.hayMas ? (
                <div className="flex justify-center">
                  <Boton jerarquia="secundario" onClick={() => void cargarMas()} disabled={cargandoMas}>
                    {cargandoMas ? "Cargando…" : "Cargar más"}
                  </Boton>
                </div>
              ) : (
                <p className="texto-cuerpo-pequeno text-center text-texto-secundario">
                  No hay más bienes.
                </p>
              )}
            </>
          )}
        </Contenedor>
      </main>
      <PieDePagina />
    </>
  );
}
