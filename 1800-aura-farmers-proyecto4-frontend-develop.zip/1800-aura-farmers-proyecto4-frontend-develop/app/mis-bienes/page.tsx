import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { cerrarSesion } from "@/app/actions/auth";
import {
  Contenedor,
  EstadoDePagina,
  NavegacionSuperior,
  PieDePagina,
  clasesBoton,
} from "@/components/ui";
import { llamarApi } from "@/lib/api";
import { obtenerUsuarioActual } from "@/lib/usuario-actual";
import { esMiEstado } from "@/lib/verificacion/documento";
import { MisBienes } from "./mis-bienes";

export const metadata: Metadata = { title: "Mis bienes · Arre" };

export default async function PaginaMisBienes() {
  const resultado = await obtenerUsuarioActual();
  // Pasa por /sesion-vencida para borrar la cookie; con ella, el proxy no deja entrar a /login.
  if (resultado.estado === "sin-sesion") redirect("/sesion-vencida");

  // GET /bienes/mios es solo para ARRENDADOR (403 para el arrendatario).
  if (resultado.estado === "ok" && resultado.usuario.rol !== "ARRENDADOR") {
    return (
      <>
        <NavegacionSuperior
          rol="arrendatario"
          nombreUsuario={resultado.usuario.nombreUsuario}
          onCerrarSesion={cerrarSesion}
        />
        <main className="flex-1 bg-fondo-base">
          <Contenedor className="flex flex-col gap-espacio-5 pt-espacio-6 pb-espacio-8 md:pt-espacio-7 md:pb-espacio-9">
            <EstadoDePagina
              tipo="sin-permiso"
              accion={
                <Link href="/" className={clasesBoton({ jerarquia: "secundario" })}>
                  Ir al inicio
                </Link>
              }
            />
          </Contenedor>
        </main>
        <PieDePagina />
      </>
    );
  }

  // Si /auth/me o mi-estado fallan, la pantalla igual carga: sin saber si está
  // verificado, el interruptor queda como si no lo estuviera (solo permite apagarlo).
  const estado = await llamarApi("verificaciones/mi-estado");
  if (estado.status === 401) redirect("/sesion-vencida");
  const arrendadorVerificado =
    estado.status === 200 && esMiEstado(estado.datos) && estado.datos.estado === "VERIFICADO";

  const nombre = resultado.estado === "ok" ? resultado.usuario.nombreUsuario : undefined;
  return <MisBienes nombreUsuario={nombre} arrendadorVerificado={arrendadorVerificado} />;
}
