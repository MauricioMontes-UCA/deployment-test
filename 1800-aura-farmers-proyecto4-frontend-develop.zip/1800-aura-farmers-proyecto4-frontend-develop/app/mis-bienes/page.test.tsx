import { render, screen } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { usuarioDePrueba } from "@/pruebas/usuario";
import PaginaMisBienes from "./page";

const { obtenerUsuarioActual, redirect, llamarApi } = vi.hoisted(() => ({
  obtenerUsuarioActual: vi.fn(),
  redirect: vi.fn(),
  llamarApi: vi.fn(),
}));
vi.mock("@/lib/usuario-actual", () => ({ obtenerUsuarioActual }));
vi.mock("@/lib/api", () => ({ llamarApi }));
vi.mock("@/app/actions/auth", () => ({ cerrarSesion: vi.fn() }));
vi.mock("next/navigation", () => ({ usePathname: () => "/mis-bienes", redirect }));
vi.stubGlobal("fetch", vi.fn(() => new Promise(() => {})));

beforeEach(() => {
  obtenerUsuarioActual.mockReset();
  redirect.mockReset();
  llamarApi.mockReset();
  llamarApi.mockResolvedValue({ status: 200, datos: { estado: "VERIFICADO" }, mensajes: [] });
  vi.mocked(fetch).mockClear();
});

describe("/mis-bienes", () => {
  it("al arrendatario le muestra «sin permiso» y no consulta nada", async () => {
    obtenerUsuarioActual.mockResolvedValue({ estado: "ok", usuario: usuarioDePrueba({ rol: "ARRENDATARIO" }) });
    render(await PaginaMisBienes());

    expect(screen.getByRole("link", { name: "Ir al inicio" })).toHaveAttribute("href", "/");
    expect(screen.queryByRole("heading", { name: "Mis bienes" })).not.toBeInTheDocument();
    expect(fetch).not.toHaveBeenCalled();
    expect(llamarApi).not.toHaveBeenCalled();
  });

  it("al arrendador le monta la lista", async () => {
    obtenerUsuarioActual.mockResolvedValue({ estado: "ok", usuario: usuarioDePrueba({ rol: "ARRENDADOR" }) });
    render(await PaginaMisBienes());

    expect(screen.getByRole("heading", { name: "Mis bienes" })).toBeInTheDocument();
    expect(llamarApi).toHaveBeenCalledWith("verificaciones/mi-estado");
    expect(fetch).toHaveBeenCalled();
  });

  it("sin sesión pasa por /sesion-vencida", async () => {
    obtenerUsuarioActual.mockResolvedValue({ estado: "sin-sesion" });
    redirect.mockImplementation(() => {
      throw new Error("NEXT_REDIRECT");
    });
    await expect(PaginaMisBienes()).rejects.toThrow("NEXT_REDIRECT");
    expect(redirect).toHaveBeenCalledWith("/sesion-vencida");
  });

  it("si mi-estado da 401 pasa por /sesion-vencida", async () => {
    obtenerUsuarioActual.mockResolvedValue({ estado: "ok", usuario: usuarioDePrueba({ rol: "ARRENDADOR" }) });
    llamarApi.mockResolvedValue({ status: 401, datos: null, mensajes: [] });
    redirect.mockImplementation(() => {
      throw new Error("NEXT_REDIRECT");
    });
    await expect(PaginaMisBienes()).rejects.toThrow("NEXT_REDIRECT");
    expect(redirect).toHaveBeenCalledWith("/sesion-vencida");
  });
});
