import { NextResponse, type NextRequest } from "next/server";
import { sesionDeRuta, urlApi } from "@/lib/api-servidor";

/** Puente hacia `GET {API_URL}/verificaciones/mi-estado`. */
export async function GET(request: NextRequest) {
  const { token, conSesion } = await sesionDeRuta(request.cookies);
  if (!token) return conSesion(NextResponse.json({ message: "No autenticado." }, { status: 401 }));

  const destino = urlApi("verificaciones/mi-estado");
  if (!destino) return conSesion(NextResponse.json({ message: "Falta API_URL." }, { status: 500 }));

  try {
    const respuesta = await fetch(destino, {
      headers: { Authorization: `Bearer ${token}` },
      cache: "no-store",
    });
    return conSesion(
      NextResponse.json(await respuesta.json().catch(() => ({})), {
        status: respuesta.status,
      }),
    );
  } catch {
    return conSesion(
      NextResponse.json({ message: "No se pudo contactar a la API." }, { status: 502 }),
    );
  }
}
