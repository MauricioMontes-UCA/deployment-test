import { NextResponse, type NextRequest } from "next/server";
import { sesionDeRuta, urlApi } from "@/lib/api-servidor";
import { MAX_DOCUMENTO_BYTES, MENSAJES_VERIFICACION } from "@/lib/verificacion/documento";

// Margen para el multipart (límites y nombre del archivo) sobre los 5 MB.
const MARGEN_MULTIPART = 64 * 1024;

/**
 * Puente hacia `POST {API_URL}/verificaciones`. Reenvía el multipart tal cual
 * (sin leerlo entero en memoria) y agrega el token de la cookie httpOnly, que
 * el navegador no puede leer. El backend valida tipo, tamaño y contenido.
 */
export async function POST(request: NextRequest) {
  const { token, conSesion } = await sesionDeRuta(request.cookies);
  if (!token) return conSesion(NextResponse.json({ message: "No autenticado." }, { status: 401 }));

  const tipo = request.headers.get("content-type") ?? "";
  if (!tipo.startsWith("multipart/form-data") || !request.body) {
    return conSesion(
      NextResponse.json(
        { message: "Debes adjuntar el documento en el campo documento." },
        { status: 400 },
      ),
    );
  }

  const largo = Number(request.headers.get("content-length"));
  if (Number.isFinite(largo) && largo > MAX_DOCUMENTO_BYTES + MARGEN_MULTIPART) {
    return conSesion(
      NextResponse.json({ message: MENSAJES_VERIFICACION.tamano }, { status: 413 }),
    );
  }

  const destino = urlApi("verificaciones");
  if (!destino) return conSesion(NextResponse.json({ message: "Falta API_URL." }, { status: 500 }));

  try {
    const respuesta = await fetch(destino, {
      method: "POST",
      headers: { Authorization: `Bearer ${token}`, "Content-Type": tipo },
      body: request.body,
      // Node exige `duplex` para enviar un cuerpo en streaming.
      duplex: "half",
      cache: "no-store",
    } as RequestInit & { duplex: "half" });
    return conSesion(
      NextResponse.json(await respuesta.json().catch(() => ({})), {
        status: respuesta.status,
      }),
    );
  } catch {
    return conSesion(
      NextResponse.json({ message: "No se pudo contactar a la API." }, { status: 502 }),
    );
  }
}
