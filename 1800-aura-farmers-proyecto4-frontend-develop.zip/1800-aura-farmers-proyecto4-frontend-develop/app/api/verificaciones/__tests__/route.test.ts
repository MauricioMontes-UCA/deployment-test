import { NextRequest } from "next/server";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { GET } from "../mi-estado/route";
import { POST } from "../route";

const { obtenerAccesoVigente } = vi.hoisted(() => ({ obtenerAccesoVigente: vi.fn() }));
vi.mock("@/lib/sesion-vigente", async (importar) => ({
  ...(await importar<typeof import("@/lib/sesion-vigente")>()),
  obtenerAccesoVigente,
}));

const fetchSimulado = vi.fn();
vi.stubGlobal("fetch", fetchSimulado);

const SESION_NUEVA = { accessToken: "acceso-nuevo", refreshToken: "refresh-nuevo", expiresIn: 900 };

function peticion(metodo: "GET" | "POST", cuerpo?: BodyInit, tipo?: string) {
  return new NextRequest("http://localhost/api/verificaciones", {
    method: metodo,
    body: cuerpo,
    headers: tipo ? { "content-type": tipo } : undefined,
    ...(cuerpo ? ({ duplex: "half" } as object) : {}),
  });
}

beforeEach(() => {
  vi.stubEnv("API_URL", "http://api.test/api/v1");
  fetchSimulado.mockReset();
  obtenerAccesoVigente.mockReset();
});

describe("GET /api/verificaciones/mi-estado", () => {
  it("sin sesión responde 401 y no llama al backend", async () => {
    obtenerAccesoVigente.mockResolvedValue({ acceso: undefined, sesionNueva: null, refreshRechazado: false });
    const respuesta = await GET(peticion("GET"));
    expect(respuesta.status).toBe(401);
    expect(fetchSimulado).not.toHaveBeenCalled();
  });

  it("reenvía con el token y escribe las cookies si hubo renovación", async () => {
    obtenerAccesoVigente.mockResolvedValue({
      acceso: "acceso-nuevo",
      sesionNueva: SESION_NUEVA,
      refreshRechazado: false,
    });
    fetchSimulado.mockResolvedValue(Response.json({ estado: "EN_REVISION" }, { status: 200 }));

    const respuesta = await GET(peticion("GET"));

    expect(respuesta.status).toBe(200);
    expect(fetchSimulado.mock.calls[0][0].toString()).toBe("http://api.test/api/v1/verificaciones/mi-estado");
    expect(fetchSimulado.mock.calls[0][1].headers.Authorization).toBe("Bearer acceso-nuevo");
    expect(respuesta.cookies.get("access_token")?.value).toBe("acceso-nuevo");
    expect(respuesta.cookies.get("refresh_token")?.value).toBe("refresh-nuevo");
  });

  it("borra las cookies cuando el backend rechazó el refresh token", async () => {
    obtenerAccesoVigente.mockResolvedValue({ acceso: undefined, sesionNueva: null, refreshRechazado: true });
    const respuesta = await GET(peticion("GET"));
    expect(respuesta.status).toBe(401);
    expect(respuesta.headers.get("set-cookie")).toContain("access_token=;");
  });
});

describe("POST /api/verificaciones", () => {
  it("exige multipart y responde 400 sin tocar el backend", async () => {
    obtenerAccesoVigente.mockResolvedValue({ acceso: "t", sesionNueva: null, refreshRechazado: false });
    const respuesta = await POST(peticion("POST", "{}", "application/json"));
    expect(respuesta.status).toBe(400);
    expect(fetchSimulado).not.toHaveBeenCalled();
  });

  it("sin sesión responde 401", async () => {
    obtenerAccesoVigente.mockResolvedValue({ acceso: undefined, sesionNueva: null, refreshRechazado: false });
    const respuesta = await POST(peticion("POST", "x", "multipart/form-data; boundary=a"));
    expect(respuesta.status).toBe(401);
  });
});
