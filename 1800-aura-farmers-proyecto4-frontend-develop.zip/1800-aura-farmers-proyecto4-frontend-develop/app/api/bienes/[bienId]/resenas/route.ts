import { NextResponse, type NextRequest } from "next/server";

const ID_BIEN = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const PAGINA = /^[1-9]\d*$/;

/**
 * Puente hacia `GET {API_URL}/bienes/:bienId/resenas?pagina=n` (BE-15.2) para
 * «Ver más reseñas». El endpoint es público, así que no se agrega token; el
 * puente existe para que el navegador no dependa de la URL del backend.
 */
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ bienId: string }> },
) {
  const { bienId } = await params;
  const pagina = request.nextUrl.searchParams.get("pagina") ?? "1";
  if (!ID_BIEN.test(bienId) || !PAGINA.test(pagina)) {
    return NextResponse.json({ message: "Bien o página inválidos." }, { status: 400 });
  }

  const apiUrl = process.env.API_URL;
  if (!apiUrl) return NextResponse.json({ message: "Falta API_URL." }, { status: 500 });

  const destino = new URL(`bienes/${bienId}/resenas`, apiUrl.replace(/\/?$/, "/"));
  destino.searchParams.set("pagina", pagina);
  try {
    const respuesta = await fetch(destino, { cache: "no-store", signal: AbortSignal.timeout(5000) });
    return NextResponse.json(await respuesta.json().catch(() => ({})), { status: respuesta.status });
  } catch {
    return NextResponse.json({ message: "No se pudo contactar a la API." }, { status: 502 });
  }
}
