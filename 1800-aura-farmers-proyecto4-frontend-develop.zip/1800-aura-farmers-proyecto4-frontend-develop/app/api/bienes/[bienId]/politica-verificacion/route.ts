import { NextResponse, type NextRequest } from "next/server";
import { llamarBackend } from "@/lib/api-backend";

const ID_BIEN = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

type Contexto = { params: Promise<{ bienId: string }> };

/** Puente hacia `GET {API_URL}/bienes/:bienId/politica-verificacion` (BE-19.1). */
export async function GET(request: NextRequest, { params }: Contexto) {
  const { bienId } = await params;
  if (!ID_BIEN.test(bienId)) {
    return NextResponse.json({ message: "Bien inválido." }, { status: 400 });
  }
  return llamarBackend(request, `bienes/${bienId}/politica-verificacion`);
}

/** Puente hacia `PUT {API_URL}/bienes/:bienId/politica-verificacion` (BE-19.1). */
export async function PUT(request: NextRequest, { params }: Contexto) {
  const { bienId } = await params;
  if (!ID_BIEN.test(bienId)) {
    return NextResponse.json({ message: "Bien inválido." }, { status: 400 });
  }

  const cuerpo = await request.json().catch(() => null);
  if (typeof cuerpo?.soloVerificados !== "boolean") {
    return NextResponse.json(
      { message: "soloVerificados debe ser true o false." },
      { status: 400 },
    );
  }
  return llamarBackend(request, `bienes/${bienId}/politica-verificacion`, {
    method: "PUT",
    body: { soloVerificados: cuerpo.soloVerificados },
  });
}
