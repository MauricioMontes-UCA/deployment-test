import { NextRequest } from "next/server";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { GET, PUT } from "../route";

const { obtenerAccesoVigente } = vi.hoisted(() => ({ obtenerAccesoVigente: vi.fn() }));
vi.mock("@/lib/sesion-vigente", async (importar) => ({
  ...(await importar<typeof import("@/lib/sesion-vigente")>()),
  obtenerAccesoVigente,
}));

const fetchSimulado = vi.fn();
vi.stubGlobal("fetch", fetchSimulado);

const BIEN = "123e4567-e89b-42d3-a456-426614174000";
const contexto = { params: Promise.resolve({ bienId: BIEN }) };
const SESION_NUEVA = { accessToken: "acceso-nuevo", refreshToken: "refresh-nuevo", expiresIn: 900 };

function peticion(metodo: "GET" | "PUT", cuerpo?: unknown) {
  return new NextRequest(`http://localhost/api/bienes/${BIEN}/politica-verificacion`, {
    method: metodo,
    body: cuerpo === undefined ? undefined : JSON.stringify(cuerpo),
  });
}

beforeEach(() => {
  vi.stubEnv("API_URL", "http://api.test/api/v1");
  fetchSimulado.mockReset();
  obtenerAccesoVigente.mockReset();
  obtenerAccesoVigente.mockResolvedValue({ acceso: "token", sesionNueva: null, refreshRechazado: false });
});

describe("/api/bienes/[bienId]/politica-verificacion", () => {
  it("GET sin sesión responde 401 y no llama al backend", async () => {
    obtenerAccesoVigente.mockResolvedValue({ acceso: undefined, sesionNueva: null, refreshRechazado: false });
    const respuesta = await GET(peticion("GET"), contexto);
    expect(respuesta.status).toBe(401);
    expect(fetchSimulado).not.toHaveBeenCalled();
  });

  it("GET reenvía con el token y escribe las cookies si hubo renovación", async () => {
    obtenerAccesoVigente.mockResolvedValue({
      acceso: "acceso-nuevo",
      sesionNueva: SESION_NUEVA,
      refreshRechazado: false,
    });
    fetchSimulado.mockResolvedValue(Response.json({ soloVerificados: true }, { status: 200 }));

    const respuesta = await GET(peticion("GET"), contexto);

    expect(respuesta.status).toBe(200);
    expect(fetchSimulado.mock.calls[0][0].toString()).toBe(
      `http://api.test/api/v1/bienes/${BIEN}/politica-verificacion`,
    );
    expect(fetchSimulado.mock.calls[0][1].headers.Authorization).toBe("Bearer acceso-nuevo");
    expect(respuesta.cookies.get("access_token")?.value).toBe("acceso-nuevo");
  });

  it("borra las cookies cuando el backend rechazó el refresh token", async () => {
    obtenerAccesoVigente.mockResolvedValue({ acceso: undefined, sesionNueva: null, refreshRechazado: true });
    const respuesta = await GET(peticion("GET"), contexto);
    expect(respuesta.status).toBe(401);
    expect(respuesta.headers.get("set-cookie")).toContain("access_token=;");
  });

  it("PUT valida el cuerpo y reenvía solo soloVerificados", async () => {
    const invalido = await PUT(peticion("PUT", { soloVerificados: "si" }), contexto);
    expect(invalido.status).toBe(400);
    expect(fetchSimulado).not.toHaveBeenCalled();

    fetchSimulado.mockResolvedValue(Response.json({ soloVerificados: false }, { status: 200 }));
    const ok = await PUT(peticion("PUT", { soloVerificados: false, otro: 1 }), contexto);
    expect(ok.status).toBe(200);
    expect(fetchSimulado.mock.calls[0][1].method).toBe("PUT");
    expect(fetchSimulado.mock.calls[0][1].body).toBe(JSON.stringify({ soloVerificados: false }));
  });

  it("responde 502 si el backend no contesta a tiempo", async () => {
    fetchSimulado.mockRejectedValue(new DOMException("tiempo agotado", "TimeoutError"));
    const respuesta = await GET(peticion("GET"), contexto);
    expect(respuesta.status).toBe(502);
    expect(fetchSimulado.mock.calls[0][1].signal).toBeInstanceOf(AbortSignal);
  });

  it("rechaza un id de bien inválido", async () => {
    const respuesta = await GET(peticion("GET"), { params: Promise.resolve({ bienId: "x" }) });
    expect(respuesta.status).toBe(400);
  });
});
