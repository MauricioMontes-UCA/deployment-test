import { NextResponse, type NextRequest } from "next/server";
import { llamarBackend } from "@/lib/api-backend";
import { ID_UUID } from "@/lib/bloqueos";
import { esFechaValida } from "@/lib/disponibilidad";

type Contexto = { params: Promise<{ bienId: string }> };

/** Puente hacia `GET {API_URL}/bienes/:bienId/bloqueos` (BE-7.3): bloqueos vigentes con su id. */
export async function GET(request: NextRequest, { params }: Contexto) {
  const { bienId } = await params;
  if (!ID_UUID.test(bienId)) {
    return NextResponse.json({ message: "Bien inválido." }, { status: 400 });
  }
  return llamarBackend(request, `bienes/${bienId}/bloqueos`);
}

/** Puente hacia `POST {API_URL}/bienes/:bienId/bloqueos` (BE-7.1). Solo reenvía `fechaInicio` y `fechaFin`. */
export async function POST(request: NextRequest, { params }: Contexto) {
  const { bienId } = await params;
  if (!ID_UUID.test(bienId)) {
    return NextResponse.json({ message: "Bien inválido." }, { status: 400 });
  }

  const cuerpo: unknown = await request.json().catch(() => null);
  const { fechaInicio, fechaFin } = (cuerpo ?? {}) as Record<string, unknown>;
  if (!esFechaValida(fechaInicio) || !esFechaValida(fechaFin)) {
    return NextResponse.json({ message: "Las fechas deben ser AAAA-MM-DD." }, { status: 400 });
  }

  return llamarBackend(request, `bienes/${bienId}/bloqueos`, {
    method: "POST",
    body: { fechaInicio, fechaFin },
  });
}
