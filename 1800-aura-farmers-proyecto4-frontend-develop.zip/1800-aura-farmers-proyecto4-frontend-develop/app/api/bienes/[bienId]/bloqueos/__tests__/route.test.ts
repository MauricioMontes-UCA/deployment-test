// @vitest-environment node
import { NextRequest } from "next/server";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { DELETE } from "../[id]/route";
import { GET, POST } from "../route";
import type { SesionApi } from "@/lib/auth-api";
import { obtenerAccesoVigente } from "@/lib/sesion-vigente";

vi.mock("@/lib/sesion-vigente", async (original) => ({
  ...(await original<typeof import("@/lib/sesion-vigente")>()),
  obtenerAccesoVigente: vi.fn(),
}));

const sesionVigente = { acceso: "token-de-prueba", sesionNueva: null, refreshRechazado: false };

const BIEN = "10000000-0000-4000-8000-000000000001";
const BLOQUEO = "20000000-0000-4000-8000-000000000002";
const API = "http://api.test/api/v1";

const fetchSimulado = vi.fn();

function peticion(metodo: string, cuerpo?: unknown) {
  return new NextRequest(`http://localhost/api/bienes/${BIEN}/bloqueos`, {
    method: metodo,
    body: cuerpo === undefined ? undefined : typeof cuerpo === "string" ? cuerpo : JSON.stringify(cuerpo),
  });
}
const contexto = (bienId = BIEN) => ({ params: Promise.resolve({ bienId }) });
const contextoId = (bienId = BIEN, id = BLOQUEO) => ({ params: Promise.resolve({ bienId, id }) });
const rango = { fechaInicio: "2026-12-24", fechaFin: "2026-12-26" };

beforeEach(() => {
  vi.stubEnv("API_URL", API);
  vi.mocked(obtenerAccesoVigente).mockResolvedValue(sesionVigente);
  fetchSimulado.mockReset();
  vi.stubGlobal("fetch", fetchSimulado);
});

afterEach(() => {
  vi.unstubAllEnvs();
  vi.unstubAllGlobals();
});

describe("sesión y configuración", () => {
  it.each([
    ["GET", () => GET(peticion("GET"), contexto())],
    ["POST", () => POST(peticion("POST", rango), contexto())],
    ["DELETE", () => DELETE(peticion("DELETE"), contextoId())],
  ])("%s sin sesión responde 401 sin llamar al backend", async (_nombre, llamar) => {
    vi.mocked(obtenerAccesoVigente).mockResolvedValue({ ...sesionVigente, acceso: undefined });
    expect((await llamar()).status).toBe(401);
    expect(fetchSimulado).not.toHaveBeenCalled();
  });

  it("si hubo que renovar el token, las cookies nuevas viajan también en los errores del backend", async () => {
    fetchSimulado.mockResolvedValue(new Response(JSON.stringify({ message: "x" }), { status: 409 }));
    vi.mocked(obtenerAccesoVigente).mockResolvedValue({
      acceso: "acceso-nuevo",
      sesionNueva: { accessToken: "acceso-nuevo", refreshToken: "refresh-nuevo", expiresIn: 900 } as SesionApi,
      refreshRechazado: false,
    });

    const respuesta = await POST(peticion("POST", rango), contexto());

    expect(respuesta.status).toBe(409);
    expect(respuesta.cookies.get("access_token")?.value).toBe("acceso-nuevo");
    expect(respuesta.cookies.get("refresh_token")?.value).toBe("refresh-nuevo");
  });

  it("si el refresh fue rechazado responde 401 y borra las cookies", async () => {
    vi.mocked(obtenerAccesoVigente).mockResolvedValue({ acceso: undefined, sesionNueva: null, refreshRechazado: true });

    const respuesta = await GET(peticion("GET"), contexto());

    expect(respuesta.status).toBe(401);
    expect(respuesta.cookies.get("access_token")?.value).toBe("");
  });

  it("sin API_URL responde 500", async () => {
    vi.stubEnv("API_URL", "");
    expect((await GET(peticion("GET"), contexto())).status).toBe(500);
  });

  it("si el backend no responde, 502", async () => {
    fetchSimulado.mockRejectedValue(new Error("red"));
    expect((await GET(peticion("GET"), contexto())).status).toBe(502);
  });
});

describe("GET /api/bienes/[bienId]/bloqueos", () => {
  it("reenvía con el token y devuelve la lista", async () => {
    const lista = [{ id: BLOQUEO, ...rango }];
    fetchSimulado.mockResolvedValue(new Response(JSON.stringify(lista), { status: 200 }));

    const respuesta = await GET(peticion("GET"), contexto());

    expect(respuesta.status).toBe(200);
    expect(await respuesta.json()).toEqual(lista);
    const [url, init] = fetchSimulado.mock.calls[0];
    expect(String(url)).toBe(`${API}/bienes/${BIEN}/bloqueos`);
    expect(init.method).toBe("GET");
    expect(init.headers.Authorization).toBe("Bearer token-de-prueba");
  });

  it("rechaza un bienId que no es UUID", async () => {
    expect((await GET(peticion("GET"), contexto("x"))).status).toBe(400);
    expect(fetchSimulado).not.toHaveBeenCalled();
  });

  it("conserva el estado de error del backend", async () => {
    fetchSimulado.mockResolvedValue(new Response(JSON.stringify({ message: "no" }), { status: 403 }));
    expect((await GET(peticion("GET"), contexto())).status).toBe(403);
  });
});

describe("POST /api/bienes/[bienId]/bloqueos", () => {
  it("reenvía solo las fechas y conserva el 201", async () => {
    fetchSimulado.mockResolvedValue(
      new Response(JSON.stringify({ id: BLOQUEO, bienId: BIEN, ...rango }), { status: 201 }),
    );

    const respuesta = await POST(peticion("POST", { ...rango, bienId: "otro", extra: 1 }), contexto());

    expect(respuesta.status).toBe(201);
    const [url, init] = fetchSimulado.mock.calls[0];
    expect(String(url)).toBe(`${API}/bienes/${BIEN}/bloqueos`);
    expect(init.method).toBe("POST");
    expect(JSON.parse(init.body)).toEqual(rango);
  });

  it.each([
    ["JSON inválido", "{no"],
    ["sin fechas", {}],
    ["fecha irreal", { fechaInicio: "2026-02-30", fechaFin: "2026-03-01" }],
    ["formato distinto", { fechaInicio: "24/12/2026", fechaFin: "26/12/2026" }],
  ])("rechaza con 400: %s", async (_nombre, cuerpo) => {
    expect((await POST(peticion("POST", cuerpo), contexto())).status).toBe(400);
    expect(fetchSimulado).not.toHaveBeenCalled();
  });

  it("devuelve el 409 del backend con sus ids", async () => {
    fetchSimulado.mockResolvedValue(
      new Response(JSON.stringify({ message: "x", reservaId: BLOQUEO }), { status: 409 }),
    );
    const respuesta = await POST(peticion("POST", rango), contexto());
    expect(respuesta.status).toBe(409);
    expect((await respuesta.json()).reservaId).toBe(BLOQUEO);
  });
});

describe("DELETE /api/bienes/[bienId]/bloqueos/[id]", () => {
  it("responde 204 sin cuerpo", async () => {
    fetchSimulado.mockResolvedValue(new Response(null, { status: 204 }));

    const respuesta = await DELETE(peticion("DELETE"), contextoId());

    expect(respuesta.status).toBe(204);
    const [url, init] = fetchSimulado.mock.calls[0];
    expect(String(url)).toBe(`${API}/bienes/${BIEN}/bloqueos/${BLOQUEO}`);
    expect(init.method).toBe("DELETE");
  });

  it("rechaza ids que no son UUID", async () => {
    expect((await DELETE(peticion("DELETE"), contextoId(BIEN, "../x"))).status).toBe(400);
    expect(fetchSimulado).not.toHaveBeenCalled();
  });

  it("conserva el 404 del backend", async () => {
    fetchSimulado.mockResolvedValue(new Response(JSON.stringify({ message: "no existe" }), { status: 404 }));
    expect((await DELETE(peticion("DELETE"), contextoId())).status).toBe(404);
  });
});
