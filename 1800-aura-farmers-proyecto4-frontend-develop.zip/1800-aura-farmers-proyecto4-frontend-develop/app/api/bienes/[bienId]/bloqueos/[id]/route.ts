import { NextResponse, type NextRequest } from "next/server";
import { llamarBackend } from "@/lib/api-backend";
import { ID_UUID } from "@/lib/bloqueos";

/** Puente hacia `DELETE {API_URL}/bienes/:bienId/bloqueos/:id` (BE-7.1). */
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ bienId: string; id: string }> },
) {
  const { bienId, id } = await params;
  if (!ID_UUID.test(bienId) || !ID_UUID.test(id)) {
    return NextResponse.json({ message: "Identificador inválido." }, { status: 400 });
  }
  return llamarBackend(request, `bienes/${bienId}/bloqueos/${id}`, { method: "DELETE" });
}
