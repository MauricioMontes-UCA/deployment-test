import { NextResponse, type NextRequest } from "next/server";
import { aplicarCambiosDeSesion, obtenerAccesoVigente } from "@/lib/sesion-vigente";

const FORMATO_DIA = /^\d{4}-\d{2}-\d{2}$/;
const ID_BIEN = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Puente hacia `GET {API_URL}/bienes/:bienId/disponibilidad` (`API_URL` ya incluye
 * el prefijo `/api/v1`, igual que para `auth/login`). El token vive en
 * una cookie httpOnly que el navegador no puede leer, así que el calendario
 * (componente de cliente) consulta aquí y este handler agrega el token.
 */
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ bienId: string }> },
) {
  const { bienId } = await params;
  if (!ID_BIEN.test(bienId)) {
    return NextResponse.json({ message: "Bien inválido." }, { status: 400 });
  }

  // Las rutas /api no pasan por el proxy: si el access token venció mientras
  // el usuario estaba en la página, se renueva aquí (compartido con el proxy)
  // y cada respuesta lleva las cookies nuevas.
  const sesion = await obtenerAccesoVigente(request.cookies);
  const conSesion = (respuesta: NextResponse) => aplicarCambiosDeSesion(respuesta, sesion);
  const token = sesion.acceso;
  if (!token) {
    return conSesion(NextResponse.json({ message: "No autenticado." }, { status: 401 }));
  }

  const apiUrl = process.env.API_URL;
  if (!apiUrl) {
    return conSesion(NextResponse.json({ message: "Falta API_URL." }, { status: 500 }));
  }

  const destino = new URL(`bienes/${bienId}/disponibilidad`, apiUrl.replace(/\/?$/, "/"));
  for (const campo of ["desde", "hasta"]) {
    const valor = request.nextUrl.searchParams.get(campo);
    if (valor === null) continue;
    if (!FORMATO_DIA.test(valor)) {
      return conSesion(
        NextResponse.json({ message: `\`${campo}\` debe ser AAAA-MM-DD.` }, { status: 400 }),
      );
    }
    destino.searchParams.set(campo, valor);
  }

  try {
    const respuesta = await fetch(destino, {
      headers: { Authorization: `Bearer ${token}` },
      cache: "no-store",
    });
    return conSesion(
      NextResponse.json(await respuesta.json().catch(() => ({})), {
        status: respuesta.status,
      }),
    );
  } catch {
    return conSesion(NextResponse.json({ message: "No se pudo contactar a la API." }, { status: 502 }));
  }
}
