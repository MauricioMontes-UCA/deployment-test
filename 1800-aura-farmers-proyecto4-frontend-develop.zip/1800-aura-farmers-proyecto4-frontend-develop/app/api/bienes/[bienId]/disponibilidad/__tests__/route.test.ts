// @vitest-environment node
import { NextRequest } from "next/server";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { GET } from "../route";
import { obtenerAccesoVigente } from "@/lib/sesion-vigente";

vi.mock("@/lib/sesion-vigente", async (original) => ({
  ...(await original<typeof import("@/lib/sesion-vigente")>()),
  obtenerAccesoVigente: vi.fn(),
}));

const BIEN = "10000000-0000-4000-8000-000000000001";
const API = "http://api.test/api/v1";

function pedir(bienId: string = BIEN, consulta = "") {
  const peticion = new NextRequest(`http://localhost/api/bienes/${bienId}/disponibilidad${consulta}`);
  return GET(peticion, { params: Promise.resolve({ bienId }) });
}

const fetchSimulado = vi.fn();

beforeEach(() => {
  vi.stubEnv("API_URL", API);
  vi.mocked(obtenerAccesoVigente).mockResolvedValue({ acceso: "token-de-prueba", sesionNueva: null, refreshRechazado: false });
  fetchSimulado.mockReset();
  vi.stubGlobal("fetch", fetchSimulado);
});

afterEach(() => {
  vi.unstubAllEnvs();
  vi.unstubAllGlobals();
});

describe("GET /api/bienes/[bienId]/disponibilidad", () => {
  it("sin sesión responde 401 y no llama al backend", async () => {
    vi.mocked(obtenerAccesoVigente).mockResolvedValue({ acceso: undefined, sesionNueva: null, refreshRechazado: false });

    const respuesta = await pedir();

    expect(respuesta.status).toBe(401);
    expect(await respuesta.json()).toEqual({ message: "No autenticado." });
    expect(fetchSimulado).not.toHaveBeenCalled();
  });

  it("rechaza un bienId que no es un UUID sin llamar al backend", async () => {
    const respuesta = await pedir("no-es-un-uuid");

    expect(respuesta.status).toBe(400);
    expect(fetchSimulado).not.toHaveBeenCalled();
  });

  it.each(["desde=18/11/2026", "hasta=mañana", "desde=2026-11-18;DROP"])(
    "rechaza fechas con formato inválido (%s)",
    async (consulta) => {
      const respuesta = await pedir(BIEN, `?${consulta}`);

      expect(respuesta.status).toBe(400);
      expect(fetchSimulado).not.toHaveBeenCalled();
    },
  );

  it("sin API_URL responde 500", async () => {
    vi.stubEnv("API_URL", "");

    const respuesta = await pedir();

    expect(respuesta.status).toBe(500);
    expect(fetchSimulado).not.toHaveBeenCalled();
  });

  it("reenvía al backend con el token, la ruta y las fechas, y devuelve su respuesta", async () => {
    const cuerpo = {
      bienId: BIEN,
      reservados: [{ fechaInicio: "2026-12-10", fechaFin: "2026-12-12" }],
      bloqueados: [],
    };
    fetchSimulado.mockResolvedValue(new Response(JSON.stringify(cuerpo), { status: 200 }));

    const respuesta = await pedir(BIEN, "?desde=2026-11-18&hasta=2027-11-17");

    expect(respuesta.status).toBe(200);
    expect(await respuesta.json()).toEqual(cuerpo);
    const [destino, opciones] = fetchSimulado.mock.calls[0];
    expect(String(destino)).toBe(`${API}/bienes/${BIEN}/disponibilidad?desde=2026-11-18&hasta=2027-11-17`);
    expect(opciones.headers).toEqual({ Authorization: "Bearer token-de-prueba" });
  });

  it("acepta un API_URL con o sin barra final", async () => {
    vi.stubEnv("API_URL", `${API}/`);
    fetchSimulado.mockResolvedValue(new Response("{}", { status: 200 }));

    await pedir();

    expect(String(fetchSimulado.mock.calls[0][0])).toBe(`${API}/bienes/${BIEN}/disponibilidad`);
  });

  it.each([
    [401, { message: "Token expirado." }],
    [404, { message: "El bien no existe." }],
    [400, { message: "La ventana de consulta no puede superar 12 meses." }],
    [500, { message: "Error interno." }],
  ])("conserva el estado %i y el mensaje del backend", async (estado, cuerpo) => {
    fetchSimulado.mockResolvedValue(new Response(JSON.stringify(cuerpo), { status: estado }));

    const respuesta = await pedir();

    expect(respuesta.status).toBe(estado);
    expect(await respuesta.json()).toEqual(cuerpo);
  });

  it("si el backend responde algo que no es JSON, conserva el estado con un cuerpo vacío", async () => {
    fetchSimulado.mockResolvedValue(new Response("<html>Bad Gateway</html>", { status: 502 }));

    const respuesta = await pedir();

    expect(respuesta.status).toBe(502);
    expect(await respuesta.json()).toEqual({});
  });

  it("si no se puede contactar al backend responde 502", async () => {
    fetchSimulado.mockRejectedValue(new TypeError("fetch failed"));

    const respuesta = await pedir();

    expect(respuesta.status).toBe(502);
    expect(await respuesta.json()).toEqual({ message: "No se pudo contactar a la API." });
  });
});
