// @vitest-environment node
import { NextRequest } from "next/server";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { reiniciarRenovaciones } from "@/lib/sesion-vigente";
import { tokenDePrueba } from "@/pruebas/tokens";
import { GET } from "../route";

const BIEN = "10000000-0000-4000-8000-000000000001";
const fetchFalso = vi.fn();

beforeEach(() => {
  reiniciarRenovaciones();
  vi.stubEnv("API_URL", "http://api.test/api/v1");
  vi.stubEnv("REFRESH_TOKEN_EXPIRES_IN_DAYS", "7");
  vi.stubGlobal("fetch", fetchFalso);
});

afterEach(() => {
  vi.unstubAllEnvs();
  vi.unstubAllGlobals();
  fetchFalso.mockReset();
});

function pedir(cookie: string) {
  const peticion = new NextRequest(`http://localhost/api/bienes/${BIEN}/disponibilidad`, { headers: { cookie } });
  return GET(peticion, { params: Promise.resolve({ bienId: BIEN }) });
}

describe("disponibilidad con el access token vencido", () => {
  it("lo renueva, consulta con el token nuevo y devuelve las cookies nuevas", async () => {
    const nuevo = tokenDePrueba({ exp: Math.floor(Date.now() / 1000) + 600 });
    fetchFalso
      .mockResolvedValueOnce(new Response(JSON.stringify({ accessToken: nuevo, refreshToken: "r2", expiresIn: 900 }), { status: 200 }))
      .mockResolvedValueOnce(new Response(JSON.stringify({ dias: [] }), { status: 200 }));

    const vencido = tokenDePrueba({ exp: Math.floor(Date.now() / 1000) - 60 });
    const respuesta = await pedir(`access_token=${vencido}; refresh_token=r1`);

    expect(respuesta.status).toBe(200);
    expect(String(fetchFalso.mock.calls[0][0])).toBe("http://api.test/api/v1/auth/refresh");
    expect(fetchFalso.mock.calls[1][1].headers.Authorization).toBe(`Bearer ${nuevo}`);
    expect(respuesta.cookies.get("refresh_token")?.value).toBe("r2");
  });

  it("si el refresh ya no sirve responde 401 y borra las cookies", async () => {
    fetchFalso.mockResolvedValueOnce(new Response(JSON.stringify({ statusCode: 401 }), { status: 401 }));
    const vencido = tokenDePrueba({ exp: Math.floor(Date.now() / 1000) - 60 });
    const respuesta = await pedir(`access_token=${vencido}; refresh_token=r1`);
    expect(respuesta.status).toBe(401);
    expect(respuesta.cookies.get("refresh_token")?.value).toBe("");
  });
});
