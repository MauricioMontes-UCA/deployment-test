import { NextResponse, type NextRequest } from "next/server";
import { PAGINA_VALIDA } from "@/lib/mis-bienes";
import { reenviarAApi } from "@/lib/solicitud/servidor";

/**
 * Puente hacia `GET {API_URL}/bienes/mios?pagina=` (BE-1.3). Valida la página
 * antes de llamar al backend; el token, su renovación y las cookies las
 * resuelve `reenviarAApi`. El 403 del arrendatario y el 401 pasan tal cual.
 */
export async function GET(request: NextRequest) {
  const pagina = request.nextUrl.searchParams.get("pagina");
  if (pagina !== null && !PAGINA_VALIDA.test(pagina)) {
    return NextResponse.json({ message: "Página inválida." }, { status: 400 });
  }
  return reenviarAApi(request, pagina ? `bienes/mios?pagina=${pagina}` : "bienes/mios", {
    method: "GET",
  });
}
