import { NextRequest } from "next/server";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { GET } from "../route";

const { obtenerAccesoVigente } = vi.hoisted(() => ({ obtenerAccesoVigente: vi.fn() }));
vi.mock("@/lib/sesion-vigente", async (importar) => ({
  ...(await importar<typeof import("@/lib/sesion-vigente")>()),
  obtenerAccesoVigente,
}));

const fetchSimulado = vi.fn();
vi.stubGlobal("fetch", fetchSimulado);

const peticion = (consulta = "") => new NextRequest(`http://localhost/api/bienes/mios${consulta}`);

beforeEach(() => {
  vi.stubEnv("API_URL", "http://api.test/api/v1");
  fetchSimulado.mockReset();
  obtenerAccesoVigente.mockReset();
  obtenerAccesoVigente.mockResolvedValue({ acceso: "token", sesionNueva: null, refreshRechazado: false });
});

describe("GET /api/bienes/mios", () => {
  it("sin sesión responde 401 y no llama al backend", async () => {
    obtenerAccesoVigente.mockResolvedValue({ acceso: undefined, sesionNueva: null, refreshRechazado: false });
    const respuesta = await GET(peticion());
    expect(respuesta.status).toBe(401);
    expect(fetchSimulado).not.toHaveBeenCalled();
  });

  it.each(["?pagina=0", "?pagina=1e2", "?pagina=01", "?pagina=-1", "?pagina="])(
    "rechaza %s con 400 sin llamar al backend",
    async (consulta) => {
      expect((await GET(peticion(consulta))).status).toBe(400);
      expect(fetchSimulado).not.toHaveBeenCalled();
    },
  );

  it("reenvía la página con el token y devuelve el cuerpo", async () => {
    const cuerpo = { items: [], pagina: 2, total: 21, hayMas: false };
    fetchSimulado.mockResolvedValue(Response.json(cuerpo));
    const respuesta = await GET(peticion("?pagina=2"));
    expect(respuesta.status).toBe(200);
    expect(await respuesta.json()).toEqual(cuerpo);
    expect(fetchSimulado.mock.calls[0][0].toString()).toBe("http://api.test/api/v1/bienes/mios?pagina=2");
    expect(fetchSimulado.mock.calls[0][1].headers.Authorization).toBe("Bearer token");
  });

  it("sin parámetros llama al listado sin página", async () => {
    fetchSimulado.mockResolvedValue(Response.json({ items: [], pagina: 1, total: 0, hayMas: false }));
    await GET(peticion());
    expect(fetchSimulado.mock.calls[0][0].toString()).toBe("http://api.test/api/v1/bienes/mios");
  });

  it("propaga el 403 del backend y responde 502 si no contesta", async () => {
    fetchSimulado.mockResolvedValue(Response.json({ message: "Prohibido" }, { status: 403 }));
    expect((await GET(peticion())).status).toBe(403);
    fetchSimulado.mockRejectedValue(new DOMException("tiempo agotado", "TimeoutError"));
    expect((await GET(peticion())).status).toBe(502);
  });
});
