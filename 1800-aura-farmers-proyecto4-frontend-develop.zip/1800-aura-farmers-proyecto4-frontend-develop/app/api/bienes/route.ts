import { NextResponse, type NextRequest } from "next/server";
import { TIEMPO_LIMITE_MS } from "@/lib/auth-api";
import { PARAMETROS_DE_BUSQUEDA } from "@/lib/busqueda";
import { obtenerApiUrl } from "@/lib/config";
import { aplicarCambiosDeSesion, obtenerAccesoVigente } from "@/lib/sesion-vigente";

/** Lo que se reenvía: los criterios de búsqueda y la paginación. */
const PERMITIDOS = [...PARAMETROS_DE_BUSQUEDA, "pagina", "tamano"];

/**
 * Puente hacia `GET {API_URL}/bienes` para la carga continua de /buscar: la
 * URL del backend solo existe en el servidor. La búsqueda es pública, así que
 * no envía token. Reenvía solo los parámetros conocidos y devuelve la
 * respuesta del backend con su mismo código (los 400 traen
 * `{ message, error, statusCode }`).
 */
export async function GET(request: NextRequest) {
  const destino = new URL("bienes", obtenerApiUrl());
  for (const campo of PERMITIDOS) {
    const valor = request.nextUrl.searchParams.get(campo);
    if (valor !== null) destino.searchParams.set(campo, valor);
  }

  try {
    const respuesta = await fetch(destino, {
      cache: "no-store",
      signal: AbortSignal.timeout(TIEMPO_LIMITE_MS),
    });
    return NextResponse.json(await respuesta.json().catch(() => ({})), {
      status: respuesta.status,
    });
  } catch {
    return NextResponse.json({ message: "No se pudo contactar a la API." }, { status: 502 });
  }
}

/**
 * Publica un bien: reenvía el multipart del navegador a POST /api/v1/bienes
 * con el JWT de la cookie, sin leer ni copiar el cuerpo (hasta 10 fotos de
 * 5 MB).
 *
 * Existe para que el formulario suba con XMLHttpRequest y muestre el progreso
 * real, sin exponer el token al JavaScript del navegador. Las rutas /api no
 * pasan por el proxy, así que si el access token venció mientras se llenaba el
 * formulario se renueva aquí, con la renovación compartida del proxy.
 *
 * Devuelve el código y el cuerpo del backend tal cual. Si el backend no
 * responde, 502.
 */
export async function POST(request: NextRequest) {
  const sesion = await obtenerAccesoVigente(request.cookies);
  const acceso = sesion.acceso;
  if (!acceso) {
    return aplicarCambiosDeSesion(
      NextResponse.json(
        { message: "Tu sesión expiró. Inicia sesión de nuevo.", statusCode: 401 },
        { status: 401 },
      ),
      sesion,
    );
  }

  let respuestaApi: Response;
  try {
    respuestaApi = await fetch(new URL("bienes", obtenerApiUrl()), {
      method: "POST",
      headers: {
        Authorization: `Bearer ${acceso}`,
        // Lleva el boundary del multipart; sin él el backend no puede leerlo.
        "Content-Type": request.headers.get("content-type") ?? "",
      },
      body: request.body,
      // Necesario en Node para enviar un cuerpo en stream.
      duplex: "half",
      cache: "no-store",
    } as RequestInit & { duplex: "half" });
  } catch {
    return NextResponse.json(
      { message: "No se pudo contactar al servidor.", statusCode: 502 },
      { status: 502 },
    );
  }

  const respuesta = new NextResponse(await respuestaApi.text(), {
    status: respuestaApi.status,
    headers: { "Content-Type": respuestaApi.headers.get("content-type") ?? "application/json" },
  });
  return aplicarCambiosDeSesion(respuesta, sesion);
}
