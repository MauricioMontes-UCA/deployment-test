// @vitest-environment node
import { NextRequest } from "next/server";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { GET } from "../route";

const API = "http://api.test/api/v1";
const fetchSimulado = vi.fn();

const pedir = (consulta = "") => GET(new NextRequest(`http://localhost/api/bienes${consulta}`));
const urlPedida = () => new URL(String(fetchSimulado.mock.calls[0][0]));

beforeEach(() => {
  vi.stubEnv("API_URL", API);
  fetchSimulado.mockReset();
  vi.stubGlobal("fetch", fetchSimulado);
});

afterEach(() => {
  vi.unstubAllEnvs();
  vi.unstubAllGlobals();
});

describe("GET /api/bienes", () => {
  it("reenvía los criterios y la paginación al backend, sin token", async () => {
    const pagina = { pagina: 2, tamanoPagina: 20, total: 45, hayMas: true, resultados: [] };
    fetchSimulado.mockResolvedValue(Response.json(pagina));

    const respuesta = await pedir(
      "?q=sal%C3%B3n&departamento=San+Salvador&municipio=Soyapango&categoria=Casa&pagina=2&tamano=20",
    );

    expect(respuesta.status).toBe(200);
    expect(await respuesta.json()).toEqual(pagina);
    const destino = urlPedida();
    expect(`${destino.origin}${destino.pathname}`).toBe(`${API}/bienes`);
    expect(Object.fromEntries(destino.searchParams)).toEqual({
      q: "salón",
      departamento: "San Salvador",
      municipio: "Soyapango",
      categoria: "Casa",
      pagina: "2",
      tamano: "20",
    });
    const init = fetchSimulado.mock.calls[0][1] as RequestInit;
    expect(new Headers(init.headers).has("Authorization")).toBe(false);
  });

  it("no reenvía parámetros desconocidos", async () => {
    fetchSimulado.mockResolvedValue(Response.json({}));

    await pedir("?q=taladro&arrendadorId=123&orden=precio");

    expect(Object.fromEntries(urlPedida().searchParams)).toEqual({ q: "taladro" });
  });

  it("devuelve el 400 del backend con su mismo cuerpo", async () => {
    const error = { message: ["La página debe ser de 1 a 10000."], error: "Bad Request", statusCode: 400 };
    fetchSimulado.mockResolvedValue(Response.json(error, { status: 400 }));

    const respuesta = await pedir("?pagina=0");

    expect(respuesta.status).toBe(400);
    expect(await respuesta.json()).toEqual(error);
  });

  it("responde 502 si el backend no contesta", async () => {
    fetchSimulado.mockRejectedValue(new TypeError("fetch failed"));

    const respuesta = await pedir();

    expect(respuesta.status).toBe(502);
    expect(await respuesta.json()).toEqual({ message: "No se pudo contactar a la API." });
  });
});
