// @vitest-environment node
import { NextRequest } from "next/server";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { reiniciarRenovaciones } from "@/lib/sesion-vigente";
import { tokenDePrueba } from "@/pruebas/tokens";
import { POST } from "./route";

const fetchFalso = vi.fn();
const vigente = () => tokenDePrueba({ exp: Math.floor(Date.now() / 1000) + 600, rol: "ARRENDADOR" });
const vencido = () => tokenDePrueba({ exp: Math.floor(Date.now() / 1000) - 60 });

function peticion(cookies: Record<string, string>) {
  const datos = new FormData();
  datos.set("titulo", "Salón de eventos");
  datos.append("fotos", new File(["png"], "a.png", { type: "image/png" }));
  const cookie = Object.entries(cookies).map(([k, v]) => `${k}=${v}`).join("; ");
  const base = new Request("http://localhost:3001/api/bienes", { method: "POST", body: datos });
  return new NextRequest(base, { headers: { cookie, "content-type": base.headers.get("content-type")! } });
}

function responder(status: number, cuerpo: unknown) {
  fetchFalso.mockResolvedValueOnce(new Response(JSON.stringify(cuerpo), { status }));
}

beforeEach(() => {
  reiniciarRenovaciones();
  vi.stubEnv("API_URL", "http://api.test/api/v1");
  vi.stubEnv("REFRESH_TOKEN_EXPIRES_IN_DAYS", "7");
  vi.stubGlobal("fetch", fetchFalso);
});

afterEach(() => {
  vi.unstubAllEnvs();
  vi.unstubAllGlobals();
  fetchFalso.mockReset();
});

describe("POST /api/bienes", () => {
  it("reenvía el multipart al backend con el JWT y el boundary", async () => {
    const acceso = vigente();
    responder(201, { id: "b1" });

    const respuesta = await POST(peticion({ access_token: acceso, refresh_token: "r" }));

    expect(respuesta.status).toBe(201);
    expect(await respuesta.json()).toEqual({ id: "b1" });
    const [url, init] = fetchFalso.mock.calls[0];
    expect(String(url)).toBe("http://api.test/api/v1/bienes");
    expect(init.headers.Authorization).toBe(`Bearer ${acceso}`);
    expect(init.headers["Content-Type"]).toMatch(/^multipart\/form-data; boundary=/);
    const reenviado = await new Response(init.body, { headers: { "content-type": init.headers["Content-Type"] } }).formData();
    expect(reenviado.get("titulo")).toBe("Salón de eventos");
    expect((reenviado.get("fotos") as File).name).toBe("a.png");
  });

  it.each([400, 403, 500])("devuelve el %i del backend tal cual", async (status) => {
    responder(status, { message: ["El título es obligatorio."], statusCode: status });
    const respuesta = await POST(peticion({ access_token: vigente() }));
    expect(respuesta.status).toBe(status);
    expect((await respuesta.json()).message).toEqual(["El título es obligatorio."]);
  });

  it("renueva el token vencido antes de reenviar y guarda las cookies nuevas", async () => {
    const nuevo = vigente();
    responder(200, { accessToken: nuevo, refreshToken: "r2", expiresIn: 900 });
    responder(201, { id: "b1" });

    const respuesta = await POST(peticion({ access_token: vencido(), refresh_token: "r1" }));

    expect(respuesta.status).toBe(201);
    expect(String(fetchFalso.mock.calls[0][0])).toBe("http://api.test/api/v1/auth/refresh");
    expect(fetchFalso.mock.calls[1][1].headers.Authorization).toBe(`Bearer ${nuevo}`);
    expect(respuesta.cookies.get("refresh_token")?.value).toBe("r2");
  });

  it("si el refresh ya no sirve responde 401 y borra las cookies", async () => {
    responder(401, { message: "Refresh token expirado.", statusCode: 401 });
    const respuesta = await POST(peticion({ access_token: vencido(), refresh_token: "r1" }));
    expect(respuesta.status).toBe(401);
    expect(respuesta.cookies.get("access_token")?.value).toBe("");
    expect(fetchFalso).toHaveBeenCalledOnce();
  });

  it("sin sesión responde 401 sin llamar al backend", async () => {
    const respuesta = await POST(peticion({}));
    expect(respuesta.status).toBe(401);
    expect(fetchFalso).not.toHaveBeenCalled();
  });

  it("si el backend no responde devuelve 502", async () => {
    fetchFalso.mockRejectedValueOnce(new TypeError("fetch failed"));
    const respuesta = await POST(peticion({ access_token: vigente() }));
    expect(respuesta.status).toBe(502);
  });
});
