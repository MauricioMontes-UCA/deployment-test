import { NextResponse, type NextRequest } from "next/server";
import { llamarBackend } from "@/lib/api-backend";
import { PAGINA_VALIDA } from "@/lib/notificaciones/reglas";

/**
 * Puente hacia `GET {API_URL}/notificaciones?pagina=N` (BE-21.1). El token vive
 * en una cookie httpOnly: el contador global y el centro de notificaciones
 * (componentes de cliente) consultan aquí. `llamarBackend` renueva la sesión,
 * aplica el tiempo límite y devuelve el código del backend tal cual.
 */
export async function GET(request: NextRequest) {
  const pagina = request.nextUrl.searchParams.get("pagina") ?? "1";
  if (!PAGINA_VALIDA.test(pagina)) {
    return NextResponse.json({ message: "La página debe ser un entero mayor o igual a 1." }, { status: 400 });
  }
  return llamarBackend(request, `notificaciones?pagina=${pagina}`);
}
