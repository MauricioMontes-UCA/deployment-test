// @vitest-environment node
import { NextRequest } from "next/server";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import type { SesionApi } from "@/lib/auth-api";
import { obtenerAccesoVigente } from "@/lib/sesion-vigente";
import { PATCH } from "../[id]/leida/route";
import { GET } from "../route";

vi.mock("@/lib/sesion-vigente", async (original) => ({
  ...(await original<typeof import("@/lib/sesion-vigente")>()),
  obtenerAccesoVigente: vi.fn(),
}));

const sesionVigente = { acceso: "token-de-prueba", sesionNueva: null, refreshRechazado: false };
const API = "http://api.test/api/v1";
const ID = "a1b2c3d4-0000-4000-8000-000000000001";
const fetchSimulado = vi.fn();

const peticionGet = (consulta = "") => new NextRequest(`http://localhost/api/notificaciones${consulta}`);
const peticionPatch = () => new NextRequest(`http://localhost/api/notificaciones/${ID}/leida`, { method: "PATCH" });
const contexto = (id = ID) => ({ params: Promise.resolve({ id }) });
const respuesta = (status: number, cuerpo: unknown = {}) =>
  new Response(JSON.stringify(cuerpo), { status, headers: { "Content-Type": "application/json" } });

beforeEach(() => {
  vi.stubEnv("API_URL", API);
  vi.mocked(obtenerAccesoVigente).mockResolvedValue(sesionVigente);
  fetchSimulado.mockReset();
  vi.stubGlobal("fetch", fetchSimulado);
});

afterEach(() => {
  vi.unstubAllEnvs();
  vi.unstubAllGlobals();
});

describe("GET /api/notificaciones", () => {
  it("reenvía la página al backend con el token y devuelve su respuesta", async () => {
    const listado = { noLeidas: 3, total: 5, pagina: 2, tamanoPagina: 20, notificaciones: [] };
    fetchSimulado.mockResolvedValue(respuesta(200, listado));

    const res = await GET(peticionGet("?pagina=2"));

    expect(res.status).toBe(200);
    expect(await res.json()).toEqual(listado);
    const [url, init] = fetchSimulado.mock.calls[0];
    expect(String(url)).toBe(`${API}/notificaciones?pagina=2`);
    expect(init.method).toBe("GET");
    expect(init.headers.Authorization).toBe("Bearer token-de-prueba");
  });

  it("sin `pagina` pide la 1", async () => {
    fetchSimulado.mockResolvedValue(respuesta(200, {}));
    await GET(peticionGet());
    expect(String(fetchSimulado.mock.calls[0][0])).toBe(`${API}/notificaciones?pagina=1`);
  });

  it.each(["0", "-1", "abc", "1.5", "01", "1&x=2"])("pagina=%s → 400 sin llamar al backend", async (pagina) => {
    const res = await GET(peticionGet(`?pagina=${encodeURIComponent(pagina)}`));
    expect(res.status).toBe(400);
    expect(fetchSimulado).not.toHaveBeenCalled();
  });

  it("sin sesión → 401 sin llamar al backend", async () => {
    vi.mocked(obtenerAccesoVigente).mockResolvedValue({ ...sesionVigente, acceso: undefined });
    expect((await GET(peticionGet())).status).toBe(401);
    expect(fetchSimulado).not.toHaveBeenCalled();
  });

  it.each([400, 401, 403, 500])("devuelve el %i del backend tal cual", async (status) => {
    fetchSimulado.mockResolvedValue(respuesta(status, { message: "x" }));
    expect((await GET(peticionGet())).status).toBe(status);
  });

  it("backend sin respuesta → 502", async () => {
    fetchSimulado.mockRejectedValue(new TypeError("fetch failed"));
    expect((await GET(peticionGet())).status).toBe(502);
  });

  it("si hubo que renovar el token, las cookies nuevas viajan en la respuesta", async () => {
    fetchSimulado.mockResolvedValue(respuesta(200, {}));
    vi.mocked(obtenerAccesoVigente).mockResolvedValue({
      acceso: "acceso-nuevo",
      sesionNueva: { accessToken: "acceso-nuevo", refreshToken: "refresh-nuevo", expiresIn: 900 } as SesionApi,
      refreshRechazado: false,
    });
    const res = await GET(peticionGet());
    expect(fetchSimulado.mock.calls[0][1].headers.Authorization).toBe("Bearer acceso-nuevo");
    expect(res.headers.getSetCookie().join(";")).toMatch(/access_token=acceso-nuevo/);
  });
});

describe("PATCH /api/notificaciones/[id]/leida", () => {
  it("reenvía el PATCH sin cuerpo y devuelve el nuevo contador", async () => {
    const marcada = { id: ID, estado: "LEIDA", leidaEn: "2026-11-18T21:00:00.000Z", noLeidas: 2 };
    fetchSimulado.mockResolvedValue(respuesta(200, marcada));

    const res = await PATCH(peticionPatch(), contexto());

    expect(res.status).toBe(200);
    expect(await res.json()).toEqual(marcada);
    const [url, init] = fetchSimulado.mock.calls[0];
    expect(String(url)).toBe(`${API}/notificaciones/${ID}/leida`);
    expect(init.method).toBe("PATCH");
    expect(init.body).toBeUndefined();
  });

  it.each(["no-es-uuid", "../../auth/me", ""])("id «%s» → 400 sin llamar al backend", async (id) => {
    expect((await PATCH(peticionPatch(), contexto(id))).status).toBe(400);
    expect(fetchSimulado).not.toHaveBeenCalled();
  });

  it("sin sesión → 401", async () => {
    vi.mocked(obtenerAccesoVigente).mockResolvedValue({ ...sesionVigente, acceso: undefined });
    expect((await PATCH(peticionPatch(), contexto())).status).toBe(401);
  });

  it.each([404, 400, 500])("devuelve el %i del backend tal cual", async (status) => {
    fetchSimulado.mockResolvedValue(respuesta(status, { message: "No encontramos esa notificación." }));
    expect((await PATCH(peticionPatch(), contexto())).status).toBe(status);
  });

  it("backend sin respuesta → 502", async () => {
    fetchSimulado.mockRejectedValue(new TypeError("fetch failed"));
    expect((await PATCH(peticionPatch(), contexto())).status).toBe(502);
  });
});
