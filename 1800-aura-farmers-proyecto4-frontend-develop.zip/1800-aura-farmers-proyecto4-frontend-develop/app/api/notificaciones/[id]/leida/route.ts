import { NextResponse, type NextRequest } from "next/server";
import { llamarBackend } from "@/lib/api-backend";
import { ID_NOTIFICACION } from "@/lib/notificaciones/reglas";

type Contexto = { params: Promise<{ id: string }> };

/**
 * Puente hacia `PATCH {API_URL}/notificaciones/:id/leida` (BE-21.2), sin cuerpo.
 * El backend solo marca avisos del usuario de la sesión: con uno ajeno o
 * inexistente responde 404, que llega igual a la pantalla.
 */
export async function PATCH(request: NextRequest, { params }: Contexto) {
  const { id } = await params;
  if (!ID_NOTIFICACION.test(id)) {
    return NextResponse.json({ message: "Notificación inválida." }, { status: 400 });
  }
  return llamarBackend(request, `notificaciones/${id}/leida`, { method: "PATCH" });
}
