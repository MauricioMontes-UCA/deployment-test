import { NextRequest } from "next/server";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import { GET } from "../route";
import { obtenerAccesoVigente } from "@/lib/sesion-vigente";

vi.mock("@/lib/sesion-vigente", async (original) => ({
  ...(await original<typeof import("@/lib/sesion-vigente")>()),
  obtenerAccesoVigente: vi.fn(),
}));

const conAcceso = (acceso: string | undefined) => ({ acceso, sesionNueva: null, refreshRechazado: false });

const fetchFalso = vi.fn();

function pedir(reporte: string, consulta = "periodo=ULTIMO_MES") {
  return GET(new NextRequest(`http://localhost/api/reportes/${reporte}?${consulta}`), {
    params: Promise.resolve({ reporte }),
  });
}

beforeEach(() => {
  vi.stubEnv("API_URL", "http://api.test/api/v1");
  vi.stubGlobal("fetch", fetchFalso);
  vi.mocked(obtenerAccesoVigente).mockResolvedValue(conAcceso("token-abc"));
});

afterEach(() => {
  vi.unstubAllEnvs();
  vi.unstubAllGlobals();
  fetchFalso.mockReset();
  vi.mocked(obtenerAccesoVigente).mockReset();
});

describe("GET /api/reportes/[reporte]", () => {
  it("reenvía el periodo al backend con el token de la cookie", async () => {
    fetchFalso.mockResolvedValue(new Response(JSON.stringify({ bienes: [] }), { status: 200 }));

    const respuesta = await pedir("ingresos", "periodo=RANGO&desde=2026-11-01&hasta=2026-11-15");

    expect(respuesta.status).toBe(200);
    expect(await respuesta.json()).toEqual({ bienes: [] });
    const [destino, init] = fetchFalso.mock.calls[0];
    expect(String(destino)).toBe(
      "http://api.test/api/v1/reportes/ingresos?periodo=RANGO&desde=2026-11-01&hasta=2026-11-15",
    );
    expect(init.headers).toEqual({ Authorization: "Bearer token-abc" });
  });

  it("solo reenvía periodo, desde y hasta", async () => {
    fetchFalso.mockResolvedValue(new Response("{}"));
    await pedir("resumen", "periodo=ULTIMO_MES&arrendadorId=otro");
    expect(String(fetchFalso.mock.calls[0][0])).not.toContain("arrendadorId");
  });

  it("devuelve tal cual el 400 y el 403 del backend", async () => {
    fetchFalso.mockResolvedValueOnce(
      new Response(JSON.stringify({ message: "El rango no puede ser mayor a 365 días." }), {
        status: 400,
      }),
    );
    const invalida = await pedir("ocupacion");
    expect(invalida.status).toBe(400);
    expect(await invalida.json()).toEqual({ message: "El rango no puede ser mayor a 365 días." });

    fetchFalso.mockResolvedValueOnce(new Response("{}", { status: 403 }));
    expect((await pedir("ocupacion")).status).toBe(403);
  });

  it("sin cookie de sesión responde 401 sin llamar al backend", async () => {
    vi.mocked(obtenerAccesoVigente).mockResolvedValue(conAcceso(undefined));
    expect((await pedir("ingresos")).status).toBe(401);
    expect(fetchFalso).not.toHaveBeenCalled();
  });

  it("un reporte que no existe responde 404", async () => {
    expect((await pedir("periodo")).status).toBe(404);
    expect(fetchFalso).not.toHaveBeenCalled();
  });

  it("si el backend no responde, 502", async () => {
    fetchFalso.mockRejectedValue(new TypeError("fetch failed"));
    expect((await pedir("calificaciones")).status).toBe(502);
  });

  it("sin API_URL responde 500", async () => {
    vi.stubEnv("API_URL", "");
    expect((await pedir("ingresos")).status).toBe(500);
  });

  it("renueva el access token vencido y escribe las cookies nuevas en la respuesta", async () => {
    vi.mocked(obtenerAccesoVigente).mockResolvedValue({
      acceso: "token-nuevo",
      sesionNueva: {
        accessToken: "token-nuevo",
        refreshToken: "refresh-nuevo",
        expiresIn: 900,
        user: {} as never,
      },
      refreshRechazado: false,
    });
    fetchFalso.mockResolvedValue(new Response("{}", { status: 200 }));

    const respuesta = await pedir("ingresos");

    expect(fetchFalso.mock.calls[0][1].headers).toEqual({ Authorization: "Bearer token-nuevo" });
    expect(respuesta.cookies.get("access_token")?.value).toBe("token-nuevo");
    expect(respuesta.cookies.get("refresh_token")?.value).toBe("refresh-nuevo");
  });

  it("si el refresh token fue rechazado, responde 401 y borra las cookies de sesión", async () => {
    vi.mocked(obtenerAccesoVigente).mockResolvedValue({
      acceso: undefined,
      sesionNueva: null,
      refreshRechazado: true,
    });

    const respuesta = await pedir("ingresos");

    expect(respuesta.status).toBe(401);
    expect(fetchFalso).not.toHaveBeenCalled();
    expect(respuesta.cookies.get("access_token")?.value).toBe("");
    expect(respuesta.cookies.get("refresh_token")?.value).toBe("");
  });
});
