import { NextResponse, type NextRequest } from "next/server";
import { REPORTES, type Reporte } from "@/lib/reportes/cliente";
import { aplicarCambiosDeSesion, obtenerAccesoVigente } from "@/lib/sesion-vigente";

/** Lo único que el backend lee de la consulta; cualquier otro parámetro se descarta. */
const PARAMETROS = ["periodo", "desde", "hasta"] as const;

/**
 * Puente hacia `GET {API_URL}/reportes/:reporte` (ingresos, ocupación,
 * calificaciones y resumen). El token vive en una cookie httpOnly que el
 * navegador no puede leer, así que las secciones del panel (componentes de
 * cliente) consultan aquí y este handler agrega el token. La validación del
 * periodo y del rol es del backend: sus 400 y 403 se devuelven tal cual.
 */
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ reporte: string }> },
) {
  const { reporte } = await params;
  if (!REPORTES.includes(reporte as Reporte)) {
    return NextResponse.json({ message: "Reporte no encontrado." }, { status: 404 });
  }

  // Las rutas /api no pasan por el proxy: si el access token venció se renueva
  // aquí y cada respuesta lleva las cookies nuevas.
  const sesion = await obtenerAccesoVigente(request.cookies);
  const conSesion = (respuesta: NextResponse) => aplicarCambiosDeSesion(respuesta, sesion);
  const token = sesion.acceso;
  if (!token) {
    return conSesion(NextResponse.json({ message: "No autenticado." }, { status: 401 }));
  }

  const apiUrl = process.env.API_URL;
  if (!apiUrl) {
    return conSesion(NextResponse.json({ message: "Falta API_URL." }, { status: 500 }));
  }

  const destino = new URL(`reportes/${reporte}`, apiUrl.replace(/\/?$/, "/"));
  for (const campo of PARAMETROS) {
    const valor = request.nextUrl.searchParams.get(campo);
    if (valor !== null) destino.searchParams.set(campo, valor);
  }

  try {
    const respuesta = await fetch(destino, {
      headers: { Authorization: `Bearer ${token}` },
      cache: "no-store",
    });
    return conSesion(
      NextResponse.json(await respuesta.json().catch(() => ({})), { status: respuesta.status }),
    );
  } catch {
    return conSesion(
      NextResponse.json({ message: "No se pudo contactar a la API." }, { status: 502 }),
    );
  }
}
