import { NextResponse, type NextRequest } from "next/server";
import { aplicarCambiosDeSesion, obtenerAccesoVigente } from "@/lib/sesion-vigente";

/** Lo único que el backend lee de la consulta; cualquier otro parámetro se descarta. */
const PARAMETROS = ["periodo", "desde", "hasta"] as const;

/**
 * Puente hacia `GET {API_URL}/reportes/resumen/exportar`. Reenvía el periodo
 * con el token de la cookie httpOnly y devuelve el archivo CSV tal cual, con
 * su `Content-Disposition` (el nombre lleva las fechas del periodo resuelto),
 * sin decodificarlo: así se conserva el BOM UTF-8 del inicio. Los errores
 * (400, 403…) del backend siempre son JSON y se devuelven con su estado.
 */
export async function GET(request: NextRequest) {
  // Las rutas /api no pasan por el proxy: si el access token venció se renueva
  // aquí y cada respuesta lleva las cookies nuevas.
  const sesion = await obtenerAccesoVigente(request.cookies);
  const conSesion = (respuesta: NextResponse) => aplicarCambiosDeSesion(respuesta, sesion);
  const token = sesion.acceso;
  if (!token) {
    return conSesion(NextResponse.json({ message: "No autenticado." }, { status: 401 }));
  }

  const apiUrl = process.env.API_URL;
  if (!apiUrl) {
    return conSesion(NextResponse.json({ message: "Falta API_URL." }, { status: 500 }));
  }

  const destino = new URL("reportes/resumen/exportar", apiUrl.replace(/\/?$/, "/"));
  for (const campo of PARAMETROS) {
    const valor = request.nextUrl.searchParams.get(campo);
    if (valor !== null) destino.searchParams.set(campo, valor);
  }

  try {
    const respuesta = await fetch(destino, {
      headers: { Authorization: `Bearer ${token}` },
      cache: "no-store",
    });

    if (!respuesta.ok) {
      return conSesion(
        NextResponse.json(await respuesta.json().catch(() => ({})), { status: respuesta.status }),
      );
    }

    const encabezados = new Headers({
      "Content-Type": respuesta.headers.get("content-type") ?? "text/csv; charset=utf-8",
      // El archivo lleva los ingresos del arrendador: que nada lo guarde.
      "Cache-Control": "no-store",
    });
    const disposicion = respuesta.headers.get("content-disposition");
    if (disposicion) encabezados.set("Content-Disposition", disposicion);

    return conSesion(
      new NextResponse(await respuesta.arrayBuffer(), { status: 200, headers: encabezados }),
    );
  } catch {
    return conSesion(
      NextResponse.json({ message: "No se pudo contactar a la API." }, { status: 502 }),
    );
  }
}
