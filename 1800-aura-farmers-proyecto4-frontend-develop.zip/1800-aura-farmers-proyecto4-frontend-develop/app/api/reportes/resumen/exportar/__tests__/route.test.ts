import { NextRequest } from "next/server";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import { GET } from "../route";
import { obtenerAccesoVigente } from "@/lib/sesion-vigente";

vi.mock("@/lib/sesion-vigente", async (original) => ({
  ...(await original<typeof import("@/lib/sesion-vigente")>()),
  obtenerAccesoVigente: vi.fn(),
}));

const conAcceso = (acceso: string | undefined) => ({ acceso, sesionNueva: null, refreshRechazado: false });

const fetchFalso = vi.fn();

const pedir = (consulta = "periodo=ULTIMO_MES") =>
  GET(new NextRequest(`http://localhost/api/reportes/resumen/exportar?${consulta}`));

const BOM = [0xef, 0xbb, 0xbf];

beforeEach(() => {
  vi.stubEnv("API_URL", "http://api.test/api/v1");
  vi.stubGlobal("fetch", fetchFalso);
  vi.mocked(obtenerAccesoVigente).mockResolvedValue(conAcceso("token-abc"));
});

afterEach(() => {
  vi.unstubAllEnvs();
  vi.unstubAllGlobals();
  fetchFalso.mockReset();
  vi.mocked(obtenerAccesoVigente).mockReset();
});

describe("GET /api/reportes/resumen/exportar", () => {
  it("devuelve el CSV con su nombre y sin decodificarlo (conserva el BOM)", async () => {
    const bytes = new Uint8Array([...BOM, ...new TextEncoder().encode("Bien,Ingresos (USD)\r\n")]);
    fetchFalso.mockResolvedValue(
      new Response(bytes, {
        status: 200,
        headers: {
          "Content-Type": "text/csv; charset=utf-8",
          "Content-Disposition": 'attachment; filename="resumen-desempeno_2026-10-07_2026-11-05.csv"',
        },
      }),
    );

    const respuesta = await pedir("periodo=RANGO&desde=2026-10-07&hasta=2026-11-05");

    expect(respuesta.status).toBe(200);
    expect(respuesta.headers.get("content-type")).toBe("text/csv; charset=utf-8");
    expect(respuesta.headers.get("content-disposition")).toBe(
      'attachment; filename="resumen-desempeno_2026-10-07_2026-11-05.csv"',
    );
    expect(respuesta.headers.get("cache-control")).toBe("no-store");
    expect([...new Uint8Array(await respuesta.arrayBuffer())]).toEqual([...bytes]);

    const [destino, init] = fetchFalso.mock.calls[0];
    expect(String(destino)).toBe(
      "http://api.test/api/v1/reportes/resumen/exportar?periodo=RANGO&desde=2026-10-07&hasta=2026-11-05",
    );
    expect(init.headers).toEqual({ Authorization: "Bearer token-abc" });
  });

  it("solo reenvía periodo, desde y hasta", async () => {
    fetchFalso.mockResolvedValue(new Response("x", { status: 200 }));
    await pedir("periodo=ULTIMO_MES&arrendadorId=otro");
    expect(String(fetchFalso.mock.calls[0][0])).not.toContain("arrendadorId");
  });

  it("devuelve los errores del backend como JSON con su estado", async () => {
    fetchFalso.mockResolvedValueOnce(
      new Response(JSON.stringify({ message: "El rango no puede ser mayor a 365 días." }), {
        status: 400,
      }),
    );
    const invalida = await pedir();
    expect(invalida.status).toBe(400);
    expect(await invalida.json()).toEqual({ message: "El rango no puede ser mayor a 365 días." });

    fetchFalso.mockResolvedValueOnce(new Response("{}", { status: 403 }));
    expect((await pedir()).status).toBe(403);
  });

  it("sin cookie de sesión responde 401 sin llamar al backend", async () => {
    vi.mocked(obtenerAccesoVigente).mockResolvedValue(conAcceso(undefined));
    expect((await pedir()).status).toBe(401);
    expect(fetchFalso).not.toHaveBeenCalled();
  });

  it("si el backend no responde, 502", async () => {
    fetchFalso.mockRejectedValue(new TypeError("fetch failed"));
    expect((await pedir()).status).toBe(502);
  });
});
