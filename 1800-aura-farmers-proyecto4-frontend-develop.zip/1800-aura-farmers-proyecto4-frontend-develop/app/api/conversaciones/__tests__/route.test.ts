// @vitest-environment node
import { NextRequest } from "next/server";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { GET } from "../route";
import { obtenerAccesoVigente } from "@/lib/sesion-vigente";

vi.mock("@/lib/sesion-vigente", async (original) => ({
  ...(await original<typeof import("@/lib/sesion-vigente")>()),
  obtenerAccesoVigente: vi.fn(),
}));

const API = "http://api.test/api/v1/";
const fetchSimulado = vi.fn();
const pedir = (consulta = "") => GET(new NextRequest(`http://localhost/api/conversaciones${consulta}`));
const urlPedida = () => String(fetchSimulado.mock.calls[0][0]);
const cabeceras = () => fetchSimulado.mock.calls[0][1].headers as Record<string, string>;

const PAGINA = {
  items: [
    {
      id: "11111111-1111-4111-8111-111111111111",
      tipo: "CONSULTA",
      bien: { id: "b1", titulo: "Salón", fotoPrincipalUrl: null },
      reservaId: null,
      otroParticipante: { id: "u1", nombreUsuario: "ana_m" },
      ultimoMensaje: null,
      actualizadaEn: "2026-11-20T16:42:00.000Z",
    },
  ],
  pagina: 1,
  total: 1,
  hayMas: false,
};

beforeEach(() => {
  vi.stubEnv("API_URL", API);
  vi.mocked(obtenerAccesoVigente).mockResolvedValue({ acceso: "token-de-prueba", sesionNueva: null, refreshRechazado: false });
  fetchSimulado.mockReset();
  vi.stubGlobal("fetch", fetchSimulado);
});

afterEach(() => {
  vi.unstubAllEnvs();
  vi.unstubAllGlobals();
});

describe("GET /api/conversaciones (puente de la bandeja)", () => {
  it("sin tipo pide todas, página 1, con el token del usuario y devuelve la página tal cual", async () => {
    fetchSimulado.mockResolvedValue(Response.json(PAGINA));
    const respuesta = await pedir();
    expect(urlPedida()).toBe(`${API}conversaciones?pagina=1`);
    expect(cabeceras().Authorization).toBe("Bearer token-de-prueba");
    expect(respuesta.status).toBe(200);
    expect(await respuesta.json()).toEqual(PAGINA);
  });

  it.each(["CONSULTA", "COORDINACION"])("reenvía tipo=%s y la página", async (tipo) => {
    fetchSimulado.mockResolvedValue(Response.json(PAGINA));
    await pedir(`?tipo=${tipo}&pagina=3`);
    expect(urlPedida()).toBe(`${API}conversaciones?tipo=${tipo}&pagina=3`);
  });

  it.each([
    ["tipo desconocido", "?tipo=TODAS"],
    ["tipo en minúsculas", "?tipo=consulta"],
    ["página 0", "?pagina=0"],
    ["página negativa", "?pagina=-1"],
    ["página con texto", "?pagina=1%26tipo%3DX"],
  ])("rechaza %s con 400 sin llamar al backend", async (_caso, consulta) => {
    const respuesta = await pedir(consulta);
    expect(respuesta.status).toBe(400);
    expect(fetchSimulado).not.toHaveBeenCalled();
  });

  it("sin sesión responde 401 sin llamar al backend", async () => {
    vi.mocked(obtenerAccesoVigente).mockResolvedValue({ acceso: undefined, sesionNueva: null, refreshRechazado: false });
    const respuesta = await pedir();
    expect(respuesta.status).toBe(401);
    expect(fetchSimulado).not.toHaveBeenCalled();
  });

  it("pasa el código del backend (401 con el token rechazado, 400)", async () => {
    fetchSimulado.mockResolvedValueOnce(Response.json({ message: "No autorizado" }, { status: 401 }));
    expect((await pedir()).status).toBe(401);
    fetchSimulado.mockResolvedValueOnce(Response.json({ message: ["pagina inválida"] }, { status: 400 }));
    expect((await pedir("?pagina=999999")).status).toBe(400);
  });

  it("si el backend no responde, 502", async () => {
    fetchSimulado.mockRejectedValue(new TypeError("fetch failed"));
    const respuesta = await pedir();
    expect(respuesta.status).toBe(502);
  });
});
