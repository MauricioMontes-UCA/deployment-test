import { NextResponse, type NextRequest } from "next/server";
import { llamarBackend } from "@/lib/api-backend";
import { esTipoConversacion } from "@/lib/bandeja";

const PAGINA = /^[1-9]\d{0,5}$/;

/**
 * Puente hacia `GET {API_URL}/conversaciones?tipo=&pagina=` (BE-13.2). La
 * bandeja (componente de cliente) no puede leer la cookie httpOnly del token:
 * consulta aquí y `llamarBackend` agrega el token, lo renueva si venció y
 * devuelve el código del backend tal cual (401 incluido).
 *
 * El backend solo devuelve conversaciones del usuario del token. Aquí se
 * validan los parámetros antes de llamarlo, para no reenviar texto arbitrario.
 */
export async function GET(request: NextRequest) {
  const tipo = request.nextUrl.searchParams.get("tipo");
  const pagina = request.nextUrl.searchParams.get("pagina") ?? "1";
  if (tipo !== null && !esTipoConversacion(tipo)) {
    return NextResponse.json({ message: "Tipo de conversación inválido." }, { status: 400 });
  }
  if (!PAGINA.test(pagina)) {
    return NextResponse.json({ message: "Página inválida." }, { status: 400 });
  }

  const consulta = new URLSearchParams();
  if (tipo) consulta.set("tipo", tipo);
  consulta.set("pagina", pagina);
  return llamarBackend(request, `conversaciones?${consulta}`);
}
