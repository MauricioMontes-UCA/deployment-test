import { NextResponse, type NextRequest } from "next/server";
import { ID_UUID, reenviarAApi } from "@/lib/solicitud/servidor";

const FORMATO_DIA = /^\d{4}-\d{2}-\d{2}$/;

/**
 * Puente hacia `POST {API_URL}/reservas` (BE-6.1): encola la solicitud y
 * responde 202 con la reserva en estado `EN_COLA`. Solo pasa los tres campos
 * del contrato; las reglas de negocio las valida el backend.
 */
export async function POST(request: NextRequest) {
  const cuerpo: unknown = await request.json().catch(() => null);
  const { bienId, fechaInicio, fechaFin } = (cuerpo ?? {}) as Record<string, unknown>;
  if (
    typeof bienId !== "string" ||
    !ID_UUID.test(bienId) ||
    typeof fechaInicio !== "string" ||
    !FORMATO_DIA.test(fechaInicio) ||
    typeof fechaFin !== "string" ||
    !FORMATO_DIA.test(fechaFin)
  ) {
    return NextResponse.json({ message: "Solicitud inválida." }, { status: 400 });
  }
  return reenviarAApi(request, "reservas", { method: "POST", cuerpo: { bienId, fechaInicio, fechaFin } });
}
