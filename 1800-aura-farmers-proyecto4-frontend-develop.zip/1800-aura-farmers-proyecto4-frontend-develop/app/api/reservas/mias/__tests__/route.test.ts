import { NextRequest } from "next/server";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { GET } from "../route";

const { obtenerAccesoVigente } = vi.hoisted(() => ({ obtenerAccesoVigente: vi.fn() }));
vi.mock("@/lib/sesion-vigente", async (importar) => ({
  ...(await importar<typeof import("@/lib/sesion-vigente")>()),
  obtenerAccesoVigente,
}));

const fetchSimulado = vi.fn();
vi.stubGlobal("fetch", fetchSimulado);

const SESION_NUEVA = { accessToken: "acceso-nuevo", refreshToken: "refresh-nuevo", expiresIn: 900 };

const peticion = (consulta = "") => new NextRequest(`http://localhost/api/reservas/mias${consulta}`);

beforeEach(() => {
  vi.stubEnv("API_URL", "http://api.test/api/v1");
  fetchSimulado.mockReset();
  obtenerAccesoVigente.mockReset();
  obtenerAccesoVigente.mockResolvedValue({ acceso: "token", sesionNueva: null, refreshRechazado: false });
});

describe("GET /api/reservas/mias", () => {
  it("sin sesión responde 401 y no llama al backend", async () => {
    obtenerAccesoVigente.mockResolvedValue({ acceso: undefined, sesionNueva: null, refreshRechazado: false });
    const respuesta = await GET(peticion());
    expect(respuesta.status).toBe(401);
    expect(fetchSimulado).not.toHaveBeenCalled();
  });

  it("rechaza un estado inválido con 400", async () => {
    const respuesta = await GET(peticion("?estado=nada"));
    expect(respuesta.status).toBe(400);
  });

  it("usa el token renovado y escribe las cookies nuevas", async () => {
    obtenerAccesoVigente.mockResolvedValue({
      acceso: "acceso-nuevo",
      sesionNueva: SESION_NUEVA,
      refreshRechazado: false,
    });
    fetchSimulado.mockResolvedValue(Response.json([], { status: 200 }));

    const respuesta = await GET(peticion());

    expect(respuesta.status).toBe(200);
    expect(fetchSimulado.mock.calls[0][0].toString()).toBe("http://api.test/api/v1/reservas/mias");
    expect(fetchSimulado.mock.calls[0][1].headers.Authorization).toBe("Bearer acceso-nuevo");
    expect(respuesta.cookies.get("access_token")?.value).toBe("acceso-nuevo");
    expect(respuesta.cookies.get("refresh_token")?.value).toBe("refresh-nuevo");
  });

  it("pasa el 401 del backend y las cookies renovadas también en errores", async () => {
    obtenerAccesoVigente.mockResolvedValue({
      acceso: "acceso-nuevo",
      sesionNueva: SESION_NUEVA,
      refreshRechazado: false,
    });
    fetchSimulado.mockResolvedValue(Response.json({}, { status: 401 }));
    const respuesta = await GET(peticion());
    expect(respuesta.status).toBe(401);
    expect(respuesta.cookies.get("access_token")?.value).toBe("acceso-nuevo");
  });

  it("borra las cookies cuando el backend rechazó el refresh token", async () => {
    obtenerAccesoVigente.mockResolvedValue({ acceso: undefined, sesionNueva: null, refreshRechazado: true });
    const respuesta = await GET(peticion());
    expect(respuesta.status).toBe(401);
    expect(respuesta.headers.get("set-cookie")).toContain("access_token=;");
  });
});
