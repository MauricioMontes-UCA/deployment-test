import { NextResponse, type NextRequest } from "next/server";
import { aplicarCambiosDeSesion, obtenerAccesoVigente } from "@/lib/sesion-vigente";
import { esEstadoReserva, listarReservasMias } from "@/lib/reservas/servidor";

/**
 * Puente hacia `GET {API_URL}/reservas/mias?estado=`. El token vive en una
 * cookie httpOnly que el navegador no puede leer; «Mis reservas» (componente
 * de cliente) consulta aquí y este handler agrega el token y los datos del bien.
 *
 * Las rutas /api no pasan por el proxy: si el access token venció se renueva
 * aquí (renovación compartida de `lib/sesion-vigente.ts`) y cada respuesta,
 * errores incluidos, lleva las cookies nuevas o las borra.
 */
export async function GET(request: NextRequest) {
  const estado = request.nextUrl.searchParams.get("estado");
  if (estado !== null && !esEstadoReserva(estado)) {
    return NextResponse.json({ message: "Estado de reserva inválido." }, { status: 400 });
  }

  const sesion = await obtenerAccesoVigente(request.cookies);
  const conSesion = (respuesta: NextResponse) => aplicarCambiosDeSesion(respuesta, sesion);
  const token = sesion.acceso;
  if (!token) {
    return conSesion(NextResponse.json({ message: "No autenticado." }, { status: 401 }));
  }

  if (!process.env.API_URL) {
    return conSesion(NextResponse.json({ message: "Falta API_URL." }, { status: 500 }));
  }

  const resultado = await listarReservasMias(token, estado ?? undefined);
  if (!resultado.ok) {
    return conSesion(
      NextResponse.json(
        { message: "No se pudieron cargar las reservas." },
        { status: resultado.status },
      ),
    );
  }
  return conSesion(NextResponse.json(resultado.reservas));
}
