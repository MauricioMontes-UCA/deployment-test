import { NextResponse, type NextRequest } from "next/server";
import { esEstadoFiltroRecibidas } from "@/lib/reservas/recibidas";
import { reenviarAApi } from "@/lib/solicitud/servidor";

/** Misma regla que el backend: entero positivo solo con dígitos, sin ceros a la izquierda. */
const PAGINA = /^[1-9]\d{0,14}$/;

/**
 * Puente hacia `GET {API_URL}/reservas/recibidas?estado=&pagina=` (BE-27.1).
 * Valida el filtro y la página antes de llamar al backend; el token, su
 * renovación y las cookies las resuelve `reenviarAApi`.
 */
export async function GET(request: NextRequest) {
  const { searchParams } = request.nextUrl;
  const estado = searchParams.get("estado");
  const pagina = searchParams.get("pagina");

  if (estado && !esEstadoFiltroRecibidas(estado)) {
    return NextResponse.json({ message: "Estado de reserva inválido." }, { status: 400 });
  }
  if (pagina !== null && !PAGINA.test(pagina)) {
    return NextResponse.json({ message: "Página inválida." }, { status: 400 });
  }

  const consulta = new URLSearchParams();
  if (estado) consulta.set("estado", estado);
  if (pagina) consulta.set("pagina", pagina);
  const texto = consulta.toString();
  return reenviarAApi(request, `reservas/recibidas${texto ? `?${texto}` : ""}`, { method: "GET" });
}
