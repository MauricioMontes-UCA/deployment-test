// @vitest-environment node
import { NextRequest } from "next/server";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { POST } from "../route";
import { GET } from "../[reservaId]/route";
import { obtenerAccesoVigente } from "@/lib/sesion-vigente";

vi.mock("@/lib/sesion-vigente", async (original) => ({
  ...(await original<typeof import("@/lib/sesion-vigente")>()),
  obtenerAccesoVigente: vi.fn(),
}));

const conAcceso = (acceso: string | undefined, resto = {}) => ({
  acceso,
  sesionNueva: null,
  refreshRechazado: false,
  ...resto,
});

const BIEN = "10000000-0000-4000-8000-000000000001";
const RESERVA = "20000000-0000-4000-8000-000000000001";
const API = "http://api.test/api/v1";

const fetchSimulado = vi.fn();

function enviar(cuerpo: unknown) {
  return POST(
    new NextRequest("http://localhost/api/reservas", {
      method: "POST",
      body: typeof cuerpo === "string" ? cuerpo : JSON.stringify(cuerpo),
    }),
  );
}

const valido = { bienId: BIEN, fechaInicio: "2026-12-10", fechaFin: "2026-12-12" };

beforeEach(() => {
  vi.stubEnv("API_URL", API);
  vi.mocked(obtenerAccesoVigente).mockResolvedValue(conAcceso("token-de-prueba"));
  fetchSimulado.mockReset();
  vi.stubGlobal("fetch", fetchSimulado);
});

afterEach(() => {
  vi.unstubAllEnvs();
  vi.unstubAllGlobals();
});

describe("POST /api/reservas", () => {
  it("sin sesión responde 401 y no llama al backend", async () => {
    vi.mocked(obtenerAccesoVigente).mockResolvedValue(conAcceso(undefined));
    const respuesta = await enviar(valido);
    expect(respuesta.status).toBe(401);
    expect(fetchSimulado).not.toHaveBeenCalled();
  });

  it.each([
    ["JSON inválido", "{no es json"],
    ["sin cuerpo", ""],
    ["bien que no es UUID", { ...valido, bienId: "1" }],
    ["fecha con formato inválido", { ...valido, fechaInicio: "10/12/2026" }],
    ["falta la fecha de fin", { bienId: BIEN, fechaInicio: "2026-12-10" }],
  ])("rechaza con 400 una solicitud inválida (%s) sin llamar al backend", async (_nombre, cuerpo) => {
    const respuesta = await enviar(cuerpo);
    expect(respuesta.status).toBe(400);
    expect(fetchSimulado).not.toHaveBeenCalled();
  });

  it("sin API_URL responde 500", async () => {
    vi.stubEnv("API_URL", "");
    expect((await enviar(valido)).status).toBe(500);
    expect(fetchSimulado).not.toHaveBeenCalled();
  });

  it("reenvía solo los tres campos con el token y devuelve el estado y cuerpo del backend", async () => {
    const reserva = { id: RESERVA, estado: "EN_COLA" };
    fetchSimulado.mockResolvedValue(new Response(JSON.stringify(reserva), { status: 202 }));

    const respuesta = await enviar({ ...valido, arrendatarioId: "otro" });

    expect(respuesta.status).toBe(202);
    expect(await respuesta.json()).toEqual(reserva);
    const [destino, opciones] = fetchSimulado.mock.calls[0];
    expect(String(destino)).toBe(`${API}/reservas`);
    expect(opciones.method).toBe("POST");
    expect(opciones.headers.Authorization).toBe("Bearer token-de-prueba");
    expect(JSON.parse(opciones.body)).toEqual(valido);
  });

  it.each([403, 409, 422])("devuelve tal cual el %i del backend", async (estado) => {
    const cuerpo = { codigo: "VERIFICACION_REQUERIDA" };
    fetchSimulado.mockResolvedValue(new Response(JSON.stringify(cuerpo), { status: estado }));
    const respuesta = await enviar(valido);
    expect(respuesta.status).toBe(estado);
    expect(await respuesta.json()).toEqual(cuerpo);
  });

  it("si hubo que renovar la sesión, la respuesta lleva las cookies nuevas, también en un error", async () => {
    vi.mocked(obtenerAccesoVigente).mockResolvedValue(
      conAcceso("nuevo", { sesionNueva: { accessToken: "nuevo", refreshToken: "r2", expiresIn: 900 } }),
    );
    fetchSimulado.mockResolvedValue(new Response("{}", { status: 409 }));

    const respuesta = await enviar(valido);

    expect(respuesta.status).toBe(409);
    expect(respuesta.cookies.get("access_token")?.value).toBe("nuevo");
    expect(respuesta.cookies.get("refresh_token")?.value).toBe("r2");
    expect(fetchSimulado.mock.calls[0][1].headers.Authorization).toBe("Bearer nuevo");
  });

  it("si el backend rechazó el refresh token, la respuesta 401 borra las cookies", async () => {
    vi.mocked(obtenerAccesoVigente).mockResolvedValue(conAcceso(undefined, { refreshRechazado: true }));

    const respuesta = await enviar(valido);

    expect(respuesta.status).toBe(401);
    expect(respuesta.cookies.get("access_token")?.value).toBe("");
    expect(respuesta.cookies.get("refresh_token")?.value).toBe("");
  });

  it("si el backend no responde devuelve 502", async () => {
    fetchSimulado.mockRejectedValue(new TypeError("fetch failed"));
    expect((await enviar(valido)).status).toBe(502);
  });
});

describe("GET /api/reservas/[reservaId]", () => {
  const consultar = (id: string) =>
    GET(new NextRequest(`http://localhost/api/reservas/${id}`), { params: Promise.resolve({ reservaId: id }) });

  it("rechaza un id que no es UUID sin llamar al backend", async () => {
    expect((await consultar("abc")).status).toBe(400);
    expect(fetchSimulado).not.toHaveBeenCalled();
  });

  it("sin sesión responde 401", async () => {
    vi.mocked(obtenerAccesoVigente).mockResolvedValue(conAcceso(undefined));
    expect((await consultar(RESERVA)).status).toBe(401);
    expect(fetchSimulado).not.toHaveBeenCalled();
  });

  it("consulta la reserva en el backend con el token", async () => {
    const reserva = { id: RESERVA, estado: "CONFIRMADA" };
    fetchSimulado.mockResolvedValue(new Response(JSON.stringify(reserva), { status: 200 }));

    const respuesta = await consultar(RESERVA);

    expect(respuesta.status).toBe(200);
    expect(await respuesta.json()).toEqual(reserva);
    const [destino, opciones] = fetchSimulado.mock.calls[0];
    expect(String(destino)).toBe(`${API}/reservas/${RESERVA}`);
    expect(opciones.method).toBe("GET");
    expect(opciones.headers.Authorization).toBe("Bearer token-de-prueba");
  });

  it("devuelve el 404 y el 403 del backend", async () => {
    fetchSimulado.mockResolvedValue(new Response("{}", { status: 404 }));
    expect((await consultar(RESERVA)).status).toBe(404);
  });
});
