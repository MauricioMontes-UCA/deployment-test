import { beforeEach, describe, expect, it, vi } from "vitest";
import { NextRequest } from "next/server";

const mocks = vi.hoisted(() => ({ sesionDeRuta: vi.fn(), urlApi: vi.fn() }));
vi.mock("@/lib/api-servidor", () => mocks);
import { POST } from "./route";

const ID = "11111111-1111-4111-8111-111111111111";
const ruta = { params: Promise.resolve({ reservaId: ID }) };
const valido = {
  fechaDevolucion: "2020-01-01T12:00:00.000Z",
  estadoFinalBien: "BUEN_ESTADO",
};
const enviar = (body: unknown = valido) =>
  POST(
    new NextRequest(`http://localhost/api/reservas/${ID}/devolucion`, {
      method: "POST",
      body: JSON.stringify(body),
      headers: { "Content-Type": "application/json" },
    }),
    ruta,
  );

beforeEach(() => {
  vi.restoreAllMocks();
  mocks.sesionDeRuta.mockReset();
  mocks.urlApi.mockReset();
  mocks.sesionDeRuta.mockResolvedValue({
    token: "jwt",
    conSesion: (r: Response) => r,
  });
  mocks.urlApi.mockReturnValue(
    "http://backend/reservas/11111111-1111-4111-8111-111111111111/devolucion",
  );
});

describe("FE-10.1 puente de devolución", () => {
  it("401 sin sesión", async () => {
    mocks.sesionDeRuta.mockResolvedValue({
      token: null,
      conSesion: (r: Response) => r,
    });
    expect((await enviar()).status).toBe(401);
  });
  it("400 si fecha no tiene zona", async () => {
    expect(
      (await enviar({ ...valido, fechaDevolucion: "2020-01-01T12:00:00" }))
        .status,
    ).toBe(400);
  });
  it("400 si fecha es futura", async () => {
    expect(
      (await enviar({ ...valido, fechaDevolucion: "2999-01-01T12:00:00Z" }))
        .status,
    ).toBe(400);
  });
  it("400 si estado es inválido", async () => {
    expect((await enviar({ ...valido, estadoFinalBien: "OTRO" })).status).toBe(
      400,
    );
  });
  it("400 si observaciones exceden 500 unidades UTF-16", async () => {
    expect(
      (await enviar({ ...valido, observaciones: "😀".repeat(251) })).status,
    ).toBe(400);
  });
  it("502 si la API falla", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockRejectedValue(new Error("sin conexión")),
    );
    expect((await enviar()).status).toBe(502);
    vi.unstubAllGlobals();
  });
  it("reenvía token y cuerpo válido", async () => {
    const fetchMock = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ estadoReserva: "FINALIZADA" }), {
        status: 201,
      }),
    );
    vi.stubGlobal("fetch", fetchMock);
    const respuesta = await enviar(valido);
    expect(respuesta.status).toBe(201);
    expect(fetchMock).toHaveBeenCalledWith(
      expect.stringContaining("/devolucion"),
      expect.objectContaining({
        method: "POST",
        headers: expect.objectContaining({ Authorization: "Bearer jwt" }),
        body: JSON.stringify(valido),
      }),
    );
    vi.unstubAllGlobals();
  });
});
