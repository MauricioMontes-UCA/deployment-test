import { NextResponse, type NextRequest } from "next/server";
import { sesionDeRuta, urlApi } from "@/lib/api-servidor";
import {
  ID_RESERVA,
  ESTADOS_FINALES,
  contarObservaciones,
} from "@/lib/devoluciones";
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ reservaId: string }> },
) {
  const { reservaId } = await params;
  const sesion = await sesionDeRuta(request.cookies);
  const responder = (datos: unknown, status: number) =>
    sesion.conSesion(NextResponse.json(datos, { status }));
  if (!sesion.token) return responder({ message: "No autenticado." }, 401);
  if (!ID_RESERVA.test(reservaId))
    return responder({ message: "Identificador de reserva inválido." }, 400);
  const body: unknown = await request.json().catch(() => null);
  if (!body || typeof body !== "object")
    return responder({ message: "Datos inválidos." }, 400);
  const dato = body as Record<string, unknown>;
  if (
    typeof dato.fechaDevolucion !== "string" ||
    !/^\d{4}-\d{2}-\d{2}T/.test(dato.fechaDevolucion) ||
    !Number.isFinite(Date.parse(dato.fechaDevolucion)) ||
    !/(Z|[+-]\d{2}:\d{2})$/.test(dato.fechaDevolucion)
  )
    return responder({ message: "Fecha ISO 8601 con zona obligatoria." }, 400);
  if (Date.parse(dato.fechaDevolucion) > Date.now())
    return responder(
      { message: "La fecha de devolución no puede ser futura." },
      400,
    );
  if (
    typeof dato.estadoFinalBien !== "string" ||
    !ESTADOS_FINALES.includes(
      dato.estadoFinalBien as (typeof ESTADOS_FINALES)[number],
    )
  )
    return responder({ message: "Estado final inválido." }, 400);
  if (
    dato.observaciones !== undefined &&
    (typeof dato.observaciones !== "string" ||
      contarObservaciones(dato.observaciones) > 500)
  )
    return responder({ message: "Observaciones inválidas." }, 400);
  const destino = urlApi(`reservas/${reservaId}/devolucion`);
  if (!destino) return responder({ message: "Falta API_URL." }, 500);
  const payload = {
    fechaDevolucion: dato.fechaDevolucion,
    estadoFinalBien: dato.estadoFinalBien,
    ...(typeof dato.observaciones === "string" && dato.observaciones.trim()
      ? { observaciones: dato.observaciones.trim() }
      : {}),
  };
  // El registro de devolución puede tardar más que una consulta GET; se limita a 15 segundos.
  try {
    const resultado = await fetch(destino, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${sesion.token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
      cache: "no-store",
      signal: AbortSignal.timeout(15000),
    });
    return responder(
      await resultado.json().catch(() => ({})),
      resultado.status,
    );
  } catch {
    return responder({ message: "No se pudo contactar a la API." }, 502);
  }
}
