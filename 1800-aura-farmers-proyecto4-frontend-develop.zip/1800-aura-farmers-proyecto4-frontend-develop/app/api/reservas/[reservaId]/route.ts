import { NextResponse, type NextRequest } from "next/server";
import { ID_UUID, reenviarAApi } from "@/lib/solicitud/servidor";

/** Puente hacia `GET {API_URL}/reservas/:id` (BE-6.3): consulta el estado de una solicitud. */
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ reservaId: string }> },
) {
  const { reservaId } = await params;
  if (!ID_UUID.test(reservaId)) {
    return NextResponse.json({ message: "Reserva inválida." }, { status: 400 });
  }
  return reenviarAApi(request, `reservas/${reservaId}`, { method: "GET" });
}
