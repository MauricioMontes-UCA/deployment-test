import { NextResponse, type NextRequest } from "next/server";
import { sesionDeRuta, urlApi } from "@/lib/api-servidor";
import { llamarApi } from "@/lib/api";
import { ID_RESERVA, objeto, numero } from "@/lib/depositos";

type Contexto = { params: Promise<{ reservaId: string }> };

export async function POST(request: NextRequest, { params }: Contexto) {
  const { reservaId } = await params;
  const sesion = await sesionDeRuta(request.cookies);
  const responder = (datos: unknown, status: number) =>
    sesion.conSesion(NextResponse.json(datos, { status }));

  if (!ID_RESERVA.test(reservaId))
    return responder({ message: "Identificador inválido." }, 400);
  if (!sesion.token) return responder({ message: "No autenticado." }, 401);

  const datos = objeto(await request.json().catch(() => null));
  if (datos.accion !== "LIBERAR" && datos.accion !== "RETENER") {
    return responder({ message: "Acción inválida." }, 400);
  }

  let cuerpo: Record<string, unknown> = { accion: "LIBERAR" };
  if (datos.accion === "RETENER") {
    const importe = numero(datos.importeRetenido);
    const justificacion = datos.justificacion;
    if (
      importe === null ||
      importe <= 0 ||
      !Number.isInteger(Math.round(importe * 100)) ||
      Math.abs(importe * 100 - Math.round(importe * 100)) > 1e-7 ||
      typeof justificacion !== "string" ||
      !justificacion.trim() ||
      justificacion.trim().length > 500
    ) {
      return responder({ message: "Importe o justificación inválidos." }, 400);
    }
    cuerpo = {
      accion: "RETENER",
      importeRetenido: importe,
      justificacion: justificacion.trim(),
    };
  }

  // El backend expone /resolucion; /resolver es exclusivamente la ruta pública del frontend.
  const ruta = `reservas/${reservaId}/deposito/resolucion`;
  if (!urlApi(ruta)) return responder({ message: "API no configurada." }, 500);
  const respuesta = await llamarApi(
    ruta,
    { method: "POST", body: JSON.stringify(cuerpo) },
    sesion.token,
  );
  return responder(
    respuesta.status === 0
      ? { message: "No se pudo contactar al servidor." }
      : (respuesta.datos ?? {}),
    respuesta.status === 0 ? 502 : respuesta.status,
  );
}
