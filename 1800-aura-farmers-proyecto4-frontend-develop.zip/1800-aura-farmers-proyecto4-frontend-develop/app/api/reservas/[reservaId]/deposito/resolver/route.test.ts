import { beforeEach, describe, expect, it, vi } from "vitest";
import { NextRequest } from "next/server";

const mocks = vi.hoisted(() => ({
  sesionDeRuta: vi.fn(),
  urlApi: vi.fn(),
  llamarApi: vi.fn(),
}));
vi.mock("@/lib/api-servidor", () => ({
  sesionDeRuta: mocks.sesionDeRuta,
  urlApi: mocks.urlApi,
}));
vi.mock("@/lib/api", () => ({ llamarApi: mocks.llamarApi }));
import { POST } from "./route";

const id = "11111111-1111-4111-8111-111111111111";
const enviar = (body: unknown, reservaId = id) =>
  POST(
    new NextRequest(
      `http://localhost/api/reservas/${reservaId}/deposito/resolver`,
      {
        method: "POST",
        body: JSON.stringify(body),
        headers: { "Content-Type": "application/json" },
      },
    ),
    { params: Promise.resolve({ reservaId }) },
  );

beforeEach(() => {
  vi.clearAllMocks();
  mocks.sesionDeRuta.mockResolvedValue({
    token: "jwt",
    conSesion: (r: Response) => r,
  });
  mocks.urlApi.mockReturnValue(new URL("http://backend/api/v1/"));
  mocks.llamarApi.mockResolvedValue({
    status: 200,
    datos: { estado: "LIBERADO" },
  });
});

describe("FE-11.1 puente de resolución", () => {
  it("rechaza acción inválida con 400", async () =>
    expect((await enviar({ accion: "OTRA" })).status).toBe(400));
  it("rechaza UUID inválido con 400", async () =>
    expect((await enviar({ accion: "LIBERAR" }, "invalido")).status).toBe(400));
  it.each([
    { accion: "RETENER", importeRetenido: 1.234, justificacion: "Motivo" },
    { accion: "RETENER", importeRetenido: 1, justificacion: " " },
    { accion: "RETENER", importeRetenido: 1, justificacion: "x".repeat(501) },
  ])("rechaza retención inválida con 400: %j", async (cuerpo) => {
    expect((await enviar(cuerpo)).status).toBe(400);
    expect(mocks.llamarApi).not.toHaveBeenCalled();
  });
  it("responde 401 sin sesión", async () => {
    mocks.sesionDeRuta.mockResolvedValue({
      token: null,
      conSesion: (r: Response) => r,
    });
    expect((await enviar({ accion: "LIBERAR" })).status).toBe(401);
  });
  it("responde 502 cuando falla backend", async () => {
    mocks.llamarApi.mockResolvedValue({ status: 0, datos: null });
    expect((await enviar({ accion: "LIBERAR" })).status).toBe(502);
  });
  it("reenvía LIBERAR a /resolucion sin campos extra", async () => {
    expect((await enviar({ accion: "LIBERAR" })).status).toBe(200);
    expect(mocks.llamarApi).toHaveBeenCalledWith(
      `reservas/${id}/deposito/resolucion`,
      { method: "POST", body: JSON.stringify({ accion: "LIBERAR" }) },
      "jwt",
    );
  });
  it("reenvía RETENER con importe y justificación", async () => {
    await enviar({
      accion: "RETENER",
      importeRetenido: 1.13,
      justificacion: " Motivo ",
    });
    expect(mocks.llamarApi).toHaveBeenCalledWith(
      `reservas/${id}/deposito/resolucion`,
      {
        method: "POST",
        body: JSON.stringify({
          accion: "RETENER",
          importeRetenido: 1.13,
          justificacion: "Motivo",
        }),
      },
      "jwt",
    );
  });
});
