import { NextResponse, type NextRequest } from "next/server";
import { sesionDeRuta, urlApi } from "@/lib/api-servidor";
import { llamarApi } from "@/lib/api";
import { ID_RESERVA } from "@/lib/depositos";

export async function GET(request: NextRequest, { params }: { params: Promise<{ reservaId: string }> }) {

    const { reservaId } = await params;
 const sesion = await sesionDeRuta(request.cookies);
 const responder = (datos: unknown, status: number) => sesion.conSesion(NextResponse.json(datos, { status }));

 if (!ID_RESERVA.test(reservaId)) return responder({ message: "Identificador inválido." }, 400);
 if (!sesion.token) return responder({ message: "No autenticado." }, 401);
 if (!urlApi(`reservas/${reservaId}/deposito`)) return responder({ message: "API no configurada." }, 500);

 const r = await llamarApi(`reservas/${reservaId}/deposito`, { method: "GET" }, sesion.token);

 return responder(r.status === 0 ? { message: "No se pudo contactar al servidor." } : r.datos ?? {}, r.status === 0 ? 502 : r.status);
}
