import {
  NextResponse,
  type NextRequest,
} from "next/server";

import {
  sesionDeRuta,
  urlApi,
} from "@/lib/api-servidor";

import { llamarApi } from "@/lib/api";

import {
  ID_RESERVA,
  type CrearPago,
} from "@/lib/pagos/tipos";

export async function POST(
  request: NextRequest,
  {
    params,
  }: {
    params: Promise<{ reservaId: string }>;
  },
) {
  const { reservaId } = await params;

  const sesion = await sesionDeRuta(request.cookies);

  const responder = (
    datos: unknown,
    status: number,
  ) =>
    sesion.conSesion(
      NextResponse.json(datos, { status }),
    );

  if (!ID_RESERVA.test(reservaId)) {
    return responder(
      { message: "Identificador de reserva inválido." },
      400,
    );
  }

  if (!sesion.token) {
    return responder(
      { message: "No autenticado." },
      401,
    );
  }

  if (!urlApi(`reservas/${reservaId}/pagos`)) {
    return responder(
      { message: "La API no está configurada." },
      500,
    );
  }

  const cuerpo: unknown = await request
    .json()
    .catch(() => null);

  if (
    typeof cuerpo !== "object" ||
    cuerpo === null
  ) {
    return responder(
      { message: "El cuerpo del pago es inválido." },
      400,
    );
  }

  const datos = cuerpo as Record<string, unknown>;

  let pago: CrearPago;

  if (datos.modalidad === "TARJETA") {
    if (
      typeof datos.numeroTarjeta !== "string" ||
      !/^\d{12,19}$/.test(datos.numeroTarjeta) ||
      typeof datos.vencimiento !== "string" ||
      !/^(0[1-9]|1[0-2])\/\d{2}$/.test(
        datos.vencimiento,
      ) ||
      typeof datos.codigoSeguridad !== "string" ||
      !/^\d{3,4}$/.test(datos.codigoSeguridad)
    ) {
      return responder(
        { message: "Los datos de tarjeta son inválidos." },
        400,
      );
    }

    pago = {
      modalidad: "TARJETA",
      numeroTarjeta: datos.numeroTarjeta,
      vencimiento: datos.vencimiento,
      codigoSeguridad: datos.codigoSeguridad,
    };
  } else if (
    datos.modalidad === "TRANSFERENCIA_BANCARIA"
  ) {
    if (
      typeof datos.referenciaSimulada !== "string" ||
      !/^[A-Za-z0-9-]{6,20}$/.test(
        datos.referenciaSimulada,
      )
    ) {
      return responder(
        { message: "La referencia es inválida." },
        400,
      );
    }

    pago = {
      modalidad: "TRANSFERENCIA_BANCARIA",
      referenciaSimulada: datos.referenciaSimulada,
    };
  } else {
    return responder(
      { message: "Modalidad de pago inválida." },
      400,
    );
  }

  const resultado = await llamarApi(
    `reservas/${reservaId}/pagos`,
    {
      method: "POST",
      body: JSON.stringify(pago),
    },
    sesion.token,
  );

  if (resultado.status === 0) {
    return responder(
      { message: "No se pudo contactar al servidor." },
      502,
    );
  }

  return responder(
    resultado.datos ?? {},
    resultado.status,
  );
}