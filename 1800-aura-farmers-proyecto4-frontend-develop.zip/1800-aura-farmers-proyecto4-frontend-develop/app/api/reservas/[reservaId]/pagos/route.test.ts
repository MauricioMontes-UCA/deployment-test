import { afterEach, describe, expect, it, vi } from "vitest";
import { NextRequest } from "next/server";

const mocks = vi.hoisted(() => ({
  sesionDeRuta: vi.fn(),
  urlApi: vi.fn(),
  llamarApi: vi.fn(),
}));

vi.mock("@/lib/api-servidor", () => ({
  sesionDeRuta: mocks.sesionDeRuta,
  urlApi: mocks.urlApi,
}));
vi.mock("@/lib/api", () => ({ llamarApi: mocks.llamarApi }));

import { POST } from "./route";

const ID = "5a3f2c10-8d4e-4b1a-9c7e-1f2a3b4c5d6e";
const ruta = { params: Promise.resolve({ reservaId: ID }) };
const request = (body?: unknown) =>
  new NextRequest(`http://localhost/api/reservas/${ID}/pagos`, {
    method: "POST",
    ...(body
      ? {
          body: JSON.stringify(body),
          headers: { "Content-Type": "application/json" },
        }
      : {}),
  });
const enviar = (body?: unknown) => POST(request(body), ruta);

afterEach(() => vi.clearAllMocks());

describe("FE-8.1 puente pagos", () => {
  it("401 sin sesión", async () => {
    mocks.sesionDeRuta.mockResolvedValue({
      token: undefined,
      conSesion: (r: Response) => r,
    });
    expect((await enviar()).status).toBe(401);
  });

  it("400 para UUID inválido", async () => {
    mocks.sesionDeRuta.mockResolvedValue({
      token: "jwt",
      conSesion: (r: Response) => r,
    });
    const r = await POST(request(), {
      params: Promise.resolve({ reservaId: "incorrecto" }),
    });
    expect(r.status).toBe(400);
  });

  it("502 si backend no responde", async () => {
    mocks.sesionDeRuta.mockResolvedValue({
      token: "jwt",
      conSesion: (r: Response) => r,
    });
    mocks.urlApi.mockReturnValue(new URL("http://localhost:3000/api/v1/"));
    mocks.llamarApi.mockResolvedValue({ status: 0, datos: null });
    const r = await enviar({
      modalidad: "TRANSFERENCIA_BANCARIA",
      referenciaSimulada: "SIM-APRUEBA",
    });
    expect(r.status).toBe(502);
  });

  it("reenvía el token sin exponerlo en la respuesta", async () => {
    mocks.sesionDeRuta.mockResolvedValue({
      token: "jwt-secreto",
      conSesion: (r: Response) => r,
    });
    mocks.urlApi.mockReturnValue(new URL("http://localhost:3000/api/v1/"));
    mocks.llamarApi.mockResolvedValue({ status: 200, datos: { ok: true } });
    const r = await enviar({
      modalidad: "TRANSFERENCIA_BANCARIA",
      referenciaSimulada: "SIM-APRUEBA",
    });
    expect(mocks.llamarApi).toHaveBeenCalledWith(
      expect.stringContaining("pagos"),
      expect.any(Object),
      "jwt-secreto",
    );
    expect(JSON.stringify(await r.json())).not.toContain("jwt-secreto");
  });
});
