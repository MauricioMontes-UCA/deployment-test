import {
  NextResponse,
  type NextRequest,
} from "next/server";

import {
  sesionDeRuta,
  urlApi,
} from "@/lib/api-servidor";

import { ID_RESERVA } from "@/lib/pagos/tipos";

import { llamarApi } from "@/lib/api";

export async function GET(
  request: NextRequest,
  {
    params,
  }: {
    params: Promise<{ reservaId: string }>;
  },
) {
  const { reservaId } = await params;

  const sesion = await sesionDeRuta(request.cookies);

  const responder = (
    datos: unknown,
    status: number,
  ) =>
    sesion.conSesion(
      NextResponse.json(datos, { status }),
    );

  if (!ID_RESERVA.test(reservaId)) {
    return responder(
      { message: "Identificador de reserva inválido." },
      400,
    );
  }

  if (!sesion.token) {
    return responder(
      { message: "No autenticado." },
      401,
    );
  }

  if (!urlApi(`reservas/${reservaId}/resumen-pago`)) {
    return responder(
      { message: "La API no está configurada." },
      500,
    );
  }

  const resultado = await llamarApi(
    `reservas/${reservaId}/resumen-pago`,
    { method: "GET" },
    sesion.token,
  );

  if (resultado.status === 0) {
    return responder(
      { message: "No se pudo contactar al servidor." },
      502,
    );
  }

  return responder(
    resultado.datos ?? {},
    resultado.status,
  );
}