import { NextResponse, type NextRequest } from "next/server";
import { ID_UUID, reenviarAApi } from "@/lib/solicitud/servidor";

/** GET interno: nunca entrega el JWT al navegador. */
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ pagoId: string }> },
) {
  const { pagoId } = await params;
  if (!ID_UUID.test(pagoId)) {
    return NextResponse.json({ message: "Identificador de pago inválido." }, { status: 400 });
  }
  return reenviarAApi(request, `pagos/${pagoId}/comprobante`, { method: "GET" });
}
