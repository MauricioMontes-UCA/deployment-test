import { beforeEach, describe, expect, it, vi } from "vitest";
import { NextRequest, NextResponse } from "next/server";

const { reenviarAApi } = vi.hoisted(() => ({ reenviarAApi: vi.fn() }));

vi.mock("@/lib/solicitud/servidor", () => ({
  ID_UUID: /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i,
  reenviarAApi,
}));

import { GET } from "./route";

const id = "11111111-1111-4111-8111-111111111111";
const request = new NextRequest(`http://localhost/api/pagos/${id}/comprobante`);
const contexto = (pagoId: string) => ({ params: Promise.resolve({ pagoId }) });

beforeEach(() => reenviarAApi.mockReset());

describe("FE-9.1 puente de comprobante", () => {
  it("rechaza un identificador inválido", async () => {
    const res = await GET(request, contexto("invalido"));
    expect(res.status).toBe(400);
    expect(reenviarAApi).not.toHaveBeenCalled();
  });

  it("reenvía GET al backend con la sesión centralizada", async () => {
    reenviarAApi.mockResolvedValue(
      NextResponse.json({ pagoId: id }, { status: 200 }),
    );
    const res = await GET(request, contexto(id));
    expect(res.status).toBe(200);
    expect(reenviarAApi).toHaveBeenCalledWith(
      request,
      `pagos/${id}/comprobante`,
      { method: "GET" },
    );
  });

  it.each([401, 403, 404, 409, 502])(
    "conserva respuesta %i del puente",
    async (status) => {
      reenviarAApi.mockResolvedValue(
        NextResponse.json({ message: "error" }, { status }),
      );
      expect((await GET(request, contexto(id))).status).toBe(status);
    },
  );
});
