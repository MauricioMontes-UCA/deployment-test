"use client";

import { cerrarSesion } from "@/app/actions/auth";
import { NavegacionSuperior, type RolNavegacion } from "@/components/ui";

type Props = { rol: Exclude<RolNavegacion, "visitante">; nombreUsuario: string };

/** Barra superior con «Cerrar sesión» conectado a la acción del servidor. */
export function BarraPerfil({ rol, nombreUsuario }: Props) {
  return (
    <NavegacionSuperior
      rol={rol}
      nombreUsuario={nombreUsuario}
      onCerrarSesion={() => void cerrarSesion()}
    />
  );
}
