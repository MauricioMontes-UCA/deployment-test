import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { cerrarSesion } from "@/app/actions/auth";
import {
  Avatar,
  Boton,
  Contenedor,
  EncabezadoDePagina,
  EstadoDePagina,
  NavegacionSuperior,
  PieDePagina,
  clasesBoton,
} from "@/components/ui";
import { llamarApi } from "@/lib/api";
import { obtenerUsuarioActual } from "@/lib/usuario-actual";
import { esMiEstado, type MiEstado } from "@/lib/verificacion/documento";
import { BarraPerfil } from "./barra-perfil";
import { textoMiembroDesde } from "./miembro-desde";
import { PanelVerificacion } from "./panel-verificacion";

export const metadata: Metadata = { title: "Perfil · Arre" };

// Estado inicial leído en el servidor: la pantalla llega ya pintada y el
// panel solo consulta de nuevo mientras la revisión está en curso. Un 401
// manda a /sesion-vencida, como en el resto de las pantallas protegidas.
async function leerEstado(): Promise<MiEstado | null> {
  const { status, datos } = await llamarApi("verificaciones/mi-estado");
  if (status === 401) redirect("/sesion-vencida");
  return status === 200 && esMiEstado(datos) ? datos : null;
}

const NOMBRE_ROL = { ARRENDADOR: "Arrendador", ARRENDATARIO: "Arrendatario" } as const;

export default async function PerfilPage() {
  const resultado = await obtenerUsuarioActual();
  // Pasa por /sesion-vencida para borrar la cookie; con ella, el proxy no deja entrar a /login.
  if (resultado.estado === "sin-sesion") redirect("/sesion-vencida");

  if (resultado.estado === "error") {
    return (
      <>
        <NavegacionSuperior rol="visitante" />
        <main className="flex-1 py-espacio-5 md:py-espacio-6">
          <Contenedor>
            <EstadoDePagina
              tipo="error"
              accion={
                <Link href="/perfil" className={clasesBoton({ jerarquia: "secundario" })}>
                  Reintentar
                </Link>
              }
            />
          </Contenedor>
        </main>
        <PieDePagina />
      </>
    );
  }

  const { usuario } = resultado;
  const rol = usuario.rol;
  const nombre = usuario.nombreUsuario;
  // Correo y fecha de alta salen de /auth/me, como el nombre y el rol.
  const { email } = usuario;
  const miembroDesde = textoMiembroDesde(usuario.createdAt);
  const estado = await leerEstado();

  return (
    <>
      <BarraPerfil
        rol={rol === "ARRENDADOR" ? "arrendador" : "arrendatario"}
        nombreUsuario={nombre}
      />
      <main className="flex-1 py-espacio-5 md:py-espacio-6">
        <Contenedor className="flex flex-col gap-espacio-5 md:gap-espacio-6">
          <EncabezadoDePagina
            sobretitulo="Mi cuenta"
            titulo="Perfil"
            descripcion="Tus datos de cuenta y la verificación de identidad."
          />
          <div className="flex flex-col gap-espacio-5 md:flex-row md:items-start md:gap-espacio-6">
            <div className="order-2 flex w-full flex-col gap-espacio-3 border border-borde-default bg-fondo-superficie p-espacio-5 md:order-1 md:w-105 md:shrink-0">
              <div className="flex items-center gap-espacio-4">
                <Avatar nombre={nombre} tamano="grande" />
                <div className="flex min-w-0 flex-col gap-0.5">
                  <p className="texto-h3 break-all text-texto-primario">{nombre}</p>
                  {rol && (
                    <p className="texto-etiqueta text-texto-acento">{NOMBRE_ROL[rol]}</p>
                  )}
                </div>
              </div>
              {email && (
                <div className="texto-cuerpo-pequeno flex items-start justify-between gap-espacio-4 border-b border-borde-sutil py-2.5">
                  <span className="text-texto-secundario">Correo</span>
                  <span className="min-w-0 break-all text-right text-texto-primario">{email}</span>
                </div>
              )}
              {rol && (
                <div className="texto-cuerpo-pequeno flex items-start justify-between gap-espacio-4 border-b border-borde-sutil py-2.5">
                  <span className="text-texto-secundario">Rol</span>
                  <span className="text-texto-primario">{NOMBRE_ROL[rol]}</span>
                </div>
              )}
              {miembroDesde && (
                <div className="texto-cuerpo-pequeno flex items-start justify-between gap-espacio-4 border-b border-borde-sutil py-2.5">
                  <span className="text-texto-secundario">Miembro desde</span>
                  <span className="text-right text-texto-primario">{miembroDesde}</span>
                </div>
              )}
              <form action={cerrarSesion}>
                <Boton type="submit" jerarquia="terciario" icono="salir">
                  Cerrar sesión
                </Boton>
              </form>
            </div>
            <div className="order-1 min-w-0 flex-1 md:order-2">
              <PanelVerificacion inicial={estado} />
            </div>
          </div>
        </Contenedor>
      </main>
      <PieDePagina />
    </>
  );
}
