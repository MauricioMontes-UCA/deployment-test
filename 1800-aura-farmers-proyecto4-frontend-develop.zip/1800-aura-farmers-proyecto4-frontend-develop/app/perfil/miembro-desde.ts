import { ZONA_HORARIA } from "@/lib/disponibilidad";

const FORMATO = new Intl.DateTimeFormat("es", {
  day: "numeric",
  month: "long",
  year: "numeric",
  timeZone: ZONA_HORARIA,
});

/**
 * «Miembro desde» de la pantalla de perfil: la fecha de alta (`createdAt` de
 * `GET /auth/me`) como «19 de noviembre de 2026», en la zona horaria de El
 * Salvador, igual que el resto de las fechas de la aplicación. Devuelve `null`
 * si la fecha no es válida, para que la fila no se muestre.
 */
export function textoMiembroDesde(createdAt: string): string | null {
  const fecha = new Date(createdAt);
  return Number.isNaN(fecha.getTime()) ? null : FORMATO.format(fecha);
}
