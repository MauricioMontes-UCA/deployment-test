import { act, render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("@/app/actions/auth", () => ({ cerrarSesion: vi.fn() }));
vi.mock("@/lib/verificacion/cliente", () => ({
  consultarEstado: vi.fn(),
  enviarDocumento: vi.fn(),
}));

import { consultarEstado, enviarDocumento } from "@/lib/verificacion/cliente";
import { INTERVALO_CONSULTA_MS, MAX_CONSULTAS, PanelVerificacion } from "./panel-verificacion";

const consultar = vi.mocked(consultarEstado);
const enviar = vi.mocked(enviarDocumento);

const sinSolicitudes = { estado: "NO_VERIFICADO", motivo: null, solicitudId: null, revisadoEn: null } as const;
const enRevision = { estado: "EN_REVISION", motivo: null, solicitudId: "s1", revisadoEn: null } as const;

function archivoValido() {
  return new File(["contenido"], "dui.png", { type: "image/png" });
}

async function elegir(archivo: File) {
  // `applyAccept: false`: el filtro `accept` del input no debe ocultar el archivo inválido.
  const usuario = userEvent.setup({ applyAccept: false });
  await usuario.upload(document.querySelector("input[type=file]") as HTMLInputElement, archivo);
  return usuario;
}

beforeEach(() => {
  consultar.mockReset();
  enviar.mockReset();
});

describe("PanelVerificacion · carga", () => {
  it("rechaza en cliente un formato inválido sin llamar al servicio", async () => {
    render(<PanelVerificacion inicial={sinSolicitudes} />);
    await elegir(new File(["x"], "a.gif", { type: "image/gif" }));
    expect(screen.getByText("Formato no permitido. Usa JPG, PNG o PDF.")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Enviar documento" })).toBeDisabled();
    expect(enviar).not.toHaveBeenCalled();
  });

  it("rechaza en cliente un archivo de más de 5 MB", async () => {
    render(<PanelVerificacion inicial={sinSolicitudes} />);
    const grande = new File(["x"], "grande.pdf", { type: "application/pdf" });
    Object.defineProperty(grande, "size", { value: 5 * 1024 * 1024 + 1 });
    await elegir(grande);
    expect(screen.getByText("El archivo supera 5 MB.")).toBeInTheDocument();
    expect(enviar).not.toHaveBeenCalled();
  });

  it("envía el documento y pasa a «En revisión» sin recargar", async () => {
    enviar.mockResolvedValue({ tipo: "ok" });
    render(<PanelVerificacion inicial={sinSolicitudes} />);
    const usuario = await elegir(archivoValido());
    await usuario.click(screen.getByRole("button", { name: "Enviar documento" }));

    expect(enviar).toHaveBeenCalledTimes(1);
    expect(await screen.findByText("Documento enviado. Está en revisión.")).toBeInTheDocument();
    expect(screen.getByText("En revisión")).toBeInTheDocument();
    expect(screen.getByText("Ya tienes un documento en revisión")).toBeInTheDocument();
  });

  it("muestra el avance mientras sube", async () => {
    let avanzar: (p: number) => void = () => {};
    let terminar: (r: { tipo: "ok" }) => void = () => {};
    enviar.mockImplementation((_a, alAvanzar) => {
      avanzar = alAvanzar;
      return new Promise((resolver) => {
        terminar = resolver;
      });
    });
    render(<PanelVerificacion inicial={sinSolicitudes} />);
    const usuario = await elegir(archivoValido());
    await usuario.click(screen.getByRole("button", { name: "Enviar documento" }));

    act(() => avanzar(60));
    expect(screen.getByText("Subiendo dui.png… 60%")).toBeInTheDocument();
    expect(screen.getByRole("progressbar", { name: "Subiendo documento" })).toHaveAttribute("aria-valuenow", "60");
    await act(async () => terminar({ tipo: "ok" }));
  });

  it("muestra el mensaje del 409 y del fallo general", async () => {
    enviar.mockResolvedValueOnce({ tipo: "conflicto", mensaje: "Ya tienes un documento en revisión." });
    consultar.mockResolvedValue({ tipo: "ok", estado: enRevision });
    render(<PanelVerificacion inicial={sinSolicitudes} />);
    const usuario = await elegir(archivoValido());
    await usuario.click(screen.getByRole("button", { name: "Enviar documento" }));
    await waitFor(() => expect(screen.getByText("En revisión")).toBeInTheDocument());
  });

  it("muestra el fallo general sin cambiar de estado", async () => {
    enviar.mockResolvedValue({ tipo: "error", mensaje: "No pudimos enviar el documento. Intenta de nuevo." });
    render(<PanelVerificacion inicial={sinSolicitudes} />);
    const usuario = await elegir(archivoValido());
    await usuario.click(screen.getByRole("button", { name: "Enviar documento" }));
    expect(await screen.findByText("No pudimos enviar el documento. Intenta de nuevo.")).toBeInTheDocument();
    expect(screen.getByText("No verificado")).toBeInTheDocument();
  });

  it("ofrece iniciar sesión de nuevo si el envío da 401", async () => {
    enviar.mockResolvedValue({ tipo: "sesion" });
    render(<PanelVerificacion inicial={sinSolicitudes} />);
    const usuario = await elegir(archivoValido());
    await usuario.click(screen.getByRole("button", { name: "Enviar documento" }));
    expect(await screen.findByText("Tu sesión venció")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Iniciar sesión" })).toBeInTheDocument();
  });
});

describe("PanelVerificacion · estados", () => {
  it("rechazado: muestra el motivo y habilita una carga nueva", () => {
    render(
      <PanelVerificacion
        inicial={{
          estado: "RECHAZADO",
          motivo: "Documento no válido (revisión simulada).",
          solicitudId: "s1",
          revisadoEn: "2026-11-18T21:12:00.000Z",
        }}
      />,
    );
    expect(screen.getByText("Tu documento fue rechazado")).toBeInTheDocument();
    expect(screen.getByText(/Documento no válido \(revisión simulada\)\./)).toBeInTheDocument();
    expect(screen.getByText(/18\/11\/2026 15:12/)).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Enviar documento nuevo" })).toBeInTheDocument();
  });

  it("verificado: sin formulario de carga", () => {
    render(
      <PanelVerificacion
        inicial={{ estado: "VERIFICADO", motivo: null, solicitudId: "s1", revisadoEn: "2026-11-18T21:12:00.000Z" }}
      />,
    );
    expect(screen.getByText("Cuenta verificada")).toBeInTheDocument();
    expect(document.querySelector("input[type=file]")).toBeNull();
  });

  it("no verificado: formulario habilitado", () => {
    render(<PanelVerificacion inicial={sinSolicitudes} />);
    expect(document.querySelector("input[type=file]")).not.toBeDisabled();
  });

  it("en revisión: formulario deshabilitado", () => {
    render(<PanelVerificacion inicial={enRevision} />);
    expect(document.querySelector("input[type=file]")).toBeDisabled();
  });

  it("si no pudo cargar el estado ofrece reintentar", async () => {
    consultar.mockResolvedValue({ tipo: "ok", estado: sinSolicitudes });
    render(<PanelVerificacion inicial={null} />);
    const usuario = userEvent.setup();
    await usuario.click(screen.getByRole("button", { name: "Reintentar" }));
    expect(await screen.findByText("No verificado")).toBeInTheDocument();
  });
});

describe("PanelVerificacion · consulta periódica", () => {
  beforeEach(() => vi.useFakeTimers());
  afterEach(() => vi.useRealTimers());

  it("consulta cada 5 s y pasa a Verificado sin recargar", async () => {
    consultar
      .mockResolvedValueOnce({ tipo: "ok", estado: enRevision })
      .mockResolvedValueOnce({
        tipo: "ok",
        estado: { estado: "VERIFICADO", motivo: null, solicitudId: "s1", revisadoEn: "2026-11-18T21:12:00.000Z" },
      });
    render(<PanelVerificacion inicial={enRevision} />);

    await act(() => vi.advanceTimersByTimeAsync(INTERVALO_CONSULTA_MS));
    expect(consultar).toHaveBeenCalledTimes(1);
    expect(screen.getByText("En revisión")).toBeInTheDocument();

    await act(() => vi.advanceTimersByTimeAsync(INTERVALO_CONSULTA_MS));
    expect(screen.getByText("Cuenta verificada")).toBeInTheDocument();

    await act(() => vi.advanceTimersByTimeAsync(INTERVALO_CONSULTA_MS * 3));
    expect(consultar).toHaveBeenCalledTimes(2);
  });

  it("pasa a Rechazado con el motivo", async () => {
    consultar.mockResolvedValue({
      tipo: "ok",
      estado: { estado: "RECHAZADO", motivo: "Borroso.", solicitudId: "s1", revisadoEn: "2026-11-18T21:12:00.000Z" },
    });
    render(<PanelVerificacion inicial={enRevision} />);
    await act(() => vi.advanceTimersByTimeAsync(INTERVALO_CONSULTA_MS));
    expect(screen.getByText(/Motivo: Borroso\./)).toBeInTheDocument();
  });

  it("a los 60 s deja de consultar y avisa que sigue en revisión", async () => {
    consultar.mockResolvedValue({ tipo: "ok", estado: enRevision });
    render(<PanelVerificacion inicial={enRevision} />);
    await act(() => vi.advanceTimersByTimeAsync(INTERVALO_CONSULTA_MS * MAX_CONSULTAS));
    expect(consultar).toHaveBeenCalledTimes(MAX_CONSULTAS);
    expect(screen.getByText("Seguimos revisando tu documento.")).toBeInTheDocument();
    expect(screen.getByText("Vuelve en unos minutos.")).toBeInTheDocument();

    await act(() => vi.advanceTimersByTimeAsync(INTERVALO_CONSULTA_MS * 5));
    expect(consultar).toHaveBeenCalledTimes(MAX_CONSULTAS);
  });

  it("si la consulta da 401 pide iniciar sesión de nuevo", async () => {
    consultar.mockResolvedValue({ tipo: "sesion" });
    render(<PanelVerificacion inicial={enRevision} />);
    await act(() => vi.advanceTimersByTimeAsync(INTERVALO_CONSULTA_MS));
    expect(screen.getByText("Tu sesión venció")).toBeInTheDocument();
  });
});
