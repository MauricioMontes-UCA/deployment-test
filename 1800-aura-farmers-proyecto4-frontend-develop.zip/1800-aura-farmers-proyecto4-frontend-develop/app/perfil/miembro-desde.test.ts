import { describe, expect, it } from "vitest";
import { textoMiembroDesde } from "./miembro-desde";

describe("textoMiembroDesde", () => {
  it("escribe la fecha de alta en español", () => {
    expect(textoMiembroDesde("2026-11-19T15:30:00.000Z")).toBe("19 de noviembre de 2026");
  });

  it("usa el día de El Salvador, no el de UTC", () => {
    // 03:00 UTC del 20 son las 21:00 del 19 en El Salvador (UTC-6).
    expect(textoMiembroDesde("2026-11-20T03:00:00.000Z")).toBe("19 de noviembre de 2026");
  });

  it("devuelve null si la fecha no es válida", () => {
    expect(textoMiembroDesde("no es una fecha")).toBeNull();
    expect(textoMiembroDesde("")).toBeNull();
  });
});
