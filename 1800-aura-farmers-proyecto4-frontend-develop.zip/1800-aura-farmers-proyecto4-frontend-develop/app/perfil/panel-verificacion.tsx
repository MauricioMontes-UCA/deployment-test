"use client";

import { useEffect, useState } from "react";
import { cerrarSesion } from "@/app/actions/auth";
import {
  Alerta,
  BarraDeProgreso,
  Boton,
  CargadorDeArchivos,
  Icono,
  InsigniaDeEstado,
  TONO_POR_ESTADO,
} from "@/components/ui";
import { consultarEstado, enviarDocumento } from "@/lib/verificacion/cliente";
import {
  MENSAJES_VERIFICACION,
  TEXTO_ESTADO,
  formatearFecha,
  formatearTamano,
  validarDocumento,
  type EstadoVerificacion,
  type MiEstado,
} from "@/lib/verificacion/documento";

/** Cada cuánto se consulta el estado mientras está EN_REVISION. */
export const INTERVALO_CONSULTA_MS = 5000;
/** Consultas antes de rendirse: 12 × 5 s = 60 s. */
export const MAX_CONSULTAS = 12;

type Props = {
  /** Estado leído en el servidor; `null` si no se pudo consultar. */
  inicial: MiEstado | null;
  sesionVencida?: boolean;
};

function Fila({ etiqueta, valor }: { etiqueta: string; valor: string }) {
  return (
    <div className="texto-cuerpo-pequeno flex items-start justify-between gap-espacio-4 border-b border-borde-sutil py-2.5">
      <span className="text-texto-secundario">{etiqueta}</span>
      <span className="min-w-0 break-words text-right text-texto-primario">{valor}</span>
    </div>
  );
}

function SesionVencida() {
  return (
    <Alerta tono="advertencia" titulo="Tu sesión venció">
      <p>Vuelve a iniciar sesión para continuar.</p>
      <form action={cerrarSesion} className="pt-espacio-2">
        <Boton type="submit" jerarquia="secundario">
          Iniciar sesión
        </Boton>
      </form>
    </Alerta>
  );
}

export function PanelVerificacion({ inicial, sesionVencida: vencidaInicial = false }: Props) {
  const [estado, setEstado] = useState<EstadoVerificacion | null>(inicial?.estado ?? null);
  const [motivo, setMotivo] = useState(inicial?.motivo ?? null);
  const [revisadoEn, setRevisadoEn] = useState(inicial?.revisadoEn ?? null);
  const [sesionVencida, setSesionVencida] = useState(vencidaInicial);
  const [archivo, setArchivo] = useState<File | null>(null);
  const [errorArchivo, setErrorArchivo] = useState<string | null>(null);
  const [errorEnvio, setErrorEnvio] = useState<string | null>(null);
  const [progreso, setProgreso] = useState<number | null>(null);
  const [recienEnviado, setRecienEnviado] = useState(false);
  const [consultas, setConsultas] = useState(0);
  const [demorado, setDemorado] = useState(false);
  const [errorCarga, setErrorCarga] = useState(inicial === null && !vencidaInicial);

  const enviando = progreso !== null;

  function aplicar(nuevo: MiEstado) {
    setEstado(nuevo.estado);
    setMotivo(nuevo.motivo);
    setRevisadoEn(nuevo.revisadoEn);
    setErrorCarga(false);
    if (nuevo.estado !== "EN_REVISION") {
      setRecienEnviado(false);
      setConsultas(0);
      setDemorado(false);
    }
  }

  // Mientras está EN_REVISION se consulta cada 5 s, hasta recibir el
  // resultado o hasta 60 s.
  useEffect(() => {
    if (estado !== "EN_REVISION" || demorado || sesionVencida) return;
    let cancelado = false;
    let hechas = 0;
    const id = setInterval(async () => {
      hechas += 1;
      const resultado = await consultarEstado();
      if (cancelado) return;
      if (resultado.tipo === "sesion") {
        setSesionVencida(true);
        return;
      }
      if (resultado.tipo === "ok" && resultado.estado.estado !== "EN_REVISION") {
        aplicar(resultado.estado);
        return;
      }
      setConsultas(hechas);
      if (hechas >= MAX_CONSULTAS) setDemorado(true);
    }, INTERVALO_CONSULTA_MS);
    return () => {
      cancelado = true;
      clearInterval(id);
    };
  }, [estado, demorado, sesionVencida]);

  async function reconsultar() {
    const resultado = await consultarEstado();
    if (resultado.tipo === "sesion") return setSesionVencida(true);
    if (resultado.tipo === "error") return setErrorCarga(true);
    setConsultas(0);
    setDemorado(false);
    aplicar(resultado.estado);
  }

  function elegirArchivos(archivos: File[]) {
    const elegido = archivos[0];
    setErrorEnvio(null);
    const error = validarDocumento(elegido);
    setErrorArchivo(error);
    setArchivo(error ? null : elegido);
  }

  async function enviar() {
    if (!archivo || enviando) return;
    // Se vuelve a validar: el envío nunca llama al servicio con un archivo inválido.
    const error = validarDocumento(archivo);
    if (error) {
      setErrorArchivo(error);
      setArchivo(null);
      return;
    }
    setErrorEnvio(null);
    setProgreso(0);
    const resultado = await enviarDocumento(archivo, setProgreso);
    setProgreso(null);
    switch (resultado.tipo) {
      case "ok":
        setArchivo(null);
        setRecienEnviado(true);
        setConsultas(0);
        setDemorado(false);
        setEstado("EN_REVISION");
        break;
      case "sesion":
        setSesionVencida(true);
        break;
      case "conflicto":
        setErrorEnvio(resultado.mensaje);
        void reconsultar();
        break;
      case "validacion":
        setErrorArchivo(resultado.mensaje);
        setArchivo(null);
        break;
      default:
        setErrorEnvio(resultado.mensaje);
    }
  }

  const puedeEnviar = estado === "NO_VERIFICADO" || estado === "RECHAZADO";
  const fecha = revisadoEn ? formatearFecha(revisadoEn) : "";

  return (
    <section
      aria-labelledby="titulo-verificacion"
      className="flex w-full flex-col gap-espacio-4 border border-borde-default bg-fondo-superficie p-espacio-5"
    >
      <div className="flex flex-wrap items-center justify-between gap-y-espacio-2">
        <div className="flex items-center gap-espacio-2">
          <Icono nombre="verificado" className="text-texto-acento" />
          <h2 id="titulo-verificacion" className="texto-h3 text-texto-primario">
            Verificación de identidad
          </h2>
        </div>
        {estado && (
          <InsigniaDeEstado texto={TEXTO_ESTADO[estado]} tono={TONO_POR_ESTADO[estado] ?? "neutro"} />
        )}
      </div>

      <p className="texto-cuerpo-pequeno text-texto-secundario">
        Algunos arrendadores solo aceptan solicitudes de usuarios verificados. Sube tu DUI o
        pasaporte; la revisión es automática y tarda como máximo 30 segundos.
      </p>

      {sesionVencida && <SesionVencida />}

      {!sesionVencida && errorCarga && (
        <Alerta tono="error" titulo="No pudimos cargar tu estado">
          <p>{MENSAJES_VERIFICACION.consulta}</p>
          <div className="pt-espacio-2">
            <Boton jerarquia="secundario" onClick={reconsultar}>
              Reintentar
            </Boton>
          </div>
        </Alerta>
      )}

      {!sesionVencida && estado === "VERIFICADO" && (
        <>
          <Alerta tono="exito" titulo="Cuenta verificada">
            Ya puedes solicitar bienes que exigen usuarios verificados.
          </Alerta>
          {fecha && <Fila etiqueta="Revisado" valor={fecha} />}
        </>
      )}

      {!sesionVencida && estado === "RECHAZADO" && (
        <Alerta tono="error" titulo="Tu documento fue rechazado">
          {motivo ? `Motivo: ${motivo} ` : ""}
          {fecha ? `Revisado el ${fecha}. ` : ""}Puedes subir un documento nuevo.
        </Alerta>
      )}

      {!sesionVencida && estado === "EN_REVISION" && (
        <>
          {demorado ? (
            <Alerta tono="info" titulo="Seguimos revisando tu documento.">
              Vuelve en unos minutos.
            </Alerta>
          ) : (
            <Alerta
              tono="info"
              titulo={
                recienEnviado ? MENSAJES_VERIFICACION.enviado : "Tu documento está en revisión."
              }
            >
              Consultamos el resultado cada 5 segundos; no necesitas recargar.
            </Alerta>
          )}
          {demorado ? (
            <div>
              <Boton jerarquia="secundario" onClick={reconsultar}>
                Consultar de nuevo
              </Boton>
            </div>
          ) : (
            <BarraDeProgreso
              valor={(consultas / MAX_CONSULTAS) * 100}
              etiqueta="Tiempo de espera de la revisión"
            />
          )}
          <CargadorDeArchivos
            onArchivos={() => {}}
            multiple={false}
            deshabilitado
            titulo="Ya tienes un documento en revisión"
            ayuda="La carga se habilita cuando termine la revisión."
          />
        </>
      )}

      {!sesionVencida && puedeEnviar && (
        <>
          <CargadorDeArchivos
            onArchivos={elegirArchivos}
            multiple={false}
            accept="image/jpeg,image/png,application/pdf"
            deshabilitado={enviando}
            titulo="Arrastra tu documento o haz clic para seleccionarlo"
            ayuda={`JPG, PNG o PDF, máximo 5 MB`}
            error={errorArchivo}
          />
          {archivo && !enviando && (
            <p className="texto-cuerpo-pequeno flex items-center gap-espacio-2 text-texto-primario">
              <Icono nombre="documento" tamano={20} className="shrink-0 text-texto-acento" />
              <span className="min-w-0 break-all">
                {archivo.name} · {formatearTamano(archivo.size)}
              </span>
            </p>
          )}
          {enviando && archivo && (
            <>
              <p role="status" className="texto-cuerpo-pequeno break-all text-texto-primario">
                Subiendo {archivo.name}… {progreso}%
              </p>
              <BarraDeProgreso valor={progreso} etiqueta="Subiendo documento" />
            </>
          )}
          {errorEnvio && <Alerta tono="error">{errorEnvio}</Alerta>}
          <Boton
            icono="documento"
            cargando={enviando}
            disabled={!archivo}
            onClick={enviar}
            className="w-full"
          >
            {estado === "RECHAZADO" ? "Enviar documento nuevo" : "Enviar documento"}
          </Boton>
        </>
      )}
    </section>
  );
}
