import { Contenedor } from "@/components/ui";
import { EsqueletoDeNotificaciones } from "./centro-de-notificaciones";

/** Mientras se consulta la sesión: el esqueleto de Figma (33:760). */
export default function Cargando() {
  return (
    <main className="flex-1">
      <Contenedor className="flex flex-col gap-espacio-4 pt-espacio-5 pb-espacio-7 md:gap-espacio-5 md:pt-espacio-7 md:pb-espacio-9">
        <h1 className="texto-h1 text-texto-primario">Notificaciones</h1>
        <div className="w-full lg:max-w-220">
          <EsqueletoDeNotificaciones />
        </div>
      </Contenedor>
    </main>
  );
}
