import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { cerrarSesion } from "@/app/actions/auth";
import { Contenedor, NavegacionSuperior, PieDePagina } from "@/components/ui";
import { obtenerUsuarioActual } from "@/lib/usuario-actual";
import { CentroDeNotificaciones } from "./centro-de-notificaciones";

export const metadata: Metadata = { title: "Notificaciones · Arre" };

/**
 * FE-21.1: centro de notificaciones de arrendadores y arrendatarios. Sin
 * sesión, el proxy lleva a /login; con la sesión rechazada por el backend
 * (401), se pasa por /sesion-vencida, que borra las cookies.
 *
 * La lista se carga en el navegador a través de `/api/notificaciones`, con la
 * misma consulta que el contador global de la campana.
 */
export default async function NotificacionesPage() {
  const sesion = await obtenerUsuarioActual();
  if (sesion.estado === "sin-sesion") redirect("/sesion-vencida");
  // El backend no respondió: lo muestra error.tsx con «Reintentar».
  if (sesion.estado === "error") throw new Error("No se pudo consultar la sesión.");
  const { usuario } = sesion;

  return (
    <>
      <NavegacionSuperior
        rol={usuario.rol === "ARRENDADOR" ? "arrendador" : "arrendatario"}
        nombreUsuario={usuario.nombreUsuario}
        onCerrarSesion={cerrarSesion}
      />
      <main className="flex-1">
        <Contenedor className="pt-espacio-5 pb-espacio-7 md:pt-espacio-7 md:pb-espacio-9">
          <CentroDeNotificaciones clave={usuario.nombreUsuario} />
        </Contenedor>
      </main>
      <PieDePagina />
    </>
  );
}
