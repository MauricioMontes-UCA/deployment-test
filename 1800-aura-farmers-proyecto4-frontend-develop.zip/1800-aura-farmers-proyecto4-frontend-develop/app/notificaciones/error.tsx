"use client"; // Los error boundaries son componentes de cliente.

import { Boton, Contenedor, EstadoDePagina } from "@/components/ui";
import { MENSAJES_NOTIFICACIONES as TEXTOS } from "@/lib/notificaciones/reglas";

/** El backend no respondió al consultar la sesión. */
export default function ErrorAlCargar({ retry }: { error: Error & { digest?: string }; retry: () => void }) {
  return (
    <main className="flex-1">
      <Contenedor className="pt-espacio-5 pb-espacio-7 md:pt-espacio-7 md:pb-espacio-9">
        <EstadoDePagina
          tipo="error"
          titulo={TEXTOS.errorCarga}
          mensaje={TEXTOS.errorCargaDetalle}
          accion={
            <Boton jerarquia="secundario" onClick={() => retry()}>
              Reintentar
            </Boton>
          }
        />
      </Contenedor>
    </main>
  );
}
