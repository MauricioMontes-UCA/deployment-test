import { act, render, screen, waitFor, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, beforeEach, describe, expect, it, vi, type MockInstance } from "vitest";
import { reiniciarContador, useNoLeidas } from "@/lib/notificaciones/contador";
import type { NotificacionApi } from "@/lib/notificaciones/reglas";
import { CentroDeNotificaciones } from "../centro-de-notificaciones";

const { irASesionVencida } = vi.hoisted(() => ({ irASesionVencida: vi.fn() }));
vi.mock("@/lib/reportes/sesion-vencida", () => ({ irASesionVencida }));

const idDe = (n: number) => `a1b2c3d4-0000-4000-8000-${String(n).padStart(12, "0")}`;
const aviso = (n: number, cambios: Partial<NotificacionApi> = {}): NotificacionApi => ({
  id: idDe(n),
  titulo: `Aviso ${n}`,
  mensaje: `Mensaje del aviso ${n}.`,
  estado: "NO_LEIDA",
  moduloOrigen: "RESERVAS",
  // Del más reciente (1) al más antiguo, como los devuelve el backend.
  creadaEn: new Date(Date.UTC(2026, 10, 18, 20, 32) - n * 60_000).toISOString(),
  ...cambios,
});
const json = (status: number, cuerpo: unknown = {}) =>
  new Response(JSON.stringify(cuerpo), { status, headers: { "Content-Type": "application/json" } });
const pagina = (n: number, notificaciones: NotificacionApi[], total: number, noLeidas = 3) =>
  json(200, { noLeidas, total, pagina: n, tamanoPagina: 20, notificaciones });

type Respuesta = Response | Promise<Response> | (() => Response | Promise<Response>);
let paginas: Record<number, Respuesta>;
let marcar: Record<string, Respuesta>;
const fetchSimulado = vi.fn(async (url: string, init?: RequestInit) => {
  const responder = async (r: Respuesta | undefined) => (typeof r === "function" ? r() : r) ?? json(500);
  const patch = /^\/api\/notificaciones\/([^/]+)\/leida$/.exec(url);
  if (patch && init?.method === "PATCH") return responder(marcar[decodeURIComponent(patch[1])]);
  const get = /^\/api\/notificaciones\?pagina=(\d+)$/.exec(url);
  if (get) return responder(paginas[Number(get[1])]);
  throw new Error(`URL inesperada: ${url}`);
});
const llamadas = (filtro: RegExp, metodo = "GET") =>
  fetchSimulado.mock.calls.filter(([url, init]) => filtro.test(url) && (init?.method ?? "GET") === metodo).length;

/** El contador como lo ve la campana, para comprobar que queda sincronizado. */
function Campana() {
  const n = useNoLeidas("ana_m");
  return <p data-testid="campana">{n ?? "—"}</p>;
}
function renderizar() {
  return render(
    <>
      <Campana />
      <CentroDeNotificaciones clave="ana_m" />
    </>,
  );
}
const lista = () => screen.getByRole("list", { name: "Notificaciones" });
const titulos = () => within(lista()).getAllByText(/^Aviso \d+$/).map((nodo) => nodo.textContent);

let errorDeConsola: MockInstance<typeof console.error>;
beforeEach(() => {
  reiniciarContador();
  irASesionVencida.mockReset();
  fetchSimulado.mockClear();
  paginas = { 1: () => pagina(1, [aviso(1), aviso(2), aviso(3, { estado: "LEIDA", moduloOrigen: "PAGOS" })], 3) };
  marcar = {};
  vi.stubGlobal("fetch", fetchSimulado);
  errorDeConsola = vi.spyOn(console, "error");
});
afterEach(() => {
  vi.unstubAllGlobals();
  expect(errorDeConsola).not.toHaveBeenCalled();
  errorDeConsola.mockRestore();
});

describe("CentroDeNotificaciones", () => {
  describe("carga", () => {
    it("muestra el esqueleto de carga y luego la lista, con una sola consulta compartida con la campana", async () => {
      renderizar();
      expect(screen.getByRole("status", { name: "Cargando notificaciones" })).toBeInTheDocument();
      await screen.findByRole("list", { name: "Notificaciones" });
      expect(llamadas(/pagina=1$/)).toBe(1);
      expect(screen.getByTestId("campana")).toHaveTextContent("3");
      expect(screen.getByText("3 sin leer")).toBeInTheDocument();
    });

    it("en el orden del backend (más reciente primero), con módulo, fecha dd/mm/aaaa hh:mm y estado", async () => {
      renderizar();
      await screen.findByRole("list", { name: "Notificaciones" });
      expect(titulos()).toEqual(["Aviso 1", "Aviso 2", "Aviso 3"]);
      const primero = screen.getByRole("button", { name: /Aviso 1/ });
      expect(primero).toHaveTextContent("Reservas");
      expect(primero).toHaveTextContent("18/11/2026 14:31");
      expect(primero).toHaveTextContent("No leída");
      const leido = within(lista()).getByText("Aviso 3").closest("article")!;
      expect(leido).toHaveTextContent("Pagos");
      expect(leido).toHaveTextContent("Leída");
    });

    it("vacío: «No tienes notificaciones.» y el contador real", async () => {
      paginas[1] = () => pagina(1, [], 0, 0);
      renderizar();
      expect(await screen.findByRole("heading", { name: "No tienes notificaciones." })).toBeInTheDocument();
      expect(screen.getByText("Aquí verás los avisos de reservas, pagos, depósitos, mensajes y verificación.")).toBeInTheDocument();
      expect(screen.getByText("0 sin leer")).toBeInTheDocument();
      expect(screen.queryByRole("button", { name: "Cargar más" })).not.toBeInTheDocument();
    });

    it("error al cargar: mensaje de Figma y «Reintentar» vuelve a consultar", async () => {
      paginas[1] = () => json(500);
      renderizar();
      expect(await screen.findByRole("heading", { name: "No pudimos cargar tus notificaciones. Intenta de nuevo." })).toBeInTheDocument();
      expect(screen.getByText("Revisa tu conexión.")).toBeInTheDocument();
      paginas[1] = () => pagina(1, [aviso(1)], 1, 1);
      await userEvent.click(screen.getByRole("button", { name: "Reintentar" }));
      await screen.findByRole("list", { name: "Notificaciones" });
      expect(titulos()).toEqual(["Aviso 1"]);
    });

    it("401 al cargar → /sesion-vencida", async () => {
      paginas[1] = () => json(401);
      renderizar();
      await waitFor(() => expect(irASesionVencida).toHaveBeenCalledOnce());
    });
  });

  describe("paginación", () => {
    const veinte = Array.from({ length: 20 }, (_, i) => aviso(i + 1));

    it("con más de 20, «Cargar más» agrega la página siguiente sin repetir avisos", async () => {
      paginas[1] = () => pagina(1, veinte, 25);
      // La página 2 llega corrida una posición (un aviso nuevo entre consultas): repite el 20.
      paginas[2] = () => pagina(2, [aviso(20), ...Array.from({ length: 5 }, (_, i) => aviso(21 + i))], 26);
      renderizar();
      await screen.findByRole("list", { name: "Notificaciones" });
      expect(titulos()).toHaveLength(20);
      await userEvent.click(screen.getByRole("button", { name: "Cargar más" }));
      await waitFor(() => expect(titulos()).toHaveLength(25));
      expect(new Set(titulos()).size).toBe(25);
      expect(titulos()[24]).toBe("Aviso 25");
      expect(llamadas(/pagina=2$/)).toBe(1);
    });

    it("con exactamente 20 no hay «Cargar más»; con 40 desaparece tras la segunda página", async () => {
      paginas[1] = () => pagina(1, veinte, 20);
      const { unmount } = renderizar();
      await screen.findByRole("list", { name: "Notificaciones" });
      expect(screen.queryByRole("button", { name: "Cargar más" })).not.toBeInTheDocument();
      unmount();

      reiniciarContador();
      paginas[1] = () => pagina(1, veinte, 40);
      paginas[2] = () => pagina(2, Array.from({ length: 20 }, (_, i) => aviso(21 + i)), 40);
      renderizar();
      await screen.findByRole("list", { name: "Notificaciones" });
      await userEvent.click(screen.getByRole("button", { name: "Cargar más" }));
      await waitFor(() => expect(titulos()).toHaveLength(40));
      expect(screen.queryByRole("button", { name: "Cargar más" })).not.toBeInTheDocument();
    });

    it("si «Cargar más» falla, avisa y conserva la lista", async () => {
      paginas[1] = () => pagina(1, veinte, 25);
      paginas[2] = () => json(500);
      renderizar();
      await screen.findByRole("list", { name: "Notificaciones" });
      await userEvent.click(screen.getByRole("button", { name: "Cargar más" }));
      expect(await screen.findByRole("alert")).toHaveTextContent("No pudimos cargar tus notificaciones. Intenta de nuevo.");
      expect(titulos()).toHaveLength(20);
    });

    it("«Actualizar» vuelve a la página 1 y al contador", async () => {
      paginas[1] = () => pagina(1, veinte, 25);
      paginas[2] = () => pagina(2, Array.from({ length: 5 }, (_, i) => aviso(21 + i)), 25);
      renderizar();
      await screen.findByRole("list", { name: "Notificaciones" });
      await userEvent.click(screen.getByRole("button", { name: "Cargar más" }));
      await waitFor(() => expect(titulos()).toHaveLength(25));

      paginas[1] = () => pagina(1, [aviso(0), ...veinte.slice(0, 19)], 26, 4);
      await userEvent.click(screen.getByRole("button", { name: "Actualizar" }));
      await waitFor(() => expect(titulos()[0]).toBe("Aviso 0"));
      expect(titulos()).toHaveLength(20);
      expect(screen.getByText("4 sin leer")).toBeInTheDocument();
      expect(screen.getByTestId("campana")).toHaveTextContent("4");
    });

    it("si «Actualizar» falla con la lista visible, avisa y la conserva", async () => {
      renderizar();
      await screen.findByRole("list", { name: "Notificaciones" });
      paginas[1] = () => json(503);
      await userEvent.click(screen.getByRole("button", { name: "Actualizar" }));
      expect(await screen.findByRole("alert")).toHaveTextContent("No pudimos cargar tus notificaciones. Intenta de nuevo.");
      expect(titulos()).toEqual(["Aviso 1", "Aviso 2", "Aviso 3"]);
    });
  });

  describe("marcar como leída", () => {
    it("abrir una «No leída» la marca, el contador baja de 3 a 2 en la pantalla y en la campana, sin navegar", async () => {
      marcar[idDe(1)] = () => json(200, { id: idDe(1), estado: "LEIDA", leidaEn: "2026-11-18T21:00:00.000Z", noLeidas: 2 });
      const antes = window.location.href;
      renderizar();
      await userEvent.click(await screen.findByRole("button", { name: /Aviso 1/ }));

      await waitFor(() => expect(screen.getByText("2 sin leer")).toBeInTheDocument());
      expect(screen.getByTestId("campana")).toHaveTextContent("2");
      const fila = within(lista()).getByText("Aviso 1").closest("li")!;
      expect(within(fila).getByText("Leída")).toBeInTheDocument();
      // Ya leída: deja de ser un botón y el foco pasa a su fila.
      expect(screen.queryByRole("button", { name: /Aviso 1/ })).not.toBeInTheDocument();
      await waitFor(() => expect(fila).toHaveFocus());
      expect(window.location.href).toBe(antes);
      expect(llamadas(/leida$/, "PATCH")).toBe(1);
    });

    it("las ya leídas no se pueden abrir otra vez", async () => {
      renderizar();
      await screen.findByRole("list", { name: "Notificaciones" });
      expect(screen.queryByRole("button", { name: /Aviso 3/ })).not.toBeInTheDocument();
      await userEvent.click(within(lista()).getByText("Aviso 3"));
      expect(llamadas(/leida$/, "PATCH")).toBe(0);
    });

    it("dos clics seguidos sobre la misma: un solo PATCH", async () => {
      let entregar!: (r: Response) => void;
      marcar[idDe(1)] = new Promise<Response>((r) => (entregar = r));
      renderizar();
      const boton = await screen.findByRole("button", { name: /Aviso 1/ });
      await userEvent.click(boton);
      await userEvent.click(boton);
      expect(llamadas(/leida$/, "PATCH")).toBe(1);
      await act(async () => entregar(json(200, { id: idDe(1), estado: "LEIDA", leidaEn: "2026-11-18T21:00:00.000Z", noLeidas: 2 })));
      await waitFor(() => expect(screen.getByText("2 sin leer")).toBeInTheDocument());
    });

    it("404: «No encontramos esa notificación.» y el contador no cambia", async () => {
      marcar[idDe(2)] = () => json(404, { message: "No encontramos esa notificación." });
      renderizar();
      await userEvent.click(await screen.findByRole("button", { name: /Aviso 2/ }));
      expect(await screen.findByRole("alert")).toHaveTextContent(/^No encontramos esa notificación\.$/);
      expect(screen.getByText("3 sin leer")).toBeInTheDocument();
      expect(screen.getByTestId("campana")).toHaveTextContent("3");
      expect(screen.getByRole("button", { name: /Aviso 2/ })).toHaveTextContent("No leída");
      // El aviso queda sobre la lista, como en Figma 33:879.
      expect(screen.getByRole("alert").compareDocumentPosition(lista()) & Node.DOCUMENT_POSITION_FOLLOWING).toBeTruthy();
    });

    it.each([
      ["500", () => json(500)],
      ["red caída", () => Promise.reject(new TypeError("Failed to fetch"))],
    ])("%s al marcar: aviso de error y nada cambia", async (_caso, respuesta) => {
      marcar[idDe(1)] = respuesta;
      renderizar();
      await userEvent.click(await screen.findByRole("button", { name: /Aviso 1/ }));
      expect(await screen.findByRole("alert")).toHaveTextContent("No pudimos marcar la notificación como leída. Intenta de nuevo.");
      expect(screen.getByText("3 sin leer")).toBeInTheDocument();
    });

    it("401 al marcar → /sesion-vencida", async () => {
      marcar[idDe(1)] = () => json(401);
      renderizar();
      await userEvent.click(await screen.findByRole("button", { name: /Aviso 1/ }));
      await waitFor(() => expect(irASesionVencida).toHaveBeenCalledOnce());
    });

    it("un nuevo intento correcto quita el aviso de error anterior", async () => {
      marcar[idDe(2)] = () => json(404);
      marcar[idDe(1)] = () => json(200, { id: idDe(1), estado: "LEIDA", leidaEn: "2026-11-18T21:00:00.000Z", noLeidas: 2 });
      renderizar();
      await userEvent.click(await screen.findByRole("button", { name: /Aviso 2/ }));
      await screen.findByRole("alert");
      await userEvent.click(screen.getByRole("button", { name: /Aviso 1/ }));
      await waitFor(() => expect(screen.queryByRole("alert")).not.toBeInTheDocument());
    });
  });

  describe("accesibilidad y teclado", () => {
    it("encabezado h1, contador anunciado y avisos operables con teclado", async () => {
      marcar[idDe(1)] = () => json(200, { id: idDe(1), estado: "LEIDA", leidaEn: "2026-11-18T21:00:00.000Z", noLeidas: 2 });
      renderizar();
      await screen.findByRole("list", { name: "Notificaciones" });
      expect(screen.getByRole("heading", { level: 1, name: "Notificaciones" })).toBeInTheDocument();
      expect(screen.getByText("3 sin leer")).toHaveAttribute("aria-live", "polite");
      // Tab: «Actualizar» → primer aviso no leído.
      await userEvent.tab();
      expect(screen.getByRole("button", { name: "Actualizar" })).toHaveFocus();
      await userEvent.tab();
      expect(screen.getByRole("button", { name: /Aviso 1/ })).toHaveFocus();
      await userEvent.keyboard("{Enter}");
      await waitFor(() => expect(screen.getByText("2 sin leer")).toBeInTheDocument());
    });
  });
});
