import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, describe, expect, it, vi } from "vitest";
import type { ResultadoUsuario } from "@/lib/usuario-actual";

const sesion = vi.hoisted(() => ({ obtenerUsuarioActual: vi.fn() }));
vi.mock("@/lib/usuario-actual", () => sesion);
const auth = vi.hoisted(() => ({ cerrarSesion: vi.fn() }));
vi.mock("@/app/actions/auth", () => auth);
vi.mock("next/navigation", async (original) => ({
  ...(await original<typeof import("next/navigation")>()),
  usePathname: () => "/notificaciones",
  redirect: vi.fn((url: string) => {
    throw new Error(`REDIRECT:${url}`);
  }),
}));
// La pantalla en sí se prueba aparte; aquí basta con saber qué usuario recibe.
vi.mock("../centro-de-notificaciones", () => ({
  CentroDeNotificaciones: ({ clave }: { clave: string }) => <p>Centro de {clave}</p>,
  EsqueletoDeNotificaciones: () => <div role="status" aria-label="Cargando notificaciones" />,
}));

const { default: NotificacionesPage } = await import("../page");
const { default: ErrorAlCargar } = await import("../error");
const { default: Cargando } = await import("../loading");

const usuario = (rol: "ARRENDADOR" | "ARRENDATARIO"): ResultadoUsuario => ({
  estado: "ok",
  usuario: { id: "u1", nombreUsuario: "ana_m", email: "ana@example.com", rol, createdAt: "2026-01-01T00:00:00.000Z" },
});

afterEach(() => vi.clearAllMocks());

describe("/notificaciones", () => {
  it.each([
    ["ARRENDATARIO", "Arrendatario"],
    ["ARRENDADOR", "Arrendador"],
  ] as const)("%s: barra con su rol, campana como página actual y el centro con su usuario", async (rol, texto) => {
    sesion.obtenerUsuarioActual.mockResolvedValue(usuario(rol));
    render(await NotificacionesPage());
    expect(screen.getByText("Centro de ana_m")).toBeInTheDocument();
    expect(screen.getAllByText(texto).length).toBeGreaterThan(0);
    // La campana (el pie de página también enlaza a /notificaciones, sin marcarse).
    const campana = screen.getByRole("link", { name: /^Notificaciones/, current: "page" });
    expect(campana).toHaveAttribute("href", "/notificaciones");
  });

  it("sesión rechazada por el backend → /sesion-vencida", async () => {
    sesion.obtenerUsuarioActual.mockResolvedValue({ estado: "sin-sesion" });
    await expect(NotificacionesPage()).rejects.toThrow("REDIRECT:/sesion-vencida");
  });

  it("backend sin respuesta → error.tsx", async () => {
    sesion.obtenerUsuarioActual.mockResolvedValue({ estado: "error" });
    await expect(NotificacionesPage()).rejects.toThrow("No se pudo consultar la sesión.");
  });

  it("error.tsx: mensaje de Figma y «Reintentar»", async () => {
    const retry = vi.fn();
    render(<ErrorAlCargar error={new Error("x")} retry={retry} />);
    expect(screen.getByRole("alert")).toHaveTextContent("No pudimos cargar tus notificaciones. Intenta de nuevo.");
    await userEvent.click(screen.getByRole("button", { name: "Reintentar" }));
    expect(retry).toHaveBeenCalledOnce();
  });

  it("loading.tsx: título y esqueleto de carga", () => {
    render(<Cargando />);
    expect(screen.getByRole("heading", { level: 1, name: "Notificaciones" })).toBeInTheDocument();
    expect(screen.getByRole("status", { name: "Cargando notificaciones" })).toBeInTheDocument();
  });
});
