"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Alerta, Boton, EncabezadoDePagina, EstadoDePagina, Notificacion } from "@/components/ui";
import { consultarPagina, marcarLeida, type ResultadoListado } from "@/lib/notificaciones/cliente";
import { establecerNoLeidas, refrescarNoLeidas, useNoLeidas } from "@/lib/notificaciones/contador";
import {
  ETIQUETA_MODULO,
  MENSAJES_NOTIFICACIONES as TEXTOS,
  formatearFechaHora,
  hayMasPaginas,
  unirPaginas,
  type NotificacionApi,
} from "@/lib/notificaciones/reglas";
import { irASesionVencida } from "@/lib/reportes/sesion-vencida";

type Fase = "cargando" | "lista" | "error";
type Aviso = "no-encontrada" | "error-marcar" | "error-carga" | null;

const TEXTO_AVISO: Record<Exclude<Aviso, null>, string> = {
  "no-encontrada": TEXTOS.noEncontrada,
  "error-marcar": TEXTOS.errorMarcar,
  "error-carga": TEXTOS.errorCarga,
};

/** Bloques de carga de Figma (33:760): cuatro de 100 px. */
export function EsqueletoDeNotificaciones() {
  return (
    <div role="status" aria-label="Cargando notificaciones" className="flex flex-col gap-espacio-4">
      {[0, 1, 2, 3].map((indice) => (
        <div key={indice} aria-hidden className="h-25 w-full bg-fondo-sutil" />
      ))}
    </div>
  );
}

/**
 * Centro de notificaciones (FE-21.1, Figma 33:1066).
 *
 * - La primera página llega con la misma consulta que el contador global.
 * - «Actualizar» vuelve a la página 1 y al contador; «Cargar más» agrega 20.
 * - Abrir un aviso «No leída» lo marca como leído (BE-21.2) sin navegar, y el
 *   contador toma el valor que devolvió el backend. Un 404 avisa y no cambia el
 *   contador.
 * - Un 401 en cualquier llamada lleva a /sesion-vencida.
 */
export function CentroDeNotificaciones({ clave }: { clave: string }) {
  const noLeidas = useNoLeidas(clave);
  const [fase, setFase] = useState<Fase>("cargando");
  const [avisos, setAvisos] = useState<NotificacionApi[]>([]);
  const [pagina, setPagina] = useState(1);
  const [total, setTotal] = useState(0);
  const [aviso, setAviso] = useState<Aviso>(null);
  const [actualizando, setActualizando] = useState(false);
  const [cargandoMas, setCargandoMas] = useState(false);
  const marcando = useRef(new Set<string>());
  const filas = useRef(new Map<string, HTMLLIElement>());

  /**
   * Aplica la página 1. Devuelve `false` si falló (la pantalla decide cómo
   * mostrarlo) y lleva a /sesion-vencida con un 401.
   */
  const aplicarPrimera = useCallback((resultado: ResultadoListado): boolean => {
    if (resultado.tipo === "sesion") {
      irASesionVencida();
      return true;
    }
    if (resultado.tipo === "error") return false;
    setAvisos(resultado.listado.notificaciones);
    setPagina(1);
    setTotal(resultado.listado.total);
    setFase("lista");
    return true;
  }, []);

  // Página 1 y contador, en una sola consulta compartida con la campana.
  useEffect(() => {
    let vigente = true;
    void refrescarNoLeidas(clave).then((resultado) => {
      if (vigente && !aplicarPrimera(resultado)) setFase("error");
    });
    return () => {
      vigente = false;
    };
  }, [clave, aplicarPrimera]);

  async function reintentar() {
    setFase("cargando");
    if (!aplicarPrimera(await refrescarNoLeidas(clave))) setFase("error");
  }

  async function actualizar() {
    if (actualizando) return;
    setActualizando(true);
    setAviso(null);
    if (!aplicarPrimera(await refrescarNoLeidas(clave))) {
      if (fase === "lista") setAviso("error-carga");
      else setFase("error");
    }
    setActualizando(false);
  }

  async function cargarMas() {
    if (cargandoMas) return;
    setCargandoMas(true);
    setAviso(null);
    const resultado = await consultarPagina(pagina + 1);
    if (resultado.tipo === "sesion") return irASesionVencida();
    if (resultado.tipo === "ok") {
      setAvisos((actuales) => unirPaginas(actuales, resultado.listado.notificaciones));
      setPagina(resultado.listado.pagina);
      setTotal(resultado.listado.total);
    } else {
      setAviso("error-carga");
    }
    setCargandoMas(false);
  }

  async function abrir(id: string) {
    if (marcando.current.has(id)) return;
    marcando.current.add(id);
    setAviso(null);
    const resultado = await marcarLeida(id);
    marcando.current.delete(id);
    if (resultado.tipo === "sesion") return irASesionVencida();
    if (resultado.tipo === "ok") {
      setAvisos((actuales) =>
        actuales.map((actual) => (actual.id === id ? { ...actual, estado: "LEIDA" } : actual)),
      );
      establecerNoLeidas(clave, resultado.marcada.noLeidas);
      // El aviso deja de ser un botón: el foco pasa a su fila para no perderse.
      requestAnimationFrame(() => filas.current.get(id)?.focus());
      return;
    }
    // 404: el aviso no existe o no es del usuario. El contador no cambia.
    setAviso(resultado.tipo === "no-encontrada" ? "no-encontrada" : "error-marcar");
  }

  const encabezado = (
    <div className="flex flex-col gap-espacio-4 md:flex-row md:items-end md:justify-between md:gap-espacio-6">
      {/* Figma: la descripción solo aparece en escritorio (33:2), no en móvil (33:415). */}
      <EncabezadoDePagina
        titulo="Notificaciones"
        descripcion="Los avisos de tus reservas, pagos, mensajes y verificación en un solo lugar."
        className="max-md:[&>p]:hidden md:max-w-205"
      />
      <div className="flex shrink-0 items-center gap-espacio-3">
        {noLeidas !== null && (
          <p aria-live="polite" className="texto-etiqueta whitespace-nowrap text-texto-secundario">
            {noLeidas} sin leer
          </p>
        )}
        <Boton
          jerarquia="secundario"
          icono="actualizar"
          cargando={actualizando}
          disabled={fase === "cargando"}
          onClick={() => void actualizar()}
        >
          Actualizar
        </Boton>
      </div>
    </div>
  );

  let cuerpo;
  if (fase === "cargando") {
    cuerpo = <EsqueletoDeNotificaciones />;
  } else if (fase === "error") {
    cuerpo = (
      <EstadoDePagina
        tipo="error"
        titulo={TEXTOS.errorCarga}
        mensaje={TEXTOS.errorCargaDetalle}
        accion={
          <Boton jerarquia="secundario" onClick={() => void reintentar()}>
            Reintentar
          </Boton>
        }
      />
    );
  } else {
    cuerpo = (
      <div className="flex flex-col gap-espacio-4">
        {aviso && <Alerta tono="error">{TEXTO_AVISO[aviso]}</Alerta>}
        {avisos.length === 0 ? (
          <EstadoDePagina tipo="vacio" titulo={TEXTOS.vacioTitulo} mensaje={TEXTOS.vacioMensaje} />
        ) : (
          <ul aria-label="Notificaciones" className="flex flex-col gap-espacio-3">
            {avisos.map((notificacion) => {
              const leida = notificacion.estado === "LEIDA";
              return (
                <li
                  key={notificacion.id}
                  tabIndex={-1}
                  ref={(fila) => {
                    if (fila) filas.current.set(notificacion.id, fila);
                    else filas.current.delete(notificacion.id);
                  }}
                  className="outline-none focus-visible:outline-2 focus-visible:outline-borde-foco"
                >
                  <Notificacion
                    titulo={notificacion.titulo}
                    mensaje={notificacion.mensaje}
                    modulo={ETIQUETA_MODULO[notificacion.moduloOrigen]}
                    fecha={formatearFechaHora(notificacion.creadaEn)}
                    leida={leida}
                    onAbrir={leida ? undefined : () => void abrir(notificacion.id)}
                  />
                </li>
              );
            })}
          </ul>
        )}
        {hayMasPaginas(pagina, total) && (
          <div className="flex justify-center">
            <Boton jerarquia="secundario" cargando={cargandoMas} onClick={() => void cargarMas()}>
              Cargar más
            </Boton>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-espacio-4 md:gap-espacio-5">
      {encabezado}
      <div className="w-full lg:max-w-220">{cuerpo}</div>
    </div>
  );
}
