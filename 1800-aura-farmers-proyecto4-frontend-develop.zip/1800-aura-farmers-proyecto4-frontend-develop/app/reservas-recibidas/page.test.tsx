import { render, screen } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { usuarioDePrueba } from "@/pruebas/usuario";
import PaginaReservasRecibidas from "./page";

const { obtenerUsuarioActual, redirect } = vi.hoisted(() => ({
  obtenerUsuarioActual: vi.fn(),
  redirect: vi.fn(),
}));
vi.mock("@/lib/usuario-actual", () => ({ obtenerUsuarioActual }));
vi.mock("@/app/actions/auth", () => ({ cerrarSesion: vi.fn() }));
vi.mock("next/navigation", () => ({ usePathname: () => "/reservas-recibidas", redirect }));
vi.stubGlobal("fetch", vi.fn(() => new Promise(() => {})));

beforeEach(() => {
  obtenerUsuarioActual.mockReset();
  redirect.mockReset();
  vi.mocked(fetch).mockClear();
});

describe("/reservas-recibidas", () => {
  it("al arrendatario le muestra «sin permiso» y no llama a la API", async () => {
    obtenerUsuarioActual.mockResolvedValue({ estado: "ok", usuario: usuarioDePrueba({ rol: "ARRENDATARIO" }) });
    render(await PaginaReservasRecibidas());

    expect(screen.getByRole("link", { name: "Ir al inicio" })).toHaveAttribute("href", "/");
    expect(screen.queryByRole("heading", { name: "Reservas recibidas" })).not.toBeInTheDocument();
    expect(fetch).not.toHaveBeenCalled();
  });

  it("al arrendador le monta la lista", async () => {
    obtenerUsuarioActual.mockResolvedValue({ estado: "ok", usuario: usuarioDePrueba({ rol: "ARRENDADOR" }) });
    render(await PaginaReservasRecibidas());

    expect(screen.getByRole("heading", { name: "Reservas recibidas" })).toBeInTheDocument();
    expect(fetch).toHaveBeenCalled();
  });

  it("sin sesión pasa por /sesion-vencida", async () => {
    obtenerUsuarioActual.mockResolvedValue({ estado: "sin-sesion" });
    redirect.mockImplementation(() => {
      throw new Error("NEXT_REDIRECT");
    });
    await expect(PaginaReservasRecibidas()).rejects.toThrow("NEXT_REDIRECT");
    expect(redirect).toHaveBeenCalledWith("/sesion-vencida");
  });
});
