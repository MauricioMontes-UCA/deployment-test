import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, describe, expect, it, vi } from "vitest";
import type { ReservaRecibida } from "@/lib/reservas/recibidas";
import { ReservasRecibidas } from "./reservas-recibidas";

vi.mock("@/app/actions/auth", () => ({ cerrarSesion: vi.fn() }));
vi.mock("next/navigation", () => ({ usePathname: () => "/reservas-recibidas" }));

function reserva(id: string, cambios: Partial<ReservaRecibida> = {}): ReservaRecibida {
  return {
    id,
    bienId: "b1",
    arrendatarioId: "u1",
    fechaInicio: "2026-11-20",
    fechaFin: "2026-11-22",
    estado: "EN_COLA",
    motivoResolucion: null,
    creadaEn: "2026-11-01T00:00:00.000Z",
    procesadaEn: null,
    bien: { id: "b1", titulo: `Salón ${id}`, fotoPrincipalUrl: null },
    arrendatario: { id: "u1", nombreUsuario: "ana_m" },
    pago: null,
    deposito: null,
    ...cambios,
  };
}

function pagina(items: ReservaRecibida[], extra: Partial<{ pagina: number; total: number; hayMas: boolean }> = {}) {
  return { items, pagina: 1, total: items.length, hayMas: false, ...extra };
}

function json(cuerpo: unknown, status = 200) {
  return Promise.resolve(new Response(JSON.stringify(cuerpo), { status }));
}

afterEach(() => vi.unstubAllGlobals());

describe("ReservasRecibidas", () => {
  it("muestra arrendatario, estado, pago, depósito y enlaza al detalle", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn(() =>
        json(
          pagina([
            reserva("1", {
              estado: "CONFIRMADA",
              pago: { id: "p1", estado: "SIMULADO_EXITOSO", total: 75 },
              deposito: { estado: "PENDIENTE", importeOriginal: 100 },
            }),
            reserva("2", { estado: "RECHAZADA", motivoResolucion: "FECHAS_NO_DISPONIBLES" }),
          ]),
        ),
      ),
    );
    render(<ReservasRecibidas nombreUsuario="carlos" />);

    expect(await screen.findByText("Salón 1")).toBeInTheDocument();
    expect(screen.getAllByText("Arrendatario: ana_m")).toHaveLength(2);
    expect(screen.getByText("Pago: $75.00 (pagado) · Depósito: $100.00 (pendiente)")).toBeInTheDocument();
    expect(screen.getByText("Motivo: fechas no disponibles")).toBeInTheDocument();
    const enlaces = screen.getAllByRole("link", { name: "Gestionar" });
    expect(enlaces[0]).toHaveAttribute("href", "/reservas/1");
    expect(screen.getByText("No hay más reservas.")).toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "Cargar más" })).not.toBeInTheDocument();
  });

  it("el filtro por estado vuelve a pedir la lista", async () => {
    const fetchSimulado = vi.fn((url: string) =>
      json(url.includes("estado=CONFIRMADA") ? pagina([reserva("9", { estado: "CONFIRMADA" })]) : pagina([reserva("1")])),
    );
    vi.stubGlobal("fetch", fetchSimulado);
    render(<ReservasRecibidas />);
    await screen.findByText("Salón 1");

    await userEvent.click(screen.getByRole("tab", { name: "Confirmadas" }));

    expect(await screen.findByText("Salón 9")).toBeInTheDocument();
    expect(screen.queryByText("Salón 1")).not.toBeInTheDocument();
    expect(fetchSimulado.mock.calls.at(-1)?.[0]).toBe("/api/reservas/recibidas?pagina=1&estado=CONFIRMADA");
  });

  it("no ofrece Canceladas como filtro", async () => {
    vi.stubGlobal("fetch", vi.fn(() => json(pagina([reserva("1")]))));
    render(<ReservasRecibidas />);
    await screen.findByText("Salón 1");
    expect(screen.queryByRole("tab", { name: "Canceladas" })).not.toBeInTheDocument();
  });

  it("carga la siguiente página de 20 en 20 y avisa cuando no hay más", async () => {
    const fetchSimulado = vi.fn((url: string) =>
      url.includes("pagina=2")
        ? json(pagina([reserva("21")], { pagina: 2, total: 21, hayMas: false }))
        : json(pagina([reserva("1")], { pagina: 1, total: 21, hayMas: true })),
    );
    vi.stubGlobal("fetch", fetchSimulado);
    render(<ReservasRecibidas />);
    await screen.findByText("Salón 1");
    expect(screen.getByText("21 reservas")).toBeInTheDocument();

    await userEvent.click(screen.getByRole("button", { name: "Cargar más" }));

    expect(await screen.findByText("Salón 21")).toBeInTheDocument();
    expect(screen.getByText("Salón 1")).toBeInTheDocument();
    expect(fetchSimulado.mock.calls.at(-1)?.[0]).toBe("/api/reservas/recibidas?pagina=2");
    expect(screen.getByText("No hay más reservas.")).toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "Cargar más" })).not.toBeInTheDocument();
  });

  it("si falla cargar más conserva la lista y deja reintentar", async () => {
    let fallar = true;
    vi.stubGlobal(
      "fetch",
      vi.fn((url: string) => {
        if (!url.includes("pagina=2")) return json(pagina([reserva("1")], { total: 21, hayMas: true }));
        if (fallar) return json({}, 500);
        return json(pagina([reserva("21")], { pagina: 2, total: 21 }));
      }),
    );
    render(<ReservasRecibidas />);
    await screen.findByText("Salón 1");

    await userEvent.click(screen.getByRole("button", { name: "Cargar más" }));
    expect(await screen.findByRole("alert")).toHaveTextContent("No pudimos cargar más reservas");
    expect(screen.getByText("Salón 1")).toBeInTheDocument();

    fallar = false;
    await userEvent.click(screen.getByRole("button", { name: "Cargar más" }));
    expect(await screen.findByText("Salón 21")).toBeInTheDocument();
    expect(screen.queryByRole("alert")).not.toBeInTheDocument();
  });

  it("muestra el estado de carga, el vacío y el error con reintento", async () => {
    let respuestas = [json({}, 500), json(pagina([]))];
    vi.stubGlobal("fetch", vi.fn(() => respuestas.shift()!));
    render(<ReservasRecibidas />);

    expect(screen.getByRole("status", { name: "Cargando reservas" })).toBeInTheDocument();
    await userEvent.click(await screen.findByRole("button", { name: "Reintentar" }));
    expect(await screen.findByText("Aún no recibes reservas")).toBeInTheDocument();
    respuestas = [];
  });

  it("con 401 muestra que la sesión venció", async () => {
    vi.stubGlobal("fetch", vi.fn(() => json({}, 401)));
    render(<ReservasRecibidas />);
    expect(await screen.findByText("Tu sesión venció")).toBeInTheDocument();
    await waitFor(() => expect(screen.getByRole("button", { name: "Iniciar sesión" })).toBeInTheDocument());
  });
});
