"use client";

import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { cerrarSesion } from "@/app/actions/auth";
import {
  Boton,
  Contenedor,
  EncabezadoDePagina,
  EstadoDePagina,
  NavegacionSuperior,
  PieDePagina,
  Pestana,
  Pestanas,
  TarjetaDeReserva,
  clasesBoton,
} from "@/components/ui";
import { ESTADO_VISUAL, formatearFechas, textoMotivo } from "@/lib/reservas/formato";
import {
  FILTROS_RECIBIDAS,
  textoPagoYDeposito,
  type EstadoFiltroRecibidas,
  type PaginaRecibidas,
  type ReservaRecibida,
} from "@/lib/reservas/recibidas";

type Filtro = EstadoFiltroRecibidas | "TODAS";
type Carga =
  | { tipo: "cargando" }
  | { tipo: "listo"; reservas: ReservaRecibida[]; pagina: number; total: number; hayMas: boolean }
  | { tipo: "sesion" }
  | { tipo: "error" };

function Esqueleto() {
  return (
    <div role="status" aria-label="Cargando reservas" className="flex flex-col gap-espacio-4">
      {[0, 1, 2].map((n) => (
        <div key={n} className="h-[122px] animate-pulse border border-borde-sutil bg-fondo-sutil" />
      ))}
    </div>
  );
}

function url(filtro: Filtro, pagina: number) {
  const consulta = new URLSearchParams({ pagina: String(pagina) });
  if (filtro !== "TODAS") consulta.set("estado", filtro);
  return `/api/reservas/recibidas?${consulta}`;
}

export function ReservasRecibidas({ nombreUsuario }: { nombreUsuario?: string }) {
  const [filtro, setFiltro] = useState<Filtro>("TODAS");
  const [carga, setCarga] = useState<Carga>({ tipo: "cargando" });
  const [intento, setIntento] = useState(0);
  const [cargandoMas, setCargandoMas] = useState(false);
  const [errorMas, setErrorMas] = useState(false);
  const filtroVigente = useRef<Filtro>("TODAS");

  // Primera página del filtro actual.
  useEffect(() => {
    filtroVigente.current = filtro;
    const control = new AbortController();
    fetch(url(filtro, 1), { signal: control.signal, cache: "no-store" })
      .then(async (respuesta) => {
        if (respuesta.status === 401) return setCarga({ tipo: "sesion" });
        if (!respuesta.ok) return setCarga({ tipo: "error" });
        const datos: PaginaRecibidas = await respuesta.json();
        setCarga({
          tipo: "listo",
          reservas: datos.items,
          pagina: datos.pagina,
          total: datos.total,
          hayMas: datos.hayMas,
        });
      })
      .catch((error) => {
        if (error?.name !== "AbortError") setCarga({ tipo: "error" });
      });
    return () => control.abort();
  }, [filtro, intento]);

  function cambiarFiltro(nuevo: Filtro) {
    if (nuevo === filtro) return;
    setCarga({ tipo: "cargando" });
    setErrorMas(false);
    setFiltro(nuevo);
  }

  function reintentar() {
    setCarga({ tipo: "cargando" });
    setIntento((n) => n + 1);
  }

  async function cargarMas() {
    if (carga.tipo !== "listo" || cargandoMas) return;
    const filtroPedido = filtro;
    setCargandoMas(true);
    setErrorMas(false);
    try {
      const respuesta = await fetch(url(filtroPedido, carga.pagina + 1), { cache: "no-store" });
      if (respuesta.status === 401) return setCarga({ tipo: "sesion" });
      if (!respuesta.ok) return setErrorMas(true);
      const datos: PaginaRecibidas = await respuesta.json();
      // Si cambió el filtro mientras tanto, esta página ya no corresponde.
      if (filtroVigente.current !== filtroPedido) return;
      setCarga((actual) =>
        actual.tipo === "listo"
          ? {
              tipo: "listo",
              reservas: [...actual.reservas, ...datos.items],
              pagina: datos.pagina,
              total: datos.total,
              hayMas: datos.hayMas,
            }
          : actual,
      );
    } catch {
      setErrorMas(true);
    } finally {
      setCargandoMas(false);
    }
  }

  return (
    <>
      <NavegacionSuperior
        rol="arrendador"
        nombreUsuario={nombreUsuario}
        onCerrarSesion={() => void cerrarSesion()}
      />
      <main className="flex-1">
        <Contenedor className="flex flex-col gap-espacio-5 pt-espacio-5 pb-espacio-8 md:pt-espacio-7 md:pb-espacio-9">
          <EncabezadoDePagina
            sobretitulo="Arrendador"
            titulo="Reservas recibidas"
            descripcion="Las solicitudes y reservas de tus bienes. Abre cada una para gestionarla."
          />
          <Pestanas etiqueta="Filtrar por estado">
            {FILTROS_RECIBIDAS.map(({ valor, texto }) => (
              <Pestana key={valor} activa={filtro === valor} onClick={() => cambiarFiltro(valor)}>
                {texto}
              </Pestana>
            ))}
          </Pestanas>

          {carga.tipo === "cargando" && <Esqueleto />}

          {carga.tipo === "error" && (
            <EstadoDePagina
              tipo="error"
              accion={
                <Boton jerarquia="secundario" onClick={reintentar}>
                  Reintentar
                </Boton>
              }
            />
          )}

          {carga.tipo === "sesion" && (
            <EstadoDePagina
              tipo="error"
              titulo="Tu sesión venció"
              mensaje="Inicia sesión de nuevo para ver tus reservas recibidas."
              accion={
                <form action={cerrarSesion}>
                  <Boton type="submit">Iniciar sesión</Boton>
                </form>
              }
            />
          )}

          {carga.tipo === "listo" && carga.reservas.length === 0 && (
            <EstadoDePagina
              tipo="vacio"
              titulo={filtro === "TODAS" ? "Aún no recibes reservas" : "No hay reservas con este estado"}
              mensaje={
                filtro === "TODAS"
                  ? "Cuando alguien solicite uno de tus bienes, lo verás aquí."
                  : "Prueba con otro filtro para ver tus demás reservas."
              }
            />
          )}

          {carga.tipo === "listo" && carga.reservas.length > 0 && (
            <>
              <p aria-live="polite" className="texto-etiqueta text-texto-secundario">
                {carga.total} {carga.total === 1 ? "reserva" : "reservas"}
              </p>
              <div className="flex flex-col gap-espacio-4">
                {carga.reservas.map((reserva) => (
                  <TarjetaDeReserva
                    key={reserva.id}
                    titulo={reserva.bien?.titulo ?? "Bien no disponible"}
                    foto={reserva.bien?.fotoPrincipalUrl}
                    fechas={formatearFechas(reserva.fechaInicio, reserva.fechaFin)}
                    participante={
                      reserva.arrendatario
                        ? `Arrendatario: ${reserva.arrendatario.nombreUsuario}`
                        : "Arrendatario no disponible"
                    }
                    estado={ESTADO_VISUAL[reserva.estado]}
                    motivoRechazo={textoMotivo(reserva.motivoResolucion)}
                    detalle={textoPagoYDeposito(reserva.pago, reserva.deposito)}
                    accion={
                      <Link
                        href={`/reservas/${reserva.id}`}
                        className={clasesBoton({ jerarquia: "terciario" })}
                      >
                        Gestionar
                      </Link>
                    }
                  />
                ))}
              </div>

              {errorMas && (
                <p role="alert" className="texto-cuerpo-pequeno text-texto-error">
                  No pudimos cargar más reservas. Intenta de nuevo.
                </p>
              )}
              {carga.hayMas ? (
                <div className="flex justify-center">
                  <Boton jerarquia="secundario" onClick={() => void cargarMas()} disabled={cargandoMas}>
                    {cargandoMas ? "Cargando…" : "Cargar más"}
                  </Boton>
                </div>
              ) : (
                <p className="texto-cuerpo-pequeno text-center text-texto-secundario">
                  No hay más reservas.
                </p>
              )}
            </>
          )}
        </Contenedor>
      </main>
      <PieDePagina />
    </>
  );
}
