import type { Metadata } from "next";
import { SeccionCalificaciones } from "@/components/reportes/seccion-calificaciones";

export const metadata: Metadata = {
  title: "Calificaciones · Panel de reportes · Arre",
};

export default function ReportesCalificaciones() {
  return <SeccionCalificaciones />;
}
