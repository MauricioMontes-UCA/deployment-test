import type { Metadata } from "next";
import { SeccionOcupacion } from "@/components/reportes/seccion-ocupacion";

export const metadata: Metadata = {
  title: "Ocupación · Panel de reportes · Arre",
};

export default function ReportesOcupacion() {
  return <SeccionOcupacion />;
}
