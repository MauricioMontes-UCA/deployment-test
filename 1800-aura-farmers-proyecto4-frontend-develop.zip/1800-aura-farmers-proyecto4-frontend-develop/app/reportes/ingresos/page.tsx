import type { Metadata } from "next";
import { SeccionIngresos } from "@/components/reportes/seccion-ingresos";

export const metadata: Metadata = {
  title: "Ingresos · Panel de reportes · Arre",
};

export default function ReportesIngresos() {
  return <SeccionIngresos />;
}
