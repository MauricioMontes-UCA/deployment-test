import { render, screen } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";
import LayoutReportes from "@/app/reportes/layout";
import { usuarioDePrueba } from "@/pruebas/usuario";
import { obtenerUsuarioActual, type ResultadoUsuario } from "@/lib/usuario-actual";

const { redirect } = vi.hoisted(() => ({
  // redirect de Next lanza para cortar el render; se imita igual.
  redirect: vi.fn((url: string) => {
    throw new Error(`REDIRECT:${url}`);
  }),
}));

vi.mock("next/navigation", () => ({
  redirect,
  usePathname: () => "/reportes/ingresos",
  useRouter: () => ({ push: vi.fn() }),
}));
vi.mock("@/app/actions/auth", () => ({ cerrarSesion: vi.fn() }));
vi.mock("@/lib/usuario-actual", () => ({ obtenerUsuarioActual: vi.fn() }));

function sesionDe(resultado: ResultadoUsuario) {
  vi.mocked(obtenerUsuarioActual).mockResolvedValue(resultado);
}

async function montar() {
  const seccion = <p>Contenido de la sección</p>;
  render(await LayoutReportes({ children: seccion, params: Promise.resolve({}) }));
}

const fetchSimulado = vi.fn();

beforeEach(() => {
  fetchSimulado.mockReset();
  vi.stubGlobal("fetch", fetchSimulado);
});

describe("Layout de /reportes", () => {
  it("el ARRENDADOR ve el panel con el selector, las pestañas y la sección", async () => {
    sesionDe({ estado: "ok", usuario: usuarioDePrueba({ nombreUsuario: "mariana_rivas", rol: "ARRENDADOR" }) });
    await montar();

    expect(screen.getByRole("heading", { level: 1, name: "Panel de reportes" })).toBeInTheDocument();
    expect(screen.getByRole("combobox", { name: "Periodo" })).toBeInTheDocument();
    expect(screen.getAllByRole("tab")).toHaveLength(4);
    expect(screen.getByText("Contenido de la sección")).toBeInTheDocument();
  });

  it("el ARRENDATARIO ve «No tienes acceso a este panel.» y no se llama a /reportes", async () => {
    sesionDe({ estado: "ok", usuario: usuarioDePrueba() });
    await montar();

    expect(screen.getByRole("heading", { name: "No tienes acceso a este panel." })).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "Ir al inicio" })).toHaveAttribute("href", "/");
    // Ni el selector ni la sección se montan, así que nada puede consultar un reporte.
    expect(screen.queryByRole("combobox", { name: "Periodo" })).not.toBeInTheDocument();
    expect(screen.queryByText("Contenido de la sección")).not.toBeInTheDocument();
    expect(fetchSimulado).not.toHaveBeenCalled();
  });

  it("sin sesión o con sesión vencida pasa por /sesion-vencida para borrar la cookie", async () => {
    sesionDe({ estado: "sin-sesion" });
    await expect(montar()).rejects.toThrow("REDIRECT:/sesion-vencida");
  });

  it("si /auth/me falla muestra el error con «Reintentar»", async () => {
    sesionDe({ estado: "error" });
    await montar();

    expect(screen.getByRole("alert")).toHaveTextContent("No pudimos cargar la información");
    expect(screen.getByRole("link", { name: "Reintentar" })).toHaveAttribute("href", "/reportes");
    expect(screen.queryByText("Contenido de la sección")).not.toBeInTheDocument();
  });
});
