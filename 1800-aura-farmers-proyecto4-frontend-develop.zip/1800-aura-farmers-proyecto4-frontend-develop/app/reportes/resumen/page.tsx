import type { Metadata } from "next";
import { SeccionResumen } from "@/components/reportes/seccion-resumen";

export const metadata: Metadata = {
  title: "Resumen · Panel de reportes · Arre",
};

export default function ReportesResumen() {
  return <SeccionResumen />;
}
