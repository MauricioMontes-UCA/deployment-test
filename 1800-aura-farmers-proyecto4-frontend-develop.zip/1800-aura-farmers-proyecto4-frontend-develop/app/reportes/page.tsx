import { redirect } from "next/navigation";

/** /reportes abre la primera sección del panel. */
export default function Reportes() {
  redirect("/reportes/ingresos");
}
