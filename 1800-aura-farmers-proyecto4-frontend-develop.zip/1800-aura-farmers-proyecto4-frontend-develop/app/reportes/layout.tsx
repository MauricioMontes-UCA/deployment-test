import type { Metadata } from "next";
import type { ReactNode } from "react";
import Link from "next/link";
import { redirect } from "next/navigation";
import { cerrarSesion } from "@/app/actions/auth";
import { PanelDeReportes } from "@/components/reportes/panel-de-reportes";
import {
  Contenedor,
  EncabezadoDePagina,
  EstadoDePagina,
  NavegacionSuperior,
  PieDePagina,
  clasesBoton,
} from "@/components/ui";
import { obtenerUsuarioActual } from "@/lib/usuario-actual";

export const metadata: Metadata = {
  title: "Panel de reportes · Arre",
};

/**
 * Layout del panel de reportes (FE-23.1). Solo entra el ARRENDADOR (rol de
 * GET /auth/me): el ARRENDATARIO ve «No tienes acceso a este panel.» y las
 * secciones no se montan, así que no se llama a ningún endpoint de reportes.
 * Sin sesión, el proxy lleva a /login; con un 401 de /auth/me (sesión vencida)
 * se pasa por /sesion-vencida, que borra la cookie y lleva a /login.
 */
export default async function LayoutReportes({ children }: LayoutProps<"/reportes">) {
  const resultado = await obtenerUsuarioActual();
  // Pasa por /sesion-vencida para borrar la cookie; con ella, el proxy no deja entrar a /login.
  if (resultado.estado === "sin-sesion") redirect("/sesion-vencida");

  if (resultado.estado === "error") {
    return (
      <Pagina>
        <EstadoDePagina
          tipo="error"
          accion={
            <Link href="/reportes" className={clasesBoton({ jerarquia: "secundario" })}>
              Reintentar
            </Link>
          }
        />
      </Pagina>
    );
  }

  const { usuario } = resultado;
  const arrendador = usuario.rol === "ARRENDADOR";
  const navegacion = (
    <NavegacionSuperior
      rol={arrendador ? "arrendador" : "arrendatario"}
      nombreUsuario={usuario.nombreUsuario}
      onCerrarSesion={cerrarSesion}
    />
  );

  if (!arrendador) {
    return (
      <Pagina navegacion={navegacion}>
        <EstadoDePagina
          tipo="sin-permiso"
          accion={
            <Link href="/" className={clasesBoton({ jerarquia: "secundario" })}>
              Ir al inicio
            </Link>
          }
        />
      </Pagina>
    );
  }

  return (
    <Pagina navegacion={navegacion}>
      <EncabezadoDePagina
        sobretitulo="Arrendador"
        titulo="Panel de reportes"
        descripcion="Ingresos, ocupación y calificación de tus bienes en el periodo que elijas."
      />
      <PanelDeReportes>{children}</PanelDeReportes>
    </Pagina>
  );
}

function Pagina({
  navegacion,
  children,
}: {
  navegacion?: ReactNode;
  children: ReactNode;
}) {
  return (
    <>
      {navegacion}
      <main className="flex-1 bg-fondo-base">
        <Contenedor className="flex flex-col gap-espacio-5 pt-espacio-6 pb-espacio-8 md:pt-espacio-7 md:pb-espacio-9">
          {children}
        </Contenedor>
      </main>
      <PieDePagina />
    </>
  );
}
