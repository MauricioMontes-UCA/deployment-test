import { render, screen } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";
import Inicio from "@/app/page";
import { obtenerTokens } from "@/lib/sesion";
import { usuarioDePrueba } from "@/pruebas/usuario";
import { obtenerUsuarioActual } from "@/lib/usuario-actual";

const redirigir = vi.hoisted(() =>
  vi.fn((destino: string): never => {
    throw new Error(`REDIRECT:${destino}`);
  }),
);
vi.mock("next/navigation", () => ({
  usePathname: () => "/",
  useRouter: () => ({ push: vi.fn(), refresh: vi.fn() }),
  redirect: redirigir,
}));
vi.mock("@/lib/sesion", () => ({ obtenerTokens: vi.fn() }));
vi.mock("@/app/actions/auth", () => ({ cerrarSesion: vi.fn() }));
vi.mock("@/lib/usuario-actual", () => ({ obtenerUsuarioActual: vi.fn() }));
// La grilla es un server component asíncrono con sus propias pruebas.
vi.mock("@/components/inicio/publicados-recientemente", () => ({
  PublicadosRecientemente: () => <p>Grilla de recientes</p>,
  PublicadosRecientementeCargando: () => null,
}));

async function montar() {
  render(await Inicio());
}

beforeEach(() => {
  vi.mocked(obtenerTokens).mockResolvedValue({ acceso: undefined, refresh: undefined });
  redirigir.mockClear();
});

describe("Portada /", () => {
  it("sin sesión muestra la barra de visitante, la búsqueda y las secciones", async () => {
    vi.mocked(obtenerUsuarioActual).mockResolvedValue({ estado: "sin-sesion" });
    await montar();

    expect(screen.getAllByRole("link", { name: /Iniciar sesión/ }).length).toBeGreaterThan(0);
    expect(
      screen.getByRole("heading", { level: 1, name: "Renta lo que necesitas, de personas cerca de ti." }),
    ).toBeInTheDocument();
    expect(screen.getByRole("search", { name: "Buscar bienes" })).toBeInTheDocument();
    expect(screen.getByText("Grilla de recientes")).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "Ver todo" })).toHaveAttribute("href", "/buscar");
    expect(screen.getByRole("heading", { name: "3. Paga y recibe" })).toBeInTheDocument();
  });

  it("cada categoría abre la búsqueda filtrada por ella", async () => {
    vi.mocked(obtenerUsuarioActual).mockResolvedValue({ estado: "sin-sesion" });
    await montar();

    expect(screen.getByRole("link", { name: "Salón de eventos" })).toHaveAttribute(
      "href",
      "/buscar?categoria=Sal%C3%B3n+de+eventos",
    );
    expect(screen.getByRole("link", { name: "Mobiliario para eventos" })).toHaveAttribute(
      "href",
      "/buscar?categoria=Mobiliario+para+eventos",
    );
  });

  it("el CTA para arrendadores lleva a /registro", async () => {
    vi.mocked(obtenerUsuarioActual).mockResolvedValue({ estado: "sin-sesion" });
    await montar();

    expect(screen.getByRole("heading", { name: "¿Tienes algo que rentar?" })).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "Crear cuenta de arrendador" })).toHaveAttribute(
      "href",
      "/registro",
    );
  });

  it("con sesión muestra la barra del rol del usuario", async () => {
    vi.mocked(obtenerUsuarioActual).mockResolvedValue({
      estado: "ok",
      usuario: usuarioDePrueba({ nombreUsuario: "mariana_rivas", rol: "ARRENDADOR" }),
    });
    await montar();

    expect(screen.queryByRole("link", { name: /Iniciar sesión/ })).not.toBeInTheDocument();
    expect(screen.getAllByRole("link", { name: "Reportes" }).length).toBeGreaterThan(0);
    expect(screen.getByText("mariana_rivas")).toBeInTheDocument();
  });

  it("con cookie pero token vencido (401) borra la sesión antes de mostrarse", async () => {
    vi.mocked(obtenerTokens).mockResolvedValue({ acceso: "token-vencido", refresh: undefined });
    vi.mocked(obtenerUsuarioActual).mockResolvedValue({ estado: "sin-sesion" });

    await expect(Inicio()).rejects.toThrow("REDIRECT:/sesion-vencida");
  });

  it("si el backend falla (no es 401) no toca la sesión", async () => {
    vi.mocked(obtenerTokens).mockResolvedValue({ acceso: "token", refresh: undefined });
    vi.mocked(obtenerUsuarioActual).mockResolvedValue({ estado: "error" });
    await montar();

    expect(redirigir).not.toHaveBeenCalled();
    expect(screen.getAllByRole("link", { name: /Iniciar sesión/ }).length).toBeGreaterThan(0);
  });
});
