// @vitest-environment node
import { NextRequest } from "next/server";
import { describe, expect, it } from "vitest";
import { proxy } from "@/proxy";
import { tokenDePrueba } from "@/pruebas/tokens";

function pedir(ruta: string, conSesion = false) {
  const peticion = new NextRequest(`http://localhost${ruta}`);
  // Un access token vigente: el proxy no necesita renovar ni llamar al backend.
  if (conSesion) peticion.cookies.set("access_token", tokenDePrueba({ exp: Math.floor(Date.now() / 1000) + 600 }));
  return proxy(peticion);
}

const destino = async (respuesta: Promise<Response>) => (await respuesta).headers.get("location");

describe("proxy", () => {
  it("la portada se ve con o sin sesión", async () => {
    expect(await destino(pedir("/"))).toBeNull();
    expect(await destino(pedir("/", true))).toBeNull();
  });

  it("la búsqueda y el detalle de un bien se ven sin sesión", async () => {
    expect(await destino(pedir("/buscar"))).toBeNull();
    expect(await destino(pedir("/buscar?q=salon"))).toBeNull();
    expect(await destino(pedir("/bienes/abc-123"))).toBeNull();
    expect(await destino(pedir("/bienes/abc-123", true))).toBeNull();
  });

  it("las demás rutas siguen pidiendo sesión", async () => {
    expect(await destino(pedir("/reportes"))).toBe("http://localhost/login");
    expect(await destino(pedir("/publicar"))).toBe("http://localhost/login");
    expect(await destino(pedir("/bienes"))).toBe("http://localhost/login");
    expect(await destino(pedir("/bienes/abc-123/reservar"))).toBe("http://localhost/login");
    expect(await destino(pedir("/buscarx"))).toBe("http://localhost/login");
  });
});
