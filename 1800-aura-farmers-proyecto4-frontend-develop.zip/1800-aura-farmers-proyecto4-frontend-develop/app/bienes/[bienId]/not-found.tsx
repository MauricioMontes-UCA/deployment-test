import Link from "next/link";
import { Contenedor, EstadoDePagina, clasesBoton } from "@/components/ui";

/** Bien inexistente o inactivo (404 de `GET /bienes/:bienId`). */
export default function BienNoEncontrado() {
  return (
    <Contenedor className="pt-espacio-5 pb-espacio-7 md:pt-10 md:pb-espacio-9">
      <EstadoDePagina
        tipo="no-encontrado"
        titulo="Esta publicación ya no está disponible."
        accion={
          <Link href="/buscar" className={clasesBoton({ jerarquia: "secundario" })}>
            Volver a la búsqueda
          </Link>
        }
      />
    </Contenedor>
  );
}
