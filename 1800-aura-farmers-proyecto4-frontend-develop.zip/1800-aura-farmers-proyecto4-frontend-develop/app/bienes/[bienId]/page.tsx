import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { DetalleDelBien } from "@/components/bienes/detalle-del-bien";
import { obtenerBienDetalle, obtenerResenasDeBien } from "@/lib/bienes";
import { obtenerUsuarioActual } from "@/lib/usuario-actual";

export async function generateMetadata({ params }: PageProps<"/bienes/[bienId]">): Promise<Metadata> {
  const { bienId } = await params;
  const bien = await obtenerBienDetalle(bienId).catch(() => null);
  return { title: bien ? `${bien.titulo} · Arre` : "Publicación no disponible · Arre" };
}

/**
 * Detalle público de un bien (FE-2.1): `GET /bienes/:bienId` y la primera
 * página de sus reseñas (BE-15.2). Un bien inexistente o inactivo muestra
 * `not-found.tsx`; cualquier otro fallo del detalle llega a `error.tsx`.
 *
 * La carpeta es `[bienId]` y no `[id]` como dice la task: Next no admite dos
 * nombres para el mismo segmento y `/bienes/[bienId]/reservar` ya existía.
 */
export default async function PaginaDetalleDelBien({
  params,
  searchParams,
}: PageProps<"/bienes/[bienId]">) {
  const { bienId } = await params;
  // «Publicar» (H1) redirige aquí con ?publicado=1 para confirmar la publicación.
  const { publicado } = await searchParams;
  const [bien, resenas, sesion] = await Promise.all([
    obtenerBienDetalle(bienId),
    obtenerResenasDeBien(bienId),
    obtenerUsuarioActual(),
  ]);
  if (!bien) notFound();

  const usuario = sesion.estado === "ok" ? sesion.usuario : null;
  return (
    <DetalleDelBien
      bien={bien}
      conSesion={usuario !== null}
      esDelUsuario={usuario?.id === bien.arrendador.id}
      resenas={resenas}
      recienPublicado={publicado === "1"}
    />
  );
}
