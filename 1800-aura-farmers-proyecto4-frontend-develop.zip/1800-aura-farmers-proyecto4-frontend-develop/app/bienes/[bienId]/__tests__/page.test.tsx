import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { beforeEach, describe, expect, it, vi } from "vitest";
import ErrorDetalleDelBien from "@/app/bienes/[bienId]/error";
import BienNoEncontrado from "@/app/bienes/[bienId]/not-found";
import PaginaDetalleDelBien, { generateMetadata } from "@/app/bienes/[bienId]/page";
import { obtenerBienDetalle } from "@/lib/bienes";
import { obtenerUsuarioActual } from "@/lib/usuario-actual";
import { BIEN } from "@/components/bienes/__tests__/bien-de-ejemplo";

const noEncontrado = vi.hoisted(() =>
  vi.fn((): never => {
    throw new Error("NOT_FOUND");
  }),
);
vi.mock("next/navigation", () => ({ notFound: noEncontrado }));
vi.mock("@/lib/bienes", async (original) => ({
  ...(await original<typeof import("@/lib/bienes")>()),
  obtenerBienDetalle: vi.fn(),
}));
vi.mock("@/lib/usuario-actual", () => ({ obtenerUsuarioActual: vi.fn() }));
vi.mock("@/components/calendario-de-disponibilidad", () => ({
  CalendarioDeDisponibilidad: () => <p>Calendario</p>,
}));

const props = (id: string) => ({ params: Promise.resolve({ bienId: id }), searchParams: Promise.resolve({}) });

beforeEach(() => {
  vi.mocked(obtenerBienDetalle).mockReset();
  vi.mocked(obtenerUsuarioActual).mockResolvedValue({ estado: "sin-sesion" });
  noEncontrado.mockClear();
});

describe("/bienes/[bienId]", () => {
  it("muestra el detalle del bien pedido", async () => {
    vi.mocked(obtenerBienDetalle).mockResolvedValue(BIEN);
    render(await PaginaDetalleDelBien(props(BIEN.id)));

    expect(obtenerBienDetalle).toHaveBeenCalledWith(BIEN.id);
    expect(screen.getByRole("heading", { level: 1, name: BIEN.titulo })).toBeInTheDocument();
  });

  it("un 404 del servicio lleva a la página de no disponible", async () => {
    vi.mocked(obtenerBienDetalle).mockResolvedValue(null);
    await expect(PaginaDetalleDelBien(props(BIEN.id))).rejects.toThrow("NOT_FOUND");
    expect(noEncontrado).toHaveBeenCalled();
  });

  it("un fallo de la API llega al límite de error", async () => {
    vi.mocked(obtenerBienDetalle).mockRejectedValue(new Error("GET /bienes respondió 500"));
    await expect(PaginaDetalleDelBien(props(BIEN.id))).rejects.toThrow("500");
    expect(noEncontrado).not.toHaveBeenCalled();
  });

  it("usa el título del bien como título de la pestaña", async () => {
    vi.mocked(obtenerBienDetalle).mockResolvedValue(BIEN);
    expect(await generateMetadata(props(BIEN.id))).toEqual({ title: `${BIEN.titulo} · Arre` });

    vi.mocked(obtenerBienDetalle).mockResolvedValue(null);
    expect(await generateMetadata(props(BIEN.id))).toEqual({ title: "Publicación no disponible · Arre" });
  });
});

describe("not-found de /bienes/[bienId]", () => {
  it("dice que la publicación ya no está disponible y enlaza a la búsqueda", () => {
    render(<BienNoEncontrado />);
    expect(screen.getByRole("heading", { name: "Esta publicación ya no está disponible." })).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "Volver a la búsqueda" })).toHaveAttribute("href", "/buscar");
  });
});

describe("error de /bienes/[bienId]", () => {
  it("muestra el mensaje de la task y «Reintentar» vuelve a pedir la página", async () => {
    const reintentar = vi.fn();
    render(<ErrorDetalleDelBien error={new Error("500")} retry={reintentar} />);

    expect(screen.getByRole("alert")).toHaveTextContent("No pudimos cargar la publicación. Intenta de nuevo.");
    await userEvent.click(screen.getByRole("button", { name: "Reintentar" }));
    expect(reintentar).toHaveBeenCalledOnce();
  });

  it("al llegar desde «Publicar» muestra «Tu publicación ya está visible»", async () => {
    vi.mocked(obtenerBienDetalle).mockResolvedValue(BIEN);
    render(
      await PaginaDetalleDelBien({
        params: Promise.resolve({ bienId: BIEN.id }),
        searchParams: Promise.resolve({ publicado: "1" }),
      }),
    );
    expect(screen.getByRole("status")).toHaveTextContent("Tu publicación ya está visible");
  });
});
