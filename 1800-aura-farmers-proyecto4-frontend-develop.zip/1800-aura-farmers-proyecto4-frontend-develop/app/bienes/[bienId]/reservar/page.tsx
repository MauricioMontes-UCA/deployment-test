import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { SolicitudDeReserva } from "@/components/solicitud-de-reserva";
import { Contenedor, EncabezadoDePagina, EstadoDePagina } from "@/components/ui";
import { ID_UUID, obtenerBien } from "@/lib/solicitud/servidor";

export const metadata: Metadata = { title: "Solicitar reserva · Arre" };

/**
 * Elegir fechas y solicitar la reserva de un bien (FE-5.1 + FE-6.1). El
 * calendario vive aquí hasta que el detalle del bien (`/bienes/[bienId]`, FE-2.1)
 * lo incorpore: `SolicitudDeReserva` se puede montar tal cual en esa página.
 */
export default async function PaginaSolicitarReserva({
  params,
}: {
  params: Promise<{ bienId: string }>;
}) {
  const { bienId } = await params;
  if (!ID_UUID.test(bienId)) notFound();

  let bien;
  try {
    bien = await obtenerBien(bienId);
  } catch (error) {
    console.error("Error al cargar el bien para la solicitud:", error);
    return (
      <Contenedor className="py-espacio-7">
        <EstadoDePagina
          tipo="error"
          titulo="No pudimos cargar el bien."
          mensaje="Recarga la página en unos momentos."
        />
      </Contenedor>
    );
  }
  if (!bien) notFound();

  return (
    <Contenedor className="flex flex-col gap-espacio-6 py-espacio-6 md:py-espacio-7">
      <EncabezadoDePagina sobretitulo="Solicitar reserva" titulo={bien.titulo} />
      <SolicitudDeReserva bien={bien} />
    </Contenedor>
  );
}
