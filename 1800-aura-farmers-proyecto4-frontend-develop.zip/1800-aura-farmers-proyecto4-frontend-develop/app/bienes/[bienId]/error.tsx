"use client";

import { Boton, Contenedor, EstadoDePagina } from "@/components/ui";

/**
 * Fallo de la API al pedir el detalle (red, 5xx). `retry` vuelve a renderizar
 * la página en el servidor, así que pide el bien de nuevo.
 */
export default function ErrorDetalleDelBien({ retry }: { error: Error & { digest?: string }; retry: () => void }) {
  return (
    <Contenedor className="pt-espacio-5 pb-espacio-7 md:pt-10 md:pb-espacio-9">
      <EstadoDePagina
        tipo="error"
        titulo="No pudimos cargar la publicación. Intenta de nuevo."
        mensaje="Revisa tu conexión y vuelve a intentarlo."
        accion={
          <Boton jerarquia="secundario" onClick={() => retry()}>
            Reintentar
          </Boton>
        }
      />
    </Contenedor>
  );
}
