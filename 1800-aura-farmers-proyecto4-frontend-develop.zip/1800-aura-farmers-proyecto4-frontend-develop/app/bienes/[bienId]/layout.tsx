import { redirect } from "next/navigation";
import { cerrarSesion } from "@/app/actions/auth";
import { NavegacionSuperior, PieDePagina } from "@/components/ui";
import { obtenerTokens } from "@/lib/sesion";
import { obtenerUsuarioActual } from "@/lib/usuario-actual";

/**
 * Marco del detalle del bien: barra superior según la sesión y pie de página.
 * Va en el layout y no en la página para que también envuelva la carga, el
 * «no disponible» y el error.
 */
export default async function LayoutDetalleDelBien({ children }: LayoutProps<"/bienes/[bienId]">) {
  const sesion = await obtenerUsuarioActual();
  // Igual que la portada: con cookie y token rechazado (401) la sesión venció.
  if (sesion.estado === "sin-sesion" && (await obtenerTokens()).acceso) {
    redirect("/sesion-vencida");
  }
  const usuario = sesion.estado === "ok" ? sesion.usuario : null;

  return (
    <>
      {usuario ? (
        <NavegacionSuperior
          rol={usuario.rol === "ARRENDADOR" ? "arrendador" : "arrendatario"}
          nombreUsuario={usuario.nombreUsuario}
          onCerrarSesion={cerrarSesion}
        />
      ) : (
        <NavegacionSuperior rol="visitante" />
      )}
      <main className="flex-1 bg-fondo-base">{children}</main>
      <PieDePagina />
    </>
  );
}
