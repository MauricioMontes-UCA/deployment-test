import { DetalleDelBienEsqueleto } from "@/components/bienes/detalle-del-bien";

export default function CargandoDetalleDelBien() {
  return <DetalleDelBienEsqueleto />;
}
