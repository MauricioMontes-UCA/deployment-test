"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { cerrarSesion } from "@/app/actions/auth";
import {
  Boton,
  Contenedor,
  EncabezadoDePagina,
  EstadoDePagina,
  NavegacionSuperior,
  PieDePagina,
  Pestana,
  Pestanas,
  TarjetaDeReserva,
  clasesBoton,
} from "@/components/ui";
import {
  accionDeReserva,
  ESTADO_VISUAL,
  FILTROS,
  formatearFechas,
  textoMotivo,
} from "@/lib/reservas/formato";
import type { EstadoReserva, ReservaVista } from "@/lib/reservas/tipos";

type Filtro = EstadoReserva | "TODAS";
type Carga =
  | { tipo: "cargando" }
  | { tipo: "listo"; reservas: ReservaVista[] }
  | { tipo: "sesion" }
  | { tipo: "error" };

function Esqueleto() {
  return (
    <div
      role="status"
      aria-label="Cargando reservas"
      className="flex flex-col gap-espacio-4"
    >
      {[0, 1, 2].map((n) => (
        <div
          key={n}
          className="h-[122px] animate-pulse border border-borde-sutil bg-fondo-sutil"
        />
      ))}
    </div>
  );
}

export function MisReservas({ nombreUsuario }: { nombreUsuario?: string }) {
  const [filtro, setFiltro] = useState<Filtro>("TODAS");
  const [carga, setCarga] = useState<Carga>({ tipo: "cargando" });
  const [intento, setIntento] = useState(0);

  useEffect(() => {
    const control = new AbortController();
    const consulta = filtro === "TODAS" ? "" : `?estado=${filtro}`;
    fetch(`/api/reservas/mias${consulta}`, {
      signal: control.signal,
      cache: "no-store",
    })
      .then(async (respuesta) => {
        if (respuesta.status === 401) return setCarga({ tipo: "sesion" });
        if (!respuesta.ok) return setCarga({ tipo: "error" });
        const reservas: ReservaVista[] = await respuesta.json();
        setCarga({ tipo: "listo", reservas });
      })
      .catch((error) => {
        if (error?.name !== "AbortError") setCarga({ tipo: "error" });
      });
    return () => control.abort();
  }, [filtro, intento]);

  function cambiarFiltro(nuevo: Filtro) {
    if (nuevo === filtro) return;
    setCarga({ tipo: "cargando" });
    setFiltro(nuevo);
  }

  function reintentar() {
    setCarga({ tipo: "cargando" });
    setIntento((n) => n + 1);
  }

  return (
    <>
      <NavegacionSuperior
        rol="arrendatario"
        nombreUsuario={nombreUsuario}
        onCerrarSesion={() => void cerrarSesion()}
      />
      <main className="flex-1">
        <Contenedor className="flex flex-col gap-espacio-5 pt-espacio-5 pb-espacio-8 md:pt-espacio-7 md:pb-espacio-9">
          <EncabezadoDePagina
            sobretitulo="Arrendatario"
            titulo="Mis reservas"
            descripcion="Tus solicitudes y reservas con su estado. Paga, coordina la entrega y califica desde aquí."
          />
          <Pestanas etiqueta="Filtrar por estado">
            {FILTROS.map(({ valor, texto }) => (
              <Pestana
                key={valor}
                activa={filtro === valor}
                onClick={() => cambiarFiltro(valor)}
              >
                {texto}
              </Pestana>
            ))}
          </Pestanas>

          {carga.tipo === "cargando" && <Esqueleto />}

          {carga.tipo === "error" && (
            <EstadoDePagina
              tipo="error"
              accion={
                <Boton jerarquia="secundario" onClick={reintentar}>
                  Reintentar
                </Boton>
              }
            />
          )}

          {carga.tipo === "sesion" && (
            <EstadoDePagina
              tipo="error"
              titulo="Tu sesión venció"
              mensaje="Inicia sesión de nuevo para ver tus reservas."
              accion={
                <form action={cerrarSesion}>
                  <Boton type="submit">Iniciar sesión</Boton>
                </form>
              }
            />
          )}

          {carga.tipo === "listo" && carga.reservas.length === 0 && (
            <EstadoDePagina
              tipo="vacio"
              titulo={
                filtro === "TODAS"
                  ? "Aún no tienes solicitudes"
                  : "No hay reservas con este estado"
              }
              mensaje={
                filtro === "TODAS"
                  ? "Cuando solicites un bien, lo verás aquí con su estado."
                  : "Prueba con otro filtro para ver tus demás reservas."
              }
              accion={
                filtro === "TODAS" ? (
                  <Link href="/" className={clasesBoton()}>
                    Explorar bienes
                  </Link>
                ) : undefined
              }
            />
          )}

          {carga.tipo === "listo" && carga.reservas.length > 0 && (
            <>
              <p
                aria-live="polite"
                className="texto-etiqueta text-texto-secundario"
              >
                {carga.reservas.length}{" "}
                {carga.reservas.length === 1 ? "reserva" : "reservas"}
              </p>
              <div className="flex flex-col gap-espacio-4">
                {carga.reservas.map((reserva) => {
                  const accion = accionDeReserva(reserva.estado, reserva.id);
                  return (
                    <TarjetaDeReserva
                      key={reserva.id}
                      titulo={reserva.titulo ?? "Bien no disponible"}
                      foto={reserva.foto}
                      fechas={formatearFechas(
                        reserva.fechaInicio,
                        reserva.fechaFin,
                      )}
                      participante={
                        reserva.arrendador
                          ? `Arrendador: ${reserva.arrendador}`
                          : "Arrendador no disponible"
                      }
                      estado={ESTADO_VISUAL[reserva.estado]}
                      motivoRechazo={textoMotivo(reserva.motivoResolucion)}
                      accion={
                        <div className="flex flex-wrap items-center gap-espacio-2">
                          <Link
                            href={accion.href}
                            className={clasesBoton({
                              jerarquia: accion.destacada
                                ? "primario"
                                : "terciario",
                            })}
                          >
                            {accion.texto}
                          </Link>
                          {(reserva.estado === "EN_CURSO" ||
                            reserva.estado === "FINALIZADA") && (
                            <Link
                              href={`/reservas/${reserva.id}/deposito`}
                              className={clasesBoton({
                                jerarquia: "terciario",
                              })}
                            >
                              Ver depósito
                            </Link>
                          )}
                        </div>
                      }
                    />
                  );
                })}
              </div>
            </>
          )}
        </Contenedor>
      </main>
      <PieDePagina />
    </>
  );
}
