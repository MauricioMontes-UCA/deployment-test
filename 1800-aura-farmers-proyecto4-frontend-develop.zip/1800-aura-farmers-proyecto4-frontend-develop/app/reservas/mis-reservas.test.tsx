import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, describe, expect, it, vi } from "vitest";
import { MisReservas } from "./mis-reservas";

vi.mock("@/app/actions/auth", () => ({ cerrarSesion: vi.fn() }));
vi.mock("next/navigation", () => ({ usePathname: () => "/reservas" }));

const base = {
  bienId: "b1",
  arrendatarioId: "u1",
  fechaInicio: "2026-11-20",
  fechaFin: "2026-11-22",
  motivoResolucion: null,
  creadaEn: "2026-11-01T00:00:00.000Z",
  procesadaEn: null,
  titulo: "Salón de eventos",
  foto: null,
  arrendador: "mariana",
};

function json(cuerpo: unknown, status = 200) {
  return Promise.resolve(new Response(JSON.stringify(cuerpo), { status }));
}

afterEach(() => vi.unstubAllGlobals());

describe("MisReservas", () => {
  it("muestra los estados con su motivo y la acción de cada uno", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn(() =>
        json([
          { ...base, id: "1", estado: "CONFIRMADA" },
          { ...base, id: "2", estado: "RECHAZADA", motivoResolucion: "FECHAS_NO_DISPONIBLES" },
          { ...base, id: "3", estado: "CANCELADA" },
        ]),
      ),
    );
    render(<MisReservas />);

    expect(await screen.findByText("3 reservas")).toBeInTheDocument();
    expect(screen.getByText("Confirmada")).toBeInTheDocument();
    expect(screen.getByText("Rechazada")).toBeInTheDocument();
    expect(screen.getByText("Cancelada")).toBeInTheDocument();
    expect(screen.getByText("Motivo: fechas no disponibles")).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "Pagar ahora" })).toHaveAttribute("href", "/reservas/1/pago");
  });

  it("filtra por estado consultando la API", async () => {
    const fetchMock = vi.fn(() => json([]));
    vi.stubGlobal("fetch", fetchMock);
    render(<MisReservas />);
    await screen.findByText("Aún no tienes solicitudes");

    await userEvent.click(screen.getByRole("tab", { name: "Rechazadas" }));

    await waitFor(() =>
      expect(fetchMock).toHaveBeenLastCalledWith(
        "/api/reservas/mias?estado=RECHAZADA",
        expect.anything(),
      ),
    );
    expect(await screen.findByText("No hay reservas con este estado")).toBeInTheDocument();
  });

  it("muestra el estado de carga mientras espera", () => {
    vi.stubGlobal("fetch", vi.fn(() => new Promise(() => {})));
    render(<MisReservas />);
    expect(screen.getByRole("status", { name: "Cargando reservas" })).toBeInTheDocument();
  });

  it("muestra el error y permite reintentar", async () => {
    const fetchMock = vi
      .fn()
      .mockImplementationOnce(() => json({}, 502))
      .mockImplementation(() => json([{ ...base, id: "1", estado: "EN_COLA" }]));
    vi.stubGlobal("fetch", fetchMock);
    render(<MisReservas />);

    await userEvent.click(await screen.findByRole("button", { name: "Reintentar" }));

    expect(await screen.findByText("1 reserva")).toBeInTheDocument();
  });

  it("ante un 401 ofrece iniciar sesión de nuevo", async () => {
    vi.stubGlobal("fetch", vi.fn(() => json({}, 401)));
    render(<MisReservas />);
    expect(await screen.findByText("Tu sesión venció")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Iniciar sesión" })).toBeInTheDocument();
  });
});
