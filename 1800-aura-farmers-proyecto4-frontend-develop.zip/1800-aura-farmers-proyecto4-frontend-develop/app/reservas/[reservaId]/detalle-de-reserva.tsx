import Link from "next/link";
import type { ReactNode } from "react";
import { EncabezadoDePagina, Icono, Imagen, InsigniaDeEstado, clasesBoton } from "@/components/ui";
import { unirClases } from "@/lib/clases";
import {
  PASOS_LINEA,
  TEXTO_DEPOSITO,
  TEXTO_PAGO,
  accionesDelArrendador,
  accionesDelArrendatario,
  formatearDinero,
  hrefConversacion,
  importeAlquiler,
  pagoExitoso,
  pasosAlcanzados,
  puedeVerComprobante,
  puedeCoordinar,
  textoDuracion,
  type AccionDeDetalle,
  type DetalleReserva,
  type RolEnReserva,
} from "@/lib/reservas/detalle";
import { ESTADO_VISUAL, formatearDia, textoMotivo } from "@/lib/reservas/formato";

const TARJETA = "flex flex-col gap-espacio-4 border border-borde-default bg-fondo-superficie p-espacio-5";

function Tarjeta({ titulo, children, className }: { titulo: string; children: ReactNode; className?: string }) {
  return (
    <section aria-label={titulo} className={unirClases(TARJETA, className)}>
      <h2 className="texto-h3 text-texto-primario">{titulo}</h2>
      {children}
    </section>
  );
}

/** Fila «etiqueta … valor» con la línea fina de Figma. */
function Fila({ etiqueta, valor, fuerte }: { etiqueta: string; valor: ReactNode; fuerte?: boolean }) {
  return (
    <div className="flex items-center justify-between gap-espacio-4 border-b border-borde-sutil py-espacio-3 last:border-b-0">
      <dt className="texto-cuerpo-pequeno text-texto-secundario">{etiqueta}</dt>
      <dd className={unirClases("texto-cuerpo-pequeno text-right text-texto-primario", fuerte && "font-semibold")}>
        {valor}
      </dd>
    </div>
  );
}

/** Línea de estados: En cola → Confirmada → En curso → Finalizada. */
function LineaDeEstados({ estado }: { estado: DetalleReserva["estado"] }) {
  const alcanzados = pasosAlcanzados(estado);
  return (
    <ol aria-label="Progreso de la reserva" className="grid grid-cols-4 gap-espacio-2">
      {PASOS_LINEA.map((paso, indice) => {
        const alcanzado = indice < alcanzados;
        return (
          <li key={paso.estado} aria-current={paso.estado === estado ? "step" : undefined} className="flex flex-col gap-espacio-2">
            <span className={unirClases("h-1 w-full", alcanzado ? "bg-fondo-marca" : "bg-fondo-acento")} />
            <span className="texto-etiqueta-pequena text-texto-primario">
              {paso.texto}
              <span className="sr-only">{alcanzado ? " (alcanzado)" : " (pendiente)"}</span>
            </span>
          </li>
        );
      })}
    </ol>
  );
}

/** Enlace o, si el estado todavía no la permite, botón deshabilitado. */
function BotonDeAccion({ accion, destacada }: { accion: AccionDeDetalle; destacada: boolean }) {
  const clases = clasesBoton({ jerarquia: destacada ? "primario" : "secundario", className: "w-full" });
  if (!accion.habilitada) {
    return (
      <span role="link" aria-disabled="true" className={unirClases(clases, "pointer-events-none opacity-40")}>
        {accion.texto}
      </span>
    );
  }
  return (
    <Link href={accion.href} className={clases}>
      {accion.texto}
    </Link>
  );
}

type Props = { detalle: DetalleReserva; rol: RolEnReserva };

/**
 * FE-6.3 (Figma 27:1219, 27:1375, 27:1511): bien, fechas, participantes, pago,
 * depósito y las acciones que le tocan al usuario según su rol y el estado.
 * La API no expone el código «RSV-…», la ubicación del bien ni la modalidad de
 * pago, así que esos datos de Figma no se muestran.
 */
export function DetalleDeReserva({ detalle, rol }: Props) {
  const { estado, bien, pago, deposito } = detalle;
  const visual = ESTADO_VISUAL[estado];
  const alquiler = importeAlquiler(detalle);
  const motivo = textoMotivo(detalle.motivoResolucion);
  const accionesPropias = rol === "ARRENDATARIO" ? accionesDelArrendatario(detalle) : [];
  const accionesArrendador = rol === "ARRENDADOR" ? accionesDelArrendador(detalle) : [];

  return (
    <>
      <div className="flex flex-col-reverse items-start gap-espacio-3 md:flex-row md:items-end md:justify-between">
        <EncabezadoDePagina sobretitulo="Reserva" titulo={bien.titulo} className="md:flex-1" />
        <InsigniaDeEstado texto={visual.texto} tono={visual.tono} />
      </div>

      {pasosAlcanzados(estado) > 0 ? (
        <LineaDeEstados estado={estado} />
      ) : (
        <p className="texto-cuerpo-pequeno text-texto-secundario">
          Esta reserva quedó {visual.texto.toLowerCase()}.{motivo ? ` ${motivo}.` : ""}
        </p>
      )}

      <div className="grid gap-espacio-5 md:grid-cols-[minmax(0,1fr)_440px] md:items-start">
        <div className="flex flex-col gap-espacio-5">
          <article className={unirClases(TARJETA, "flex-row items-center gap-espacio-4")}>
            <Imagen src={bien.foto} alt={bien.titulo} sizes="88px" compacta className="size-22 shrink-0" />
            <div className="flex min-w-0 flex-col items-start gap-espacio-2">
              <h2 className="texto-h3 text-texto-primario">{bien.titulo}</h2>
              <Link href={`/bienes/${bien.id}`} className={clasesBoton({ jerarquia: "terciario" })}>
                Ver publicación
              </Link>
            </div>
          </article>

          <Tarjeta titulo="Fechas">
            <dl>
              <Fila etiqueta="Inicio" valor={formatearDia(detalle.fechaInicio)} />
              <Fila etiqueta="Fin" valor={formatearDia(detalle.fechaFin)} />
              <Fila etiqueta="Duración" valor={textoDuracion(detalle.fechaInicio, detalle.fechaFin)} />
            </dl>
          </Tarjeta>

          <Tarjeta titulo="Participantes">
            <dl>
              <Fila etiqueta="Arrendador" valor={detalle.arrendador.nombreUsuario} />
              <Fila etiqueta="Arrendatario" valor={detalle.arrendatario.nombreUsuario} />
            </dl>
          </Tarjeta>
        </div>

        <div className="flex flex-col gap-espacio-5">
          {pago && (
            <Tarjeta titulo="Pago">
              <dl>
                {alquiler !== null && <Fila etiqueta="Alquiler" valor={formatearDinero(alquiler)} />}
                {alquiler !== null && deposito && (
                  <Fila etiqueta="Depósito de garantía" valor={formatearDinero(deposito.importe)} />
                )}
                <Fila etiqueta={pagoExitoso(detalle) ? "Total pagado" : "Total"} valor={formatearDinero(pago.total)} fuerte />
                <Fila etiqueta="Estado" valor={TEXTO_PAGO[pago.estado]} />
              </dl>
              {puedeVerComprobante(detalle, rol) && (
                <Link
                  href={`/pagos/${pago.id}/comprobante`}
                  className={clasesBoton({ jerarquia: "secundario", className: "w-full" })}
                >
                  <Icono nombre="documento" tamano={20} />
                  Ver comprobante
                </Link>
              )}
            </Tarjeta>
          )}

          {deposito && (
            <Tarjeta titulo="Depósito de garantía">
              <dl>
                <Fila etiqueta="Importe" valor={formatearDinero(deposito.importe)} />
                <Fila etiqueta="Estado" valor={TEXTO_DEPOSITO[deposito.estado]} />
              </dl>
            </Tarjeta>
          )}

          {accionesPropias.length > 0 && (
            <Tarjeta titulo="Acciones">
              {accionesPropias.map((accion) => (
                <BotonDeAccion key={accion.clave} accion={accion} destacada />
              ))}
            </Tarjeta>
          )}

          {puedeCoordinar(estado) && (
            <Tarjeta titulo="Coordinación de entrega">
              <p className="texto-cuerpo-pequeno text-texto-secundario">
                Acuerda fecha, hora y lugar de entrega por mensajes. Disponible con la reserva confirmada o en curso.
              </p>
              <Link href={hrefConversacion(detalle.id)} className={clasesBoton({ jerarquia: "secundario", className: "w-full" })}>
                <Icono nombre="mensaje" tamano={20} />
                Abrir conversación
              </Link>
            </Tarjeta>
          )}

          {rol === "ARRENDADOR" && (
            <Tarjeta titulo="Acciones del arrendador">
              <p className="texto-cuerpo-pequeno text-texto-secundario">
                Registrar la devolución con la reserva en curso; resolver el depósito y calificar, cuando queda
                finalizada.
              </p>
              {accionesArrendador.map((accion) => (
                <BotonDeAccion key={accion.clave} accion={accion} destacada={accion.clave === "devolucion"} />
              ))}
            </Tarjeta>
          )}
        </div>
      </div>
    </>
  );
}
