import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import type { ReactNode } from "react";
import { cerrarSesion } from "@/app/actions/auth";
import {
  Contenedor,
  EstadoDePagina,
  NavegacionSuperior,
  PieDePagina,
  clasesBoton,
} from "@/components/ui";
import type { UsuarioActual } from "@/lib/usuario-actual";
import { cargarDetalle } from "./datos";
import { DetalleDeReserva } from "./detalle-de-reserva";

export const metadata: Metadata = { title: "Detalle de reserva · Arre" };

/** Navegación, contenido con los márgenes de Figma y pie de página. */
function Marco({ usuario, children }: { usuario: UsuarioActual; children: ReactNode }) {
  return (
    <>
      <NavegacionSuperior
        rol={usuario.rol === "ARRENDADOR" ? "arrendador" : "arrendatario"}
        nombreUsuario={usuario.nombreUsuario}
        onCerrarSesion={cerrarSesion}
      />
      <main className="flex-1">
        <Contenedor className="flex flex-col gap-5 pt-espacio-5 pb-espacio-7 md:gap-espacio-6 md:pt-espacio-7 md:pb-espacio-9">
          {children}
        </Contenedor>
      </main>
      <PieDePagina />
    </>
  );
}

/** FE-6.3: detalle de una reserva para su arrendatario y para el arrendador dueño del bien. */
export default async function DetalleReservaPage({ params }: { params: Promise<{ reservaId: string }> }) {
  const { reservaId } = await params;
  const pantalla = await cargarDetalle(reservaId);

  // Como en el resto de la app: una página no puede borrar cookies, así que
  // /sesion-vencida las borra, revoca la sesión y lleva al login.
  if (pantalla.tipo === "sin-sesion") redirect("/sesion-vencida");

  if (pantalla.tipo === "no-encontrada") {
    return (
      <Marco usuario={pantalla.usuario}>
        <EstadoDePagina
          tipo="no-encontrado"
          titulo="No encontramos esa reserva."
          mensaje="Revisa el enlace e intenta de nuevo."
          accion={
            <Link
              href={pantalla.usuario.rol === "ARRENDADOR" ? "/reservas-recibidas" : "/reservas"}
              className={clasesBoton({ jerarquia: "secundario" })}
            >
              {pantalla.usuario.rol === "ARRENDADOR" ? "Ir a reservas recibidas" : "Ir a mis reservas"}
            </Link>
          }
        />
      </Marco>
    );
  }

  return (
    <Marco usuario={pantalla.usuario}>
      <DetalleDeReserva detalle={pantalla.detalle} rol={pantalla.rol} />
    </Marco>
  );
}
