"use client";
import Link from "next/link";
import { useRef, useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import { Alerta, AreaDeTexto, Boton, CampoDeTexto, DialogoDeConfirmacion, EncabezadoDePagina, Imagen, Selector, clasesBoton } from "@/components/ui";
import { contarObservaciones, fechaIso, fechaLocalActual, validarDevolucion, type EstadoFinalBien, type ResumenDevolucion } from "@/lib/devoluciones";
const opciones = [{ valor: "BUEN_ESTADO", etiqueta: "Buen estado" }, { valor: "DANADO", etiqueta: "Dañado" }, { valor: "INCOMPLETO", etiqueta: "Incompleto" }];
function fechaCorta(valor: string) { const fecha = new Date(valor); return Number.isFinite(fecha.getTime()) ? new Intl.DateTimeFormat("es-SV", { day: "2-digit", month: "2-digit", year: "numeric", timeZone: "UTC" }).format(fecha) : valor; }
function mensajeApi(datos: unknown, alternativo: string) { if (!datos || typeof datos !== "object") return alternativo; const m = (datos as Record<string, unknown>).message; return typeof m === "string" ? m : Array.isArray(m) && typeof m[0] === "string" ? m[0] : alternativo; }
export function FormularioDevolucion({ resumen }: { resumen: ResumenDevolucion }) {
  const router = useRouter();
  const [fecha, setFecha] = useState(() => fechaLocalActual());
  const [estado, setEstado] = useState("");
  const [observaciones, setObservaciones] = useState("");
  const [validar, setValidar] = useState(false);
  const [confirmando, setConfirmando] = useState(false);
  const [enviando, setEnviando] = useState(false);
  const [error, setError] = useState("");
  const [exito, setExito] = useState(false);
  const [sinPermiso, setSinPermiso] = useState(false);
  const bloqueo = useRef(false);
  const errores = validarDevolucion(fecha, estado, observaciones);
  const bloqueada = resumen.estado !== "EN_CURSO";
  const motivo = resumen.estado === "FINALIZADA" ? "La devolución de esta reserva ya fue registrada o la reserva fue cerrada automáticamente." : "No se puede registrar la devolución porque el alquiler no ha iniciado.";
  function solicitarConfirmacion(evento: FormEvent<HTMLFormElement>) {
    evento.preventDefault();setValidar(true);setError("");
    if (!bloqueada && !sinPermiso && !Object.keys(errores).length) setConfirmando(true);
  }
  async function guardar() {
    if (bloqueo.current || enviando) return;
    const nuevosErrores = validarDevolucion(fecha, estado, observaciones);
    if (Object.keys(nuevosErrores).length) { setValidar(true);setConfirmando(false);return; }
    bloqueo.current = true;setEnviando(true);setError("");
    try {
      const respuesta = await fetch(`/api/reservas/${resumen.reservaId}/devolucion`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ fechaDevolucion: fechaIso(fecha), estadoFinalBien: estado as EstadoFinalBien, ...(observaciones.trim() ? { observaciones: observaciones.trim() } : {}) }) });
      const datos: unknown = await respuesta.json().catch(() => null);
      if (respuesta.status === 401) { router.replace("/sesion-vencida");return; }
      if (respuesta.status === 403) { setSinPermiso(true);setError("No tienes permiso para registrar esta devolución.");return; }
      if (!respuesta.ok) { setError(mensajeApi(datos, respuesta.status === 409 ? "La devolución de esta reserva ya fue registrada o el alquiler no está en curso." : "No se pudo registrar la devolución."));return; }
      if (!datos || typeof datos !== "object" || (datos as Record<string, unknown>).estadoReserva !== "FINALIZADA") { setError("No se pudo confirmar la finalización de la reserva.");return; }
      setExito(true);router.refresh();
    } catch { setError("No se pudo conectar con el servidor. Intenta de nuevo."); }
    finally { bloqueo.current = false;setEnviando(false);setConfirmando(false); }
  }
  const resumenTarjeta = <aside className="order-1 flex flex-col gap-espacio-4 border border-borde-default bg-fondo-superficie p-espacio-4 lg:order-2"><div className="flex gap-espacio-3"><Imagen src={resumen.foto} alt={resumen.titulo} className="h-16 w-16 shrink-0" sizes="64px"/><div className="min-w-0"><p className="texto-cuerpo-medio text-texto-primario">{resumen.titulo}</p><p className="texto-cuerpo-pequeno text-texto-secundario">Reserva {resumen.reservaId.slice(0, 8).toUpperCase()} · Arrendatario: {resumen.arrendatario}</p></div></div><dl className="flex flex-col gap-espacio-3 texto-cuerpo-pequeno">{[["Período", `${fechaCorta(resumen.fechaInicio)} → ${fechaCorta(resumen.fechaFin)}`],["Estado actual", resumen.estado === "EN_CURSO" ? "En curso" : resumen.estado],["Depósito", resumen.deposito === null ? "Pendiente" : `$${resumen.deposito.toFixed(2)} pendiente`]].map(([nombre, valor]) => <div key={nombre} className="flex justify-between gap-3 border-b border-borde-sutil pb-espacio-2"><dt className="text-texto-secundario">{nombre}</dt><dd className="text-right text-texto-primario">{valor}</dd></div>)}</dl></aside>;
  return <div className="flex flex-col gap-espacio-6"><EncabezadoDePagina sobretitulo={`RESERVA ${resumen.reservaId.slice(0, 8).toUpperCase()}`} titulo="Registrar devolución" descripcion="Deja constancia de la fecha y del estado en que recibiste el bien. Al guardar, la reserva queda Finalizada."/><div className="grid grid-cols-1 items-start gap-espacio-6 lg:grid-cols-[minmax(0,1fr)_340px]"><section className="order-2 flex flex-col gap-espacio-4 lg:order-1">{exito ? <><Alerta tono="exito" titulo="Devolución registrada">La reserva quedó Finalizada. Ya puedes resolver el depósito de garantía.</Alerta><Link href={`/reservas/${resumen.reservaId}/deposito`} className={clasesBoton({ className: "w-full justify-center" })}>Resolver depósito</Link><Link href={`/reservas/${resumen.reservaId}`} className={clasesBoton({ jerarquia: "secundario", className: "w-full justify-center" })}>Volver al detalle de la reserva</Link></> : <>{bloqueada && <Alerta tono="error" titulo="No se puede registrar la devolución">{motivo}</Alerta>}{sinPermiso && <Alerta tono="error" titulo="Sin permiso">Solo el arrendador propietario puede registrar la devolución.</Alerta>}{error && <Alerta tono="error" titulo="No se pudo registrar la devolución">{error}</Alerta>}<form onSubmit={solicitarConfirmacion} noValidate className="flex flex-col gap-espacio-4"><CampoDeTexto etiqueta="Fecha de devolución" type="datetime-local" value={fecha} onChange={(e) => setFecha(e.target.value)} max={fechaLocalActual()} required disabled={bloqueada || enviando || sinPermiso} error={validar ? errores.fecha : undefined}/><Selector etiqueta="Estado final del bien" opciones={opciones} valor={estado} onCambiar={setEstado} placeholder="Selecciona el estado" ayuda="Buen estado, Dañado o Incompleto." error={validar ? errores.estado : undefined} deshabilitado={bloqueada || enviando || sinPermiso}/><AreaDeTexto etiqueta="Observaciones (opcional)" value={observaciones} onChange={(e) => setObservaciones(e.target.value)} limite={500} contarCaracteres={contarObservaciones} rows={4} disabled={bloqueada || enviando || sinPermiso} error={validar ? errores.observaciones : undefined}/><Boton type="submit" className="w-full" disabled={bloqueada || enviando || sinPermiso} cargando={enviando}>Registrar devolución</Boton></form></>}</section>{resumenTarjeta}</div><DialogoDeConfirmacion abierto={confirmando} titulo="¿Registrar la devolución?" mensaje={<>Se guardará la fecha {fecha.replace("T", " ")} y el estado {opciones.find(o => o.valor === estado)?.etiqueta}. La reserva pasará a Finalizada.</>} textoConfirmar="Registrar" cargando={enviando} onCancelar={() => setConfirmando(false)} onConfirmar={() => { void guardar(); }}/></div>;
}
