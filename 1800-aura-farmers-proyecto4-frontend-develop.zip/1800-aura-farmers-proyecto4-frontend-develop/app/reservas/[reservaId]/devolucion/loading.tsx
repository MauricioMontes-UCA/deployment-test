import { EstadoDePagina } from "@/components/ui";
export default function CargandoDevolucion() { return <main className="mx-auto w-full max-w-4xl p-8"><EstadoDePagina tipo="cargando" titulo="Cargando reserva…" /></main>; }
