import { beforeEach, describe, expect, it, vi } from "vitest";
import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import type { ResumenDevolucion } from "@/lib/devoluciones";

const mocks = vi.hoisted(() => ({ replace: vi.fn(), refresh: vi.fn() }));
const router = { replace: mocks.replace, refresh: mocks.refresh };
vi.mock("next/navigation", () => ({ useRouter: () => router }));
vi.mock("@/components/ui", async (importOriginal) => {
  const original = await importOriginal<typeof import("@/components/ui")>();
  return {
    ...original,
    Selector: ({
      etiqueta,
      opciones,
      valor,
      onCambiar,
    }: {
      etiqueta: string;
      opciones: { valor: string; etiqueta: string }[];
      valor: string;
      onCambiar: (valor: string) => void;
    }) => (
      <label>
        {etiqueta}
        <select value={valor} onChange={(e) => onCambiar(e.target.value)}>
          <option value="">Selecciona</option>
          {opciones.map((opcion) => (
            <option key={opcion.valor} value={opcion.valor}>
              {opcion.etiqueta}
            </option>
          ))}
        </select>
      </label>
    ),
    DialogoDeConfirmacion: ({
      abierto,
      onConfirmar,
      onCancelar,
    }: {
      abierto: boolean;
      onConfirmar: () => void;
      onCancelar: () => void;
    }) =>
      abierto ? (
        <div role="dialog">
          <button onClick={onConfirmar}>Confirmar registro</button>
          <button onClick={onCancelar}>Cancelar registro</button>
        </div>
      ) : null,
  };
});
import { FormularioDevolucion } from "./formulario-devolucion";

const resumen: ResumenDevolucion = {
  reservaId: "11111111-1111-4111-8111-111111111111",
  titulo: "Cámara",
  foto: null,
  arrendatario: "Ana",
  fechaInicio: "2020-01-01",
  fechaFin: "2020-01-02",
  estado: "EN_CURSO",
  deposito: 100,
};
const responder = (status: number, datos: unknown) => ({
  status,
  ok: status >= 200 && status < 300,
  json: async () => datos,
});
const fetchMock = vi.fn();
beforeEach(() => {
  fetchMock.mockReset();
  mocks.replace.mockReset();
  mocks.refresh.mockReset();
  vi.stubGlobal("fetch", fetchMock);
});

async function preparar() {
  render(<FormularioDevolucion resumen={resumen} />);
  fireEvent.change(screen.getByLabelText(/Estado final del bien/i), {
    target: { value: "BUEN_ESTADO" },
  });
  fireEvent.click(screen.getByRole("button", { name: "Registrar devolución" }));
  expect(await screen.findByRole("dialog")).toBeInTheDocument();
}

describe("FE-10.1 formulario", () => {
  it("solicita confirmación antes de enviar", async () => {
    await preparar();
    expect(fetchMock).not.toHaveBeenCalled();
  });
  it("envía una sola vez mientras está pendiente", async () => {
    let resolver!: (valor: unknown) => void;
    fetchMock.mockImplementation(
      () =>
        new Promise((resolve) => {
          resolver = resolve;
        }),
    );
    await preparar();
    fireEvent.click(screen.getByRole("button", { name: "Confirmar registro" }));
    fireEvent.click(screen.getByRole("button", { name: "Confirmar registro" }));
    expect(fetchMock).toHaveBeenCalledTimes(1);
    resolver(responder(201, { estadoReserva: "FINALIZADA" }));
    expect(
      await screen.findByText(/La reserva quedó Finalizada/),
    ).toBeInTheDocument();
  });
  it("muestra éxito Finalizada", async () => {
    fetchMock.mockResolvedValue(
      responder(201, { estadoReserva: "FINALIZADA" }),
    );
    await preparar();
    fireEvent.click(screen.getByRole("button", { name: "Confirmar registro" }));
    expect(
      await screen.findByText(/La reserva quedó Finalizada/),
    ).toBeInTheDocument();
  });
  it("401 redirige a sesión vencida", async () => {
    fetchMock.mockResolvedValue(responder(401, {}));
    await preparar();
    fireEvent.click(screen.getByRole("button", { name: "Confirmar registro" }));
    await waitFor(() =>
      expect(mocks.replace).toHaveBeenCalledWith("/sesion-vencida"),
    );
  });
  it("403 muestra sin permiso", async () => {
    fetchMock.mockResolvedValue(responder(403, {}));
    await preparar();
    fireEvent.click(screen.getByRole("button", { name: "Confirmar registro" }));
    expect(
      await screen.findByText(
        /Solo el arrendador propietario puede registrar la devolución/,
      ),
    ).toBeInTheDocument();
  });
  it("409 muestra el mensaje del backend", async () => {
    fetchMock.mockResolvedValue(
      responder(409, { message: "Devolución ya registrada" }),
    );
    await preparar();
    fireEvent.click(screen.getByRole("button", { name: "Confirmar registro" }));
    expect(
      await screen.findByText("Devolución ya registrada"),
    ).toBeInTheDocument();
  });
});
