import type { Metadata } from "next";
import type { ReactNode } from "react";
import Link from "next/link";
import { redirect } from "next/navigation";
import { cerrarSesion } from "@/app/actions/auth";
import { llamarApi } from "@/lib/api";
import { obtenerUsuarioActual } from "@/lib/usuario-actual";
import { ID_RESERVA, leerResumen } from "@/lib/devoluciones";
import {
  Contenedor,
  EstadoDePagina,
  NavegacionSuperior,
  PieDePagina,
  clasesBoton,
} from "@/components/ui";
import { FormularioDevolucion } from "./formulario-devolucion";
export const metadata: Metadata = { title: "Registrar devolución · Arre" };
export default async function PaginaDevolucion({
  params,
}: {
  params: Promise<{ reservaId: string }>;
}) {
  const { reservaId } = await params;
  const sesion = await obtenerUsuarioActual();
  if (sesion.estado === "sin-sesion") redirect("/sesion-vencida");
  if (sesion.estado === "error")
    throw new Error("No se pudo consultar la sesión.");
  const usuario = sesion.usuario;
  let vista: ReactNode;
  if (usuario.rol !== "ARRENDADOR") {
    vista = (
      <EstadoDePagina
        tipo="sin-permiso"
        titulo="No tienes acceso a esta devolución."
        mensaje="Solo el arrendador propietario puede registrar la devolución."
      />
    );
  } else if (!ID_RESERVA.test(reservaId)) {
    vista = (
      <EstadoDePagina tipo="no-encontrado" titulo="Reserva no encontrada." />
    );
  } else {
    const respuesta = await llamarApi(`reservas/${reservaId}`);
    if (respuesta.status === 401) redirect("/sesion-vencida");
    if (respuesta.status === 403)
      vista = (
        <EstadoDePagina
          tipo="sin-permiso"
          titulo="No tienes acceso a esta devolución."
        />
      );
    else if (respuesta.status === 404)
      vista = (
        <EstadoDePagina tipo="no-encontrado" titulo="Reserva no encontrada." />
      );
    else if (respuesta.status !== 200)
      throw new Error("No se pudo consultar la reserva.");
    else {
      const resumen = leerResumen(respuesta.datos, reservaId);
      if (!resumen) throw new Error("La API devolvió una reserva incompleta.");
      // La API valida la propiedad al guardar. El detalle de reserva puede no incluir bien.propietarioId.
      const datos = respuesta.datos as Record<string, unknown>;
      const bien =
        datos.bien && typeof datos.bien === "object"
          ? (datos.bien as Record<string, unknown>)
          : {};
      const propietarioId =
        (datos.arrendador && typeof datos.arrendador === "object"
          ? (datos.arrendador as Record<string, unknown>).id
          : undefined) ??
        bien.propietarioId ??
        bien.arrendadorId ??
        datos.arrendadorId;
      vista =
        propietarioId && propietarioId !== usuario.id ? (
          <EstadoDePagina
            tipo="sin-permiso"
            titulo="No tienes acceso a esta devolución."
            mensaje="Solo el propietario del bien puede registrarla."
          />
        ) : (
          <FormularioDevolucion resumen={resumen} />
        );
    }
  }
  return (
    <>
      <NavegacionSuperior
        rol="arrendador"
        nombreUsuario={usuario.nombreUsuario}
        onCerrarSesion={cerrarSesion}
      />
      <main className="flex-1">
        <Contenedor className="py-espacio-7 md:py-espacio-9">
          {vista}
          <div className="mt-espacio-5">
            <Link
              href="/reservas-recibidas"
              className={clasesBoton({ jerarquia: "terciario" })}
            >
              Volver a reservas recibidas
            </Link>
          </div>
        </Contenedor>
      </main>
      <PieDePagina />
    </>
  );
}
