"use client";
import { Boton, EstadoDePagina } from "@/components/ui";
export default function ErrorDevolucion({ reset }: { error: Error; reset: () => void }) { return <main className="mx-auto w-full max-w-4xl p-8"><EstadoDePagina tipo="error" titulo="No pudimos cargar la reserva." accion={<Boton onClick={reset} jerarquia="secundario">Reintentar</Boton>} /></main>; }
