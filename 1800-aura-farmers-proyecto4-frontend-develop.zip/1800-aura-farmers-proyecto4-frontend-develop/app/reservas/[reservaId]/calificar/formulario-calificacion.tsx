"use client";

import Link from "next/link";
import { unstable_rethrow } from "next/navigation";
import { useId, useRef, useState, useTransition, type FormEvent, type ReactNode } from "react";
import {
  AreaDeTexto,
  Alerta,
  Boton,
  Calificacion,
  DialogoDeConfirmacion,
  clasesBoton,
} from "@/components/ui";
import {
  LIMITE_COMENTARIO,
  armarPayload,
  clasificarErrorResenas,
  contarCaracteres,
  errorComentario,
  esPuntuacionValida,
  normalizarComentario,
  puedeEnviar,
  type CalificacionFormulario,
  type CrearResenasPayload,
  type ErrorResenas,
  type TipoErrorResenas,
} from "@/lib/resenas";

/** Resultado de enviar la reseña. `status` es `null` si falló la red. */
export type ResultadoEnvio = { ok: true } | { ok: false; status: number | null };

type FormularioCalificacionProps = {
  reservaId: string;
  /** Nombre de usuario del arrendador, para la pregunta de su sección. */
  nombreArrendador: string;
  /** Resumen de la reserva (`TarjetaResumenReserva`), arriba del formulario. */
  resumen: ReactNode;
  /**
   * Envía la reseña. Con éxito, quien la implementa navega a la reserva: si es
   * una server action que llama a `redirect()`, la promesa se rechaza con la
   * redirección de Next, que este formulario deja pasar al router.
   */
  enviar: (payload: CrearResenasPayload) => Promise<ResultadoEnvio>;
  /**
   * Bloqueo que ya se conoce al cargar, antes de cualquier envío: 422 cuando
   * la reserva no está finalizada o venció el plazo. El aviso va arriba, entre
   * el resumen y las secciones (frame «Fuera de plazo» de Figma), los campos
   * quedan deshabilitados y no se puede enviar. Solo admite los códigos que
   * bloquean, así nunca convive con un error de envío.
   */
  errorInicial?: 409 | 422;
};

const SIN_CALIFICAR: CalificacionFormulario = { puntuacion: 0, comentario: "" };

/** El contador cuenta igual que la validación y el backend: code points, sin los espacios de los extremos. */
const contarComoBackend = (texto: string) => contarCaracteres(normalizarComentario(texto));

/**
 * Avisos de Figma para las respuestas que bloquean el formulario (409 y 422).
 * Incluyen el mensaje exacto de Jira (como título en 409, como texto en 422).
 * Tras un envío van sobre los botones, como los demás errores del servidor; si
 * el bloqueo se conoce al cargar (`errorInicial`), van arriba.
 */
const AVISO_BLOQUEO: Partial<
  Record<TipoErrorResenas, { tono: "advertencia" | "error"; titulo: string; mensaje: string }>
> = {
  "ya-calificada": {
    tono: "advertencia",
    titulo: "Ya calificaste esta reserva.",
    mensaje: "Las reseñas no se pueden editar ni eliminar.",
  },
  "fuera-de-plazo": {
    tono: "error",
    titulo: "No puedes calificar esta reserva",
    mensaje:
      "Solo puedes calificar reservas finalizadas dentro de los 14 días posteriores a la devolución.",
  },
};

/**
 * Formulario de calificación de una reserva finalizada (FE-15.1): estrellas y
 * comentario opcional para el bien y para el arrendador, confirmación antes de
 * enviar y los mensajes de cada respuesta del servidor. No conoce el backend:
 * recibe `enviar`.
 */
export function FormularioCalificacion({
  reservaId,
  nombreArrendador,
  resumen,
  enviar,
  errorInicial,
}: FormularioCalificacionProps) {
  const [bien, setBien] = useState<CalificacionFormulario>(SIN_CALIFICAR);
  const [arrendador, setArrendador] = useState<CalificacionFormulario>(SIN_CALIFICAR);
  const [confirmando, setConfirmando] = useState(false);
  const [enviando, setEnviando] = useState(false);
  // Bloqueo conocido al cargar: no cambia durante la vida del formulario.
  const [bloqueoInicial] = useState<ErrorResenas | null>(() =>
    errorInicial === undefined ? null : clasificarErrorResenas(errorInicial),
  );
  // Error de un envío real (respuesta del servidor o red).
  const [error, setError] = useState<ErrorResenas | null>(null);
  // Candado síncrono: el estado de React no alcanza a frenar dos clics seguidos.
  const enviandoAhora = useRef(false);
  // Las server actions se invocan dentro de una transición (convención de
  // Next): así la redirección de `redirect()` llega al router en vez de quedar
  // como un error suelto.
  const [, startTransition] = useTransition();

  const formulario = { bien, arrendador };
  const bloqueado = Boolean(bloqueoInicial || error?.bloqueante);
  const habilitado = puedeEnviar({ formulario, enviando, bloqueado });
  const faltanPuntuaciones =
    !esPuntuacionValida(bien.puntuacion) || !esPuntuacionValida(arrendador.puntuacion);
  const aviso = error ? AVISO_BLOQUEO[error.tipo] : undefined;
  const avisoInicial = bloqueoInicial ? AVISO_BLOQUEO[bloqueoInicial.tipo] : undefined;

  function pedirConfirmacion(evento: FormEvent<HTMLFormElement>) {
    evento.preventDefault();
    if (habilitado) setConfirmando(true);
  }

  function confirmar() {
    const payload = armarPayload(formulario);
    setConfirmando(false);
    if (!payload || enviandoAhora.current || bloqueado) return;

    enviandoAhora.current = true;
    setEnviando(true);
    setError(null);
    startTransition(async () => {
      let resultado: ResultadoEnvio;
      try {
        resultado = await enviar(payload);
      } catch (excepcion) {
        // Una redirección de Next (éxito o sesión vencida) no es un error de
        // red: se relanza para que el router navegue.
        unstable_rethrow(excepcion);
        resultado = { ok: false, status: null };
      }
      // Con éxito se queda en «Procesando…» hasta que la página navegue.
      if (resultado.ok) return;

      setError(clasificarErrorResenas(resultado.status));
      setEnviando(false);
      enviandoAhora.current = false;
    });
  }

  return (
    <>
      <form
        noValidate
        onSubmit={pedirConfirmacion}
        className="flex w-full flex-col gap-5 md:max-w-[720px]"
      >
        {resumen}

        {/* Bloqueo conocido al cargar: arriba, visible antes de tocar el formulario (Figma «Fuera de plazo»). */}
        {avisoInicial && (
          <Alerta tono={avisoInicial.tono} titulo={avisoInicial.titulo}>
            {avisoInicial.mensaje}
          </Alerta>
        )}

        <SeccionCalificacion
          titulo="El bien"
          pregunta="¿Cómo estaba el bien y se ajustó a la descripción?"
          etiquetaEstrellas="Calificación del bien"
          sufijoAccesible="sobre el bien"
          valor={bien}
          onCambiar={setBien}
          deshabilitada={Boolean(bloqueoInicial)}
        />
        <SeccionCalificacion
          titulo="El arrendador"
          pregunta={`¿Cómo fue el trato y la entrega con ${nombreArrendador}?`}
          etiquetaEstrellas="Calificación del arrendador"
          sufijoAccesible="sobre el arrendador"
          valor={arrendador}
          onCambiar={setArrendador}
          deshabilitada={Boolean(bloqueoInicial)}
        />

        {/*
          Errores del servidor sobre los botones (Jira), un solo aviso a la vez
          para que se anuncie una vez. 409 y 422 conservan el tono y el título de
          Figma; los demás, la alerta de error con el mensaje.
        */}
        {aviso ? (
          <Alerta tono={aviso.tono} titulo={aviso.titulo}>
            {aviso.mensaje}
          </Alerta>
        ) : (
          error && <Alerta tono="error">{error.mensaje}</Alerta>
        )}

        <div className="flex gap-espacio-3 md:justify-end">
          <Link
            href={`/reservas/${encodeURIComponent(reservaId)}`}
            className={clasesBoton({ jerarquia: "secundario", className: "flex-1 md:flex-none" })}
          >
            Cancelar
          </Link>
          <Boton
            type="submit"
            disabled={!habilitado}
            cargando={enviando}
            className="flex-1 md:flex-none"
          >
            Enviar reseña
          </Boton>
        </div>

        {faltanPuntuaciones && !bloqueado && (
          <p className="texto-cuerpo-pequeno text-texto-secundario">
            Elige una puntuación para el bien y otra para el arrendador.
          </p>
        )}
      </form>

      <DialogoDeConfirmacion
        abierto={confirmando}
        titulo="¿Enviar tu reseña?"
        mensaje="No podrás editarla."
        textoConfirmar="Enviar"
        onConfirmar={confirmar}
        onCancelar={() => setConfirmando(false)}
      />
    </>
  );
}

function SeccionCalificacion({
  titulo,
  pregunta,
  etiquetaEstrellas,
  sufijoAccesible,
  valor,
  onCambiar,
  deshabilitada = false,
}: {
  titulo: string;
  pregunta: string;
  /** Nombre accesible del grupo de estrellas, por ejemplo «Calificación del bien». */
  etiquetaEstrellas: string;
  /** Distingue los dos campos «Comentario (opcional)» para lectores de pantalla. */
  sufijoAccesible: string;
  valor: CalificacionFormulario;
  onCambiar: (valor: CalificacionFormulario) => void;
  /**
   * La reserva no se puede calificar: estrellas de solo lectura (`Calificacion`
   * sin `onCambiar`, su API existente) y comentario deshabilitado.
   */
  deshabilitada?: boolean;
}) {
  const idTitulo = useId();
  const error = errorComentario(valor.comentario);
  return (
    <section
      aria-labelledby={idTitulo}
      className="flex flex-col gap-espacio-3 border border-borde-default bg-fondo-superficie p-espacio-5"
    >
      <h2 id={idTitulo} className="texto-h4 text-texto-primario">
        {titulo}
      </h2>
      <p className="texto-cuerpo-pequeno text-texto-secundario">{pregunta}</p>
      <Calificacion
        valor={valor.puntuacion}
        etiqueta={etiquetaEstrellas}
        onCambiar={deshabilitada ? undefined : (puntuacion) => onCambiar({ ...valor, puntuacion })}
      />
      <AreaDeTexto
        disabled={deshabilitada}
        etiqueta={
          <>
            Comentario (opcional) <span className="solo-lector">{sufijoAccesible}</span>
          </>
        }
        placeholder="Cuéntanos cómo fue tu experiencia…"
        limite={LIMITE_COMENTARIO}
        contarCaracteres={contarComoBackend}
        value={valor.comentario}
        onChange={(evento) => onCambiar({ ...valor, comentario: evento.target.value })}
        error={error ?? undefined}
      />
    </section>
  );
}
