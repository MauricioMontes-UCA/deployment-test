import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import type { ReactNode } from "react";
import { cerrarSesion } from "@/app/actions/auth";
import { enviarResenas } from "@/app/actions/resenas";
import {
  Contenedor,
  EncabezadoDePagina,
  EstadoDePagina,
  NavegacionSuperior,
  PieDePagina,
  clasesBoton,
} from "@/components/ui";
import { cargarPantalla, type UsuarioActual } from "./datos";
import { FormularioCalificacion } from "./formulario-calificacion";
import { TarjetaResumenReserva } from "./tarjeta-resumen-reserva";

export const metadata: Metadata = { title: "Califica tu experiencia · Arre" };

/** Navegación, contenido con los márgenes de Figma y pie de página. */
function Marco({ usuario, children }: { usuario: UsuarioActual; children: ReactNode }) {
  return (
    <>
      <NavegacionSuperior
        rol={usuario.rol === "ARRENDADOR" ? "arrendador" : "arrendatario"}
        nombreUsuario={usuario.nombreUsuario}
        onCerrarSesion={cerrarSesion}
      />
      <main className="flex-1">
        <Contenedor className="flex flex-col gap-5 pt-espacio-5 pb-espacio-7 md:gap-espacio-6 md:pt-espacio-7 md:pb-espacio-9">
          {children}
        </Contenedor>
      </main>
      <PieDePagina />
    </>
  );
}

const irAlInicio = (
  <Link href="/" className={clasesBoton({ jerarquia: "secundario" })}>
    Ir al inicio
  </Link>
);

/** FE-15.1: el arrendatario califica el bien y al arrendador de una reserva finalizada. */
export default async function CalificarReservaPage({
  params,
}: PageProps<"/reservas/[reservaId]/calificar">) {
  const { reservaId } = await params;
  const pantalla = await cargarPantalla(reservaId);

  switch (pantalla.tipo) {
    case "sin-sesion":
      // Como en el resto de la app (PR #2): una página no puede borrar cookies,
      // así que /sesion-vencida las borra, revoca la sesión y lleva al login.
      redirect("/sesion-vencida");

    case "sin-permiso":
      return (
        <Marco usuario={pantalla.usuario}>
          <EstadoDePagina
            tipo="sin-permiso"
            titulo="No tienes permiso para ver esta pantalla."
            mensaje="Solo el arrendatario de la reserva puede calificarla."
            accion={irAlInicio}
          />
        </Marco>
      );

    case "no-encontrada":
      return (
        <Marco usuario={pantalla.usuario}>
          <EstadoDePagina
            tipo="no-encontrado"
            titulo="No encontramos esa reserva."
            mensaje="Revisa el enlace e intenta de nuevo."
            accion={irAlInicio}
          />
        </Marco>
      );

    case "lista": {
      const { usuario, datos } = pantalla;
      return (
        <Marco usuario={usuario}>
          <EncabezadoDePagina
            titulo="Califica tu experiencia"
            descripcion="Tu reseña aparece en el detalle del bien y ayuda a otros arrendatarios a decidir. No podrás editarla después."
          />
          <FormularioCalificacion
            reservaId={datos.reservaId}
            nombreArrendador={datos.arrendador}
            resumen={
              <TarjetaResumenReserva
                titulo={datos.titulo}
                foto={datos.foto}
                fechaInicio={datos.fechaInicio}
                fechaFin={datos.fechaFin}
                finalizadaEl={datos.finalizadaEl}
                arrendador={datos.arrendador}
              />
            }
            enviar={enviarResenas.bind(null, datos.reservaId)}
            // Reserva no finalizada o fuera de plazo: el mismo aviso que daría el 422, antes de llenar nada.
            errorInicial={datos.elegible ? undefined : 422}
          />
        </Marco>
      );
    }
  }
}
