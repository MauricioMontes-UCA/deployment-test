import { render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { TarjetaResumenReserva, formatearDia } from "../tarjeta-resumen-reserva";

const base = {
  titulo: "Taladro industrial Bosch",
  fechaInicio: "2026-11-02",
  fechaFin: "2026-11-04",
  arrendador: "jose_r",
};

describe("formatearDia", () => {
  it("convierte AAAA-MM-DD en DD/MM/AAAA sin correr el día", () => {
    expect(formatearDia("2026-11-02")).toBe("02/11/2026");
    expect(formatearDia("2027-01-01")).toBe("01/01/2027");
  });
});

describe("TarjetaResumenReserva", () => {
  it("muestra el bien, las fechas y el arrendador", () => {
    render(<TarjetaResumenReserva {...base} />);
    expect(screen.getByRole("heading", { level: 2, name: "Taladro industrial Bosch" })).toBeInTheDocument();
    expect(screen.getByText("02/11/2026 → 04/11/2026")).toBeInTheDocument();
    expect(screen.getByText("Arrendador: jose_r")).toBeInTheDocument();
  });

  it("sin fecha de finalización no inventa «Finalizada el…»", () => {
    render(<TarjetaResumenReserva {...base} finalizadaEl={null} />);
    expect(screen.queryByText(/Finalizada el/)).not.toBeInTheDocument();
  });

  it("con fecha de finalización la agrega a las fechas, como en Figma", () => {
    render(<TarjetaResumenReserva {...base} finalizadaEl="2026-11-04" />);
    expect(
      screen.getByText("02/11/2026 → 04/11/2026 · Finalizada el 04/11/2026"),
    ).toBeInTheDocument();
  });

  it("con foto la muestra con el título como texto alternativo", () => {
    render(<TarjetaResumenReserva {...base} foto="/uploads/taladro.jpg" />);
    expect(screen.getByRole("img", { name: "Taladro industrial Bosch" })).toBeInTheDocument();
  });

  it("sin foto muestra el reemplazo del design system", () => {
    render(<TarjetaResumenReserva {...base} foto={null} />);
    expect(screen.getByText("Foto no disponible")).toBeInTheDocument();
  });
});
