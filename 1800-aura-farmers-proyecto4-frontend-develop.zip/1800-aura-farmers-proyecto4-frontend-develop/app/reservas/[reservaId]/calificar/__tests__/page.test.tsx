import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, describe, expect, it, vi } from "vitest";
import { usuarioDePrueba } from "@/pruebas/usuario";
import type { PantallaCalificacion } from "../datos";

const datos = vi.hoisted(() => ({ cargarPantalla: vi.fn() }));
vi.mock("../datos", () => datos);

const accion = vi.hoisted(() => ({ enviarResenas: vi.fn() }));
vi.mock("@/app/actions/resenas", () => accion);

const auth = vi.hoisted(() => ({ cerrarSesion: vi.fn() }));
vi.mock("@/app/actions/auth", () => auth);

vi.mock("next/navigation", async (importOriginal) => ({
  ...(await importOriginal<typeof import("next/navigation")>()),
  redirect: vi.fn((url: string) => {
    throw new Error(`REDIRECT:${url}`);
  }),
}));

const { default: CalificarReservaPage } = await import("../page");

const RESERVA = "5a3f2c10-8d4e-4b1a-9c7e-1f2a3b4c5d6e";
const usuario = usuarioDePrueba();

async function renderizar(pantalla: PantallaCalificacion, reservaId = RESERVA) {
  datos.cargarPantalla.mockResolvedValue(pantalla);
  render(await CalificarReservaPage({ params: Promise.resolve({ reservaId }) } as PageProps<"/reservas/[reservaId]/calificar">));
}

afterEach(() => {
  vi.clearAllMocks();
});

const datosLista = {
  reservaId: RESERVA,
  fechaInicio: "2026-11-02",
  fechaFin: "2026-11-04",
  finalizadaEl: "2026-11-04",
  titulo: "Taladro industrial Bosch",
  foto: "/uploads/bienes/principal.jpg",
  arrendador: "jose_r",
  elegible: true,
};

const PLAZO =
  "Solo puedes calificar reservas finalizadas dentro de los 14 días posteriores a la devolución.";

describe("CalificarReservaPage", () => {
  it("con datos reales muestra encabezado, resumen y formulario", async () => {
    await renderizar({ tipo: "lista", usuario, datos: datosLista });

    expect(datos.cargarPantalla).toHaveBeenCalledWith(RESERVA);
    expect(screen.getByRole("heading", { level: 1, name: "Califica tu experiencia" })).toBeInTheDocument();
    expect(screen.getByRole("heading", { name: "Taladro industrial Bosch" })).toBeInTheDocument();
    expect(screen.getByText("02/11/2026 → 04/11/2026 · Finalizada el 04/11/2026")).toBeInTheDocument();
    expect(screen.queryByText(/RSV-/)).not.toBeInTheDocument();
    expect(screen.getByText("¿Cómo fue el trato y la entrega con jose_r?")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Enviar reseña" })).toBeDisabled();
    expect(screen.queryByText(PLAZO)).not.toBeInTheDocument();
    expect(screen.getByRole("link", { name: "Cancelar" })).toHaveAttribute("href", `/reservas/${RESERVA}`);
    // Navegación del arrendatario con su nombre (menú de escritorio y móvil).
    expect(screen.getAllByText("ana_m").length).toBeGreaterThan(0);
  });

  it("una reserva no elegible muestra el aviso del 422 antes de llenar nada y bloquea el envío", async () => {
    await renderizar({ tipo: "lista", usuario, datos: { ...datosLista, finalizadaEl: null, elegible: false } });

    const aviso = screen.getByRole("alert");
    expect(aviso).toHaveTextContent("No puedes calificar esta reserva");
    expect(aviso).toHaveTextContent(PLAZO);
    // Arriba, como en el frame «Fuera de plazo»: tras la tarjeta y antes de las secciones.
    const despues = (a: Node, b: Node) => Boolean(a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING);
    expect(despues(screen.getByRole("heading", { name: "Taladro industrial Bosch" }), aviso)).toBe(true);
    expect(despues(aviso, screen.getByRole("region", { name: "El bien" }))).toBe(true);
    expect(screen.getAllByRole("alert")).toHaveLength(1);
    expect(screen.getByRole("textbox", { name: "Comentario (opcional) sobre el bien" })).toBeDisabled();
    expect(screen.getByRole("button", { name: "Enviar reseña" })).toBeDisabled();
    expect(screen.queryByText(/Finalizada el/)).not.toBeInTheDocument();
    expect(screen.queryByText("Elige una puntuación para el bien y otra para el arrendador.")).not.toBeInTheDocument();
  });

  it("sin sesión o con la sesión rechazada pasa por /sesion-vencida (PR #2), sin pintar nada", async () => {
    await expect(renderizar({ tipo: "sin-sesion" })).rejects.toThrow("REDIRECT:/sesion-vencida");
    expect(screen.queryByText("Tu sesión expiró.")).not.toBeInTheDocument();
  });

  it("«Cerrar sesión» del menú del usuario llama a la acción compartida cerrarSesion", async () => {
    await renderizar({ tipo: "lista", usuario, datos: datosLista });
    // Botón del usuario (escritorio): abre el menú con «Cerrar sesión».
    const menu = screen.getAllByRole("button").find((boton) => boton.getAttribute("aria-haspopup") === "menu")!;
    await userEvent.click(menu);
    await userEvent.click(screen.getByRole("menuitem", { name: "Cerrar sesión" }));
    expect(auth.cerrarSesion).toHaveBeenCalledOnce();
  });

  it("el rol Arrendador ve el estado sin permiso de Figma", async () => {
    await renderizar({ tipo: "sin-permiso", usuario: usuarioDePrueba({ id: "u2", nombreUsuario: "jose_r", rol: "ARRENDADOR" }) });
    expect(screen.getByRole("heading", { name: "No tienes permiso para ver esta pantalla." })).toBeInTheDocument();
    expect(screen.getByText("Solo el arrendatario de la reserva puede calificarla.")).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "Ir al inicio" })).toHaveAttribute("href", "/");
    expect(screen.queryByRole("button", { name: "Enviar reseña" })).not.toBeInTheDocument();
  });

  it("una reserva inexistente o de otro muestra «No encontramos esa reserva.»", async () => {
    await renderizar({ tipo: "no-encontrada", usuario });
    expect(screen.getByRole("heading", { name: "No encontramos esa reserva." })).toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "Enviar reseña" })).not.toBeInTheDocument();
  });

  it("pasa el id tal cual a la carga, que decide si es válido", async () => {
    await renderizar({ tipo: "no-encontrada", usuario }, "no-es-uuid");
    expect(datos.cargarPantalla).toHaveBeenCalledWith("no-es-uuid");
    expect(screen.getByRole("heading", { name: "No encontramos esa reserva." })).toBeInTheDocument();
  });

  it("un error inesperado de carga se propaga a error.tsx", async () => {
    datos.cargarPantalla.mockRejectedValue(new Error("reservas/:id respondió 500."));
    await expect(
      CalificarReservaPage({ params: Promise.resolve({ reservaId: RESERVA }) } as PageProps<"/reservas/[reservaId]/calificar">),
    ).rejects.toThrow("respondió 500");
  });
});
