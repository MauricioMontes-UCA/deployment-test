import { fireEvent, render, screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { redirect } from "next/navigation";
import { Component, type ReactNode } from "react";
import { afterEach, beforeAll, beforeEach, describe, expect, it, vi, type MockInstance } from "vitest";
import type { CrearResenasPayload } from "@/lib/resenas";
import { FormularioCalificacion, type ResultadoEnvio } from "../formulario-calificacion";
import { TarjetaResumenReserva } from "../tarjeta-resumen-reserva";

const RESERVA = "5a3f2c10-8d4e-4b1a-9c7e-1f2a3b4c5d6e";
const GENERICO = "No pudimos enviar tu reseña. Intenta de nuevo.";
const AYUDA = "Elige una puntuación para el bien y otra para el arrendador.";

beforeAll(() => {
  // jsdom no implementa showModal/close de <dialog>; se simula lo mínimo.
  HTMLDialogElement.prototype.showModal ??= function (this: HTMLDialogElement) {
    this.setAttribute("open", "");
  };
  HTMLDialogElement.prototype.close ??= function (this: HTMLDialogElement) {
    this.removeAttribute("open");
  };
});

// Ninguna prueba debe dejar advertencias de React en la consola.
let errorDeConsola: MockInstance<typeof console.error>;
beforeEach(() => {
  errorDeConsola = vi.spyOn(console, "error");
});
afterEach(() => {
  expect(errorDeConsola).not.toHaveBeenCalled();
  errorDeConsola.mockRestore();
});

type Enviar = (payload: CrearResenasPayload) => Promise<ResultadoEnvio>;

function renderizar(enviar: Enviar = vi.fn<Enviar>(async () => ({ ok: true }))) {
  render(
    <FormularioCalificacion
      reservaId={RESERVA}
      nombreArrendador="jose_r"
      resumen={
        <TarjetaResumenReserva
          titulo="Taladro industrial Bosch"
          fechaInicio="2026-11-02"
          fechaFin="2026-11-04"
          arrendador="jose_r"
        />
      }
      enviar={enviar}
    />,
  );
  return enviar;
}

/** Promesa que la prueba resuelve cuando quiere, para ver el estado «enviando». */
function diferida() {
  let resolver!: (resultado: ResultadoEnvio) => void;
  const promesa = new Promise<ResultadoEnvio>((r) => {
    resolver = r;
  });
  return { promesa, resolver };
}

const grupo = (nombre: string) => screen.getByRole("radiogroup", { name: nombre });
const estrellas = (n: number) => (n === 1 ? "1 estrella" : `${n} estrellas`);

async function calificar(bien: number, arrendador: number) {
  await userEvent.click(within(grupo("Calificación del bien")).getByRole("radio", { name: estrellas(bien) }));
  await userEvent.click(
    within(grupo("Calificación del arrendador")).getByRole("radio", { name: estrellas(arrendador) }),
  );
}

const comentarioBien = () => screen.getByRole("textbox", { name: "Comentario (opcional) sobre el bien" });
const comentarioArrendador = () =>
  screen.getByRole("textbox", { name: "Comentario (opcional) sobre el arrendador" });
const botonEnviar = () => screen.getByRole("button", { name: "Enviar reseña" });
const dialogo = () => screen.queryByRole("dialog", { name: "¿Enviar tu reseña?" });

async function enviarYConfirmar() {
  await userEvent.click(botonEnviar());
  await userEvent.click(within(dialogo()!).getByRole("button", { name: "Enviar" }));
}

describe("FormularioCalificacion", () => {
  describe("estado inicial", () => {
    it("empieza sin estrellas, con contadores en 0/500 y «Enviar reseña» deshabilitado", () => {
      renderizar();
      for (const nombre of ["Calificación del bien", "Calificación del arrendador"]) {
        const radios = within(grupo(nombre)).getAllByRole("radio");
        expect(radios).toHaveLength(5);
        for (const radio of radios) expect(radio).not.toBeChecked();
      }
      expect(screen.getAllByText("0/500")).toHaveLength(2);
      expect(comentarioBien()).toHaveValue("");
      expect(comentarioBien()).toHaveAttribute("placeholder", "Cuéntanos cómo fue tu experiencia…");
      expect(botonEnviar()).toBeDisabled();
      expect(screen.getByText(AYUDA)).toBeInTheDocument();
      expect(screen.queryByRole("alert")).not.toBeInTheDocument();
      expect(dialogo()).not.toBeInTheDocument();
    });

    it("muestra el resumen de la reserva y la pregunta con el arrendador", () => {
      renderizar();
      expect(screen.getByRole("heading", { name: "Taladro industrial Bosch" })).toBeInTheDocument();
      expect(screen.getByRole("region", { name: "El bien" })).toBeInTheDocument();
      expect(screen.getByRole("region", { name: "El arrendador" })).toBeInTheDocument();
      expect(screen.getByText("¿Cómo fue el trato y la entrega con jose_r?")).toBeInTheDocument();
    });
  });

  describe("puntuaciones", () => {
    it("con una sola puntuación sigue deshabilitado", async () => {
      renderizar();
      await userEvent.click(within(grupo("Calificación del bien")).getByRole("radio", { name: "4 estrellas" }));
      expect(botonEnviar()).toBeDisabled();
      expect(screen.getByText(AYUDA)).toBeInTheDocument();
    });

    it("con las dos puntuaciones se habilita y desaparece la ayuda", async () => {
      renderizar();
      await calificar(4, 5);
      expect(within(grupo("Calificación del bien")).getByRole("radio", { name: "4 estrellas" })).toBeChecked();
      expect(within(grupo("Calificación del arrendador")).getByRole("radio", { name: "5 estrellas" })).toBeChecked();
      expect(botonEnviar()).toBeEnabled();
      expect(screen.queryByText(AYUDA)).not.toBeInTheDocument();
    });

    it("las estrellas se manejan con las flechas del teclado", async () => {
      renderizar();
      const tres = within(grupo("Calificación del bien")).getByRole("radio", { name: "3 estrellas" });
      await userEvent.click(tres);
      expect(tres).toHaveFocus();
      await userEvent.keyboard("{ArrowRight}");
      expect(within(grupo("Calificación del bien")).getByRole("radio", { name: "4 estrellas" })).toBeChecked();
      await userEvent.keyboard("{ArrowLeft}{ArrowLeft}");
      expect(within(grupo("Calificación del bien")).getByRole("radio", { name: "2 estrellas" })).toBeChecked();
    });
  });

  describe("comentarios", () => {
    it("son opcionales: sin comentarios se envían solo las puntuaciones", async () => {
      const enviar = renderizar();
      await calificar(3, 2);
      await enviarYConfirmar();
      expect(enviar).toHaveBeenCalledExactlyOnceWith({ bien: { puntuacion: 3 }, arrendador: { puntuacion: 2 } });
    });

    it("al pasar de 500 muestra al instante el mensaje bajo el campo y bloquea el envío", async () => {
      renderizar();
      await calificar(4, 5);
      await userEvent.click(comentarioBien());
      await userEvent.paste("a".repeat(512));

      expect(comentarioBien()).toHaveValue("a".repeat(512));
      expect(screen.getByText("512/500")).toHaveClass("text-texto-error");
      expect(comentarioBien()).toHaveAttribute("aria-invalid", "true");
      expect(comentarioBien()).toHaveAccessibleDescription("Tu comentario supera los 500 caracteres por 12.");
      expect(botonEnviar()).toBeDisabled();
    });

    it("al volver a 500 desaparece el error y se puede enviar", async () => {
      renderizar();
      await calificar(4, 5);
      await userEvent.click(comentarioArrendador());
      await userEvent.paste("a".repeat(501));
      expect(botonEnviar()).toBeDisabled();

      await userEvent.type(comentarioArrendador(), "{Backspace}");
      expect(screen.getByText("500/500")).not.toHaveClass("text-texto-error");
      expect(comentarioArrendador()).not.toHaveAttribute("aria-invalid");
      expect(botonEnviar()).toBeEnabled();
    });

    it("el contador cuenta como la validación: emojis por code point y sin espacios de los extremos", async () => {
      renderizar();
      await userEvent.type(comentarioBien(), "  😀👍🏽  ");
      expect(screen.getByText("3/500")).toBeInTheDocument();
    });

    it("500 emojis caben (String.length daría 1000) y 501 se pasan por 1", async () => {
      renderizar();
      await calificar(4, 5);
      await userEvent.click(comentarioBien());
      await userEvent.paste("😀".repeat(500));
      expect(screen.getByText("500/500")).toBeInTheDocument();
      expect(botonEnviar()).toBeEnabled();

      await userEvent.paste("😀");
      expect(screen.getByText("501/500")).toBeInTheDocument();
      expect(comentarioBien()).toHaveAccessibleDescription("Tu comentario supera los 500 caracteres por 1.");
      expect(botonEnviar()).toBeDisabled();
    });

    it("los dos campos tienen nombres accesibles distintos", () => {
      renderizar();
      expect(comentarioBien()).not.toBe(comentarioArrendador());
    });
  });

  describe("confirmación y envío", () => {
    it("«Enviar reseña» abre la confirmación sin enviar todavía", async () => {
      const enviar = renderizar();
      await calificar(4, 5);
      await userEvent.click(botonEnviar());
      const confirmacion = dialogo()!;
      expect(confirmacion).toBeInTheDocument();
      expect(confirmacion).toHaveAccessibleDescription("No podrás editarla.");
      expect(within(confirmacion).getByRole("button", { name: "Cancelar" })).toBeInTheDocument();
      expect(enviar).not.toHaveBeenCalled();
    });

    it("cancelar en el diálogo no envía y conserva lo escrito", async () => {
      const enviar = renderizar();
      await calificar(4, 5);
      await userEvent.type(comentarioBien(), "Funcionó perfecto.");
      await userEvent.click(botonEnviar());
      await userEvent.click(within(dialogo()!).getByRole("button", { name: "Cancelar" }));

      expect(dialogo()).not.toBeInTheDocument();
      expect(enviar).not.toHaveBeenCalled();
      expect(comentarioBien()).toHaveValue("Funcionó perfecto.");
      expect(botonEnviar()).toBeEnabled();
    });

    it("confirmar llama a enviar una vez con el cuerpo exacto, comentarios recortados", async () => {
      const enviar = renderizar();
      await calificar(4, 5);
      await userEvent.type(comentarioBien(), "  Funcionó perfecto y venía con su maletín y brocas. ");
      await userEvent.type(comentarioArrendador(), "   ");
      await enviarYConfirmar();

      expect(enviar).toHaveBeenCalledExactlyOnceWith({
        bien: { puntuacion: 4, comentario: "Funcionó perfecto y venía con su maletín y brocas." },
        arrendador: { puntuacion: 5 },
      });
    });

    it("mientras envía muestra «Procesando…», queda ocupado y no permite otro envío", async () => {
      const { promesa, resolver } = diferida();
      const enviar = renderizar(vi.fn<Enviar>(() => promesa));
      await calificar(4, 5);
      await enviarYConfirmar();

      const procesando = screen.getByRole("button", { name: "Procesando…" });
      expect(procesando).toBeDisabled();
      expect(procesando).toHaveAttribute("aria-busy", "true");
      expect(dialogo()).not.toBeInTheDocument();

      await userEvent.click(procesando);
      fireEvent.submit(procesando.closest("form")!);
      expect(dialogo()).not.toBeInTheDocument();
      expect(enviar).toHaveBeenCalledTimes(1);

      resolver({ ok: true });
    });

    it("dos clics seguidos en «Enviar» del diálogo envían una sola vez", async () => {
      const { promesa, resolver } = diferida();
      const enviar = renderizar(vi.fn<Enviar>(() => promesa));
      await calificar(4, 5);
      await userEvent.click(botonEnviar());
      const confirmar = within(dialogo()!).getByRole("button", { name: "Enviar" });

      fireEvent.click(confirmar);
      fireEvent.click(confirmar);

      expect(enviar).toHaveBeenCalledTimes(1);
      expect(await screen.findByRole("button", { name: "Procesando…" })).toBeDisabled();
      // React entrelaza las transiciones asíncronas pendientes: hay que cerrarla
      // para no frenar las de las pruebas siguientes.
      resolver({ ok: true });
    });

    it("la redirección de éxito de la server action llega al router y no se muestra como error de red", async () => {
      // Con `redirect()`, Next rechaza la promesa de la acción con NEXT_REDIRECT y
      // espera que llegue a su RedirectBoundary. Aquí un límite de errores la recibe.
      class Limite extends Component<{ children: ReactNode }, { error: unknown }> {
        state = { error: null };
        static getDerivedStateFromError(error: unknown) {
          return { error };
        }
        render() {
          return this.state.error ? <p>Redirigiendo: {String((this.state.error as Error).message)}</p> : this.props.children;
        }
      }
      // React informa en consola el error que captura un límite: aquí es esperado.
      errorDeConsola.mockImplementation(() => {});
      const enviar = vi.fn<Enviar>(async () => redirect(`/reservas/${RESERVA}?resena=enviada`));
      render(
        <Limite>
          <FormularioCalificacion reservaId={RESERVA} nombreArrendador="jose_r" resumen={null} enviar={enviar} />
        </Limite>,
      );
      await calificar(4, 5);
      await enviarYConfirmar();

      expect(await screen.findByText("Redirigiendo: NEXT_REDIRECT")).toBeInTheDocument();
      expect(screen.queryByText(GENERICO)).not.toBeInTheDocument();
      expect(enviar).toHaveBeenCalledTimes(1);
      errorDeConsola.mockClear();
    });

    it("con éxito no muestra errores y se queda en «Procesando…» hasta que la página navegue", async () => {
      const enviar = renderizar();
      await calificar(5, 5);
      await enviarYConfirmar();

      expect(enviar).toHaveBeenCalledTimes(1);
      expect(await screen.findByRole("button", { name: "Procesando…" })).toBeDisabled();
      expect(screen.queryByRole("alert")).not.toBeInTheDocument();
    });
  });

  describe("errores recuperables", () => {
    it.each([
      [400, "Revisa la puntuación y el comentario."],
      [403, "No tienes permiso para calificar esta reserva."],
      [404, "No encontramos esa reserva."],
      [500, GENERICO],
      [503, GENERICO],
    ])("%i muestra su mensaje sobre los botones y deja reintentar con los mismos datos", async (status, mensaje) => {
      const enviar = vi
        .fn<Enviar>()
        .mockResolvedValueOnce({ ok: false, status })
        .mockResolvedValueOnce({ ok: true });
      renderizar(enviar);
      await calificar(4, 5);
      await userEvent.type(comentarioBien(), "Muy bien.");
      await enviarYConfirmar();

      const alerta = await screen.findByRole("alert");
      expect(alerta).toHaveTextContent(mensaje);
      // Sobre los botones: la alerta va antes de «Enviar reseña» en el documento.
      expect(alerta.compareDocumentPosition(botonEnviar()) & Node.DOCUMENT_POSITION_FOLLOWING).toBeTruthy();
      expect(comentarioBien()).toHaveValue("Muy bien.");
      expect(within(grupo("Calificación del bien")).getByRole("radio", { name: "4 estrellas" })).toBeChecked();
      expect(botonEnviar()).toBeEnabled();

      await enviarYConfirmar();
      expect(enviar).toHaveBeenCalledTimes(2);
      expect(enviar).toHaveBeenLastCalledWith({
        bien: { puntuacion: 4, comentario: "Muy bien." },
        arrendador: { puntuacion: 5 },
      });
    });

    it("un fallo de red (enviar lanza) muestra el mensaje genérico y permite reintentar", async () => {
      renderizar(vi.fn<Enviar>().mockRejectedValueOnce(new TypeError("Failed to fetch")));
      await calificar(4, 5);
      await enviarYConfirmar();
      expect(await screen.findByRole("alert")).toHaveTextContent(GENERICO);
      expect(botonEnviar()).toBeEnabled();
    });

    it("un fallo de red informado como status null muestra el mensaje genérico", async () => {
      renderizar(vi.fn<Enviar>().mockResolvedValueOnce({ ok: false, status: null }));
      await calificar(4, 5);
      await enviarYConfirmar();
      expect(await screen.findByRole("alert")).toHaveTextContent(GENERICO);
    });
  });

  describe("errores que bloquean (409 y 422)", () => {
    it("409 muestra un solo aviso, sobre los botones, y bloquea el envío", async () => {
      const enviar = renderizar(vi.fn<Enviar>().mockResolvedValue({ ok: false, status: 409 }));
      await calificar(4, 5);
      await enviarYConfirmar();

      // Tono advertencia de Figma (role="status"), con el mensaje exacto de Jira.
      const aviso = await screen.findByRole("status");
      expect(aviso).toHaveTextContent("Ya calificaste esta reserva.");
      expect(aviso).toHaveTextContent("Las reseñas no se pueden editar ni eliminar.");
      expect(aviso).toHaveClass("border-estado-advertencia");
      // Un solo anuncio: ninguna otra región viva repite el mensaje.
      expect(screen.queryByRole("alert")).not.toBeInTheDocument();
      expect(screen.getAllByText("Ya calificaste esta reserva.")).toHaveLength(1);
      // Sobre los botones: después de las secciones y antes de «Enviar reseña».
      expect(
        screen.getByRole("region", { name: "El arrendador" }).compareDocumentPosition(aviso) &
          Node.DOCUMENT_POSITION_FOLLOWING,
      ).toBeTruthy();
      expect(aviso.compareDocumentPosition(botonEnviar()) & Node.DOCUMENT_POSITION_FOLLOWING).toBeTruthy();

      expect(botonEnviar()).toBeDisabled();
      expect(screen.queryByText(AYUDA)).not.toBeInTheDocument();
      fireEvent.submit(botonEnviar().closest("form")!);
      expect(dialogo()).not.toBeInTheDocument();
      expect(enviar).toHaveBeenCalledTimes(1);
    });

    it("422 muestra un solo aviso de error, sobre los botones, y bloquea el envío", async () => {
      const enviar = renderizar(vi.fn<Enviar>().mockResolvedValue({ ok: false, status: 422 }));
      await calificar(4, 5);
      await enviarYConfirmar();

      const plazo =
        "Solo puedes calificar reservas finalizadas dentro de los 14 días posteriores a la devolución.";
      const alertas = await screen.findAllByRole("alert");
      expect(alertas).toHaveLength(1);
      expect(alertas[0]).toHaveTextContent("No puedes calificar esta reserva");
      expect(alertas[0]).toHaveTextContent(plazo);
      expect(screen.queryByRole("status")).not.toBeInTheDocument();
      expect(screen.getAllByText(plazo)).toHaveLength(1);
      // Sobre los botones: después de las secciones y antes de «Enviar reseña».
      expect(
        screen.getByRole("region", { name: "El arrendador" }).compareDocumentPosition(alertas[0]) &
          Node.DOCUMENT_POSITION_FOLLOWING,
      ).toBeTruthy();
      expect(alertas[0].compareDocumentPosition(botonEnviar()) & Node.DOCUMENT_POSITION_FOLLOWING).toBeTruthy();

      expect(botonEnviar()).toBeDisabled();
      // Cambiar los datos no desbloquea: el plazo no depende del formulario.
      await userEvent.click(within(grupo("Calificación del bien")).getByRole("radio", { name: "2 estrellas" }));
      expect(botonEnviar()).toBeDisabled();
      expect(enviar).toHaveBeenCalledTimes(1);
    });
  });

  describe("errorInicial (reserva que ya se sabe no elegible)", () => {
    const PLAZO =
      "Solo puedes calificar reservas finalizadas dentro de los 14 días posteriores a la devolución.";
    const sigue = (a: Node, b: Node) => Boolean(a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING);

    function renderizarConError(errorInicial: 409 | 422 | undefined, enviar = vi.fn<Enviar>()) {
      render(
        <FormularioCalificacion
          reservaId={RESERVA}
          nombreArrendador="jose_r"
          resumen={<p>Resumen de la reserva</p>}
          enviar={enviar}
          errorInicial={errorInicial}
        />,
      );
      return enviar;
    }

    it("con 422 el aviso va arriba: después del resumen y antes de las secciones, no sobre los botones", () => {
      renderizarConError(422);
      const aviso = screen.getByRole("alert");
      expect(aviso).toHaveTextContent("No puedes calificar esta reserva");
      expect(aviso).toHaveTextContent(PLAZO);
      expect(sigue(screen.getByText("Resumen de la reserva"), aviso)).toBe(true);
      expect(sigue(aviso, screen.getByRole("region", { name: "El bien" }))).toBe(true);
      expect(sigue(aviso, screen.getByRole("region", { name: "El arrendador" }))).toBe(true);
    });

    it("es un solo aviso, anunciado una vez: nada se repite sobre los botones", () => {
      renderizarConError(422);
      expect(screen.getAllByRole("alert")).toHaveLength(1);
      expect(screen.queryByRole("status")).not.toBeInTheDocument();
      expect(screen.getAllByText(PLAZO)).toHaveLength(1);
      // Entre la última sección y los botones no hay ningún aviso.
      const arrendador = screen.getByRole("region", { name: "El arrendador" });
      expect(sigue(arrendador, screen.getByRole("alert"))).toBe(false);
    });

    it("deshabilita los campos: estrellas de solo lectura y comentarios deshabilitados", () => {
      renderizarConError(422);
      expect(screen.queryByRole("radiogroup")).not.toBeInTheDocument();
      expect(screen.queryAllByRole("radio")).toHaveLength(0);
      expect(screen.getAllByRole("img", { name: "0 de 5 estrellas" })).toHaveLength(2);
      expect(comentarioBien()).toBeDisabled();
      expect(comentarioArrendador()).toBeDisabled();
    });

    it("mantiene el envío bloqueado y sin ayuda de puntuación", () => {
      const enviar = renderizarConError(422);
      expect(botonEnviar()).toBeDisabled();
      expect(screen.queryByText(AYUDA)).not.toBeInTheDocument();
      fireEvent.submit(botonEnviar().closest("form")!);
      expect(dialogo()).not.toBeInTheDocument();
      expect(enviar).not.toHaveBeenCalled();
      // «Cancelar» sigue disponible para volver a la reserva.
      expect(screen.getByRole("link", { name: "Cancelar" })).toHaveAttribute("href", `/reservas/${RESERVA}`);
    });

    it("sin errorInicial empieza sin avisos y con los campos activos (comportamiento anterior)", () => {
      renderizarConError(undefined);
      expect(screen.queryByRole("alert")).not.toBeInTheDocument();
      expect(screen.queryByRole("status")).not.toBeInTheDocument();
      expect(screen.getByText(AYUDA)).toBeInTheDocument();
      expect(screen.getAllByRole("radiogroup")).toHaveLength(2);
      expect(comentarioBien()).toBeEnabled();
      expect(comentarioArrendador()).toBeEnabled();
    });
  });

  describe("cancelar", () => {
    it("«Cancelar» lleva a la reserva sin enviar nada", () => {
      const enviar = renderizar();
      const cancelar = screen.getByRole("link", { name: "Cancelar" });
      expect(cancelar).toHaveAttribute("href", `/reservas/${RESERVA}`);
      expect(enviar).not.toHaveBeenCalled();
    });

    it("codifica el id en la ruta", () => {
      render(
        <FormularioCalificacion
          reservaId="a b/c"
          nombreArrendador="jose_r"
          resumen={null}
          enviar={vi.fn<Enviar>()}
        />,
      );
      expect(screen.getByRole("link", { name: "Cancelar" })).toHaveAttribute("href", "/reservas/a%20b%2Fc");
    });
  });
});
