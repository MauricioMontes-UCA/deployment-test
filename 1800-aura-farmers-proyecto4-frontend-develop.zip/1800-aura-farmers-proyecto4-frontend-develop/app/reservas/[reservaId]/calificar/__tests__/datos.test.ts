import { afterEach, describe, expect, it, vi } from "vitest";
import { usuarioDePrueba } from "@/pruebas/usuario";
import type { RespuestaApiCruda } from "@/lib/api";
import type { ResultadoUsuario } from "@/lib/usuario-actual";

const api = vi.hoisted(() => ({ llamarApi: vi.fn() }));
vi.mock("@/lib/api", () => api);
const sesion = vi.hoisted(() => ({ obtenerUsuarioActual: vi.fn() }));
vi.mock("@/lib/usuario-actual", () => sesion);

const { cargarPantalla, ErrorDeCarga } = await import("../datos");

const RESERVA = "5a3f2c10-8d4e-4b1a-9c7e-1f2a3b4c5d6e";
const BIEN = "7c9e6679-7425-40de-944b-e07fc1f90ae7";
/** 10/11/2026 a mediodía en El Salvador: 6 días después de la finalización. */
const AHORA = new Date("2026-11-10T18:00:00Z");

const usuario = (rol: "ARRENDATARIO" | "ARRENDADOR" = "ARRENDATARIO"): ResultadoUsuario => ({
  estado: "ok",
  usuario: usuarioDePrueba({ rol }),
});
const cruda = (status: number, datos: unknown = null): RespuestaApiCruda => ({ status, datos, mensajes: [] });

/** Respuesta de `GET /reservas/:id` (BE-6, con bien y participantes). */
function reservaApi(cambios: Record<string, unknown> = {}) {
  return cruda(200, {
    id: RESERVA,
    bienId: BIEN,
    arrendatarioId: "u1",
    fechaInicio: "2026-11-02",
    fechaFin: "2026-11-04",
    estado: "FINALIZADA",
    motivoResolucion: null,
    creadaEn: "2026-10-30T10:00:00.000Z",
    procesadaEn: "2026-10-30T10:00:05.000Z",
    finalizadaEn: "2026-11-04T16:00:00.000Z",
    bien: {
      id: BIEN,
      titulo: "Taladro industrial Bosch",
      fotoPrincipalUrl: "/uploads/bienes/principal.jpg",
      precio: 15,
      unidadCobro: "DIA",
    },
    arrendatario: { id: "u1", nombreUsuario: "ana_m" },
    arrendador: { id: "u2", nombreUsuario: "jose_r" },
    pago: null,
    deposito: null,
    ...cambios,
  });
}

function responder(resultado: ResultadoUsuario, reserva?: RespuestaApiCruda) {
  sesion.obtenerUsuarioActual.mockResolvedValue(resultado);
  if (reserva) api.llamarApi.mockResolvedValue(reserva);
}

afterEach(() => {
  vi.resetAllMocks();
});

describe("cargarPantalla", () => {
  it("con datos reales arma la pantalla con el usuario de la sesión y la reserva (sin consultar el bien)", async () => {
    responder(usuario(), reservaApi());
    expect(await cargarPantalla(RESERVA, AHORA)).toEqual({
      tipo: "lista",
      usuario: usuarioDePrueba(),
      datos: {
        reservaId: RESERVA,
        fechaInicio: "2026-11-02",
        fechaFin: "2026-11-04",
        finalizadaEl: "2026-11-04",
        titulo: "Taladro industrial Bosch",
        foto: "/uploads/bienes/principal.jpg",
        arrendador: "jose_r",
        elegible: true,
      },
    });
    expect(sesion.obtenerUsuarioActual).toHaveBeenCalledOnce();
    expect(api.llamarApi.mock.calls.map(([ruta]) => ruta)).toEqual([`reservas/${RESERVA}`]);
  });

  it("pide el usuario y la reserva en paralelo, sin esperar uno al otro", async () => {
    let resolverUsuario!: (r: ResultadoUsuario) => void;
    sesion.obtenerUsuarioActual.mockReturnValue(new Promise<ResultadoUsuario>((r) => (resolverUsuario = r)));
    api.llamarApi.mockResolvedValue(reservaApi());

    const carga = cargarPantalla(RESERVA, AHORA);
    // El usuario sigue pendiente y la reserva ya se pidió.
    expect(api.llamarApi).toHaveBeenCalledOnce();
    resolverUsuario(usuario());
    expect(await carga).toMatchObject({ tipo: "lista" });
  });

  it("un bien desactivado no impide calificar: no se consulta GET /bienes/:id", async () => {
    responder(usuario(), reservaApi());
    await cargarPantalla(RESERVA, AHORA);
    expect(api.llamarApi.mock.calls.some(([ruta]) => String(ruta).startsWith("bienes/"))).toBe(false);
  });

  it("no inventa datos: sin foto principal la foto es null y no hay código RSV", async () => {
    responder(usuario(), reservaApi({ bien: { id: BIEN, titulo: "Taladro", fotoPrincipalUrl: null } }));
    const pantalla = await cargarPantalla(RESERVA, AHORA);
    expect(pantalla.tipo === "lista" && pantalla.datos.foto).toBeNull();
    expect(pantalla.tipo === "lista" && Object.keys(pantalla.datos).sort()).toEqual(
      ["arrendador", "elegible", "fechaFin", "fechaInicio", "finalizadaEl", "foto", "reservaId", "titulo"],
    );
  });

  it("la fecha de finalización es el día de El Salvador, no el de UTC", async () => {
    // 05/11 03:00 UTC es 04/11 21:00 en El Salvador.
    responder(usuario(), reservaApi({ finalizadaEn: "2026-11-05T03:00:00.000Z" }));
    const pantalla = await cargarPantalla(RESERVA, AHORA);
    expect(pantalla.tipo === "lista" && pantalla.datos.finalizadaEl).toBe("2026-11-04");
  });

  describe("elegibilidad (estado y plazo de 14 días)", () => {
    const elegible = async (cambios: Record<string, unknown>, ahora: Date) => {
      responder(usuario(), reservaApi(cambios));
      const pantalla = await cargarPantalla(RESERVA, ahora);
      return pantalla.tipo === "lista" ? pantalla.datos.elegible : undefined;
    };

    it("FINALIZADA dentro del plazo: elegible", async () => {
      expect(await elegible({}, AHORA)).toBe(true);
    });

    it("día 14 en El Salvador: elegible; día 15: no", async () => {
      expect(await elegible({}, new Date("2026-11-19T05:59:59Z"))).toBe(true);
      expect(await elegible({}, new Date("2026-11-19T06:00:00Z"))).toBe(false);
    });

    it.each(["CONFIRMADA", "EN_CURSO", "EN_COLA", "RECHAZADA", "CANCELADA"])(
      "%s (no finalizada): no elegible",
      async (estado) => {
        expect(await elegible({ estado, finalizadaEn: null }, AHORA)).toBe(false);
      },
    );

    it("FINALIZADA sin fecha de finalización: no elegible y sin «Finalizada el…»", async () => {
      responder(usuario(), reservaApi({ finalizadaEn: null }));
      const pantalla = await cargarPantalla(RESERVA, AHORA);
      expect(pantalla).toMatchObject({ tipo: "lista", datos: { elegible: false, finalizadaEl: null } });
    });
  });

  it("sin sesión (sin cookie o 401 en auth/me)", async () => {
    responder({ estado: "sin-sesion" }, cruda(401));
    expect(await cargarPantalla(RESERVA, AHORA)).toEqual({ tipo: "sin-sesion" });
  });

  it("un 401 en la reserva también es sesión rechazada", async () => {
    responder(usuario(), cruda(401));
    expect(await cargarPantalla(RESERVA, AHORA)).toEqual({ tipo: "sin-sesion" });
  });

  it("el rol Arrendador no tiene permiso (aunque pueda leer la reserva)", async () => {
    responder(usuario("ARRENDADOR"), reservaApi());
    expect(await cargarPantalla(RESERVA, AHORA)).toEqual({
      tipo: "sin-permiso",
      usuario: usuarioDePrueba({ rol: "ARRENDADOR" }),
    });
  });

  it("un id que no es UUID es «no encontrada» y no se consulta la reserva", async () => {
    responder(usuario());
    expect(await cargarPantalla("no-es-uuid", AHORA)).toMatchObject({ tipo: "no-encontrada" });
    expect(api.llamarApi).not.toHaveBeenCalled();
  });

  it("con un id inválido, el rol Arrendador sigue viendo «sin permiso»", async () => {
    responder(usuario("ARRENDADOR"));
    expect(await cargarPantalla("no-es-uuid", AHORA)).toMatchObject({ tipo: "sin-permiso" });
  });

  it.each([404, 403])("la reserva responde %i (inexistente o ajena): «no encontrada»", async (status) => {
    responder(usuario(), cruda(status, { message: "x" }));
    expect(await cargarPantalla(RESERVA, AHORA)).toEqual({
      tipo: "no-encontrada",
      usuario: usuarioDePrueba(),
    });
  });

  it.each([
    ["auth/me con error", { estado: "error" } as ResultadoUsuario, reservaApi()],
    ["reserva con 500", usuario(), cruda(500)],
    ["reserva sin respuesta (status 0)", usuario(), cruda(0)],
    ["reserva sin bien ni arrendador (backend anterior a BE-6)", usuario(), cruda(200, { id: RESERVA, bienId: BIEN, estado: "FINALIZADA", fechaInicio: "2026-11-02", fechaFin: "2026-11-04" })],
    ["reserva con finalizadaEn de otro tipo", usuario(), reservaApi({ finalizadaEn: 123 })],
  ])("%s lanza ErrorDeCarga", async (_caso, resultado, reserva) => {
    responder(resultado, reserva);
    await expect(cargarPantalla(RESERVA, AHORA)).rejects.toBeInstanceOf(ErrorDeCarga);
  });
});
