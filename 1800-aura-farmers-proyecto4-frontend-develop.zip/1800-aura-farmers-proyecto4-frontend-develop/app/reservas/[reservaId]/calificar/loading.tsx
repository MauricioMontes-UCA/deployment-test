import { Contenedor, EstadoDePagina } from "@/components/ui";

/** Mientras se consultan la sesión, la reserva y el bien. */
export default function Cargando() {
  return (
    <main className="flex-1">
      <Contenedor className="pt-espacio-5 pb-espacio-7 md:pt-espacio-7 md:pb-espacio-9">
        <EstadoDePagina tipo="cargando" />
      </Contenedor>
    </main>
  );
}
