import { llamarApi, type RespuestaApiCruda } from "@/lib/api";
import { hoyEnElSalvador } from "@/lib/disponibilidad";
import { puedeCalificarse } from "@/lib/resenas";
import { obtenerUsuarioActual, type UsuarioActual } from "@/lib/usuario-actual";

export type { UsuarioActual };

const ID_RESERVA = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/** Lo que la pantalla necesita, tomado tal cual de `GET /reservas/:id`. */
export type DatosCalificacion = {
  reservaId: string;
  fechaInicio: string;
  fechaFin: string;
  /** Día de la finalización en El Salvador (AAAA-MM-DD), si la reserva terminó. */
  finalizadaEl: string | null;
  titulo: string;
  /** Ruta de la foto principal (`/uploads/…`), si el bien tiene. */
  foto: string | null;
  arrendador: string;
  /**
   * Si la reserva cumple estado y plazo para calificarse, con las reglas del
   * backend. Si no, la pantalla muestra el aviso del 422 sin dejar enviar.
   */
  elegible: boolean;
};

export type PantallaCalificacion =
  /**
   * Sin sesión o con la sesión rechazada por el backend (401). La página pasa
   * por `/sesion-vencida`, que borra las cookies y lleva al login.
   */
  | { tipo: "sin-sesion" }
  | { tipo: "no-encontrada"; usuario: UsuarioActual }
  | { tipo: "sin-permiso"; usuario: UsuarioActual }
  | { tipo: "lista"; usuario: UsuarioActual; datos: DatosCalificacion };

/** Error inesperado del backend: lo muestra `error.tsx` con «Reintentar». */
export class ErrorDeCarga extends Error {
  constructor(recurso: string, status: number) {
    super(status === 0 ? `No se pudo consultar ${recurso}.` : `${recurso} respondió ${status}.`);
    this.name = "ErrorDeCarga";
  }
}

const esObjeto = (valor: unknown): valor is Record<string, unknown> =>
  typeof valor === "object" && valor !== null;

/**
 * Lee de `GET /reservas/:id` lo que muestra la pantalla. Desde BE-6 la
 * respuesta trae el bien (título y foto principal) y el arrendador, así que no
 * hace falta consultar el bien aparte: un bien desactivado no impide calificar.
 */
function leerReserva(datos: unknown, ahora: Date) {
  if (!esObjeto(datos) || !esObjeto(datos.bien) || !esObjeto(datos.arrendador)) return null;
  const { estado, fechaInicio, fechaFin, finalizadaEn } = datos;
  const { titulo, fotoPrincipalUrl } = datos.bien;
  const { nombreUsuario } = datos.arrendador;
  if (
    typeof estado !== "string" ||
    typeof fechaInicio !== "string" ||
    typeof fechaFin !== "string" ||
    typeof titulo !== "string" ||
    typeof nombreUsuario !== "string" ||
    (finalizadaEn != null && typeof finalizadaEn !== "string")
  ) {
    return null;
  }
  const finalizada = typeof finalizadaEn === "string" && !Number.isNaN(Date.parse(finalizadaEn)) ? finalizadaEn : null;
  return {
    fechaInicio,
    fechaFin,
    finalizadaEl: finalizada ? hoyEnElSalvador(new Date(finalizada)) : null,
    titulo,
    foto: typeof fotoPrincipalUrl === "string" ? fotoPrincipalUrl : null,
    arrendador: nombreUsuario,
    elegible: puedeCalificarse({ estado, finalizadaEn: finalizada }, ahora),
  };
}

/**
 * Decide qué muestra `/reservas/[reservaId]/calificar` con datos reales: el
 * usuario de la sesión (`obtenerUsuarioActual`, `GET /auth/me`) y
 * `GET /reservas/:id` (fechas, estado, bien y arrendador), en paralelo porque
 * ninguna depende de la otra. Las decisiones se toman en el mismo orden: sesión,
 * rol y luego la reserva.
 *
 * Usa el cliente compartido (`llamarApi`): el token sale de la cookie httpOnly y
 * su renovación la hace el proxy. La API no expone el código «RSV-…», así que no
 * se devuelve. Los errores inesperados lanzan `ErrorDeCarga`. `ahora` se recibe
 * para poder probar el plazo.
 */
export async function cargarPantalla(
  reservaId: string,
  ahora: Date = new Date(),
): Promise<PantallaCalificacion> {
  const idValido = ID_RESERVA.test(reservaId);
  const [sesion, reserva] = await Promise.all([
    obtenerUsuarioActual(),
    idValido ? llamarApi(`reservas/${reservaId}`) : Promise.resolve<RespuestaApiCruda | null>(null),
  ]);

  if (sesion.estado === "sin-sesion") return { tipo: "sin-sesion" };
  if (sesion.estado === "error") throw new ErrorDeCarga("auth/me", 0);
  const { usuario } = sesion;

  if (usuario.rol !== "ARRENDATARIO") return { tipo: "sin-permiso", usuario };
  if (!reserva) return { tipo: "no-encontrada", usuario };

  if (reserva.status === 401) return { tipo: "sin-sesion" };
  // Una reserva ajena responde 404 (BE-27.2); el 403 de versiones anteriores se trata igual.
  if (reserva.status === 404 || reserva.status === 403) return { tipo: "no-encontrada", usuario };
  const datosReserva = reserva.status === 200 ? leerReserva(reserva.datos, ahora) : null;
  if (!datosReserva) throw new ErrorDeCarga("reservas/:id", reserva.status);

  return { tipo: "lista", usuario, datos: { reservaId, ...datosReserva } };
}
