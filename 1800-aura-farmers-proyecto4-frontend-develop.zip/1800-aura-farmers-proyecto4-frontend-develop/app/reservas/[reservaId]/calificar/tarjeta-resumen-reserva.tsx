import { Imagen } from "@/components/ui";
import { unirClases } from "@/lib/clases";

type TarjetaResumenReservaProps = {
  /** Título del bien. */
  titulo: string;
  foto?: string | null;
  /** Primer y último día de la reserva, en AAAA-MM-DD. */
  fechaInicio: string;
  fechaFin: string;
  /**
   * Día de la devolución o del cierre automático, en AAAA-MM-DD. Sin él (la
   * reserva no tiene `finalizadaEn`), la tarjeta no muestra «Finalizada el…».
   */
  finalizadaEl?: string | null;
  /**
   * Nombre de usuario de la otra parte de la reserva: el arrendador en FE-15.1
   * o el arrendatario en FE-16.1 (con `rolParticipante="Arrendatario"`).
   */
  arrendador: string;
  /** Texto del rol antes del nombre. Por defecto «Arrendador», como en FE-15.1. */
  rolParticipante?: "Arrendador" | "Arrendatario";
  className?: string;
};

/** AAAA-MM-DD → DD/MM/AAAA, sin pasar por `Date` para que la zona horaria no corra el día. */
export function formatearDia(dia: string): string {
  const [anio, mes, diaDelMes] = dia.split("-");
  return `${diaDelMes}/${mes}/${anio}`;
}

/**
 * Resumen de la reserva que se califica (FE-15.1 y FE-16.1): foto, título del
 * bien, fechas y la otra parte. Es propio de estas pantallas:
 * `TarjetaDeReserva` lleva insignia de estado y acción, que aquí no van.
 */
export function TarjetaResumenReserva({
  titulo,
  foto,
  fechaInicio,
  fechaFin,
  finalizadaEl,
  arrendador,
  rolParticipante = "Arrendador",
  className,
}: TarjetaResumenReservaProps) {
  const fechas = `${formatearDia(fechaInicio)} → ${formatearDia(fechaFin)}`;
  return (
    <article
      className={unirClases(
        "flex w-full items-center gap-espacio-4 border border-borde-default bg-fondo-superficie p-espacio-4",
        className,
      )}
    >
      <Imagen src={foto} alt={titulo} sizes="72px" className="size-18 shrink-0" />
      <div className="flex min-w-0 flex-1 flex-col gap-espacio-1">
        <h2 className="texto-h4 text-texto-primario">{titulo}</h2>
        <p className="texto-cuerpo-pequeno text-texto-secundario">
          {finalizadaEl ? `${fechas} · Finalizada el ${formatearDia(finalizadaEl)}` : fechas}
        </p>
        <p className="texto-cuerpo-pequeno text-texto-secundario">
          {rolParticipante}: {arrendador}
        </p>
      </div>
    </article>
  );
}
