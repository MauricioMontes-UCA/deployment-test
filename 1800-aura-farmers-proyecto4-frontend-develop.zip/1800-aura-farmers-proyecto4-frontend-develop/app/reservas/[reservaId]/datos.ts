import { llamarApi, type RespuestaApiCruda } from "@/lib/api";
import { leerDetalle, rolEnReserva, type DetalleReserva, type RolEnReserva } from "@/lib/reservas/detalle";
import { obtenerUsuarioActual, type UsuarioActual } from "@/lib/usuario-actual";

const ID_RESERVA = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export type PantallaDetalle =
  /** Sin sesión o con la sesión rechazada (401): la página pasa por `/sesion-vencida`. */
  | { tipo: "sin-sesion" }
  /** La reserva no existe o el usuario no participa en ella: no se muestra ningún dato. */
  | { tipo: "no-encontrada"; usuario: UsuarioActual }
  | { tipo: "lista"; usuario: UsuarioActual; detalle: DetalleReserva; rol: RolEnReserva };

/** Error inesperado del backend: lo muestra `error.tsx` con «Reintentar». */
export class ErrorDeCarga extends Error {
  constructor(recurso: string, status: number) {
    super(status === 0 ? `No se pudo consultar ${recurso}.` : `${recurso} respondió ${status}.`);
    this.name = "ErrorDeCarga";
  }
}

/**
 * Decide qué muestra `/reservas/[reservaId]` con datos reales: el usuario de la
 * sesión (`GET /auth/me`) y `GET /reservas/:id`, en paralelo. El backend
 * responde 404 a quien no participa (BE-27.2), y aquí también se comprueba que
 * el usuario sea el arrendatario o el arrendador antes de pintar nada, así
 * que un ajeno nunca ve datos de la reserva. Los demás errores lanzan
 * `ErrorDeCarga`.
 */
export async function cargarDetalle(reservaId: string): Promise<PantallaDetalle> {
  const idValido = ID_RESERVA.test(reservaId);
  const [sesion, reserva] = await Promise.all([
    obtenerUsuarioActual(),
    idValido ? llamarApi(`reservas/${reservaId}`) : Promise.resolve<RespuestaApiCruda | null>(null),
  ]);

  if (sesion.estado === "sin-sesion") return { tipo: "sin-sesion" };
  if (sesion.estado === "error") throw new ErrorDeCarga("auth/me", 0);
  const { usuario } = sesion;

  if (!reserva) return { tipo: "no-encontrada", usuario };
  if (reserva.status === 401) return { tipo: "sin-sesion" };
  // 403: versiones anteriores del backend respondían así a una reserva ajena.
  if (reserva.status === 404 || reserva.status === 403) return { tipo: "no-encontrada", usuario };

  const detalle = reserva.status === 200 ? leerDetalle(reserva.datos) : null;
  if (!detalle) throw new ErrorDeCarga("reservas/:id", reserva.status);

  const rol = rolEnReserva(detalle, usuario.id);
  if (!rol) return { tipo: "no-encontrada", usuario };
  return { tipo: "lista", usuario, detalle, rol };
}
