import { afterEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({ api: vi.fn(), usuario: vi.fn() }));
vi.mock("@/lib/api", () => ({ llamarApi: mocks.api }));
vi.mock("@/lib/usuario-actual", () => ({ obtenerUsuarioActual: mocks.usuario }));

const { cargarDetalle, ErrorDeCarga } = await import("../datos");

const ID = "5a3f2c10-8d4e-4b1a-9c7e-1f2a3b4c5d6e";
const usuario = (id: string, rol: "ARRENDATARIO" | "ARRENDADOR") => ({
  estado: "ok",
  usuario: { id, nombreUsuario: id, email: `${id}@example.com`, rol, createdAt: "2026-11-01T00:00:00.000Z" },
});
const cuerpo = {
  id: ID,
  estado: "CONFIRMADA",
  fechaInicio: "2026-11-14",
  fechaFin: "2026-11-16",
  motivoResolucion: null,
  bien: { id: "b1", titulo: "Salón", fotoPrincipalUrl: null },
  arrendatario: { id: "u1", nombreUsuario: "luis.perez" },
  arrendador: { id: "u2", nombreUsuario: "mariana_rivas" },
  pago: null,
  deposito: null,
};

afterEach(() => vi.clearAllMocks());

describe("cargarDetalle", () => {
  it("sin sesión o con 401 pide pasar por /sesion-vencida", async () => {
    mocks.usuario.mockResolvedValue({ estado: "sin-sesion" });
    mocks.api.mockResolvedValue({ status: 401, datos: null, mensajes: [] });
    expect(await cargarDetalle(ID)).toEqual({ tipo: "sin-sesion" });

    mocks.usuario.mockResolvedValue(usuario("u1", "ARRENDATARIO"));
    expect(await cargarDetalle(ID)).toEqual({ tipo: "sin-sesion" });
  });

  it("el arrendatario y el arrendador dueño ven la reserva con su rol", async () => {
    mocks.api.mockResolvedValue({ status: 200, datos: cuerpo, mensajes: [] });
    mocks.usuario.mockResolvedValue(usuario("u1", "ARRENDATARIO"));
    expect(await cargarDetalle(ID)).toMatchObject({ tipo: "lista", rol: "ARRENDATARIO" });
    mocks.usuario.mockResolvedValue(usuario("u2", "ARRENDADOR"));
    expect(await cargarDetalle(ID)).toMatchObject({ tipo: "lista", rol: "ARRENDADOR" });
    expect(mocks.api).toHaveBeenCalledWith(`reservas/${ID}`);
  });

  it("un usuario ajeno recibe no encontrada, aunque la API devuelva datos", async () => {
    mocks.usuario.mockResolvedValue(usuario("u3", "ARRENDATARIO"));
    mocks.api.mockResolvedValue({ status: 200, datos: cuerpo, mensajes: [] });
    expect(await cargarDetalle(ID)).toMatchObject({ tipo: "no-encontrada" });
    expect(await cargarDetalle(ID)).not.toHaveProperty("detalle");
  });

  it.each([404, 403])("un %s del backend es no encontrada", async (status) => {
    mocks.usuario.mockResolvedValue(usuario("u1", "ARRENDATARIO"));
    mocks.api.mockResolvedValue({ status, datos: null, mensajes: [] });
    expect(await cargarDetalle(ID)).toMatchObject({ tipo: "no-encontrada" });
  });

  it("un id que no es UUID es no encontrada sin llamar a la API de reservas", async () => {
    mocks.usuario.mockResolvedValue(usuario("u1", "ARRENDATARIO"));
    expect(await cargarDetalle("no-es-uuid")).toMatchObject({ tipo: "no-encontrada" });
    expect(mocks.api).not.toHaveBeenCalled();
  });

  it.each([0, 500])("un %s o una respuesta incompleta lanza ErrorDeCarga", async (status) => {
    mocks.usuario.mockResolvedValue(usuario("u1", "ARRENDATARIO"));
    mocks.api.mockResolvedValue({ status, datos: null, mensajes: [] });
    await expect(cargarDetalle(ID)).rejects.toBeInstanceOf(ErrorDeCarga);
    mocks.api.mockResolvedValue({ status: 200, datos: { id: ID }, mensajes: [] });
    await expect(cargarDetalle(ID)).rejects.toBeInstanceOf(ErrorDeCarga);
  });

  it("un fallo de /auth/me lanza ErrorDeCarga", async () => {
    mocks.usuario.mockResolvedValue({ estado: "error" });
    mocks.api.mockResolvedValue({ status: 200, datos: cuerpo, mensajes: [] });
    await expect(cargarDetalle(ID)).rejects.toBeInstanceOf(ErrorDeCarga);
  });
});
