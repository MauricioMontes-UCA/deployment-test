import { render, screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, describe, expect, it, vi } from "vitest";
import { leerDetalle } from "@/lib/reservas/detalle";
import type { PantallaDetalle } from "../datos";

const datos = vi.hoisted(() => ({ cargarDetalle: vi.fn() }));
vi.mock("../datos", () => datos);
vi.mock("@/app/actions/auth", () => ({ cerrarSesion: vi.fn() }));
vi.mock("next/navigation", async (original) => ({
  ...(await original<typeof import("next/navigation")>()),
  redirect: vi.fn((url: string) => {
    throw new Error(`REDIRECT:${url}`);
  }),
}));

const { default: DetalleReservaPage } = await import("../page");
const { default: ErrorAlCargar } = await import("../error");
const { default: Cargando } = await import("../loading");

const ID = "5a3f2c10-8d4e-4b1a-9c7e-1f2a3b4c5d6e";
const arrendatario = { id: "u1", nombreUsuario: "luis.perez", email: "l@example.com", rol: "ARRENDATARIO", createdAt: "2026-11-01T00:00:00.000Z" } as const;
const arrendador = { id: "u2", nombreUsuario: "mariana_rivas", email: "m@example.com", rol: "ARRENDADOR", createdAt: "2026-11-01T00:00:00.000Z" } as const;

const base = {
  id: ID,
  estado: "EN_CURSO",
  fechaInicio: "2026-11-14",
  fechaFin: "2026-11-16",
  motivoResolucion: null,
  bien: { id: "b1", titulo: "Salón de eventos Las Palmas", fotoPrincipalUrl: "/uploads/s.jpg" },
  arrendatario: { id: "u1", nombreUsuario: "luis.perez" },
  arrendador: { id: "u2", nombreUsuario: "mariana_rivas" },
  pago: { id: "p1", estado: "SIMULADO_EXITOSO", total: 265 },
  deposito: { estado: "PENDIENTE", importeOriginal: 25 },
};

function lista(cambios: Record<string, unknown>, rol: "ARRENDATARIO" | "ARRENDADOR"): PantallaDetalle {
  return {
    tipo: "lista",
    usuario: rol === "ARRENDADOR" ? arrendador : arrendatario,
    detalle: leerDetalle({ ...base, ...cambios })!,
    rol,
  };
}

async function renderizar(pantalla: PantallaDetalle) {
  datos.cargarDetalle.mockResolvedValue(pantalla);
  render(await DetalleReservaPage({ params: Promise.resolve({ reservaId: ID }) }));
}

afterEach(() => vi.clearAllMocks());

describe("/reservas/[reservaId]", () => {
  it("muestra bien, estado, fechas, participantes, pago y depósito", async () => {
    await renderizar(lista({}, "ARRENDATARIO"));

    expect(datos.cargarDetalle).toHaveBeenCalledWith(ID);
    expect(screen.getByRole("heading", { level: 1, name: "Salón de eventos Las Palmas" })).toBeInTheDocument();
    expect(screen.getAllByText("En curso").length).toBeGreaterThan(0);
    expect(screen.getByRole("link", { name: "Ver publicación" })).toHaveAttribute("href", "/bienes/b1");
    const fechas = screen.getByRole("region", { name: "Fechas" });
    expect(within(fechas).getByText("14/11/2026")).toBeInTheDocument();
    expect(within(fechas).getByText("16/11/2026")).toBeInTheDocument();
    expect(within(fechas).getByText("3 días")).toBeInTheDocument();
    const participantes = screen.getByRole("region", { name: "Participantes" });
    expect(within(participantes).getByText("mariana_rivas")).toBeInTheDocument();
    expect(within(participantes).getByText("luis.perez")).toBeInTheDocument();
    const pago = screen.getByRole("region", { name: "Pago" });
    expect(within(pago).getByText("$240.00")).toBeInTheDocument();
    expect(within(pago).getByText("$25.00")).toBeInTheDocument();
    expect(within(pago).getByText("Total pagado")).toBeInTheDocument();
    expect(within(pago).getByText("$265.00")).toBeInTheDocument();
    expect(within(pago).getByRole("link", { name: "Ver comprobante" })).toHaveAttribute("href", "/pagos/p1/comprobante");
    const deposito = screen.getByRole("region", { name: "Depósito de garantía" });
    expect(within(deposito).getByText("Pendiente")).toBeInTheDocument();
    // Sin datos que la API no expone.
    expect(screen.queryByText(/RSV-/)).not.toBeInTheDocument();
    expect(screen.queryByText(/Modalidad/)).not.toBeInTheDocument();
  });

  it("la línea de estados marca los pasos alcanzados", async () => {
    await renderizar(lista({}, "ARRENDATARIO"));
    const linea = screen.getByRole("list", { name: "Progreso de la reserva" });
    expect(within(linea).getByText("Confirmada").textContent).toContain("alcanzado");
    expect(within(linea).getByText("Finalizada").textContent).toContain("pendiente");
  });

  it("sin pago ni depósito no muestra esas tarjetas ni el comprobante", async () => {
    await renderizar(lista({ estado: "CONFIRMADA", pago: null, deposito: null }, "ARRENDATARIO"));
    expect(screen.queryByRole("region", { name: "Pago" })).not.toBeInTheDocument();
    expect(screen.queryByRole("region", { name: "Depósito de garantía" })).not.toBeInTheDocument();
    expect(screen.queryByRole("link", { name: "Ver comprobante" })).not.toBeInTheDocument();
    expect(screen.getByRole("link", { name: "Pagar ahora" })).toHaveAttribute("href", `/reservas/${ID}/pago`);
  });

  it("un pago rechazado no se desglosa: el total ($73) no se muestra como alquiler", async () => {
    // El backend devuelve deposito: null con un pago rechazado, aunque el total lo incluya ($48 + $25).
    await renderizar(lista({ estado: "CONFIRMADA", pago: { id: "p1", estado: "SIMULADO_RECHAZADO", total: 73 }, deposito: null }, "ARRENDATARIO"));
    const pago = screen.getByRole("region", { name: "Pago" });
    expect(within(pago).queryByText("Alquiler")).not.toBeInTheDocument();
    expect(within(pago).queryByText("Depósito de garantía")).not.toBeInTheDocument();
    expect(within(pago).getByText("Total")).toBeInTheDocument();
    expect(within(pago).getByText("$73.00")).toBeInTheDocument();
    expect(within(pago).getByText("Rechazado")).toBeInTheDocument();
    expect(screen.queryByRole("link", { name: "Ver comprobante" })).not.toBeInTheDocument();
    expect(screen.getByRole("link", { name: "Pagar ahora" })).toBeInTheDocument();
  });

  it("el arrendador ve el pago pero no el enlace al comprobante, que es solo del arrendatario", async () => {
    await renderizar(lista({}, "ARRENDADOR"));
    const pago = screen.getByRole("region", { name: "Pago" });
    expect(within(pago).getByText("Total pagado")).toBeInTheDocument();
    expect(within(pago).getByText("$240.00")).toBeInTheDocument();
    expect(screen.queryByRole("link", { name: "Ver comprobante" })).not.toBeInTheDocument();
  });

  it("arrendatario con la reserva en curso: coordinar, sin acciones del arrendador", async () => {
    await renderizar(lista({}, "ARRENDATARIO"));
    expect(screen.getByRole("link", { name: "Abrir conversación" })).toHaveAttribute("href", `/reservas/${ID}/conversacion`);
    expect(screen.queryByRole("link", { name: "Pagar ahora" })).not.toBeInTheDocument();
    expect(screen.queryByText("Acciones del arrendador")).not.toBeInTheDocument();
    expect(screen.queryByText("Registrar devolución")).not.toBeInTheDocument();
  });

  it("arrendatario con la reserva finalizada: califica y ya no coordina", async () => {
    await renderizar(lista({ estado: "FINALIZADA" }, "ARRENDATARIO"));
    expect(screen.getByRole("link", { name: "Calificar" })).toHaveAttribute("href", `/reservas/${ID}/calificar`);
    expect(screen.queryByRole("link", { name: "Abrir conversación" })).not.toBeInTheDocument();
  });

  it("arrendador con la reserva en curso: solo la devolución está habilitada", async () => {
    await renderizar(lista({}, "ARRENDADOR"));
    expect(screen.getByRole("link", { name: "Registrar devolución" })).toHaveAttribute("href", `/reservas/${ID}/devolucion`);
    expect(screen.getByText("Resolver depósito")).toHaveAttribute("aria-disabled", "true");
    expect(screen.getByText("Calificar arrendatario")).toHaveAttribute("aria-disabled", "true");
    expect(screen.getByRole("link", { name: "Abrir conversación" })).toBeInTheDocument();
  });

  it("arrendador con la reserva finalizada: resuelve el depósito y califica", async () => {
    await renderizar(lista({ estado: "FINALIZADA" }, "ARRENDADOR"));
    expect(screen.getByRole("link", { name: "Resolver depósito" })).toHaveAttribute("href", `/reservas/${ID}/deposito/resolver`);
    expect(screen.getByRole("link", { name: "Calificar arrendatario" })).toHaveAttribute("href", `/reservas/${ID}/calificar-arrendatario`);
    expect(screen.getByText("Registrar devolución")).toHaveAttribute("aria-disabled", "true");
    expect(screen.queryByRole("link", { name: "Abrir conversación" })).not.toBeInTheDocument();
  });

  it.each([
    ["RECHAZADA", "Rechazada", "FECHAS_NO_DISPONIBLES", "Motivo: fechas no disponibles"],
    ["CANCELADA", "Cancelada", null, null],
  ])("una reserva %s no usa la línea de estados", async (estado, texto, motivoResolucion, motivo) => {
    await renderizar(lista({ estado, motivoResolucion, pago: null, deposito: null }, "ARRENDATARIO"));
    expect(screen.queryByRole("list", { name: "Progreso de la reserva" })).not.toBeInTheDocument();
    expect(screen.getAllByText(texto).length).toBeGreaterThan(0);
    if (motivo) expect(screen.getByText(new RegExp(motivo))).toBeInTheDocument();
  });

  it("un usuario ajeno ve «no encontrada» sin datos de la reserva", async () => {
    await renderizar({ tipo: "no-encontrada", usuario: arrendatario });
    expect(screen.getByText("No encontramos esa reserva.")).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "Ir a mis reservas" })).toHaveAttribute("href", "/reservas");
    expect(screen.queryByText("Fechas")).not.toBeInTheDocument();
    expect(screen.queryByText("Salón de eventos Las Palmas")).not.toBeInTheDocument();
  });

  it("para un arrendador, «no encontrada» vuelve a reservas recibidas", async () => {
    await renderizar({ tipo: "no-encontrada", usuario: arrendador });
    expect(screen.getByRole("link", { name: "Ir a reservas recibidas" })).toHaveAttribute("href", "/reservas-recibidas");
  });

  it("sin sesión redirige a /sesion-vencida", async () => {
    datos.cargarDetalle.mockResolvedValue({ tipo: "sin-sesion" });
    await expect(DetalleReservaPage({ params: Promise.resolve({ reservaId: ID }) })).rejects.toThrow("REDIRECT:/sesion-vencida");
  });
});

describe("estados de carga y error", () => {
  it("muestra el estado de carga", () => {
    render(<Cargando />);
    expect(screen.getByText("Cargando…")).toBeInTheDocument();
  });

  it("el error ofrece Reintentar", async () => {
    const retry = vi.fn();
    render(<ErrorAlCargar error={new Error("x")} retry={retry} />);
    await userEvent.click(screen.getByRole("button", { name: "Reintentar" }));
    expect(retry).toHaveBeenCalledTimes(1);
  });
});
