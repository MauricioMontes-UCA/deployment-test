import { render, screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, describe, expect, it, vi } from "vitest";
import type { PantallaCoordinacion } from "../datos";

const datos = vi.hoisted(() => ({ cargarCoordinacion: vi.fn() }));
vi.mock("../datos", () => datos);
const accion = vi.hoisted(() => ({ enviarMensajeCoordinacion: vi.fn() }));
vi.mock("@/app/actions/coordinacion", () => accion);
const auth = vi.hoisted(() => ({ cerrarSesion: vi.fn() }));
vi.mock("@/app/actions/auth", () => auth);
vi.mock("next/navigation", async (original) => ({
  ...(await original<typeof import("next/navigation")>()),
  redirect: vi.fn((url: string) => {
    throw new Error(`REDIRECT:${url}`);
  }),
}));

const { default: CoordinacionPage } = await import("../page");
const { default: ErrorAlCargar } = await import("../error");
const { default: Cargando } = await import("../loading");

const RESERVA = "5a3f2c10-8d4e-4b1a-9c7e-1f2a3b4c5d6e";
const arrendador = { id: "u2", nombreUsuario: "mariana_rivas", email: "m@example.com", rol: "ARRENDADOR", createdAt: "2026-11-01T00:00:00.000Z" } as const;
const arrendatario = { id: "u1", nombreUsuario: "luis.perez", email: "l@example.com", rol: "ARRENDATARIO", createdAt: "2026-11-01T00:00:00.000Z" } as const;

const conversacion = {
  id: "c1",
  reservaId: RESERVA,
  estado: "CONFIRMADA" as const,
  fechaInicio: "2026-11-24",
  fechaFin: "2026-11-25",
  bien: { id: "b1", titulo: "Salón de eventos Las Palmas" },
  arrendador: { id: "u2", nombreUsuario: "mariana_rivas" },
  arrendatario: { id: "u1", nombreUsuario: "luis.perez" },
};
const mensajes = [
  { id: "m1", remitente: { id: "u2", nombreUsuario: "mariana_rivas" }, contenido: "Podemos el martes 24 a las 8:00 a. m.", creadoEn: "2026-11-20T15:10:00.000Z" },
];

async function renderizar(pantalla: PantallaCoordinacion) {
  datos.cargarCoordinacion.mockResolvedValue(pantalla);
  render(await CoordinacionPage({ params: Promise.resolve({ reservaId: RESERVA }) } as PageProps<"/reservas/[reservaId]/conversacion">));
}

afterEach(() => vi.clearAllMocks());

describe("/reservas/[reservaId]/conversacion", () => {
  it("arrendador: encabezado con el otro participante, resumen, participantes, estado e historial", async () => {
    await renderizar({ tipo: "lista", usuario: arrendador, datos: { conversacion, foto: "/uploads/bienes/salon.jpg", mensajes } });

    expect(datos.cargarCoordinacion).toHaveBeenCalledWith(RESERVA);
    expect(screen.getByRole("heading", { level: 1, name: "Conversación de la reserva con luis.perez" })).toBeInTheDocument();
    expect(screen.getByText("Coordinación de entrega")).toBeInTheDocument();
    const tarjeta = screen.getByRole("article", { name: "Salón de eventos Las Palmas" });
    expect(within(tarjeta).getByText("Reserva")).toBeInTheDocument();
    expect(within(tarjeta).getByText("24/11/2026 → 25/11/2026 · 2 días")).toBeInTheDocument();
    expect(within(tarjeta).getByText("Arrendador: mariana_rivas · Arrendatario: luis.perez")).toBeInTheDocument();
    expect(within(tarjeta).getByText("Confirmada")).toBeInTheDocument();
    expect(within(tarjeta).getByText("Acuerda por aquí")).toBeInTheDocument();
    expect(within(tarjeta).getByRole("img", { name: "Salón de eventos Las Palmas" })).toBeInTheDocument();
    // Sin código de reserva inventado.
    expect(screen.queryByText(/RSV-/)).not.toBeInTheDocument();
    // Resumen móvil.
    expect(screen.getByText("Entrega · Confirmada")).toBeInTheDocument();
    // Panel compartido con los títulos de Figma y el historial.
    const panel = screen.getByRole("region", { name: /Coordinación con luis\.perez/ });
    expect(within(panel).getByText("Mensajes sobre la entrega")).toBeInTheDocument();
    expect(within(panel).getByText("mariana_rivas · 20/11/2026 09:10")).toBeInTheDocument();
    expect(within(panel).getByText("mariana_rivas · 20/11/2026 09:10").parentElement).toHaveClass("self-end");
    // Sin formulario estructurado: solo el campo de mensaje.
    expect(within(panel).getAllByRole("textbox")).toHaveLength(1);
  });

  it("arrendatario: el otro participante es el arrendador", async () => {
    await renderizar({ tipo: "lista", usuario: arrendatario, datos: { conversacion, foto: null, mensajes: [] } });
    expect(screen.getByRole("heading", { level: 1, name: "Conversación de la reserva con mariana_rivas" })).toBeInTheDocument();
    expect(screen.getByText("Aún no hay mensajes")).toBeInTheDocument();
    expect(screen.getByText("Acuerda aquí la fecha, la hora y el lugar de la entrega.")).toBeInTheDocument();
    // Sin foto: la tarjeta de escritorio muestra el texto; la miniatura móvil
    // (56 px) usa la variante compacta, solo con el ícono.
    const [miniatura, tarjeta] = screen.getAllByText("Foto no disponible");
    expect(miniatura).toHaveClass("sr-only");
    expect(tarjeta).toHaveClass("texto-etiqueta-pequena");
    expect(tarjeta).not.toHaveClass("sr-only");
  });

  it("el envío va a la coordinación de esta reserva y un 422 cierra la conversación con su aviso", async () => {
    accion.enviarMensajeCoordinacion.mockResolvedValue({ ok: false, status: 422 });
    await renderizar({ tipo: "lista", usuario: arrendatario, datos: { conversacion, foto: null, mensajes: [] } });
    await userEvent.type(screen.getByRole("textbox", { name: /Mensaje/ }), "¿A las 8?");
    await userEvent.click(screen.getByRole("button", { name: "Enviar mensaje" }));
    expect(await screen.findByRole("alert")).toHaveTextContent("La coordinación está disponible cuando la reserva está confirmada o en curso.");
    expect(accion.enviarMensajeCoordinacion).toHaveBeenCalledWith(RESERVA, "¿A las 8?");
    expect(screen.getByRole("textbox", { name: /Mensaje/ })).toHaveValue("¿A las 8?");
    expect(screen.getByRole("button", { name: "Enviar mensaje" })).toBeDisabled();
  });

  it.each([
    ["FINALIZADA", "Finalizada"],
    ["CANCELADA", "Cancelada"],
    ["EN_COLA", "En cola"],
    ["RECHAZADA", "Rechazada"],
  ] as const)("«Reserva no permitida» (%s): aviso de Figma, sin historial ni formulario", async (estado, texto) => {
    await renderizar({ tipo: "no-permitida", usuario: arrendatario, estado });
    expect(screen.getByRole("heading", { name: "La coordinación está disponible cuando la reserva está confirmada o en curso." })).toBeInTheDocument();
    expect(screen.getByText(`Esta reserva está ${texto}.`)).toBeInTheDocument();
    expect(screen.queryByRole("log")).not.toBeInTheDocument();
    expect(screen.queryByRole("textbox")).not.toBeInTheDocument();
    expect(screen.getByRole("link", { name: "Volver a mis reservas" })).toHaveAttribute("href", "/reservas");
  });

  it("«no permitida» para el arrendador regresa a reservas recibidas; sin estado conocido no lo inventa", async () => {
    await renderizar({ tipo: "no-permitida", usuario: arrendador, estado: null });
    expect(screen.getByText("Revisa el estado de la reserva.")).toBeInTheDocument();
    expect(screen.queryByText(/Esta reserva está/)).not.toBeInTheDocument();
    expect(screen.getByRole("link", { name: "Volver a reservas recibidas" })).toHaveAttribute("href", "/reservas-recibidas");
  });

  it("tercero: «No tienes acceso a esta conversación.» con «Ir al inicio»", async () => {
    await renderizar({ tipo: "sin-permiso", usuario: arrendatario });
    expect(screen.getByRole("heading", { name: "No tienes acceso a esta conversación." })).toBeInTheDocument();
    expect(screen.getByText("Solo participan el arrendador y el arrendatario.")).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "Ir al inicio" })).toHaveAttribute("href", "/");
    expect(screen.queryByRole("log")).not.toBeInTheDocument();
  });

  it("reserva inexistente: «No encontramos esa reserva.»", async () => {
    await renderizar({ tipo: "no-encontrada", usuario: arrendador });
    expect(screen.getByRole("heading", { name: "No encontramos esa reserva." })).toBeInTheDocument();
    expect(screen.queryByRole("textbox")).not.toBeInTheDocument();
  });

  it("sin sesión → /sesion-vencida", async () => {
    await expect(renderizar({ tipo: "sin-sesion" })).rejects.toThrow("REDIRECT:/sesion-vencida");
  });

  it("error.tsx y loading.tsx", async () => {
    const retry = vi.fn();
    render(<ErrorAlCargar error={new Error("x")} retry={retry} />);
    expect(screen.getByRole("alert")).toHaveTextContent("No pudimos cargar la coordinación");
    await userEvent.click(screen.getByRole("button", { name: "Reintentar" }));
    expect(retry).toHaveBeenCalledOnce();
    render(<Cargando />);
    expect(screen.getByRole("status")).toHaveTextContent("Cargando la coordinación…");
  });
});
