import { afterEach, describe, expect, it, vi } from "vitest";
import type { RespuestaApiCruda } from "@/lib/api";
import type { ResultadoUsuario } from "@/lib/usuario-actual";

const api = vi.hoisted(() => ({ llamarApi: vi.fn() }));
vi.mock("@/lib/api", () => api);
const sesion = vi.hoisted(() => ({ obtenerUsuarioActual: vi.fn() }));
vi.mock("@/lib/usuario-actual", () => sesion);

const { cargarCoordinacion, ErrorDeCarga } = await import("../datos");

const RESERVA = "5a3f2c10-8d4e-4b1a-9c7e-1f2a3b4c5d6e";
const R_CONVERSACION = `reservas/${RESERVA}/conversacion`;
const R_DETALLE = `reservas/${RESERVA}`;
const R_MENSAJES = `reservas/${RESERVA}/conversacion/mensajes?orden=asc`;

// Variables (no literales sueltos): compilan con y sin `email`/`createdAt` en UsuarioActual.
const arrendador = { id: "u2", nombreUsuario: "mariana_rivas", email: "m@example.com", rol: "ARRENDADOR", createdAt: "2026-11-01T00:00:00.000Z" } as const;
const arrendatario = { id: "u1", nombreUsuario: "luis.perez", email: "l@example.com", rol: "ARRENDATARIO", createdAt: "2026-11-01T00:00:00.000Z" } as const;
const conSesion = (usuario: typeof arrendador | typeof arrendatario): ResultadoUsuario => ({ estado: "ok", usuario });
const cruda = (status: number, datos: unknown = null): RespuestaApiCruda => ({ status, datos, mensajes: [] });

const conversacionApi = (estado = "CONFIRMADA") =>
  cruda(200, {
    id: "c1",
    reservaId: RESERVA,
    estado,
    fechaInicio: "2026-11-24",
    fechaFin: "2026-11-25",
    bien: { id: "b1", titulo: "Salón de eventos Las Palmas" },
    arrendador: { id: "u2", nombreUsuario: "mariana_rivas" },
    arrendatario: { id: "u1", nombreUsuario: "luis.perez" },
    creadaEn: "2026-11-20T15:00:00.000Z",
  });
const detalleApi = (estado = "CONFIRMADA", fotoPrincipalUrl: string | null = "/uploads/bienes/salon.jpg") =>
  cruda(200, { id: RESERVA, estado, bien: { titulo: "Salón de eventos Las Palmas", fotoPrincipalUrl } });
const mensaje = (id: string, remitenteId: string, creadoEn: string) => ({
  id,
  conversacionId: "c1",
  remitente: { id: remitenteId, nombreUsuario: remitenteId === "u2" ? "mariana_rivas" : "luis.perez" },
  contenido: `Mensaje ${id}`,
  creadoEn,
});
const historialApi = (mensajes: unknown[] = []) => cruda(200, { conversacionId: "c1", orden: "asc", mensajes });

function responder({
  usuario = conSesion(arrendatario),
  conversacion = conversacionApi(),
  detalle = detalleApi(),
  historial = historialApi(),
}: { usuario?: ResultadoUsuario; conversacion?: RespuestaApiCruda; detalle?: RespuestaApiCruda; historial?: RespuestaApiCruda } = {}) {
  sesion.obtenerUsuarioActual.mockResolvedValue(usuario);
  api.llamarApi.mockImplementation(async (ruta: string) => {
    if (ruta === R_CONVERSACION) return conversacion;
    if (ruta === R_DETALLE) return detalle;
    if (ruta === R_MENSAJES) return historial;
    throw new Error(`ruta inesperada: ${ruta}`);
  });
}
const pidioHistorial = () => api.llamarApi.mock.calls.some(([ruta]) => ruta === R_MENSAJES);

afterEach(() => {
  vi.resetAllMocks();
});

describe("cargarCoordinacion", () => {
  it.each([
    ["arrendatario", arrendatario],
    ["arrendador dueño", arrendador],
  ] as const)("%s con la reserva CONFIRMADA: conversación, foto e historial", async (_rol, usuario) => {
    responder({
      usuario: conSesion(usuario),
      historial: historialApi([mensaje("m1", "u2", "2026-11-20T15:10:00.000Z"), mensaje("m2", "u1", "2026-11-20T15:18:00.000Z")]),
    });
    const pantalla = await cargarCoordinacion(RESERVA);

    expect(api.llamarApi).toHaveBeenCalledWith(R_CONVERSACION);
    expect(api.llamarApi).toHaveBeenCalledWith(R_DETALLE);
    expect(api.llamarApi).toHaveBeenCalledWith(R_MENSAJES);
    expect(pantalla.tipo).toBe("lista");
    if (pantalla.tipo !== "lista") return;
    expect(pantalla.usuario.id).toBe(usuario.id);
    expect(pantalla.datos.conversacion).toMatchObject({ estado: "CONFIRMADA", bien: { titulo: "Salón de eventos Las Palmas" } });
    expect(pantalla.datos.foto).toBe("/uploads/bienes/salon.jpg");
    expect(pantalla.datos.mensajes.map((m) => m.id)).toEqual(["m1", "m2"]);
  });

  it("EN_CURSO también muestra la conversación", async () => {
    responder({ conversacion: conversacionApi("EN_CURSO"), detalle: detalleApi("EN_CURSO") });
    expect((await cargarCoordinacion(RESERVA)).tipo).toBe("lista");
  });

  it("el historial queda en orden cronológico aunque llegue desordenado", async () => {
    responder({
      historial: historialApi([
        mensaje("m3", "u2", "2026-11-20T15:25:00.000Z"),
        mensaje("m1", "u2", "2026-11-20T15:10:00.000Z"),
        mensaje("m2", "u1", "2026-11-20T15:18:00.000Z"),
      ]),
    });
    const pantalla = await cargarCoordinacion(RESERVA);
    if (pantalla.tipo !== "lista") throw new Error(pantalla.tipo);
    expect(pantalla.datos.mensajes.map((m) => m.id)).toEqual(["m1", "m2", "m3"]);
  });

  describe("estados no permitidos", () => {
    it.each(["FINALIZADA", "CANCELADA"])(
      "%s con conversación existente: «no permitida» con su estado y SIN pedir el historial",
      async (estado) => {
        responder({ conversacion: conversacionApi(estado), detalle: detalleApi(estado) });
        const pantalla = await cargarCoordinacion(RESERVA);
        expect(pantalla).toMatchObject({ tipo: "no-permitida", estado });
        expect(pidioHistorial()).toBe(false);
      },
    );

    it.each(["EN_COLA", "RECHAZADA", "FINALIZADA", "CANCELADA"])(
      "422 del backend (%s sin conversación): «no permitida» con el estado del detalle",
      async (estado) => {
        responder({ conversacion: cruda(422, { message: "x" }), detalle: detalleApi(estado) });
        expect(await cargarCoordinacion(RESERVA)).toMatchObject({ tipo: "no-permitida", estado });
        expect(pidioHistorial()).toBe(false);
      },
    );

    it("422 sin detalle legible: «no permitida» con estado desconocido", async () => {
      responder({ conversacion: cruda(422), detalle: cruda(500) });
      expect(await cargarCoordinacion(RESERVA)).toMatchObject({ tipo: "no-permitida", estado: null });
    });

    it("la reserva cambia de estado entre las dos llamadas (422 en el historial): «no permitida»", async () => {
      responder({ historial: cruda(422), detalle: detalleApi("CANCELADA") });
      expect(await cargarCoordinacion(RESERVA)).toMatchObject({ tipo: "no-permitida", estado: "CANCELADA" });
    });
  });

  describe("permisos y errores", () => {
    it("un tercero (403): sin permiso y sin historial", async () => {
      responder({ conversacion: cruda(403), detalle: cruda(404) });
      expect((await cargarCoordinacion(RESERVA)).tipo).toBe("sin-permiso");
      expect(pidioHistorial()).toBe(false);
    });

    it.each([
      [404, "no-encontrada"],
      [400, "no-encontrada"],
      [401, "sin-sesion"],
    ])("%i al abrir → %s", async (status, tipo) => {
      responder({ conversacion: cruda(status) });
      expect((await cargarCoordinacion(RESERVA)).tipo).toBe(tipo);
    });

    it("id que no es UUID → no encontrada, sin llamar al backend", async () => {
      responder();
      expect((await cargarCoordinacion("no-es-uuid")).tipo).toBe("no-encontrada");
      expect(api.llamarApi).not.toHaveBeenCalled();
    });

    it("sin sesión o /auth/me caído", async () => {
      responder({ usuario: { estado: "sin-sesion" } });
      expect(await cargarCoordinacion(RESERVA)).toEqual({ tipo: "sin-sesion" });
      responder({ usuario: { estado: "error" } });
      await expect(cargarCoordinacion(RESERVA)).rejects.toBeInstanceOf(ErrorDeCarga);
    });

    it.each([
      ["409", cruda(409)],
      ["500", cruda(500)],
      ["sin respuesta", cruda(0)],
      ["cuerpo inesperado", cruda(200, { id: "c1" })],
    ])("%s al abrir → ErrorDeCarga", async (_caso, conversacion) => {
      responder({ conversacion });
      await expect(cargarCoordinacion(RESERVA)).rejects.toBeInstanceOf(ErrorDeCarga);
    });

    it.each([
      [401, "sin-sesion"],
      [403, "sin-permiso"],
      [404, "no-encontrada"],
    ])("%i en el historial → %s", async (status, tipo) => {
      responder({ historial: cruda(status) });
      expect((await cargarCoordinacion(RESERVA)).tipo).toBe(tipo);
    });

    it.each([
      ["500", cruda(500)],
      ["sin respuesta", cruda(0)],
      ["un mensaje ilegible", historialApi([{ id: "roto" }])],
    ])("%s en el historial → ErrorDeCarga", async (_caso, historial) => {
      responder({ historial });
      await expect(cargarCoordinacion(RESERVA)).rejects.toBeInstanceOf(ErrorDeCarga);
    });
  });

  describe("foto opcional", () => {
    it.each([
      ["el bien no tiene foto", detalleApi("CONFIRMADA", null)],
      ["el detalle falla (500)", cruda(500)],
      ["el detalle no responde", cruda(0)],
      ["el detalle trae otra forma", cruda(200, { bien: "x" })],
    ])("%s: la pantalla carga igual, sin foto", async (_caso, detalle) => {
      responder({ detalle });
      const pantalla = await cargarCoordinacion(RESERVA);
      expect(pantalla.tipo).toBe("lista");
      if (pantalla.tipo === "lista") expect(pantalla.datos.foto).toBeNull();
    });
  });
});
