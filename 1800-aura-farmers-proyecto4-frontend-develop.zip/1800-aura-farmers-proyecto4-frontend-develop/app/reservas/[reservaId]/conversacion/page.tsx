import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import type { ReactNode } from "react";
import { cerrarSesion } from "@/app/actions/auth";
import { enviarMensajeCoordinacion } from "@/app/actions/coordinacion";
import { PanelDeConversacion } from "@/components/mensajeria/panel-de-conversacion";
import {
  Contenedor,
  EncabezadoDePagina,
  EstadoDePagina,
  NavegacionSuperior,
  PieDePagina,
  clasesBoton,
} from "@/components/ui";
import { ESTADO_VISUAL, TEXTOS_COORDINACION as TEXTOS, otroParticipante, regresoPorRol } from "@/lib/coordinacion";
import { cargarCoordinacion, type UsuarioActual } from "./datos";
import { ResumenReserva, TarjetaReserva } from "./tarjeta-reserva";

export const metadata: Metadata = { title: "Coordinación de entrega · Arre" };

/** Navegación, contenido con los márgenes de Figma y pie de página. */
function Marco({ usuario, children }: { usuario: UsuarioActual; children: ReactNode }) {
  return (
    <>
      <NavegacionSuperior
        rol={usuario.rol === "ARRENDADOR" ? "arrendador" : "arrendatario"}
        nombreUsuario={usuario.nombreUsuario}
        onCerrarSesion={cerrarSesion}
      />
      <main className="flex-1">
        <Contenedor className="flex flex-col gap-espacio-4 pt-espacio-5 pb-espacio-7 lg:gap-espacio-6 lg:pt-espacio-7 lg:pb-espacio-9">
          {children}
        </Contenedor>
      </main>
      <PieDePagina />
    </>
  );
}

const enlace = (href: string, texto: string) => (
  <Link href={href} className={clasesBoton({ jerarquia: "secundario" })}>
    {texto}
  </Link>
);

/**
 * FE-14.1: coordinación de la entrega por reserva. Participan el arrendador
 * dueño del bien y el arrendatario; solo con la reserva CONFIRMADA o EN_CURSO.
 * Los acuerdos (fecha, hora, lugar) se escriben en mensajes: no hay
 * formulario estructurado.
 */
export default async function CoordinacionPage({ params }: PageProps<"/reservas/[reservaId]/conversacion">) {
  const { reservaId } = await params;
  const pantalla = await cargarCoordinacion(reservaId);

  switch (pantalla.tipo) {
    case "sin-sesion":
      // Una página no puede borrar cookies: /sesion-vencida las borra, revoca
      // la sesión y lleva al login (PR #2).
      redirect("/sesion-vencida");

    case "sin-permiso":
      return (
        <Marco usuario={pantalla.usuario}>
          <EstadoDePagina
            tipo="sin-permiso"
            titulo={TEXTOS.sinPermisoTitulo}
            mensaje={TEXTOS.sinPermisoMensaje}
            accion={enlace("/", "Ir al inicio")}
          />
        </Marco>
      );

    case "no-encontrada": {
      const regreso = regresoPorRol(pantalla.usuario.rol);
      return (
        <Marco usuario={pantalla.usuario}>
          <EstadoDePagina
            tipo="no-encontrado"
            titulo={TEXTOS.noEncontradaTitulo}
            mensaje={TEXTOS.noEncontradaMensaje}
            accion={enlace(regreso.href, regreso.texto)}
          />
        </Marco>
      );
    }

    case "no-permitida": {
      // Figma 30:1167. Mientras no exista /reservas/[reservaId], el regreso es
      // la lista de reservas de cada rol.
      const regreso = regresoPorRol(pantalla.usuario.rol);
      return (
        <Marco usuario={pantalla.usuario}>
          <EstadoDePagina
            tipo="sin-permiso"
            icono="candado"
            titulo={TEXTOS.noPermitida}
            mensaje={
              pantalla.estado ? `Esta reserva está ${ESTADO_VISUAL[pantalla.estado].texto}.` : "Revisa el estado de la reserva."
            }
            accion={enlace(regreso.href, regreso.texto)}
          />
        </Marco>
      );
    }

    case "lista": {
      const { usuario, datos } = pantalla;
      const { conversacion, foto, mensajes } = datos;
      const otro = otroParticipante(conversacion, usuario.id);
      return (
        <Marco usuario={usuario}>
          {/* En móvil el título lo da el panel (Figma 30:1088); el h1 queda para lectores de pantalla. */}
          <div className="sr-only lg:not-sr-only">
            <EncabezadoDePagina
              sobretitulo="Coordinación de entrega"
              titulo={`Conversación de la reserva con ${otro.nombreUsuario}`}
            />
          </div>
          <div className="flex flex-col gap-espacio-4 lg:flex-row lg:items-start lg:gap-espacio-6">
            <ResumenReserva conversacion={conversacion} foto={foto} className="lg:hidden" />
            <TarjetaReserva conversacion={conversacion} foto={foto} className="hidden lg:flex lg:w-100 lg:shrink-0" />
            <PanelDeConversacion
              usuario={usuario}
              titulo={{ movil: `Coordinación con ${otro.nombreUsuario}`, escritorio: "Mensajes sobre la entrega" }}
              vacio={{ titulo: TEXTOS.vacioTitulo, mensaje: TEXTOS.vacioMensaje }}
              mensajesIniciales={mensajes}
              enviar={enviarMensajeCoordinacion.bind(null, conversacion.reservaId)}
              bloqueos={{ 422: TEXTOS.noPermitida }}
              className="lg:flex-1"
            />
          </div>
        </Marco>
      );
    }
  }
}
