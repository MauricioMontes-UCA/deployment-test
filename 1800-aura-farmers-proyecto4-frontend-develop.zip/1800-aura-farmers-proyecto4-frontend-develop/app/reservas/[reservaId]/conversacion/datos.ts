import { llamarApi, type RespuestaApiCruda } from "@/lib/api";
import {
  admiteCoordinacion,
  esEstadoReserva,
  leerConversacionReserva,
  type ConversacionReserva,
  type EstadoReserva,
} from "@/lib/coordinacion";
import { leerHistorial, type MensajeConversacion } from "@/lib/mensajes";
import { obtenerUsuarioActual, type UsuarioActual } from "@/lib/usuario-actual";

export type { UsuarioActual };

const ID_RESERVA = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export type DatosCoordinacion = {
  conversacion: ConversacionReserva;
  /** Foto principal del bien (`/uploads/…`), si el detalle de la reserva la trajo. Opcional. */
  foto: string | null;
  /** Historial en orden cronológico. */
  mensajes: MensajeConversacion[];
};

export type PantallaCoordinacion =
  /** Sin sesión o sesión rechazada (401): la página pasa por `/sesion-vencida`. */
  | { tipo: "sin-sesion" }
  /** El usuario no es el arrendatario de la reserva ni el dueño del bien (403). */
  | { tipo: "sin-permiso"; usuario: UsuarioActual }
  /** El id no es válido o la reserva no existe (404). */
  | { tipo: "no-encontrada"; usuario: UsuarioActual }
  /**
   * La reserva no está CONFIRMADA ni EN_CURSO. `estado` es `null` si el
   * backend respondió 422 y el detalle de la reserva no pudo leerse.
   */
  | { tipo: "no-permitida"; usuario: UsuarioActual; estado: EstadoReserva | null }
  | { tipo: "lista"; usuario: UsuarioActual; datos: DatosCoordinacion };

/** Error inesperado del backend: lo muestra `error.tsx` con «Reintentar». */
export class ErrorDeCarga extends Error {
  constructor(recurso: string, status: number) {
    super(status === 0 ? `No se pudo consultar ${recurso}.` : `${recurso} respondió ${status}.`);
    this.name = "ErrorDeCarga";
  }
}

const esObjeto = (valor: unknown): valor is Record<string, unknown> =>
  typeof valor === "object" && valor !== null;

/** Del detalle de la reserva (`GET /reservas/:id`, BE-27.2) solo se usan la foto y el estado. */
function leerDetalle(respuesta: RespuestaApiCruda) {
  if (respuesta.status !== 200 || !esObjeto(respuesta.datos)) return { foto: null, estado: null };
  const { estado, bien } = respuesta.datos;
  const foto = esObjeto(bien) && typeof bien.fotoPrincipalUrl === "string" ? bien.fotoPrincipalUrl : null;
  return { foto, estado: esEstadoReserva(estado) ? estado : null };
}

/**
 * Decide qué muestra `/reservas/[reservaId]/conversacion` (FE-14.1):
 *
 * 1. Usuario de la sesión (`GET /auth/me`).
 * 2. En paralelo: `GET /reservas/:id/conversacion` (recupera o crea la
 *    conversación y trae estado, fechas, bien y participantes) y
 *    `GET /reservas/:id` (solo para la foto, que es opcional; si falla, la
 *    pantalla sigue sin foto).
 * 3. **Antes del historial se comprueba el estado:** el backend devuelve una
 *    conversación ya existente aunque la reserva esté FINALIZADA o CANCELADA,
 *    pero Jira solo admite CONFIRMADA y EN_CURSO, así que en otro estado se
 *    muestra «Reserva no permitida» sin pedir ni mostrar mensajes.
 * 4. `GET /reservas/:id/conversacion/mensajes?orden=asc`.
 *
 * 403 → sin permiso; 404 o id inválido → no encontrada; 422 → no permitida;
 * 401 → sin sesión; el resto (409, 5xx, sin respuesta, cuerpo inesperado) →
 * `ErrorDeCarga`.
 */
export async function cargarCoordinacion(reservaId: string): Promise<PantallaCoordinacion> {
  const sesion = await obtenerUsuarioActual();
  if (sesion.estado === "sin-sesion") return { tipo: "sin-sesion" };
  if (sesion.estado === "error") throw new ErrorDeCarga("auth/me", 0);
  const { usuario } = sesion;

  if (!ID_RESERVA.test(reservaId)) return { tipo: "no-encontrada", usuario };

  const [respuesta, detalle] = await Promise.all([
    llamarApi(`reservas/${reservaId}/conversacion`),
    llamarApi(`reservas/${reservaId}`),
  ]);
  const { foto, estado: estadoDetalle } = leerDetalle(detalle);

  if (respuesta.status === 401) return { tipo: "sin-sesion" };
  if (respuesta.status === 403) return { tipo: "sin-permiso", usuario };
  if (respuesta.status === 404 || respuesta.status === 400) return { tipo: "no-encontrada", usuario };
  if (respuesta.status === 422) return { tipo: "no-permitida", usuario, estado: estadoDetalle };
  const conversacion = respuesta.status === 200 ? leerConversacionReserva(respuesta.datos) : null;
  if (!conversacion) throw new ErrorDeCarga("reservas/:id/conversacion", respuesta.status);

  if (!admiteCoordinacion(conversacion.estado)) {
    return { tipo: "no-permitida", usuario, estado: conversacion.estado };
  }

  const historial = await llamarApi(`reservas/${reservaId}/conversacion/mensajes?orden=asc`);
  if (historial.status === 401) return { tipo: "sin-sesion" };
  if (historial.status === 403) return { tipo: "sin-permiso", usuario };
  if (historial.status === 404) return { tipo: "no-encontrada", usuario };
  // La reserva cambió de estado entre las dos llamadas.
  if (historial.status === 422) return { tipo: "no-permitida", usuario, estado: estadoDetalle };
  const mensajes = historial.status === 200 ? leerHistorial(historial.datos) : null;
  if (!mensajes) throw new ErrorDeCarga("reservas/:id/conversacion/mensajes", historial.status);

  return { tipo: "lista", usuario, datos: { conversacion, foto, mensajes } };
}
