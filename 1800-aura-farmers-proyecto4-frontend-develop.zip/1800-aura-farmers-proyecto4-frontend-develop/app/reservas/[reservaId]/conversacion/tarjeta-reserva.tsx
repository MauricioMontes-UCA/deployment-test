import { Imagen, InsigniaDeEstado } from "@/components/ui";
import { unirClases } from "@/lib/clases";
import { ESTADO_VISUAL, formatearFechasReserva, type ConversacionReserva } from "@/lib/coordinacion";

type TarjetaReservaProps = {
  conversacion: ConversacionReserva;
  /** Foto principal del bien; sin ella se ve el reemplazo «Foto no disponible». */
  foto: string | null;
  className?: string;
};

/**
 * Resumen de la reserva en escritorio (Figma 30:1044): foto, bien, fechas,
 * participantes, estado y la sugerencia de qué acordar. La API no expone el
 * código «RSV-…» de la reserva, así que el sobretítulo dice solo «Reserva».
 */
export function TarjetaReserva({ conversacion, foto, className }: TarjetaReservaProps) {
  const { bien, fechaInicio, fechaFin, arrendador, arrendatario, estado } = conversacion;
  const visual = ESTADO_VISUAL[estado];
  return (
    <article
      aria-labelledby="reserva-titulo"
      className={unirClases(
        "flex w-full flex-col gap-espacio-3 border border-borde-default bg-fondo-superficie p-espacio-5",
        className,
      )}
    >
      <Imagen src={foto} alt={bien.titulo} sizes="352px" className="h-58 w-full" />
      <p className="texto-sobretitulo text-texto-secundario">Reserva</p>
      <h2 id="reserva-titulo" className="texto-h3 text-texto-primario">
        {bien.titulo}
      </h2>
      <p className="texto-cuerpo-pequeno text-texto-secundario">{formatearFechasReserva(fechaInicio, fechaFin)}</p>
      <p className="texto-cuerpo-pequeno text-texto-secundario">
        Arrendador: {arrendador.nombreUsuario} · Arrendatario: {arrendatario.nombreUsuario}
      </p>
      <InsigniaDeEstado texto={visual.texto} tono={visual.tono} className="self-start" />
      {/* Figma 30:1053: los acuerdos se escriben en mensajes, sin formulario estructurado. */}
      <div className="flex flex-col gap-1.5 bg-fondo-info p-espacio-4 text-texto-primario">
        <p className="texto-etiqueta">Acuerda por aquí</p>
        <ul className="texto-cuerpo-pequeno flex flex-col gap-1.5">
          <li>· Fecha y hora de entrega</li>
          <li>· Lugar de entrega</li>
          <li>· Condiciones y observaciones</li>
        </ul>
      </div>
    </article>
  );
}

/** Resumen móvil (Figma 30:1132): foto pequeña, bien y «Entrega · {estado}». */
export function ResumenReserva({ conversacion, foto, className }: TarjetaReservaProps) {
  const { bien, estado } = conversacion;
  return (
    <article
      className={unirClases(
        "flex w-full items-center gap-espacio-3 border border-borde-default bg-fondo-superficie p-espacio-4",
        className,
      )}
    >
      <Imagen src={foto} alt={bien.titulo} sizes="56px" compacta className="size-14 shrink-0" />
      <div className="flex min-w-0 flex-1 flex-col gap-espacio-1">
        <h2 className="texto-h4 text-texto-primario">{bien.titulo}</h2>
        <p className="texto-etiqueta-pequena text-texto-secundario">Entrega · {ESTADO_VISUAL[estado].texto}</p>
      </div>
    </article>
  );
}
