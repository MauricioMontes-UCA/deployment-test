import type { Metadata } from "next";
import type { ReactNode } from "react";

import Link from "next/link";
import { redirect } from "next/navigation";

import { cerrarSesion } from "@/app/actions/auth";

import {
  Contenedor,
  EstadoDePagina,
  NavegacionSuperior,
  PieDePagina,
  clasesBoton,
} from "@/components/ui";

import { PantallaPago } from "@/components/pagos/pantalla-pago";

import { llamarApi } from "@/lib/api";

import { obtenerUsuarioActual, type UsuarioActual } from "@/lib/usuario-actual";

import { ID_RESERVA } from "@/lib/pagos/tipos";

export const metadata: Metadata = {
  title: "Pagar reserva · Arre",
};

function Marco({
  usuario,
  children,
}: {
  usuario: UsuarioActual;
  children: ReactNode;
}) {
  return (
    <>
      <NavegacionSuperior
        rol={usuario.rol === "ARRENDADOR" ? "arrendador" : "arrendatario"}
        nombreUsuario={usuario.nombreUsuario}
        onCerrarSesion={cerrarSesion}
      />

      <main className="flex-1">
        <Contenedor className="flex flex-col gap-espacio-6 py-espacio-7">
          {children}
        </Contenedor>
      </main>

      <PieDePagina />
    </>
  );
}

const volver = (
  <Link
    href="/"
    className={clasesBoton({
      jerarquia: "secundario",
    })}
  >
    Volver al inicio
  </Link>
);

export default async function PagoReservaPage({
  params,
}: {
  params: Promise<{ reservaId: string }>;
}) {
  const { reservaId } = await params;

  const sesion = await obtenerUsuarioActual();

  if (sesion.estado === "sin-sesion") {
    redirect("/sesion-vencida");
  }

  if (sesion.estado === "error") {
    throw new Error("No se pudo verificar la sesión actual.");
  }

  const { usuario } = sesion;

  if (usuario.rol !== "ARRENDATARIO") {
    return (
      <Marco usuario={usuario}>
        <EstadoDePagina
          tipo="sin-permiso"
          titulo="No tienes permiso para pagar esta reserva."
          mensaje="Solo el arrendatario puede realizar el pago."
          accion={volver}
        />
      </Marco>
    );
  }

  if (!ID_RESERVA.test(reservaId)) {
    return (
      <Marco usuario={usuario}>
        <EstadoDePagina
          tipo="no-encontrado"
          titulo="La reserva no es válida."
          mensaje="Verifica el enlace de la reserva."
          accion={volver}
        />
      </Marco>
    );
  }

  const respuesta = await llamarApi(`reservas/${reservaId}`);

  if (respuesta.status === 401) {
    redirect("/sesion-vencida");
  }

  if (respuesta.status === 403 || respuesta.status === 404) {
    return (
      <Marco usuario={usuario}>
        <EstadoDePagina
          tipo={respuesta.status === 403 ? "sin-permiso" : "no-encontrado"}
          titulo="No puedes acceder a esta reserva."
          mensaje="La reserva no existe o no pertenece a tu cuenta."
          accion={volver}
        />
      </Marco>
    );
  }

  if (
    respuesta.status !== 200 ||
    typeof respuesta.datos !== "object" ||
    respuesta.datos === null
  ) {
    return (
      <Marco usuario={usuario}>
        <EstadoDePagina
          tipo="error"
          titulo="No pudimos consultar la reserva."
          mensaje="Inténtalo nuevamente más tarde."
          accion={volver}
        />
      </Marco>
    );
  }

  const reserva = respuesta.datos as Record<string, unknown>;

  if (reserva.arrendatarioId !== usuario.id) {
    return (
      <Marco usuario={usuario}>
        <EstadoDePagina
          tipo="sin-permiso"
          titulo="Esta reserva no pertenece a tu cuenta."
          accion={volver}
        />
      </Marco>
    );
  }

  const bien =
    typeof reserva.bien === "object" && reserva.bien !== null
      ? (reserva.bien as Record<string, unknown>)
      : null;

  const pago =
    typeof reserva.pago === "object" && reserva.pago !== null
      ? (reserva.pago as Record<string, unknown>)
      : null;

  const pagoPrevio =
    pago && typeof pago.id === "string" && pago.estado === "SIMULADO_EXITOSO"
      ? {
          id: pago.id,
          total: typeof pago.total === "number" ? pago.total : null,
        }
      : null;

  return (
    <Marco usuario={usuario}>
      <PantallaPago
        reservaId={reservaId}
        tituloBien={
          typeof bien?.titulo === "string" ? bien.titulo : "Reserva de alquiler"
        }
        fechaInicio={
          typeof reserva.fechaInicio === "string" ? reserva.fechaInicio : null
        }
        fechaFin={
          typeof reserva.fechaFin === "string" ? reserva.fechaFin : null
        }
        fotoBien={
          typeof bien?.fotoPrincipalUrl === "string"
            ? bien.fotoPrincipalUrl
            : null
        }
        precioUnitario={typeof bien?.precio === "number" ? bien.precio : null}
        unidadCobro={
          typeof bien?.unidadCobro === "string" ? bien.unidadCobro : null
        }
        pagoPrevio={pagoPrevio}
      />
    </Marco>
  );
}
