import { afterEach, describe, expect, it, vi } from "vitest";
import { render, screen } from "@testing-library/react";

const mocks = vi.hoisted(() => ({
  usuario: vi.fn(),
  api: vi.fn(),
  redirect: vi.fn((ruta: string) => {
    throw new Error(`REDIRECT:${ruta}`);
  }),
}));

vi.mock("@/lib/usuario-actual", () => ({
  obtenerUsuarioActual: mocks.usuario,
}));
vi.mock("@/lib/api", () => ({ llamarApi: mocks.api }));
vi.mock("next/navigation", () => ({ redirect: mocks.redirect }));
vi.mock("@/app/actions/auth", () => ({ cerrarSesion: vi.fn() }));
vi.mock("@/components/pagos/pantalla-pago", () => ({
  PantallaPago: ({
    tituloBien,
    pagoPrevio,
  }: {
    tituloBien: string;
    pagoPrevio?: { id: string; total: number | null } | null;
  }) => (
    <div>
      Pago de {tituloBien}
      {pagoPrevio ? ` · pagada ${pagoPrevio.id} ${pagoPrevio.total}` : ""}
    </div>
  ),
}));
vi.mock("@/components/ui", () => ({
  Contenedor: ({ children }: { children: React.ReactNode }) => (
    <div>{children}</div>
  ),
  EstadoDePagina: ({ titulo }: { titulo: string }) => <div>{titulo}</div>,
  NavegacionSuperior: () => <nav />,
  PieDePagina: () => <footer />,
  clasesBoton: () => "",
}));

import Pagina from "./page";

const ID = "5a3f2c10-8d4e-4b1a-9c7e-1f2a3b4c5d6e";
const usuario = { id: "usuario-1", rol: "ARRENDATARIO", nombreUsuario: "ana" };
const renderizar = async () =>
  render(await Pagina({ params: Promise.resolve({ reservaId: ID }) }));

afterEach(() => vi.clearAllMocks());

describe("FE-8.1 página de pago", () => {
  it("sin sesión redirige", async () => {
    mocks.usuario.mockResolvedValue({ estado: "sin-sesion" });
    await expect(renderizar()).rejects.toThrow("REDIRECT:/sesion-vencida");
  });

  it("impide acceso al arrendador", async () => {
    mocks.usuario.mockResolvedValue({
      estado: "autenticado",
      usuario: { ...usuario, rol: "ARRENDADOR" },
    });
    await renderizar();
    expect(
      screen.getByText("No tienes permiso para pagar esta reserva."),
    ).toBeInTheDocument();
  });

  it("impide acceso a reserva ajena", async () => {
    mocks.usuario.mockResolvedValue({ estado: "autenticado", usuario });
    mocks.api.mockResolvedValue({
      status: 200,
      datos: { arrendatarioId: "otro", bien: { titulo: "Taladro" } },
    });
    await renderizar();
    expect(
      screen.getByText("Esta reserva no pertenece a tu cuenta."),
    ).toBeInTheDocument();
  });

  it("muestra pantalla para reserva propia", async () => {
    mocks.usuario.mockResolvedValue({ estado: "autenticado", usuario });
    mocks.api.mockResolvedValue({
      status: 200,
      datos: { arrendatarioId: usuario.id, bien: { titulo: "Taladro" } },
    });
    await renderizar();
    expect(screen.getByText("Pago de Taladro")).toBeInTheDocument();
  });

  it("pasa el pago exitoso de la reserva para mostrar «ya pagada»", async () => {
    mocks.usuario.mockResolvedValue({ estado: "autenticado", usuario });
    mocks.api.mockResolvedValue({
      status: 200,
      datos: {
        arrendatarioId: usuario.id,
        bien: { titulo: "Taladro" },
        pago: { id: "pago-9", estado: "SIMULADO_EXITOSO", total: 240 },
      },
    });
    await renderizar();
    expect(
      screen.getByText("Pago de Taladro · pagada pago-9 240"),
    ).toBeInTheDocument();
  });

  it("ignora un pago rechazado: la reserva sigue pagable", async () => {
    mocks.usuario.mockResolvedValue({ estado: "autenticado", usuario });
    mocks.api.mockResolvedValue({
      status: 200,
      datos: {
        arrendatarioId: usuario.id,
        bien: { titulo: "Taladro" },
        pago: { id: "pago-9", estado: "SIMULADO_RECHAZADO", total: 240 },
      },
    });
    await renderizar();
    expect(screen.getByText("Pago de Taladro")).toBeInTheDocument();
  });
});
