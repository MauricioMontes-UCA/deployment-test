import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import type { ReactNode } from "react";
import { cerrarSesion } from "@/app/actions/auth";
import { calificarArrendatario } from "@/app/actions/calificacion-arrendatario";
import {
  Contenedor,
  EncabezadoDePagina,
  EstadoDePagina,
  NavegacionSuperior,
  PieDePagina,
  clasesBoton,
} from "@/components/ui";
import { TarjetaResumenReserva } from "../calificar/tarjeta-resumen-reserva";
import { cargarPantallaArrendatario, type UsuarioActual } from "./datos";
import {
  CalificacionRegistrada,
  FormularioCalificacionArrendatario,
} from "./formulario-calificacion-arrendatario";

export const metadata: Metadata = { title: "Califica al arrendatario · Arre" };

/** Navegación, contenido con los márgenes de Figma y pie de página. */
function Marco({ usuario, children }: { usuario: UsuarioActual; children: ReactNode }) {
  return (
    <>
      <NavegacionSuperior
        rol={usuario.rol === "ARRENDADOR" ? "arrendador" : "arrendatario"}
        nombreUsuario={usuario.nombreUsuario}
        onCerrarSesion={cerrarSesion}
      />
      <main className="flex-1">
        <Contenedor className="flex flex-col gap-5 pt-espacio-5 pb-espacio-7 md:gap-espacio-6 md:pt-espacio-7 md:pb-espacio-9">
          {children}
        </Contenedor>
      </main>
      <PieDePagina />
    </>
  );
}

const irAlInicio = (
  <Link href="/" className={clasesBoton({ jerarquia: "secundario" })}>
    Ir al inicio
  </Link>
);

/** FE-16.1: el arrendador califica al arrendatario de una reserva finalizada. */
export default async function CalificarArrendatarioPage({
  params,
}: PageProps<"/reservas/[reservaId]/calificar-arrendatario">) {
  const { reservaId } = await params;
  const pantalla = await cargarPantallaArrendatario(reservaId);

  switch (pantalla.tipo) {
    case "sin-sesion":
      // Como en el resto de la app (PR #2): /sesion-vencida borra las cookies y lleva al login.
      redirect("/sesion-vencida");

    case "sin-permiso":
      return (
        <Marco usuario={pantalla.usuario}>
          <EstadoDePagina
            tipo="sin-permiso"
            titulo="No tienes permiso para ver esta pantalla."
            accion={irAlInicio}
          />
        </Marco>
      );

    case "no-encontrada":
      return (
        <Marco usuario={pantalla.usuario}>
          <EstadoDePagina
            tipo="no-encontrado"
            titulo="No encontramos esa reserva."
            mensaje="Revisa el enlace e intenta de nuevo."
            accion={irAlInicio}
          />
        </Marco>
      );

    case "lista": {
      const { usuario, datos } = pantalla;
      const { resena, promedioArrendatario, totalCalificaciones } = datos.calificacion;
      const resumen = (
        <TarjetaResumenReserva
          titulo={datos.titulo}
          foto={datos.foto}
          fechaInicio={datos.fechaInicio}
          fechaFin={datos.fechaFin}
          finalizadaEl={datos.finalizadaEl}
          arrendador={datos.arrendatario}
          rolParticipante="Arrendatario"
        />
      );
      return (
        <Marco usuario={usuario}>
          {resena ? (
            // Ya calificada (BE-16.2): solo lectura, sin formulario, aunque
            // haya vencido el plazo. Sin el aviso «Calificación enviada.».
            <>
              <EncabezadoDePagina
                titulo="Califica al arrendatario"
                descripcion="Ya calificaste al arrendatario en esta reserva."
              />
              <CalificacionRegistrada
                resumen={resumen}
                nombreArrendatario={datos.arrendatario}
                calificacion={{
                  puntuacion: resena.puntuacion,
                  comentario: resena.comentario,
                  promedioArrendatario,
                  totalCalificaciones,
                }}
              />
            </>
          ) : (
            <>
              <EncabezadoDePagina
                titulo="Califica al arrendatario"
                descripcion="Deja constancia del trato y del cuidado que tuvo con tu bien. La calificación no se puede editar."
              />
              <FormularioCalificacionArrendatario
                reservaId={datos.reservaId}
                nombreArrendatario={datos.arrendatario}
                resumen={resumen}
                calificar={calificarArrendatario.bind(null, datos.reservaId)}
                // Reserva no finalizada o fuera de plazo: el aviso del 422 antes de llenar nada.
                errorInicial={datos.elegible ? undefined : 422}
              />
            </>
          )}
        </Marco>
      );
    }
  }
}
