import { render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { TarjetaResumenReserva } from "../../calificar/tarjeta-resumen-reserva";

const base = {
  titulo: "Taladro industrial Bosch",
  fechaInicio: "2026-11-02",
  fechaFin: "2026-11-04",
  arrendador: "jose_r",
};

describe("TarjetaResumenReserva · rolParticipante", () => {
  it("sin la prop sigue mostrando «Arrendador:» (compatibilidad con FE-15.1)", () => {
    render(<TarjetaResumenReserva {...base} />);
    expect(screen.getByText("Arrendador: jose_r")).toBeInTheDocument();
  });

  it("con rolParticipante «Arrendatario» muestra «Arrendatario:» y el nombre", () => {
    render(<TarjetaResumenReserva {...base} arrendador="maria_lopez" rolParticipante="Arrendatario" />);
    expect(screen.getByText("Arrendatario: maria_lopez")).toBeInTheDocument();
    expect(screen.queryByText(/^Arrendador:/)).not.toBeInTheDocument();
  });
});
