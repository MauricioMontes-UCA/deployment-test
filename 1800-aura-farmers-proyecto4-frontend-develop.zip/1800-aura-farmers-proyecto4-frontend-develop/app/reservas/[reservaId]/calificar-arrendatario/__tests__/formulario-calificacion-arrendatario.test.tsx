import { fireEvent, render, screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, beforeAll, beforeEach, describe, expect, it, vi, type MockInstance } from "vitest";
import type { CalificarArrendatarioPayload, ResultadoCalificacion } from "@/lib/calificacion-arrendatario";
import {
  CalificacionRegistrada,
  FormularioCalificacionArrendatario,
  type CalificacionLeida,
} from "../formulario-calificacion-arrendatario";

const RESERVA = "5a3f2c10-8d4e-4b1a-9c7e-1f2a3b4c5d6e";
const GENERICO = "No pudimos enviar la calificación. Intenta de nuevo.";
const PLAZO = "Solo puedes calificar reservas finalizadas dentro de los 14 días posteriores a la devolución.";

beforeAll(() => {
  // jsdom no implementa showModal/close de <dialog>; se simula lo mínimo.
  HTMLDialogElement.prototype.showModal ??= function (this: HTMLDialogElement) {
    this.setAttribute("open", "");
  };
  HTMLDialogElement.prototype.close ??= function (this: HTMLDialogElement) {
    this.removeAttribute("open");
  };
});

// Ninguna prueba debe dejar advertencias de React en la consola.
let errorDeConsola: MockInstance<typeof console.error>;
beforeEach(() => {
  errorDeConsola = vi.spyOn(console, "error");
});
afterEach(() => {
  expect(errorDeConsola).not.toHaveBeenCalled();
  errorDeConsola.mockRestore();
});

type Calificar = (payload: CalificarArrendatarioPayload) => Promise<ResultadoCalificacion>;
const exito = (promedio: number | null = 4.6, total: number | null = 7): ResultadoCalificacion => ({
  ok: true,
  promedioArrendatario: promedio,
  totalCalificaciones: total,
});

function renderizar(calificar: Calificar = vi.fn<Calificar>(async () => exito()), errorInicial?: 409 | 422) {
  render(
    <FormularioCalificacionArrendatario
      reservaId={RESERVA}
      nombreArrendatario="maria_lopez"
      resumen={<p>Resumen de la reserva</p>}
      calificar={calificar}
      errorInicial={errorInicial}
    />,
  );
  return calificar;
}

function diferida() {
  let resolver!: (r: ResultadoCalificacion) => void;
  const promesa = new Promise<ResultadoCalificacion>((r) => (resolver = r));
  return { promesa, resolver };
}

const grupo = () => screen.getByRole("radiogroup", { name: "Calificación del arrendatario" });
const elegir = (n: number) =>
  userEvent.click(within(grupo()).getByRole("radio", { name: n === 1 ? "1 estrella" : `${n} estrellas` }));
const comentario = () => screen.getByRole("textbox", { name: "Comentario (opcional)" });
const botonEnviar = () => screen.getByRole("button", { name: "Enviar calificación" });
const dialogo = () => screen.queryByRole("dialog", { name: "¿Enviar tu calificación?" });
const sigue = (a: Node, b: Node) => Boolean(a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING);

async function enviarYConfirmar() {
  await userEvent.click(botonEnviar());
  await userEvent.click(within(dialogo()!).getByRole("button", { name: "Enviar" }));
}

describe("FormularioCalificacionArrendatario", () => {
  describe("estado inicial y validaciones", () => {
    it("empieza sin estrellas, con 0/500, la sección con el nombre del arrendatario y el botón deshabilitado", () => {
      renderizar();
      expect(screen.getByRole("region", { name: "maria_lopez" })).toBeInTheDocument();
      expect(screen.getByText("¿Cómo fue el trato y el cuidado del bien?")).toBeInTheDocument();
      for (const radio of within(grupo()).getAllByRole("radio")) expect(radio).not.toBeChecked();
      expect(screen.getByText("0/500")).toBeInTheDocument();
      expect(botonEnviar()).toBeDisabled();
      expect(screen.queryByRole("alert")).not.toBeInTheDocument();
    });

    it("una puntuación de 1 a 5 basta para habilitar el envío (el comentario es opcional)", async () => {
      renderizar();
      await elegir(1);
      expect(botonEnviar()).toBeEnabled();
      await elegir(5);
      expect(within(grupo()).getByRole("radio", { name: "5 estrellas" })).toBeChecked();
      expect(botonEnviar()).toBeEnabled();
    });

    it("las estrellas se manejan con las flechas del teclado", async () => {
      renderizar();
      await elegir(3);
      await userEvent.keyboard("{ArrowRight}");
      expect(within(grupo()).getByRole("radio", { name: "4 estrellas" })).toBeChecked();
    });

    it("al pasar de 500 muestra el mensaje bajo el campo y bloquea el envío; al volver a 500 se desbloquea", async () => {
      renderizar();
      await elegir(4);
      await userEvent.click(comentario());
      await userEvent.paste("a".repeat(501));
      expect(screen.getByText("501/500")).toHaveClass("text-texto-error");
      expect(comentario()).toHaveAccessibleDescription("Tu comentario supera los 500 caracteres por 1.");
      expect(botonEnviar()).toBeDisabled();
      await userEvent.type(comentario(), "{Backspace}");
      expect(screen.getByText("500/500")).not.toHaveClass("text-texto-error");
      expect(botonEnviar()).toBeEnabled();
    });

    it("el contador cuenta como el backend: emojis por code point y sin los espacios de los extremos", async () => {
      renderizar();
      await userEvent.type(comentario(), "  😀👍🏽  ");
      expect(screen.getByText("3/500")).toBeInTheDocument();
    });
  });

  describe("confirmación y envío", () => {
    it("pide confirmación con el texto exacto y cancelar no envía", async () => {
      const calificar = renderizar();
      await elegir(4);
      await userEvent.click(botonEnviar());
      expect(dialogo()).toHaveAccessibleDescription("No podrás editarla.");
      await userEvent.click(within(dialogo()!).getByRole("button", { name: "Cancelar" }));
      expect(dialogo()).not.toBeInTheDocument();
      expect(calificar).not.toHaveBeenCalled();
    });

    it("confirmar envía una vez el cuerpo exacto (comentario recortado)", async () => {
      const calificar = renderizar();
      await elegir(5);
      await userEvent.type(comentario(), "  Cuidó muy bien la cámara.  ");
      await enviarYConfirmar();
      expect(calificar).toHaveBeenCalledExactlyOnceWith({ puntuacion: 5, comentario: "Cuidó muy bien la cámara." });
    });

    it("sin comentario envía solo la puntuación", async () => {
      const calificar = renderizar();
      await elegir(2);
      await enviarYConfirmar();
      expect(calificar).toHaveBeenCalledExactlyOnceWith({ puntuacion: 2 });
    });

    it("mientras envía muestra «Procesando…» y no permite otro envío", async () => {
      const { promesa, resolver } = diferida();
      const calificar = renderizar(vi.fn<Calificar>(() => promesa));
      await elegir(4);
      await enviarYConfirmar();
      const procesando = screen.getByRole("button", { name: "Procesando…" });
      expect(procesando).toBeDisabled();
      expect(procesando).toHaveAttribute("aria-busy", "true");
      fireEvent.submit(procesando.closest("form")!);
      expect(dialogo()).not.toBeInTheDocument();
      expect(calificar).toHaveBeenCalledTimes(1);
      resolver(exito());
      await screen.findByText("Calificación enviada.");
    });

    it("dos clics seguidos en «Enviar» del diálogo envían una sola vez", async () => {
      const { promesa, resolver } = diferida();
      const calificar = renderizar(vi.fn<Calificar>(() => promesa));
      await elegir(4);
      await userEvent.click(botonEnviar());
      const confirmar = within(dialogo()!).getByRole("button", { name: "Enviar" });
      fireEvent.click(confirmar);
      fireEvent.click(confirmar);
      expect(calificar).toHaveBeenCalledTimes(1);
      resolver(exito());
      await screen.findByText("Calificación enviada.");
    });
  });

  describe("éxito: solo lectura", () => {
    it("tras el 201 se queda en la pantalla, en solo lectura, con el mensaje y el promedio con un decimal", async () => {
      renderizar(vi.fn<Calificar>(async () => exito(4, 7)));
      await elegir(5);
      await userEvent.type(comentario(), "Cuidó muy bien la cámara.");
      await enviarYConfirmar();

      const aviso = await screen.findByRole("status");
      expect(aviso).toHaveTextContent("Calificación enviada.");
      // El backend envía 4.0 como 4: se muestra «4.0».
      expect(aviso).toHaveTextContent("Promedio actual del arrendatario: 4.0.");
      expect(screen.getByText("4.0 de promedio · 7 calificaciones")).toBeInTheDocument();
      expect(screen.getByRole("img", { name: "maria_lopez" })).toBeInTheDocument();
      expect(screen.getByRole("region", { name: "Tu calificación" })).toBeInTheDocument();
      expect(screen.getByRole("img", { name: "5 de 5 estrellas" })).toBeInTheDocument();
      expect(screen.getByText("Cuidó muy bien la cámara.")).toBeInTheDocument();
      expect(screen.getByText("Solo lectura: las calificaciones no se editan ni se eliminan.")).toBeInTheDocument();
      expect(screen.getByText("Resumen de la reserva")).toBeInTheDocument();
    });

    it("en solo lectura no hay controles: ni editar, eliminar, enviar, cancelar, estrellas ni campo", async () => {
      renderizar(vi.fn<Calificar>(async () => exito(4.6, 1)));
      await elegir(4);
      await enviarYConfirmar();
      await screen.findByText("Calificación enviada.");

      expect(screen.queryAllByRole("button")).toHaveLength(0);
      expect(screen.queryAllByRole("link")).toHaveLength(0);
      expect(screen.queryByRole("radiogroup")).not.toBeInTheDocument();
      expect(screen.queryByRole("textbox")).not.toBeInTheDocument();
      expect(screen.queryByText(/editar/i, { selector: "button, a" })).not.toBeInTheDocument();
      expect(screen.queryByText(/eliminar/i, { selector: "button, a" })).not.toBeInTheDocument();
      expect(screen.getByText("4.6 de promedio · 1 calificación")).toBeInTheDocument();
    });

    it("sin comentario muestra «Sin comentario.», no un párrafo vacío", async () => {
      renderizar(vi.fn<Calificar>(async () => exito(3.5, 2)));
      await elegir(3);
      await enviarYConfirmar();
      const tuCalificacion = await screen.findByRole("region", { name: "Tu calificación" });
      const parrafos = within(tuCalificacion).queryAllByText(/./, { selector: "p" });
      expect(parrafos.map((p) => p.textContent)).toEqual(["Sin comentario."]);
    });

    it("si el backend no devolvió promedio ni total, no los inventa", async () => {
      renderizar(vi.fn<Calificar>(async () => exito(null, null)));
      await elegir(4);
      await enviarYConfirmar();
      const aviso = await screen.findByRole("status");
      expect(aviso).toHaveTextContent("Calificación enviada.");
      expect(aviso).not.toHaveTextContent("Promedio");
      expect(screen.queryByText(/de promedio|calificacion(es)?$/)).not.toBeInTheDocument();
    });
  });

  describe("errores de envío (sobre los botones)", () => {
    it.each([
      [400, "Revisa la puntuación y el comentario."],
      [403, "No tienes permiso para calificar esta reserva."],
      [404, "No encontramos esa reserva."],
      [500, GENERICO],
      [503, GENERICO],
    ])("%i muestra su mensaje sobre los botones y deja reintentar", async (status, mensaje) => {
      const calificar = vi
        .fn<Calificar>()
        .mockResolvedValueOnce({ ok: false, status })
        .mockResolvedValueOnce(exito());
      renderizar(calificar);
      await elegir(4);
      await enviarYConfirmar();

      const alerta = await screen.findByRole("alert");
      expect(alerta).toHaveTextContent(mensaje);
      expect(sigue(screen.getByRole("region", { name: "maria_lopez" }), alerta)).toBe(true);
      expect(sigue(alerta, botonEnviar())).toBe(true);
      expect(within(grupo()).getByRole("radio", { name: "4 estrellas" })).toBeChecked();
      expect(botonEnviar()).toBeEnabled();

      await enviarYConfirmar();
      expect(calificar).toHaveBeenCalledTimes(2);
    });

    it("red caída (calificar lanza) muestra el mensaje genérico de FE-16.1", async () => {
      renderizar(vi.fn<Calificar>().mockRejectedValueOnce(new TypeError("Failed to fetch")));
      await elegir(4);
      await enviarYConfirmar();
      expect(await screen.findByRole("alert")).toHaveTextContent(GENERICO);
    });

    it("409 muestra «Ya calificaste al arrendatario en esta reserva.» una vez y bloquea", async () => {
      const calificar = renderizar(vi.fn<Calificar>().mockResolvedValue({ ok: false, status: 409 }));
      await elegir(4);
      await enviarYConfirmar();
      const aviso = await screen.findByRole("status");
      expect(aviso).toHaveTextContent("Ya calificaste al arrendatario en esta reserva.");
      expect(screen.getAllByText("Ya calificaste al arrendatario en esta reserva.")).toHaveLength(1);
      expect(sigue(aviso, botonEnviar())).toBe(true);
      expect(botonEnviar()).toBeDisabled();
      await elegir(2);
      expect(botonEnviar()).toBeDisabled();
      expect(calificar).toHaveBeenCalledTimes(1);
      // No se reconstruye una calificación a partir del 409.
      expect(screen.queryByText("Calificación enviada.")).not.toBeInTheDocument();
    });

    it("422 muestra el aviso del plazo una vez, sobre los botones, y bloquea", async () => {
      renderizar(vi.fn<Calificar>().mockResolvedValue({ ok: false, status: 422 }));
      await elegir(4);
      await enviarYConfirmar();
      const alertas = await screen.findAllByRole("alert");
      expect(alertas).toHaveLength(1);
      expect(alertas[0]).toHaveTextContent("No puedes calificar esta reserva");
      expect(alertas[0]).toHaveTextContent(PLAZO);
      expect(sigue(alertas[0], botonEnviar())).toBe(true);
      expect(botonEnviar()).toBeDisabled();
    });
  });

  describe("reserva no elegible al cargar (errorInicial 422)", () => {
    it("el aviso va arriba (tras el resumen y antes de la sección), una sola vez", () => {
      renderizar(undefined, 422);
      const aviso = screen.getByRole("alert");
      expect(aviso).toHaveTextContent("No puedes calificar esta reserva");
      expect(aviso).toHaveTextContent(PLAZO);
      expect(sigue(screen.getByText("Resumen de la reserva"), aviso)).toBe(true);
      expect(sigue(aviso, screen.getByRole("region", { name: "maria_lopez" }))).toBe(true);
      expect(screen.getAllByRole("alert")).toHaveLength(1);
    });

    it("estrellas de solo lectura, comentario deshabilitado y envío bloqueado", () => {
      const calificar = renderizar(undefined, 422);
      expect(screen.queryByRole("radiogroup")).not.toBeInTheDocument();
      expect(screen.getByRole("img", { name: "0 de 5 estrellas" })).toBeInTheDocument();
      expect(comentario()).toBeDisabled();
      expect(botonEnviar()).toBeDisabled();
      fireEvent.submit(botonEnviar().closest("form")!);
      expect(dialogo()).not.toBeInTheDocument();
      expect(calificar).not.toHaveBeenCalled();
    });
  });

  describe("cancelar", () => {
    it("«Cancelar» lleva a /reservas/{id} sin enviar", () => {
      const calificar = renderizar();
      expect(screen.getByRole("link", { name: "Cancelar" })).toHaveAttribute("href", `/reservas/${RESERVA}`);
      expect(calificar).not.toHaveBeenCalled();
    });
  });
});

describe("CalificacionRegistrada (reingreso con una calificación ya registrada)", () => {
  const registrada: CalificacionLeida = {
    puntuacion: 4,
    comentario: "Buen comportamiento",
    promedioArrendatario: 4.5,
    totalCalificaciones: 2,
  };
  const mostrar = (calificacion: CalificacionLeida = registrada, recienEnviada?: boolean) =>
    render(
      <CalificacionRegistrada
        resumen={<p>Resumen de la reserva</p>}
        calificacion={calificacion}
        nombreArrendatario="maria_lopez"
        recienEnviada={recienEnviada}
      />,
    );

  it("sin «recienEnviada» no muestra «Calificación enviada.», pero sí todo lo demás", () => {
    mostrar();
    expect(screen.queryByText("Calificación enviada.")).not.toBeInTheDocument();
    expect(screen.queryByRole("status")).not.toBeInTheDocument();
    expect(screen.getByText("Resumen de la reserva")).toBeInTheDocument();
    expect(screen.getByText("4.5 de promedio · 2 calificaciones")).toBeInTheDocument();
    expect(screen.getByRole("img", { name: "4 de 5 estrellas" })).toBeInTheDocument();
    expect(screen.getByText("Buen comportamiento")).toBeInTheDocument();
    expect(screen.getByText("Solo lectura: las calificaciones no se editan ni se eliminan.")).toBeInTheDocument();
  });

  it("con «recienEnviada» muestra el aviso con el promedio", () => {
    mostrar(registrada, true);
    expect(screen.getByRole("status")).toHaveTextContent("Calificación enviada.");
    expect(screen.getByRole("status")).toHaveTextContent("Promedio actual del arrendatario: 4.5.");
  });

  it("no tiene controles", () => {
    mostrar();
    expect(screen.queryAllByRole("button")).toHaveLength(0);
    expect(screen.queryAllByRole("link")).toHaveLength(0);
    expect(screen.queryByRole("radiogroup")).not.toBeInTheDocument();
    expect(screen.queryByRole("textbox")).not.toBeInTheDocument();
  });

  it("comentario null: «Sin comentario.»", () => {
    mostrar({ ...registrada, comentario: null });
    const tuCalificacion = screen.getByRole("region", { name: "Tu calificación" });
    expect(within(tuCalificacion).getByText("Sin comentario.")).toBeInTheDocument();
  });

  it("promedio entero con un decimal y total en singular", () => {
    mostrar({ ...registrada, promedioArrendatario: 5, totalCalificaciones: 1 });
    expect(screen.getByText("5.0 de promedio · 1 calificación")).toBeInTheDocument();
  });
});
