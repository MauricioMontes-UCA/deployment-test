import { render, screen, within } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";
import type { PantallaCalificacionArrendatario } from "../datos";

const datos = vi.hoisted(() => ({ cargarPantallaArrendatario: vi.fn() }));
vi.mock("../datos", () => datos);
vi.mock("@/app/actions/calificacion-arrendatario", () => ({ calificarArrendatario: vi.fn() }));
vi.mock("@/app/actions/auth", () => ({ cerrarSesion: vi.fn() }));
vi.mock("next/navigation", async (importOriginal) => ({
  ...(await importOriginal<typeof import("next/navigation")>()),
  redirect: vi.fn((url: string) => {
    throw new Error(`REDIRECT:${url}`);
  }),
}));

const { default: Pagina } = await import("../page");

const RESERVA = "5a3f2c10-8d4e-4b1a-9c7e-1f2a3b4c5d6e";
// Variables (no literales sueltos): compilan con y sin `email`/`createdAt` en UsuarioActual.
const arrendador = { id: "u2", nombreUsuario: "jose_r", email: "jose@example.com", rol: "ARRENDADOR", createdAt: "2026-11-01T00:00:00.000Z" } as const;
const arrendatario = { id: "u1", nombreUsuario: "maria_lopez", email: "maria@example.com", rol: "ARRENDATARIO", createdAt: "2026-11-01T00:00:00.000Z" } as const;
const datosLista = {
  reservaId: RESERVA,
  fechaInicio: "2026-11-02",
  fechaFin: "2026-11-04",
  finalizadaEl: "2026-11-04",
  titulo: "Taladro industrial Bosch",
  foto: "/uploads/bienes/t.jpg",
  arrendatario: "maria_lopez",
  elegible: true,
  calificacion: { resena: null, promedioArrendatario: null, totalCalificaciones: 0 },
};
const RESENA = {
  resenaId: "9b1c2d3e-4f50-4a6b-8c7d-0e1f2a3b4c5d",
  puntuacion: 4,
  comentario: "Buen comportamiento",
  creadaEn: "2026-11-05T15:00:00.000Z",
} as const;
/** Ya calificada: 4.5 de promedio entre 2 calificaciones del arrendatario. */
const datosCalificada = {
  ...datosLista,
  calificacion: { resena: RESENA, promedioArrendatario: 4.5, totalCalificaciones: 2 },
};
const PLAZO = "Solo puedes calificar reservas finalizadas dentro de los 14 días posteriores a la devolución.";

async function renderizar(pantalla: PantallaCalificacionArrendatario) {
  datos.cargarPantallaArrendatario.mockResolvedValue(pantalla);
  render(
    await Pagina({ params: Promise.resolve({ reservaId: RESERVA }) } as PageProps<"/reservas/[reservaId]/calificar-arrendatario">),
  );
}

afterEach(() => {
  vi.clearAllMocks();
});

describe("CalificarArrendatarioPage", () => {
  it("el arrendador ve encabezado, tarjeta con «Arrendatario:» y el formulario", async () => {
    await renderizar({ tipo: "lista", usuario: arrendador, datos: datosLista });
    expect(datos.cargarPantallaArrendatario).toHaveBeenCalledWith(RESERVA);
    expect(screen.getByRole("heading", { level: 1, name: "Califica al arrendatario" })).toBeInTheDocument();
    expect(screen.getByText("Arrendatario: maria_lopez")).toBeInTheDocument();
    expect(screen.queryByText(/^Arrendador:/)).not.toBeInTheDocument();
    expect(screen.getByText("02/11/2026 → 04/11/2026 · Finalizada el 04/11/2026")).toBeInTheDocument();
    expect(screen.getByRole("region", { name: "maria_lopez" })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Enviar calificación" })).toBeDisabled();
    expect(screen.queryByText(/RSV-/)).not.toBeInTheDocument();
  });

  it("una reserva no elegible carga con el aviso del 422 y bloqueada", async () => {
    await renderizar({ tipo: "lista", usuario: arrendador, datos: { ...datosLista, elegible: false } });
    expect(screen.getByRole("alert")).toHaveTextContent(PLAZO);
    expect(screen.getByRole("textbox", { name: "Comentario (opcional)" })).toBeDisabled();
    expect(screen.getByRole("button", { name: "Enviar calificación" })).toBeDisabled();
  });

  it("sin reseña pero con historial muestra el formulario, no la solo lectura", async () => {
    await renderizar({
      tipo: "lista",
      usuario: arrendador,
      datos: { ...datosLista, calificacion: { resena: null, promedioArrendatario: 3.7, totalCalificaciones: 3 } },
    });
    expect(screen.getByRole("radiogroup", { name: "Calificación del arrendatario" })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Enviar calificación" })).toBeInTheDocument();
    expect(screen.queryByRole("region", { name: "Tu calificación" })).not.toBeInTheDocument();
  });

  describe("ya calificada (reingreso)", () => {
    const principal = () => within(screen.getByRole("main"));

    it("muestra la calificación en solo lectura con puntuación, comentario, promedio y total", async () => {
      await renderizar({ tipo: "lista", usuario: arrendador, datos: datosCalificada });
      expect(screen.getByRole("heading", { level: 1, name: "Califica al arrendatario" })).toBeInTheDocument();
      expect(screen.getByText("Ya calificaste al arrendatario en esta reserva.")).toBeInTheDocument();
      expect(screen.getByText("Arrendatario: maria_lopez")).toBeInTheDocument();
      expect(screen.getByText("4.5 de promedio · 2 calificaciones")).toBeInTheDocument();
      const tuCalificacion = screen.getByRole("region", { name: "Tu calificación" });
      expect(within(tuCalificacion).getByRole("img", { name: "4 de 5 estrellas" })).toBeInTheDocument();
      expect(within(tuCalificacion).getByText("Buen comportamiento")).toBeInTheDocument();
      expect(screen.getByText("Solo lectura: las calificaciones no se editan ni se eliminan.")).toBeInTheDocument();
    });

    it("no repite «Calificación enviada.» al volver a entrar", async () => {
      await renderizar({ tipo: "lista", usuario: arrendador, datos: datosCalificada });
      expect(screen.queryByText("Calificación enviada.")).not.toBeInTheDocument();
      expect(screen.queryByText(/Promedio actual del arrendatario/)).not.toBeInTheDocument();
      expect(screen.queryByRole("status")).not.toBeInTheDocument();
    });

    it("no hay formulario ni controles para enviar, editar o eliminar", async () => {
      await renderizar({ tipo: "lista", usuario: arrendador, datos: datosCalificada });
      expect(principal().queryByRole("form")).not.toBeInTheDocument();
      expect(principal().queryAllByRole("button")).toHaveLength(0);
      expect(principal().queryAllByRole("link")).toHaveLength(0);
      expect(principal().queryByRole("radiogroup")).not.toBeInTheDocument();
      expect(principal().queryByRole("textbox")).not.toBeInTheDocument();
      expect(document.querySelector("main form")).toBeNull();
    });

    it("comentario null: muestra «Sin comentario.»", async () => {
      await renderizar({
        tipo: "lista",
        usuario: arrendador,
        datos: { ...datosCalificada, calificacion: { ...datosCalificada.calificacion, resena: { ...RESENA, comentario: null } } },
      });
      const tuCalificacion = screen.getByRole("region", { name: "Tu calificación" });
      expect(within(tuCalificacion).getByText("Sin comentario.")).toBeInTheDocument();
    });

    it("después de los 14 días sigue en solo lectura, sin el aviso de plazo", async () => {
      await renderizar({ tipo: "lista", usuario: arrendador, datos: { ...datosCalificada, elegible: false } });
      expect(screen.getByRole("region", { name: "Tu calificación" })).toBeInTheDocument();
      expect(screen.queryByText(PLAZO)).not.toBeInTheDocument();
      expect(screen.queryByRole("alert")).not.toBeInTheDocument();
    });

    it("el promedio se muestra siempre con un decimal", async () => {
      await renderizar({
        tipo: "lista",
        usuario: arrendador,
        datos: { ...datosCalificada, calificacion: { ...datosCalificada.calificacion, promedioArrendatario: 4, totalCalificaciones: 1 } },
      });
      expect(screen.getByText("4.0 de promedio · 1 calificación")).toBeInTheDocument();
    });
  });

  it("el rol Arrendatario ve exactamente «No tienes permiso para ver esta pantalla.»", async () => {
    await renderizar({ tipo: "sin-permiso", usuario: arrendatario });
    expect(screen.getByRole("heading", { name: "No tienes permiso para ver esta pantalla." })).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "Ir al inicio" })).toHaveAttribute("href", "/");
    expect(screen.queryByRole("button", { name: "Enviar calificación" })).not.toBeInTheDocument();
  });

  it("una reserva inexistente o ajena muestra «No encontramos esa reserva.»", async () => {
    await renderizar({ tipo: "no-encontrada", usuario: arrendador });
    expect(screen.getByRole("heading", { name: "No encontramos esa reserva." })).toBeInTheDocument();
  });

  it("sin sesión pasa por /sesion-vencida", async () => {
    await expect(renderizar({ tipo: "sin-sesion" })).rejects.toThrow("REDIRECT:/sesion-vencida");
  });

  it("un error inesperado de carga se propaga a error.tsx", async () => {
    datos.cargarPantallaArrendatario.mockRejectedValue(new Error("reservas/:id respondió 500."));
    await expect(
      Pagina({ params: Promise.resolve({ reservaId: RESERVA }) } as PageProps<"/reservas/[reservaId]/calificar-arrendatario">),
    ).rejects.toThrow("respondió 500");
  });
});
