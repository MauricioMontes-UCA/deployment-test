import { afterEach, describe, expect, it, vi } from "vitest";
import type { RespuestaApiCruda } from "@/lib/api";
import type { ResultadoUsuario } from "@/lib/usuario-actual";

const api = vi.hoisted(() => ({ llamarApi: vi.fn() }));
vi.mock("@/lib/api", () => api);
const sesion = vi.hoisted(() => ({ obtenerUsuarioActual: vi.fn() }));
vi.mock("@/lib/usuario-actual", () => sesion);

const { cargarPantallaArrendatario, ErrorDeCarga } = await import("../datos");

const RESERVA = "5a3f2c10-8d4e-4b1a-9c7e-1f2a3b4c5d6e";
/** 10/11/2026 a mediodía en El Salvador: 6 días después de la finalización. */
const AHORA = new Date("2026-11-10T18:00:00Z");

// Variable (no literal suelto): compila con y sin `email`/`createdAt` en UsuarioActual.
const datosUsuario = { id: "u2", nombreUsuario: "jose_r", email: "jose@example.com", createdAt: "2026-11-01T00:00:00.000Z" };
const usuario = (rol: "ARRENDADOR" | "ARRENDATARIO" = "ARRENDADOR"): ResultadoUsuario => ({
  estado: "ok",
  usuario: { ...datosUsuario, rol },
});
const cruda = (status: number, datos: unknown = null): RespuestaApiCruda => ({ status, datos, mensajes: [] });

/** Respuesta de `GET /reservas/:id` vista por el arrendador dueño (BE-27.2). */
function reservaApi(cambios: Record<string, unknown> = {}) {
  return cruda(200, {
    id: RESERVA,
    bienId: "b1",
    arrendatarioId: "u1",
    fechaInicio: "2026-11-02",
    fechaFin: "2026-11-04",
    estado: "FINALIZADA",
    finalizadaEn: "2026-11-04T16:00:00.000Z",
    bien: { id: "b1", titulo: "Taladro industrial Bosch", fotoPrincipalUrl: "/uploads/bienes/t.jpg" },
    arrendatario: { id: "u1", nombreUsuario: "maria_lopez" },
    arrendador: { id: "u2", nombreUsuario: "jose_r" },
    ...cambios,
  });
}

const RUTA_CALIFICACION = `reservas/${RESERVA}/resenas/arrendatario`;
const SIN_CALIFICACION = { resena: null, promedioArrendatario: null, totalCalificaciones: 0 };
const RESENA = {
  resenaId: "9b1c2d3e-4f50-4a6b-8c7d-0e1f2a3b4c5d",
  puntuacion: 4,
  comentario: "Buen comportamiento",
  creadaEn: "2026-11-05T15:00:00.000Z",
};
const CALIFICADA = { resena: RESENA, promedioArrendatario: 4.5, totalCalificaciones: 2 };

/** Respuesta de `GET /reservas/:id/resenas/arrendatario` (BE-16.2). */
const calificacionApi = (cuerpo: unknown = SIN_CALIFICACION) => cruda(200, cuerpo);

/** Cada ruta responde lo suyo: la reserva y la calificación se piden por separado. */
function responder(
  resultado: ResultadoUsuario,
  reserva?: RespuestaApiCruda,
  calificacion: RespuestaApiCruda = calificacionApi(),
) {
  sesion.obtenerUsuarioActual.mockResolvedValue(resultado);
  if (reserva) {
    api.llamarApi.mockImplementation(async (ruta: string) =>
      ruta === RUTA_CALIFICACION ? calificacion : reserva,
    );
  }
}

afterEach(() => {
  vi.resetAllMocks();
});

describe("cargarPantallaArrendatario", () => {
  it("el arrendador dueño ve la reserva con el nombre del arrendatario", async () => {
    responder(usuario(), reservaApi());
    expect(await cargarPantallaArrendatario(RESERVA, AHORA)).toEqual({
      tipo: "lista",
      usuario: { ...datosUsuario, rol: "ARRENDADOR" },
      datos: {
        reservaId: RESERVA,
        fechaInicio: "2026-11-02",
        fechaFin: "2026-11-04",
        finalizadaEl: "2026-11-04",
        titulo: "Taladro industrial Bosch",
        foto: "/uploads/bienes/t.jpg",
        arrendatario: "maria_lopez",
        elegible: true,
        calificacion: SIN_CALIFICACION,
      },
    });
    expect(api.llamarApi.mock.calls.map(([ruta]) => ruta)).toEqual([`reservas/${RESERVA}`, RUTA_CALIFICACION]);
  });

  it("pide el usuario, la reserva y la calificación en paralelo", async () => {
    let resolver!: (r: ResultadoUsuario) => void;
    sesion.obtenerUsuarioActual.mockReturnValue(new Promise<ResultadoUsuario>((r) => (resolver = r)));
    api.llamarApi.mockImplementation(async (ruta: string) =>
      ruta === RUTA_CALIFICACION ? calificacionApi() : reservaApi(),
    );
    const carga = cargarPantallaArrendatario(RESERVA, AHORA);
    expect(api.llamarApi).toHaveBeenCalledTimes(2);
    resolver(usuario());
    expect(await carga).toMatchObject({ tipo: "lista" });
  });

  describe("calificación registrada (GET de BE-16.2)", () => {
    const calificacionCargada = async (cuerpo: unknown, cambios: Record<string, unknown> = {}, ahora = AHORA) => {
      responder(usuario(), reservaApi(cambios), calificacionApi(cuerpo));
      const pantalla = await cargarPantallaArrendatario(RESERVA, ahora);
      if (pantalla.tipo !== "lista") throw new Error(`se esperaba «lista», llegó «${pantalla.tipo}»`);
      return pantalla.datos;
    };

    it("con reseña: la entrega con el promedio y el total", async () => {
      expect((await calificacionCargada(CALIFICADA)).calificacion).toEqual(CALIFICADA);
    });

    it("sin reseña ni historial: promedio null y total 0", async () => {
      expect((await calificacionCargada(SIN_CALIFICACION)).calificacion).toEqual(SIN_CALIFICACION);
    });

    it("sin reseña en esta reserva conserva el promedio y el total reales del arrendatario", async () => {
      const otras = { resena: null, promedioArrendatario: 3.7, totalCalificaciones: 3 };
      expect((await calificacionCargada(otras)).calificacion).toEqual(otras);
    });

    it("comentario null llega como null", async () => {
      const datos = await calificacionCargada({ ...CALIFICADA, resena: { ...RESENA, comentario: null } });
      expect(datos.calificacion.resena?.comentario).toBeNull();
    });

    it("al volver a entrar después de los 14 días sigue mostrando la reseña", async () => {
      const datos = await calificacionCargada(CALIFICADA, {}, new Date("2026-12-20T18:00:00Z"));
      expect(datos.elegible).toBe(false);
      expect(datos.calificacion.resena).toEqual(RESENA);
    });

    it("una reserva no finalizada se carga sin reseña y no elegible", async () => {
      const datos = await calificacionCargada(SIN_CALIFICACION, { estado: "EN_CURSO", finalizadaEn: null });
      expect(datos.elegible).toBe(false);
      expect(datos.calificacion).toEqual(SIN_CALIFICACION);
    });

    it("401 en la calificación: sesión vencida", async () => {
      responder(usuario(), reservaApi(), cruda(401));
      expect(await cargarPantallaArrendatario(RESERVA, AHORA)).toEqual({ tipo: "sin-sesion" });
    });

    it("403 en la calificación: sin permiso", async () => {
      responder(usuario(), reservaApi(), cruda(403));
      expect(await cargarPantallaArrendatario(RESERVA, AHORA)).toMatchObject({ tipo: "sin-permiso" });
    });

    it("404 en la calificación (reserva inexistente o ajena): no encontrada", async () => {
      responder(usuario(), reservaApi(), cruda(404));
      expect(await cargarPantallaArrendatario(RESERVA, AHORA)).toMatchObject({ tipo: "no-encontrada" });
    });

    it("una reserva 404 gana aunque la calificación responda otra cosa", async () => {
      responder(usuario(), cruda(404), cruda(500));
      expect(await cargarPantallaArrendatario(RESERVA, AHORA)).toMatchObject({ tipo: "no-encontrada" });
    });

    it.each([
      ["500", cruda(500)],
      ["503", cruda(503)],
      ["sin respuesta (red o tiempo agotado)", cruda(0)],
      ["400 inesperado", cruda(400)],
      ["200 sin cuerpo", cruda(200, null)],
      ["200 con cuerpo inválido", calificacionApi({ resena: null })],
      ["200 con reseña inválida", calificacionApi({ ...CALIFICADA, resena: { ...RESENA, puntuacion: 9 } })],
      ["200 incoherente (reseña con total 0)", calificacionApi({ ...CALIFICADA, promedioArrendatario: null, totalCalificaciones: 0 })],
    ])("calificación %s: ErrorDeCarga, nunca el formulario por defecto", async (_caso, calificacion) => {
      responder(usuario(), reservaApi(), calificacion);
      await expect(cargarPantallaArrendatario(RESERVA, AHORA)).rejects.toBeInstanceOf(ErrorDeCarga);
    });
  });

  it("el rol Arrendatario no tiene permiso", async () => {
    responder(usuario("ARRENDATARIO"), reservaApi());
    expect(await cargarPantallaArrendatario(RESERVA, AHORA)).toMatchObject({ tipo: "sin-permiso" });
  });

  it("sin sesión o con 401 (en auth/me o en la reserva)", async () => {
    responder({ estado: "sin-sesion" }, cruda(401));
    expect(await cargarPantallaArrendatario(RESERVA, AHORA)).toEqual({ tipo: "sin-sesion" });
    responder(usuario(), cruda(401));
    expect(await cargarPantallaArrendatario(RESERVA, AHORA)).toEqual({ tipo: "sin-sesion" });
  });

  it.each([404, 403])("una reserva inexistente o ajena (%i) es «no encontrada»", async (status) => {
    responder(usuario(), cruda(status));
    expect(await cargarPantallaArrendatario(RESERVA, AHORA)).toMatchObject({ tipo: "no-encontrada" });
  });

  it("un id que no es UUID es «no encontrada» sin consultar la reserva", async () => {
    responder(usuario());
    expect(await cargarPantallaArrendatario("no-es-uuid", AHORA)).toMatchObject({ tipo: "no-encontrada" });
    expect(api.llamarApi).not.toHaveBeenCalled();
  });

  describe("elegibilidad (misma regla que el backend para H16)", () => {
    const elegible = async (cambios: Record<string, unknown>, ahora: Date) => {
      responder(usuario(), reservaApi(cambios));
      const p = await cargarPantallaArrendatario(RESERVA, ahora);
      return p.tipo === "lista" ? p.datos.elegible : undefined;
    };

    it("día 14 en El Salvador: elegible; día 15: no", async () => {
      expect(await elegible({}, new Date("2026-11-19T05:59:59Z"))).toBe(true);
      expect(await elegible({}, new Date("2026-11-19T06:00:00Z"))).toBe(false);
    });

    it.each(["CONFIRMADA", "EN_CURSO", "EN_COLA", "RECHAZADA", "CANCELADA"])("%s: no elegible", async (estado) => {
      expect(await elegible({ estado, finalizadaEn: null }, AHORA)).toBe(false);
    });

    it("FINALIZADA sin finalizadaEn: no elegible", async () => {
      expect(await elegible({ finalizadaEn: null }, AHORA)).toBe(false);
    });
  });

  it.each([
    ["auth/me con error", { estado: "error" } as ResultadoUsuario, reservaApi()],
    ["reserva con 500", usuario(), cruda(500)],
    ["reserva sin respuesta", usuario(), cruda(0)],
    ["reserva sin arrendatario (backend anterior)", usuario(), reservaApi({ arrendatario: undefined })],
  ])("%s lanza ErrorDeCarga", async (_caso, resultado, reserva) => {
    responder(resultado, reserva);
    await expect(cargarPantallaArrendatario(RESERVA, AHORA)).rejects.toBeInstanceOf(ErrorDeCarga);
  });
});
