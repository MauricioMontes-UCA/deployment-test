/** Mismo estado de carga que la calificación de FE-15.1. */
export { default } from "../calificar/loading";
