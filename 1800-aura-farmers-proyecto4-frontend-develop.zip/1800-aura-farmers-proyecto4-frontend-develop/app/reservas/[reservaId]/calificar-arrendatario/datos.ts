import { llamarApi, type RespuestaApiCruda } from "@/lib/api";
import {
  leerConsultaCalificacion,
  type ConsultaCalificacionArrendatario,
} from "@/lib/calificacion-arrendatario";
import { hoyEnElSalvador } from "@/lib/disponibilidad";
import { puedeCalificarse } from "@/lib/resenas";
import { obtenerUsuarioActual, type UsuarioActual } from "@/lib/usuario-actual";

export type { UsuarioActual };

const ID_RESERVA = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Lo que la pantalla necesita, tomado tal cual de `GET /reservas/:id` y de
 * `GET /reservas/:id/resenas/arrendatario`.
 */
export type DatosCalificacionArrendatario = {
  reservaId: string;
  fechaInicio: string;
  fechaFin: string;
  /** Día de la finalización en El Salvador (AAAA-MM-DD), si la reserva terminó. */
  finalizadaEl: string | null;
  titulo: string;
  /** Ruta de la foto principal (`/uploads/…`), si el bien tiene. */
  foto: string | null;
  /** Nombre de usuario del arrendatario que se califica. */
  arrendatario: string;
  /**
   * Si la reserva cumple estado y plazo para calificarse, con las reglas del
   * backend (las mismas que H15). Si no, se muestra el aviso del 422.
   */
  elegible: boolean;
  /**
   * Calificación ya registrada (o `null`) y promedio y total del arrendatario
   * (BE-16.2). Con reseña, la pantalla queda en solo lectura.
   */
  calificacion: ConsultaCalificacionArrendatario;
};

export type PantallaCalificacionArrendatario =
  /** Sin sesión o con la sesión rechazada (401): la página pasa por `/sesion-vencida`. */
  | { tipo: "sin-sesion" }
  | { tipo: "no-encontrada"; usuario: UsuarioActual }
  | { tipo: "sin-permiso"; usuario: UsuarioActual }
  | { tipo: "lista"; usuario: UsuarioActual; datos: DatosCalificacionArrendatario };

/** Error inesperado del backend: lo muestra `error.tsx` con «Reintentar». */
export class ErrorDeCarga extends Error {
  constructor(recurso: string, status: number) {
    super(status === 0 ? `No se pudo consultar ${recurso}.` : `${recurso} respondió ${status}.`);
    this.name = "ErrorDeCarga";
  }
}

const esObjeto = (valor: unknown): valor is Record<string, unknown> =>
  typeof valor === "object" && valor !== null;

/** Lee de `GET /reservas/:id` (BE-6 y BE-27.2) lo que muestra la pantalla. */
function leerReserva(datos: unknown, ahora: Date) {
  if (!esObjeto(datos) || !esObjeto(datos.bien) || !esObjeto(datos.arrendatario)) return null;
  const { estado, fechaInicio, fechaFin, finalizadaEn } = datos;
  const { titulo, fotoPrincipalUrl } = datos.bien;
  const { nombreUsuario } = datos.arrendatario;
  if (
    typeof estado !== "string" ||
    typeof fechaInicio !== "string" ||
    typeof fechaFin !== "string" ||
    typeof titulo !== "string" ||
    typeof nombreUsuario !== "string" ||
    (finalizadaEn != null && typeof finalizadaEn !== "string")
  ) {
    return null;
  }
  const finalizada = typeof finalizadaEn === "string" && !Number.isNaN(Date.parse(finalizadaEn)) ? finalizadaEn : null;
  return {
    fechaInicio,
    fechaFin,
    finalizadaEl: finalizada ? hoyEnElSalvador(new Date(finalizada)) : null,
    titulo,
    foto: typeof fotoPrincipalUrl === "string" ? fotoPrincipalUrl : null,
    arrendatario: nombreUsuario,
    elegible: puedeCalificarse({ estado, finalizadaEn: finalizada }, ahora),
  };
}

/**
 * Decide qué muestra `/reservas/[reservaId]/calificar-arrendatario`: el usuario
 * de la sesión (`obtenerUsuarioActual`), `GET /reservas/:id` y
 * `GET /reservas/:id/resenas/arrendatario` (BE-16.2), en paralelo.
 * Decide en orden: sesión, rol (solo ARRENDADOR), la reserva y la
 * calificación. Desde BE-27.2 el arrendador dueño del bien puede leer la
 * reserva; una ajena responde 404, igual que una inexistente.
 *
 * Si la calificación no se puede leer (5xx, red o respuesta inválida) se lanza
 * `ErrorDeCarga`: nunca se muestra el formulario sin saber si ya existe una.
 */
export async function cargarPantallaArrendatario(
  reservaId: string,
  ahora: Date = new Date(),
): Promise<PantallaCalificacionArrendatario> {
  const idValido = ID_RESERVA.test(reservaId);
  const consultar = (ruta: string) =>
    idValido ? llamarApi(ruta) : Promise.resolve<RespuestaApiCruda | null>(null);
  const [sesion, reserva, consulta] = await Promise.all([
    obtenerUsuarioActual(),
    consultar(`reservas/${reservaId}`),
    consultar(`reservas/${reservaId}/resenas/arrendatario`),
  ]);

  if (sesion.estado === "sin-sesion") return { tipo: "sin-sesion" };
  if (sesion.estado === "error") throw new ErrorDeCarga("auth/me", 0);
  const { usuario } = sesion;

  if (usuario.rol !== "ARRENDADOR") return { tipo: "sin-permiso", usuario };
  if (!reserva || !consulta) return { tipo: "no-encontrada", usuario };

  if (reserva.status === 401 || consulta.status === 401) return { tipo: "sin-sesion" };
  if (reserva.status === 404 || reserva.status === 403) return { tipo: "no-encontrada", usuario };
  const datosReserva = reserva.status === 200 ? leerReserva(reserva.datos, ahora) : null;
  if (!datosReserva) throw new ErrorDeCarga("reservas/:id", reserva.status);

  // BE-16.2: 403 si el rol no es ARRENDADOR; 404 si la reserva no existe o es ajena.
  if (consulta.status === 403) return { tipo: "sin-permiso", usuario };
  if (consulta.status === 404) return { tipo: "no-encontrada", usuario };
  const calificacion = consulta.status === 200 ? leerConsultaCalificacion(consulta.datos) : null;
  if (!calificacion) throw new ErrorDeCarga("reservas/:id/resenas/arrendatario", consulta.status);

  return { tipo: "lista", usuario, datos: { reservaId, ...datosReserva, calificacion } };
}
