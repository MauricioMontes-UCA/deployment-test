"use client"; // Los error boundaries son componentes de cliente.

/** Mismo estado de error con «Reintentar» que la calificación de FE-15.1. */
export { default } from "../calificar/error";
