"use client";

import Link from "next/link";
import { unstable_rethrow } from "next/navigation";
import { useId, useRef, useState, useTransition, type FormEvent, type ReactNode } from "react";
import {
  Alerta,
  AreaDeTexto,
  Avatar,
  Boton,
  Calificacion,
  DialogoDeConfirmacion,
  clasesBoton,
} from "@/components/ui";
import {
  armarPayloadArrendatario,
  calificacionValida,
  clasificarErrorArrendatario,
  formatearPromedio,
  textoTotalCalificaciones,
  type CalificarArrendatarioPayload,
  type ResultadoCalificacion,
  type ResumenCalificacion,
} from "@/lib/calificacion-arrendatario";
import {
  LIMITE_COMENTARIO,
  contarCaracteres,
  errorComentario,
  normalizarComentario,
  type CalificacionFormulario,
  type ErrorResenas,
  type TipoErrorResenas,
} from "@/lib/resenas";

type FormularioCalificacionArrendatarioProps = {
  reservaId: string;
  /** Nombre de usuario del arrendatario: título de la sección y de la tarjeta enviada. */
  nombreArrendatario: string;
  /** Resumen de la reserva (`TarjetaResumenReserva`), arriba del formulario. */
  resumen: ReactNode;
  /** Envía la calificación. Con 201 devuelve el promedio y el total reales. */
  calificar: (payload: CalificarArrendatarioPayload) => Promise<ResultadoCalificacion>;
  /**
   * Bloqueo que ya se conoce al cargar (422: reserva no finalizada o fuera de
   * plazo). El aviso va arriba, como en el frame «Fuera de plazo» de Figma, los
   * campos quedan deshabilitados y no se puede enviar.
   */
  errorInicial?: 409 | 422;
};

/**
 * Calificación en solo lectura: la recién enviada (lo enviado más el 201) o la
 * ya registrada al volver a entrar (`GET …/resenas/arrendatario`).
 */
export type CalificacionLeida = { puntuacion: number; comentario: string | null } & ResumenCalificacion;

const SIN_CALIFICAR: CalificacionFormulario = { puntuacion: 0, comentario: "" };

/** El contador cuenta igual que la validación y el backend: code points, sin los espacios de los extremos. */
const contarComoBackend = (texto: string) => contarCaracteres(normalizarComentario(texto));

/** Avisos de Figma para las respuestas que bloquean (409 y 422), con los mensajes de FE-16.1. */
const AVISO_BLOQUEO: Partial<
  Record<TipoErrorResenas, { tono: "advertencia" | "error"; titulo?: string; mensaje: string }>
> = {
  "ya-calificada": {
    tono: "advertencia",
    mensaje: "Ya calificaste al arrendatario en esta reserva.",
  },
  "fuera-de-plazo": {
    tono: "error",
    titulo: "No puedes calificar esta reserva",
    mensaje:
      "Solo puedes calificar reservas finalizadas dentro de los 14 días posteriores a la devolución.",
  },
};

/**
 * Formulario de calificación del arrendatario (FE-16.1): una puntuación de 1 a
 * 5 y un comentario opcional, confirmación antes de enviar y, con el 201, el
 * mismo espacio pasa a solo lectura con el promedio del arrendatario. No
 * conoce el backend: recibe `calificar`.
 */
export function FormularioCalificacionArrendatario({
  reservaId,
  nombreArrendatario,
  resumen,
  calificar,
  errorInicial,
}: FormularioCalificacionArrendatarioProps) {
  const [calificacion, setCalificacion] = useState<CalificacionFormulario>(SIN_CALIFICAR);
  const [confirmando, setConfirmando] = useState(false);
  const [enviando, setEnviando] = useState(false);
  const [enviada, setEnviada] = useState<CalificacionLeida | null>(null);
  // Bloqueo conocido al cargar: no cambia durante la vida del formulario.
  const [bloqueoInicial] = useState<ErrorResenas | null>(() =>
    errorInicial === undefined ? null : clasificarErrorArrendatario(errorInicial),
  );
  // Error de un envío real (respuesta del servidor o red).
  const [error, setError] = useState<ErrorResenas | null>(null);
  // Candado síncrono: el estado de React no alcanza a frenar dos clics seguidos.
  const enviandoAhora = useRef(false);
  // Las server actions se invocan dentro de una transición (convención de Next):
  // así una redirección (401 → /sesion-vencida) llega al router.
  const [, startTransition] = useTransition();
  const idSeccion = useId();

  const bloqueado = Boolean(bloqueoInicial || error?.bloqueante);
  const habilitado = !enviando && !bloqueado && calificacionValida(calificacion);
  const avisoInicial = bloqueoInicial ? AVISO_BLOQUEO[bloqueoInicial.tipo] : undefined;
  const aviso = error ? AVISO_BLOQUEO[error.tipo] : undefined;

  function pedirConfirmacion(evento: FormEvent<HTMLFormElement>) {
    evento.preventDefault();
    if (habilitado) setConfirmando(true);
  }

  function confirmar() {
    const payload = armarPayloadArrendatario(calificacion);
    setConfirmando(false);
    if (!payload || enviandoAhora.current || bloqueado) return;

    enviandoAhora.current = true;
    setEnviando(true);
    setError(null);
    startTransition(async () => {
      let resultado: ResultadoCalificacion;
      try {
        resultado = await calificar(payload);
      } catch (excepcion) {
        // Una redirección de Next (sesión vencida) no es un error de red.
        unstable_rethrow(excepcion);
        resultado = { ok: false, status: null };
      }
      if (resultado.ok) {
        // Se muestra lo que se envió y lo que devolvió el backend; el candado
        // queda cerrado: no hay más envíos desde esta pantalla.
        setEnviada({
          puntuacion: payload.puntuacion,
          comentario: payload.comentario ?? null,
          promedioArrendatario: resultado.promedioArrendatario,
          totalCalificaciones: resultado.totalCalificaciones,
        });
        setEnviando(false);
        return;
      }
      setError(clasificarErrorArrendatario(resultado.status));
      setEnviando(false);
      enviandoAhora.current = false;
    });
  }

  if (enviada) {
    return (
      <CalificacionRegistrada
        resumen={resumen}
        calificacion={enviada}
        nombreArrendatario={nombreArrendatario}
        recienEnviada
      />
    );
  }

  return (
    <>
      <form
        noValidate
        onSubmit={pedirConfirmacion}
        className="flex w-full flex-col gap-5 md:max-w-[720px]"
      >
        {resumen}

        {/* Bloqueo conocido al cargar: arriba, antes de tocar el formulario (Figma «Fuera de plazo»). */}
        {avisoInicial && (
          <Alerta tono={avisoInicial.tono} titulo={avisoInicial.titulo}>
            {avisoInicial.mensaje}
          </Alerta>
        )}

        <section
          aria-labelledby={idSeccion}
          className="flex flex-col gap-espacio-3 border border-borde-default bg-fondo-superficie p-espacio-5"
        >
          <h2 id={idSeccion} className="texto-h4 text-texto-primario">
            {nombreArrendatario}
          </h2>
          <p className="texto-cuerpo-pequeno text-texto-secundario">
            ¿Cómo fue el trato y el cuidado del bien?
          </p>
          <Calificacion
            valor={calificacion.puntuacion}
            etiqueta="Calificación del arrendatario"
            onCambiar={
              bloqueoInicial ? undefined : (puntuacion) => setCalificacion({ ...calificacion, puntuacion })
            }
          />
          <AreaDeTexto
            disabled={Boolean(bloqueoInicial)}
            etiqueta="Comentario (opcional)"
            placeholder="Cuéntanos cómo fue tu experiencia…"
            limite={LIMITE_COMENTARIO}
            contarCaracteres={contarComoBackend}
            value={calificacion.comentario}
            onChange={(evento) => setCalificacion({ ...calificacion, comentario: evento.target.value })}
            error={errorComentario(calificacion.comentario) ?? undefined}
          />
        </section>

        {/* Errores de un envío real, sobre los botones y uno a la vez para anunciarse una sola vez. */}
        {aviso ? (
          <Alerta tono={aviso.tono} titulo={aviso.titulo}>
            {aviso.mensaje}
          </Alerta>
        ) : (
          error && <Alerta tono="error">{error.mensaje}</Alerta>
        )}

        <div className="flex gap-espacio-3 md:justify-end">
          <Link
            href={`/reservas/${encodeURIComponent(reservaId)}`}
            className={clasesBoton({ jerarquia: "secundario", className: "flex-1 md:flex-none" })}
          >
            Cancelar
          </Link>
          <Boton
            type="submit"
            disabled={!habilitado}
            cargando={enviando}
            className="flex-1 md:flex-none"
          >
            Enviar calificación
          </Boton>
        </div>
      </form>

      <DialogoDeConfirmacion
        abierto={confirmando}
        titulo="¿Enviar tu calificación?"
        mensaje="No podrás editarla."
        textoConfirmar="Enviar"
        onConfirmar={confirmar}
        onCancelar={() => setConfirmando(false)}
      />
    </>
  );
}

/**
 * Estado de solo lectura (frame «Enviada» de Figma): el arrendatario con su
 * promedio y total, y la calificación. Sin «Editar», «Eliminar» ni ningún otro
 * control. El aviso «Calificación enviada.» solo aparece tras un POST exitoso
 * (`recienEnviada`), no al volver a entrar.
 */
export function CalificacionRegistrada({
  resumen: tarjetaReserva,
  calificacion,
  nombreArrendatario,
  recienEnviada = false,
}: {
  /** Resumen de la reserva (`TarjetaResumenReserva`), arriba. */
  resumen: ReactNode;
  calificacion: CalificacionLeida;
  nombreArrendatario: string;
  recienEnviada?: boolean;
}) {
  const idTitulo = useId();
  const { promedioArrendatario: promedio, totalCalificaciones: total } = calificacion;
  const resumen = [
    promedio !== null ? `${formatearPromedio(promedio)} de promedio` : null,
    total !== null ? textoTotalCalificaciones(total) : null,
  ]
    .filter(Boolean)
    .join(" · ");

  return (
    <div className="flex w-full flex-col gap-5 md:max-w-[720px]">
      {tarjetaReserva}

      {recienEnviada && (
        <Alerta tono="exito" titulo="Calificación enviada.">
          {promedio !== null && `Promedio actual del arrendatario: ${formatearPromedio(promedio)}.`}
        </Alerta>
      )}

      <article className="flex items-center gap-espacio-3 border border-borde-default bg-fondo-superficie p-espacio-4">
        <Avatar nombre={nombreArrendatario} tamano="grande" />
        <div className="flex min-w-0 flex-col gap-0.5">
          <h2 className="texto-h4 text-texto-primario">{nombreArrendatario}</h2>
          {resumen && <p className="texto-cuerpo-pequeno text-texto-secundario">{resumen}</p>}
        </div>
      </article>

      <section
        aria-labelledby={idTitulo}
        className="flex flex-col gap-espacio-3 border border-borde-default bg-fondo-superficie p-espacio-5"
      >
        <h2 id={idTitulo} className="texto-h4 text-texto-primario">
          Tu calificación
        </h2>
        <Calificacion valor={calificacion.puntuacion} />
        {calificacion.comentario ? (
          <p className="texto-cuerpo text-texto-secundario">{calificacion.comentario}</p>
        ) : (
          <p className="texto-cuerpo-pequeno text-texto-secundario italic">Sin comentario.</p>
        )}
      </section>

      <p className="texto-cuerpo-pequeno text-texto-secundario">
        Solo lectura: las calificaciones no se editan ni se eliminan.
      </p>
    </div>
  );
}
