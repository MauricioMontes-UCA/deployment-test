// app/reservas/[reservaId]/deposito/page.test.tsx

import { beforeEach, describe, expect, it, vi } from "vitest";
import { render, screen } from "@testing-library/react";

const mocks = vi.hoisted(() => ({
  obtenerUsuarioActual: vi.fn(),
  llamarApi: vi.fn(),
  redirect: vi.fn(() => {
    throw new Error("NEXT_REDIRECT");
  }),
}));

vi.mock("@/lib/usuario-actual", () => ({
  obtenerUsuarioActual: mocks.obtenerUsuarioActual,
}));

vi.mock("@/lib/api", () => ({
  llamarApi: mocks.llamarApi,
}));

vi.mock("next/navigation", () => ({
  redirect: mocks.redirect,
}));

vi.mock("@/app/actions/auth", () => ({
  cerrarSesion: vi.fn(),
}));

vi.mock("@/components/ui", async (importOriginal) => {
  const original = await importOriginal<typeof import("@/components/ui")>();

  return {
    ...original,
    NavegacionSuperior: () => null,
    PieDePagina: () => null,
  };
});

import Pagina from "./page";

const reservaId = "11111111-1111-4111-8111-111111111111";

const params = {
  params: Promise.resolve({ reservaId }),
};

const deposito = {
  estado: "PENDIENTE",
  importeOriginal: 40,
  importeRetenido: 0,
  importeLiberado: 0,
  justificacion: null,
  fechaResolucion: null,
  resolucionAutomatica: false,
};

beforeEach(() => {
  vi.clearAllMocks();

  mocks.obtenerUsuarioActual.mockResolvedValue({
    estado: "ok",
    usuario: {
      id: "u1",
      rol: "ARRENDATARIO",
      nombreUsuario: "Ana",
    },
  });

  mocks.llamarApi.mockResolvedValue({
    status: 200,
    datos: deposito,
  });
});

describe("FE-12.1 página", () => {
  it("redirige sin sesión", async () => {
    mocks.obtenerUsuarioActual.mockResolvedValue({
      estado: "sin-sesion",
    });

    await expect(Pagina(params)).rejects.toThrow("NEXT_REDIRECT");

    expect(mocks.redirect).toHaveBeenCalledWith("/sesion-vencida");
    expect(mocks.llamarApi).not.toHaveBeenCalled();
  });

  it("bloquea ARRENDADOR sin consultar API", async () => {
    mocks.obtenerUsuarioActual.mockResolvedValue({
      estado: "ok",
      usuario: {
        id: "u2",
        rol: "ARRENDADOR",
        nombreUsuario: "B",
      },
    });

    render(await Pagina(params));

    expect(
      screen.getByText("No tienes acceso a este depósito."),
    ).toBeInTheDocument();

    expect(mocks.llamarApi).not.toHaveBeenCalled();
  });

  it("redirige en 401", async () => {
    mocks.llamarApi.mockResolvedValue({
      status: 401,
      datos: null,
    });

    await expect(Pagina(params)).rejects.toThrow("NEXT_REDIRECT");

    expect(mocks.redirect).toHaveBeenCalledWith("/sesion-vencida");
  });

  it.each([403, 404, 502])(
    "maneja estado HTTP %i",
    async (status) => {
      mocks.llamarApi.mockResolvedValue({
        status,
        datos: null,
      });

      render(await Pagina(params));

      const texto =
        status === 403
          ? "No tienes acceso a este depósito."
          : status === 404
            ? "No hay depósito de garantía."
            : "No pudimos cargar el depósito.";

      expect(screen.getByText(texto)).toBeInTheDocument();
    },
  );

  it("muestra datos backend en 200", async () => {
    render(await Pagina(params));

    expect(
      screen.getByText("Mi depósito de garantía"),
    ).toBeInTheDocument();

    expect(mocks.llamarApi).toHaveBeenCalledWith(
      `reservas/${reservaId}/deposito`,
    );
  });
});