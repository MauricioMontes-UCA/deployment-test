import type { Metadata } from "next";
import type { ReactNode } from "react";
import { redirect } from "next/navigation";

import { cerrarSesion } from "@/app/actions/auth";
import { llamarApi } from "@/lib/api";
import { obtenerUsuarioActual } from "@/lib/usuario-actual";
import { ID_RESERVA, leerDeposito } from "@/lib/deposito-consulta";
import {
  Contenedor,
  EstadoDePagina,
  NavegacionSuperior,
  PieDePagina,
} from "@/components/ui";

import { VistaDeposito } from "./vista-deposito";

export const metadata: Metadata = {
  title: "Mi depósito de garantía · Arre",
};

export default async function PaginaDeposito({
  params,
}: {
  params: Promise<{ reservaId: string }>;
}) {
  const { reservaId } = await params;
  const sesion = await obtenerUsuarioActual();

  if (sesion.estado === "sin-sesion") {
    redirect("/sesion-vencida");
  }

  if (sesion.estado === "error") {
    throw new Error("No se pudo consultar la sesión.");
  }

  const usuario = sesion.usuario;
  let contenido: ReactNode;

  if (usuario.rol !== "ARRENDATARIO") {
    contenido = (
      <EstadoDePagina
        tipo="sin-permiso"
        titulo="No tienes acceso a este depósito."
        mensaje="El depósito pertenece a otra reserva."
      />
    );
  } else if (!ID_RESERVA.test(reservaId)) {
    contenido = (
      <EstadoDePagina
        tipo="no-encontrado"
        titulo="Reserva no encontrada."
      />
    );
  } else {
    const respuesta = await llamarApi(`reservas/${reservaId}/deposito`);

    if (respuesta.status === 401) {
      redirect("/sesion-vencida");
    }

    if (respuesta.status === 403) {
      contenido = (
        <EstadoDePagina
          tipo="sin-permiso"
          titulo="No tienes acceso a este depósito."
          mensaje="El depósito pertenece a otra reserva."
        />
      );
    } else if (respuesta.status === 404) {
      contenido = (
        <EstadoDePagina
          tipo="vacio"
          titulo="No hay depósito de garantía."
          mensaje="Esta reserva no tiene un depósito registrado."
        />
      );
    } else if (respuesta.status !== 200) {
      contenido = (
        <EstadoDePagina
          tipo="error"
          titulo="No pudimos cargar el depósito."
          mensaje="Revisa tu conexión e intenta de nuevo."
        />
      );
    } else {
      contenido = (
        <VistaDeposito
          reservaId={reservaId}
          deposito={leerDeposito(respuesta.datos)}
        />
      );
    }
  }

  return (
    <>
      <NavegacionSuperior
        rol={
          usuario.rol === "ARRENDATARIO"
            ? "arrendatario"
            : "arrendador"
        }
        nombreUsuario={usuario.nombreUsuario}
        onCerrarSesion={cerrarSesion}
      />

      <main className="flex-1">
        <Contenedor className="py-espacio-7 md:py-espacio-9">
          {contenido}
        </Contenedor>
      </main>

      <PieDePagina />
    </>
  );
}