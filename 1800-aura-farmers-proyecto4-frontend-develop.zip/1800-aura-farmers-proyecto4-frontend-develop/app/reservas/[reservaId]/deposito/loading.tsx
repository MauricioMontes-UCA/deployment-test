import { Contenedor, EstadoDePagina } from "@/components/ui";

export default function CargandoDeposito() {
  return (
    <main className="flex-1">
      <Contenedor className="py-espacio-9">
        <EstadoDePagina
          tipo="cargando"
          titulo="Cargando depósito de garantía…"
        />
      </Contenedor>
    </main>
  );
}
