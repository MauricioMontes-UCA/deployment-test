"use client";

import { Contenedor, EstadoDePagina } from "@/components/ui";

export default function ErrorDeposito({
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <main className="flex-1">
      <Contenedor className="py-espacio-9">
        <EstadoDePagina
          tipo="error"
          titulo="No pudimos cargar el depósito."
          accion={
            <button type="button" onClick={reset} className="underline">
              Reintentar
            </button>
          }
        />
      </Contenedor>
    </main>
  );
}
