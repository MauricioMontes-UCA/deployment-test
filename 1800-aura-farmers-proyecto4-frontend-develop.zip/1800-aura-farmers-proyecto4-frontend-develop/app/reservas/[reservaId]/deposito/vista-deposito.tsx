import Link from "next/link";
import { Alerta, EstadoDePagina } from "@/components/ui";
import {
  type Deposito,
  dinero,
  esPendiente,
  estadoDeposito,
  fecha,
} from "@/lib/deposito-consulta";

type Props = {
  deposito: Deposito | null;
  reservaId: string;
  referencia?: string;
};

export function VistaDeposito({ deposito, reservaId, referencia }: Props) {
  if (!deposito) {
    return (
      <EstadoDePagina
        tipo="vacio"
        titulo="No hay depósito de garantía."
        mensaje="Esta reserva no tiene un depósito registrado."
      />
    );
  }

  const pendiente = esPendiente(deposito.estado);
  return (
    <section
      className="w-full max-w-[610px]"
      aria-label="Detalle del depósito de garantía"
    >
      <p className="mb-espacio-2 texto-etiqueta text-texto-terciario uppercase tracking-widest">
        {referencia ?? `RESERVA ${reservaId}`}
      </p>
      <h1 className="mb-espacio-6 font-serif text-3xl text-texto-primario">
        Mi depósito de garantía
      </h1>
      <div className="border border-borde-fuerte bg-fondo-superficie p-espacio-5 md:p-espacio-6">
        <div className="flex items-center justify-between gap-espacio-3 border-b border-borde-sutil pb-espacio-3">
          <span className="texto-cuerpo-medio text-texto-primario">Estado</span>
          <span
            className={`px-espacio-2 py-1 texto-etiqueta ${pendiente ? "bg-fondo-advertencia text-estado-advertencia" : "bg-fondo-exito text-estado-exito"}`}
          >
            {estadoDeposito(deposito.estado)}
          </span>
        </div>
        <dl className="texto-cuerpo-pequeno text-texto-primario">
          <Fila
            titulo="Importe original"
            valor={dinero(deposito.importeOriginal)}
          />
          <Fila
            titulo="Importe retenido"
            valor={dinero(deposito.importeRetenido)}
          />
          <Fila
            titulo="Importe liberado"
            valor={dinero(deposito.importeLiberado)}
          />
          {deposito.fechaResolucion && (
            <Fila
              titulo="Fecha de resolución"
              valor={fecha(deposito.fechaResolucion)}
            />
          )}
          {deposito.justificacion && (
            <div className="border-t border-borde-sutil py-espacio-3">
              <dt className="mb-espacio-1 texto-cuerpo-medio">
                Justificación de la retención
              </dt>
              <dd className="whitespace-pre-wrap">{deposito.justificacion}</dd>
            </div>
          )}
        </dl>
        {pendiente && (
          <div className="mt-espacio-3">
            <Alerta
              tono="advertencia"
              titulo="El depósito aún está pendiente de resolución"
            >
              El arrendador aún no ha resuelto el depósito.
            </Alerta>
          </div>
        )}
        {deposito.resolucionAutomatica && (
          <div className="mt-espacio-3">
            <Alerta tono="info">
              Liberado automáticamente por vencimiento del plazo
            </Alerta>
          </div>
        )}
      </div>
      <Link
        href="/reservas"
        className="mt-espacio-6 inline-block texto-cuerpo-medio text-texto-primario hover:underline"
      >
        Volver a mis reservas
      </Link>
    </section>
  );
}

function Fila({ titulo, valor }: { titulo: string; valor: string }) {
  return (
    <div className="flex items-center justify-between gap-espacio-3 border-b border-borde-sutil py-espacio-3">
      <dt className="text-texto-secundario">{titulo}</dt>
      <dd className="font-medium">{valor}</dd>
    </div>
  );
}
