import type { Metadata } from "next";
import type { ReactNode } from "react";
import { redirect } from "next/navigation";
import { cerrarSesion } from "@/app/actions/auth";
import {
  Contenedor,
  EstadoDePagina,
  NavegacionSuperior,
  PieDePagina,
} from "@/components/ui";
import { obtenerUsuarioActual } from "@/lib/usuario-actual";
import { llamarApi } from "@/lib/api";
import { ID_RESERVA, objeto } from "@/lib/depositos";
import { FormularioResolucionDeposito } from "./formulario-resolucion";
export const metadata: Metadata = {
  title: "Resolver depósito de garantía · Arre",
};
export default async function Pagina({
  params,
}: {
  params: Promise<{ reservaId: string }>;
}) {
  const { reservaId } = await params;
  const sesion = await obtenerUsuarioActual();
  if (sesion.estado === "sin-sesion") redirect("/sesion-vencida");
  if (sesion.estado === "error")
    throw new Error("No se pudo verificar la sesión.");
  const usuario = sesion.usuario;
  const marco = (contenido: ReactNode) => (
    <>
      <NavegacionSuperior
        rol={usuario.rol === "ARRENDADOR" ? "arrendador" : "arrendatario"}
        nombreUsuario={usuario.nombreUsuario}
        onCerrarSesion={cerrarSesion}
      />
      <main className="flex-1 bg-fondo-base">
        <Contenedor className="py-espacio-7">{contenido}</Contenedor>
      </main>
      <PieDePagina />
    </>
  );
  if (usuario.rol !== "ARRENDADOR")
    return marco(
      <EstadoDePagina
        tipo="sin-permiso"
        titulo="No tienes permiso para resolver este depósito."
      />,
    );
  if (!ID_RESERVA.test(reservaId))
    return marco(
      <EstadoDePagina tipo="no-encontrado" titulo="La reserva no es válida." />,
    );
  const r = await llamarApi(`reservas/${reservaId}`);
  if (r.status === 401) redirect("/sesion-vencida");
  if (r.status === 403)
    return marco(
      <EstadoDePagina
        tipo="sin-permiso"
        titulo="No tienes acceso a esta reserva."
      />,
    );
  if (r.status === 404)
    return marco(
      <EstadoDePagina tipo="no-encontrado" titulo="Reserva no encontrada." />,
    );
  if (r.status !== 200)
    return marco(
      <EstadoDePagina tipo="error" titulo="No se pudo consultar la reserva." />,
    );
  const reserva = objeto(r.datos);
  if (objeto(reserva.arrendador).id !== usuario.id)
    return marco(
      <EstadoDePagina
        tipo="sin-permiso"
        titulo="Solo el propietario puede resolver el depósito."
      />,
    );
  return marco(
    <FormularioResolucionDeposito reservaId={reservaId} reserva={reserva} />,
  );
}
