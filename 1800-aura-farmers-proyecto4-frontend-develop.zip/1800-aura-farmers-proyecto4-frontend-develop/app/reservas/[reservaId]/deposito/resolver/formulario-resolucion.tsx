"use client";
/* eslint-disable @next/next/no-img-element */
import {
  useCallback,
  useEffect,
  useRef,
  useState,
  type FormEvent,
} from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  Alerta,
  AreaDeTexto,
  Boton,
  CampoDeTexto,
  DialogoDeConfirmacion,
  EncabezadoDePagina,
  EstadoDePagina,
  OpcionEnTarjeta,
  clasesBoton,
} from "@/components/ui";
import {
  dinero,
  mensajeError,
  numero,
  objeto,
  validarRetencion,
  type AccionDeposito,
} from "@/lib/depositos";

export function FormularioResolucionDeposito({
  reservaId,
  reserva,
}: {
  reservaId: string;
  reserva: Record<string, unknown>;
}) {
  const router = useRouter();
  const [deposito, setDeposito] = useState<Record<string, unknown> | null>(
    null,
  );
  const [estado, setEstado] = useState<
    "cargando" | "listo" | "error" | "sin-permiso" | "no-encontrado"
  >("cargando");
  const [accion, setAccion] = useState<AccionDeposito>("LIBERAR");
  const [importe, setImporte] = useState("");
  const [justificacion, setJustificacion] = useState("");
  const [errores, setErrores] = useState(false);
  const [mensaje, setMensaje] = useState<string | null>(null);
  const [confirmando, setConfirmando] = useState(false);
  const [procesando, setProcesando] = useState(false);
  const enviando = useRef(false);
  const cargar = useCallback(
    async (signal?: AbortSignal) => {
      try {
        const r = await fetch(`/api/reservas/${reservaId}/deposito`, {
          signal,
          cache: "no-store",
        });
        if (r.status === 401) {
          router.replace("/sesion-vencida");
          return;
        }
        if (r.status === 403) {
          setEstado("sin-permiso");
          return;
        }
        if (r.status === 404) {
          setEstado("no-encontrado");
          return;
        }
        const datos: unknown = await r.json().catch(() => null);
        if (!r.ok) {
          setMensaje(mensajeError(datos, "No pudimos consultar el depósito."));
          setEstado("error");
          return;
        }
        setDeposito(objeto(datos));
        setEstado("listo");
      } catch (e) {
        if ((e as Error).name !== "AbortError") {
          setMensaje("No pudimos conectar con el servidor.");
          setEstado("error");
        }
      }
    },
    [reservaId, router],
  );

  useEffect(() => {
    const c = new AbortController();
    void Promise.resolve().then(() => {
      if (!c.signal.aborted) return cargar(c.signal);
    });
    return () => c.abort();
  }, [cargar]);

  const bien = objeto(reserva.bien);
  const saldo = numero(deposito?.importeDisponible) ?? 0;
  const original =
    numero(
      deposito?.importeOriginal ??
        deposito?.montoOriginal ??
        deposito?.monto ??
        bien.deposito,
    ) ?? saldo;
  const resuelto =
    Boolean(deposito?.fechaResolucion) ||
    ["LIBERADO", "RETENIDO", "PARCIALMENTE_RETENIDO", "RESUELTO"].includes(
      String(deposito?.estado ?? ""),
    );
  const automatico = deposito?.resolucionAutomatica === true;
  const vencido = false;
  const errorRetencion =
    accion === "RETENER"
      ? validarRetencion(importe, justificacion, saldo)
      : null;
  const errorImporte =
    accion === "RETENER" &&
    Boolean(validarRetencion(importe, "Motivo válido", saldo));
  const errorJustificacion =
    accion === "RETENER" &&
    (!justificacion.trim() || justificacion.trim().length > 500);
  const bloquear =
    procesando ||
    resuelto ||
    vencido ||
    estado !== "listo" ||
    reserva.estado !== "FINALIZADA";
  const confirmar = (e: FormEvent) => {
    e.preventDefault();
    setErrores(true);
    setMensaje(null);
    if (bloquear || errorRetencion) return;
    setConfirmando(true);
  };
  const enviar = async () => {
    if (enviando.current || bloquear || errorRetencion) return;
    enviando.current = true;
    setProcesando(true);
    setMensaje(null);

    try {
      const body =
        accion === "LIBERAR"
          ? { accion }
          : {
              accion,
              importeRetenido: Number(importe),
              justificacion: justificacion.trim(),
            };
      const r = await fetch(`/api/reservas/${reservaId}/deposito/resolver`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });

      if (r.status === 401) {
        router.replace("/sesion-vencida");
        return;
      }
      const datos: unknown = await r.json().catch(() => null);

      if (!r.ok) {
        setMensaje(mensajeError(datos, "No se pudo resolver el depósito."));
        setConfirmando(false);
        if (r.status === 403) setEstado("sin-permiso");
        return;
      }

      const resultado = objeto(datos);

      setDeposito({
        ...objeto(deposito),
        ...resultado,
        estado:
          resultado.estado ?? (accion === "LIBERAR" ? "LIBERADO" : "RETENIDO"),
        fechaResolucion: resultado.fechaResolucion ?? new Date().toISOString(),
      });
      setConfirmando(false);
    } catch {
      setMensaje("No se pudo contactar al servidor.");
      setConfirmando(false);
    } finally {
      enviando.current = false;
      setProcesando(false);
    }
  };

  if (estado === "cargando")
    return <EstadoDePagina tipo="cargando" titulo="Cargando depósito…" />;
  if (estado === "sin-permiso")
    return (
      <EstadoDePagina
        tipo="sin-permiso"
        titulo="No tienes permiso para resolver este depósito."
      />
    );
  if (estado === "no-encontrado")
    return (
      <EstadoDePagina tipo="no-encontrado" titulo="Depósito no encontrado." />
    );
  if (estado === "error")
    return (
      <EstadoDePagina
        tipo="error"
        titulo="No pudimos consultar el depósito."
        mensaje={mensaje ?? undefined}
        accion={
          <Boton
            jerarquia="secundario"
            onClick={() => {
              setEstado("cargando");
              void cargar();
            }}
          >
            Reintentar
          </Boton>
        }
      />
    );

  const titulo =
    typeof bien.titulo === "string" ? bien.titulo : "Bien alquilado";
  const fecha = (valor: unknown) =>
    typeof valor === "string"
      ? new Date(valor).toLocaleDateString("es-SV")
      : "—";

  return (
    <div className="flex flex-col gap-espacio-6">
      <EncabezadoDePagina
        sobretitulo={`RESERVA RSV-${reservaId.slice(0, 8).toUpperCase()}`}
        titulo="Resolver el depósito de garantía"
        descripcion="Libera el depósito completo o retén una parte o su totalidad con una justificación."
      />
      {String(reserva.estado ?? "") !== "FINALIZADA" && !resuelto && (
        <Alerta tono="advertencia">
          La reserva debe estar FINALIZADA para resolver el depósito.
        </Alerta>
      )}
      <div className="grid grid-cols-1 items-start gap-espacio-6 lg:grid-cols-[minmax(0,1fr)_380px]">
        <section className="order-2 flex flex-col gap-espacio-5 lg:order-1">
          {resuelto ? (
            <>
              <Alerta tono="exito" titulo="Depósito resuelto">
                {automatico
                  ? "Liberado automáticamente por vencimiento del plazo"
                  : "El arrendatario recibió un aviso."}
              </Alerta>
              <div className="border border-borde-default bg-fondo-superficie p-espacio-5">
                <h2 className="texto-h3 mb-espacio-4">
                  Resultado de la resolución
                </h2>
                {[
                  ["Estado", deposito?.estado],
                  ["Importe retenido", dinero(deposito?.importeRetenido)],
                  ["Importe liberado", dinero(deposito?.importeLiberado)],
                  ["Justificación", deposito?.justificacion],
                  ["Fecha de resolución", fecha(deposito?.fechaResolucion)],
                ].map(([k, v]) => (
                  <div
                    key={String(k)}
                    className="flex justify-between gap-espacio-3 border-b border-borde-sutil py-espacio-2 texto-cuerpo-pequeno"
                  >
                    <span>{String(k)}</span>
                    <span>{v == null ? "—" : String(v)}</span>
                  </div>
                ))}
              </div>
              <Boton disabled className="w-full">
                Confirmar resolución
              </Boton>
            </>
          ) : vencido ? (
            <Alerta tono="info" titulo="Plazo vencido">
              El plazo para resolver el depósito venció y fue liberado
              automáticamente.
            </Alerta>
          ) : (
            <form
              onSubmit={confirmar}
              noValidate
              className="flex flex-col gap-espacio-4"
            >
              <h2 className="texto-cuerpo-medio">
                ¿Qué quieres hacer con el depósito?
              </h2>
              <OpcionEnTarjeta
                name="accion"
                value="LIBERAR"
                checked={accion === "LIBERAR"}
                onChange={() => {
                  setAccion("LIBERAR");
                  setErrores(false);
                }}
                titulo="Liberar el depósito completo"
                descripcion={`Se devolverán ${dinero(saldo)} al arrendatario.`}
              />
              <OpcionEnTarjeta
                name="accion"
                value="RETENER"
                checked={accion === "RETENER"}
                onChange={() => setAccion("RETENER")}
                titulo="Retener una parte o el total"
                descripcion="Indica el importe y explica el motivo."
              />
              {accion === "RETENER" && (
                <>
                  <CampoDeTexto
                    etiqueta="Importe a retener (USD)"
                    value={importe}
                    onChange={(e) => setImporte(e.target.value)}
                    placeholder="15.00"
                    inputMode="decimal"
                    error={
                      errores && errorImporte
                        ? `La retención debe ser mayor que $0.00 y hasta ${dinero(saldo)}, con 2 decimales.`
                        : undefined
                    }
                  />
                  <AreaDeTexto
                    etiqueta="Justificación"
                    value={justificacion}
                    onChange={(e) => setJustificacion(e.target.value)}
                    limite={500}
                    placeholder="Explica el motivo de la retención."
                    error={
                      errores && errorJustificacion
                        ? "La justificación es obligatoria y debe tener hasta 500 caracteres."
                        : undefined
                    }
                  />
                </>
              )}
              {mensaje && <Alerta tono="error">{mensaje}</Alerta>}
              <Boton type="submit" className="w-full" disabled={bloquear}>
                Confirmar resolución
              </Boton>
            </form>
          )}
        </section>
        <aside className="order-1 flex flex-col gap-espacio-4 border border-borde-default bg-fondo-superficie p-espacio-5 lg:order-2">
          <div className="flex items-center gap-espacio-3">
            {typeof bien.fotoPrincipalUrl === "string" &&
            bien.fotoPrincipalUrl ? (
              <img
                src={bien.fotoPrincipalUrl}
                alt={titulo}
                className="size-14 shrink-0 object-cover"
              />
            ) : (
              <div
                className="flex size-14 shrink-0 items-center justify-center bg-fondo-sutil"
                aria-label="Sin fotografía"
              >
                —
              </div>
            )}
            <div>
              <h2 className="texto-cuerpo-medio">{titulo}</h2>
              <p className="texto-cuerpo-pequeno text-texto-secundario">
                RSV-{reservaId.slice(0, 8).toUpperCase()} · Arrendatario:{" "}
                {String(objeto(reserva.arrendatario).nombreUsuario ?? "—")}
              </p>
            </div>
          </div>
          {[
            ["Estado de reserva", reserva.estado ?? "—"],
            ["Importe original", dinero(original)],
            ["Saldo disponible", dinero(saldo)],
          ].map(([k, v]) => (
            <div
              key={String(k)}
              className="flex justify-between gap-espacio-3 border-b border-borde-sutil py-espacio-2 texto-cuerpo-pequeno"
            >
              <span>{String(k)}</span>
              <span>{String(v)}</span>
            </div>
          ))}
        </aside>
      </div>
      <DialogoDeConfirmacion
        abierto={confirmando}
        titulo={
          accion === "RETENER"
            ? `¿Retener ${dinero(importe)} del depósito?`
            : "¿Liberar el depósito completo?"
        }
        mensaje={
          accion === "RETENER"
            ? `Se liberarán ${dinero(saldo - Number(importe))} al arrendatario. Esta decisión no se puede cambiar.`
            : `Se devolverán ${dinero(saldo)} al arrendatario. Esta decisión no se puede cambiar.`
        }
        textoConfirmar={accion === "RETENER" ? "Retener" : "Liberar"}
        peligro={accion === "RETENER"}
        cargando={procesando}
        onCancelar={() => setConfirmando(false)}
        onConfirmar={() => void enviar()}
      />
      <Link
        href={`/reservas/${reservaId}`}
        className={clasesBoton({ jerarquia: "secundario" })}
      >
        Volver al detalle de la reserva
      </Link>
    </div>
  );
}
