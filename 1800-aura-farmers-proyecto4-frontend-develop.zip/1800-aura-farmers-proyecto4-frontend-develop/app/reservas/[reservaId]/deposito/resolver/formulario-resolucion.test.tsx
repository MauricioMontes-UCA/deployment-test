import { beforeEach, describe, expect, it, vi } from "vitest";
import { fireEvent, render, screen, waitFor } from "@testing-library/react";

const mocks = vi.hoisted(() => ({ replace: vi.fn() }));
const router = { replace: mocks.replace };
vi.mock("next/navigation", () => ({ useRouter: () => router }));
vi.mock("@/components/ui", async (importOriginal) => {
  const original = await importOriginal<typeof import("@/components/ui")>();
  return {
    ...original,
    DialogoDeConfirmacion: ({
      abierto,
      onConfirmar,
      onCancelar,
    }: {
      abierto: boolean;
      onConfirmar: () => void;
      onCancelar: () => void;
    }) =>
      abierto ? (
        <div role="dialog">
          <button onClick={onConfirmar}>Aceptar resolución</button>
          <button onClick={onCancelar}>Cancelar</button>
        </div>
      ) : null,
  };
});
import { FormularioResolucionDeposito } from "./formulario-resolucion";

const id = "11111111-1111-4111-8111-111111111111";
const reserva = {
  estado: "FINALIZADA",
  bien: { titulo: "Cámara" },
  arrendatario: { nombreUsuario: "Ana" },
};
const deposito = {
  estado: "PENDIENTE",
  importeOriginal: 40,
  importeDisponible: 40,
};
const respuesta = (status: number, datos: unknown) => ({
  status,
  ok: status >= 200 && status < 300,
  json: async () => datos,
});
const fetchMock = vi.fn();

beforeEach(() => {
  fetchMock.mockReset();
  mocks.replace.mockReset();
  fetchMock.mockResolvedValue(respuesta(200, deposito));
  vi.stubGlobal("fetch", fetchMock);
});

async function montar() {
  render(<FormularioResolucionDeposito reservaId={id} reserva={reserva} />);
  await screen.findByText("Cámara");
}

async function confirmar() {
  fireEvent.click(screen.getByRole("button", { name: "Confirmar resolución" }));
  expect(await screen.findByRole("dialog")).toBeInTheDocument();
}

describe("FE-11.1 formulario de resolución", () => {
  it("LIBERAR no exige campos y pide confirmación previa", async () => {
    await montar();
    await confirmar();
    expect(fetchMock).toHaveBeenCalledTimes(1);
  });
  it("RETENER exige importe y justificación", async () => {
    await montar();
    fireEvent.click(screen.getByText("Retener una parte o el total"));
    fireEvent.click(
      screen.getByRole("button", { name: "Confirmar resolución" }),
    );
    expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
    fireEvent.change(screen.getByLabelText(/Importe a retener/), {
      target: { value: "15.00" },
    });
    fireEvent.change(screen.getByLabelText(/Justificación/), {
      target: { value: "Daño reportado" },
    });
    await confirmar();
  });
  it("envía una sola vez y muestra importes del backend tras resolver", async () => {
    await montar();
    await confirmar();
    let terminar!: (value: unknown) => void;
    fetchMock.mockImplementationOnce(
      () =>
        new Promise((resolve) => {
          terminar = resolve;
        }),
    );
    fireEvent.click(screen.getByRole("button", { name: "Aceptar resolución" }));
    fireEvent.click(screen.getByRole("button", { name: "Aceptar resolución" }));
    expect(fetchMock).toHaveBeenCalledTimes(2);
    terminar(
      respuesta(200, {
        estado: "LIBERADO",
        importeRetenido: 0,
        importeLiberado: 40,
      }),
    );
    expect(
      await screen.findByText("Resultado de la resolución"),
    ).toBeInTheDocument();
    expect(
      screen.getByRole("button", { name: "Confirmar resolución" }),
    ).toBeDisabled();
  });
  it("401 redirige a sesión vencida", async () => {
    await montar();
    await confirmar();
    fetchMock.mockResolvedValueOnce(respuesta(401, {}));
    fireEvent.click(screen.getByRole("button", { name: "Aceptar resolución" }));
    await waitFor(() =>
      expect(mocks.replace).toHaveBeenCalledWith("/sesion-vencida"),
    );
  });
  it("403 muestra sin permiso", async () => {
    await montar();
    await confirmar();
    fetchMock.mockResolvedValueOnce(respuesta(403, {}));
    fireEvent.click(screen.getByRole("button", { name: "Aceptar resolución" }));
    expect(
      await screen.findByText("No tienes permiso para resolver este depósito."),
    ).toBeInTheDocument();
  });
  it.each([409, 422])("%i muestra el mensaje del backend", async (status) => {
    await montar();
    await confirmar();
    fetchMock.mockResolvedValueOnce(
      respuesta(status, { message: `Error ${status}` }),
    );
    fireEvent.click(screen.getByRole("button", { name: "Aceptar resolución" }));
    expect(await screen.findByText(`Error ${status}`)).toBeInTheDocument();
  });
  it("muestra liberación automática sin afirmar aviso al arrendatario", async () => {
    fetchMock.mockResolvedValueOnce(
      respuesta(200, {
        ...deposito,
        estado: "LIBERADO",
        resolucionAutomatica: true,
      }),
    );
    await montar();
    expect(
      screen.getByText("Liberado automáticamente por vencimiento del plazo"),
    ).toBeInTheDocument();
  });
});
