import { beforeEach, describe, expect, it, vi } from "vitest";
import { render, screen } from "@testing-library/react";

const mocks = vi.hoisted(() => ({
  obtenerUsuarioActual: vi.fn(),
  llamarApi: vi.fn(),
  redirect: vi.fn(),
}));
vi.mock("@/lib/usuario-actual", () => ({
  obtenerUsuarioActual: mocks.obtenerUsuarioActual,
}));
vi.mock("@/lib/api", () => ({ llamarApi: mocks.llamarApi }));
vi.mock("next/navigation", () => ({ redirect: mocks.redirect }));
vi.mock("@/app/actions/auth", () => ({ cerrarSesion: vi.fn() }));
vi.mock("@/components/ui", async (importOriginal) => {
  const original = await importOriginal<typeof import("@/components/ui")>();
  return {
    ...original,
    NavegacionSuperior: () => null,
    PieDePagina: () => null,
  };
});
vi.mock("./formulario-resolucion", () => ({
  FormularioResolucionDeposito: () => <div>Formulario autorizado</div>,
}));
import Pagina from "./page";

const id = "11111111-1111-4111-8111-111111111111";
const params = { params: Promise.resolve({ reservaId: id }) };
beforeEach(() => {
  vi.clearAllMocks();
  mocks.obtenerUsuarioActual.mockResolvedValue({
    estado: "autenticado",
    usuario: { id, rol: "ARRENDADOR", nombreUsuario: "Arrendador" },
  });
  mocks.llamarApi.mockResolvedValue({
    status: 200,
    datos: { arrendador: { id } },
  });
});

describe("FE-11.1 página y propietario", () => {
  it("bloquea ARRENDATARIO sin consultar API", async () => {
    mocks.obtenerUsuarioActual.mockResolvedValue({
      estado: "autenticado",
      usuario: { id, rol: "ARRENDATARIO", nombreUsuario: "Ana" },
    });
    render(await Pagina(params));
    expect(
      screen.getByText("No tienes permiso para resolver este depósito."),
    ).toBeInTheDocument();
    expect(mocks.llamarApi).not.toHaveBeenCalled();
  });
  it("permite al arrendador.id propietario", async () => {
    render(await Pagina(params));
    expect(screen.getByText("Formulario autorizado")).toBeInTheDocument();
  });
  it("bloquea al arrendador ajeno", async () => {
    mocks.llamarApi.mockResolvedValue({
      status: 200,
      datos: { arrendador: { id: "otro" } },
    });
    render(await Pagina(params));
    expect(
      screen.getByText("Solo el propietario puede resolver el depósito."),
    ).toBeInTheDocument();
  });
});
