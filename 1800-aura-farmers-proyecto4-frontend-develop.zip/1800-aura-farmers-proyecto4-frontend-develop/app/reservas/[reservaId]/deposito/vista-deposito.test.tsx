import { describe, expect, it } from "vitest";
import { render, screen } from "@testing-library/react";
import { VistaDeposito } from "./vista-deposito";
import type { Deposito } from "@/lib/deposito-consulta";

const base: Deposito = {
  estado: "PENDIENTE",
  importeOriginal: 40,
  importeRetenido: 0,
  importeLiberado: 0,
  resolucionAutomatica: false,
};

describe("FE-12.1 vista de solo lectura", () => {
  it("presenta pendiente sin inventar fecha límite", () => {
    render(<VistaDeposito deposito={base} reservaId="r1" />);
    expect(
      screen.getByText("El depósito aún está pendiente de resolución"),
    ).toBeInTheDocument();
    expect(screen.queryByText(/tiene hasta/i)).not.toBeInTheDocument();
    expect(
      screen.getByRole("link", { name: "Volver a mis reservas" }),
    ).toHaveAttribute("href", "/reservas");
  });
  it("presenta resuelto, importes y justificación", () => {
    render(
      <VistaDeposito
        reservaId="r1"
        deposito={{
          ...base,
          estado: "PARCIALMENTE_RETENIDO",
          importeRetenido: 15,
          importeLiberado: 25,
          justificacion: "Daños",
          fechaResolucion: "2026-11-01T12:00:00Z",
        }}
      />,
    );
    expect(screen.getByText("Parcialmente retenido")).toBeInTheDocument();
    expect(screen.getByText("Daños")).toBeInTheDocument();
    expect(screen.getByText("$15.00")).toBeInTheDocument();
    expect(screen.getByText("$25.00")).toBeInTheDocument();
    expect(screen.getByText("Fecha de resolución")).toBeInTheDocument();
  });
  it("informa liberación automática", () => {
    render(
      <VistaDeposito
        reservaId="r1"
        deposito={{
          ...base,
          estado: "LIBERADO",
          importeLiberado: 40,
          resolucionAutomatica: true,
        }}
      />,
    );
    expect(
      screen.getByText("Liberado automáticamente por vencimiento del plazo"),
    ).toBeInTheDocument();
  });
  it("presenta vacío cuando no hay depósito", () => {
    render(<VistaDeposito reservaId="r1" deposito={null} />);
    expect(
      screen.getByText("No hay depósito de garantía."),
    ).toBeInTheDocument();
  });
});
