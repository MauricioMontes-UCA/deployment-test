import { render, screen } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { usuarioDePrueba } from "@/pruebas/usuario";
import PaginaMisReservas from "./page";

const { obtenerUsuarioActual, redirect } = vi.hoisted(() => ({
  obtenerUsuarioActual: vi.fn(),
  redirect: vi.fn(),
}));
vi.mock("@/lib/usuario-actual", () => ({ obtenerUsuarioActual }));
vi.mock("@/app/actions/auth", () => ({ cerrarSesion: vi.fn() }));
vi.mock("next/navigation", () => ({ usePathname: () => "/reservas", redirect }));
vi.stubGlobal("fetch", vi.fn(() => new Promise(() => {})));

beforeEach(() => {
  obtenerUsuarioActual.mockReset();
  redirect.mockReset();
});

describe("/reservas", () => {
  it("al arrendador le muestra «sin permiso» con su barra y un enlace al inicio", async () => {
    obtenerUsuarioActual.mockResolvedValue({
      estado: "ok",
      usuario: usuarioDePrueba({ rol: "ARRENDADOR", nombreUsuario: "carlos" }),
    });
    render(await PaginaMisReservas());

    expect(screen.getByRole("link", { name: "Ir al inicio" })).toHaveAttribute("href", "/");
    expect(screen.getByRole("link", { name: "Reservas recibidas" })).toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "Reintentar" })).not.toBeInTheDocument();
    expect(fetch).not.toHaveBeenCalled();
  });

  it("al arrendatario le monta el listado", async () => {
    obtenerUsuarioActual.mockResolvedValue({ estado: "ok", usuario: usuarioDePrueba() });
    render(await PaginaMisReservas());

    // Barra y pie de página llevan a /reservas, no a /mis-reservas (404).
    const enlaces = screen.getAllByRole("link", { name: "Mis reservas" });
    expect(enlaces.length).toBeGreaterThan(1);
    enlaces.forEach((enlace) => expect(enlace).toHaveAttribute("href", "/reservas"));
    expect(fetch).toHaveBeenCalled();
  });

  it("sin sesión pasa por /sesion-vencida", async () => {
    obtenerUsuarioActual.mockResolvedValue({ estado: "sin-sesion" });
    redirect.mockImplementation(() => {
      throw new Error("NEXT_REDIRECT");
    });
    await expect(PaginaMisReservas()).rejects.toThrow("NEXT_REDIRECT");
    expect(redirect).toHaveBeenCalledWith("/sesion-vencida");
  });
});
