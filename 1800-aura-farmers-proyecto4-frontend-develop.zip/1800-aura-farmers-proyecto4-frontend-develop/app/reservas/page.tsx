import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { cerrarSesion } from "@/app/actions/auth";
import {
  Contenedor,
  EstadoDePagina,
  NavegacionSuperior,
  PieDePagina,
  clasesBoton,
} from "@/components/ui";
import { obtenerUsuarioActual } from "@/lib/usuario-actual";
import { MisReservas } from "./mis-reservas";

export const metadata: Metadata = { title: "Mis reservas · Arre" };

export default async function PaginaMisReservas() {
  const resultado = await obtenerUsuarioActual();
  // Pasa por /sesion-vencida para borrar la cookie; con ella, el proxy no deja entrar a /login.
  if (resultado.estado === "sin-sesion") redirect("/sesion-vencida");

  // GET /reservas/mias es solo para ARRENDATARIO (403 para el arrendador):
  // se le muestra «sin permiso» en vez de un error que no se resuelve al reintentar.
  if (resultado.estado === "ok" && resultado.usuario.rol === "ARRENDADOR") {
    return (
      <>
        <NavegacionSuperior
          rol="arrendador"
          nombreUsuario={resultado.usuario.nombreUsuario}
          onCerrarSesion={cerrarSesion}
        />
        <main className="flex-1 bg-fondo-base">
          <Contenedor className="flex flex-col gap-espacio-5 pt-espacio-6 pb-espacio-8 md:pt-espacio-7 md:pb-espacio-9">
            <EstadoDePagina
              tipo="sin-permiso"
              accion={
                <Link href="/" className={clasesBoton({ jerarquia: "secundario" })}>
                  Ir al inicio
                </Link>
              }
            />
          </Contenedor>
        </main>
        <PieDePagina />
      </>
    );
  }

  // Si /auth/me falla por otra causa, la pantalla igual carga: el listado
  // maneja su propio error y la barra usa el nombre por defecto.
  const nombre = resultado.estado === "ok" ? resultado.usuario.nombreUsuario : undefined;
  return <MisReservas nombreUsuario={nombre} />;
}
