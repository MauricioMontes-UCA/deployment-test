import { afterEach, describe, expect, it, vi } from "vitest";
import { render, screen } from "@testing-library/react";
import { MisReservas } from "./mis-reservas";

vi.mock("@/app/actions/auth", () => ({ cerrarSesion: vi.fn() }));
vi.mock("next/navigation", () => ({ usePathname: () => "/reservas" }));
afterEach(() => vi.unstubAllGlobals());

describe("FE-12.1 acceso desde reservas", () => {
  it("ofrece consultar el depósito de una reserva finalizada", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue(
        new Response(
          JSON.stringify([
            {
              id: "11111111-1111-4111-8111-111111111111",
              bienId: "b1",
              arrendatarioId: "u1",
              fechaInicio: "2026-11-01",
              fechaFin: "2026-11-02",
              estado: "FINALIZADA",
              motivoResolucion: null,
              creadaEn: "2026-10-01T00:00:00Z",
              procesadaEn: null,
              titulo: "Cámara",
              foto: null,
              arrendador: "Ana",
            },
          ]),
          { status: 200 },
        ),
      ),
    );
    render(<MisReservas />);
    expect(
      await screen.findByRole("link", { name: "Ver depósito" }),
    ).toHaveAttribute(
      "href",
      "/reservas/11111111-1111-4111-8111-111111111111/deposito",
    );
  });
});
