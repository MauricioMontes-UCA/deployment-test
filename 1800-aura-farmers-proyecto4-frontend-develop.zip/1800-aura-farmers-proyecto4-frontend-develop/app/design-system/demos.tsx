"use client";

import { useState } from "react";
import {
  Boton,
  CampanaDeNotificaciones,
  Calificacion,
  CargadorDeArchivos,
  ChipDeFiltro,
  Contenedor,
  Conversacion,
  DialogoDeConfirmacion,
  MesDeCalendario,
  MiniaturaDeFoto,
  NavegacionSuperior,
  PanelDePestana,
  Pestana,
  Pestanas,
  Selector,
  SelectorDePeriodo,
  type EstadoDia,
  type PeriodoReporte,
  type RolNavegacion,
} from "@/components/ui";

/*
 * Ejemplos interactivos del catálogo. Viven aquí y no en los componentes
 * porque el estado de demostración no es parte del Design System.
 */

export function DemoNavegacion() {
  const [rol, setRol] = useState<RolNavegacion>("arrendador");
  return (
    <div className="flex flex-col gap-espacio-3">
      <NavegacionSuperior
        rol={rol}
        nombreUsuario={rol === "arrendador" ? "mariana_rivas" : "ana_m"}
        noLeidas={3}
        onCerrarSesion={() => undefined}
      />
      <Contenedor className="flex flex-wrap gap-espacio-2">
        {(["visitante", "arrendatario", "arrendador"] as const).map((opcion) => (
          <Boton
            key={opcion}
            jerarquia={rol === opcion ? "primario" : "secundario"}
            onClick={() => setRol(opcion)}
          >
            {opcion}
          </Boton>
        ))}
      </Contenedor>
    </div>
  );
}

const OPCIONES = [
  { valor: "espacio", etiqueta: "Espacio" },
  { valor: "equipo", etiqueta: "Equipo" },
  { valor: "vehiculo", etiqueta: "Vehículo" },
];

const DEPARTAMENTOS = [
  "Ahuachapán", "Cabañas", "Chalatenango", "Cuscatlán", "La Libertad", "La Paz", "La Unión",
  "Morazán", "San Miguel", "San Salvador", "San Vicente", "Santa Ana", "Sonsonate", "Usulután",
].map((nombre) => ({ valor: nombre, etiqueta: nombre }));

export function DemoSelector() {
  const [valor, setValor] = useState<string | null>(null);
  return (
    <div className="grid gap-espacio-5 sm:grid-cols-2 lg:grid-cols-3">
      <Selector
        etiqueta="Departamento"
        opciones={DEPARTAMENTOS}
        ayuda="Lista larga: prueba las flechas o escribe «san»."
      />
      <Selector etiqueta="Tipo de bien" opciones={OPCIONES} valor={valor} onCambiar={setValor} ayuda="Texto de ayuda opcional." />
      <Selector etiqueta="Lleno" opciones={OPCIONES} valorInicial="equipo" ayuda="Texto de ayuda opcional." />
      <Selector etiqueta="Con error" opciones={OPCIONES} error="Elige un tipo de bien." />
      <Selector etiqueta="Deshabilitado" opciones={OPCIONES} deshabilitado ayuda="Texto de ayuda opcional." />
    </div>
  );
}

export function DemoChips() {
  const [filtros, setFiltros] = useState(["Propiedad", "San Salvador", "Hasta $100"]);
  return (
    <div className="flex flex-wrap gap-espacio-2">
      {filtros.map((filtro) => (
        <ChipDeFiltro
          key={filtro}
          texto={filtro}
          onQuitar={() => setFiltros((actuales) => actuales.filter((f) => f !== filtro))}
        />
      ))}
    </div>
  );
}

const PESTANAS = [
  ["ingresos", "Ingresos"],
  ["ocupacion", "Ocupación"],
  ["calificaciones", "Calificaciones"],
] as const;

export function DemoPestanas() {
  const [activa, setActiva] = useState<string>("ingresos");
  return (
    <div className="flex flex-col gap-espacio-4">
      <Pestanas etiqueta="Reportes">
        {PESTANAS.map(([id, texto]) => (
          <Pestana
            key={id}
            id={`demo-tab-${id}`}
            panel={`demo-panel-${id}`}
            activa={activa === id}
            onClick={() => setActiva(id)}
          >
            {texto}
          </Pestana>
        ))}
      </Pestanas>
      {PESTANAS.map(([id, texto]) => (
        <PanelDePestana key={id} id={`demo-panel-${id}`} pestana={`demo-tab-${id}`} activo={activa === id}>
          <p className="texto-cuerpo-pequeno text-texto-secundario">Contenido de «{texto}».</p>
        </PanelDePestana>
      ))}
      <p className="texto-etiqueta-pequena text-texto-secundario">Sin pestaña activa (la primera queda alcanzable con Tab):</p>
      <Pestanas etiqueta="Filtrar por estado">
        <Pestana>Todas</Pestana>
        <Pestana>Confirmadas</Pestana>
        <Pestana>Rechazadas</Pestana>
      </Pestanas>
    </div>
  );
}

export function DemoCampana() {
  return (
    <>
      <CampanaDeNotificaciones noLeidas={0} />
      <CampanaDeNotificaciones noLeidas={3} />
      <CampanaDeNotificaciones noLeidas={120} />
    </>
  );
}

export function DemoCalificacion() {
  const [valor, setValor] = useState(0);
  return (
    <div className="flex flex-col gap-espacio-3">
      <Calificacion valor={valor} onCambiar={setValor} etiqueta="Calificación del bien" />
      {[0, 1, 2, 3, 4, 5].map((n) => (
        <Calificacion key={n} valor={n} />
      ))}
      <span className="flex items-center gap-espacio-3">
        <Calificacion valor={4.5} />
        <span className="texto-etiqueta-pequena text-texto-secundario">Promedio 4,5</span>
      </span>
    </div>
  );
}

export function DemoDialogo() {
  const [abierto, setAbierto] = useState<"normal" | "peligro" | null>(null);
  return (
    <div className="flex flex-wrap gap-espacio-3">
      <Boton jerarquia="secundario" onClick={() => setAbierto("normal")}>
        Abrir confirmación
      </Boton>
      <Boton jerarquia="peligro" onClick={() => setAbierto("peligro")}>
        Abrir acción destructiva
      </Boton>
      <DialogoDeConfirmacion
        abierto={abierto === "normal"}
        titulo="¿Enviar tu reseña?"
        mensaje="No podrás editarla después de enviarla."
        onConfirmar={() => setAbierto(null)}
        onCancelar={() => setAbierto(null)}
      />
      <DialogoDeConfirmacion
        abierto={abierto === "peligro"}
        titulo="¿Eliminar el bloqueo?"
        mensaje="Las fechas volverán a estar disponibles."
        textoConfirmar="Eliminar"
        peligro
        onConfirmar={() => setAbierto(null)}
        onCancelar={() => setAbierto(null)}
      />
    </div>
  );
}

export function DemoCargador() {
  const [nombres, setNombres] = useState<string[]>([]);
  return (
    <div className="grid gap-espacio-4 md:grid-cols-2">
      <div className="flex flex-col gap-espacio-2">
        <CargadorDeArchivos
          accept="image/jpeg,image/png"
          ayuda="JPG o PNG, máximo 5 MB cada una"
          onArchivos={(archivos) => setNombres(archivos.map((archivo) => archivo.name))}
        />
        {nombres.length > 0 && (
          <p className="texto-cuerpo-pequeno text-texto-secundario">Elegidos: {nombres.join(", ")}</p>
        )}
      </div>
      <CargadorDeArchivos
        onArchivos={() => undefined}
        error="JPG o PNG, máximo 5 MB cada una"
      />
    </div>
  );
}

export function DemoMiniaturas() {
  const [principal, setPrincipal] = useState(0);
  return (
    <div className="flex flex-wrap gap-espacio-4">
      {[0, 1, 2].map((indice) => (
        <MiniaturaDeFoto
          key={indice}
          src="/imagenes/foto-ejemplo.png"
          alt={`Foto ${indice + 1}`}
          principal={principal === indice}
          onMarcarPrincipal={() => setPrincipal(indice)}
          onMoverIzquierda={indice > 0 ? () => undefined : undefined}
          onMoverDerecha={indice < 2 ? () => undefined : undefined}
          onQuitar={() => undefined}
        />
      ))}
    </div>
  );
}

export function DemoConversaciones() {
  return (
    <div className="flex max-w-sm flex-col border-t border-borde-sutil">
      <Conversacion
        usuario="carlos_mendez"
        bien="Cámara profesional Canon EOS · Consulta"
        hora="10:45"
        ultimoMensaje="Sí, continúa disponible."
        href="#"
      />
      <Conversacion
        usuario="carlos_mendez"
        bien="Cámara profesional Canon EOS · Entrega"
        hora="10:45"
        ultimoMensaje="Sí, continúa disponible."
        href="#"
        activa
      />
    </div>
  );
}

export function DemoSelectorDePeriodo() {
  const [periodo, setPeriodo] = useState<PeriodoReporte>("rango");
  const [desde, setDesde] = useState("2026-08-01");
  const [hasta, setHasta] = useState("2026-07-01");
  const error =
    periodo === "rango" && desde && hasta && hasta < desde
      ? "La fecha final no puede ser anterior a la inicial."
      : undefined;
  return (
    <SelectorDePeriodo
      periodo={periodo}
      onCambiarPeriodo={setPeriodo}
      desde={desde}
      hasta={hasta}
      onCambiarDesde={setDesde}
      onCambiarHasta={setHasta}
      onAplicar={() => undefined}
      error={error}
    />
  );
}

/** Reproduce el ejemplo de Figma: hoy 18, reservado 20–22, bloqueado 26–27, rango 24–25. */
export function DemoCalendario() {
  const [mes, setMes] = useState(10);
  const ejemplo: Record<string, EstadoDia> = {
    "2026-11-18": "hoy",
    "2026-11-20": "reservado",
    "2026-11-21": "reservado",
    "2026-11-22": "reservado",
    "2026-11-24": "seleccionado",
    "2026-11-25": "en-rango",
    "2026-11-26": "bloqueado",
    "2026-11-27": "bloqueado",
  };
  return (
    <MesDeCalendario
      anio={2026}
      mes={mes}
      estadoDe={(fecha) =>
        ejemplo[fecha] ?? (fecha < "2026-11-18" ? "pasado" : "disponible")
      }
      onSeleccionarDia={() => undefined}
      onMesAnterior={() => setMes((m) => m - 1)}
      onMesSiguiente={() => setMes((m) => m + 1)}
    />
  );
}
