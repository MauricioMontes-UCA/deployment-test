import type { Metadata } from "next";
import { notFound } from "next/navigation";
import type { ReactNode } from "react";
import {
  Alerta,
  AreaDeTexto,
  Avatar,
  BarraDeProgreso,
  Boton,
  CampoDeTexto,
  Casilla,
  Contenedor,
  DiaDeCalendario,
  EncabezadoDePagina,
  EstadoDePagina,
  Icono,
  Imagen,
  InsigniaDeEstado,
  Interruptor,
  LeyendaDeCalendario,
  Logo,
  Mensaje,
  NOMBRES_ICONO,
  Notificacion,
  OpcionEnTarjeta,
  PieDePagina,
  Radio,
  Tabla,
  TablaCelda,
  TablaEncabezado,
  TarjetaDeBien,
  TarjetaDeBienEsqueleto,
  TarjetaDeReserva,
  clasesBoton,
  type EstadoDia,
  type TonoInsignia,
} from "@/components/ui";
import {
  DemoCalendario,
  DemoCampana,
  DemoCalificacion,
  DemoCargador,
  DemoChips,
  DemoConversaciones,
  DemoDialogo,
  DemoMiniaturas,
  DemoNavegacion,
  DemoPestanas,
  DemoSelector,
  DemoSelectorDePeriodo,
} from "./demos";

export const metadata: Metadata = {
  title: "Design System · Arre",
};

const PALETA = [
  { nombre: "Oliva dorado", hex: "#745E1E", token: "fondo-marca", uso: "Marca: botón primario, acentos" },
  { nombre: "Café oliva oscuro", hex: "#483E1F", token: "fondo-marca-hover", uso: "Hover de marca, texto secundario, bordes fuertes" },
  { nombre: "Dorado arena", hex: "#C8B377", token: "borde-default", uso: "Bordes por defecto, deshabilitado" },
  { nombre: "Crema pálido", hex: "#F2E4B8", token: "fondo-sutil", uso: "Superficie sutil, encabezados de tabla" },
  { nombre: "Marfil cálido", hex: "#FFF7DF", token: "fondo-superficie", uso: "Superficie de tarjetas y campos" },
  { nombre: "Amarillo mantequilla", hex: "#FFECB4", token: "fondo-acento", uso: "Acento: seleccionado, mensajes propios" },
  { nombre: "Blanco crema suave", hex: "#FAF4E1", token: "fondo-base", uso: "Fondo base de la página" },
  { nombre: "Café tinta", hex: "#2B2614", token: "fondo-inverso", uso: "Texto principal y pie de página" },
];

const ESTADOS = [
  { nombre: "Verde salvia", hex: "#5B7F3A", token: "estado-exito", uso: "Éxito (ícono, borde, marcador)" },
  { nombre: "Fondo éxito", hex: "#E4EBD6", token: "fondo-exito", uso: "Fondo de éxito" },
  { nombre: "Ocre ámbar", hex: "#C98A1B", token: "estado-advertencia", uso: "Espera / advertencia" },
  { nombre: "Fondo espera", hex: "#F7E8C4", token: "fondo-advertencia", uso: "Fondo de advertencia" },
  { nombre: "Ladrillo", hex: "#A8432D", token: "estado-error", uso: "Error y texto de error" },
  { nombre: "Fondo error", hex: "#F3DDD5", token: "fondo-error", uso: "Fondo de error, días reservados" },
  { nombre: "Azul grisáceo", hex: "#4A6E7C", token: "estado-info", uso: "Información" },
  { nombre: "Fondo información", hex: "#DCE6EA", token: "fondo-info", uso: "Fondo de información" },
];

const TIPOGRAFIA = [
  { clase: "texto-display", nombre: "Display", detalle: "Cormorant 64/72 · móvil 40/48", ejemplo: "Renta lo que necesitas" },
  { clase: "texto-h1", nombre: "Título/H1", detalle: "Cormorant 44/52 · móvil 32/40", ejemplo: "Salón de eventos Las Palmas" },
  { clase: "texto-h2", nombre: "Título/H2", detalle: "Cormorant 32/40", ejemplo: "Salón de eventos Las Palmas" },
  { clase: "texto-h3", nombre: "Título/H3", detalle: "Cormorant 24/32", ejemplo: "Salón de eventos Las Palmas" },
  { clase: "texto-h4", nombre: "Título/H4", detalle: "Cormorant Bold 20/28", ejemplo: "Salón de eventos Las Palmas" },
  { clase: "texto-precio-grande", nombre: "Precio/Grande", detalle: "Cormorant 32/40", ejemplo: "$80.00 / día" },
  { clase: "texto-precio", nombre: "Precio/Base", detalle: "Cormorant Bold 20/24", ejemplo: "$80.00 / día" },
  { clase: "texto-cuerpo-grande", nombre: "Cuerpo/Grande", detalle: "DM Sans 18/28", ejemplo: "Bien publicado con fotos, condiciones y depósito." },
  { clase: "texto-cuerpo", nombre: "Cuerpo/Base", detalle: "DM Sans 16/24", ejemplo: "Bien publicado con fotos, condiciones y depósito." },
  { clase: "texto-cuerpo-medio", nombre: "Cuerpo/Base Medio", detalle: "DM Sans Medium 16/24", ejemplo: "Bien publicado con fotos, condiciones y depósito." },
  { clase: "texto-cuerpo-pequeno", nombre: "Cuerpo/Pequeño", detalle: "DM Sans 14/20", ejemplo: "Bien publicado con fotos, condiciones y depósito." },
  { clase: "texto-etiqueta", nombre: "Etiqueta/Base", detalle: "DM Sans Medium 14/20", ejemplo: "Bien publicado con fotos, condiciones y depósito." },
  { clase: "texto-etiqueta-pequena", nombre: "Etiqueta/Pequeña", detalle: "DM Sans Medium 12/16", ejemplo: "Bien publicado con fotos, condiciones y depósito." },
  { clase: "texto-boton", nombre: "Botón/Base", detalle: "DM Sans SemiBold 15/20 · 2 %", ejemplo: "Solicitar reserva" },
  { clase: "texto-sobretitulo", nombre: "Sobretítulo", detalle: "DM Sans SemiBold 12/16 · 12 %", ejemplo: "Reservas recibidas" },
  { clase: "texto-logo", nombre: "Logo/Base", detalle: "Great Vibes 44/48", ejemplo: "Arre" },
];

const ESPACIOS = [4, 8, 12, 16, 24, 32, 48, 64, 96];

const TONOS: TonoInsignia[] = ["neutro", "marca", "exito", "advertencia", "error", "info"];
const ESTADOS_DIA: EstadoDia[] = ["disponible", "hoy", "seleccionado", "en-rango", "reservado", "bloqueado", "pasado"];

/**
 * Catálogo del Design System «Arre», solo para desarrollo: muestra cada
 * fundamento y componente con sus variantes para compararlo con Figma.
 */
export default function PaginaDesignSystem() {
  if (process.env.NODE_ENV === "production") notFound();

  return (
    <main className="flex flex-col gap-espacio-8 pb-espacio-8">
      <DemoNavegacion />
      <Contenedor className="flex flex-col gap-espacio-8">
        <EncabezadoDePagina
          sobretitulo="Arre · Design System"
          titulo="Catálogo de componentes"
          descripcion="Fundamentos, componentes y patrones de Figma implementados en el repo. Solo disponible en desarrollo."
        />

        <Seccion titulo="Principios">
          <div className="grid gap-espacio-5 sm:grid-cols-2 lg:grid-cols-4">
            {[
              ["Esquinas rectas", "Ningún elemento usa esquinas redondeadas (radio 0)."],
              ["Colores sólidos", "Sin gradientes, sombras ni desenfoques. Profundidad con bordes de 1 px."],
              ["Serif para títulos", "Cormorant Garamond en títulos y precios; DM Sans en el resto; Great Vibes en el logo."],
              ["Layout sereno", "Contenedor de 1312 px (márgenes de 64) y 328 px en móvil (márgenes de 16). Múltiplos de 4."],
            ].map(([titulo, texto]) => (
              <div key={titulo} className="flex flex-col gap-espacio-2 border border-borde-default bg-fondo-superficie p-espacio-5">
                <p className="texto-h3">{titulo}</p>
                <p className="texto-cuerpo-pequeno text-texto-secundario">{texto}</p>
              </div>
            ))}
          </div>
        </Seccion>

        <Seccion titulo="Color">
          <Subtitulo>Paleta base</Subtitulo>
          <Muestras colores={PALETA} />
          <Subtitulo>Estados</Subtitulo>
          <Muestras colores={ESTADOS} />
        </Seccion>

        <Seccion titulo="Tipografía">
          <div className="flex flex-col divide-y divide-borde-sutil">
            {TIPOGRAFIA.map((estilo) => (
              <div key={estilo.clase} className="flex flex-col gap-espacio-2 py-espacio-3 md:flex-row md:items-center md:gap-espacio-6">
                <div className="flex w-64 shrink-0 flex-col">
                  <span className="texto-etiqueta">{estilo.nombre}</span>
                  <code className="texto-etiqueta-pequena text-texto-secundario">
                    {estilo.clase} · {estilo.detalle}
                  </code>
                </div>
                <span className={estilo.clase}>{estilo.ejemplo}</span>
              </div>
            ))}
          </div>
        </Seccion>

        <Seccion titulo="Espaciado">
          <div className="flex flex-wrap items-end gap-espacio-5">
            {ESPACIOS.map((px, indice) => (
              <div key={px} className="flex flex-col items-center gap-espacio-2">
                <span className="bg-fondo-marca" style={{ width: px, height: px }} />
                <span className="texto-etiqueta">{px}</span>
                <code className="texto-etiqueta-pequena text-texto-secundario">espacio-{indice + 1}</code>
              </div>
            ))}
          </div>
        </Seccion>

        <Seccion titulo="Marca e íconos">
          <div className="flex flex-wrap items-center gap-espacio-6">
            <Logo />
            <Logo version="con-lema" />
            <div className="flex flex-wrap gap-espacio-6 bg-fondo-inverso p-espacio-5">
              <Logo fondo="oscuro" />
              <Logo fondo="oscuro" version="con-lema" />
            </div>
          </div>
          <div className="flex flex-wrap gap-espacio-5">
            <Imagen src="/imagenes/foto-ejemplo.png" alt="Foto de ejemplo" sizes="240px" className="size-60" />
            <Imagen alt="Foto no disponible" className="size-60" />
          </div>
          <ul className="grid grid-cols-3 gap-espacio-4 sm:grid-cols-6 lg:grid-cols-10">
            {NOMBRES_ICONO.map((nombre) => (
              <li key={nombre} className="flex flex-col items-center gap-espacio-2 border border-borde-sutil bg-fondo-superficie p-espacio-3">
                <Icono nombre={nombre} />
                <code className="texto-etiqueta-pequena text-texto-secundario">{nombre}</code>
              </li>
            ))}
          </ul>
        </Seccion>

        <Seccion titulo="Formularios">
          <Subtitulo>Botón</Subtitulo>
          {(["primario", "secundario", "terciario", "peligro"] as const).map((jerarquia) => (
            <Fila key={jerarquia}>
              <Boton jerarquia={jerarquia}>Botón</Boton>
              <Boton jerarquia={jerarquia} icono="mas">
                Con ícono
              </Boton>
              <Boton jerarquia={jerarquia} disabled>
                Botón
              </Boton>
              <Boton jerarquia={jerarquia} cargando>
                Botón
              </Boton>
            </Fila>
          ))}
          <Fila>
            <a href="#" className={clasesBoton({ jerarquia: "terciario" })}>
              Enlace con estilo de botón
            </a>
          </Fila>

          <Subtitulo>Campo de texto</Subtitulo>
          <Rejilla>
            <CampoDeTexto etiqueta="Nombre de usuario" placeholder="Escribe aquí" ayuda="Texto de ayuda opcional." contador maxLength={30} />
            <CampoDeTexto etiqueta="Lleno" defaultValue="ana_m" ayuda="Texto de ayuda opcional." contador maxLength={30} />
            <CampoDeTexto etiqueta="Con error" defaultValue="an" error="Debe tener al menos 3 caracteres." contador maxLength={30} />
            <CampoDeTexto etiqueta="Deshabilitado" placeholder="Escribe aquí" ayuda="Texto de ayuda opcional." disabled />
            <CampoDeTexto etiqueta="Búsqueda" icono="buscar" placeholder="Busca un bien" />
          </Rejilla>

          <Subtitulo>Área de texto</Subtitulo>
          <Rejilla>
            <AreaDeTexto etiqueta="Descripción" placeholder="Escribe aquí" ayuda="Texto de ayuda opcional." contador maxLength={500} />
            <AreaDeTexto etiqueta="Con error" defaultValue="Muy corta" error="La descripción es obligatoria." contador maxLength={500} />
            <AreaDeTexto etiqueta="Deshabilitado" placeholder="Escribe aquí" disabled />
          </Rejilla>

          <Subtitulo>Selector</Subtitulo>
          <DemoSelector />
        </Seccion>

        <Seccion titulo="Selección e indicadores">
          <Subtitulo>Opción en tarjeta</Subtitulo>
          <div className="grid gap-espacio-4 sm:grid-cols-2">
            <OpcionEnTarjeta name="rol-demo" value="ARRENDADOR" titulo="Quiero publicar mis bienes" descripcion="Arrendador" />
            <OpcionEnTarjeta name="rol-demo" value="ARRENDATARIO" titulo="Quiero rentar bienes" descripcion="Arrendatario" defaultChecked />
          </div>

          <Subtitulo>Radio, casilla e interruptor</Subtitulo>
          <Fila>
            <Radio name="radio-demo" texto="Opción" />
            <Radio name="radio-demo" texto="Opción" defaultChecked />
            <Radio name="radio-demo-2" texto="Opción" disabled />
            <Radio name="radio-demo-3" texto="Opción" disabled defaultChecked />
          </Fila>
          <Fila>
            <Casilla texto="Casilla" />
            <Casilla texto="Casilla" defaultChecked />
            <Casilla texto="Casilla" disabled />
            <Casilla texto="Casilla" disabled defaultChecked />
          </Fila>
          <Fila>
            <Interruptor texto="Solo usuarios verificados" />
            <Interruptor texto="Solo usuarios verificados" defaultChecked />
            <Interruptor texto="Solo usuarios verificados" disabled />
            <Interruptor texto="Solo usuarios verificados" disabled defaultChecked />
          </Fila>

          <Subtitulo>Insignia de estado</Subtitulo>
          <Fila>
            {TONOS.map((tono) => (
              <InsigniaDeEstado key={tono} tono={tono} texto="Estado" />
            ))}
          </Fila>

          <Subtitulo>Chip de filtro</Subtitulo>
          <DemoChips />

          <Subtitulo>Alerta</Subtitulo>
          <div className="flex max-w-xl flex-col gap-espacio-4">
            {(["exito", "advertencia", "error", "info"] as const).map((tono) => (
              <Alerta key={tono} tono={tono} titulo="Título del aviso">
                Mensaje que explica qué pasó y qué hacer.
              </Alerta>
            ))}
          </div>

          <Subtitulo>Pestañas</Subtitulo>
          <DemoPestanas />

          <Subtitulo>Avatar y campana</Subtitulo>
          <Fila>
            <Avatar nombre="mariana_rivas" />
            <Avatar nombre="mariana_rivas" tamano="grande" />
            <DemoCampana />
          </Fila>

          <Subtitulo>Barra de progreso</Subtitulo>
          <div className="flex max-w-xs flex-col gap-espacio-5">
            <BarraDeProgreso valor={0} etiqueta="Sin avance" />
            <BarraDeProgreso valor={40} etiqueta="Subiendo fotos" />
            <BarraDeProgreso valor={100} etiqueta="Completo" />
          </div>
        </Seccion>

        <Seccion titulo="Contenido">
          <Subtitulo>Tarjeta de bien</Subtitulo>
          <div className="grid grid-cols-1 gap-espacio-5 sm:grid-cols-2 lg:grid-cols-4">
            <TarjetaDeBien
              titulo="Salón de eventos Las Palmas con terraza y cocina"
              precio="$80.00 / día"
              ubicacion="San Salvador Centro, San Salvador"
              foto="/imagenes/foto-ejemplo.png"
              href="#"
            />
            <TarjetaDeBien titulo="Taladro industrial" precio="$12.00 / día" ubicacion="Santa Tecla, La Libertad" />
            <TarjetaDeBienEsqueleto />
          </div>

          <Subtitulo>Notificación</Subtitulo>
          <div className="flex max-w-3xl flex-col gap-espacio-3">
            <Notificacion
              titulo="Nueva solicitud de reserva"
              mensaje="ana_m solicitó Taladro industrial del 20/11/2026 al 22/11/2026."
              modulo="Reservas"
              fecha="18/11/2026 14:32"
            />
            <Notificacion
              titulo="Nueva solicitud de reserva"
              mensaje="ana_m solicitó Taladro industrial del 20/11/2026 al 22/11/2026."
              modulo="Reservas"
              fecha="18/11/2026 14:32"
              leida
            />
          </div>

          <Subtitulo>Día de calendario</Subtitulo>
          <Fila>
            {ESTADOS_DIA.map((estado) => (
              <DiaDeCalendario key={estado} dia={14} estado={estado} etiqueta={`14, ${estado}`} />
            ))}
          </Fila>

          <Subtitulo>Calificación</Subtitulo>
          <DemoCalificacion />

          <Subtitulo>Mensaje</Subtitulo>
          <div className="flex max-w-xl flex-col gap-espacio-3">
            <Mensaje autor="carlos_mendez" fecha="05/11/2026 10:40">
              Sí, incluye dos baterías y el cargador.
            </Mensaje>
            <Mensaje autor="ana_m" fecha="05/11/2026 10:42" propio>
              Perfecto, gracias.
            </Mensaje>
          </div>

          <Subtitulo>Tabla</Subtitulo>
          <Tabla>
            <thead>
              <tr>
                <TablaEncabezado>Bien</TablaEncabezado>
                <TablaEncabezado alineacion="derecha" orden="descendente">
                  Ingresos
                </TablaEncabezado>
                <TablaEncabezado alineacion="derecha" orden="ascendente">
                  Ocupación
                </TablaEncabezado>
              </tr>
            </thead>
            <tbody>
              <tr>
                <TablaCelda>Salón Las Palmas</TablaCelda>
                <TablaCelda alineacion="derecha">$480.00</TablaCelda>
                <TablaCelda alineacion="derecha">62 %</TablaCelda>
              </tr>
              <tr>
                <TablaCelda>Taladro industrial</TablaCelda>
                <TablaCelda alineacion="derecha" enfasis="atenuada">
                  Sin ingresos
                </TablaCelda>
                <TablaCelda alineacion="derecha" enfasis="atenuada">
                  Sin días disponibles
                </TablaCelda>
              </tr>
              <tr>
                <TablaCelda enfasis="total">Total</TablaCelda>
                <TablaCelda enfasis="total" alineacion="derecha">
                  $480.00
                </TablaCelda>
                <TablaCelda enfasis="total" alineacion="derecha">
                  31 %
                </TablaCelda>
              </tr>
            </tbody>
          </Tabla>
        </Seccion>

        <Seccion titulo="Composición">
          <Subtitulo>Diálogo de confirmación</Subtitulo>
          <DemoDialogo />

          <Subtitulo>Cargador de archivos</Subtitulo>
          <DemoCargador />

          <Subtitulo>Miniatura de foto</Subtitulo>
          <DemoMiniaturas />

          <Subtitulo>Tarjeta de reserva</Subtitulo>
          <div className="flex flex-col gap-espacio-4">
            <TarjetaDeReserva
              titulo="Cámara profesional Canon EOS"
              foto="/imagenes/foto-ejemplo.png"
              fechas="20/11/2026 → 22/11/2026 · 3 días"
              participante="Arrendador: carlos_mendez"
              estado={{ texto: "Confirmada", tono: "exito" }}
              accion={
                <a href="#" className={clasesBoton({ jerarquia: "terciario" })}>
                  Ver detalle
                </a>
              }
            />
            <TarjetaDeReserva
              titulo="Taladro industrial"
              foto="/imagenes/foto-ejemplo.png"
              fechas="02/12/2026 → 03/12/2026 · 2 días"
              motivoRechazo="Motivo: el bien estará en mantenimiento esas fechas."
              participante="Arrendatario: ana_m"
              estado={{ texto: "Rechazada", tono: "error" }}
              accion={
                <a href="#" className={clasesBoton({ jerarquia: "terciario" })}>
                  Gestionar
                </a>
              }
            />
          </div>

          <Subtitulo>Conversación</Subtitulo>
          <DemoConversaciones />
        </Seccion>

        <Seccion titulo="Patrones">
          <Subtitulo>Estado de página</Subtitulo>
          <div className="grid gap-espacio-4 lg:grid-cols-2">
            <EstadoDePagina tipo="vacio" accion={<Boton>Buscar bienes</Boton>} />
            <EstadoDePagina tipo="error" accion={<Boton jerarquia="secundario">Reintentar</Boton>} />
            <EstadoDePagina tipo="sin-permiso" accion={<Boton jerarquia="secundario">Ir al inicio</Boton>} />
            <EstadoDePagina tipo="no-encontrado" accion={<Boton jerarquia="secundario">Volver a la búsqueda</Boton>} />
            <EstadoDePagina tipo="cargando" />
          </div>

          <Subtitulo>Selector de periodo</Subtitulo>
          <DemoSelectorDePeriodo />

          <Subtitulo>Mes de calendario y leyenda</Subtitulo>
          <DemoCalendario />
          <LeyendaDeCalendario />

          <Subtitulo>Encabezado de página</Subtitulo>
          <EncabezadoDePagina
            sobretitulo="Sección"
            titulo="Título de la página"
            descripcion="Descripción breve de lo que el usuario puede hacer en esta pantalla."
          />
        </Seccion>
      </Contenedor>
      <PieDePagina />
    </main>
  );
}

function Seccion({ titulo, children }: { titulo: string; children: ReactNode }) {
  return (
    <section className="flex flex-col gap-espacio-5 border-t border-borde-default pt-espacio-6">
      <h2 className="texto-h2">{titulo}</h2>
      {children}
    </section>
  );
}

function Subtitulo({ children }: { children: ReactNode }) {
  return <h3 className="texto-sobretitulo pt-espacio-2 text-texto-acento">{children}</h3>;
}

function Fila({ children }: { children: ReactNode }) {
  return <div className="flex flex-wrap items-center gap-espacio-5">{children}</div>;
}

function Rejilla({ children }: { children: ReactNode }) {
  return <div className="grid gap-espacio-5 sm:grid-cols-2 lg:grid-cols-3">{children}</div>;
}

function Muestras({
  colores,
}: {
  colores: { nombre: string; hex: string; token: string; uso: string }[];
}) {
  return (
    <div className="grid gap-espacio-4 sm:grid-cols-2 lg:grid-cols-4">
      {colores.map((color) => (
        <div key={color.nombre} className="flex flex-col border border-borde-default">
          <span className="h-24" style={{ backgroundColor: `var(--color-${color.token})` }} />
          <div className="flex flex-col gap-0.5 bg-fondo-superficie p-espacio-3">
            <span className="texto-etiqueta">{color.nombre}</span>
            <code className="texto-etiqueta-pequena text-texto-secundario">
              {color.hex} · {color.token}
            </code>
            <span className="texto-etiqueta-pequena text-texto-secundario">{color.uso}</span>
          </div>
        </div>
      ))}
    </div>
  );
}
