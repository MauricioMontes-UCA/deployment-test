import type { Metadata } from "next";
import { BarraDeBusqueda } from "@/components/busqueda/barra-de-busqueda";
import { ChipsDeFiltros } from "@/components/busqueda/chips-de-filtros";
import { FiltrosDeBusqueda } from "@/components/busqueda/filtros-de-busqueda";
import { ResultadosDeBusqueda } from "@/components/busqueda/resultados-de-busqueda";
import { Contenedor } from "@/components/ui";
import { criteriosDesdeUrl, urlDeBusqueda, type ParametrosDeUrl } from "@/lib/busqueda";

export const metadata: Metadata = {
  title: "Buscar bienes · Arre",
};

/**
 * Búsqueda de bienes (FE-3.1) con filtros (FE-4.1). Los criterios y los
 * filtros viven en la URL (`/buscar?q=salon&departamento=…&tipo=PROPIEDAD…`),
 * así que recargar o compartir el enlace conserva la búsqueda y los chips. Los
 * resultados se cargan en el navegador, de 20 en 20, a medida que se baja.
 */
export default async function PaginaBuscar({
  searchParams,
}: {
  searchParams: Promise<ParametrosDeUrl>;
}) {
  const criterios = criteriosDesdeUrl(await searchParams);
  // Una búsqueda nueva monta la barra y los resultados desde cero: la barra
  // toma los criterios nuevos y la lista vuelve a la página 1.
  const busqueda = urlDeBusqueda(criterios);

  return (
    <Contenedor className="flex flex-col gap-5 pt-5 pb-espacio-7 md:gap-espacio-6 md:pt-10 md:pb-espacio-9">
      <BarraDeBusqueda key={`barra:${busqueda}`} variante="resultados" criterios={criterios} />
      <div className="flex flex-col gap-5 lg:flex-row lg:items-start lg:gap-espacio-6">
        <FiltrosDeBusqueda key={`filtros:${busqueda}`} criterios={criterios} />
        <div className="min-w-0 flex-1">
          <ResultadosDeBusqueda
            key={`resultados:${busqueda}`}
            criterios={criterios}
            filtrosActivos={<ChipsDeFiltros criterios={criterios} />}
          />
        </div>
      </div>
    </Contenedor>
  );
}
