import { render, screen, within } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";
import LayoutBuscar from "@/app/buscar/layout";
import PaginaBuscar from "@/app/buscar/page";
import { obtenerTokens } from "@/lib/sesion";
import { obtenerUsuarioActual } from "@/lib/usuario-actual";

const redirigir = vi.hoisted(() =>
  vi.fn((destino: string): never => {
    throw new Error(`REDIRECT:${destino}`);
  }),
);
vi.mock("next/navigation", () => ({
  usePathname: () => "/buscar",
  useRouter: () => ({ push: vi.fn(), replace: vi.fn(), refresh: vi.fn() }),
  redirect: redirigir,
}));
vi.mock("@/lib/sesion", () => ({ obtenerTokens: vi.fn() }));
vi.mock("@/app/actions/auth", () => ({ cerrarSesion: vi.fn() }));
vi.mock("@/lib/usuario-actual", () => ({ obtenerUsuarioActual: vi.fn() }));
// La lista tiene sus propias pruebas; aquí basta con saber qué criterios recibe.
vi.mock("@/components/busqueda/resultados-de-busqueda", () => ({
  ResultadosDeBusqueda: ({
    criterios,
    filtrosActivos,
  }: {
    criterios: object;
    filtrosActivos?: React.ReactNode;
  }) => (
    <>
      <p data-testid="criterios">{JSON.stringify(criterios)}</p>
      {filtrosActivos}
    </>
  ),
}));

beforeEach(() => {
  vi.mocked(obtenerTokens).mockResolvedValue({ acceso: undefined, refresh: undefined });
  redirigir.mockClear();
});

describe("Página /buscar", () => {
  it("al recargar conserva el término y la ubicación de la URL", async () => {
    render(
      await PaginaBuscar({
        searchParams: Promise.resolve({
          q: "salón",
          departamento: "San Salvador",
          municipio: "Soyapango",
        }),
      }),
    );

    expect(screen.getByRole("searchbox", { name: "Buscar" })).toHaveValue("salón");
    expect(screen.getByRole("combobox", { name: "Departamento" })).toHaveTextContent("San Salvador");
    expect(screen.getByRole("combobox", { name: "Municipio" })).toHaveTextContent("Soyapango");
    expect(JSON.parse(screen.getByTestId("criterios").textContent!)).toEqual({
      q: "salón",
      departamento: "San Salvador",
      municipio: "Soyapango",
    });
  });

  it("al recargar conserva los filtros, los chips y el panel", async () => {
    render(
      await PaginaBuscar({
        searchParams: Promise.resolve({
          q: "salón",
          tipo: "PROPIEDAD",
          categoria: "Salón de eventos",
          precioMin: "20",
          precioMax: "100",
        }),
      }),
    );

    const chips = within(screen.getByRole("list", { name: "Filtros activos" }));
    expect(chips.getAllByRole("listitem").map((chip) => chip.textContent)).toEqual([
      "Propiedad",
      "Salón de eventos",
      "$20 a $100",
    ]);
    const panel = within(screen.getByRole("complementary", { name: "Filtros" }));
    expect(panel.getByRole("radio", { name: "Propiedad" })).toBeChecked();
    expect(panel.getByLabelText("Mínimo")).toHaveValue(20);
    expect(screen.getByRole("button", { name: "Filtros (3)" })).toBeInTheDocument();
  });

  it("sin parámetros busca todo", async () => {
    render(await PaginaBuscar({ searchParams: Promise.resolve({}) }));

    expect(screen.getByRole("searchbox", { name: "Buscar" })).toHaveValue("");
    expect(screen.getByTestId("criterios")).toHaveTextContent("{}");
  });
});

describe("Layout de /buscar", () => {
  const hijos = <p>Contenido</p>;
  const montar = async () =>
  render(await LayoutBuscar({ children: hijos }));
  it("sin sesión muestra la barra de visitante", async () => {
    vi.mocked(obtenerUsuarioActual).mockResolvedValue({ estado: "sin-sesion" });
    await montar();

    expect(screen.getAllByRole("link", { name: /Iniciar sesión/ }).length).toBeGreaterThan(0);
    expect(screen.getByText("Contenido")).toBeInTheDocument();
  });

  it("con un token rechazado manda a /sesion-vencida", async () => {
    vi.mocked(obtenerUsuarioActual).mockResolvedValue({ estado: "sin-sesion" });
    vi.mocked(obtenerTokens).mockResolvedValue({ acceso: "vencido", refresh: undefined });

    await expect(montar()).rejects.toThrow("REDIRECT:/sesion-vencida");
  });
});
