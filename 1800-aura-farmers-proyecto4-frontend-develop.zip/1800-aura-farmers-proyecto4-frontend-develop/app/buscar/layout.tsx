import { redirect } from "next/navigation";
import { cerrarSesion } from "@/app/actions/auth";
import { NavegacionSuperior, PieDePagina } from "@/components/ui";
import { obtenerTokens } from "@/lib/sesion";
import { obtenerUsuarioActual } from "@/lib/usuario-actual";

/**
 * Marco de /buscar: barra superior según la sesión y pie de página. La
 * búsqueda es pública, así que se ve también sin sesión.
 */
export default async function LayoutBuscar({
  children,
}: {
   children: React.ReactNode;
}) { 
  
  const sesion = await obtenerUsuarioActual();
  // Igual que la portada: con token y rechazado por el backend (401), la
  // sesión venció y se borran las cookies antes de seguir.
  if (sesion.estado === "sin-sesion" && (await obtenerTokens()).acceso) {
    redirect("/sesion-vencida");
  }
  const usuario = sesion.estado === "ok" ? sesion.usuario : null;

  return (
    <>
      {usuario ? (
        <NavegacionSuperior
          rol={usuario.rol === "ARRENDADOR" ? "arrendador" : "arrendatario"}
          nombreUsuario={usuario.nombreUsuario}
          onCerrarSesion={cerrarSesion}
        />
      ) : (
        <NavegacionSuperior rol="visitante" />
      )}
      <main className="flex-1 bg-fondo-base">{children}</main>
      <PieDePagina />
    </>
  );
}
