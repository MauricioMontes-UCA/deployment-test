import { NextResponse, type NextRequest } from "next/server";
import { llamarApi } from "@/lib/api";
import { cerrarSesionApi } from "@/lib/auth-api";
import { COOKIE_REFRESH, borrarCookiesSesion } from "@/lib/cookies-sesion";
import { aplicarCambiosDeSesion, obtenerAccesoVigente } from "@/lib/sesion-vigente";

/**
 * Cierra una sesión que el backend ya rechazó (401) y lleva a /login. Un
 * server component no puede borrar cookies al renderizar, y sin borrarlas el
 * proxy podría ver una sesión y devolver a `/`. Los layouts y `apiFetch`
 * redirigen aquí en vez de a /login.
 *
 * Como es un GET y las cookies SameSite=Lax viajan en una navegación desde
 * otro sitio, un enlace externo podría pedir esta ruta. Por eso antes de
 * cerrar nada se comprueba la sesión con /auth/me:
 * - si responde 200, la sesión está viva y solo se redirige a `/`;
 * - si el backend no responde, tampoco se toca nada;
 * - solo con un 401 (o sin ningún token utilizable) se revoca el refresh
 *   token en el backend y se borran las dos cookies.
 *
 * La redirección es relativa (`Location: /login`): detrás de Docker o de un
 * proxy, `request.nextUrl` trae el host en el que escucha el servidor
 * (p. ej. `0.0.0.0:3001`) y no el que usa el navegador.
 */
function irA(ruta: string) {
  return new NextResponse(null, { status: 307, headers: { Location: ruta } });
}

export async function GET(request: NextRequest) {
  const refresh = request.cookies.get(COOKIE_REFRESH)?.value;
  const estado = await obtenerAccesoVigente(request.cookies);

  if (estado.acceso) {
    const { status } = await llamarApi("auth/me", {}, estado.acceso);
    if (status !== 401) return aplicarCambiosDeSesion(irA("/"), estado);
  } else if (refresh && !estado.refreshRechazado) {
    // Hay refresh token pero el backend no respondió: se reintenta después.
    return irA("/");
  }

  // Si el backend no responde a la revocación, igual se cierra la sesión aquí.
  if (refresh) await cerrarSesionApi(refresh);
  const respuesta = irA("/login");
  borrarCookiesSesion(respuesta.cookies);
  return respuesta;
}
