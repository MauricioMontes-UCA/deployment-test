// @vitest-environment node
import { NextRequest } from "next/server";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { GET } from "@/app/sesion-vencida/route";
import { reiniciarRenovaciones } from "@/lib/sesion-vigente";
import { tokenDePrueba } from "@/pruebas/tokens";

const fetchSimulado = vi.fn();
const API = "http://api.test/api/v1";
const vigente = () => tokenDePrueba({ exp: Math.floor(Date.now() / 1000) + 600 });
const vencido = () => tokenDePrueba({ exp: Math.floor(Date.now() / 1000) - 60 });

function responder(status: number, cuerpo: unknown = {}) {
  // Un 204 no lleva cuerpo.
  fetchSimulado.mockResolvedValueOnce(new Response(status === 204 ? null : JSON.stringify(cuerpo), { status }));
}

beforeEach(() => {
  reiniciarRenovaciones();
  vi.stubEnv("API_URL", API);
  vi.stubEnv("REFRESH_TOKEN_EXPIRES_IN_DAYS", "7");
  vi.stubGlobal("fetch", fetchSimulado);
});

afterEach(() => {
  vi.unstubAllEnvs();
  vi.unstubAllGlobals();
  fetchSimulado.mockReset();
});

function pedir(cookie?: string) {
  return GET(new NextRequest("http://localhost:3001/sesion-vencida", { headers: cookie ? { cookie } : {} }));
}

// La redirección es relativa: no depende del host en el que escucha el servidor.
const destino = (respuesta: Response) => respuesta.headers.get("location");
const llamadas = () => fetchSimulado.mock.calls.map(([url]) => String(url).replace(API, ""));

describe("GET /sesion-vencida", () => {
  it("con el token rechazado (401) revoca el refresh token, borra las cookies y va al login", async () => {
    responder(401, { message: "La cuenta no existe o está inactiva.", statusCode: 401 });
    responder(204);

    const respuesta = await pedir(`access_token=${vigente()}; refresh_token=r1`);

    expect(destino(respuesta)).toBe("/login");
    expect(llamadas()).toEqual(["/auth/me", "/auth/logout"]);
    expect(JSON.parse(fetchSimulado.mock.calls[1][1].body)).toEqual({ refreshToken: "r1" });
    expect(respuesta.cookies.get("access_token")?.value).toBe("");
    expect(respuesta.cookies.get("refresh_token")?.value).toBe("");
  });

  it("con una sesión válida no cierra nada: un enlace de otro sitio no puede cerrarla", async () => {
    responder(200, { id: "u1" });

    const respuesta = await pedir(`access_token=${vigente()}; refresh_token=r1`);

    expect(destino(respuesta)).toBe("/");
    expect(llamadas()).toEqual(["/auth/me"]);
    expect(respuesta.cookies.get("refresh_token")).toBeUndefined();
  });

  it("con el access vencido pero el refresh vivo, renueva y no cierra la sesión", async () => {
    const nuevo = vigente();
    responder(200, { accessToken: nuevo, refreshToken: "r2", expiresIn: 900 });
    responder(200, { id: "u1" });

    const respuesta = await pedir(`access_token=${vencido()}; refresh_token=r1`);

    expect(destino(respuesta)).toBe("/");
    expect(llamadas()).toEqual(["/auth/refresh", "/auth/me"]);
    expect(respuesta.cookies.get("refresh_token")?.value).toBe("r2");
  });

  it("si el backend no responde, no toca la sesión", async () => {
    fetchSimulado.mockRejectedValueOnce(new TypeError("fetch failed"));
    const respuesta = await pedir(`access_token=${vigente()}; refresh_token=r1`);
    expect(destino(respuesta)).toBe("/");
    expect(respuesta.cookies.get("refresh_token")).toBeUndefined();
  });

  it("redirige con una ruta relativa aunque el servidor escuche en 0.0.0.0 (Docker)", async () => {
    const respuesta = await GET(new NextRequest("http://0.0.0.0:3001/sesion-vencida"));
    expect(respuesta.status).toBe(307);
    expect(respuesta.headers.get("location")).toBe("/login");
  });

  it("sin cookies no llama al backend y lleva al login", async () => {
    const respuesta = await pedir();
    expect(fetchSimulado).not.toHaveBeenCalled();
    expect(destino(respuesta)).toBe("/login");
  });
});
