"use client";

import { PanelDeConversacion } from "@/components/mensajeria/panel-de-conversacion";
import type { MensajeConversacion, ResultadoEnvioMensaje } from "@/lib/mensajes";

type ConversacionPreviaProps = {
  /** Usuario de la sesión: sus mensajes van a la derecha. */
  usuario: { id: string; nombreUsuario: string };
  /** Nombre de usuario del arrendador (título del panel en móvil). */
  arrendador: string;
  /** Historial en orden cronológico. */
  mensajesIniciales: MensajeConversacion[];
  /** Server action con el id de la conversación ya aplicado. */
  enviar: (contenido: string) => Promise<ResultadoEnvioMensaje>;
  className?: string;
};

/**
 * Panel de mensajes de FE-13.1: el panel compartido con los textos de la
 * consulta previa (Figma 30:2, 30:460 y 30:548). Toda la lógica vive en
 * `PanelDeConversacion`.
 */
export function ConversacionPrevia({ arrendador, ...props }: ConversacionPreviaProps) {
  return (
    <PanelDeConversacion
      {...props}
      titulo={{ movil: `Conversación con ${arrendador}`, escritorio: "Mensajes" }}
      vacio={{ titulo: "Aún no hay mensajes", mensaje: "Escribe tu primera pregunta sobre esta publicación." }}
    />
  );
}
