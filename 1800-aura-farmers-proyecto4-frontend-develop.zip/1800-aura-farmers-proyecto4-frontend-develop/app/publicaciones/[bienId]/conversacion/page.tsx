import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import type { ReactNode } from "react";
import { cerrarSesion } from "@/app/actions/auth";
import { enviarMensaje } from "@/app/actions/conversacion";
import {
  Contenedor,
  EncabezadoDePagina,
  EstadoDePagina,
  NavegacionSuperior,
  PieDePagina,
  clasesBoton,
} from "@/components/ui";
import { ConversacionPrevia } from "./conversacion-previa";
import { cargarConversacion, type UsuarioActual } from "./datos";
import { ResumenPublicacion, TarjetaPublicacion } from "./tarjeta-publicacion";

export const metadata: Metadata = { title: "Consulta previa · Arre" };

/** Navegación, contenido con los márgenes de Figma y pie de página. */
function Marco({ usuario, children }: { usuario: UsuarioActual; children: ReactNode }) {
  return (
    <>
      <NavegacionSuperior
        rol={usuario.rol === "ARRENDADOR" ? "arrendador" : "arrendatario"}
        nombreUsuario={usuario.nombreUsuario}
        onCerrarSesion={cerrarSesion}
      />
      <main className="flex-1">
        <Contenedor className="flex flex-col gap-espacio-4 pt-espacio-5 pb-espacio-7 lg:gap-espacio-6 lg:pt-espacio-7 lg:pb-espacio-9">
          {children}
        </Contenedor>
      </main>
      <PieDePagina />
    </>
  );
}

const volverABuscar = (
  <Link href="/buscar" className={clasesBoton({ jerarquia: "secundario" })}>
    Volver a la búsqueda
  </Link>
);

/**
 * FE-13.1: el arrendatario consulta al arrendador antes de reservar. Abre (o
 * recupera) la conversación sobre la publicación y muestra su historial.
 *
 * El arrendador responde desde su bandeja (FE-13.2), no desde esta ruta.
 */
export default async function ConsultaPreviaPage({
  params,
}: PageProps<"/publicaciones/[bienId]/conversacion">) {
  const { bienId } = await params;
  const pantalla = await cargarConversacion(bienId);

  switch (pantalla.tipo) {
    case "sin-sesion":
      // Una página no puede borrar cookies: /sesion-vencida las borra, revoca
      // la sesión y lleva al login (PR #2).
      redirect("/sesion-vencida");

    case "sin-permiso":
      return (
        <Marco usuario={pantalla.usuario}>
          <EstadoDePagina
            tipo="sin-permiso"
            titulo="No tienes permiso para ver esta conversación."
            mensaje="Solo los arrendatarios pueden consultar al arrendador desde una publicación."
            accion={volverABuscar}
          />
        </Marco>
      );

    case "no-encontrada":
      return (
        <Marco usuario={pantalla.usuario}>
          <EstadoDePagina
            tipo="no-encontrado"
            titulo="No encontramos esa publicación."
            mensaje="Revisa el enlace o búscala de nuevo."
            accion={volverABuscar}
          />
        </Marco>
      );

    case "inactiva":
      return (
        <Marco usuario={pantalla.usuario}>
          <EstadoDePagina
            tipo="no-encontrado"
            icono="buscar"
            titulo="Esta publicación ya no está disponible."
            mensaje="Solo se pueden enviar consultas sobre publicaciones activas."
            accion={volverABuscar}
          />
        </Marco>
      );

    case "lista": {
      const { usuario, datos } = pantalla;
      return (
        <Marco usuario={usuario}>
          {/*
            En móvil el título lo da el panel (Figma); el h1 queda para lectores de
            pantalla. `sr-only` va en un contenedor propio: puesto en el <header>,
            su `w-full` anulaba el ancho de 1 px y desbordaba la página a 360 px.
          */}
          <div className="sr-only lg:not-sr-only">
            <EncabezadoDePagina sobretitulo="Consulta previa" titulo={`Conversación con ${datos.arrendador}`} />
          </div>
          <div className="flex flex-col gap-espacio-4 lg:flex-row lg:items-start lg:gap-espacio-6">
            <ResumenPublicacion
              publicacion={datos.publicacion}
              arrendador={datos.arrendador}
              className="lg:hidden"
            />
            <TarjetaPublicacion
              publicacion={datos.publicacion}
              arrendador={datos.arrendador}
              className="hidden lg:flex lg:w-100 lg:shrink-0"
            />
            <ConversacionPrevia
              usuario={usuario}
              arrendador={datos.arrendador}
              mensajesIniciales={datos.mensajes}
              enviar={enviarMensaje.bind(null, datos.conversacionId)}
              className="lg:flex-1"
            />
          </div>
        </Marco>
      );
    }
  }
}
