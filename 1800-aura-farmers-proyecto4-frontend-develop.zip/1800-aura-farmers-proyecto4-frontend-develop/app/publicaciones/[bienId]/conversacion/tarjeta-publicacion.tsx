import Link from "next/link";
import { Imagen, InsigniaDeEstado, clasesBoton } from "@/components/ui";
import { unirClases } from "@/lib/clases";
import type { PublicacionConsultada } from "./datos";

type TarjetaPublicacionProps = {
  publicacion: PublicacionConsultada;
  arrendador: string;
  className?: string;
};

/**
 * Detalle del bien (FE-2.1). Su ruta planificada es `/bienes/{id}`, que llega
 * con el PR #16; el calendario de disponibilidad vive en esa misma página.
 */
const rutaPublicacion = (id: string) => `/bienes/${id}`;

/**
 * Publicación consultada, en escritorio (FE-13.1): foto, título, precio,
 * arrendador, estado y los enlaces al detalle. Solo se llega aquí con la
 * publicación ACTIVA (el backend rechaza las demás), por eso la insignia es fija.
 */
export function TarjetaPublicacion({ publicacion, arrendador, className }: TarjetaPublicacionProps) {
  const ruta = rutaPublicacion(publicacion.id);
  return (
    <article
      aria-labelledby="publicacion-titulo"
      className={unirClases(
        "flex w-full flex-col gap-espacio-3 border border-borde-default bg-fondo-superficie p-espacio-5",
        className,
      )}
    >
      <Imagen src={publicacion.foto} alt={publicacion.titulo} sizes="352px" className="h-58 w-full" />
      <p className="texto-sobretitulo text-texto-secundario">Publicación</p>
      <h2 id="publicacion-titulo" className="texto-h3 text-texto-primario">
        {publicacion.titulo}
      </h2>
      <p className="texto-precio text-texto-primario">{publicacion.precio}</p>
      <p className="texto-cuerpo-pequeno text-texto-secundario">Arrendador: {arrendador}</p>
      <InsigniaDeEstado texto="Activa" tono="exito" className="self-start" />
      <Link href={ruta} className={clasesBoton({ jerarquia: "secundario", className: "w-full" })}>
        Ver publicación
      </Link>
      <Link href={ruta} className={clasesBoton({ jerarquia: "primario", className: "w-full" })}>
        Ver disponibilidad
      </Link>
    </article>
  );
}

/** Resumen de la publicación en móvil (FE-13.1): foto pequeña, título y arrendador. */
export function ResumenPublicacion({ publicacion, arrendador, className }: TarjetaPublicacionProps) {
  return (
    <article
      className={unirClases(
        "flex w-full items-center gap-espacio-3 border border-borde-default bg-fondo-superficie p-espacio-4",
        className,
      )}
    >
      <Imagen src={publicacion.foto} alt={publicacion.titulo} sizes="56px" compacta className="size-14 shrink-0" />
      <div className="flex min-w-0 flex-1 flex-col gap-espacio-1">
        {/* Figma 30:509: título en «Título/H4» y «Consulta · …» en «Etiqueta/Pequeña». */}
        <h2 className="texto-h4 text-texto-primario">
          <Link href={rutaPublicacion(publicacion.id)} className="underline-offset-2 hover:underline">
            {publicacion.titulo}
          </Link>
        </h2>
        <p className="texto-etiqueta-pequena text-texto-secundario">Consulta · {arrendador}</p>
      </div>
    </article>
  );
}
