import { llamarApi } from "@/lib/api";
import { formatearPrecio, type UnidadCobro } from "@/lib/bienes";
import { leerHistorial, type MensajeConversacion } from "@/lib/mensajes";
import { obtenerUsuarioActual, type UsuarioActual } from "@/lib/usuario-actual";

export type { UsuarioActual };

const ID_BIEN = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const UNIDADES: readonly string[] = ["HORA", "DIA", "NOCHE", "SEMANA"] satisfies UnidadCobro[];

/** La publicación tal como la muestra la tarjeta. */
export type PublicacionConsultada = {
  id: string;
  titulo: string;
  /** «$80.00 / día». */
  precio: string;
  /** Ruta de la foto principal (`/uploads/…`), si el bien tiene. */
  foto: string | null;
};

export type DatosConversacion = {
  conversacionId: string;
  publicacion: PublicacionConsultada;
  /** Nombre de usuario del arrendador, según la conversación. */
  arrendador: string;
  /** Historial en orden cronológico. */
  mensajes: MensajeConversacion[];
};

export type PantallaConversacion =
  /** Sin sesión o sesión rechazada (401): la página pasa por `/sesion-vencida`. */
  | { tipo: "sin-sesion" }
  /** No es arrendatario, o el backend dice que no participa (403). */
  | { tipo: "sin-permiso"; usuario: UsuarioActual }
  /** El id no es válido o la publicación no existe (404). */
  | { tipo: "no-encontrada"; usuario: UsuarioActual }
  /** La publicación no está ACTIVA (422 de BE-13.1). */
  | { tipo: "inactiva"; usuario: UsuarioActual }
  | { tipo: "lista"; usuario: UsuarioActual; datos: DatosConversacion };

/** Error inesperado del backend: lo muestra `error.tsx` con «Reintentar». */
export class ErrorDeCarga extends Error {
  constructor(recurso: string, status: number) {
    super(status === 0 ? `No se pudo consultar ${recurso}.` : `${recurso} respondió ${status}.`);
    this.name = "ErrorDeCarga";
  }
}

const esObjeto = (valor: unknown): valor is Record<string, unknown> =>
  typeof valor === "object" && valor !== null;

/** Id y arrendador de la respuesta de `POST /bienes/:bienId/conversacion`. */
function leerConversacion(datos: unknown) {
  if (!esObjeto(datos) || !esObjeto(datos.arrendador)) return null;
  const { id } = datos;
  const { nombreUsuario } = datos.arrendador;
  if (typeof id !== "string" || !ID_BIEN.test(id) || typeof nombreUsuario !== "string") return null;
  return { id, arrendador: nombreUsuario };
}

/** Lo que muestra la tarjeta, de `GET /bienes/:bienId` (la foto principal va primero). */
function leerPublicacion(datos: unknown, bienId: string): PublicacionConsultada | null {
  if (!esObjeto(datos)) return null;
  const { titulo, precio, unidadCobro, fotos } = datos;
  if (
    typeof titulo !== "string" ||
    typeof precio !== "number" ||
    !Number.isFinite(precio) ||
    typeof unidadCobro !== "string" ||
    !UNIDADES.includes(unidadCobro) ||
    (fotos !== undefined && !Array.isArray(fotos))
  ) {
    return null;
  }
  const principal = Array.isArray(fotos)
    ? (fotos.find((foto) => esObjeto(foto) && foto.esPrincipal === true) ?? fotos[0])
    : undefined;
  const foto = esObjeto(principal) && typeof principal.url === "string" ? principal.url : null;
  return { id: bienId, titulo, precio: formatearPrecio(precio, unidadCobro as UnidadCobro), foto };
}

/**
 * Decide qué muestra `/publicaciones/[bienId]/conversacion` (FE-13.1), solo
 * para el ARRENDATARIO:
 *
 * 1. Usuario de la sesión (`GET /auth/me`). Otro rol no llama al backend: la
 *    apertura crea la conversación, y solo un arrendatario puede abrirla.
 * 2. En paralelo, `POST /bienes/:bienId/conversacion` (201 la crea, 200 la
 *    recupera; los dos sirven igual) y `GET /bienes/:bienId` (la tarjeta).
 * 3. `GET /conversaciones/:id/mensajes?orden=asc`: el historial, que el backend
 *    solo entrega a los participantes.
 *
 * El backend comprueba que la publicación esté ACTIVA antes de crear o
 * recuperar la conversación, así que una publicación inactiva responde 422 y
 * se muestra el estado «ya no está disponible». El frontend no agrega reglas
 * propias. Los errores inesperados lanzan `ErrorDeCarga`.
 */
export async function cargarConversacion(bienId: string): Promise<PantallaConversacion> {
  const sesion = await obtenerUsuarioActual();
  if (sesion.estado === "sin-sesion") return { tipo: "sin-sesion" };
  if (sesion.estado === "error") throw new ErrorDeCarga("auth/me", 0);
  const { usuario } = sesion;

  if (usuario.rol !== "ARRENDATARIO") return { tipo: "sin-permiso", usuario };
  if (!ID_BIEN.test(bienId)) return { tipo: "no-encontrada", usuario };

  const [apertura, bien] = await Promise.all([
    llamarApi(`bienes/${bienId}/conversacion`, { method: "POST" }),
    llamarApi(`bienes/${bienId}`),
  ]);

  if (apertura.status === 401) return { tipo: "sin-sesion" };
  if (apertura.status === 403) return { tipo: "sin-permiso", usuario };
  if (apertura.status === 404 || apertura.status === 400) return { tipo: "no-encontrada", usuario };
  if (apertura.status === 422) return { tipo: "inactiva", usuario };
  const conversacion =
    apertura.status === 200 || apertura.status === 201 ? leerConversacion(apertura.datos) : null;
  if (!conversacion) throw new ErrorDeCarga("bienes/:bienId/conversacion", apertura.status);

  // El detalle público solo muestra publicaciones ACTIVA: un 404 aquí, con la
  // conversación ya abierta, es que dejó de estar activa entre las dos llamadas.
  if (bien.status === 404) return { tipo: "inactiva", usuario };
  const publicacion = bien.status === 200 ? leerPublicacion(bien.datos, bienId) : null;
  if (!publicacion) throw new ErrorDeCarga("bienes/:bienId", bien.status);

  const historial = await llamarApi(`conversaciones/${conversacion.id}/mensajes?orden=asc`);
  if (historial.status === 401) return { tipo: "sin-sesion" };
  if (historial.status === 403) return { tipo: "sin-permiso", usuario };
  if (historial.status === 404) return { tipo: "no-encontrada", usuario };
  const mensajes = historial.status === 200 ? leerHistorial(historial.datos) : null;
  if (!mensajes) throw new ErrorDeCarga("conversaciones/:id/mensajes", historial.status);

  return {
    tipo: "lista",
    usuario,
    datos: { conversacionId: conversacion.id, publicacion, arrendador: conversacion.arrendador, mensajes },
  };
}
