import { render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { ResumenPublicacion, TarjetaPublicacion } from "../tarjeta-publicacion";

const publicacion = { id: "b1", titulo: "Salón de eventos Las Palmas", precio: "$80.00 / día", foto: null };

describe("miniaturas de la consulta previa sin foto", () => {
  it("el resumen móvil (56 px) usa la variante compacta: solo el ícono", () => {
    render(<ResumenPublicacion publicacion={publicacion} arrendador="mariana_rivas" />);
    expect(screen.getByText("Foto no disponible")).toHaveClass("sr-only");
    expect(screen.getByText("Consulta · mariana_rivas")).toBeInTheDocument();
  });

  it("la tarjeta de escritorio conserva el reemplazo con texto visible", () => {
    render(<TarjetaPublicacion publicacion={publicacion} arrendador="mariana_rivas" />);
    expect(screen.getByText("Foto no disponible")).not.toHaveClass("sr-only");
  });

  it("con foto, el resumen móvil muestra la imagen", () => {
    render(<ResumenPublicacion publicacion={{ ...publicacion, foto: "/uploads/bienes/principal.jpg" }} arrendador="mariana_rivas" />);
    expect(screen.getByRole("img", { name: "Salón de eventos Las Palmas" })).toBeInTheDocument();
    expect(screen.queryByText("Foto no disponible")).not.toBeInTheDocument();
  });
});
