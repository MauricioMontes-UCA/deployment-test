import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";
import ErrorAlCargar from "../error";
import Cargando from "../loading";

describe("estados de carga", () => {
  it("error.tsx: aviso y «Reintentar» llama a retry", async () => {
    const retry = vi.fn();
    render(<ErrorAlCargar error={new Error("x")} retry={retry} />);
    expect(screen.getByRole("alert")).toHaveTextContent("No pudimos cargar la conversación");
    await userEvent.click(screen.getByRole("button", { name: "Reintentar" }));
    expect(retry).toHaveBeenCalledOnce();
  });

  it("loading.tsx: estado de carga anunciado", () => {
    render(<Cargando />);
    expect(screen.getByRole("status")).toHaveTextContent("Cargando la conversación…");
  });
});
