import { render, screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, describe, expect, it, vi } from "vitest";
import type { PantallaConversacion } from "../datos";

const datos = vi.hoisted(() => ({ cargarConversacion: vi.fn() }));
vi.mock("../datos", () => datos);

const accion = vi.hoisted(() => ({ enviarMensaje: vi.fn() }));
vi.mock("@/app/actions/conversacion", () => accion);

const auth = vi.hoisted(() => ({ cerrarSesion: vi.fn() }));
vi.mock("@/app/actions/auth", () => auth);

vi.mock("next/navigation", async (importOriginal) => ({
  ...(await importOriginal<typeof import("next/navigation")>()),
  redirect: vi.fn((url: string) => {
    throw new Error(`REDIRECT:${url}`);
  }),
}));

const { default: ConsultaPreviaPage } = await import("../page");

const BIEN = "7c9e6679-7425-40de-944b-e07fc1f90ae7";
const CONVERSACION = "0b6c7d8e-1f2a-4b3c-8d4e-5f6a7b8c9d0e";
// Con todos los campos de UsuarioActual (develop agregó email y createdAt en AF-99).
const usuario = {
  id: "u1",
  nombreUsuario: "ana_m",
  email: "ana@example.com",
  rol: "ARRENDATARIO",
  createdAt: "2026-11-01T00:00:00.000Z",
} as const;

const datosLista = {
  conversacionId: CONVERSACION,
  arrendador: "mariana_rivas",
  publicacion: {
    id: BIEN,
    titulo: "Salón de eventos Las Palmas",
    precio: "$80.00 / día",
    foto: "/uploads/bienes/principal.jpg",
  },
  mensajes: [
    {
      id: "m1",
      remitente: { id: "u1", nombreUsuario: "ana_m" },
      contenido: "Hola, ¿el salón incluye mesas y sillas?",
      creadoEn: "2026-11-05T16:32:00.000Z",
    },
  ],
};

async function renderizar(pantalla: PantallaConversacion, bienId = BIEN) {
  datos.cargarConversacion.mockResolvedValue(pantalla);
  render(
    await ConsultaPreviaPage({
      params: Promise.resolve({ bienId }),
    } as PageProps<"/publicaciones/[bienId]/conversacion">),
  );
}

afterEach(() => {
  vi.clearAllMocks();
});

describe("ConsultaPreviaPage", () => {
  it("lista: encabezado, publicación, arrendador, enlaces y conversación", async () => {
    await renderizar({ tipo: "lista", usuario, datos: datosLista });

    expect(datos.cargarConversacion).toHaveBeenCalledWith(BIEN);
    expect(screen.getByRole("heading", { level: 1, name: "Conversación con mariana_rivas" })).toBeInTheDocument();
    expect(screen.getByText("Consulta previa")).toBeInTheDocument();

    const tarjeta = screen.getByRole("article", { name: "Salón de eventos Las Palmas" });
    expect(within(tarjeta).getByText("Publicación")).toBeInTheDocument();
    expect(within(tarjeta).getByText("$80.00 / día")).toBeInTheDocument();
    expect(within(tarjeta).getByText("Arrendador: mariana_rivas")).toBeInTheDocument();
    expect(within(tarjeta).getByText("Activa")).toBeInTheDocument();
    expect(within(tarjeta).getByRole("link", { name: "Ver publicación" })).toHaveAttribute("href", `/bienes/${BIEN}`);
    expect(within(tarjeta).getByRole("link", { name: "Ver disponibilidad" })).toHaveAttribute("href", `/bienes/${BIEN}`);
    expect(within(tarjeta).getByRole("img", { name: "Salón de eventos Las Palmas" })).toBeInTheDocument();

    // Resumen móvil: título enlazado y «Consulta · arrendador».
    expect(screen.getByText("Consulta · mariana_rivas")).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "Salón de eventos Las Palmas" })).toHaveAttribute("href", `/bienes/${BIEN}`);

    expect(screen.getByRole("log", { name: "Historial de mensajes" })).toHaveTextContent("Hola, ¿el salón incluye mesas y sillas?");
    expect(screen.getByRole("button", { name: "Enviar mensaje" })).toBeInTheDocument();
    expect(screen.getAllByText("ana_m").length).toBeGreaterThan(0);
  });

  it("M1: el h1 se oculta en móvil desde un contenedor propio, sin `sr-only` en el <header> de ancho completo", async () => {
    await renderizar({ tipo: "lista", usuario, datos: datosLista });
    const encabezado = screen.getByRole("heading", { level: 1 }).closest("header")!;

    // El <header> trae `w-full`: con `sr-only` encima, desbordaba la página 16 px a 360 px.
    expect(encabezado).toHaveClass("w-full");
    expect(encabezado).not.toHaveClass("sr-only");
    expect(encabezado.className).not.toMatch(/not-sr-only/);
    // Lo oculta (solo visualmente) un contenedor sin ancho propio, y se muestra desde lg.
    const contenedor = encabezado.parentElement!;
    expect(contenedor.tagName).toBe("DIV");
    expect(contenedor.className.split(/\s+/).sort()).toEqual(["lg:not-sr-only", "sr-only"]);
    // Sigue en el árbol accesible y con el sobretítulo.
    expect(within(encabezado).getByText("Consulta previa")).toBeInTheDocument();
  });

  it("B2: el resumen móvil usa «Título/H4» y «Etiqueta/Pequeña» como en Figma 30:509", async () => {
    await renderizar({ tipo: "lista", usuario, datos: datosLista });
    const consulta = screen.getByText("Consulta · mariana_rivas");
    expect(consulta).toHaveClass("texto-etiqueta-pequena");
    expect(consulta).not.toHaveClass("texto-cuerpo-pequeno");
    const titulo = screen.getByRole("link", { name: "Salón de eventos Las Palmas" }).closest("h2")!;
    expect(titulo).toHaveClass("texto-h4");
    expect(titulo).not.toHaveClass("texto-cuerpo-medio");
  });

  it("la acción de envío lleva aplicado el id de la conversación", async () => {
    accion.enviarMensaje.mockResolvedValue({ ok: false, status: 500 });
    await renderizar({ tipo: "lista", usuario, datos: datosLista });
    await userEvent.type(screen.getByRole("textbox", { name: /Mensaje/ }), "¿Hay parqueo?");
    await userEvent.click(screen.getByRole("button", { name: "Enviar mensaje" }));
    await screen.findByRole("alert");
    expect(accion.enviarMensaje).toHaveBeenCalledWith(CONVERSACION, "¿Hay parqueo?");
  });

  it("sin sesión o sesión rechazada → /sesion-vencida", async () => {
    await expect(renderizar({ tipo: "sin-sesion" })).rejects.toThrow("REDIRECT:/sesion-vencida");
  });

  it("sin permiso (otro rol o no participa): estado sin permiso y sin formulario ni mensajes", async () => {
    await renderizar({ tipo: "sin-permiso", usuario: { ...usuario, rol: "ARRENDADOR" } });
    expect(screen.getByRole("heading", { name: "No tienes permiso para ver esta conversación." })).toBeInTheDocument();
    expect(screen.queryByRole("log")).not.toBeInTheDocument();
    expect(screen.queryByRole("textbox")).not.toBeInTheDocument();
    expect(screen.getByRole("link", { name: "Volver a la búsqueda" })).toHaveAttribute("href", "/buscar");
  });

  it("publicación inexistente: estado no encontrado", async () => {
    await renderizar({ tipo: "no-encontrada", usuario });
    expect(screen.getByRole("heading", { name: "No encontramos esa publicación." })).toBeInTheDocument();
    expect(screen.queryByRole("textbox")).not.toBeInTheDocument();
  });

  it("publicación inactiva: el estado de Figma con «Volver a la búsqueda» y sin formulario", async () => {
    await renderizar({ tipo: "inactiva", usuario });
    expect(screen.getByRole("heading", { name: "Esta publicación ya no está disponible." })).toBeInTheDocument();
    expect(screen.getByText("Solo se pueden enviar consultas sobre publicaciones activas.")).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "Volver a la búsqueda" })).toHaveAttribute("href", "/buscar");
    expect(screen.queryByRole("textbox")).not.toBeInTheDocument();
    expect(screen.queryByRole("heading", { level: 1 })).not.toBeInTheDocument();
  });

  it("un error de carga se propaga a error.tsx", async () => {
    datos.cargarConversacion.mockRejectedValue(new Error("caído"));
    await expect(
      ConsultaPreviaPage({ params: Promise.resolve({ bienId: BIEN }) } as PageProps<"/publicaciones/[bienId]/conversacion">),
    ).rejects.toThrow("caído");
  });
});
