import { afterEach, describe, expect, it, vi } from "vitest";
import type { RespuestaApiCruda } from "@/lib/api";
import type { ResultadoUsuario } from "@/lib/usuario-actual";

const api = vi.hoisted(() => ({ llamarApi: vi.fn() }));
vi.mock("@/lib/api", () => api);
const sesion = vi.hoisted(() => ({ obtenerUsuarioActual: vi.fn() }));
vi.mock("@/lib/usuario-actual", () => sesion);

const { cargarConversacion, ErrorDeCarga } = await import("../datos");

const BIEN = "7c9e6679-7425-40de-944b-e07fc1f90ae7";
const CONVERSACION = "0b6c7d8e-1f2a-4b3c-8d4e-5f6a7b8c9d0e";

const usuario = (rol: "ARRENDATARIO" | "ARRENDADOR" | "ADMINISTRADOR" = "ARRENDATARIO"): ResultadoUsuario =>
  ({ estado: "ok", usuario: { id: "u1", nombreUsuario: "ana_m", rol } }) as ResultadoUsuario;
const cruda = (status: number, datos: unknown = null): RespuestaApiCruda => ({ status, datos, mensajes: [] });

const conversacionApi = (status = 201) =>
  cruda(status, {
    id: CONVERSACION,
    bienId: BIEN,
    arrendador: { id: "u2", nombreUsuario: "mariana_rivas" },
    arrendatario: { id: "u1", nombreUsuario: "ana_m" },
    creadaEn: "2026-11-05T16:30:00.000Z",
  });

const bienApi = (cambios: Record<string, unknown> = {}) =>
  cruda(200, {
    id: BIEN,
    titulo: "Salón de eventos Las Palmas",
    precio: 80,
    unidadCobro: "DIA",
    arrendador: { id: "u2", nombreUsuario: "mariana_rivas" },
    fotos: [
      { url: "/uploads/bienes/principal.jpg", orden: 0, esPrincipal: true },
      { url: "/uploads/bienes/otra.jpg", orden: 1, esPrincipal: false },
    ],
    ...cambios,
  });

const mensaje = (id: string, remitenteId: string, creadoEn: string) => ({
  id,
  conversacionId: CONVERSACION,
  remitente: { id: remitenteId, nombreUsuario: remitenteId === "u1" ? "ana_m" : "mariana_rivas" },
  contenido: `Mensaje ${id}`,
  creadoEn,
});

const historialApi = (mensajes: unknown[] = []) =>
  cruda(200, { conversacionId: CONVERSACION, orden: "asc", mensajes });

/** Responde según la ruta, como el backend. */
function responder({
  sesionResultado = usuario(),
  apertura = conversacionApi(),
  bien = bienApi(),
  historial = historialApi(),
}: {
  sesionResultado?: ResultadoUsuario;
  apertura?: RespuestaApiCruda;
  bien?: RespuestaApiCruda;
  historial?: RespuestaApiCruda;
} = {}) {
  sesion.obtenerUsuarioActual.mockResolvedValue(sesionResultado);
  api.llamarApi.mockImplementation(async (ruta: string) => {
    if (ruta === `bienes/${BIEN}/conversacion`) return apertura;
    if (ruta === `bienes/${BIEN}`) return bien;
    if (ruta === `conversaciones/${CONVERSACION}/mensajes?orden=asc`) return historial;
    throw new Error(`ruta inesperada: ${ruta}`);
  });
}

afterEach(() => {
  vi.resetAllMocks();
});

describe("cargarConversacion", () => {
  it("201: abre la conversación, lee el bien y el historial con las rutas del contrato", async () => {
    responder();
    const pantalla = await cargarConversacion(BIEN);

    expect(api.llamarApi).toHaveBeenCalledWith(`bienes/${BIEN}/conversacion`, { method: "POST" });
    expect(api.llamarApi).toHaveBeenCalledWith(`bienes/${BIEN}`);
    expect(api.llamarApi).toHaveBeenCalledWith(`conversaciones/${CONVERSACION}/mensajes?orden=asc`);
    expect(pantalla).toEqual({
      tipo: "lista",
      usuario: { id: "u1", nombreUsuario: "ana_m", rol: "ARRENDATARIO" },
      datos: {
        conversacionId: CONVERSACION,
        arrendador: "mariana_rivas",
        publicacion: {
          id: BIEN,
          titulo: "Salón de eventos Las Palmas",
          precio: "$80.00 / día",
          foto: "/uploads/bienes/principal.jpg",
        },
        mensajes: [],
      },
    });
  });

  it("200: recupera la conversación existente y su historial", async () => {
    responder({
      apertura: conversacionApi(200),
      historial: historialApi([
        mensaje("m1", "u1", "2026-11-05T16:32:00.000Z"),
        mensaje("m2", "u2", "2026-11-05T16:40:00.000Z"),
      ]),
    });
    const pantalla = await cargarConversacion(BIEN);
    expect(pantalla.tipo).toBe("lista");
    if (pantalla.tipo !== "lista") return;
    expect(pantalla.datos.conversacionId).toBe(CONVERSACION);
    expect(pantalla.datos.mensajes.map((m) => m.id)).toEqual(["m1", "m2"]);
  });

  it("el historial queda en orden cronológico aunque el backend lo mande desordenado", async () => {
    responder({
      historial: historialApi([
        mensaje("m3", "u1", "2026-11-05T16:42:00.000Z"),
        mensaje("m1", "u1", "2026-11-05T16:32:00.000Z"),
        mensaje("m2", "u2", "2026-11-05T16:40:00.000Z"),
      ]),
    });
    const pantalla = await cargarConversacion(BIEN);
    if (pantalla.tipo !== "lista") throw new Error(pantalla.tipo);
    expect(pantalla.datos.mensajes.map((m) => m.id)).toEqual(["m1", "m2", "m3"]);
  });

  it("sin foto principal marcada usa la primera; sin fotos, null", async () => {
    responder({ bien: bienApi({ fotos: [{ url: "/uploads/bienes/a.jpg", orden: 0, esPrincipal: false }] }) });
    let pantalla = await cargarConversacion(BIEN);
    if (pantalla.tipo !== "lista") throw new Error(pantalla.tipo);
    expect(pantalla.datos.publicacion.foto).toBe("/uploads/bienes/a.jpg");

    responder({ bien: bienApi({ fotos: [] }) });
    pantalla = await cargarConversacion(BIEN);
    if (pantalla.tipo !== "lista") throw new Error(pantalla.tipo);
    expect(pantalla.datos.publicacion.foto).toBeNull();
  });

  describe("acceso por rol", () => {
    it.each(["ARRENDADOR", "ADMINISTRADOR"] as const)("%s → sin permiso, sin abrir conversación", async (rol) => {
      responder({ sesionResultado: usuario(rol) });
      expect(await cargarConversacion(BIEN)).toEqual({ tipo: "sin-permiso", usuario: { id: "u1", nombreUsuario: "ana_m", rol } });
      expect(api.llamarApi).not.toHaveBeenCalled();
    });

    it("sin sesión → sin-sesion, sin llamar al backend", async () => {
      responder({ sesionResultado: { estado: "sin-sesion" } });
      expect(await cargarConversacion(BIEN)).toEqual({ tipo: "sin-sesion" });
      expect(api.llamarApi).not.toHaveBeenCalled();
    });

    it("/auth/me falla → ErrorDeCarga", async () => {
      responder({ sesionResultado: { estado: "error" } });
      await expect(cargarConversacion(BIEN)).rejects.toBeInstanceOf(ErrorDeCarga);
    });
  });

  it("un bienId que no es UUID → no encontrada, sin llamar al backend", async () => {
    responder();
    expect((await cargarConversacion("abc")).tipo).toBe("no-encontrada");
    expect(api.llamarApi).not.toHaveBeenCalled();
  });

  describe("errores al abrir la conversación", () => {
    it.each([
      [401, "sin-sesion"],
      [403, "sin-permiso"],
      [404, "no-encontrada"],
      [400, "no-encontrada"],
      [422, "inactiva"],
    ])("%i → %s, sin pedir mensajes", async (status, tipo) => {
      responder({ apertura: cruda(status, { message: "x" }) });
      expect((await cargarConversacion(BIEN)).tipo).toBe(tipo);
      expect(api.llamarApi).not.toHaveBeenCalledWith(expect.stringContaining("conversaciones/"));
    });

    it.each([409, 500, 0])("%i → ErrorDeCarga", async (status) => {
      responder({ apertura: cruda(status) });
      await expect(cargarConversacion(BIEN)).rejects.toBeInstanceOf(ErrorDeCarga);
    });

    it.each([
      ["sin id", { arrendador: { nombreUsuario: "x" } }],
      ["id que no es UUID", { id: "1", arrendador: { nombreUsuario: "x" } }],
      ["sin arrendador", { id: CONVERSACION }],
      ["cuerpo nulo", null],
    ])("200/201 con cuerpo inesperado (%s) → ErrorDeCarga", async (_caso, cuerpo) => {
      responder({ apertura: cruda(201, cuerpo) });
      await expect(cargarConversacion(BIEN)).rejects.toBeInstanceOf(ErrorDeCarga);
    });
  });

  describe("errores de la publicación", () => {
    it("404 con la conversación abierta → inactiva (dejó de estar activa entre las llamadas)", async () => {
      responder({ bien: cruda(404) });
      expect((await cargarConversacion(BIEN)).tipo).toBe("inactiva");
    });

    it.each([
      ["500", cruda(500)],
      ["sin respuesta", cruda(0)],
      ["precio como texto", bienApi({ precio: "80" })],
      ["unidad desconocida", bienApi({ unidadCobro: "MES" })],
      ["sin título", bienApi({ titulo: undefined })],
      ["fotos no es lista", bienApi({ fotos: "x" })],
    ])("%s → ErrorDeCarga", async (_caso, bien) => {
      responder({ bien });
      await expect(cargarConversacion(BIEN)).rejects.toBeInstanceOf(ErrorDeCarga);
    });
  });

  describe("errores del historial", () => {
    it.each([
      [401, "sin-sesion"],
      [403, "sin-permiso"],
      [404, "no-encontrada"],
    ])("%i → %s", async (status, tipo) => {
      responder({ historial: cruda(status) });
      expect((await cargarConversacion(BIEN)).tipo).toBe(tipo);
    });

    it.each([
      ["500", cruda(500)],
      ["sin respuesta", cruda(0)],
      ["sin lista", cruda(200, { mensajes: null })],
      ["un mensaje ilegible", historialApi([{ id: "roto" }])],
    ])("%s → ErrorDeCarga", async (_caso, historial) => {
      responder({ historial });
      await expect(cargarConversacion(BIEN)).rejects.toBeInstanceOf(ErrorDeCarga);
    });
  });
});
