import { fireEvent, render, screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { redirect } from "next/navigation";
import { Component, type ReactNode } from "react";
import { afterEach, beforeEach, describe, expect, it, vi, type MockInstance } from "vitest";
import type { ResultadoEnvioMensaje } from "@/app/actions/conversacion";
import type { MensajeConversacion } from "@/lib/mensajes";
import { ConversacionPrevia } from "../conversacion-previa";

const INVALIDO = "El mensaje debe contener entre 1 y 1000 caracteres";
const ERROR_ENVIO = "No se pudo enviar el mensaje";

const ANA = { id: "u1", nombreUsuario: "ana_m" };
const MARIANA = { id: "u2", nombreUsuario: "mariana_rivas" };

const mensaje = (
  id: string,
  remitente: typeof ANA,
  contenido: string,
  creadoEn = "2026-11-05T16:32:00.000Z",
): MensajeConversacion => ({ id, remitente, contenido, creadoEn });

const HISTORIAL = [
  mensaje("m1", ANA, "Hola, ¿el salón incluye mesas y sillas?", "2026-11-05T16:32:00.000Z"),
  mensaje("m2", MARIANA, "Sí, incluye mesas y sillas para 100 invitados.", "2026-11-05T16:40:00.000Z"),
];

// Ninguna prueba debe dejar advertencias de React en la consola.
let errorDeConsola: MockInstance<typeof console.error>;
beforeEach(() => {
  errorDeConsola = vi.spyOn(console, "error");
});
afterEach(() => {
  expect(errorDeConsola).not.toHaveBeenCalled();
  errorDeConsola.mockRestore();
});

type Enviar = (contenido: string) => Promise<ResultadoEnvioMensaje>;

function renderizar({
  enviar = vi.fn<Enviar>(),
  mensajes = HISTORIAL,
}: { enviar?: Enviar; mensajes?: MensajeConversacion[] } = {}) {
  render(<ConversacionPrevia usuario={ANA} arrendador="mariana_rivas" mensajesIniciales={mensajes} enviar={enviar} />);
  return enviar;
}

/** Promesa que la prueba resuelve cuando quiere, para ver el estado «enviando». */
function diferido() {
  let resolver!: (resultado: ResultadoEnvioMensaje) => void;
  let rechazar!: (error: unknown) => void;
  const promesa = new Promise<ResultadoEnvioMensaje>((r, e) => {
    resolver = r;
    rechazar = e;
  });
  return { promesa, resolver, rechazar };
}

const campo = () => screen.getByRole("textbox", { name: /Mensaje/ });
const botonEnviar = () => screen.getByRole("button", { name: /Enviar mensaje|Procesando/ });
const historial = () => screen.getByRole("log", { name: "Historial de mensajes" });

/** Escribe sin pasar por el teclado simulado (más rápido para textos largos). */
const escribir = (texto: string) => fireEvent.change(campo(), { target: { value: texto } });

describe("ConversacionPrevia", () => {
  describe("historial", () => {
    it("vacío: muestra el estado de Figma y el contador en 0/1000", () => {
      renderizar({ mensajes: [] });
      expect(within(historial()).getByText("Aún no hay mensajes")).toBeInTheDocument();
      expect(within(historial()).getByText("Escribe tu primera pregunta sobre esta publicación.")).toBeInTheDocument();
      expect(screen.getByText("0/1000")).toBeInTheDocument();
    });

    it("con mensajes: los muestra en orden, con autor y fecha local, sin estado vacío", () => {
      renderizar();
      const textos = within(historial())
        .getAllByText(/Hola, ¿el salón|Sí, incluye/)
        .map((nodo) => nodo.textContent);
      expect(textos).toEqual(["Hola, ¿el salón incluye mesas y sillas?", "Sí, incluye mesas y sillas para 100 invitados."]);
      expect(screen.getByText("ana_m · 05/11/2026 10:32")).toBeInTheDocument();
      expect(screen.getByText("mariana_rivas · 05/11/2026 10:40")).toBeInTheDocument();
      expect(screen.queryByText("Aún no hay mensajes")).not.toBeInTheDocument();
    });

    it("los propios van a la derecha (acento) y los del arrendador a la izquierda (con borde)", () => {
      renderizar();
      const propio = screen.getByText("ana_m · 05/11/2026 10:32").parentElement!;
      const ajeno = screen.getByText("mariana_rivas · 05/11/2026 10:40").parentElement!;
      expect(propio).toHaveClass("self-end", "bg-fondo-acento");
      expect(ajeno).toHaveClass("self-start", "border");
      expect(ajeno).not.toHaveClass("bg-fondo-acento");
    });

    it("conserva saltos de línea y no interpreta HTML", () => {
      renderizar({ mensajes: [mensaje("m1", MARIANA, "Línea 1\nLínea 2 <b>no</b>")] });
      const parrafo = within(historial()).getByText(/Línea 1/);
      expect(parrafo).toHaveClass("whitespace-pre-wrap");
      expect(parrafo.textContent).toBe("Línea 1\nLínea 2 <b>no</b>");
      expect(parrafo.querySelector("b")).toBeNull();
    });
  });

  describe("validación", () => {
    it("vacío: muestra el error al enviar, no llama al backend y enfoca el campo", async () => {
      const enviar = renderizar();
      await userEvent.click(botonEnviar());
      expect(screen.getByText(INVALIDO)).toBeInTheDocument();
      expect(campo()).toHaveAttribute("aria-invalid", "true");
      expect(campo()).toHaveFocus();
      expect(enviar).not.toHaveBeenCalled();
    });

    it("no muestra el error antes de intentar enviar", () => {
      renderizar();
      expect(screen.queryByText(INVALIDO)).not.toBeInTheDocument();
      expect(campo()).not.toHaveAttribute("aria-invalid");
    });

    it("solo espacios y saltos de línea: rechazado", async () => {
      const enviar = renderizar();
      escribir("   \n\t ");
      await userEvent.click(botonEnviar());
      expect(screen.getByText(INVALIDO)).toBeInTheDocument();
      expect(enviar).not.toHaveBeenCalled();
    });

    it("el error se va al corregir el texto", async () => {
      renderizar();
      await userEvent.click(botonEnviar());
      await userEvent.type(campo(), "Hola");
      expect(screen.queryByText(INVALIDO)).not.toBeInTheDocument();
    });

    it("1000 caracteres: válido, contador 1000/1000 y se envía", async () => {
      const enviar = renderizar({ enviar: vi.fn<Enviar>(async () => ({ ok: true, mensaje: null })) });
      escribir("a".repeat(1000));
      expect(screen.getByText("1000/1000")).toBeInTheDocument();
      expect(screen.queryByText(INVALIDO)).not.toBeInTheDocument();
      await userEvent.click(botonEnviar());
      expect(enviar).toHaveBeenCalledWith("a".repeat(1000));
    });

    it("1001 caracteres: error mientras se escribe (sin cortar el texto) y no se envía", async () => {
      const enviar = renderizar();
      escribir("a".repeat(1001));
      expect(screen.getByText("1001/1000")).toBeInTheDocument();
      expect(screen.getByText(INVALIDO)).toBeInTheDocument();
      expect(campo()).toHaveValue("a".repeat(1001));
      expect(campo()).not.toHaveAttribute("maxLength");
      await userEvent.click(botonEnviar());
      expect(enviar).not.toHaveBeenCalled();
    });

    it("emojis y Unicode cuentan como 1 cada uno, como en el backend", async () => {
      const enviar = renderizar({ enviar: vi.fn<Enviar>(async () => ({ ok: true, mensaje: null })) });
      escribir("¿Mañana? 😀🎉");
      expect(screen.getByText("11/1000")).toBeInTheDocument();

      escribir("😀".repeat(1000));
      expect(screen.getByText("1000/1000")).toBeInTheDocument();
      expect(screen.queryByText(INVALIDO)).not.toBeInTheDocument();
      await userEvent.click(botonEnviar());
      expect(enviar).toHaveBeenCalledWith("😀".repeat(1000));
    });

    it("1001 emojis: inválido", () => {
      renderizar();
      escribir("😀".repeat(1001));
      expect(screen.getByText("1001/1000")).toBeInTheDocument();
      expect(screen.getByText(INVALIDO)).toBeInTheDocument();
    });
  });

  describe("envío", () => {
    it("envía el texto original sin recortar", async () => {
      const enviar = renderizar({ enviar: vi.fn<Enviar>(async () => ({ ok: true, mensaje: null })) });
      escribir("  Hola  \n");
      await userEvent.click(botonEnviar());
      expect(enviar).toHaveBeenCalledWith("  Hola  \n");
    });

    it("mientras se envía: burbuja «enviando…» distinta, botón «Procesando…» y campo de solo lectura", async () => {
      const { promesa, resolver } = diferido();
      renderizar({ enviar: vi.fn<Enviar>(() => promesa) });
      escribir("¿Tiene parqueo?");
      await userEvent.click(botonEnviar());

      const etiquetaPendiente = await screen.findByText("ana_m · enviando…");
      const burbuja = etiquetaPendiente.parentElement!;
      expect(burbuja).toHaveClass("opacity-70");
      expect(within(burbuja).getByText("¿Tiene parqueo?")).toBeInTheDocument();
      expect(botonEnviar()).toBeDisabled();
      expect(botonEnviar()).toHaveTextContent("Procesando…");
      expect(campo()).toHaveAttribute("readonly");
      expect(campo()).toHaveValue("¿Tiene parqueo?");
      // No se marca como enviado antes del 201: no hay fecha ni burbuja definitiva.
      expect(screen.getAllByText(/^ana_m · \d{2}\/\d{2}\/\d{4} \d{2}:\d{2}$/)).toHaveLength(1); // solo m1
      expect(within(historial()).getAllByText("¿Tiene parqueo?")).toHaveLength(1);

      resolver({ ok: false, status: 500 });
      await screen.findByText(ERROR_ENVIO);
    });

    it("con 201: reemplaza la burbuja pendiente por el mensaje real del backend y limpia el campo", async () => {
      const real = mensaje("m3", ANA, "¿Tiene parqueo?", "2026-11-05T16:50:00.000Z");
      const { promesa, resolver } = diferido();
      renderizar({ enviar: vi.fn<Enviar>(() => promesa) });
      escribir("¿Tiene parqueo?");
      await userEvent.click(botonEnviar());
      await screen.findByText("ana_m · enviando…");

      resolver({ ok: true, mensaje: real });

      expect(await screen.findByText("ana_m · 05/11/2026 10:50")).toBeInTheDocument();
      expect(screen.queryByText("ana_m · enviando…")).not.toBeInTheDocument();
      expect(campo()).toHaveValue("");
      expect(screen.getByText("0/1000")).toBeInTheDocument();
      expect(campo()).not.toHaveAttribute("readonly");
      expect(campo()).toHaveFocus();
      expect(botonEnviar()).toHaveTextContent("Enviar mensaje");
      // Queda al final del historial.
      const ultimo = within(historial()).getAllByText(/ · /).at(-1);
      expect(ultimo).toHaveTextContent("ana_m · 05/11/2026 10:50");
    });

    it("desde el estado vacío, el primer mensaje reemplaza el aviso «Aún no hay mensajes»", async () => {
      const real = mensaje("m1", ANA, "Primera pregunta");
      renderizar({ mensajes: [], enviar: vi.fn<Enviar>(async () => ({ ok: true, mensaje: real })) });
      escribir("Primera pregunta");
      await userEvent.click(botonEnviar());
      expect(await within(historial()).findByText("Primera pregunta")).toBeInTheDocument();
      expect(screen.queryByText("Aún no hay mensajes")).not.toBeInTheDocument();
    });

    it("un 201 ilegible no inventa el mensaje: limpia el campo y avisa que recargue", async () => {
      renderizar({ enviar: vi.fn<Enviar>(async () => ({ ok: true, mensaje: null })) });
      escribir("Hola");
      await userEvent.click(botonEnviar());
      expect(await screen.findByRole("status")).toHaveTextContent("Tu mensaje se envió. Recarga la página para verlo en el historial.");
      expect(within(historial()).queryByText("Hola")).not.toBeInTheDocument();
      expect(campo()).toHaveValue("");
    });

    it("doble envío: dos clics y un Enter seguidos llaman una sola vez", async () => {
      const { promesa, resolver } = diferido();
      const enviar = renderizar({ enviar: vi.fn<Enviar>(() => promesa) });
      escribir("Hola");
      const formulario = campo().closest("form")!;
      fireEvent.submit(formulario);
      fireEvent.submit(formulario);
      fireEvent.click(botonEnviar());
      expect(enviar).toHaveBeenCalledTimes(1);

      resolver({ ok: true, mensaje: mensaje("m3", ANA, "Hola") });
      await within(historial()).findByText("Hola");
      expect(enviar).toHaveBeenCalledTimes(1);
    });

    it("después de terminar un envío se puede enviar otro", async () => {
      let n = 0;
      const enviar = renderizar({
        enviar: vi.fn<Enviar>(async (contenido) => ({ ok: true, mensaje: mensaje(`n${++n}`, ANA, contenido) })),
      });
      escribir("Uno");
      await userEvent.click(botonEnviar());
      await within(historial()).findByText("Uno");
      escribir("Dos");
      await userEvent.click(botonEnviar());
      await within(historial()).findByText("Dos");
      expect(enviar).toHaveBeenCalledTimes(2);
    });
  });

  describe("errores", () => {
    it.each([
      ["500", { ok: false, status: 500 } as const],
      ["403", { ok: false, status: 403 } as const],
      ["404", { ok: false, status: 404 } as const],
      ["400", { ok: false, status: 400 } as const],
      ["red o tiempo agotado", { ok: false, status: null } as const],
    ])("%s: muestra «No se pudo enviar el mensaje», conserva el texto y quita la burbuja", async (_caso, resultado) => {
      renderizar({ enviar: vi.fn<Enviar>(async () => resultado) });
      escribir("  ¿Tiene parqueo? 🚗");
      await userEvent.click(botonEnviar());

      const alerta = await screen.findByRole("alert");
      expect(alerta).toHaveTextContent(/^No se pudo enviar el mensaje$/);
      expect(campo()).toHaveValue("  ¿Tiene parqueo? 🚗");
      expect(campo()).not.toHaveAttribute("readonly");
      expect(campo()).toHaveFocus();
      expect(screen.queryByText("ana_m · enviando…")).not.toBeInTheDocument();
      expect(within(historial()).queryByText(/Tiene parqueo/)).not.toBeInTheDocument();
      expect(botonEnviar()).toBeEnabled();
    });

    it("la acción rechaza con una excepción (fallo de red del cliente): mismo aviso, texto conservado", async () => {
      renderizar({ enviar: vi.fn<Enviar>(async () => Promise.reject(new TypeError("Failed to fetch"))) });
      escribir("Hola");
      await userEvent.click(botonEnviar());
      expect(await screen.findByRole("alert")).toHaveTextContent(ERROR_ENVIO);
      expect(campo()).toHaveValue("Hola");
    });

    it("el aviso va arriba del campo y se reintenta con el mismo texto; con éxito desaparece", async () => {
      const enviar = vi
        .fn<Enviar>()
        .mockResolvedValueOnce({ ok: false, status: 500 })
        .mockResolvedValueOnce({ ok: true, mensaje: mensaje("m3", ANA, "Reintento", "2026-11-05T16:55:00.000Z") });
      renderizar({ enviar });
      escribir("Reintento");
      await userEvent.click(botonEnviar());
      const alerta = await screen.findByRole("alert");
      expect(alerta.compareDocumentPosition(campo()) & Node.DOCUMENT_POSITION_FOLLOWING).toBeTruthy();

      await userEvent.click(botonEnviar());
      await screen.findByText("ana_m · 05/11/2026 10:55");
      expect(enviar).toHaveBeenNthCalledWith(2, "Reintento");
      expect(screen.queryByRole("alert")).not.toBeInTheDocument();
    });

    it("401: el redirect de la acción sigue su curso y no se muestra como error de envío", async () => {
      class Limite extends Component<{ children: ReactNode }, { error: unknown }> {
        state = { error: null };
        static getDerivedStateFromError(error: unknown) {
          return { error };
        }
        render() {
          return this.state.error ? <p>Redirigiendo: {String((this.state.error as Error).message)}</p> : this.props.children;
        }
      }
      // React informa en consola el error que captura un límite: aquí es esperado.
      errorDeConsola.mockImplementation(() => {});
      const enviar = vi.fn<Enviar>(async () => redirect("/sesion-vencida"));
      render(
        <Limite>
          <ConversacionPrevia usuario={ANA} arrendador="mariana_rivas" mensajesIniciales={[]} enviar={enviar} />
        </Limite>,
      );
      escribir("Hola");
      await userEvent.click(botonEnviar());

      expect(await screen.findByText("Redirigiendo: NEXT_REDIRECT")).toBeInTheDocument();
      expect(screen.queryByText(ERROR_ENVIO)).not.toBeInTheDocument();
      errorDeConsola.mockClear();
    });
  });

  describe("accesibilidad y teclado", () => {
    it("panel con título, historial como registro, campo con etiqueta y contador", () => {
      renderizar();
      expect(screen.getByRole("region", { name: /Conversación con mariana_rivas/ })).toBeInTheDocument();
      expect(historial()).toBeInTheDocument();
      expect(campo()).toHaveAttribute("placeholder", "Escribe tu mensaje…");
      expect(screen.getByText("Mensaje")).toBeInTheDocument();
    });

    it("el error queda asociado al campo con aria-describedby", async () => {
      renderizar();
      await userEvent.click(botonEnviar());
      const descripcion = document.getElementById(campo().getAttribute("aria-describedby")!);
      expect(descripcion).toHaveTextContent(INVALIDO);
    });

    it("con teclado: Tab llega al campo y luego al botón; Enter en el botón envía", async () => {
      const enviar = renderizar({ enviar: vi.fn<Enviar>(async () => ({ ok: true, mensaje: mensaje("m3", ANA, "Hola") })) });
      await userEvent.tab();
      expect(campo()).toHaveFocus();
      await userEvent.keyboard("Hola");
      await userEvent.tab();
      expect(botonEnviar()).toHaveFocus();
      await userEvent.keyboard("{Enter}");
      expect(enviar).toHaveBeenCalledWith("Hola");
      await screen.findByText("0/1000");
    });

    it("B1: «Enviar mensaje» va a la derecha con ancho automático en todos los tamaños, también mientras envía", async () => {
      const { promesa, resolver } = diferido();
      renderizar({ enviar: vi.fn<Enviar>(() => promesa) });
      expect(botonEnviar()).toHaveClass("self-end");
      expect(botonEnviar().className).not.toMatch(/(^|\s)(md:)?w-(full|auto)(\s|$)/);
      expect(botonEnviar()).toHaveAttribute("type", "submit");

      escribir("Hola");
      await userEvent.click(botonEnviar());
      await screen.findByText("ana_m · enviando…");
      expect(botonEnviar()).toHaveClass("self-end");
      expect(botonEnviar()).toBeDisabled();
      expect(botonEnviar()).toHaveAttribute("aria-busy", "true");

      resolver({ ok: false, status: 500 });
      await screen.findByRole("alert");
      expect(botonEnviar()).toBeEnabled();
    });

    it("Enter dentro del campo agrega un salto de línea y no envía", async () => {
      const enviar = renderizar();
      await userEvent.click(campo());
      await userEvent.keyboard("Hola{Enter}mundo");
      expect(campo()).toHaveValue("Hola\nmundo");
      expect(enviar).not.toHaveBeenCalled();
    });
  });
});
