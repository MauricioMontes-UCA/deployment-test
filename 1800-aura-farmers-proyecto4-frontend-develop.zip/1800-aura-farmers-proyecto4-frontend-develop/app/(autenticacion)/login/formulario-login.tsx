"use client";

import { useActionState, useState } from "react";
import { iniciarSesion, type EstadoLogin } from "@/app/actions/auth";
import { Alerta, Boton, CampoDeTexto } from "@/components/ui";
import { validarEmail } from "@/lib/validaciones/registro";

const estadoInicial: EstadoLogin = {};

/**
 * Formulario de login con correo y contraseña (H0). Los campos son controlados
 * para que «Iniciar sesión» se habilite solo con un correo válido y una
 * contraseña, y para conservar lo escrito cuando el backend responde 401.
 */
export function FormularioLogin() {
  const [estado, accion, enviando] = useActionState(iniciarSesion, estadoInicial);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const valido = !validarEmail(email.trim()) && password.length > 0;

  return (
    <form action={accion} className="flex flex-col gap-5" noValidate>
      {estado.error && (
        <Alerta
          tono="error"
          titulo={estado.credencialesInvalidas ? "No pudimos iniciar sesión" : undefined}
        >
          {estado.error}
        </Alerta>
      )}
      <CampoDeTexto
        etiqueta="Correo electrónico"
        name="email"
        type="email"
        autoComplete="email"
        required
        value={email}
        onChange={(evento) => setEmail(evento.target.value)}
        placeholder="correo@ejemplo.com"
        invalido={estado.credencialesInvalidas}
      />
      <CampoDeTexto
        etiqueta="Contraseña"
        name="password"
        type="password"
        autoComplete="current-password"
        required
        value={password}
        onChange={(evento) => setPassword(evento.target.value)}
        invalido={estado.credencialesInvalidas}
      />
      <Boton type="submit" cargando={enviando} disabled={!valido} className="w-full">
        Iniciar sesión
      </Boton>
    </form>
  );
}
