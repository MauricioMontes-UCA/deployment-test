import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, describe, expect, it, vi } from "vitest";
import type { EstadoLogin } from "@/app/actions/auth";

const { iniciarSesion } = vi.hoisted(() => ({
  iniciarSesion: vi.fn<(estado: EstadoLogin, datos: FormData) => Promise<EstadoLogin>>(),
}));
vi.mock("@/app/actions/auth", () => ({ iniciarSesion }));

import { FormularioLogin } from "./formulario-login";

afterEach(() => iniciarSesion.mockReset());

const campo = (nombre: string) => screen.getByLabelText(nombre);
const botonEntrar = () => screen.getByRole("button", { name: /Iniciar sesión|Procesando/ });

describe("FormularioLogin", () => {
  it("«Iniciar sesión» se habilita solo con un correo válido y una contraseña", async () => {
    render(<FormularioLogin />);
    expect(botonEntrar()).toBeDisabled();
    await userEvent.type(campo("Correo electrónico"), "ana@");
    await userEvent.type(campo("Contraseña"), "Str0ngPass");
    expect(botonEntrar()).toBeDisabled();
    await userEvent.type(campo("Correo electrónico"), "example.com");
    expect(botonEntrar()).toBeEnabled();
  });

  it("con 401 muestra el aviso, marca los campos y conserva lo escrito", async () => {
    iniciarSesion.mockResolvedValueOnce({
      error: "Credenciales inválidas.",
      credencialesInvalidas: true,
      email: "ana@example.com",
    });
    render(<FormularioLogin />);
    await userEvent.type(campo("Correo electrónico"), "ana@example.com");
    await userEvent.type(campo("Contraseña"), "Str0ngPass");
    await userEvent.click(botonEntrar());

    const alerta = await screen.findByRole("alert");
    expect(alerta).toHaveTextContent("No pudimos iniciar sesión");
    expect(alerta).toHaveTextContent("Credenciales inválidas.");
    expect(campo("Correo electrónico")).toHaveValue("ana@example.com");
    expect(campo("Correo electrónico")).toHaveAttribute("aria-invalid", "true");
    expect(campo("Contraseña")).toHaveAttribute("aria-invalid", "true");
  });

  it("con un error de red muestra el mensaje sin título", async () => {
    iniciarSesion.mockResolvedValueOnce({
      error: "No pudimos iniciar sesión. Intenta de nuevo.",
      email: "ana@example.com",
    });
    render(<FormularioLogin />);
    await userEvent.type(campo("Correo electrónico"), "ana@example.com");
    await userEvent.type(campo("Contraseña"), "Str0ngPass");
    await userEvent.click(botonEntrar());

    const alerta = await screen.findByRole("alert");
    expect(alerta).toHaveTextContent("No pudimos iniciar sesión. Intenta de nuevo.");
    expect(campo("Contraseña")).not.toHaveAttribute("aria-invalid");
  });
});
