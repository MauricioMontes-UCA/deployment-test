import type { Metadata } from "next";
import Link from "next/link";
import { Alerta } from "@/components/ui";
import { FormularioLogin } from "./formulario-login";

export const metadata: Metadata = {
  title: "Iniciar sesión · Arre",
};

export default async function PaginaLogin({ searchParams }: PageProps<"/login">) {
  const { registro } = await searchParams;
  return (
    <>
      <h1 className="texto-h1 text-texto-primario">Inicia sesión</h1>
      <p className="texto-cuerpo text-texto-secundario">Entra con tu correo y contraseña.</p>
      {registro === "ok" && (
        <Alerta tono="exito" titulo="Cuenta creada">
          Cuenta creada. Inicia sesión.
        </Alerta>
      )}
      <FormularioLogin />
      <p className="texto-cuerpo-pequeno text-texto-secundario">
        ¿No tienes cuenta?{" "}
        <Link href="/registro" className="text-texto-acento underline hover:text-texto-primario">
          Crear cuenta
        </Link>
      </p>
    </>
  );
}
