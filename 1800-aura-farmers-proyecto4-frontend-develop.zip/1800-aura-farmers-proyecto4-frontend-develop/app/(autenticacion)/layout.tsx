import type { ReactNode } from "react";
import { Contenedor, Icono, NavegacionSuperior, PieDePagina, type IconoNombre } from "@/components/ui";

const PUNTOS_DE_MARCA: { icono: IconoNombre; texto: string }[] = [
  { icono: "bienes", texto: "Espacios y equipo publicados con fotos, condiciones y depósito." },
  { icono: "calendario", texto: "Disponibilidad real y respuesta automática a tu solicitud." },
  { icono: "verificado", texto: "Pagos de prueba, comprobantes y verificación de identidad." },
];

/**
 * Marco de las pantallas de acceso (login y registro), como en Figma: barra de
 * visitante, panel de marca a la izquierda y el formulario a la derecha. En
 * móvil y tableta el panel se oculta y queda solo el formulario.
 */
export default function LayoutAutenticacion({ children }: { children: ReactNode }) {
  return (
    <>
      <NavegacionSuperior rol="visitante" />
      <main className="flex-1 pt-espacio-5 pb-espacio-7 md:pt-espacio-8 md:pb-espacio-9">
        <Contenedor className="flex items-start gap-espacio-9">
          <PanelDeMarca />
          <div className="flex w-full max-w-120 flex-col gap-5">{children}</div>
        </Contenedor>
      </main>
      <PieDePagina />
    </>
  );
}

function PanelDeMarca() {
  return (
    <aside className="hidden w-140 shrink-0 flex-col gap-espacio-5 bg-fondo-sutil px-espacio-7 py-14 lg:flex">
      <p className="texto-sobretitulo text-texto-acento">Arre</p>
      <p className="texto-display text-texto-primario">Renta lo que necesitas, de personas cerca de ti.</p>
      <ul className="flex flex-col gap-espacio-5">
        {PUNTOS_DE_MARCA.map(({ icono, texto }) => (
          <li key={icono} className="flex items-start gap-espacio-3">
            <Icono nombre={icono} tamano={24} className="shrink-0 text-texto-acento" />
            <span className="texto-cuerpo text-texto-secundario">{texto}</span>
          </li>
        ))}
      </ul>
    </aside>
  );
}
