import type { Metadata } from "next";
import Link from "next/link";
import { FormularioRegistro } from "./formulario-registro";

export const metadata: Metadata = {
  title: "Crear cuenta · Arre",
};

export default function PaginaRegistro() {
  return (
    <>
      <h1 className="texto-h1 text-texto-primario">Crear cuenta</h1>
      <p className="texto-cuerpo text-texto-secundario">
        Regístrate con un nombre de usuario y elige cómo vas a usar Arre.
      </p>
      <FormularioRegistro />
      <p className="texto-cuerpo-pequeno text-texto-secundario">
        ¿Ya tienes cuenta?{" "}
        <Link href="/login" className="text-texto-acento underline hover:text-texto-primario">
          Ya tengo cuenta
        </Link>
      </p>
    </>
  );
}
