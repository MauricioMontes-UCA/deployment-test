"use client";

import { startTransition, useActionState, useState, type ChangeEvent, type FormEvent } from "react";
import { registrar, type EstadoRegistro } from "@/app/actions/auth";
import { Alerta, Boton, CampoDeTexto, OpcionEnTarjeta } from "@/components/ui";
import {
  NOMBRE_USUARIO_MAX,
  PASSWORD_MAX,
  EMAIL_MAX,
  validarRegistro,
  type CampoRegistro,
  type ValoresRegistro,
} from "@/lib/validaciones/registro";

const estadoInicial: EstadoRegistro = { envio: 0 };

const VALORES_VACIOS: ValoresRegistro = { nombreUsuario: "", email: "", password: "", rol: "" };

/**
 * Formulario de registro (H0). Los campos son controlados para que lo escrito
 * se conserve cuando el backend responde 409 o 400.
 *
 * La acción se lanza desde `onSubmit` y no con `<form action>`: con
 * `action`, React reinicia el formulario al terminar y el radio del rol
 * quedaría desmarcado aunque el estado lo tenga elegido.
 *
 * Los errores de validación aparecen al salir de cada campo. Los del backend
 * se muestran mientras el campo conserve el valor con el que se envió: si el
 * usuario lo corrige, el mensaje viejo desaparece.
 */
export function FormularioRegistro() {
  const [estado, accion, enviando] = useActionState(registrar, estadoInicial);
  const [valores, setValores] = useState(VALORES_VACIOS);
  const [tocados, setTocados] = useState<Partial<Record<CampoRegistro, boolean>>>({});
  const [enviado, setEnviado] = useState<ValoresRegistro | null>(null);

  const erroresCliente = validarRegistro(valores);
  const formularioValido = Object.keys(erroresCliente).length === 0;

  function errorDe(campo: CampoRegistro): string | undefined {
    if (tocados[campo] && erroresCliente[campo]) return erroresCliente[campo];
    const delServidor = estado.errores?.[campo];
    if (delServidor && enviado && valores[campo] === enviado[campo]) return delServidor;
  }

  function alCambiar(evento: ChangeEvent<HTMLInputElement>) {
    const { name, value } = evento.target;
    setValores((actuales) => ({ ...actuales, [name]: value }));
  }

  function alEnviar(evento: FormEvent<HTMLFormElement>) {
    evento.preventDefault();
    if (!formularioValido || enviando) return;
    setEnviado(valores);
    const datos = new FormData(evento.currentTarget);
    startTransition(() => accion(datos));
  }

  function alSalir(campo: CampoRegistro) {
    setTocados((actuales) => ({ ...actuales, [campo]: true }));
  }

  return (
    <form
      onSubmit={alEnviar}
      className="flex flex-col gap-5"
      noValidate
    >
      {estado.error && (
        <Alerta tono="error" titulo={estado.conflicto ? "No pudimos crear tu cuenta" : undefined}>
          {estado.error}
        </Alerta>
      )}

      <CampoDeTexto
        etiqueta="Nombre de usuario"
        name="nombreUsuario"
        autoComplete="username"
        value={valores.nombreUsuario}
        onChange={alCambiar}
        onBlur={() => alSalir("nombreUsuario")}
        maxLength={NOMBRE_USUARIO_MAX}
        contador
        placeholder="ej. ana_m"
        ayuda="De 3 a 30 caracteres: letras, números, punto, guion y guion bajo."
        error={errorDe("nombreUsuario")}
      />
      <CampoDeTexto
        etiqueta="Correo electrónico"
        name="email"
        type="email"
        autoComplete="email"
        value={valores.email}
        onChange={alCambiar}
        onBlur={() => alSalir("email")}
        maxLength={EMAIL_MAX}
        placeholder="correo@ejemplo.com"
        error={errorDe("email")}
      />
      <CampoDeTexto
        etiqueta="Contraseña"
        name="password"
        type="password"
        autoComplete="new-password"
        value={valores.password}
        onChange={alCambiar}
        onBlur={() => alSalir("password")}
        maxLength={PASSWORD_MAX}
        placeholder="Mínimo 8 caracteres"
        error={errorDe("password")}
      />

      <fieldset className="flex flex-col gap-2.5">
        <legend className="texto-etiqueta float-left mb-2.5 w-full text-texto-primario">
          ¿Cómo vas a usar la plataforma?
        </legend>
        <OpcionEnTarjeta
          name="rol"
          value="ARRENDATARIO"
          titulo="Quiero rentar bienes"
          descripcion="Arrendatario"
          checked={valores.rol === "ARRENDATARIO"}
          onChange={alCambiar}
        />
        <OpcionEnTarjeta
          name="rol"
          value="ARRENDADOR"
          titulo="Quiero publicar mis bienes"
          descripcion="Arrendador"
          checked={valores.rol === "ARRENDADOR"}
          onChange={alCambiar}
        />
        <p className={errorDe("rol") ? "texto-cuerpo-pequeno text-texto-error" : "texto-cuerpo-pequeno text-texto-secundario"}>
          {errorDe("rol") ?? "Ninguna opción viene marcada por defecto."}
        </p>
      </fieldset>

      <Boton
        type="submit"
        cargando={enviando}
        disabled={!formularioValido}
        className="w-full"
      >
        Crear cuenta
      </Boton>
    </form>
  );
}
