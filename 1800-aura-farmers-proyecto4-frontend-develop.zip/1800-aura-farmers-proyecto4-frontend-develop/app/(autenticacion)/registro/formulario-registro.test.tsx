import { act, fireEvent, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, describe, expect, it, vi } from "vitest";
import type { EstadoRegistro } from "@/app/actions/auth";

const { registrar } = vi.hoisted(() => ({
  registrar: vi.fn<(estado: EstadoRegistro, datos: FormData) => Promise<EstadoRegistro>>(),
}));
vi.mock("@/app/actions/auth", () => ({ registrar }));

import { FormularioRegistro } from "./formulario-registro";

afterEach(() => registrar.mockReset());

const campo = (nombre: string) => screen.getByLabelText(nombre);
const botonCrear = () => screen.getByRole("button", { name: /Crear cuenta|Procesando/ });

async function llenarValido() {
  await userEvent.type(campo("Nombre de usuario"), "ana_m");
  await userEvent.type(campo("Correo electrónico"), "ana@example.com");
  await userEvent.type(campo("Contraseña"), "Str0ngPass");
  await userEvent.click(screen.getByText("Quiero rentar bienes"));
}

describe("FormularioRegistro", () => {
  it("el botón queda deshabilitado hasta que todo es válido, incluido el rol", async () => {
    render(<FormularioRegistro />);
    expect(botonCrear()).toBeDisabled();

    await userEvent.type(campo("Nombre de usuario"), "ana_m");
    await userEvent.type(campo("Correo electrónico"), "ana@example.com");
    await userEvent.type(campo("Contraseña"), "Str0ngPass");
    expect(botonCrear()).toBeDisabled();

    await userEvent.click(screen.getByText("Quiero publicar mis bienes"));
    expect(botonCrear()).toBeEnabled();
  });

  it("no tiene un rol elegido por defecto", () => {
    render(<FormularioRegistro />);
    for (const opcion of screen.getAllByRole("radio")) expect(opcion).not.toBeChecked();
  });

  it("no deja enviar con un nombre de usuario de 2 ni de 31 caracteres", async () => {
    render(<FormularioRegistro />);
    await llenarValido();
    const nombre = campo("Nombre de usuario");

    await userEvent.clear(nombre);
    await userEvent.type(nombre, "ab");
    await userEvent.tab();
    expect(botonCrear()).toBeDisabled();
    expect(screen.getByText("El nombre de usuario debe tener al menos 3 caracteres.")).toBeInTheDocument();

    // maxLength impide escribir el carácter 31; un valor pegado de más igual se valida.
    fireEvent.change(nombre, { target: { value: "a".repeat(31) } });
    expect(botonCrear()).toBeDisabled();
    expect(screen.getByText("El nombre de usuario no puede superar los 30 caracteres.")).toBeInTheDocument();
  });

  it("muestra el contador n/30 del nombre de usuario", async () => {
    render(<FormularioRegistro />);
    expect(screen.getByText("0/30")).toBeInTheDocument();
    await userEvent.type(campo("Nombre de usuario"), "ana_m");
    expect(screen.getByText("5/30")).toBeInTheDocument();
  });

  it("muestra los errores de validación al salir del campo, no mientras se escribe", async () => {
    render(<FormularioRegistro />);
    await userEvent.type(campo("Correo electrónico"), "ana@");
    expect(screen.queryByText("El email no tiene un formato válido.")).not.toBeInTheDocument();
    await userEvent.tab();
    expect(screen.getByText("El email no tiene un formato válido.")).toBeInTheDocument();
  });

  it("envía los cuatro campos a la server action", async () => {
    registrar.mockResolvedValueOnce({ envio: 1 });
    render(<FormularioRegistro />);
    await llenarValido();
    await userEvent.click(botonCrear());

    const datos = registrar.mock.calls[0][1];
    expect(Object.fromEntries(datos.entries())).toEqual({
      nombreUsuario: "ana_m",
      email: "ana@example.com",
      password: "Str0ngPass",
      rol: "ARRENDATARIO",
    });
  });

  it("con 409 muestra el mensaje y conserva lo escrito", async () => {
    registrar.mockResolvedValueOnce({
      error: "Ese correo o nombre de usuario ya está registrado.",
      conflicto: true,
      envio: 1,
    });
    render(<FormularioRegistro />);
    await llenarValido();
    await userEvent.click(botonCrear());

    const alerta = await screen.findByRole("alert");
    expect(alerta).toHaveTextContent("No pudimos crear tu cuenta");
    expect(alerta).toHaveTextContent("Ese correo o nombre de usuario ya está registrado.");
    expect(campo("Nombre de usuario")).toHaveValue("ana_m");
    expect(campo("Correo electrónico")).toHaveValue("ana@example.com");
    expect(campo("Contraseña")).toHaveValue("Str0ngPass");
    expect(screen.getByRole("radio", { name: /Quiero rentar bienes/ })).toBeChecked();
  });

  it("con 400 muestra el mensaje bajo el campo hasta que se corrige", async () => {
    registrar.mockResolvedValueOnce({
      errores: { email: "El email no tiene un formato válido." },
      envio: 1,
    });
    render(<FormularioRegistro />);
    await llenarValido();
    await userEvent.click(botonCrear());

    expect(await screen.findByText("El email no tiene un formato válido.")).toBeInTheDocument();
    expect(campo("Correo electrónico")).toHaveAttribute("aria-invalid", "true");

    await userEvent.type(campo("Correo electrónico"), "m");
    expect(screen.queryByText("El email no tiene un formato válido.")).not.toBeInTheDocument();
  });

  it("con error de red o 500 muestra el mensaje general", async () => {
    registrar.mockResolvedValueOnce({ error: "No pudimos crear tu cuenta. Intenta de nuevo.", envio: 1 });
    render(<FormularioRegistro />);
    await llenarValido();
    await userEvent.click(botonCrear());
    expect(await screen.findByRole("alert")).toHaveTextContent(
      "No pudimos crear tu cuenta. Intenta de nuevo.",
    );
  });

  it("deshabilita el botón mientras se envía", async () => {
    let terminar: (estado: EstadoRegistro) => void = () => {};
    registrar.mockReturnValueOnce(new Promise((resolver) => (terminar = resolver)));
    render(<FormularioRegistro />);
    await llenarValido();
    await userEvent.click(botonCrear());

    expect(await screen.findByRole("button", { name: "Procesando…" })).toBeDisabled();
    await act(async () => terminar({ envio: 1 }));
    expect(screen.getByRole("button", { name: "Crear cuenta" })).toBeEnabled();
  });
});
