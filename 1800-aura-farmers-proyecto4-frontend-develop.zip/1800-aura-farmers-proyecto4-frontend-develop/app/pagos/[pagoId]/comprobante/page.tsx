import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { cerrarSesion } from "@/app/actions/auth";
import { Contenedor, NavegacionSuperior, PieDePagina } from "@/components/ui";
import { obtenerUsuarioActual } from "@/lib/usuario-actual";
import { VistaComprobante } from "@/components/pagos/vista-comprobante";

export const metadata: Metadata = { title: "Comprobante de pago · Arre" };

export default async function PaginaComprobante({
  params,
}: {
  params: Promise<{ pagoId: string }>;
}) {
  const { pagoId } = await params;
  const resultado = await obtenerUsuarioActual();
  if (resultado.estado === "sin-sesion") redirect("/sesion-vencida");
  return (
    <>
      <div className="print:hidden">
        <NavegacionSuperior
          rol={
            resultado.estado === "ok" && resultado.usuario.rol === "ARRENDADOR"
              ? "arrendador"
              : "arrendatario"
          }
          nombreUsuario={
            resultado.estado === "ok"
              ? resultado.usuario.nombreUsuario
              : undefined
          }
          onCerrarSesion={cerrarSesion}
        />
      </div>
      <main className="flex-1 bg-fondo-base print:bg-white">
        <Contenedor className="flex justify-center pt-espacio-7 pb-espacio-9 print:p-0">
          <VistaComprobante
            pagoId={pagoId}
            sinPermiso={
              resultado.estado === "ok" &&
              resultado.usuario.rol !== "ARRENDATARIO"
            }
          />
        </Contenedor>
      </main>
      <div className="print:hidden">
        <PieDePagina />
      </div>
    </>
  );
}
