"use client";

import { useRouter } from "next/navigation";
import { useEffect, useRef, useState, type ChangeEvent, type FormEvent, type ReactNode } from "react";
import {
  Alerta,
  AreaDeTexto,
  BarraDeProgreso,
  Boton,
  CampoDeTexto,
  CargadorDeArchivos,
  MiniaturaDeFoto,
  Selector,
} from "@/components/ui";
import { mensajesDe } from "@/lib/auth-api";
import { unirClases } from "@/lib/clases";
import { CATEGORIAS_POR_TIPO, TIPOS_BIEN, UNIDADES_COBRO, esTipoBien } from "@/lib/catalogos/bienes";
import { DEPARTAMENTOS, municipiosDe } from "@/lib/ubicaciones";
import { subirBien } from "@/lib/subir-bien";
import {
  ACEPTAR_FOTOS,
  CONDICIONES_MAX,
  DESCRIPCION_MAX,
  DIRECCION_MAX,
  MAX_FOTOS,
  MAX_FOTO_MB,
  TITULO_MAX,
  VALORES_BIEN_VACIOS,
  campoDeMensajeBien,
  normalizarMonto,
  validarBien,
  validarFoto,
  type CampoBien,
  type ErroresBien,
} from "@/lib/validaciones/bien";

type Foto = { id: string; archivo: File; url: string };

const MENSAJE_400 = "Revisa los campos marcados.";
const MENSAJE_403 = "Solo los arrendadores pueden publicar.";
const MENSAJE_GENERAL = "No pudimos publicar tu bien. Intenta de nuevo.";

/** Cómo se nombra cada campo en el resumen del 400 («Corrige el título y el precio.»). */
const NOMBRE_CAMPO: Record<CampoBien, string> = {
  tipo: "el tipo de bien",
  categoria: "la categoría",
  titulo: "el título",
  descripcion: "la descripción",
  precio: "el precio",
  unidadCobro: "la unidad de cobro",
  deposito: "el depósito",
  capacidad: "la capacidad",
  condiciones: "las condiciones de uso",
  departamento: "el departamento",
  municipio: "el municipio",
  direccionReferencia: "la dirección de referencia",
  fotos: "las fotos",
};

/** «a», «a y b», «a, b y c». */
function enumerar(partes: string[]): string {
  return partes.length < 2 ? partes.join("") : `${partes.slice(0, -1).join(", ")} y ${partes.at(-1)}`;
}

type ErrorGeneral = { titulo?: string; detalle: string };

/** Copia de los errores sin el de `campo`. */
function sinCampo(errores: ErroresBien, campo: CampoBien): ErroresBien {
  const copia = { ...errores };
  delete copia[campo];
  return copia;
}

const opciones = (lista: readonly string[]) => lista.map((valor) => ({ valor, etiqueta: valor }));
const OPCIONES_DEPARTAMENTO = opciones(DEPARTAMENTOS);

/**
 * Formulario de publicación de un bien (H1) con galería de fotos.
 *
 * Los campos son controlados y las fotos viven en el estado, con vistas
 * previas locales. Al enviar se arma el multipart en el orden que eligió el
 * usuario e `indicePrincipal` apunta a la foto principal dentro de ese orden.
 * La subida va por XMLHttpRequest para mostrar el progreso real.
 */
export function FormularioPublicacion() {
  const router = useRouter();
  const [valores, setValores] = useState(VALORES_BIEN_VACIOS);
  const [fotos, setFotos] = useState<Foto[]>([]);
  const [idPrincipal, setIdPrincipal] = useState<string | null>(null);
  const [tocados, setTocados] = useState<Partial<Record<CampoBien, boolean>>>({});
  const [erroresServidor, setErroresServidor] = useState<ErroresBien>({});
  const [erroresArchivos, setErroresArchivos] = useState<string[]>([]);
  const [errorGeneral, setErrorGeneral] = useState<ErrorGeneral | null>(null);
  const [progreso, setProgreso] = useState<number | null>(null);
  const enviando = progreso !== null;

  // Libera las vistas previas al salir de la página.
  const fotosActuales = useRef(fotos);
  useEffect(() => {
    fotosActuales.current = fotos;
  }, [fotos]);
  useEffect(() => () => fotosActuales.current.forEach((foto) => URL.revokeObjectURL(foto.url)), []);

  const erroresCliente = validarBien(valores, fotos.length);
  const formularioValido = Object.keys(erroresCliente).length === 0;
  const tipo = esTipoBien(valores.tipo) ? valores.tipo : null;
  const principal = idPrincipal ?? fotos[0]?.id ?? null;

  function errorDe(campo: CampoBien): string | undefined {
    return erroresServidor[campo] ?? (tocados[campo] ? erroresCliente[campo] : undefined);
  }

  /** Cambia un campo; el error del servidor de ese campo deja de aplicar. */
  function cambiar(campo: Exclude<CampoBien, "fotos">, valor: string) {
    setValores((actuales) => {
      const nuevos = { ...actuales, [campo]: valor };
      // Las listas dependientes se vacían cuando cambia la de arriba.
      if (campo === "tipo" && valor !== actuales.tipo) {
        nuevos.categoria = "";
        if (valor !== "PROPIEDAD") nuevos.capacidad = "";
      }
      if (campo === "departamento" && valor !== actuales.departamento) nuevos.municipio = "";
      return nuevos;
    });
    setErroresServidor((actuales) => sinCampo(actuales, campo));
  }

  const alCambiarTexto =
    (campo: Exclude<CampoBien, "fotos">) =>
    (evento: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
      cambiar(campo, evento.target.value);

  const tocar = (campo: CampoBien) => () =>
    setTocados((actuales) => ({ ...actuales, [campo]: true }));

  function agregarFotos(archivos: File[]) {
    const rechazos: string[] = [];
    const nuevas: Foto[] = [];
    for (const archivo of archivos) {
      const error = validarFoto(archivo);
      if (error) rechazos.push(error);
      else if (fotos.length + nuevas.length >= MAX_FOTOS)
        rechazos.push(`«${archivo.name}» no se agregó: se pueden subir como máximo ${MAX_FOTOS} fotos.`);
      else nuevas.push({ id: crypto.randomUUID(), archivo, url: URL.createObjectURL(archivo) });
    }
    setFotos((actuales) => [...actuales, ...nuevas]);
    setErroresArchivos(rechazos);
    setTocados((actuales) => ({ ...actuales, fotos: true }));
    setErroresServidor((actuales) => sinCampo(actuales, "fotos"));
  }

  function quitarFoto(id: string) {
    const foto = fotos.find((actual) => actual.id === id);
    if (foto) URL.revokeObjectURL(foto.url);
    setFotos((actuales) => actuales.filter((actual) => actual.id !== id));
    if (idPrincipal === id) setIdPrincipal(null);
    setErroresServidor((actuales) => sinCampo(actuales, "fotos"));
  }

  function moverFoto(indice: number, desplazamiento: -1 | 1) {
    setFotos((actuales) => {
      const nuevas = [...actuales];
      const destino = indice + desplazamiento;
      [nuevas[indice], nuevas[destino]] = [nuevas[destino], nuevas[indice]];
      return nuevas;
    });
  }

  /** Arma el multipart con los nombres del contrato de POST /bienes. */
  function armarDatos(): FormData {
    const datos = new FormData();
    datos.set("tipo", valores.tipo);
    datos.set("categoria", valores.categoria);
    datos.set("titulo", valores.titulo.trim());
    datos.set("descripcion", valores.descripcion.trim());
    datos.set("precio", normalizarMonto(valores.precio));
    datos.set("unidadCobro", valores.unidadCobro);
    if (valores.deposito.trim()) datos.set("deposito", normalizarMonto(valores.deposito));
    if (tipo === "PROPIEDAD" && valores.capacidad.trim()) datos.set("capacidad", valores.capacidad.trim());
    if (valores.condiciones.trim()) datos.set("condiciones", valores.condiciones.trim());
    datos.set("departamento", valores.departamento);
    datos.set("municipio", valores.municipio);
    if (valores.direccionReferencia.trim())
      datos.set("direccionReferencia", valores.direccionReferencia.trim());
    datos.set("indicePrincipal", String(Math.max(0, fotos.findIndex((foto) => foto.id === principal))));
    for (const foto of fotos) datos.append("fotos", foto.archivo, foto.archivo.name);
    return datos;
  }

  async function alEnviar(evento: FormEvent<HTMLFormElement>) {
    evento.preventDefault();
    if (!formularioValido || enviando) return;

    setErrorGeneral(null);
    setErroresServidor({});
    setProgreso(0);
    const { status, cuerpo } = await subirBien(armarDatos(), setProgreso);

    if (status === 201) {
      const { id } = cuerpo as { id: string };
      router.push(`/bienes/${id}?publicado=1`);
      return;
    }

    setProgreso(null);
    if (status === 401) {
      // /sesion-vencida confirma con /auth/me y borra las cookies solo si el
      // backend las rechaza; /login devolvería al inicio con la sesión caída.
      router.push("/sesion-vencida");
    } else if (status === 400) {
      const porCampo: ErroresBien = {};
      for (const mensaje of mensajesDe(cuerpo)) {
        const campo = campoDeMensajeBien(mensaje);
        // Varias fotos pueden fallar a la vez: se juntan bajo el cargador.
        if (campo === "fotos") porCampo.fotos = porCampo.fotos ? `${porCampo.fotos} ${mensaje}` : mensaje;
        else if (campo) porCampo[campo] ??= mensaje;
      }
      setErroresServidor(porCampo);
      const campos = (Object.keys(porCampo) as CampoBien[]).map((campo) => NOMBRE_CAMPO[campo]);
      setErrorGeneral(
        campos.length
          ? { titulo: MENSAJE_400, detalle: `Corrige ${enumerar(campos)}.` }
          : { detalle: MENSAJE_400 },
      );
    } else if (status === 403) {
      setErrorGeneral({ detalle: MENSAJE_403 });
    } else {
      setErrorGeneral({ detalle: MENSAJE_GENERAL });
    }
  }

  const errorFotos = [errorDe("fotos"), ...erroresArchivos].filter(Boolean).join(" ") || undefined;

  return (
    <form
      onSubmit={alEnviar}
      noValidate
      className="grid items-start gap-espacio-5 lg:grid-cols-[minmax(0,1fr)_448px] lg:gap-espacio-6"
    >
      <div className="flex min-w-0 flex-col gap-espacio-5">
        <Seccion titulo="Datos del bien">
          <div className="grid grid-cols-2 items-start gap-espacio-4">
            <Selector
              etiqueta="Tipo de bien"
              opciones={TIPOS_BIEN}
              valor={valores.tipo || null}
              onCambiar={(valor) => cambiar("tipo", valor)}
              error={errorDe("tipo")}
            />
            <Selector
              key={valores.tipo || "sin-tipo"}
              etiqueta="Categoría"
              opciones={tipo ? opciones(CATEGORIAS_POR_TIPO[tipo]) : []}
              valor={valores.categoria || null}
              onCambiar={(valor) => cambiar("categoria", valor)}
              placeholder={tipo ? "Selecciona una categoría" : "Elige primero el tipo"}
              deshabilitado={!tipo}
              ayuda="La lista cambia según el tipo."
              error={errorDe("categoria")}
            />
          </div>
          <CampoDeTexto
            etiqueta="Título"
            value={valores.titulo}
            onChange={alCambiarTexto("titulo")}
            onBlur={tocar("titulo")}
            maxLength={TITULO_MAX}
            contador
            placeholder="Salón de eventos Las Palmas"
            error={errorDe("titulo")}
          />
          <AreaDeTexto
            etiqueta="Descripción"
            value={valores.descripcion}
            onChange={alCambiarTexto("descripcion")}
            onBlur={tocar("descripcion")}
            maxLength={DESCRIPCION_MAX}
            contador
            placeholder="Qué incluye, en qué estado está y para qué sirve."
            error={errorDe("descripcion")}
          />
          <div className="grid grid-cols-2 items-start gap-espacio-4">
            <CampoDeTexto
              etiqueta="Precio"
              inputMode="decimal"
              value={valores.precio}
              onChange={alCambiarTexto("precio")}
              onBlur={tocar("precio")}
              placeholder="80.00"
              error={errorDe("precio")}
            />
            <Selector
              etiqueta="Unidad de cobro"
              opciones={UNIDADES_COBRO}
              valor={valores.unidadCobro || null}
              onCambiar={(valor) => cambiar("unidadCobro", valor)}
              error={errorDe("unidadCobro")}
            />
          </div>
          <div className="grid grid-cols-2 items-start gap-espacio-4">
            <CampoDeTexto
              etiqueta="Depósito de garantía"
              inputMode="decimal"
              value={valores.deposito}
              onChange={alCambiarTexto("deposito")}
              onBlur={tocar("deposito")}
              placeholder="0.00"
              ayuda="Escribe 0 si no pides depósito."
              error={errorDe("deposito")}
            />
            {tipo === "PROPIEDAD" && (
              <CampoDeTexto
                etiqueta="Capacidad (personas)"
                inputMode="numeric"
                value={valores.capacidad}
                onChange={alCambiarTexto("capacidad")}
                onBlur={tocar("capacidad")}
                placeholder="120"
                ayuda="Solo para propiedades."
                error={errorDe("capacidad")}
              />
            )}
          </div>
          <AreaDeTexto
            etiqueta="Condiciones de uso"
            value={valores.condiciones}
            onChange={alCambiarTexto("condiciones")}
            onBlur={tocar("condiciones")}
            maxLength={CONDICIONES_MAX}
            contador
            placeholder="No se permite fumar. Horario hasta las 23:00."
            error={errorDe("condiciones")}
          />
        </Seccion>

        <Seccion titulo="Ubicación">
          <div className="grid grid-cols-2 items-start gap-espacio-4">
            <Selector
              etiqueta="Departamento"
              opciones={OPCIONES_DEPARTAMENTO}
              valor={valores.departamento || null}
              onCambiar={(valor) => cambiar("departamento", valor)}
              error={errorDe("departamento")}
            />
            <Selector
              key={valores.departamento || "sin-departamento"}
              etiqueta="Municipio"
              opciones={opciones(municipiosDe(valores.departamento))}
              valor={valores.municipio || null}
              onCambiar={(valor) => cambiar("municipio", valor)}
              placeholder={valores.departamento ? "Selecciona un municipio" : "Elige primero el departamento"}
              deshabilitado={!valores.departamento}
              ayuda="Depende del departamento."
              error={errorDe("municipio")}
            />
          </div>
          <CampoDeTexto
            etiqueta="Dirección de referencia"
            value={valores.direccionReferencia}
            onChange={alCambiarTexto("direccionReferencia")}
            onBlur={tocar("direccionReferencia")}
            maxLength={DIRECCION_MAX}
            placeholder="Frente al parque central, portón negro."
            ayuda="Opcional."
            error={errorDe("direccionReferencia")}
          />
        </Seccion>
      </div>

      <div className="flex min-w-0 flex-col gap-espacio-5">
        <Seccion titulo={`Fotos (de 1 a ${MAX_FOTOS})`} className="gap-espacio-4">
          <CargadorDeArchivos
            onArchivos={agregarFotos}
            accept={ACEPTAR_FOTOS}
            titulo="Arrastra tus fotos o haz clic para seleccionarlas"
            ayuda={`JPG o PNG, máximo ${MAX_FOTO_MB} MB cada una`}
            error={errorFotos}
            deshabilitado={enviando || fotos.length >= MAX_FOTOS}
          />
          {fotos.length > 0 && (
            <ul className="flex flex-wrap gap-espacio-4" aria-label="Fotos elegidas">
              {fotos.map((foto, indice) => (
                <li key={foto.id}>
                  <MiniaturaDeFoto
                    src={foto.url}
                    alt={`Foto ${indice + 1}: ${foto.archivo.name}`}
                    principal={foto.id === principal}
                    onMarcarPrincipal={() => setIdPrincipal(foto.id)}
                    onMoverIzquierda={indice > 0 ? () => moverFoto(indice, -1) : undefined}
                    onMoverDerecha={indice < fotos.length - 1 ? () => moverFoto(indice, 1) : undefined}
                    onQuitar={enviando ? undefined : () => quitarFoto(foto.id)}
                  />
                </li>
              ))}
            </ul>
          )}
          <p className="texto-cuerpo-pequeno text-texto-secundario">
            Usa las flechas para ordenar. La foto principal se usa como portada.
          </p>
        </Seccion>

        <div className="flex flex-col gap-espacio-3">
          {errorGeneral && (
            <Alerta tono="error" titulo={errorGeneral.titulo}>
              {errorGeneral.detalle}
            </Alerta>
          )}
          <Boton type="submit" cargando={enviando} disabled={!formularioValido} className="w-full">
            Publicar
          </Boton>
          {enviando && <BarraDeProgreso valor={(progreso ?? 0) * 100} etiqueta="Subiendo la publicación" />}
          <p className="texto-cuerpo-pequeno text-texto-secundario">
            &quot;Publicar&quot; se habilita al completar los campos obligatorios y subir al menos una foto.
          </p>
        </div>
      </div>
    </form>
  );
}

/** Tarjeta de una sección del formulario, con el título en serif como en Figma. */
function Seccion({
  titulo,
  className,
  children,
}: {
  titulo: string;
  className?: string;
  children: ReactNode;
}) {
  return (
    <fieldset
      className={unirClases(
        "flex min-w-0 flex-col gap-5 border border-borde-default bg-fondo-superficie p-espacio-5",
        className,
      )}
    >
      <legend className="texto-h3 float-left w-full text-texto-primario">{titulo}</legend>
      {children}
    </fieldset>
  );
}
