import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { cerrarSesion } from "@/app/actions/auth";
import {
  Contenedor,
  EncabezadoDePagina,
  EstadoDePagina,
  NavegacionSuperior,
  PieDePagina,
  clasesBoton,
} from "@/components/ui";
import { obtenerUsuarioActual } from "@/lib/usuario-actual";
import { FormularioPublicacion } from "./formulario-publicacion";

export const metadata: Metadata = {
  title: "Publicar un bien · Arre",
};

/**
 * Publicación de un bien (H1). El proxy ya filtra por el rol del token; aquí se
 * vuelve a validar con /auth/me, porque el rol del token puede estar viejo.
 */
export default async function PaginaPublicar() {
  const sesion = await obtenerUsuarioActual();
  // 401 de /auth/me: la sesión ya no sirve (cuenta inactiva o token revocado).
  if (sesion.estado === "sin-sesion") redirect("/sesion-vencida");
  if (sesion.estado === "error") {
    return (
      <main className="flex flex-1 items-center py-espacio-7">
        <Contenedor>
          <EstadoDePagina
            tipo="error"
            accion={
              <Link href="/publicar" className={clasesBoton({ jerarquia: "secundario" })}>
                Reintentar
              </Link>
            }
          />
        </Contenedor>
      </main>
    );
  }
  const { usuario } = sesion;
  if (usuario.rol !== "ARRENDADOR") redirect("/");

  return (
    <>
      <NavegacionSuperior
        rol="arrendador"
        nombreUsuario={usuario.nombreUsuario}
        onCerrarSesion={cerrarSesion}
      />
      <main className="flex-1 pt-espacio-5 pb-espacio-7 md:pt-espacio-7 md:pb-espacio-9">
        <Contenedor className="flex flex-col gap-espacio-5 md:gap-10">
          {/* En Figma la descripción solo aparece en escritorio. */}
          <EncabezadoDePagina
            sobretitulo="Mis bienes"
            titulo="Publicar un bien"
            className="max-md:[&>p:last-child]:hidden"
            descripcion="Describe tu propiedad o equipo. Lo verán los arrendatarios en la búsqueda."
          />
          <FormularioPublicacion />
        </Contenedor>
      </main>
      <PieDePagina />
    </>
  );
}
