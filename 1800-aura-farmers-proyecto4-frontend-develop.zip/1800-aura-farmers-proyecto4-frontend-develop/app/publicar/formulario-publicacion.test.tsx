import { act, fireEvent, render, screen, within, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, beforeAll, beforeEach, describe, expect, it, vi } from "vitest";
import type { ResultadoSubida } from "@/lib/subir-bien";

const { subirBien, push } = vi.hoisted(() => ({
  subirBien: vi.fn<(datos: FormData, alAvanzar: (p: number) => void) => Promise<ResultadoSubida>>(),
  push: vi.fn(),
}));
vi.mock("@/lib/subir-bien", () => ({ subirBien }));
vi.mock("next/navigation", () => ({ useRouter: () => ({ push }), usePathname: () => "/publicar" }));
// next/image necesita el optimizador de Next; en las pruebas basta un <img>.
vi.mock("next/image", () => ({
  // eslint-disable-next-line @next/next/no-img-element
  default: ({ src, alt }: { src: string; alt: string }) => <img src={src} alt={alt} />,
}));

import { FormularioPublicacion } from "./formulario-publicacion";

let usuario: ReturnType<typeof userEvent.setup>;

beforeAll(() => {
  URL.createObjectURL = vi.fn((archivo: Blob) => `blob:${(archivo as File).name}`);
  URL.revokeObjectURL = vi.fn();
});

beforeEach(() => {
  // applyAccept: false para que lleguen al formulario también los archivos
  // que el diálogo del navegador filtraría, y probar la validación propia.
  usuario = userEvent.setup({ applyAccept: false });
});

afterEach(() => {
  subirBien.mockReset();
  push.mockReset();
});

const foto = (nombre: string, tipo = "image/jpeg", bytes = 1024) => {
  const archivo = new File(["contenido"], nombre, { type: tipo });
  Object.defineProperty(archivo, "size", { value: bytes });
  return archivo;
};

const botonPublicar = () => screen.getByRole("button", { name: /Publicar|Procesando/ });
const inputFotos = () => document.querySelector<HTMLInputElement>('input[type="file"]')!;

async function elegir(etiqueta: string, opcion: string) {
  const selector = screen.getByRole("combobox", { name: etiqueta });

  await usuario.click(selector);
  
  const opcionDisponible = await screen.findByRole(
    "option",
    { name: opcion },
    { timeout: 3000 },
  );

  await usuario.click(opcionDisponible);

  await waitFor(() => {
    expect(selector).toHaveAttribute("aria-expanded", "false");
  });
}

async function llenarDatos() {
  await elegir("Tipo de bien", "Propiedad");
  await elegir("Categoría", "Salón de eventos");
  await usuario.type(screen.getByLabelText("Título"), "Salón de eventos Las Palmas");
  await usuario.type(screen.getByLabelText("Descripción"), "Salón climatizado con cocina.");
  await usuario.type(screen.getByLabelText("Precio"), "80");
  await elegir("Unidad de cobro", "Por día");
  await elegir("Departamento", "La Libertad");
  await elegir("Municipio", "Santa Tecla");
}

async function llenarTodo(fotos = [foto("sala.jpg")]) {
  await llenarDatos();
  await usuario.upload(inputFotos(), fotos);
}

describe("FormularioPublicacion", () => {
  it("«Publicar» queda deshabilitado hasta completar lo obligatorio y subir una foto", async () => {
    render(<FormularioPublicacion />);
    expect(botonPublicar()).toBeDisabled();
    await llenarDatos();
    expect(botonPublicar()).toBeDisabled();
    await usuario.upload(inputFotos(), foto("sala.jpg"));
    expect(botonPublicar()).toBeEnabled();
  });

  it("la categoría depende del tipo y el municipio del departamento", async () => {
    render(<FormularioPublicacion />);
    expect(screen.getByRole("combobox", { name: "Categoría" })).toBeDisabled();
    await elegir("Tipo de bien", "Equipo");
    await usuario.click(screen.getByRole("combobox", { name: "Categoría" }));
    expect(screen.getByRole("option", { name: "Herramientas" })).toBeInTheDocument();
    expect(screen.queryByRole("option", { name: "Casa" })).not.toBeInTheDocument();
    await usuario.click(screen.getByRole("option", { name: "Herramientas" }));

    // Cambiar el tipo vacía la categoría elegida.
    await elegir("Tipo de bien", "Propiedad");
    expect(screen.getByRole("combobox", { name: "Categoría" })).toHaveTextContent("Selecciona una categoría");

    await elegir("Departamento", "San Salvador");
    await usuario.click(screen.getByRole("combobox", { name: "Municipio" }));
    expect(screen.getByRole("option", { name: "Soyapango" })).toBeInTheDocument();
    expect(screen.queryByRole("option", { name: "Santa Tecla" })).not.toBeInTheDocument();
  });

  it("solo pide la capacidad para propiedades", async () => {
    render(<FormularioPublicacion />);
    await elegir("Tipo de bien", "Equipo");
    expect(screen.queryByLabelText("Capacidad (personas)")).not.toBeInTheDocument();
    await elegir("Tipo de bien", "Propiedad");
    expect(screen.getByLabelText("Capacidad (personas)")).toBeInTheDocument();
  });

  it("no deja publicar con precio 0 ni con título de más de 100 caracteres", async () => {
    render(<FormularioPublicacion />);
    await llenarTodo();
    const precio = screen.getByLabelText("Precio");
    await usuario.clear(precio);
    await usuario.type(precio, "0");
    await usuario.tab();
    expect(botonPublicar()).toBeDisabled();
    expect(screen.getByText("El precio debe ser mayor que 0.")).toBeInTheDocument();

    await usuario.clear(precio);
    await usuario.type(precio, "80");
    // maxLength impide escribir el carácter 101; un texto pegado de más igual se valida.
    fireEvent.change(screen.getByLabelText("Título"), { target: { value: "a".repeat(101) } });
    fireEvent.blur(screen.getByLabelText("Título"));
    expect(botonPublicar()).toBeDisabled();
    expect(screen.getByText("El título no puede superar los 100 caracteres.")).toBeInTheDocument();
  });

  it("muestra los contadores del título y la descripción", async () => {
    render(<FormularioPublicacion />);
    expect(screen.getByText("0/100")).toBeInTheDocument();
    expect(screen.getByText("0/2000")).toBeInTheDocument();
  });

  it("rechaza en el navegador archivos que no son JPG o PNG o pesan más de 5 MB", async () => {
    render(<FormularioPublicacion />);
    await usuario.upload(inputFotos(), [
      foto("buena.png", "image/png"),
      foto("documento.pdf", "application/pdf"),
      foto("enorme.jpg", "image/jpeg", 6 * 1024 * 1024),
    ]);
    expect(screen.getByText(/«documento.pdf» no es JPG ni PNG\./)).toBeInTheDocument();
    expect(screen.getByText(/«enorme.jpg» pesa más de 5 MB\./)).toBeInTheDocument();
    expect(within(screen.getByRole("list", { name: "Fotos elegidas" })).getAllByRole("listitem")).toHaveLength(1);
  });

  it("no agrega más de 10 fotos", async () => {
    render(<FormularioPublicacion />);
    const once = Array.from({ length: 11 }, (_, i) => foto(`f${i + 1}.jpg`));
    await usuario.upload(inputFotos(), once);
    expect(within(screen.getByRole("list", { name: "Fotos elegidas" })).getAllByRole("listitem")).toHaveLength(10);
    expect(screen.getByText(/«f11.jpg» no se agregó/)).toBeInTheDocument();
  });

  it("envía la foto marcada como principal como principal, respetando el orden", async () => {
    subirBien.mockResolvedValueOnce({ status: 201, cuerpo: { id: "b1" } });
    render(<FormularioPublicacion />);
    await llenarTodo([foto("uno.jpg"), foto("dos.jpg"), foto("tres.jpg")]);

    // «tres» pasa al segundo lugar y se marca como principal.
    await usuario.click(screen.getAllByRole("button", { name: "Mover a la izquierda" })[2]);
    // «uno» es la principal por defecto y no tiene botón: el primero es el de «tres».
    await usuario.click(screen.getAllByRole("button", { name: "Marcar principal" })[0]);
    await usuario.click(botonPublicar());

    const datos = subirBien.mock.calls[0][0];
    expect((datos.getAll("fotos") as File[]).map((f) => f.name)).toEqual(["uno.jpg", "tres.jpg", "dos.jpg"]);
    expect(datos.get("indicePrincipal")).toBe("1");
  }, 15000);

  it("envía los campos con los nombres del contrato y omite los opcionales vacíos", async () => {
    subirBien.mockResolvedValueOnce({ status: 201, cuerpo: { id: "b1" } });
    render(<FormularioPublicacion />);
    await llenarTodo();
    await usuario.click(botonPublicar());

    const datos = subirBien.mock.calls[0][0];
    expect(Object.fromEntries([...datos.entries()].filter(([clave]) => clave !== "fotos"))).toEqual({
      tipo: "PROPIEDAD",
      categoria: "Salón de eventos",
      titulo: "Salón de eventos Las Palmas",
      descripcion: "Salón climatizado con cocina.",
      precio: "80",
      unidadCobro: "DIA",
      departamento: "La Libertad",
      municipio: "Santa Tecla",
      indicePrincipal: "0",
    });
  }, 15000);

  it("con éxito lleva al detalle del bien con el aviso de publicación", async () => {
    subirBien.mockResolvedValueOnce({ status: 201, cuerpo: { id: "7c9e" } });
    render(<FormularioPublicacion />);
    await llenarTodo();
    await usuario.click(botonPublicar());
    expect(push).toHaveBeenCalledWith("/bienes/7c9e?publicado=1");
  }, 15000);

  it("con 400 muestra el mensaje general y cada error bajo su campo", async () => {
    subirBien.mockResolvedValueOnce({
      status: 400,
      cuerpo: {
        message: ["La categoría no pertenece al tipo elegido.", "La foto 1 (sala.jpg) debe ser JPG, PNG o WEBP."],
        statusCode: 400,
      },
    });
    render(<FormularioPublicacion />);
    await llenarTodo();
    await usuario.click(botonPublicar());

    const alerta = await screen.findByRole("alert", { name: "" });
    expect(alerta).toHaveTextContent("Revisa los campos marcados.");
    expect(alerta).toHaveTextContent("Corrige la categoría y las fotos.");
    expect(screen.getByText("La categoría no pertenece al tipo elegido.")).toBeInTheDocument();
    expect(screen.getByText(/La foto 1 \(sala\.jpg\) debe ser JPG, PNG o WEBP\./)).toBeInTheDocument();
  }, 15000);

  it.each([
    [403, "Solo los arrendadores pueden publicar."],
    [500, "No pudimos publicar tu bien. Intenta de nuevo."],
    [502, "No pudimos publicar tu bien. Intenta de nuevo."],
    [0, "No pudimos publicar tu bien. Intenta de nuevo."],
  ])("con %i muestra «%s» y conserva lo escrito", async (status, mensaje) => {
    subirBien.mockResolvedValueOnce({ status, cuerpo: null });
    render(<FormularioPublicacion />);
    await llenarTodo();
    await usuario.click(botonPublicar());

    expect(await screen.findByText(mensaje)).toBeInTheDocument();
    expect(screen.getByLabelText("Título")).toHaveValue("Salón de eventos Las Palmas");
    expect(botonPublicar()).toBeEnabled();
  });

  it("con 401 manda a /sesion-vencida", async () => {
    subirBien.mockResolvedValueOnce({ status: 401, cuerpo: null });
    render(<FormularioPublicacion />);
    await llenarTodo();
    await usuario.click(botonPublicar());
    expect(push).toHaveBeenCalledWith("/sesion-vencida");
  });

  it("mientras sube muestra el progreso y no permite un segundo envío", async () => {
    let avanzar: (p: number) => void = () => {};
    let terminar: (r: ResultadoSubida) => void = () => {};
    subirBien.mockImplementationOnce((_datos, alAvanzar) => {
      avanzar = alAvanzar;
      return new Promise((resolver) => (terminar = resolver));
    });
    render(<FormularioPublicacion />);
    await llenarTodo();
    await usuario.click(botonPublicar());

    expect(botonPublicar()).toBeDisabled();
    expect(botonPublicar()).toHaveAccessibleName("Procesando…");
    act(() => avanzar(0.4));
    expect(screen.getByRole("progressbar", { name: "Subiendo la publicación" })).toHaveAttribute("aria-valuenow", "40");

    fireEvent.submit(botonPublicar().closest("form")!);
    expect(subirBien).toHaveBeenCalledOnce();

    await act(async () => terminar({ status: 500, cuerpo: null }));
    expect(screen.queryByRole("progressbar")).not.toBeInTheDocument();
  });
});
