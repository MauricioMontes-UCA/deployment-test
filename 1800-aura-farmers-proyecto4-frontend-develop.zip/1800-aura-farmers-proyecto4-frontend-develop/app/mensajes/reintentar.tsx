"use client";

import { useRouter } from "next/navigation";
import { useTransition } from "react";
import { Boton } from "@/components/ui";

/** Vuelve a pedir al servidor la conversación abierta, sin perder la lista ni la pestaña. */
export function BotonReintentar() {
  const router = useRouter();
  const [pendiente, iniciar] = useTransition();
  return (
    <Boton jerarquia="secundario" cargando={pendiente} onClick={() => iniciar(() => router.refresh())}>
      Reintentar
    </Boton>
  );
}
