import { afterEach, describe, expect, it, vi } from "vitest";
import type { RespuestaApiCruda } from "@/lib/api";
import type { ResultadoUsuario } from "@/lib/usuario-actual";

const api = vi.hoisted(() => ({ llamarApi: vi.fn() }));
vi.mock("@/lib/api", () => api);
const sesion = vi.hoisted(() => ({ obtenerUsuarioActual: vi.fn() }));
vi.mock("@/lib/usuario-actual", () => sesion);

const { cargarConsulta, cargarUsuarioBandeja, ErrorDeCarga, PAGINAS_DE_BUSQUEDA } = await import("../datos");

const CONV = "11111111-1111-4111-8111-111111111111";
const R_HISTORIAL = `conversaciones/${CONV}/mensajes?orden=asc`;
const rPagina = (n: number) => `conversaciones?tipo=CONSULTA&pagina=${n}`;

const arrendador = { id: "u2", nombreUsuario: "mariana_rivas", email: "m@example.com", rol: "ARRENDADOR", createdAt: "2026-11-01T00:00:00.000Z" } as const;
const arrendatario = { id: "u1", nombreUsuario: "ana_m", email: "a@example.com", rol: "ARRENDATARIO", createdAt: "2026-11-01T00:00:00.000Z" } as const;
const conSesion = (usuario: typeof arrendador | typeof arrendatario): ResultadoUsuario => ({ estado: "ok", usuario });
const cruda = (status: number, datos: unknown = null): RespuestaApiCruda => ({ status, datos, mensajes: [] });

const item = (id: string, otro = { id: "u1", nombreUsuario: "ana_m" }) => ({
  id,
  tipo: "CONSULTA",
  bien: { id: "b1", titulo: "Salón de eventos Las Palmas", fotoPrincipalUrl: null },
  reservaId: null,
  otroParticipante: otro,
  ultimoMensaje: null,
  actualizadaEn: "2026-11-20T16:42:00.000Z",
});
const pagina = (items: unknown[], hayMas = false) => cruda(200, { items, pagina: 1, total: items.length, hayMas });
const mensaje = (id: string, remitente: { id: string; nombreUsuario: string }, creadoEn: string) => ({
  id,
  conversacionId: CONV,
  remitente,
  contenido: `Mensaje ${id}`,
  creadoEn,
});
const historial = (mensajes: unknown[] = []) => cruda(200, { conversacionId: CONV, orden: "asc", mensajes });

function responder({
  usuario = conSesion(arrendador),
  mensajes = historial(),
  paginas = [pagina([item(CONV)])],
}: { usuario?: ResultadoUsuario; mensajes?: RespuestaApiCruda; paginas?: RespuestaApiCruda[] } = {}) {
  sesion.obtenerUsuarioActual.mockResolvedValue(usuario);
  api.llamarApi.mockImplementation(async (ruta: string, init?: RequestInit) => {
    if (init?.method && init.method !== "GET") throw new Error(`método inesperado: ${init.method} ${ruta}`);
    if (ruta === R_HISTORIAL) return mensajes;
    const n = /^conversaciones\?tipo=CONSULTA&pagina=(\d+)$/.exec(ruta)?.[1];
    if (n) return paginas[Number(n) - 1] ?? pagina([]);
    throw new Error(`ruta inesperada: ${ruta}`);
  });
}
const rutasPedidas = () => api.llamarApi.mock.calls.map(([ruta]) => ruta as string);

afterEach(() => vi.clearAllMocks());

describe("cargarConsulta (consulta por id de conversación)", () => {
  it("arrendador: historial en orden y datos de la bandeja (bien y otro participante)", async () => {
    responder({
      mensajes: historial([
        mensaje("m2", { id: "u2", nombreUsuario: "mariana_rivas" }, "2026-11-05T16:40:00.000Z"),
        mensaje("m1", { id: "u1", nombreUsuario: "ana_m" }, "2026-11-05T16:32:00.000Z"),
      ]),
    });
    const pantalla = await cargarConsulta(CONV);
    expect(pantalla.tipo).toBe("lista");
    if (pantalla.tipo !== "lista") return;
    expect(pantalla.datos.conversacionId).toBe(CONV);
    expect(pantalla.datos.mensajes.map(({ id }) => id)).toEqual(["m1", "m2"]);
    expect(pantalla.datos.conversacion?.bien.titulo).toBe("Salón de eventos Las Palmas");
    expect(pantalla.datos.otro).toEqual({ id: "u1", nombreUsuario: "ana_m" });
  });

  it("arrendatario: la misma consulta por id, con el arrendador como otro participante", async () => {
    responder({ usuario: conSesion(arrendatario), paginas: [pagina([item(CONV, { id: "u2", nombreUsuario: "mariana_rivas" })])] });
    const pantalla = await cargarConsulta(CONV);
    expect(pantalla.tipo === "lista" && pantalla.datos.otro?.nombreUsuario).toBe("mariana_rivas");
  });

  it("solo lee: nunca abre ni crea una conversación (sin POST ni rutas de bienes)", async () => {
    responder();
    await cargarConsulta(CONV);
    expect(rutasPedidas()).toEqual(expect.arrayContaining([R_HISTORIAL, rPagina(1)]));
    expect(rutasPedidas().some((ruta) => ruta.startsWith("bienes/"))).toBe(false);
    expect(api.llamarApi.mock.calls.every(([, init]) => !init || !init.method || init.method === "GET")).toBe(true);
  });

  it("busca la conversación en las páginas siguientes mientras `hayMas`", async () => {
    responder({ paginas: [pagina([item("otra-1")], true), pagina([item(CONV)], false)] });
    const pantalla = await cargarConsulta(CONV);
    expect(pantalla.tipo === "lista" && pantalla.datos.conversacion?.id).toBe(CONV);
    expect(rutasPedidas()).toContain(rPagina(2));
  });

  it("sin `hayMas` no pide más páginas aunque no la encuentre", async () => {
    responder({ paginas: [pagina([item("otra-1")], false), pagina([item(CONV)])] });
    const pantalla = await cargarConsulta(CONV);
    expect(rutasPedidas().filter((ruta) => ruta.startsWith("conversaciones?"))).toEqual([rPagina(1)]);
    expect(pantalla.tipo === "lista" && pantalla.datos.conversacion).toBeNull();
  });

  it(`deja de buscar tras ${PAGINAS_DE_BUSQUEDA} páginas; sin datos de la bandeja, el otro participante sale del historial`, async () => {
    responder({
      paginas: Array.from({ length: 8 }, (_, n) => pagina([item(`otra-${n}`)], true)),
      mensajes: historial([
        mensaje("m1", { id: "u2", nombreUsuario: "mariana_rivas" }, "2026-11-05T16:32:00.000Z"),
        mensaje("m2", { id: "u1", nombreUsuario: "ana_m" }, "2026-11-05T16:40:00.000Z"),
      ]),
    });
    const pantalla = await cargarConsulta(CONV);
    expect(rutasPedidas().filter((ruta) => ruta.startsWith("conversaciones?"))).toHaveLength(PAGINAS_DE_BUSQUEDA);
    expect(pantalla.tipo === "lista" && pantalla.datos.conversacion).toBeNull();
    expect(pantalla.tipo === "lista" && pantalla.datos.otro).toEqual({ id: "u1", nombreUsuario: "ana_m" });
  });

  describe("pista de la tarjeta (página donde estaba en la bandeja)", () => {
    /** Bandeja de «Todas» simulada: `conversaciones?pagina=N` (sin tipo). */
    function responderConTodas(paginasTodas: Record<number, RespuestaApiCruda>, paginasConsulta: RespuestaApiCruda[]) {
      responder({ paginas: paginasConsulta });
      const base = api.llamarApi.getMockImplementation()!;
      api.llamarApi.mockImplementation(async (ruta: string, init?: RequestInit) => {
        const n = /^conversaciones\?pagina=(\d+)$/.exec(ruta)?.[1];
        if (n) return paginasTodas[Number(n)] ?? pagina([]);
        return base(ruta, init);
      });
    }

    it("más allá de las primeras 100 consultas: la encuentra con una sola petición extra (la de la pista)", async () => {
      responderConTodas({ 9: pagina([item("otra"), item(CONV)], true) }, [pagina([item("reciente")], true)]);
      const pantalla = await cargarConsulta(CONV, { filtro: null, pagina: 9 });
      expect(pantalla.tipo === "lista" && pantalla.datos.conversacion?.id).toBe(CONV);
      expect(rutasPedidas().filter((ruta) => ruta.startsWith("conversaciones?"))).toEqual([rPagina(1), "conversaciones?pagina=9"]);
    });

    it("pista de «Consultas»: pide esa página con el filtro", async () => {
      responder({ paginas: [pagina([item("a")], true), pagina([item("b")], true), pagina([item(CONV)], true)] });
      const pantalla = await cargarConsulta(CONV, { filtro: "CONSULTA", pagina: 3 });
      expect(pantalla.tipo === "lista" && pantalla.datos.conversacion?.id).toBe(CONV);
      expect(rutasPedidas().filter((ruta) => ruta.startsWith("conversaciones?"))).toEqual([rPagina(1), rPagina(3)]);
    });

    it("pista vieja o falsa: no la encuentra ahí y sigue la búsqueda normal, sin repetir páginas", async () => {
      responderConTodas({ 4: pagina([item("otra")], true) }, [pagina([item("a")], true), pagina([item(CONV)])]);
      const pantalla = await cargarConsulta(CONV, { filtro: null, pagina: 4 });
      expect(pantalla.tipo === "lista" && pantalla.datos.conversacion?.id).toBe(CONV);
      expect(rutasPedidas().filter((ruta) => ruta.startsWith("conversaciones?"))).toEqual([rPagina(1), "conversaciones?pagina=4", rPagina(2)]);
    });

    it("una pista vieja de «Consultas» no hace pedir dos veces la misma página", async () => {
      responder({ paginas: [pagina([item("a")], true), pagina([item("b")], true), pagina([item(CONV)])] });
      const pantalla = await cargarConsulta(CONV, { filtro: "CONSULTA", pagina: 2 });
      expect(pantalla.tipo === "lista" && pantalla.datos.conversacion?.id).toBe(CONV);
      expect(rutasPedidas().filter((ruta) => ruta.startsWith("conversaciones?"))).toEqual([rPagina(1), rPagina(2), rPagina(3)]);
    });

    it("la pista nunca sirve a quien no participa: con 403 no se pide la página de la pista", async () => {
      responderConTodas({ 9: pagina([item(CONV)]) }, [pagina([])]);
      const conPagina9 = api.llamarApi.getMockImplementation()!;
      api.llamarApi.mockImplementation(async (ruta: string, init?: RequestInit) =>
        ruta === R_HISTORIAL ? cruda(403) : conPagina9(ruta, init),
      );
      const pantalla = await cargarConsulta(CONV, { filtro: null, pagina: 9 });
      expect(pantalla.tipo).toBe("sin-permiso");
      expect(rutasPedidas()).not.toContain("conversaciones?pagina=9");
    });
  });

  it("con un historial donde el otro sí escribió, identifica al otro participante aunque la bandeja no la traiga", async () => {
    responder({
      paginas: [pagina([])],
      mensajes: historial([
        mensaje("m1", { id: "u2", nombreUsuario: "mariana_rivas" }, "2026-11-05T16:32:00.000Z"),
        mensaje("m2", { id: "u1", nombreUsuario: "ana_m" }, "2026-11-05T16:40:00.000Z"),
      ]),
    });
    const pantalla = await cargarConsulta(CONV);
    // La sesión es mariana_rivas (u2): el otro es ana_m, nunca ella misma.
    expect(pantalla.tipo === "lista" && pantalla.datos.otro).toEqual({ id: "u1", nombreUsuario: "ana_m" });
  });

  it("si la bandeja falla, la consulta igual se muestra (sin inventar bien ni participante)", async () => {
    responder({ paginas: [cruda(500)] });
    const pantalla = await cargarConsulta(CONV);
    expect(pantalla).toMatchObject({ tipo: "lista", datos: { conversacion: null, otro: null, mensajes: [] } });
  });

  it.each([
    [403, "sin-permiso"],
    [404, "no-encontrada"],
    [400, "no-encontrada"],
    [401, "sin-sesion"],
  ])("historial %i → %s, sin exponer datos de la bandeja", async (status, tipo) => {
    responder({ mensajes: cruda(status) });
    const pantalla = await cargarConsulta(CONV);
    expect(pantalla.tipo).toBe(tipo);
    expect(pantalla).not.toHaveProperty("datos");
  });

  it("id inválido: no encontrada sin llamar al backend", async () => {
    responder();
    expect((await cargarConsulta("../../auth/me")).tipo).toBe("no-encontrada");
    expect(api.llamarApi).not.toHaveBeenCalled();
  });

  it.each([
    ["500", cruda(500)],
    ["sin respuesta", cruda(0)],
    ["cuerpo inesperado", cruda(200, { mensajes: [{ id: 1 }] })],
  ])("historial %s → ErrorDeCarga (error.tsx con Reintentar)", async (_caso, respuesta) => {
    responder({ mensajes: respuesta });
    await expect(cargarConsulta(CONV)).rejects.toBeInstanceOf(ErrorDeCarga);
  });

  it("sin sesión no llama al backend; si /auth/me falla, ErrorDeCarga", async () => {
    responder({ usuario: { estado: "sin-sesion" } });
    expect((await cargarConsulta(CONV)).tipo).toBe("sin-sesion");
    expect(api.llamarApi).not.toHaveBeenCalled();
    responder({ usuario: { estado: "error" } });
    await expect(cargarConsulta(CONV)).rejects.toBeInstanceOf(ErrorDeCarga);
  });
});

describe("cargarUsuarioBandeja", () => {
  it("devuelve el usuario, «sin-sesion» o lanza ErrorDeCarga", async () => {
    sesion.obtenerUsuarioActual.mockResolvedValueOnce(conSesion(arrendatario));
    expect(await cargarUsuarioBandeja()).toEqual({ tipo: "ok", usuario: arrendatario });
    sesion.obtenerUsuarioActual.mockResolvedValueOnce({ estado: "sin-sesion" });
    expect(await cargarUsuarioBandeja()).toEqual({ tipo: "sin-sesion" });
    sesion.obtenerUsuarioActual.mockResolvedValueOnce({ estado: "error" });
    await expect(cargarUsuarioBandeja()).rejects.toBeInstanceOf(ErrorDeCarga);
  });
});
