import { render, screen } from "@testing-library/react";
import type { ReactNode } from "react";
import { afterEach, describe, expect, it, vi } from "vitest";
import type { SeleccionBandeja } from "@/lib/bandeja";

const datos = vi.hoisted(() => ({ cargarUsuarioBandeja: vi.fn() }));
vi.mock("../datos", () => datos);
const bandeja = vi.hoisted(() => ({ props: null as null | Record<string, unknown> }));
vi.mock("../bandeja-de-mensajes", () => ({
  BandejaDeMensajes: ({ children, ...props }: { children?: ReactNode }) => {
    bandeja.props = props;
    return <div data-testid="bandeja">{children}</div>;
  },
}));
vi.mock("../paneles", () => ({
  PanelSeleccionado: ({ seleccion }: { seleccion: SeleccionBandeja }) => <p>Panel {JSON.stringify(seleccion)}</p>,
  SinSeleccion: () => <p>Elige una conversación</p>,
}));
vi.mock("@/app/actions/auth", () => ({ cerrarSesion: vi.fn() }));
vi.mock("next/navigation", async (original) => ({
  ...(await original<typeof import("next/navigation")>()),
  redirect: vi.fn((url: string) => {
    throw new Error(`REDIRECT:${url}`);
  }),
}));

const { default: MensajesPage } = await import("../page");
const { default: ErrorAlCargar } = await import("../error");
const { default: Cargando } = await import("../loading");

const CONV = "11111111-1111-4111-8111-111111111111";
const RESERVA = "22222222-2222-4222-8222-222222222222";
const arrendador = { id: "u2", nombreUsuario: "mariana_rivas", email: "m@example.com", rol: "ARRENDADOR", createdAt: "2026-11-01T00:00:00.000Z" } as const;
const arrendatario = { id: "u1", nombreUsuario: "ana_m", email: "a@example.com", rol: "ARRENDATARIO", createdAt: "2026-11-01T00:00:00.000Z" } as const;

async function renderizar(usuario: typeof arrendador | typeof arrendatario, parametros: Record<string, string> = {}) {
  datos.cargarUsuarioBandeja.mockResolvedValue({ tipo: "ok", usuario });
  render(await MensajesPage({ searchParams: Promise.resolve(parametros) } as PageProps<"/mensajes">));
}

afterEach(() => {
  vi.clearAllMocks();
  bandeja.props = null;
});

describe("/mensajes", () => {
  it("arrendador: encabezado de Figma y bandeja con su id y rol, sin conversación abierta", async () => {
    await renderizar(arrendador);
    expect(screen.getByRole("heading", { level: 1, name: "Mensajes" })).toBeInTheDocument();
    expect(screen.getByText("Consultas sobre tus publicaciones y conversaciones de entrega de tus reservas.")).toBeInTheDocument();
    expect(bandeja.props).toEqual({ usuario: { id: "u2", rol: "ARRENDADOR" }, filtroInicial: null, seleccion: null });
    expect(screen.getByText("Elige una conversación")).toBeInTheDocument();
    expect(screen.getAllByRole("link", { name: "Reportes" }).length).toBeGreaterThan(0);
  });

  it("arrendatario: su descripción y su navegación", async () => {
    await renderizar(arrendatario);
    expect(screen.getByText("Tus consultas sobre publicaciones y conversaciones de entrega de tus reservas.")).toBeInTheDocument();
    expect(bandeja.props).toMatchObject({ usuario: { id: "u1", rol: "ARRENDATARIO" } });
    expect(screen.queryByRole("link", { name: "Reportes" })).not.toBeInTheDocument();
  });

  it("pestaña y conversación abierta desde la URL (consulta por id)", async () => {
    await renderizar(arrendador, { tipo: "CONSULTA", consulta: CONV });
    const seleccion = { tipo: "consulta", conversacionId: CONV };
    expect(bandeja.props).toMatchObject({ filtroInicial: "CONSULTA", seleccion });
    expect(screen.getByText(`Panel ${JSON.stringify(seleccion)}`)).toBeInTheDocument();
  });

  it("coordinación abierta por id de reserva", async () => {
    await renderizar(arrendatario, { reserva: RESERVA });
    expect(screen.getByText(`Panel ${JSON.stringify({ tipo: "reserva", reservaId: RESERVA })}`)).toBeInTheDocument();
  });

  it("parámetros inválidos: «Todas» y sin conversación abierta", async () => {
    await renderizar(arrendador, { tipo: "OTRA", consulta: "abc" });
    expect(bandeja.props).toMatchObject({ filtroInicial: null, seleccion: null });
    expect(screen.getByText("Elige una conversación")).toBeInTheDocument();
  });

  it("sin sesión → /sesion-vencida", async () => {
    datos.cargarUsuarioBandeja.mockResolvedValue({ tipo: "sin-sesion" });
    await expect(MensajesPage({ searchParams: Promise.resolve({}) } as PageProps<"/mensajes">)).rejects.toThrow(
      "REDIRECT:/sesion-vencida",
    );
  });

  it("error.tsx reintenta y loading.tsx anuncia la carga", async () => {
    const retry = vi.fn();
    const { unmount } = render(<ErrorAlCargar error={new Error("x")} retry={retry} />);
    expect(screen.getByRole("alert")).toHaveTextContent("No pudimos cargar tus mensajes");
    screen.getByRole("button", { name: "Reintentar" }).click();
    expect(retry).toHaveBeenCalled();
    unmount();
    render(<Cargando />);
    expect(screen.getByRole("status")).toHaveTextContent("Cargando tus mensajes…");
  });
});
