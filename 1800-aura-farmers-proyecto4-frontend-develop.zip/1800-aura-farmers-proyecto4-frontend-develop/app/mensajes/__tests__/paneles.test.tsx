import { render, screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, describe, expect, it, vi } from "vitest";
import type { PantallaCoordinacion } from "@/app/reservas/[reservaId]/conversacion/datos";
import type { PantallaConsulta } from "../datos";

const datos = vi.hoisted(() => ({ cargarConsulta: vi.fn() }));
vi.mock("../datos", () => datos);
const coordinacion = vi.hoisted(() => ({ cargarCoordinacion: vi.fn() }));
vi.mock("@/app/reservas/[reservaId]/conversacion/datos", () => coordinacion);
const acciones = vi.hoisted(() => ({ enviarMensaje: vi.fn(), enviarMensajeCoordinacion: vi.fn() }));
vi.mock("@/app/actions/conversacion", () => ({ enviarMensaje: acciones.enviarMensaje }));
vi.mock("@/app/actions/coordinacion", () => ({ enviarMensajeCoordinacion: acciones.enviarMensajeCoordinacion }));
const navegacion = vi.hoisted(() => ({ refresh: vi.fn() }));
vi.mock("next/navigation", async (original) => ({
  ...(await original<typeof import("next/navigation")>()),
  useRouter: () => navegacion,
  redirect: vi.fn((url: string) => {
    throw new Error(`REDIRECT:${url}`);
  }),
}));

const { PanelSeleccionado, SinSeleccion, tituloConsulta } = await import("../paneles");

const CONV = "11111111-1111-4111-8111-111111111111";
const RESERVA = "22222222-2222-4222-8222-222222222222";
const arrendador = { id: "u2", nombreUsuario: "mariana_rivas", email: "m@example.com", rol: "ARRENDADOR", createdAt: "2026-11-01T00:00:00.000Z" } as const;
const ana = { id: "u1", nombreUsuario: "ana_m" };
const mensajes = [
  { id: "m1", remitente: ana, contenido: "Hola, ¿el salón incluye mesas y sillas?", creadoEn: "2026-11-05T16:32:00.000Z" },
];
const itemBandeja = {
  id: CONV,
  tipo: "CONSULTA" as const,
  bien: { id: "b1", titulo: "Salón de eventos Las Palmas", foto: null },
  reservaId: null,
  otroParticipante: ana,
  ultimoMensaje: null,
  actualizadaEn: "2026-11-05T16:32:00.000Z",
};
const consultaLista = (cambios: Partial<{ conversacion: typeof itemBandeja | null; otro: typeof ana | null }> = {}): PantallaConsulta => ({
  tipo: "lista",
  usuario: arrendador,
  datos: { conversacionId: CONV, conversacion: itemBandeja, otro: ana, mensajes, ...cambios },
});
const coordinacionLista: PantallaCoordinacion = {
  tipo: "lista",
  usuario: arrendador,
  datos: {
    conversacion: {
      id: "c2",
      reservaId: RESERVA,
      estado: "CONFIRMADA",
      fechaInicio: "2026-11-24",
      fechaFin: "2026-11-25",
      bien: { id: "b1", titulo: "Salón de eventos Las Palmas" },
      arrendador: { id: "u2", nombreUsuario: "mariana_rivas" },
      arrendatario: { id: "u3", nombreUsuario: "luis.perez" },
    },
    foto: null,
    mensajes: [],
  },
};

const errorDeCarga = () => Object.assign(new Error("backend caído"), { name: "ErrorDeCarga" });
const renderizarConsulta = async () => render(await PanelSeleccionado({ seleccion: { tipo: "consulta", conversacionId: CONV } }));
const renderizarReserva = async () => render(await PanelSeleccionado({ seleccion: { tipo: "reserva", reservaId: RESERVA } }));

afterEach(() => vi.clearAllMocks());

describe("panel de la conversación seleccionada (escritorio)", () => {
  it("consulta: título de Figma con el otro participante y el bien, historial y respuesta por id", async () => {
    datos.cargarConsulta.mockResolvedValue(consultaLista());
    acciones.enviarMensaje.mockResolvedValue({ ok: true, mensaje: null });
    await renderizarConsulta();

    expect(datos.cargarConsulta).toHaveBeenCalledWith(CONV, undefined);
    expect(coordinacion.cargarCoordinacion).not.toHaveBeenCalled();
    const titulo = screen.getByRole("heading", { level: 2 });
    expect(within(titulo).getByText("Conversación con ana_m · Salón de eventos Las Palmas")).toHaveClass("hidden", "lg:inline");
    expect(screen.getByText("Hola, ¿el salón incluye mesas y sillas?")).toBeInTheDocument();

    await userEvent.type(screen.getByRole("textbox", { name: /Mensaje/ }), "Sí, incluye mesas");
    await userEvent.click(screen.getByRole("button", { name: "Enviar mensaje" }));
    expect(acciones.enviarMensaje).toHaveBeenCalledWith(CONV, "Sí, incluye mesas");
    expect(acciones.enviarMensajeCoordinacion).not.toHaveBeenCalled();
  });

  it("pasa la pista de la tarjeta a la carga de la consulta", async () => {
    datos.cargarConsulta.mockResolvedValue(consultaLista());
    render(await PanelSeleccionado({ seleccion: { tipo: "consulta", conversacionId: CONV, pista: { filtro: "CONSULTA", pagina: 6 } } }));
    expect(datos.cargarConsulta).toHaveBeenCalledWith(CONV, { filtro: "CONSULTA", pagina: 6 });
  });

  it.each([
    ["sin-permiso", "No tienes acceso a esta conversación."],
    ["no-encontrada", "No encontramos esa conversación."],
  ] as const)("consulta %s: aviso sin historial ni formulario", async (tipo, texto) => {
    datos.cargarConsulta.mockResolvedValue({ tipo, usuario: arrendador });
    await renderizarConsulta();
    expect(screen.getByText(texto)).toBeInTheDocument();
    expect(screen.queryByRole("textbox")).not.toBeInTheDocument();
  });

  it("coordinación: reutiliza la carga de FE-14.1, responde por reserva y un 422 bloquea el envío", async () => {
    coordinacion.cargarCoordinacion.mockResolvedValue(coordinacionLista);
    acciones.enviarMensajeCoordinacion.mockResolvedValue({ ok: false, status: 422 });
    await renderizarReserva();

    expect(coordinacion.cargarCoordinacion).toHaveBeenCalledWith(RESERVA);
    expect(screen.getByText("Conversación con luis.perez · Salón de eventos Las Palmas")).toBeInTheDocument();
    expect(screen.getByText("Acuerda aquí la fecha, la hora y el lugar de la entrega.")).toBeInTheDocument();

    await userEvent.type(screen.getByRole("textbox", { name: /Mensaje/ }), "¿A las 8?");
    await userEvent.click(screen.getByRole("button", { name: "Enviar mensaje" }));
    expect(acciones.enviarMensajeCoordinacion).toHaveBeenCalledWith(RESERVA, "¿A las 8?");
    expect(await screen.findByRole("alert")).toHaveTextContent("La coordinación está disponible cuando la reserva está confirmada o en curso.");
    expect(screen.getByRole("button", { name: "Enviar mensaje" })).toBeDisabled();
  });

  it.each([
    [{ tipo: "no-permitida", estado: "FINALIZADA" }, "Esta reserva está Finalizada."],
    [{ tipo: "no-permitida", estado: null }, "Revisa el estado de la reserva."],
    [{ tipo: "sin-permiso" }, "No tienes acceso a esta conversación."],
    [{ tipo: "no-encontrada" }, "No encontramos esa reserva."],
  ] as const)("coordinación %o: aviso sin historial ni formulario", async (pantalla, texto) => {
    coordinacion.cargarCoordinacion.mockResolvedValue({ ...pantalla, usuario: arrendador });
    await renderizarReserva();
    expect(screen.getByText(texto)).toBeInTheDocument();
    expect(screen.queryByRole("textbox")).not.toBeInTheDocument();
  });

  it("sin sesión (401) pasa por /sesion-vencida", async () => {
    datos.cargarConsulta.mockResolvedValue({ tipo: "sin-sesion" });
    await expect(renderizarConsulta()).rejects.toThrow("REDIRECT:/sesion-vencida");
    coordinacion.cargarCoordinacion.mockResolvedValue({ tipo: "sin-sesion" });
    await expect(renderizarReserva()).rejects.toThrow("REDIRECT:/sesion-vencida");
  });

  it("si la carga falla, el error queda en el panel con «Reintentar» (refresca solo el servidor)", async () => {
    datos.cargarConsulta.mockRejectedValue(errorDeCarga());
    await renderizarConsulta();
    expect(screen.getByRole("alert")).toHaveTextContent("No pudimos cargar esta conversación");
    await userEvent.click(screen.getByRole("button", { name: "Reintentar" }));
    expect(navegacion.refresh).toHaveBeenCalled();
  });

  it("un error que no es de carga no se esconde", async () => {
    coordinacion.cargarCoordinacion.mockRejectedValue(new TypeError("fallo de programación"));
    await expect(renderizarReserva()).rejects.toThrow("fallo de programación");
  });

  it("sin conversación abierta pide elegir una", () => {
    render(<SinSeleccion />);
    expect(screen.getByText("Elige una conversación")).toBeInTheDocument();
  });
});

describe("tituloConsulta: no inventa lo que el backend no dio", () => {
  const base = consultaLista();
  if (base.tipo !== "lista") throw new Error("fixture");
  it.each([
    [base.datos, { movil: "Conversación con ana_m", escritorio: "Conversación con ana_m · Salón de eventos Las Palmas" }],
    [{ ...base.datos, conversacion: null }, { movil: "Conversación con ana_m", escritorio: "Conversación con ana_m" }],
    [{ ...base.datos, conversacion: null, otro: null }, { movil: "Consulta", escritorio: "Consulta" }],
  ])("%#", (datosConsulta, esperado) => {
    expect(tituloConsulta(datosConsulta)).toEqual(esperado);
  });
});
