import { act, render, screen, waitFor, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, beforeEach, describe, expect, it, vi, type MockInstance } from "vitest";
import type { SeleccionBandeja } from "@/lib/bandeja";

const navegacion = vi.hoisted(() => ({ push: vi.fn(), refresh: vi.fn() }));
vi.mock("next/navigation", () => ({ useRouter: () => navegacion }));

const { BandejaDeMensajes } = await import("../bandeja-de-mensajes");

const RESERVA = "22222222-2222-4222-8222-222222222222";
const id = (n: number) => `00000000-0000-4000-8000-${String(n).padStart(12, "0")}`;

type Item = Record<string, unknown>;
const consulta = (n: number, cambios: Item = {}): Item => ({
  id: id(n),
  tipo: "CONSULTA",
  bien: { id: `b${n}`, titulo: `Bien ${n}`, fotoPrincipalUrl: null },
  reservaId: null,
  otroParticipante: { id: `u${n}`, nombreUsuario: `persona_${n}` },
  ultimoMensaje: { contenido: `Último mensaje ${n}`, enviadoEn: "2026-11-20T16:42:00.000Z", remitenteId: `u${n}` },
  actualizadaEn: "2026-11-20T16:42:00.000Z",
  ...cambios,
});
const coordinacion = (n: number, cambios: Item = {}): Item =>
  consulta(n, { tipo: "COORDINACION", reservaId: RESERVA, ...cambios });
const pagina = (items: Item[], hayMas = false, n = 1) => ({ items, pagina: n, total: items.length, hayMas });

const fetchSimulado = vi.fn<(url: string, init?: RequestInit) => Promise<Response>>();
const urls = () => fetchSimulado.mock.calls.map(([url]) => url);
const responderCon = (datos: unknown, status = 200) => Promise.resolve(Response.json(datos, { status }));

let escritorio = false;
let errorDeConsola: MockInstance<typeof console.error>;

beforeEach(() => {
  vi.useFakeTimers({ toFake: ["Date"] });
  vi.setSystemTime(new Date("2026-11-20T18:00:00.000Z")); // 12:00 en El Salvador
  vi.stubGlobal("fetch", fetchSimulado);
  escritorio = false;
  vi.stubGlobal("matchMedia", (consultaMedia: string) => ({
    matches: escritorio && consultaMedia === "(min-width: 64rem)",
    addEventListener: () => {},
    removeEventListener: () => {},
  }));
  window.history.replaceState(null, "", "/mensajes");
  errorDeConsola = vi.spyOn(console, "error");
});

afterEach(() => {
  expect(errorDeConsola).not.toHaveBeenCalled();
  errorDeConsola.mockRestore();
  fetchSimulado.mockReset();
  vi.clearAllMocks();
  vi.unstubAllGlobals();
  vi.useRealTimers();
});

function renderizar({
  rol = "ARRENDADOR" as "ARRENDADOR" | "ARRENDATARIO",
  filtroInicial = null as "CONSULTA" | "COORDINACION" | null,
  seleccion = null as SeleccionBandeja | null,
  panel = true,
} = {}) {
  return render(
    <BandejaDeMensajes usuario={{ id: "yo", rol }} filtroInicial={filtroInicial} seleccion={seleccion}>
      {panel ? <section aria-label="Panel de prueba">Panel abierto</section> : undefined}
    </BandejaDeMensajes>,
  );
}
const tarjetas = () => within(screen.getByRole("list", { name: "Conversaciones" })).getAllByRole("link");
const pestana = (nombre: string) => screen.getByRole("tab", { name: nombre });

describe("BandejaDeMensajes", () => {
  it("carga «Todas» (página 1, sin tipo) y muestra las tarjetas en el orden del backend", async () => {
    fetchSimulado.mockImplementation(() =>
      responderCon(
        pagina([
          consulta(1),
          coordinacion(2, { actualizadaEn: "2026-11-19T15:00:00.000Z", ultimoMensaje: { contenido: "Listo", enviadoEn: "2026-11-19T15:00:00.000Z", remitenteId: "yo" } }),
          consulta(3, { actualizadaEn: "2026-11-16T15:00:00.000Z", ultimoMensaje: null }),
        ]),
      ),
    );
    renderizar();
    expect(screen.getByRole("status")).toHaveTextContent("Cargando conversaciones…");

    const [primera, segunda, tercera] = await waitFor(tarjetas);
    expect(urls()).toEqual(["/api/conversaciones?pagina=1"]);
    expect(pestana("Todas")).toHaveAttribute("aria-selected", "true");
    // Bien · tipo, otro participante, último mensaje y fecha relativa de Figma.
    expect(primera).toHaveTextContent("persona_1");
    expect(primera).toHaveTextContent("Bien 1 · Consulta");
    expect(primera).toHaveTextContent("Último mensaje 1");
    expect(primera).toHaveTextContent("10:42");
    expect(segunda).toHaveTextContent("Bien 2 · Entrega");
    expect(segunda).toHaveTextContent("Ayer");
    expect(tercera).toHaveTextContent("Aún no hay mensajes");
    expect(tercera).toHaveTextContent("16/11");
    // No hay contador de no leídos inventado.
    expect(screen.queryByText(/no leíd/i)).not.toBeInTheDocument();
  });

  it("las pestañas filtran por tipo, reinician la paginación y guardan la pestaña en la URL", async () => {
    fetchSimulado.mockImplementation((url) =>
      responderCon(url.includes("COORDINACION") ? pagina([coordinacion(9)]) : url.includes("CONSULTA") ? pagina([consulta(5)]) : pagina([consulta(1)], true)),
    );
    renderizar();
    await waitFor(tarjetas);

    await userEvent.click(pestana("Consultas"));
    await waitFor(() => expect(tarjetas()[0]).toHaveTextContent("persona_5"));
    expect(tarjetas()).toHaveLength(1);
    expect(screen.queryByRole("button", { name: "Cargar más" })).not.toBeInTheDocument();
    expect(window.location.search).toBe("?tipo=CONSULTA");

    await userEvent.click(pestana("Coordinación"));
    await waitFor(() => expect(tarjetas()[0]).toHaveTextContent("persona_9"));
    expect(pestana("Coordinación")).toHaveAttribute("aria-selected", "true");
    expect(urls()).toEqual([
      "/api/conversaciones?pagina=1",
      "/api/conversaciones?tipo=CONSULTA&pagina=1",
      "/api/conversaciones?tipo=COORDINACION&pagina=1",
    ]);
  });

  it("empieza en la pestaña de la URL", async () => {
    fetchSimulado.mockImplementation(() => responderCon(pagina([coordinacion(1)])));
    renderizar({ filtroInicial: "COORDINACION" });
    await waitFor(tarjetas);
    expect(urls()).toEqual(["/api/conversaciones?tipo=COORDINACION&pagina=1"]);
    expect(pestana("Coordinación")).toHaveAttribute("aria-selected", "true");
  });

  it("«Cargar más» pide la página siguiente, no repite conversaciones y desaparece sin `hayMas`", async () => {
    const primeras = Array.from({ length: 20 }, (_, n) => consulta(n + 1));
    fetchSimulado
      .mockImplementationOnce(() => responderCon(pagina(primeras, true)))
      // La 20 subió de página por un mensaje nuevo: no se repite.
      .mockImplementationOnce(() => responderCon(pagina([consulta(20), consulta(21), consulta(22)], false, 2)));
    renderizar();
    await waitFor(() => expect(tarjetas()).toHaveLength(20));

    await userEvent.click(screen.getByRole("button", { name: "Cargar más" }));
    await waitFor(() => expect(tarjetas()).toHaveLength(22));
    expect(urls()[1]).toBe("/api/conversaciones?pagina=2");
    expect(tarjetas().map((t) => within(t).getByText(/^persona_\d+$/).textContent)).toEqual(
      Array.from({ length: 22 }, (_, n) => `persona_${n + 1}`),
    );
    expect(screen.queryByRole("button", { name: "Cargar más" })).not.toBeInTheDocument();
  });

  it("si «Cargar más» falla, conserva lo cargado, avisa y deja reintentar", async () => {
    fetchSimulado
      .mockImplementationOnce(() => responderCon(pagina([consulta(1)], true)))
      .mockImplementationOnce(() => responderCon({ message: "x" }, 500))
      .mockImplementationOnce(() => responderCon(pagina([consulta(2)], false, 2)));
    renderizar();
    await waitFor(tarjetas);
    await userEvent.click(screen.getByRole("button", { name: "Cargar más" }));
    expect(await screen.findByRole("alert")).toHaveTextContent("No pudimos cargar más conversaciones.");
    expect(tarjetas()).toHaveLength(1);

    await userEvent.click(screen.getByRole("button", { name: "Reintentar" }));
    await waitFor(() => expect(tarjetas()).toHaveLength(2));
    expect(urls()).toEqual(["/api/conversaciones?pagina=1", "/api/conversaciones?pagina=2", "/api/conversaciones?pagina=2"]);
    expect(screen.queryByRole("alert")).not.toBeInTheDocument();
  });

  it("al cambiar rápido de pestaña descarta la respuesta vieja (no mezcla resultados)", async () => {
    let soltarTodas!: (r: Response) => void;
    fetchSimulado.mockImplementation((url) =>
      url.includes("CONSULTA")
        ? responderCon(pagina([consulta(5)]))
        : new Promise<Response>((resolver) => {
            soltarTodas = resolver;
          }),
    );
    renderizar();
    await userEvent.click(pestana("Consultas"));
    await waitFor(() => expect(tarjetas()[0]).toHaveTextContent("persona_5"));

    // Llega tarde la respuesta de «Todas».
    await act(async () => soltarTodas(Response.json(pagina([consulta(1), consulta(2)]))));
    expect(tarjetas()).toHaveLength(1);
    expect(tarjetas()[0]).toHaveTextContent("persona_5");
    // La petición vieja se canceló.
    expect(fetchSimulado.mock.calls[0][1]?.signal?.aborted).toBe(true);
  });

  it("un «Cargar más» que llega después de cambiar de pestaña no se mezcla con la pestaña nueva", async () => {
    let soltarPagina2!: (r: Response) => void;
    fetchSimulado.mockImplementation((url) => {
      if (url.includes("pagina=2")) return new Promise<Response>((resolver) => (soltarPagina2 = resolver));
      return responderCon(url.includes("CONSULTA") ? pagina([consulta(5)]) : pagina([consulta(1)], true));
    });
    renderizar();
    await waitFor(tarjetas);
    await userEvent.click(screen.getByRole("button", { name: "Cargar más" }));
    await userEvent.click(pestana("Consultas"));
    await waitFor(() => expect(tarjetas()[0]).toHaveTextContent("persona_5"));

    await act(async () => soltarPagina2(Response.json(pagina([consulta(2), consulta(3)], false, 2))));
    expect(tarjetas()).toHaveLength(1);
    expect(tarjetas()[0]).toHaveTextContent("persona_5");
  });

  it.each([
    ["500", () => responderCon({ message: "x" }, 500)],
    ["cuerpo inesperado", () => responderCon({ items: [{ id: 1 }], pagina: 1, total: 1, hayMas: false })],
    ["sin conexión", () => Promise.reject(new TypeError("Failed to fetch"))],
  ])("error al cargar (%s): aviso con «Reintentar» que vuelve a pedir", async (_caso, fallo) => {
    fetchSimulado.mockImplementationOnce(fallo).mockImplementationOnce(() => responderCon(pagina([consulta(1)])));
    renderizar();
    const aviso = await screen.findByRole("alert");
    expect(aviso).toHaveTextContent("No pudimos cargar tus mensajes");
    await userEvent.click(within(aviso).getByRole("button", { name: "Reintentar" }));
    await waitFor(() => expect(tarjetas()).toHaveLength(1));
    expect(urls()).toEqual(["/api/conversaciones?pagina=1", "/api/conversaciones?pagina=1"]);
  });

  it("401: pasa por /sesion-vencida", async () => {
    fetchSimulado.mockImplementation(() => responderCon({ message: "No autenticado." }, 401));
    renderizar();
    await waitFor(() => expect(navegacion.push).toHaveBeenCalledWith("/sesion-vencida"));
  });

  it.each([
    ["ARRENDADOR", null, "Aún no tienes mensajes", "Las consultas de arrendatarios y las conversaciones de entrega aparecerán aquí."],
    ["ARRENDATARIO", null, "Aún no tienes mensajes", "Tus consultas sobre publicaciones y las conversaciones de entrega aparecerán aquí."],
    ["ARRENDADOR", "CONSULTA", "No tienes consultas", "Cuando un arrendatario pregunte por una de tus publicaciones, verás aquí la conversación."],
    ["ARRENDATARIO", "CONSULTA", "No tienes consultas", "Cuando preguntes por una publicación, verás aquí la conversación."],
    ["ARRENDATARIO", "COORDINACION", "No tienes conversaciones de entrega", "Las conversaciones para coordinar la entrega de tus reservas aparecerán aquí."],
  ] as const)("vacía (%s, %s): «%s»", async (rol, filtroInicial, titulo, mensaje) => {
    fetchSimulado.mockImplementation(() => responderCon(pagina([])));
    renderizar({ rol, filtroInicial });
    expect(await screen.findByText(titulo)).toBeInTheDocument();
    expect(screen.getByText(mensaje)).toBeInTheDocument();
    // Sin conversaciones ni ninguna abierta, no se muestra el panel para elegir.
    expect(screen.queryByText("Panel abierto")).not.toBeInTheDocument();
  });

  describe("móvil: cada conversación abre su propia pantalla", () => {
    it.each(["ARRENDADOR", "ARRENDATARIO"] as const)(
      "%s: la consulta por id de conversación (con su pista, nunca por bien) y la coordinación por reserva",
      async (rol) => {
        fetchSimulado.mockImplementation(() => responderCon(pagina([consulta(1), coordinacion(2)])));
        renderizar({ rol });
        const [c, r] = await waitFor(tarjetas);
        expect(c).toHaveAttribute("href", `/mensajes/${id(1)}?pista=TODAS-1`);
        expect(c.getAttribute("href")).not.toContain("/publicaciones/");
        expect(r).toHaveAttribute("href", `/reservas/${RESERVA}/conversacion`);
        expect(c).not.toHaveAttribute("aria-current");
      },
    );

    it("la pista lleva la pestaña y la página donde apareció la tarjeta («Cargar más»)", async () => {
      fetchSimulado
        .mockImplementationOnce(() => responderCon(pagina([consulta(1)], true)))
        // La 1 vuelve a aparecer en la página 2: conserva su primera página.
        .mockImplementationOnce(() => responderCon(pagina([consulta(1), consulta(2)], false, 2)));
      renderizar({ rol: "ARRENDATARIO", filtroInicial: "CONSULTA" });
      await waitFor(tarjetas);
      await userEvent.click(screen.getByRole("button", { name: "Cargar más" }));
      await waitFor(() => expect(tarjetas()).toHaveLength(2));
      expect(tarjetas()[0]).toHaveAttribute("href", `/mensajes/${id(1)}?pista=CONSULTA-1`);
      expect(tarjetas()[1]).toHaveAttribute("href", `/mensajes/${id(2)}?pista=CONSULTA-2`);
    });

    it("el panel de la conversación es solo de escritorio", async () => {
      fetchSimulado.mockImplementation(() => responderCon(pagina([consulta(1)])));
      renderizar();
      await waitFor(tarjetas);
      expect(screen.getByText("Panel abierto").parentElement).toHaveClass("hidden", "lg:flex");
    });
  });

  describe("escritorio: lista y conversación lado a lado", () => {
    beforeEach(() => {
      escritorio = true;
    });

    it("cada tarjeta abre la conversación al lado (en la URL) y la seleccionada se destaca", async () => {
      fetchSimulado.mockImplementation(() => responderCon(pagina([consulta(1), coordinacion(2)])));
      renderizar({ seleccion: { tipo: "consulta", conversacionId: id(1) } });
      const [c, r] = await waitFor(tarjetas);
      expect(c).toHaveAttribute("href", `/mensajes?consulta=${id(1)}&pista=TODAS-1`);
      expect(r).toHaveAttribute("href", `/mensajes?reserva=${RESERVA}`);
      expect(c).toHaveAttribute("aria-current", "page");
      expect(r).not.toHaveAttribute("aria-current");
      // Lista de 400 px y panel con el resto.
      expect(screen.getByRole("tabpanel")).toHaveClass("lg:w-100");
      expect(screen.getByText("Panel abierto").parentElement).toHaveClass("lg:flex-1");
    });

    it("al cambiar de pestaña conserva la conversación abierta y la lleva en los enlaces", async () => {
      fetchSimulado.mockImplementation((url) =>
        responderCon(url.includes("COORDINACION") ? pagina([coordinacion(2)]) : pagina([consulta(1), coordinacion(2)])),
      );
      renderizar({ seleccion: { tipo: "reserva", reservaId: RESERVA } });
      await waitFor(tarjetas);
      await userEvent.click(pestana("Coordinación"));
      await waitFor(() => expect(tarjetas()).toHaveLength(1));
      expect(window.location.search).toBe(`?tipo=COORDINACION&reserva=${RESERVA}`);
      expect(screen.getByText("Panel abierto")).toBeInTheDocument();
      expect(tarjetas()[0]).toHaveAttribute("aria-current", "page");
      expect(tarjetas()[0]).toHaveAttribute("href", `/mensajes?tipo=COORDINACION&reserva=${RESERVA}`);
    });

    it("con una conversación abierta, el panel sigue aunque la pestaña quede vacía", async () => {
      fetchSimulado.mockImplementation(() => responderCon(pagina([])));
      renderizar({ seleccion: { tipo: "consulta", conversacionId: id(1) } });
      expect(await screen.findByText("Aún no tienes mensajes")).toBeInTheDocument();
      expect(screen.getByText("Panel abierto")).toBeInTheDocument();
    });
  });
});
