import { llamarApi } from "@/lib/api";
import { esId, leerPaginaBandeja, type ConversacionBandeja, type Participante, type PistaBandeja } from "@/lib/bandeja";
import { leerHistorial, type MensajeConversacion } from "@/lib/mensajes";
import { obtenerUsuarioActual, type UsuarioActual } from "@/lib/usuario-actual";

export type { UsuarioActual };

/**
 * Páginas de consultas que se revisan para encontrar los datos de una
 * conversación (bien y otro participante). El backend no tiene
 * `GET /conversaciones/:id`; la bandeja es la única fuente de esos datos.
 */
export const PAGINAS_DE_BUSQUEDA = 5;

export type DatosConsulta = {
  conversacionId: string;
  /** Datos de la bandeja; `null` si la conversación no apareció en las páginas revisadas. */
  conversacion: ConversacionBandeja | null;
  /** Otro participante: de la bandeja o, si no apareció, del historial. `null` si no hay cómo saberlo. */
  otro: Participante | null;
  /** Historial en orden cronológico. */
  mensajes: MensajeConversacion[];
};

export type PantallaConsulta =
  /** Sin sesión o sesión rechazada (401): la página pasa por `/sesion-vencida`. */
  | { tipo: "sin-sesion" }
  /** El usuario no participa en la conversación (403). */
  | { tipo: "sin-permiso"; usuario: UsuarioActual }
  /** El id no es válido, la conversación no existe o es de una reserva (404). */
  | { tipo: "no-encontrada"; usuario: UsuarioActual }
  | { tipo: "lista"; usuario: UsuarioActual; datos: DatosConsulta };

/** Error inesperado del backend: lo muestra `error.tsx` con «Reintentar». */
export class ErrorDeCarga extends Error {
  constructor(recurso: string, status: number) {
    super(status === 0 ? `No se pudo consultar ${recurso}.` : `${recurso} respondió ${status}.`);
    this.name = "ErrorDeCarga";
  }
}

/** Usuario de la sesión para `/mensajes`. */
export async function cargarUsuarioBandeja(): Promise<{ tipo: "sin-sesion" } | { tipo: "ok"; usuario: UsuarioActual }> {
  const sesion = await obtenerUsuarioActual();
  if (sesion.estado === "sin-sesion") return { tipo: "sin-sesion" };
  if (sesion.estado === "error") throw new ErrorDeCarga("auth/me", 0);
  return { tipo: "ok", usuario: sesion.usuario };
}

type Respuesta = Awaited<ReturnType<typeof llamarApi>>;

const rutaPagina = (filtro: "CONSULTA" | null, pagina: number) =>
  filtro ? `conversaciones?tipo=${filtro}&pagina=${pagina}` : `conversaciones?pagina=${pagina}`;

/**
 * Busca la conversación en la bandeja del usuario (solo trae las suyas):
 *
 * 1. La primera página de consultas, pedida en paralelo con el historial.
 * 2. La página de la pista (donde estaba la tarjeta que se abrió), si la hay:
 *    una sola petición aunque la conversación esté más allá de las primeras
 *    `PAGINAS_DE_BUSQUEDA` páginas.
 * 3. Las siguientes páginas de consultas, hasta `PAGINAS_DE_BUSQUEDA` en total
 *    y mientras `hayMas` (para la URL abierta directamente, sin pista).
 *
 * Una página que falla o no se puede leer corta la búsqueda: los datos son
 * solo para el encabezado y el historial ya llegó.
 */
async function buscarEnBandeja(
  conversacionId: string,
  primera: Promise<Respuesta>,
  pista: PistaBandeja | undefined,
): Promise<ConversacionBandeja | null> {
  const pedidas = new Set<string>();
  const revisar = async (filtro: "CONSULTA" | null, pagina: number, respuesta?: Promise<Respuesta>) => {
    const ruta = rutaPagina(filtro, pagina);
    pedidas.add(ruta);
    const { status, datos } = await (respuesta ?? llamarApi(ruta));
    const leida = status === 200 ? leerPaginaBandeja(datos) : null;
    if (!leida) return { encontrada: null, seguir: false };
    const encontrada = leida.items.find(({ id, tipo }) => id === conversacionId && tipo === "CONSULTA") ?? null;
    return { encontrada, seguir: leida.hayMas };
  };

  let resultado = await revisar("CONSULTA", 1, primera);
  if (resultado.encontrada) return resultado.encontrada;
  let hayMas = resultado.seguir;

  if (pista && !pedidas.has(rutaPagina(pista.filtro, pista.pagina))) {
    const conPista = await revisar(pista.filtro, pista.pagina);
    if (conPista.encontrada) return conPista.encontrada;
  }

  for (let pagina = 2; hayMas && pagina <= PAGINAS_DE_BUSQUEDA; pagina++) {
    if (pedidas.has(rutaPagina("CONSULTA", pagina))) continue;
    resultado = await revisar("CONSULTA", pagina);
    if (resultado.encontrada) return resultado.encontrada;
    hayMas = resultado.seguir;
  }
  return null;
}

/**
 * Decide qué muestra una consulta abierta por id (`/mensajes/[conversacionId]`
 * y el panel de la bandeja en escritorio). Solo lee: **nunca abre ni crea una
 * conversación** (eso es `POST /bienes/:bienId/conversacion`, de FE-13.1).
 *
 * 1. Usuario de la sesión (`GET /auth/me`).
 * 2. En paralelo: `GET /conversaciones/:id/mensajes?orden=asc`, que el
 *    backend solo entrega a los dos participantes (403 a los demás; 404 si no
 *    existe o si es de una reserva), y la primera página de consultas de la
 *    bandeja para el bien y el otro participante.
 * 3. Solo si participa, el resto de la búsqueda en la bandeja (con la pista,
 *    si la hay). Sin esos datos la consulta igual se lee y se responde.
 *
 * 401 → sin sesión; 403 → sin permiso; 404 o id inválido → no encontrada; el
 * resto del historial (5xx, sin respuesta, cuerpo inesperado) → `ErrorDeCarga`.
 */
export async function cargarConsulta(conversacionId: string, pista?: PistaBandeja): Promise<PantallaConsulta> {
  const sesion = await obtenerUsuarioActual();
  if (sesion.estado === "sin-sesion") return { tipo: "sin-sesion" };
  if (sesion.estado === "error") throw new ErrorDeCarga("auth/me", 0);
  const { usuario } = sesion;

  if (!esId(conversacionId)) return { tipo: "no-encontrada", usuario };

  const primeraPagina = llamarApi(rutaPagina("CONSULTA", 1));
  const historial = await llamarApi(`conversaciones/${conversacionId}/mensajes?orden=asc`);
  if (historial.status === 401) return { tipo: "sin-sesion" };
  if (historial.status === 403) return { tipo: "sin-permiso", usuario };
  if (historial.status === 404 || historial.status === 400) return { tipo: "no-encontrada", usuario };
  const mensajes = historial.status === 200 ? leerHistorial(historial.datos) : null;
  if (!mensajes) throw new ErrorDeCarga("conversaciones/:id/mensajes", historial.status);

  // Solo después de confirmar que participa se usan los datos de la bandeja.
  const conversacion = await buscarEnBandeja(conversacionId, primeraPagina, pista);
  const otro =
    conversacion?.otroParticipante ??
    mensajes.map(({ remitente }) => remitente).find(({ id }) => id !== usuario.id) ??
    null;

  return { tipo: "lista", usuario, datos: { conversacionId, conversacion, otro, mensajes } };
}
