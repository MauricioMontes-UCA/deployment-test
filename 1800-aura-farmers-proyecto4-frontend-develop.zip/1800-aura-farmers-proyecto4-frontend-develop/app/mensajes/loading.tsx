import { Contenedor, EstadoDePagina } from "@/components/ui";

/** Mientras se consulta la sesión (la lista y la conversación tienen su propia carga). */
export default function Cargando() {
  return (
    <main className="flex-1">
      <Contenedor className="pt-espacio-5 pb-espacio-7 lg:pt-espacio-7 lg:pb-espacio-9">
        <EstadoDePagina tipo="cargando" titulo="Cargando tus mensajes…" />
      </Contenedor>
    </main>
  );
}
