import { render, screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, describe, expect, it, vi } from "vitest";
import type { PantallaConsulta } from "../../datos";

const datos = vi.hoisted(() => ({ cargarConsulta: vi.fn() }));
vi.mock("../../datos", () => datos);
const accion = vi.hoisted(() => ({ enviarMensaje: vi.fn() }));
vi.mock("@/app/actions/conversacion", () => accion);
vi.mock("@/app/actions/coordinacion", () => ({ enviarMensajeCoordinacion: vi.fn() }));
vi.mock("@/app/reservas/[reservaId]/conversacion/datos", () => ({ cargarCoordinacion: vi.fn() }));
vi.mock("@/app/actions/auth", () => ({ cerrarSesion: vi.fn() }));
vi.mock("next/navigation", async (original) => ({
  ...(await original<typeof import("next/navigation")>()),
  redirect: vi.fn((url: string) => {
    throw new Error(`REDIRECT:${url}`);
  }),
}));

const { default: ConsultaPage } = await import("../page");
const { default: ErrorAlCargar } = await import("../error");
const { default: Cargando } = await import("../loading");

const CONV = "11111111-1111-4111-8111-111111111111";
const arrendador = { id: "u2", nombreUsuario: "mariana_rivas", email: "m@example.com", rol: "ARRENDADOR", createdAt: "2026-11-01T00:00:00.000Z" } as const;
const ana = { id: "u1", nombreUsuario: "ana_m" };
const lista: PantallaConsulta = {
  tipo: "lista",
  usuario: arrendador,
  datos: {
    conversacionId: CONV,
    conversacion: {
      id: CONV,
      tipo: "CONSULTA",
      bien: { id: "b1", titulo: "Salón de eventos Las Palmas", foto: null },
      reservaId: null,
      otroParticipante: ana,
      ultimoMensaje: null,
      actualizadaEn: "2026-11-05T16:32:00.000Z",
    },
    otro: ana,
    mensajes: [{ id: "m1", remitente: ana, contenido: "Hola, ¿el salón incluye mesas y sillas?", creadoEn: "2026-11-05T16:32:00.000Z" }],
  },
};

async function renderizar(pantalla: PantallaConsulta, parametros: Record<string, string> = {}, id = CONV) {
  datos.cargarConsulta.mockResolvedValue(pantalla);
  render(
    await ConsultaPage({
      params: Promise.resolve({ conversacionId: id }),
      searchParams: Promise.resolve(parametros),
    } as PageProps<"/mensajes/[conversacionId]">),
  );
}

afterEach(() => vi.clearAllMocks());

describe("/mensajes/[conversacionId]", () => {
  it("el arrendador ve la consulta, con su título, el historial y el regreso a «Consultas»", async () => {
    await renderizar(lista);
    expect(datos.cargarConsulta).toHaveBeenCalledWith(CONV, undefined);
    expect(screen.getByRole("heading", { level: 1, name: "Conversación con ana_m · Salón de eventos Las Palmas" })).toBeInTheDocument();
    const titulo = screen.getByRole("heading", { level: 2 });
    expect(within(titulo).getByText("Conversación con ana_m")).toHaveClass("lg:hidden");
    expect(screen.getByText("Hola, ¿el salón incluye mesas y sillas?")).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "Volver a mensajes" })).toHaveAttribute("href", "/mensajes?tipo=CONSULTA");
  });

  it("acceso directo con la pista de la tarjeta: la usa para buscar los datos y vuelve a esa pestaña", async () => {
    await renderizar(lista, { pista: "TODAS-7" });
    expect(datos.cargarConsulta).toHaveBeenCalledWith(CONV, { filtro: null, pagina: 7 });
    expect(screen.getByRole("link", { name: "Volver a mensajes" })).toHaveAttribute("href", "/mensajes");
  });

  it("una pista inválida se ignora", async () => {
    await renderizar(lista, { pista: "COORDINACION-1" });
    expect(datos.cargarConsulta).toHaveBeenCalledWith(CONV, undefined);
  });

  it("sin datos de la bandeja ni mensajes del otro: se lee y se responde igual, con el título «Consulta»", async () => {
    accion.enviarMensaje.mockResolvedValue({ ok: true, mensaje: null });
    await renderizar({ ...lista, datos: { ...lista.datos, conversacion: null, otro: null, mensajes: [] } });
    expect(screen.getByRole("heading", { level: 1, name: "Consulta" })).toBeInTheDocument();
    await userEvent.type(screen.getByRole("textbox", { name: /Mensaje/ }), "Hola");
    await userEvent.click(screen.getByRole("button", { name: "Enviar mensaje" }));
    expect(accion.enviarMensaje).toHaveBeenCalledWith(CONV, "Hola");
  });

  it("responde por id de conversación (sin abrir una consulta nueva)", async () => {
    accion.enviarMensaje.mockResolvedValue({ ok: true, mensaje: { id: "m2", remitente: { id: "u2", nombreUsuario: "mariana_rivas" }, contenido: "Sí, incluye", creadoEn: "2026-11-05T16:40:00.000Z" } });
    await renderizar(lista);
    await userEvent.type(screen.getByRole("textbox", { name: /Mensaje/ }), "Sí, incluye");
    await userEvent.click(screen.getByRole("button", { name: "Enviar mensaje" }));
    expect(accion.enviarMensaje).toHaveBeenCalledWith(CONV, "Sí, incluye");
    expect(await screen.findByText("Sí, incluye")).toBeInTheDocument();
  });

  it("consulta vacía: el texto vacío de la bandeja", async () => {
    await renderizar({ ...lista, datos: { ...lista.datos, mensajes: [] } });
    expect(screen.getByText("Los mensajes de esta consulta aparecerán aquí.")).toBeInTheDocument();
  });

  it.each([
    ["sin-permiso", "No tienes acceso a esta conversación."],
    ["no-encontrada", "No encontramos esa conversación."],
  ] as const)("%s: aviso sin historial, con regreso a la bandeja", async (tipo, texto) => {
    await renderizar({ tipo, usuario: arrendador });
    expect(screen.getByText(texto)).toBeInTheDocument();
    expect(screen.queryByRole("textbox")).not.toBeInTheDocument();
    expect(screen.getByRole("link", { name: "Volver a mensajes" })).toHaveAttribute("href", "/mensajes?tipo=CONSULTA");
  });

  it("sin sesión → /sesion-vencida", async () => {
    await expect(renderizar({ tipo: "sin-sesion" })).rejects.toThrow("REDIRECT:/sesion-vencida");
  });

  it("error.tsx reintenta y loading.tsx anuncia la carga", async () => {
    const retry = vi.fn();
    const { unmount } = render(<ErrorAlCargar error={new Error("x")} retry={retry} />);
    expect(screen.getByRole("alert")).toHaveTextContent("No pudimos cargar la conversación");
    await userEvent.click(screen.getByRole("button", { name: "Reintentar" }));
    expect(retry).toHaveBeenCalled();
    unmount();
    render(<Cargando />);
    expect(screen.getByRole("status")).toHaveTextContent("Cargando la conversación…");
  });
});
