"use client"; // Los error boundaries son componentes de cliente.

import { Boton, Contenedor, EstadoDePagina } from "@/components/ui";

/** Falla inesperada al cargar la consulta (backend caído o respuesta inválida). */
export default function ErrorAlCargar({ retry }: { error: Error & { digest?: string }; retry: () => void }) {
  return (
    <main className="flex-1">
      <Contenedor className="pt-espacio-5 pb-espacio-7 lg:pt-espacio-7 lg:pb-espacio-9">
        <EstadoDePagina
          tipo="error"
          titulo="No pudimos cargar la conversación"
          accion={
            <Boton jerarquia="secundario" onClick={() => retry()}>
              Reintentar
            </Boton>
          }
        />
      </Contenedor>
    </main>
  );
}
