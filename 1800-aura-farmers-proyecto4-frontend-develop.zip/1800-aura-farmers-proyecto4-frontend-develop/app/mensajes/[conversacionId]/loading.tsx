import { Contenedor, EstadoDePagina } from "@/components/ui";

/** Mientras se consultan la sesión, el historial y los datos de la consulta. */
export default function Cargando() {
  return (
    <main className="flex-1">
      <Contenedor className="pt-espacio-5 pb-espacio-7 lg:pt-espacio-7 lg:pb-espacio-9">
        <EstadoDePagina tipo="cargando" titulo="Cargando la conversación…" />
      </Contenedor>
    </main>
  );
}
