import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import type { ReactNode } from "react";
import { cerrarSesion } from "@/app/actions/auth";
import {
  Contenedor,
  EncabezadoDePagina,
  EstadoDePagina,
  Icono,
  NavegacionSuperior,
  PieDePagina,
  clasesBoton,
} from "@/components/ui";
import { leerPista, primerValor, rutaBandeja } from "@/lib/bandeja";
import { cargarConsulta, type UsuarioActual } from "../datos";
import { PanelDeConsulta, tituloConsulta } from "../paneles";

export const metadata: Metadata = { title: "Consulta · Arre" };

function Marco({ usuario, children }: { usuario: UsuarioActual; children: ReactNode }) {
  return (
    <>
      <NavegacionSuperior
        rol={usuario.rol === "ARRENDADOR" ? "arrendador" : "arrendatario"}
        nombreUsuario={usuario.nombreUsuario}
        onCerrarSesion={cerrarSesion}
      />
      <main className="flex-1">
        <Contenedor className="flex flex-col gap-espacio-4 pt-espacio-5 pb-espacio-7 lg:gap-espacio-6 lg:pt-espacio-7 lg:pb-espacio-9">
          {children}
        </Contenedor>
      </main>
      <PieDePagina />
    </>
  );
}

const volver = (href: string) => (
  <Link href={href} className={clasesBoton({ jerarquia: "secundario" })}>
    Volver a mensajes
  </Link>
);

/**
 * Consulta abierta por id de conversación (FE-13.2): la pantalla propia de
 * una consulta en móvil, para los dos roles. Solo lee el historial y responde
 * (`GET`/`POST /conversaciones/:id/mensajes`): nunca crea una conversación
 * y no depende de que la publicación siga ACTIVA.
 *
 * `?pista=` (opcional) dice en qué pestaña y página de la bandeja estaba la
 * tarjeta: sirve para encontrar el bien y el otro participante, y para volver
 * a esa pestaña.
 */
export default async function ConsultaPage({ params, searchParams }: PageProps<"/mensajes/[conversacionId]">) {
  const { conversacionId } = await params;
  const pista = leerPista(primerValor((await searchParams).pista)) ?? undefined;
  const regreso = rutaBandeja(pista ? pista.filtro : "CONSULTA", null);
  const pantalla = await cargarConsulta(conversacionId, pista);

  switch (pantalla.tipo) {
    case "sin-sesion":
      redirect("/sesion-vencida");

    case "sin-permiso":
      return (
        <Marco usuario={pantalla.usuario}>
          <EstadoDePagina
            tipo="sin-permiso"
            titulo="No tienes acceso a esta conversación."
            mensaje="Solo participan las dos personas de la conversación."
            accion={volver(regreso)}
          />
        </Marco>
      );

    case "no-encontrada":
      return (
        <Marco usuario={pantalla.usuario}>
          <EstadoDePagina
            tipo="no-encontrado"
            titulo="No encontramos esa conversación."
            mensaje="Revisa el enlace o búscala en tu bandeja."
            accion={volver(regreso)}
          />
        </Marco>
      );

    case "lista": {
      const { usuario, datos } = pantalla;
      const titulo = tituloConsulta(datos);
      return (
        <Marco usuario={usuario}>
          <Link
            href={regreso}
            className="texto-etiqueta inline-flex items-center gap-espacio-1 self-start text-texto-secundario underline-offset-2 hover:underline"
          >
            <Icono nombre="chevron-izquierda" tamano={16} />
            Volver a mensajes
          </Link>
          {/* En móvil el título lo da el panel; el h1 queda para lectores de pantalla (como FE-13.1 y FE-14.1). */}
          <div className="sr-only lg:not-sr-only">
            <EncabezadoDePagina sobretitulo="Consulta" titulo={titulo.escritorio} />
          </div>
          <PanelDeConsulta usuario={usuario} datos={datos} />
        </Marco>
      );
    }
  }
}
