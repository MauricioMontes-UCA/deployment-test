import { redirect } from "next/navigation";
import { enviarMensaje } from "@/app/actions/conversacion";
import { enviarMensajeCoordinacion } from "@/app/actions/coordinacion";
import { cargarCoordinacion, type PantallaCoordinacion } from "@/app/reservas/[reservaId]/conversacion/datos";
import { PanelDeConversacion } from "@/components/mensajeria/panel-de-conversacion";
import { EstadoDePagina } from "@/components/ui";
import type { SeleccionBandeja } from "@/lib/bandeja";
import { ESTADO_VISUAL, TEXTOS_COORDINACION, otroParticipante } from "@/lib/coordinacion";
import { cargarConsulta, type DatosConsulta, type PantallaConsulta, type UsuarioActual } from "./datos";
import { BotonReintentar } from "./reintentar";

/** Estado vacío de una consulta, para los dos participantes. */
export const VACIO_CONSULTA = {
  titulo: "Aún no hay mensajes",
  mensaje: "Los mensajes de esta consulta aparecerán aquí.",
};

/** Título de Figma 30:1397: «Conversación con ana_m · Salón de eventos Las Palmas», sin inventar lo que falte. */
export function tituloConsulta({ otro, conversacion }: DatosConsulta) {
  const bien = conversacion?.bien.titulo;
  const con = otro ? `Conversación con ${otro.nombreUsuario}` : "Consulta";
  return { movil: con, escritorio: bien ? `${con} · ${bien}` : con };
}

/** Panel de una consulta abierta por id. Responde con la acción de FE-13.1 (`POST /conversaciones/:id/mensajes`). */
export function PanelDeConsulta({
  usuario,
  datos,
  className,
}: {
  usuario: UsuarioActual;
  datos: DatosConsulta;
  className?: string;
}) {
  return (
    <PanelDeConversacion
      usuario={usuario}
      titulo={tituloConsulta(datos)}
      vacio={VACIO_CONSULTA}
      mensajesIniciales={datos.mensajes}
      enviar={enviarMensaje.bind(null, datos.conversacionId)}
      className={className}
    />
  );
}

const SIN_PERMISO = { titulo: "No tienes acceso a esta conversación.", mensaje: "Solo participan las dos personas de la conversación." };
const NO_ENCONTRADA = { titulo: "No encontramos esa conversación.", mensaje: "Elige otra conversación de la lista." };

/** Una carga que falló por el backend (5xx, sin respuesta, cuerpo inesperado): las dos cargas usan este nombre. */
const esErrorDeCarga = (error: unknown) => error instanceof Error && error.name === "ErrorDeCarga";

/**
 * Conversación abierta al lado de la bandeja, en escritorio. Reutiliza las
 * cargas de cada pantalla, con sus mismas reglas:
 * - consulta: `cargarConsulta` (por id; nunca abre una conversación);
 * - coordinación: `cargarCoordinacion` de FE-14.1 (por reserva; solo
 *   CONFIRMADA o EN_CURSO, comprobado antes de pedir el historial).
 *
 * Los errores quedan dentro del panel, con «Reintentar»: la lista sigue usable.
 */
export async function PanelSeleccionado({ seleccion }: { seleccion: SeleccionBandeja }) {
  const clase = "w-full";
  let carga: { tipo: "consulta"; pantalla: PantallaConsulta } | { tipo: "reserva"; pantalla: PantallaCoordinacion } | null;
  try {
    carga =
      seleccion.tipo === "consulta"
        ? { tipo: "consulta", pantalla: await cargarConsulta(seleccion.conversacionId, seleccion.pista) }
        : { tipo: "reserva", pantalla: await cargarCoordinacion(seleccion.reservaId) };
  } catch (error) {
    if (!esErrorDeCarga(error)) throw error;
    carga = null;
  }

  if (!carga) {
    return (
      <EstadoDePagina
        tipo="error"
        titulo="No pudimos cargar esta conversación"
        accion={<BotonReintentar />}
        className={clase}
      />
    );
  }

  if (carga.tipo === "consulta") {
    const { pantalla } = carga;
    switch (pantalla.tipo) {
      case "sin-sesion":
        redirect("/sesion-vencida");
      case "sin-permiso":
        return <EstadoDePagina tipo="sin-permiso" {...SIN_PERMISO} className={clase} />;
      case "no-encontrada":
        return <EstadoDePagina tipo="no-encontrado" {...NO_ENCONTRADA} className={clase} />;
      case "lista":
        return (
          <PanelDeConsulta
            key={pantalla.datos.conversacionId}
            usuario={pantalla.usuario}
            datos={pantalla.datos}
            className={clase}
          />
        );
    }
  }

  const { pantalla } = carga;
  switch (pantalla.tipo) {
    case "sin-sesion":
      redirect("/sesion-vencida");
    case "sin-permiso":
      return (
        <EstadoDePagina
          tipo="sin-permiso"
          titulo={TEXTOS_COORDINACION.sinPermisoTitulo}
          mensaje={TEXTOS_COORDINACION.sinPermisoMensaje}
          className={clase}
        />
      );
    case "no-encontrada":
      return (
        <EstadoDePagina
          tipo="no-encontrado"
          titulo={TEXTOS_COORDINACION.noEncontradaTitulo}
          mensaje={TEXTOS_COORDINACION.noEncontradaMensaje}
          className={clase}
        />
      );
    case "no-permitida":
      // Figma 30:1167: sin historial ni formulario.
      return (
        <EstadoDePagina
          tipo="sin-permiso"
          icono="candado"
          titulo={TEXTOS_COORDINACION.noPermitida}
          mensaje={
            pantalla.estado ? `Esta reserva está ${ESTADO_VISUAL[pantalla.estado].texto}.` : "Revisa el estado de la reserva."
          }
          className={clase}
        />
      );
    case "lista": {
      const { usuario, datos } = pantalla;
      const otro = otroParticipante(datos.conversacion, usuario.id).nombreUsuario;
      return (
        <PanelDeConversacion
          key={datos.conversacion.reservaId}
          usuario={usuario}
          titulo={{
            movil: `Coordinación con ${otro}`,
            escritorio: `Conversación con ${otro} · ${datos.conversacion.bien.titulo}`,
          }}
          vacio={{ titulo: TEXTOS_COORDINACION.vacioTitulo, mensaje: TEXTOS_COORDINACION.vacioMensaje }}
          mensajesIniciales={datos.mensajes}
          enviar={enviarMensajeCoordinacion.bind(null, datos.conversacion.reservaId)}
          bloqueos={{ 422: TEXTOS_COORDINACION.noPermitida }}
          className={clase}
        />
      );
    }
  }
}

/** Escritorio sin conversación abierta. */
export function SinSeleccion() {
  return (
    <EstadoDePagina
      tipo="vacio"
      icono="mensaje"
      titulo="Elige una conversación"
      mensaje="Selecciona una conversación de la lista para ver sus mensajes y responder."
      className="w-full"
    />
  );
}
