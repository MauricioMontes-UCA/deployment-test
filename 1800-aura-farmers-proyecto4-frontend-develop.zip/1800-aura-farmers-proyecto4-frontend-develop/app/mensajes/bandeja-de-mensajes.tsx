"use client";

import { useRouter } from "next/navigation";
import { useEffect, useRef, useState, useSyncExternalStore, type ReactNode } from "react";
import { Alerta, Boton, Conversacion, EstadoDePagina, PanelDePestana, Pestana, Pestanas } from "@/components/ui";
import {
  FILTROS_BANDEJA,
  esSeleccionada,
  etiquetaBien,
  formatearFechaBandeja,
  leerPaginaBandeja,
  pistaDe,
  rutaBandeja,
  rutaConversacion,
  rutaPuenteBandeja,
  seleccionDe,
  unirPaginas,
  vistaPrevia,
  type ConversacionBandeja,
  type FiltroBandeja,
  type SeleccionBandeja,
} from "@/lib/bandeja";
import type { Rol } from "@/lib/jwt";

type Lista =
  | { estado: "cargando" }
  | { estado: "error" }
  | {
      estado: "lista";
      items: ConversacionBandeja[];
      /** Página en la que apareció cada conversación por primera vez (pista para abrirla). */
      paginas: Readonly<Record<string, number>>;
      pagina: number;
      hayMas: boolean;
      cargandoMas: boolean;
      errorMas: boolean;
    };

/** Ancho `lg` de Tailwind: desde aquí la conversación se abre al lado de la lista. */
const ESCRITORIO = "(min-width: 64rem)";

function suscribirEscritorio(avisar: () => void) {
  if (typeof window.matchMedia !== "function") return () => {};
  const consulta = window.matchMedia(ESCRITORIO);
  consulta.addEventListener("change", avisar);
  return () => consulta.removeEventListener("change", avisar);
}
const esEscritorio = () => typeof window.matchMedia === "function" && window.matchMedia(ESCRITORIO).matches;

/** Textos del estado vacío por pestaña y rol (Figma 30:1515 para «Todas»). */
function textosVacio(filtro: FiltroBandeja, rol: Rol) {
  const arrendador = rol === "ARRENDADOR";
  if (filtro === "CONSULTA") {
    return {
      titulo: "No tienes consultas",
      mensaje: arrendador
        ? "Cuando un arrendatario pregunte por una de tus publicaciones, verás aquí la conversación."
        : "Cuando preguntes por una publicación, verás aquí la conversación.",
    };
  }
  if (filtro === "COORDINACION") {
    return {
      titulo: "No tienes conversaciones de entrega",
      mensaje: "Las conversaciones para coordinar la entrega de tus reservas aparecerán aquí.",
    };
  }
  return {
    titulo: "Aún no tienes mensajes",
    mensaje: arrendador
      ? "Las consultas de arrendatarios y las conversaciones de entrega aparecerán aquí."
      : "Tus consultas sobre publicaciones y las conversaciones de entrega aparecerán aquí.",
  };
}

/** Anota la página de las conversaciones nuevas; las repetidas conservan la primera (como `unirPaginas`). */
function anotarPagina(paginas: Readonly<Record<string, number>>, items: readonly ConversacionBandeja[], pagina: number) {
  const nuevas = { ...paginas };
  for (const { id } of items) nuevas[id] ??= pagina;
  return nuevas;
}

type BandejaDeMensajesProps = {
  usuario: { id: string; rol: Rol };
  /** Pestaña de la URL al entrar. */
  filtroInicial: FiltroBandeja;
  /** Conversación abierta al lado de la lista (escritorio), según la URL. */
  seleccion: SeleccionBandeja | null;
  /** Panel de la conversación seleccionada, o el aviso para elegir una (solo escritorio). */
  children?: ReactNode;
};

/**
 * Bandeja de FE-13.2 (Figma 30:1271 y 30:1429): pestañas, lista paginada y,
 * en escritorio, la conversación seleccionada al lado. En móvil cada
 * conversación abre su propia pantalla: la coordinación por reserva (FE-14.1) y
 * la consulta, para los dos roles, por id de conversación.
 *
 * - Consulta `/api/conversaciones` (puente con el token): 20 por página, en el
 *   orden del backend (más reciente primero); «Cargar más» mientras `hayMas`.
 * - Cambiar de pestaña reinicia la paginación. Cada petición lleva un número:
 *   la respuesta de una petición vieja se descarta, así no se mezclan
 *   resultados al cambiar rápido de pestaña.
 * - Un 401 pasa por `/sesion-vencida`.
 */
export function BandejaDeMensajes({ usuario, filtroInicial, seleccion, children }: BandejaDeMensajesProps) {
  const router = useRouter();
  const [filtro, setFiltro] = useState<FiltroBandeja>(filtroInicial);
  const [lista, setLista] = useState<Lista>({ estado: "cargando" });
  const [intento, setIntento] = useState(0);
  const solicitud = useRef(0);
  const control = useRef<AbortController | null>(null);
  const escritorio = useSyncExternalStore(suscribirEscritorio, esEscritorio, () => false);

  /** Pide una página. Devuelve la página leída, `"sesion"` o `null` si falló o quedó vieja. */
  async function pedir(filtroPedido: FiltroBandeja, pagina: number) {
    const numero = ++solicitud.current;
    control.current?.abort();
    const actual = new AbortController();
    control.current = actual;
    try {
      const respuesta = await fetch(rutaPuenteBandeja(filtroPedido, pagina), {
        signal: actual.signal,
        cache: "no-store",
      });
      if (numero !== solicitud.current) return { vieja: true as const };
      if (respuesta.status === 401) return { sesion: true as const };
      const datos = respuesta.ok ? leerPaginaBandeja(await respuesta.json().catch(() => null)) : null;
      if (numero !== solicitud.current) return { vieja: true as const };
      return { datos };
    } catch {
      return numero === solicitud.current ? { datos: null } : { vieja: true as const };
    }
  }

  useEffect(() => {
    let vigente = true;
    void pedir(filtro, 1).then((resultado) => {
      if (!vigente || "vieja" in resultado) return;
      if ("sesion" in resultado) return router.push("/sesion-vencida");
      const { datos } = resultado;
      setLista(
        datos
          ? {
              estado: "lista",
              items: unirPaginas([], datos.items),
              paginas: anotarPagina({}, datos.items, 1),
              pagina: 1,
              hayMas: datos.hayMas,
              cargandoMas: false,
              errorMas: false,
            }
          : { estado: "error" },
      );
    });
    return () => {
      vigente = false;
    };
    // `pedir` y `router` no cambian el resultado: solo el filtro y el reintento disparan la carga.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filtro, intento]);

  useEffect(() => () => control.current?.abort(), []);

  function cambiarFiltro(nuevo: FiltroBandeja) {
    if (nuevo === filtro) return;
    setLista({ estado: "cargando" });
    setFiltro(nuevo);
    // La pestaña queda en la URL con la conversación abierta, sin volver a pedir la página al servidor.
    window.history.replaceState(null, "", rutaBandeja(nuevo, seleccion));
  }

  function reintentar() {
    setLista({ estado: "cargando" });
    setIntento((n) => n + 1);
  }

  async function cargarMas() {
    if (lista.estado !== "lista" || lista.cargandoMas || !lista.hayMas) return;
    const siguiente = lista.pagina + 1;
    setLista({ ...lista, cargandoMas: true, errorMas: false });
    const resultado = await pedir(filtro, siguiente);
    if ("vieja" in resultado) return;
    if ("sesion" in resultado) return router.push("/sesion-vencida");
    const { datos } = resultado;
    setLista((previa) => {
      if (previa.estado !== "lista") return previa;
      return datos
        ? {
            ...previa,
            items: unirPaginas(previa.items, datos.items),
            paginas: anotarPagina(previa.paginas, datos.items, siguiente),
            pagina: siguiente,
            hayMas: datos.hayMas,
            cargandoMas: false,
          }
        : { ...previa, cargandoMas: false, errorMas: true };
    });
  }

  const vacia = lista.estado === "lista" && lista.items.length === 0;
  // Sin conversaciones ni ninguna abierta, no hay nada que elegir: el estado vacío ocupa todo el ancho.
  const conPanel = children != null && !(vacia && seleccion === null);
  const pestanaActiva = `pestana-${filtro ?? "todas"}`;

  return (
    <div className="flex flex-col gap-espacio-4 lg:gap-espacio-6">
      <Pestanas etiqueta="Filtrar conversaciones">
        {FILTROS_BANDEJA.map(({ tipo, texto }) => (
          <Pestana
            key={texto}
            id={`pestana-${tipo ?? "todas"}`}
            panel="bandeja-lista"
            activa={filtro === tipo}
            onClick={() => cambiarFiltro(tipo)}
          >
            {texto}
          </Pestana>
        ))}
      </Pestanas>

      {/* Figma 30:1338: lista de 400 px, 24 px de separación y el panel con el resto (888 px a 1440). */}
      <div className="flex flex-col gap-espacio-5 lg:flex-row lg:items-start">
        <PanelDePestana
          id="bandeja-lista"
          pestana={pestanaActiva}
          activo
          className={`flex w-full min-w-0 flex-col gap-espacio-4 focus-visible:outline-2 ${conPanel ? "lg:w-100 lg:shrink-0" : ""}`}
        >
          {lista.estado === "cargando" && <EstadoDePagina tipo="cargando" titulo="Cargando conversaciones…" />}

          {lista.estado === "error" && (
            <EstadoDePagina
              tipo="error"
              titulo="No pudimos cargar tus mensajes"
              accion={
                <Boton jerarquia="secundario" onClick={reintentar}>
                  Reintentar
                </Boton>
              }
            />
          )}

          {vacia && <EstadoDePagina tipo="vacio" {...textosVacio(filtro, usuario.rol)} />}

          {lista.estado === "lista" && lista.items.length > 0 && (
            <>
              <ul aria-label="Conversaciones" className="flex flex-col border border-borde-default">
                {lista.items.map((conversacion) => {
                  const pista = pistaDe(filtro, lista.paginas[conversacion.id]);
                  return (
                    <li key={conversacion.id} className="[&:last-child>a]:border-b-0">
                      <Conversacion
                        usuario={conversacion.otroParticipante.nombreUsuario}
                        bien={etiquetaBien(conversacion)}
                        hora={formatearFechaBandeja(conversacion.actualizadaEn)}
                        ultimoMensaje={vistaPrevia(conversacion)}
                        activa={escritorio && esSeleccionada(conversacion, seleccion)}
                        href={
                          escritorio
                            ? rutaBandeja(filtro, seleccionDe(conversacion, pista))
                            : rutaConversacion(conversacion, pista)
                        }
                      />
                    </li>
                  );
                })}
              </ul>

              {lista.errorMas && (
                <Alerta tono="error">No pudimos cargar más conversaciones. Intenta de nuevo.</Alerta>
              )}
              {lista.hayMas && (
                <Boton
                  jerarquia="secundario"
                  cargando={lista.cargandoMas}
                  onClick={() => void cargarMas()}
                  className="self-center"
                >
                  {lista.errorMas ? "Reintentar" : "Cargar más"}
                </Boton>
              )}
            </>
          )}
        </PanelDePestana>

        {conPanel && <div className="hidden min-w-0 lg:flex lg:flex-1">{children}</div>}
      </div>
    </div>
  );
}
