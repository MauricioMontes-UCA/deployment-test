import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { Suspense } from "react";
import { cerrarSesion } from "@/app/actions/auth";
import { Contenedor, EncabezadoDePagina, EstadoDePagina, NavegacionSuperior, PieDePagina } from "@/components/ui";
import { leerParametrosBandeja } from "@/lib/bandeja";
import { BandejaDeMensajes } from "./bandeja-de-mensajes";
import { cargarUsuarioBandeja } from "./datos";
import { PanelSeleccionado, SinSeleccion } from "./paneles";

export const metadata: Metadata = { title: "Mensajes · Arre" };

/** Descripción de Figma 30:1271 para el arrendador; la del arrendatario sigue el mismo patrón. */
const DESCRIPCION = {
  ARRENDADOR: "Consultas sobre tus publicaciones y conversaciones de entrega de tus reservas.",
  ARRENDATARIO: "Tus consultas sobre publicaciones y conversaciones de entrega de tus reservas.",
} as const;

/**
 * FE-13.2: bandeja de mensajes, para arrendador y arrendatario. La lista se
 * carga en el cliente (pestañas y «Cargar más»); la conversación abierta en
 * escritorio llega de la URL (`?consulta=` o `?reserva=`) y se carga aquí,
 * en el servidor, con las mismas reglas de su pantalla propia.
 */
export default async function MensajesPage({ searchParams }: PageProps<"/mensajes">) {
  const sesion = await cargarUsuarioBandeja();
  // Una página no puede borrar cookies: /sesion-vencida las borra y lleva al login (PR #2).
  if (sesion.tipo === "sin-sesion") redirect("/sesion-vencida");
  const { usuario } = sesion;
  const { tipo, seleccion } = leerParametrosBandeja(await searchParams);
  const clave = seleccion ? `${seleccion.tipo}:${seleccion.tipo === "consulta" ? seleccion.conversacionId : seleccion.reservaId}` : "ninguna";

  return (
    <>
      <NavegacionSuperior
        rol={usuario.rol === "ARRENDADOR" ? "arrendador" : "arrendatario"}
        nombreUsuario={usuario.nombreUsuario}
        onCerrarSesion={cerrarSesion}
      />
      <main className="flex-1">
        <Contenedor className="flex flex-col gap-espacio-4 pt-espacio-5 pb-espacio-7 lg:gap-espacio-6 lg:pt-espacio-7 lg:pb-espacio-9">
          <EncabezadoDePagina titulo="Mensajes" descripcion={<span className="hidden lg:inline">{DESCRIPCION[usuario.rol]}</span>} />
          <BandejaDeMensajes usuario={{ id: usuario.id, rol: usuario.rol }} filtroInicial={tipo} seleccion={seleccion}>
            {seleccion ? (
              // La clave hace que cada conversación muestre su propia carga mientras la lista sigue usable.
              <Suspense key={clave} fallback={<EstadoDePagina tipo="cargando" titulo="Cargando la conversación…" className="w-full" />}>
                <PanelSeleccionado seleccion={seleccion} />
              </Suspense>
            ) : (
              <SinSeleccion />
            )}
          </BandejaDeMensajes>
        </Contenedor>
      </main>
      <PieDePagina />
    </>
  );
}
