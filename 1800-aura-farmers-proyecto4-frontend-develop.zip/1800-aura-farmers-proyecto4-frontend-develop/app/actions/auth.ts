"use server";

import { redirect } from "next/navigation";
import {
  cerrarSesionApi,
  iniciarSesionApi,
  registrarUsuarioApi,
} from "@/lib/auth-api";
import type { Rol } from "@/lib/jwt";
import { borrarSesion, guardarSesion, obtenerTokens } from "@/lib/sesion";
import {
  campoDeMensaje,
  validarEmail,
  validarRegistro,
  type ErroresRegistro,
} from "@/lib/validaciones/registro";

// ─── Login ──────────────────────────────────────────────────────────────────

export type EstadoLogin = {
  error?: string;
  /** 401 o 400 del backend: el formulario marca en rojo el correo y la contraseña. */
  credencialesInvalidas?: boolean;
  email?: string;
};


/** Inicia sesión con POST /auth/login y guarda el par de tokens en cookies. */
export async function iniciarSesion(
  _estado: EstadoLogin,
  formData: FormData,
): Promise<EstadoLogin> {
  const email = String(formData.get("email") ?? "").trim();
  const password = String(formData.get("password") ?? "");

  if (!email || !password) return { error: "Ingresa tu correo y contraseña.", email };
  // Mismas reglas que el registro; en el login el mensaje es más general.
  if (validarEmail(email)) return { error: "Ingresa un correo válido.", email };

  const resultado = await iniciarSesionApi(email, password);
  if (!resultado.ok) {
    // 401 y 400 traen un mensaje del backend («Credenciales inválidas.»).
    const credencialesInvalidas = resultado.status === 401 || resultado.status === 400;
    const mensaje = credencialesInvalidas && resultado.mensajes[0];
    return {
      error: mensaje || "No pudimos iniciar sesión. Intenta de nuevo.",
      credencialesInvalidas,
      email,
    };
  }

  await guardarSesion(resultado.datos);
  redirect("/");
}

/** Revoca el refresh token en el backend y borra las cookies. */
export async function cerrarSesion() {
  const { refresh } = await obtenerTokens();
  // Si el backend no responde, igual se cierra la sesión en este navegador.
  if (refresh) await cerrarSesionApi(refresh);
  await borrarSesion();
  redirect("/login");
}

// ─── Registro ───────────────────────────────────────────────────────────────

export type EstadoRegistro = {
  /** Errores por campo (400 del backend o validación del servidor). */
  errores?: ErroresRegistro;
  /** Error que no es de un campo: 409, red o 500. */
  error?: string;
  /** El 409: el formulario lo titula «No pudimos crear tu cuenta», como en Figma. */
  conflicto?: boolean;
  /** Cuántas veces se envió; el formulario lo usa para saber si hay respuesta nueva. */
  envio: number;
};

const ERROR_CONFLICTO = "Ese correo o nombre de usuario ya está registrado.";
const ERROR_GENERAL = "No pudimos crear tu cuenta. Intenta de nuevo.";

/**
 * Registra la cuenta con POST /api/v1/users. Con 201 lleva al login con el
 * aviso «Cuenta creada. Inicia sesión.».
 */
export async function registrar(
  estado: EstadoRegistro,
  formData: FormData,
): Promise<EstadoRegistro> {
  const envio = estado.envio + 1;
  const valores = {
    nombreUsuario: String(formData.get("nombreUsuario") ?? "").trim(),
    email: String(formData.get("email") ?? "").trim(),
    password: String(formData.get("password") ?? ""),
    rol: String(formData.get("rol") ?? ""),
  };

  const errores = validarRegistro(valores);
  if (Object.keys(errores).length > 0) return { errores, envio };

  const resultado = await registrarUsuarioApi({ ...valores, rol: valores.rol as Rol });

  if (!resultado.ok) {
    if (resultado.status === 409) return { error: ERROR_CONFLICTO, conflicto: true, envio };
    if (resultado.status === 400) {
      const erroresApi: ErroresRegistro = {};
      const sinCampo: string[] = [];
      for (const mensaje of resultado.mensajes) {
        const campo = campoDeMensaje(mensaje);
        if (campo) erroresApi[campo] ??= mensaje;
        else sinCampo.push(mensaje);
      }
      const conCampo = Object.keys(erroresApi).length > 0;
      return { errores: erroresApi, error: sinCampo[0] ?? (conCampo ? undefined : ERROR_GENERAL), envio };
    }
    return { error: ERROR_GENERAL, envio };
  }

  redirect("/login?registro=ok");
}
