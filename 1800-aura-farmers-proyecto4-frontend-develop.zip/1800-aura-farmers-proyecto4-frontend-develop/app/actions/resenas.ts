"use server";

import { redirect } from "next/navigation";
import type { ResultadoEnvio } from "@/app/reservas/[reservaId]/calificar/formulario-calificacion";
import { llamarApi } from "@/lib/api";
import { armarPayload, type FormularioResenas } from "@/lib/resenas";

const ID_RESERVA = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Aviso que muestra la reserva tras un envío exitoso (contrato con la pantalla
 * de detalle). No se exporta: un archivo "use server" solo exporta funciones.
 */
const PARAMETRO_EXITO = "resena=enviada";

/**
 * Lo que llega del navegador no es confiable: se reconstruye el formulario con
 * solo los campos esperados y se vuelve a validar con las reglas de la pantalla.
 */
function aFormulario(valor: unknown): FormularioResenas | null {
  if (typeof valor !== "object" || valor === null) return null;
  const leer = (parte: unknown) => {
    if (typeof parte !== "object" || parte === null) return null;
    const { puntuacion, comentario } = parte as Record<string, unknown>;
    if (typeof puntuacion !== "number") return null;
    if (comentario !== undefined && typeof comentario !== "string") return null;
    return { puntuacion, comentario: comentario ?? "" };
  };
  const { bien, arrendador } = valor as Record<string, unknown>;
  const formularioBien = leer(bien);
  const formularioArrendador = leer(arrendador);
  if (!formularioBien || !formularioArrendador) return null;
  return { bien: formularioBien, arrendador: formularioArrendador };
}

/**
 * Envía la reseña del bien y del arrendador (`POST /reservas/:reservaId/resenas`,
 * BE-15.1) con el cliente compartido (`llamarApi`): el token sale de la cookie
 * httpOnly y su renovación la hace el proxy, que también atiende a las server
 * actions.
 *
 * - 201: redirige a `/reservas/{reservaId}?resena=enviada`.
 * - 401 (sin sesión o sesión rechazada): redirige a `/sesion-vencida`, que
 *   borra las cookies, revoca la sesión y lleva al login.
 * - Otro código: `{ ok: false, status }`; sin respuesta (red o tiempo agotado,
 *   `status` 0): `{ ok: false, status: null }`.
 *
 * Valida antes de llamar: un id que no es UUID responde como 404 y un cuerpo
 * inválido como 400, sin tocar el backend.
 */
export async function enviarResenas(reservaId: string, datos: unknown): Promise<ResultadoEnvio> {
  if (typeof reservaId !== "string" || !ID_RESERVA.test(reservaId)) {
    return { ok: false, status: 404 };
  }
  const formulario = aFormulario(datos);
  const payload = formulario && armarPayload(formulario);
  if (!payload) return { ok: false, status: 400 };

  const { status } = await llamarApi(`reservas/${reservaId}/resenas`, {
    method: "POST",
    body: JSON.stringify(payload),
  });

  // `redirect` lanza: va fuera de cualquier try/catch (guía de Next).
  if (status === 0) return { ok: false, status: null };
  if (status === 401) redirect("/sesion-vencida");
  if (status === 201) redirect(`/reservas/${reservaId}?${PARAMETRO_EXITO}`);
  return { ok: false, status };
}
