import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const { redirect, guardarSesion, borrarSesion, obtenerTokens } = vi.hoisted(() => ({
  // redirect de Next lanza para cortar la ejecución; se imita igual.
  redirect: vi.fn((url: string) => {
    throw new Error(`REDIRECT:${url}`);
  }),
  guardarSesion: vi.fn(),
  borrarSesion: vi.fn(),
  obtenerTokens: vi.fn(),
}));

vi.mock("next/navigation", () => ({ redirect }));
vi.mock("@/lib/sesion", () => ({ guardarSesion, borrarSesion, obtenerTokens }));

import { cerrarSesion, iniciarSesion, registrar } from "./auth";

const fetchFalso = vi.fn();

function responder(status: number, cuerpo?: unknown) {
  fetchFalso.mockResolvedValueOnce(
    new Response(cuerpo === undefined ? null : JSON.stringify(cuerpo), { status }),
  );
}

function formulario(valores: Record<string, string>) {
  const datos = new FormData();
  for (const [clave, valor] of Object.entries(valores)) datos.set(clave, valor);
  return datos;
}

const validos = {
  nombreUsuario: "ana_m",
  email: "ana@example.com",
  password: "Str0ngPass",
  rol: "ARRENDATARIO",
};

beforeEach(() => {
  vi.stubEnv("API_URL", "http://api.test/api/v1");
  vi.stubGlobal("fetch", fetchFalso);
});

afterEach(() => {
  vi.unstubAllEnvs();
  vi.unstubAllGlobals();
  vi.clearAllMocks();
  fetchFalso.mockReset();
});

describe("registrar", () => {
  it("con 201 lleva al login con el aviso de cuenta creada", async () => {
    responder(201, { id: "1" });
    await expect(registrar({ envio: 0 }, formulario(validos))).rejects.toThrow(
      "REDIRECT:/login?registro=ok",
    );
    expect(JSON.parse(fetchFalso.mock.calls[0][1].body)).toEqual(validos);
  });

  it("no llama a la API si los datos no son válidos", async () => {
    const estado = await registrar({ envio: 0 }, formulario({ ...validos, nombreUsuario: "ab", rol: "" }));
    expect(fetchFalso).not.toHaveBeenCalled();
    expect(estado.errores?.nombreUsuario).toBe("El nombre de usuario debe tener al menos 3 caracteres.");
    expect(estado.errores?.rol).toBeDefined();
    expect(estado.envio).toBe(1);
  });

  it("con 400 pone cada mensaje del backend en su campo", async () => {
    responder(400, {
      message: [
        "El nombre de usuario solo puede incluir letras, números, punto, guion y guion bajo.",
        "El email no tiene un formato válido.",
      ],
      statusCode: 400,
    });
    const estado = await registrar({ envio: 0 }, formulario(validos));
    expect(estado.errores).toEqual({
      nombreUsuario: "El nombre de usuario solo puede incluir letras, números, punto, guion y guion bajo.",
      email: "El email no tiene un formato válido.",
    });
    expect(estado.error).toBeUndefined();
  });

  it("con un 400 sin campo reconocible muestra un error general", async () => {
    responder(400, { message: ["property extra should not exist"], statusCode: 400 });
    const estado = await registrar({ envio: 0 }, formulario(validos));
    expect(estado.error).toBe("property extra should not exist");
  });

  it("con 409 avisa que el correo o el usuario ya existe", async () => {
    responder(409, { message: "El nombre de usuario ya está registrado.", statusCode: 409 });
    const estado = await registrar({ envio: 0 }, formulario(validos));
    expect(estado.error).toBe("Ese correo o nombre de usuario ya está registrado.");
  });

  it.each([
    ["500", () => responder(500, { message: "Internal server error" })],
    ["red caída", () => fetchFalso.mockRejectedValueOnce(new TypeError("fetch failed"))],
  ])("con %s muestra el error general", async (_caso, preparar) => {
    preparar();
    const estado = await registrar({ envio: 0 }, formulario(validos));
    expect(estado.error).toBe("No pudimos crear tu cuenta. Intenta de nuevo.");
  });
});

describe("iniciarSesion", () => {
  it("guarda la sesión y lleva al inicio", async () => {
    const sesion = { accessToken: "a", refreshToken: "r", expiresIn: 900, user: {} };
    responder(200, sesion);
    await expect(
      iniciarSesion({}, formulario({ email: "ana@example.com", password: "Str0ngPass" })),
    ).rejects.toThrow("REDIRECT:/");
    expect(guardarSesion).toHaveBeenCalledWith(sesion);
  });

  it("con 401 muestra el mensaje del backend y conserva el correo", async () => {
    responder(401, { message: "Credenciales inválidas.", statusCode: 401 });
    const estado = await iniciarSesion({}, formulario({ email: "ana@example.com", password: "mala" }));
    expect(estado).toEqual({
      error: "Credenciales inválidas.",
      credencialesInvalidas: true,
      email: "ana@example.com",
    });
    expect(guardarSesion).not.toHaveBeenCalled();
  });
});

describe("cerrarSesion", () => {
  it("revoca el refresh token en el backend y borra las cookies", async () => {
    obtenerTokens.mockResolvedValueOnce({ acceso: "a", refresh: "r" });
    responder(204);
    await expect(cerrarSesion()).rejects.toThrow("REDIRECT:/login");
    expect(JSON.parse(fetchFalso.mock.calls[0][1].body)).toEqual({ refreshToken: "r" });
    expect(borrarSesion).toHaveBeenCalled();
  });

  it("borra las cookies aunque el backend no responda", async () => {
    obtenerTokens.mockResolvedValueOnce({ acceso: "a", refresh: "r" });
    fetchFalso.mockRejectedValueOnce(new TypeError("fetch failed"));
    await expect(cerrarSesion()).rejects.toThrow("REDIRECT:/login");
    expect(borrarSesion).toHaveBeenCalled();
  });
});
