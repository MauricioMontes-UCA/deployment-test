"use server";

import { redirect } from "next/navigation";
import { llamarApi } from "@/lib/api";
import {
  armarPayloadArrendatario,
  leerResumenCalificacion,
  type ResultadoCalificacion,
} from "@/lib/calificacion-arrendatario";

const ID_RESERVA = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Lo que llega del navegador no es confiable: se reconstruye la calificación
 * con solo los campos esperados y se vuelve a validar con las reglas de la
 * pantalla.
 */
function aCalificacion(valor: unknown) {
  if (typeof valor !== "object" || valor === null) return null;
  const { puntuacion, comentario } = valor as Record<string, unknown>;
  if (typeof puntuacion !== "number") return null;
  if (comentario !== undefined && typeof comentario !== "string") return null;
  return { puntuacion, comentario: comentario ?? "" };
}

/**
 * Envía la calificación del arrendatario (`POST /reservas/:reservaId/resenas/arrendatario`,
 * BE-16.1) con el cliente compartido (`llamarApi`): el token sale de la cookie
 * httpOnly y su renovación la hace el proxy, que también atiende a las server
 * actions.
 *
 * - 201: `{ ok: true, promedioArrendatario, totalCalificaciones }` con los
 *   datos reales de la respuesta. No redirige: la pantalla pasa a solo lectura.
 * - 401 (sin sesión o sesión rechazada): redirige a `/sesion-vencida`.
 * - Otro código: `{ ok: false, status }`; sin respuesta (red o tiempo agotado,
 *   `status` 0): `{ ok: false, status: null }`.
 *
 * Valida antes de llamar: un id que no es UUID responde como 404 y un cuerpo
 * inválido como 400, sin tocar el backend.
 */
export async function calificarArrendatario(
  reservaId: string,
  datos: unknown,
): Promise<ResultadoCalificacion> {
  if (typeof reservaId !== "string" || !ID_RESERVA.test(reservaId)) {
    return { ok: false, status: 404 };
  }
  const calificacion = aCalificacion(datos);
  const payload = calificacion && armarPayloadArrendatario(calificacion);
  if (!payload) return { ok: false, status: 400 };

  const respuesta = await llamarApi(`reservas/${reservaId}/resenas/arrendatario`, {
    method: "POST",
    body: JSON.stringify(payload),
  });

  // `redirect` lanza: va fuera de cualquier try/catch (guía de Next).
  if (respuesta.status === 0) return { ok: false, status: null };
  if (respuesta.status === 401) redirect("/sesion-vencida");
  if (respuesta.status === 201) return { ok: true, ...leerResumenCalificacion(respuesta.datos) };
  return { ok: false, status: respuesta.status };
}
