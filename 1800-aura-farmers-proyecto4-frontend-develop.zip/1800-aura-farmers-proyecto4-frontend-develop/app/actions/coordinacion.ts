"use server";

import { redirect } from "next/navigation";
import { llamarApi } from "@/lib/api";
import { leerMensaje, validarMensaje, type ResultadoEnvioMensaje } from "@/lib/mensajes";

const ID_RESERVA = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Envía un mensaje a la coordinación de una reserva
 * (`POST /reservas/:reservaId/conversacion/mensajes`, BE-14.1) con el cliente
 * compartido (`llamarApi`). Mismo contrato que `enviarMensaje` de la consulta
 * previa: el texto viaja tal cual y se vuelve a validar aquí (id inválido →
 * 404, texto inválido → 400) antes de llamar al backend.
 *
 * - 201: el mensaje real del backend.
 * - 401: `/sesion-vencida`, que borra las cookies y lleva al login.
 * - 422 (la reserva dejó de estar CONFIRMADA o EN_CURSO), 403, 404, 409…: el código.
 * - Sin respuesta: `status: null`.
 *
 * El aviso al otro participante («Mensaje sobre la entrega») lo crea el backend.
 */
export async function enviarMensajeCoordinacion(
  reservaId: string,
  contenido: unknown,
): Promise<ResultadoEnvioMensaje> {
  if (typeof reservaId !== "string" || !ID_RESERVA.test(reservaId)) {
    return { ok: false, status: 404 };
  }
  if (typeof contenido !== "string" || validarMensaje(contenido)) {
    return { ok: false, status: 400 };
  }

  const { status, datos } = await llamarApi(`reservas/${reservaId}/conversacion/mensajes`, {
    method: "POST",
    body: JSON.stringify({ contenido }),
  });

  // `redirect` lanza: va fuera de cualquier try/catch (guía de Next).
  if (status === 0) return { ok: false, status: null };
  if (status === 401) redirect("/sesion-vencida");
  if (status === 201) return { ok: true, mensaje: leerMensaje(datos) };
  return { ok: false, status };
}
