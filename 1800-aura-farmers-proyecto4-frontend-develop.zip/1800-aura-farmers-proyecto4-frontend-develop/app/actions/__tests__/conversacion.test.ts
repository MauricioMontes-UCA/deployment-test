import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

// Se prueba la server action con el cliente compartido real (`llamarApi` de
// `lib/api.ts`, PR #2) y solo se simulan la cookie, la red y `redirect`.
const almacen = vi.hoisted(() => ({ acceso: "token-de-prueba" as string | undefined }));
vi.mock("next/headers", () => ({
  cookies: async () => ({
    get: (nombre: string) =>
      nombre === "access_token" && almacen.acceso ? { name: nombre, value: almacen.acceso } : undefined,
  }),
}));
vi.mock("next/navigation", () => ({
  redirect: vi.fn((url: string) => {
    throw new Error(`REDIRECT:${url}`);
  }),
}));

const { enviarMensaje } = await import("@/app/actions/conversacion");

const CONVERSACION = "0b6c7d8e-1f2a-4b3c-8d4e-5f6a7b8c9d0e";
const URL_MENSAJES = `http://localhost:3000/api/v1/conversaciones/${CONVERSACION}/mensajes`;
const fetchSimulado = vi.fn();

const respuesta = (status: number, cuerpo: unknown = {}) =>
  new Response(JSON.stringify(cuerpo), { status, headers: { "Content-Type": "application/json" } });

const mensajeApi = {
  id: "m9",
  conversacionId: CONVERSACION,
  remitente: { id: "u1", nombreUsuario: "ana_m" },
  contenido: "  ¿Tiene parqueo? 🚗\n",
  creadoEn: "2026-11-05T16:50:00.000Z",
};

beforeEach(() => {
  vi.stubEnv("API_URL", "http://localhost:3000/api/v1");
  vi.stubGlobal("fetch", fetchSimulado);
  almacen.acceso = "token-de-prueba";
});

afterEach(() => {
  vi.unstubAllEnvs();
  vi.unstubAllGlobals();
  vi.resetAllMocks();
});

describe("enviarMensaje", () => {
  it("hace POST con Bearer y el texto original, sin recortar, y devuelve el mensaje real del 201", async () => {
    fetchSimulado.mockResolvedValue(respuesta(201, mensajeApi));

    const resultado = await enviarMensaje(CONVERSACION, "  ¿Tiene parqueo? 🚗\n");

    expect(fetchSimulado).toHaveBeenCalledOnce();
    const [url, init] = fetchSimulado.mock.calls[0];
    expect(String(url)).toBe(URL_MENSAJES);
    expect(init.method).toBe("POST");
    expect(init.headers.Authorization).toBe("Bearer token-de-prueba");
    expect(init.headers["Content-Type"]).toBe("application/json");
    expect(JSON.parse(init.body)).toEqual({ contenido: "  ¿Tiene parqueo? 🚗\n" });
    expect(resultado).toEqual({
      ok: true,
      mensaje: {
        id: "m9",
        remitente: { id: "u1", nombreUsuario: "ana_m" },
        contenido: "  ¿Tiene parqueo? 🚗\n",
        creadoEn: "2026-11-05T16:50:00.000Z",
      },
    });
  });

  it("un 201 con cuerpo inesperado sigue siendo éxito, pero sin inventar el mensaje", async () => {
    fetchSimulado.mockResolvedValue(respuesta(201, { raro: true }));
    expect(await enviarMensaje(CONVERSACION, "Hola")).toEqual({ ok: true, mensaje: null });
  });

  it.each([
    ["vacío", ""],
    ["solo espacios", "   \n "],
    ["1001 caracteres", "a".repeat(1001)],
    ["no es texto", 42],
  ])("contenido inválido (%s) → 400 sin llamar al backend", async (_caso, contenido) => {
    expect(await enviarMensaje(CONVERSACION, contenido)).toEqual({ ok: false, status: 400 });
    expect(fetchSimulado).not.toHaveBeenCalled();
  });

  it("acepta 1000 emojis (contados por punto de código)", async () => {
    fetchSimulado.mockResolvedValue(respuesta(201, { ...mensajeApi, contenido: "😀".repeat(1000) }));
    const resultado = await enviarMensaje(CONVERSACION, "😀".repeat(1000));
    expect(resultado.ok).toBe(true);
    expect(fetchSimulado).toHaveBeenCalledOnce();
  });

  it("un id que no es UUID → 404 sin llamar al backend", async () => {
    expect(await enviarMensaje("../auth/me", "Hola")).toEqual({ ok: false, status: 404 });
    expect(fetchSimulado).not.toHaveBeenCalled();
  });

  it("401 lleva a /sesion-vencida", async () => {
    fetchSimulado.mockResolvedValue(respuesta(401, { message: "Unauthorized" }));
    await expect(enviarMensaje(CONVERSACION, "Hola")).rejects.toThrow("REDIRECT:/sesion-vencida");
  });

  it.each([400, 403, 404, 500, 503])("%i → { ok: false, status }", async (status) => {
    fetchSimulado.mockResolvedValue(respuesta(status, { message: "x" }));
    expect(await enviarMensaje(CONVERSACION, "Hola")).toEqual({ ok: false, status });
  });

  it("sin respuesta (red caída) → status null", async () => {
    fetchSimulado.mockRejectedValue(new TypeError("fetch failed"));
    expect(await enviarMensaje(CONVERSACION, "Hola")).toEqual({ ok: false, status: null });
  });
});
