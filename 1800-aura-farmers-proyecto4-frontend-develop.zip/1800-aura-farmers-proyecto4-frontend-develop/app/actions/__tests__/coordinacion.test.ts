import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

// Se prueba la server action con el cliente compartido real (`llamarApi` de
// `lib/api.ts`) y solo se simulan la cookie, la red y `redirect`.
const almacen = vi.hoisted(() => ({ acceso: "token-de-prueba" as string | undefined }));
vi.mock("next/headers", () => ({
  cookies: async () => ({
    get: (nombre: string) =>
      nombre === "access_token" && almacen.acceso ? { name: nombre, value: almacen.acceso } : undefined,
  }),
}));
vi.mock("next/navigation", () => ({
  redirect: vi.fn((url: string) => {
    throw new Error(`REDIRECT:${url}`);
  }),
}));

const { enviarMensajeCoordinacion } = await import("@/app/actions/coordinacion");

const RESERVA = "5a3f2c10-8d4e-4b1a-9c7e-1f2a3b4c5d6e";
const URL_MENSAJES = `http://localhost:3000/api/v1/reservas/${RESERVA}/conversacion/mensajes`;
const fetchSimulado = vi.fn();

const respuesta = (status: number, cuerpo: unknown = {}) =>
  new Response(JSON.stringify(cuerpo), { status, headers: { "Content-Type": "application/json" } });

const mensajeApi = {
  id: "m9",
  conversacionId: "c1",
  remitente: { id: "u2", nombreUsuario: "mariana_rivas" },
  contenido: "  El martes 24 a las 8:00 a. m. 🚚\n",
  creadoEn: "2026-11-20T15:10:00.000Z",
};

beforeEach(() => {
  vi.stubEnv("API_URL", "http://localhost:3000/api/v1");
  vi.stubGlobal("fetch", fetchSimulado);
  almacen.acceso = "token-de-prueba";
});

afterEach(() => {
  vi.unstubAllEnvs();
  vi.unstubAllGlobals();
  vi.resetAllMocks();
});

describe("enviarMensajeCoordinacion", () => {
  it("hace POST a la coordinación de la reserva con Bearer y el texto original, y devuelve el mensaje del 201", async () => {
    fetchSimulado.mockResolvedValue(respuesta(201, mensajeApi));

    const resultado = await enviarMensajeCoordinacion(RESERVA, "  El martes 24 a las 8:00 a. m. 🚚\n");

    expect(fetchSimulado).toHaveBeenCalledOnce();
    const [url, init] = fetchSimulado.mock.calls[0];
    expect(String(url)).toBe(URL_MENSAJES);
    expect(init.method).toBe("POST");
    expect(init.headers.Authorization).toBe("Bearer token-de-prueba");
    expect(JSON.parse(init.body)).toEqual({ contenido: "  El martes 24 a las 8:00 a. m. 🚚\n" });
    expect(resultado).toEqual({
      ok: true,
      mensaje: {
        id: "m9",
        remitente: { id: "u2", nombreUsuario: "mariana_rivas" },
        contenido: "  El martes 24 a las 8:00 a. m. 🚚\n",
        creadoEn: "2026-11-20T15:10:00.000Z",
      },
    });
  });

  it("201 con cuerpo inesperado: éxito sin inventar el mensaje", async () => {
    fetchSimulado.mockResolvedValue(respuesta(201, { raro: true }));
    expect(await enviarMensajeCoordinacion(RESERVA, "Hola")).toEqual({ ok: true, mensaje: null });
  });

  it.each([
    ["vacío", ""],
    ["solo espacios", " \n\t "],
    ["1001 caracteres", "a".repeat(1001)],
    ["1001 emojis", "😀".repeat(1001)],
    ["no es texto", 7],
  ])("contenido inválido (%s) → 400 sin llamar al backend", async (_caso, contenido) => {
    expect(await enviarMensajeCoordinacion(RESERVA, contenido)).toEqual({ ok: false, status: 400 });
    expect(fetchSimulado).not.toHaveBeenCalled();
  });

  it("1000 emojis caben (se cuentan por punto de código)", async () => {
    fetchSimulado.mockResolvedValue(respuesta(201, { ...mensajeApi, contenido: "😀".repeat(1000) }));
    expect((await enviarMensajeCoordinacion(RESERVA, "😀".repeat(1000))).ok).toBe(true);
  });

  it("un reservaId que no es UUID → 404 sin llamar al backend", async () => {
    expect(await enviarMensajeCoordinacion("../auth/me", "Hola")).toEqual({ ok: false, status: 404 });
    expect(fetchSimulado).not.toHaveBeenCalled();
  });

  it("401 lleva a /sesion-vencida", async () => {
    fetchSimulado.mockResolvedValue(respuesta(401));
    await expect(enviarMensajeCoordinacion(RESERVA, "Hola")).rejects.toThrow("REDIRECT:/sesion-vencida");
  });

  it.each([400, 403, 404, 409, 422, 500])("%i → { ok: false, status }", async (status) => {
    fetchSimulado.mockResolvedValue(respuesta(status, { message: "x" }));
    expect(await enviarMensajeCoordinacion(RESERVA, "Hola")).toEqual({ ok: false, status });
  });

  it("red caída → status null", async () => {
    fetchSimulado.mockRejectedValue(new TypeError("fetch failed"));
    expect(await enviarMensajeCoordinacion(RESERVA, "Hola")).toEqual({ ok: false, status: null });
  });
});
