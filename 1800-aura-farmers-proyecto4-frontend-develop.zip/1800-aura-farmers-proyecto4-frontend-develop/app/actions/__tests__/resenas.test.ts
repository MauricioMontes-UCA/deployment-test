import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

// Se prueba la server action con el cliente compartido real (`llamarApi` de
// `lib/api.ts`, PR #2) y solo se simulan la cookie, la red y `redirect`.
const almacen = vi.hoisted(() => ({ acceso: "token-de-prueba" as string | undefined }));
vi.mock("next/headers", () => ({
  cookies: async () => ({
    get: (nombre: string) =>
      nombre === "access_token" && almacen.acceso ? { name: nombre, value: almacen.acceso } : undefined,
  }),
}));
vi.mock("next/navigation", () => ({
  redirect: vi.fn((url: string) => {
    throw new Error(`REDIRECT:${url}`);
  }),
}));

const { enviarResenas } = await import("@/app/actions/resenas");

const RESERVA = "5a3f2c10-8d4e-4b1a-9c7e-1f2a3b4c5d6e";
const URL_RESENAS = `http://localhost:3000/api/v1/reservas/${RESERVA}/resenas`;
const fetchSimulado = vi.fn();

const respuesta = (status: number, cuerpo: unknown = {}) =>
  new Response(JSON.stringify(cuerpo), { status, headers: { "Content-Type": "application/json" } });

const valido = {
  bien: { puntuacion: 4, comentario: "  Funcionó perfecto.  " },
  arrendador: { puntuacion: 5, comentario: "" },
};

beforeEach(() => {
  vi.stubEnv("API_URL", "http://localhost:3000/api/v1");
  vi.stubGlobal("fetch", fetchSimulado);
  almacen.acceso = "token-de-prueba";
});

afterEach(() => {
  vi.unstubAllEnvs();
  vi.unstubAllGlobals();
  vi.resetAllMocks();
});

describe("enviarResenas", () => {
  it("hace POST al endpoint real con Bearer de la cookie y el cuerpo exacto (recortado, sin vacíos)", async () => {
    fetchSimulado.mockResolvedValue(respuesta(201));
    await expect(enviarResenas(RESERVA, valido)).rejects.toThrow();

    expect(fetchSimulado).toHaveBeenCalledOnce();
    const [url, init] = fetchSimulado.mock.calls[0];
    expect(String(url)).toBe(URL_RESENAS);
    expect(init.method).toBe("POST");
    expect(init.headers).toEqual({
      Authorization: "Bearer token-de-prueba",
      "Content-Type": "application/json",
    });
    expect(init.cache).toBe("no-store");
    expect(init.signal).toBeInstanceOf(AbortSignal);
    expect(JSON.parse(init.body)).toStrictEqual({
      bien: { puntuacion: 4, comentario: "Funcionó perfecto." },
      arrendador: { puntuacion: 5 },
    });
  });

  it("con 201 redirige a la reserva con el aviso de éxito", async () => {
    fetchSimulado.mockResolvedValue(
      respuesta(201, { reservaId: RESERVA, resenaBienId: "a", resenaArrendadorId: "b", creadaEn: "2026-11-19T10:00:00.000Z" }),
    );
    await expect(enviarResenas(RESERVA, valido)).rejects.toThrow(`REDIRECT:/reservas/${RESERVA}?resena=enviada`);
  });

  it("descarta propiedades que el backend no acepta", async () => {
    fetchSimulado.mockResolvedValue(respuesta(201));
    await expect(
      enviarResenas(RESERVA, {
        bien: { puntuacion: 3, comentario: "Bien", autorId: "otro" },
        arrendador: { puntuacion: 2, tipo: "ARRENDATARIO" },
        arrendatarioId: "otro",
      }),
    ).rejects.toThrow();
    expect(JSON.parse(fetchSimulado.mock.calls[0][1].body)).toStrictEqual({
      bien: { puntuacion: 3, comentario: "Bien" },
      arrendador: { puntuacion: 2 },
    });
  });

  it.each([400, 403, 404, 409, 422, 500, 503])("devuelve el código %i sin redirigir", async (status) => {
    fetchSimulado.mockResolvedValue(respuesta(status, { message: "x" }));
    expect(await enviarResenas(RESERVA, valido)).toEqual({ ok: false, status });
  });

  it("si la red falla (status 0 de llamarApi) devuelve status null", async () => {
    fetchSimulado.mockRejectedValue(new TypeError("fetch failed"));
    expect(await enviarResenas(RESERVA, valido)).toEqual({ ok: false, status: null });
  });

  it("si se agota el tiempo de llamarApi también es un fallo de red", async () => {
    fetchSimulado.mockRejectedValue(new DOMException("The operation was aborted due to timeout", "TimeoutError"));
    expect(await enviarResenas(RESERVA, valido)).toEqual({ ok: false, status: null });
  });

  it("con 401 (sesión rechazada) pasa por /sesion-vencida", async () => {
    fetchSimulado.mockResolvedValue(respuesta(401, { message: "Unauthorized" }));
    await expect(enviarResenas(RESERVA, valido)).rejects.toThrow("REDIRECT:/sesion-vencida");
  });

  it("sin cookie no envía Authorization y el 401 del backend lleva a /sesion-vencida", async () => {
    almacen.acceso = undefined;
    fetchSimulado.mockResolvedValue(respuesta(401));
    await expect(enviarResenas(RESERVA, valido)).rejects.toThrow("REDIRECT:/sesion-vencida");
    expect(fetchSimulado.mock.calls[0][1].headers).not.toHaveProperty("Authorization");
  });

  it.each(["no-es-uuid", "", "../../auth/me", `${RESERVA}/../otra`])(
    "un id inválido (%j) responde como 404 sin llamar al backend",
    async (id) => {
      expect(await enviarResenas(id, valido)).toEqual({ ok: false, status: 404 });
      expect(fetchSimulado).not.toHaveBeenCalled();
    },
  );

  it.each([
    ["sin cuerpo", undefined],
    ["sin arrendador", { bien: { puntuacion: 4 } }],
    ["puntuación 0", { bien: { puntuacion: 0 }, arrendador: { puntuacion: 5 } }],
    ["puntuación decimal", { bien: { puntuacion: 4.5 }, arrendador: { puntuacion: 5 } }],
    ["puntuación como texto", { bien: { puntuacion: "4" }, arrendador: { puntuacion: 5 } }],
    ["comentario no es texto", { bien: { puntuacion: 4, comentario: 42 }, arrendador: { puntuacion: 5 } }],
    ["comentario de 501", { bien: { puntuacion: 4, comentario: "a".repeat(501) }, arrendador: { puntuacion: 5 } }],
  ])("un cuerpo inválido (%s) responde como 400 sin llamar al backend", async (_caso, datos) => {
    expect(await enviarResenas(RESERVA, datos)).toEqual({ ok: false, status: 400 });
    expect(fetchSimulado).not.toHaveBeenCalled();
  });
});
