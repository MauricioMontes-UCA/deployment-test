import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

// Se prueba la server action con el cliente compartido real (`llamarApi`) y
// solo se simulan la cookie, la red y `redirect`.
const almacen = vi.hoisted(() => ({ acceso: "token-de-prueba" as string | undefined }));
vi.mock("next/headers", () => ({
  cookies: async () => ({
    get: (nombre: string) =>
      nombre === "access_token" && almacen.acceso ? { name: nombre, value: almacen.acceso } : undefined,
  }),
}));
vi.mock("next/navigation", () => ({
  redirect: vi.fn((url: string) => {
    throw new Error(`REDIRECT:${url}`);
  }),
}));

const { calificarArrendatario } = await import("@/app/actions/calificacion-arrendatario");

const RESERVA = "5a3f2c10-8d4e-4b1a-9c7e-1f2a3b4c5d6e";
const URL_ENDPOINT = `http://localhost:3000/api/v1/reservas/${RESERVA}/resenas/arrendatario`;
const fetchSimulado = vi.fn();

const respuesta = (status: number, cuerpo: unknown = {}) =>
  new Response(JSON.stringify(cuerpo), { status, headers: { "Content-Type": "application/json" } });
const creada = (promedio: number, total: number) =>
  respuesta(201, { resenaId: "r1", promedioArrendatario: promedio, totalCalificaciones: total, creadaEn: "2026-11-20T10:00:00.000Z" });

beforeEach(() => {
  vi.stubEnv("API_URL", "http://localhost:3000/api/v1");
  vi.stubGlobal("fetch", fetchSimulado);
  almacen.acceso = "token-de-prueba";
});

afterEach(() => {
  vi.unstubAllEnvs();
  vi.unstubAllGlobals();
  vi.resetAllMocks();
});

describe("calificarArrendatario", () => {
  it("hace POST al endpoint real con Bearer de la cookie y el cuerpo exacto", async () => {
    fetchSimulado.mockResolvedValue(creada(4.6, 7));
    await calificarArrendatario(RESERVA, { puntuacion: 5, comentario: "  Cuidó muy bien la cámara.  " });

    expect(fetchSimulado).toHaveBeenCalledOnce();
    const [url, init] = fetchSimulado.mock.calls[0];
    expect(String(url)).toBe(URL_ENDPOINT);
    expect(init.method).toBe("POST");
    expect(init.headers).toEqual({ Authorization: "Bearer token-de-prueba", "Content-Type": "application/json" });
    expect(JSON.parse(init.body)).toStrictEqual({ puntuacion: 5, comentario: "Cuidó muy bien la cámara." });
  });

  it("omite el comentario vacío y descarta campos extra", async () => {
    fetchSimulado.mockResolvedValue(creada(4, 1));
    await calificarArrendatario(RESERVA, { puntuacion: 3, comentario: "   ", tipo: "ARRENDATARIO", autorId: "x" });
    expect(JSON.parse(fetchSimulado.mock.calls[0][1].body)).toStrictEqual({ puntuacion: 3 });
  });

  it("con 201 NO redirige: devuelve el promedio y el total reales", async () => {
    fetchSimulado.mockResolvedValue(creada(4.6, 7));
    expect(await calificarArrendatario(RESERVA, { puntuacion: 5 })).toEqual({
      ok: true,
      promedioArrendatario: 4.6,
      totalCalificaciones: 7,
    });
  });

  it("con 201 y una respuesta sin promedio válido no inventa datos", async () => {
    fetchSimulado.mockResolvedValue(respuesta(201, { resenaId: "r1" }));
    expect(await calificarArrendatario(RESERVA, { puntuacion: 5 })).toEqual({
      ok: true,
      promedioArrendatario: null,
      totalCalificaciones: null,
    });
  });

  it.each([400, 403, 404, 409, 422, 500, 503])("devuelve el código %i", async (status) => {
    fetchSimulado.mockResolvedValue(respuesta(status, { message: "x" }));
    expect(await calificarArrendatario(RESERVA, { puntuacion: 4 })).toEqual({ ok: false, status });
  });

  it("red caída o tiempo agotado: status null", async () => {
    fetchSimulado.mockRejectedValueOnce(new TypeError("fetch failed"));
    expect(await calificarArrendatario(RESERVA, { puntuacion: 4 })).toEqual({ ok: false, status: null });
    fetchSimulado.mockRejectedValueOnce(new DOMException("timeout", "TimeoutError"));
    expect(await calificarArrendatario(RESERVA, { puntuacion: 4 })).toEqual({ ok: false, status: null });
  });

  it("con 401 pasa por /sesion-vencida", async () => {
    fetchSimulado.mockResolvedValue(respuesta(401));
    await expect(calificarArrendatario(RESERVA, { puntuacion: 4 })).rejects.toThrow("REDIRECT:/sesion-vencida");
  });

  it("sin cookie no envía Authorization y el 401 lleva a /sesion-vencida", async () => {
    almacen.acceso = undefined;
    fetchSimulado.mockResolvedValue(respuesta(401));
    await expect(calificarArrendatario(RESERVA, { puntuacion: 4 })).rejects.toThrow("REDIRECT:/sesion-vencida");
    expect(fetchSimulado.mock.calls[0][1].headers).not.toHaveProperty("Authorization");
  });

  it.each(["no-es-uuid", "", "../../auth/me"])("un id inválido (%j) responde 404 sin llamar al backend", async (id) => {
    expect(await calificarArrendatario(id, { puntuacion: 4 })).toEqual({ ok: false, status: 404 });
    expect(fetchSimulado).not.toHaveBeenCalled();
  });

  it.each([
    ["sin cuerpo", undefined],
    ["puntuación 0", { puntuacion: 0 }],
    ["puntuación 6", { puntuacion: 6 }],
    ["puntuación decimal", { puntuacion: 4.5 }],
    ["puntuación como texto", { puntuacion: "4" }],
    ["comentario no es texto", { puntuacion: 4, comentario: 42 }],
    ["comentario de 501", { puntuacion: 4, comentario: "a".repeat(501) }],
  ])("un cuerpo inválido (%s) responde 400 sin llamar al backend", async (_caso, datos) => {
    expect(await calificarArrendatario(RESERVA, datos)).toEqual({ ok: false, status: 400 });
    expect(fetchSimulado).not.toHaveBeenCalled();
  });
});
