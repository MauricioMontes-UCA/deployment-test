"use server";

import { redirect } from "next/navigation";
import { llamarApi } from "@/lib/api";
import { leerMensaje, validarMensaje, type ResultadoEnvioMensaje } from "@/lib/mensajes";

// El tipo vive en lib/mensajes.ts (lo comparten la consulta y la coordinación);
// se reexporta para quien ya lo importaba desde aquí.
export type { ResultadoEnvioMensaje };

const ID_CONVERSACION = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Envía un mensaje a una conversación previa (`POST /conversaciones/:id/mensajes`,
 * BE-13.1) con el cliente compartido (`llamarApi`).
 *
 * El contenido viaja exactamente como lo escribió el usuario, sin recortar.
 * Lo que llega del navegador no es confiable: se vuelven a validar el id y el
 * texto antes de llamar al backend (id inválido → 404, texto inválido → 400).
 *
 * Un 401 lleva a `/sesion-vencida`, que borra las cookies y lleva al login.
 * Las notificaciones al otro participante las crea el backend.
 */
export async function enviarMensaje(
  conversacionId: string,
  contenido: unknown,
): Promise<ResultadoEnvioMensaje> {
  if (typeof conversacionId !== "string" || !ID_CONVERSACION.test(conversacionId)) {
    return { ok: false, status: 404 };
  }
  if (typeof contenido !== "string" || validarMensaje(contenido)) {
    return { ok: false, status: 400 };
  }

  const { status, datos } = await llamarApi(`conversaciones/${conversacionId}/mensajes`, {
    method: "POST",
    body: JSON.stringify({ contenido }),
  });

  // `redirect` lanza: va fuera de cualquier try/catch (guía de Next).
  if (status === 0) return { ok: false, status: null };
  if (status === 401) redirect("/sesion-vencida");
  if (status === 201) return { ok: true, mensaje: leerMensaje(datos) };
  return { ok: false, status };
}
