# Pruebas del frontend

## Decisión

Usamos **Vitest** con **React Testing Library** y **jsdom**.

- Vitest es la herramienta que recomienda la guía de Next.js para pruebas unitarias y de componentes, y la misma que usa el backend: el equipo escribe pruebas con la misma API en los dos repos.
- React Testing Library prueba los componentes como los usa una persona (por rol, etiqueta y texto), no por su estructura interna. Eso obliga a que los formularios sean accesibles: si una prueba no encuentra un campo por su etiqueta, un lector de pantalla tampoco.
- jsdom simula el navegador. Las pruebas que necesitan el entorno de Node (el proxy y los route handlers, que usan `NextRequest`) lo piden con el comentario `// @vitest-environment node` al inicio del archivo.

Se usa **Vitest 4** y no 5: Vitest 5 exige `@types/node` 22 o superior y el repo está en la 20.

## Cómo correrlas

```bash
npm test            # una corrida
npm run test:watch  # modo observación
```

## Convenciones

- Las pruebas viven junto al código, en `*.test.ts(x)`: `app/publicar/formulario-publicacion.test.tsx`, `lib/validaciones/bien.test.ts`.
- Las de componentes del Design System están en `components/ui/__tests__/`.
- Las utilidades compartidas entre pruebas van en `pruebas/` (por ejemplo, `tokenDePrueba` para armar un JWT).
- Las llamadas a la API se prueban con `fetch` simulado (`vi.stubGlobal("fetch", …)`) y las variables de entorno con `vi.stubEnv`.
- Las server actions y módulos con `server-only` se simulan con `vi.mock` desde la prueba del componente que los usa.
- Para subir archivos con `userEvent.upload`, usar `userEvent.setup({ applyAccept: false })` cuando se quiere probar la validación propia de formatos: si no, el filtro `accept` del input descarta el archivo antes de que llegue al componente.
- `jsdom` no implementa `URL.createObjectURL` ni `HTMLDialogElement.showModal`: se simulan en la prueba que los necesita.
