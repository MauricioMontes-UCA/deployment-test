import { NextResponse, type NextRequest } from "next/server";
import { COOKIE_ACCESO, COOKIE_REFRESH } from "@/lib/cookies-sesion";
import { aplicarCambiosDeSesion, obtenerAccesoVigente } from "@/lib/sesion-vigente";
import { leerPayload, type Rol } from "@/lib/jwt";

/** Solo para quien no tiene sesión: con sesión llevan al inicio. */
const rutasPublicas = ["/login", "/registro"];
/**
 * Rutas que se ven con o sin sesión. El catálogo del design system además da
 * 404 en producción desde su propia página.
 */
const rutasLibres = ["/design-system", "/sesion-vencida"];
/**
 * Páginas que se ven con o sin sesión: la portada (solo `/`), la búsqueda (con
 * sus subrutas) y el detalle de un bien (`/bienes/:id`, solo ese nivel). A
 * diferencia de las rutas libres, aquí sí se renueva el token si venció, para
 * que la barra muestre al usuario; pero nunca se redirige.
 */
const paginasParaTodos = [/^\/$/, /^\/buscar(\/.*)?$/, /^\/bienes\/[^/]+$/];
/**
 * Rutas que exigen un rol. Es un chequeo optimista con el rol del token: la
 * página vuelve a validarlo con /auth/me y el backend con su guard de roles.
 */
const rutasPorRol: { ruta: string; rol: Rol }[] = [{ ruta: "/publicar", rol: "ARRENDADOR" }];

function coincide(pathname: string, ruta: string) {
  return pathname === ruta || pathname.startsWith(`${ruta}/`);
}

/**
 * Chequeo optimista de la sesión y renovación del access token.
 *
 * - Sesión válida = access token con `exp` en el futuro (se lee sin verificar
 *   la firma; el backend lo verifica en cada petición).
 * - Si venció y hay refresh token, se renueva con `obtenerAccesoVigente`, que
 *   comparte la renovación entre peticiones simultáneas con el mismo token.
 *   Las cookies nuevas se escriben en la respuesta y en la request, para que
 *   los server components de esta misma navegación ya usen el token nuevo.
 * - Si el backend rechaza el refresh (401), se borran las cookies. Si no
 *   responde, se conservan para reintentar en la siguiente navegación.
 */
export async function proxy(request: NextRequest) {
  const { pathname } = request.nextUrl;
  // Coincide con la ruta y con todo lo que cuelga de ella.
  const esLibre = rutasLibres.some((ruta) => coincide(pathname, ruta));
  if (esLibre) return NextResponse.next();

  const estado = await obtenerAccesoVigente(request.cookies);
  const sesionValida = Boolean(estado.acceso);
  const { sesionNueva } = estado;
  const conCookies = (respuesta: NextResponse) => aplicarCambiosDeSesion(respuesta, estado);

  const esPublica = rutasPublicas.includes(pathname);
  if (esPublica && sesionValida) {
    return conCookies(NextResponse.redirect(new URL("/", request.nextUrl)));
  }
  const esParaTodos = paginasParaTodos.some((patron) => patron.test(pathname));
  if (!esPublica && !esParaTodos && !sesionValida) {
    return conCookies(NextResponse.redirect(new URL("/login", request.nextUrl)));
  }

  const rolExigido = rutasPorRol.find(({ ruta }) => coincide(pathname, ruta))?.rol;
  if (rolExigido) {
    const rol = leerPayload(estado.acceso)?.rol;
    if (rol !== rolExigido) {
      return conCookies(NextResponse.redirect(new URL("/", request.nextUrl)));
    }
  }

  if (sesionNueva) {
    // RequestCookies.set reescribe el header Cookie que reciben las páginas.
    request.cookies.set(COOKIE_ACCESO, sesionNueva.accessToken);
    request.cookies.set(COOKIE_REFRESH, sesionNueva.refreshToken);
  }
  return conCookies(NextResponse.next({ request: { headers: request.headers } }));
}

export const config = {
  matcher: [
    {
      source:
        "/((?!api|_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp|ico)$).*)",
      // Los prefetch del router no pasan por el proxy: no hace falta renovar
      // para ellos y así hay menos renovaciones en paralelo. Las páginas
      // protegidas igual validan con la API. Las rutas /api tampoco pasan
      // (el proxy cargaría el cuerpo, con un tope de 10 MB): renuevan por su
      // cuenta con obtenerAccesoVigente.
      missing: [
        { type: "header", key: "next-router-prefetch" },
        { type: "header", key: "purpose", value: "prefetch" },
      ],
    },
  ],
};
