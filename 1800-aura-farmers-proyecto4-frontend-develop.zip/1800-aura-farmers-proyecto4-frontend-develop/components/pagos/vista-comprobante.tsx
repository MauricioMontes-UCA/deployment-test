"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Boton, EstadoDePagina, Icono, clasesBoton } from "@/components/ui";
import { dinero, esComprobantePago, fechaComprobante, type ComprobantePago } from "@/lib/pagos/comprobante";

export type EstadoComprobante =
  | { tipo: "cargando" }
  | { tipo: "listo"; comprobante: ComprobantePago }
  | { tipo: "rechazado"; mensaje: string }
  | { tipo: "sin-permiso" }
  | { tipo: "no-encontrado" }
  | { tipo: "error" };

function Fila({ etiqueta, valor, destacado = false }: { etiqueta: string; valor: string; destacado?: boolean }) {
  return (
    <div className="flex items-start justify-between gap-espacio-4 border-b border-borde-sutil py-espacio-3">
      <dt className="texto-cuerpo-pequeno text-texto-secundario">{etiqueta}</dt>
      <dd className={destacado ? "texto-cuerpo-medio text-texto-primario text-right font-semibold" : "texto-cuerpo-pequeno text-texto-primario text-right break-all"}>{valor}</dd>
    </div>
  );
}

/** Solo los datos persistidos del backend pueden producir un comprobante exitoso. */
export function VistaComprobante({ pagoId, sinPermiso = false }: { pagoId: string; sinPermiso?: boolean }) {
  const router = useRouter();
  const [estado, setEstado] = useState<EstadoComprobante>({ tipo: "cargando" });
  const [intento, setIntento] = useState(0);

  useEffect(() => {
    if (sinPermiso) return;
    const controller = new AbortController();
    async function cargar() {
      try {
        const respuesta = await fetch(`/api/pagos/${encodeURIComponent(pagoId)}/comprobante`, {
          method: "GET", cache: "no-store", signal: controller.signal,
        });
        if (controller.signal.aborted) return;
        if (respuesta.status === 401) { router.replace("/sesion-vencida"); return; }
        if (respuesta.status === 403) { setEstado({ tipo: "sin-permiso" }); return; }
        if (respuesta.status === 404 || respuesta.status === 400) { setEstado({ tipo: "no-encontrado" }); return; }
        if (respuesta.status === 409) {
          setEstado({ tipo: "rechazado", mensaje: "El pago no cuenta con un comprobante de éxito" });
          return;
        }
        if (!respuesta.ok) { setEstado({ tipo: "error" }); return; }
        const datos: unknown = await respuesta.json();
        if (controller.signal.aborted) return;
        setEstado(esComprobantePago(datos) && datos.pagoId.toLowerCase() === pagoId.toLowerCase()
          ? { tipo: "listo", comprobante: datos } : { tipo: "error" });
      } catch {
        if (!controller.signal.aborted) setEstado({ tipo: "error" });
      }
    }
    void cargar();
    return () => controller.abort();
  }, [pagoId, router, intento, sinPermiso]);

  if (sinPermiso || estado.tipo === "sin-permiso") {
    return (
      <div className="w-full max-w-md">
        <EstadoDePagina tipo="sin-permiso" titulo="No tienes acceso a este comprobante." mensaje="El pago pertenece a otra reserva o no tienes permiso para consultarlo." accion={<Link href="/" className={clasesBoton({ jerarquia: "secundario" })}>Ir al inicio</Link>} />
      </div>
    );
  }
  if (estado.tipo === "cargando") return <div className="w-full max-w-md"><EstadoDePagina tipo="cargando" titulo="Cargando comprobante…" /></div>;
  if (estado.tipo === "no-encontrado") return <div className="w-full max-w-md"><EstadoDePagina tipo="no-encontrado" titulo="No encontramos este pago." mensaje="Comprueba el enlace o vuelve a tus reservas." accion={<Link href="/reservas" className={clasesBoton({ jerarquia: "secundario" })}>Mis reservas</Link>} /></div>;
  if (estado.tipo === "error") return <div className="w-full max-w-md"><EstadoDePagina tipo="error" titulo="No pudimos cargar el comprobante." accion={<Boton jerarquia="secundario" onClick={() => { setEstado({ tipo: "cargando" }); setIntento((v) => v + 1); }}>Reintentar</Boton>} /></div>;
  if (estado.tipo === "rechazado") return (
    <section className="flex w-full max-w-md flex-col items-center gap-espacio-5 border border-borde-sutil bg-fondo-superficie px-espacio-6 py-espacio-7 text-center">
      <span className="flex bg-fondo-error p-espacio-3"><Icono nombre="alerta" tamano={28} className="text-estado-error" /></span>
      <h1 className="texto-h3 text-texto-primario">El pago no cuenta con un comprobante de éxito</h1>
      <p className="texto-cuerpo-pequeno text-texto-secundario">Este pago no se completó exitosamente. No existe un comprobante de éxito.</p>
      <Link href="/reservas" className={clasesBoton({ jerarquia: "secundario" })}>Volver a mis reservas</Link>
    </section>
  );

  const c = estado.comprobante;
  return (
    <article aria-label="Comprobante de pago" className="flex w-full max-w-md flex-col gap-espacio-5 border border-borde-default bg-fondo-superficie px-espacio-6 py-espacio-7 print:max-w-none print:border-0">
      <div className="flex flex-col items-center gap-espacio-3 text-center">
        <span className="flex bg-fondo-exito p-espacio-3"><Icono nombre="check" tamano={28} className="text-estado-exito" /></span>
        <h1 className="texto-h3 text-texto-primario">Pago realizado</h1>
        <span className="texto-etiqueta-pequena bg-fondo-exito px-espacio-2 py-1 text-texto-primario">Simulado exitoso</span>
      </div>
      <dl className="flex flex-col">
        <Fila etiqueta="Identificador del pago" valor={c.pagoId} />
        <Fila etiqueta="Identificador del comprobante" valor={c.comprobanteId} />
        <Fila etiqueta="Reserva" valor={c.reservaId} />
        <Fila etiqueta="Fecha y hora" valor={fechaComprobante(c.fechaHora)} />
        <Fila etiqueta="Modalidad" valor={c.modalidad === "TARJETA" ? "Tarjeta" : "Transferencia bancaria"} />
        <Fila etiqueta="Alquiler" valor={dinero(c.importeAlquiler)} />
        <Fila etiqueta="Depósito de garantía" valor={dinero(c.importeDeposito)} />
        <Fila etiqueta="Total pagado" valor={`${dinero(c.total)} USD`} destacado />
      </dl>
      <div className="flex flex-col gap-espacio-2 print:hidden">
        <Boton jerarquia="secundario" icono="descargar" onClick={() => window.print()} className="w-full">Descargar o imprimir</Boton>
        <Link href={`/reservas/${c.reservaId}`} className={clasesBoton({ jerarquia: "terciario", className: "w-full justify-center" })}>Volver al detalle de la reserva</Link>
      </div>
    </article>
  );
}
