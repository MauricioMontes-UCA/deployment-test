import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { VistaComprobante } from "./vista-comprobante";

const { replace, routerMock } = vi.hoisted(() => {
  const replace = vi.fn();

  return { replace, routerMock: { replace } };
});

vi.mock("next/navigation", () => ({ useRouter: () => routerMock }));

const ID = "11111111-1111-4111-8111-111111111111";
const datos = {
  pagoId: ID,
  comprobanteId: "22222222-2222-4222-8222-222222222222",
  reservaId: "33333333-3333-4333-8333-333333333333",
  fechaHora: "2026-11-18T21:42:00.000Z",
  importeAlquiler: 160,
  importeDeposito: 25,
  total: 185,
  modalidad: "TARJETA",
  estado: "SIMULADO_EXITOSO",
};

const fetchMock = vi.fn();

beforeEach(() => {
  fetchMock.mockReset();
  replace.mockReset();
  vi.stubGlobal("fetch", fetchMock);
  replace.mockReset();
});

afterEach(() => {
  vi.unstubAllGlobals();
});

function responder(status: number, body: unknown = {}) {
  fetchMock.mockResolvedValue({
    status,
    ok: status >= 200 && status < 300,
    json: async () => body,
  });
}

describe("FE-9.1 comprobante", () => {
  it("muestra todos los campos del comprobante y navegación", async () => {
    responder(200, datos);
    render(<VistaComprobante pagoId={ID} />);
    expect(await screen.findByText("Pago realizado")).toBeInTheDocument();
    expect(screen.getByText(datos.comprobanteId)).toBeInTheDocument();
    expect(screen.getByText("$185.00 USD")).toBeInTheDocument();
    expect(
      screen.getByRole("link", { name: /Volver al detalle/ }),
    ).toHaveAttribute("href", `/reservas/${datos.reservaId}`);
    expect(fetchMock).toHaveBeenCalledTimes(1);
  });

  it("409 no muestra éxito", async () => {
    responder(409);
    render(<VistaComprobante pagoId={ID} />);
    expect(
      await screen.findByText("El pago no cuenta con un comprobante de éxito"),
    ).toBeInTheDocument();
    expect(screen.queryByText("Pago realizado")).not.toBeInTheDocument();
  });

  it.each([403, 404, 400])(
    "trata correctamente el estado %i",
    async (status) => {
      responder(status);
      render(<VistaComprobante pagoId={ID} />);
      expect(
        await screen.findByText(
          status === 403
            ? "No tienes acceso a este comprobante."
            : "No encontramos este pago.",
        ),
      ).toBeInTheDocument();
      expect(screen.queryByText("Pago realizado")).not.toBeInTheDocument();
    },
  );

  it("401 redirige a sesión vencida", async () => {
    responder(401);
    render(<VistaComprobante pagoId={ID} />);
    await waitFor(() =>
      expect(replace).toHaveBeenCalledWith("/sesion-vencida"),
    );
  });

  it("no acepta un 200 con estado rechazado", async () => {
    responder(200, { ...datos, estado: "SIMULADO_RECHAZADO" });
    render(<VistaComprobante pagoId={ID} />);
    expect(
      await screen.findByText("No pudimos cargar el comprobante."),
    ).toBeInTheDocument();
    expect(screen.queryByText("Pago realizado")).not.toBeInTheDocument();
  });

  it("permite reintentar tras error", async () => {
    responder(502);
    render(<VistaComprobante pagoId={ID} />);
    await userEvent.click(
      await screen.findByRole("button", { name: "Reintentar" }),
    );
    await waitFor(() => expect(fetchMock).toHaveBeenCalledTimes(2));
  });

  it("no consulta la API para rol sin permiso", () => {
    render(<VistaComprobante pagoId={ID} sinPermiso />);
    expect(
      screen.getByText("No tienes acceso a este comprobante."),
    ).toBeInTheDocument();
    expect(fetchMock).not.toHaveBeenCalled();
  });
});
