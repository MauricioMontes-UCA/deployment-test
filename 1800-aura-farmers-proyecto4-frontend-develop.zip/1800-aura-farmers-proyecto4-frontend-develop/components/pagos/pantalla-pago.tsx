"use client";

import {
  useCallback,
  useEffect,
  useRef,
  useState,
  type FormEvent,
} from "react";

import {
  Alerta,
  Boton,
  CampoDeTexto,
  EncabezadoDePagina,
  EstadoDePagina,
  OpcionEnTarjeta,
} from "@/components/ui";

import {
  esResultadoPago,
  esResumenPago,
  formatearDinero,
  mensajeError,
  validarReferencia,
  validarTarjeta,
  type CrearPago,
  type ModalidadPago,
  type ResultadoPago,
  type ResumenPago,
} from "@/lib/pagos/tipos";

import { useRouter } from "next/navigation";
import Link from "next/link";
import { Imagen, clasesBoton } from "@/components/ui";

type Props = {
  reservaId: string;
  tituloBien: string;
  fechaInicio: string | null;
  fechaFin: string | null;
  fotoBien?: string | null;
  precioUnitario?: number | null;
  unidadCobro?: string | null;
  /**
   * Pago exitoso que `GET /reservas/:id` ya trae. Si existe, la reserva
   * está pagada y no hace falta pedir el resumen (el backend responde 422).
   */
  pagoPrevio?: { id: string; total: number | null } | null;
};

type EstadoCarga =
  | "cargando"
  | "lista"
  | "error"
  | "sin-permiso"
  | "no-disponible"
  | "ya-pagada";

function fechaLegible(valor: string | null): string {
  if (!valor) return "No disponible";

  const fecha = new Date(valor);

  if (Number.isNaN(fecha.getTime())) {
    return valor;
  }

  return new Intl.DateTimeFormat("es-SV", {
    day: "numeric",
    month: "long",
    year: "numeric",
    timeZone: "UTC",
  }).format(fecha);
}

export function PantallaPago({
  reservaId,
  tituloBien,
  fechaInicio,
  fechaFin,
  fotoBien,
  precioUnitario,
  unidadCobro,
  pagoPrevio = null,
}: Props) {
  const router = useRouter();

  const [carga, setCarga] = useState<EstadoCarga>(
    pagoPrevio ? "ya-pagada" : "cargando",
  );

  const [resumen, setResumen] = useState<ResumenPago | null>(null);

  const [modalidad, setModalidad] = useState<ModalidadPago>("TARJETA");

  const [numeroTarjeta, setNumeroTarjeta] = useState("");

  const [vencimiento, setVencimiento] = useState("");

  const [cvv, setCvv] = useState("");

  const [referencia, setReferencia] = useState("");

  const [procesando, setProcesando] = useState(false);

  const [error, setError] = useState<string | null>(null);

  const [resultado, setResultado] = useState<ResultadoPago | null>(null);

  const envioEnCurso = useRef(false);
  const [comprobanteId, setComprobanteId] = useState<string | null>(
    pagoPrevio?.id ?? null,
  );
  const [mensajeNoDisponible, setMensajeNoDisponible] = useState<string | null>(
    null,
  );

  const cargarResumen = useCallback(
    async (signal?: AbortSignal) => {
      try {
        const respuesta = await fetch(
          `/api/reservas/${reservaId}/resumen-pago`,
          {
            method: "GET",
            cache: "no-store",
            signal,
          },
        );

        if (respuesta.status === 401) {
          router.replace("/sesion-vencida");
          return;
        }

        if (respuesta.status === 403) {
          setCarga("sin-permiso");
          return;
        }

        if ([404, 409, 422].includes(respuesta.status)) {
          const detalle: unknown = await respuesta.json().catch(() => null);
          const mensaje = mensajeError(
            detalle,
            "La reserva no está disponible para pagar.",
          );
          setMensajeNoDisponible(mensaje);
          if (typeof detalle === "object" && detalle !== null) {
            const registro = detalle as Record<string, unknown>;
            if (typeof registro.pagoId === "string")
              setComprobanteId(registro.pagoId);
          }
          setCarga(respuesta.status === 409 ? "ya-pagada" : "no-disponible");
          return;
        }

        const datos: unknown = await respuesta.json();

        if (!respuesta.ok) {
          throw new Error(mensajeError(datos));
        }

        if (!esResumenPago(datos)) {
          throw new Error("El servidor devolvió un resumen de pago inválido.");
        }

        setResumen(datos);
        setCarga("lista");
      } catch (fallo) {
        if (
          signal?.aborted ||
          (fallo instanceof DOMException && fallo.name === "AbortError")
        ) {
          return;
        }

        setError(
          fallo instanceof Error
            ? fallo.message
            : "No pudimos consultar los cargos.",
        );

        setCarga("error");
      }
    },
    [reservaId, router],
  );

  useEffect(() => {
    if (pagoPrevio) return;

    const controller = new AbortController();

    const iniciarCarga = async () => {
      await cargarResumen(controller.signal);
    };

    void iniciarCarga();

    return () => {
      controller.abort();
    };
  }, [cargarResumen, pagoPrevio]);

  function cambiarModalidad(siguiente: ModalidadPago) {
    if (procesando || resultado?.estado === "SIMULADO_EXITOSO") {
      return;
    }

    setModalidad(siguiente);
    setError(null);

    // Los datos de tarjeta no se conservan al
    // cambiar de modalidad.
    setNumeroTarjeta("");
    setVencimiento("");
    setCvv("");
    setReferencia("");
  }

  async function enviarPago(evento: FormEvent<HTMLFormElement>) {
    evento.preventDefault();

    if (
      envioEnCurso.current ||
      procesando ||
      !resumen ||
      resultado?.estado === "SIMULADO_EXITOSO"
    ) {
      return;
    }

    let cuerpo: CrearPago;

    if (modalidad === "TARJETA") {
      const validacion = validarTarjeta(numeroTarjeta, vencimiento, cvv);

      if (validacion) {
        setError(validacion);
        return;
      }

      cuerpo = {
        modalidad: "TARJETA",
        numeroTarjeta,
        vencimiento,
        codigoSeguridad: cvv,
      };
    } else {
      const validacion = validarReferencia(referencia);

      if (validacion) {
        setError(validacion);
        return;
      }

      cuerpo = {
        modalidad: "TRANSFERENCIA_BANCARIA",
        referenciaSimulada: referencia,
      };
    }

    envioEnCurso.current = true;
    setProcesando(true);
    setError(null);
    setResultado(null);

    try {
      const respuesta = await fetch(`/api/reservas/${reservaId}/pagos`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(cuerpo),
      });

      // No conservar los datos sensibles después
      // de enviar la solicitud.
      setNumeroTarjeta("");
      setVencimiento("");
      setCvv("");

      if (respuesta.status === 401) {
        router.replace("/sesion-vencida");
        return;
      }

      if (respuesta.status === 403) {
        setCarga("sin-permiso");
        return;
      }

      const datos: unknown = await respuesta.json();

      if (!respuesta.ok) {
        if (respuesta.status === 409) {
          setCarga("ya-pagada");
          setMensajeNoDisponible(mensajeError(datos));
          if (
            typeof datos === "object" &&
            datos !== null &&
            "pagoId" in datos &&
            typeof datos.pagoId === "string"
          )
            setComprobanteId(datos.pagoId);
        } else if (respuesta.status === 422) {
          setCarga("no-disponible");
          setMensajeNoDisponible(mensajeError(datos));
        } else {
          setError(mensajeError(datos, "No se pudo procesar el pago."));
        }
        return;
      }

      if (!esResultadoPago(datos)) {
        throw new Error("El servidor devolvió un resultado de pago inválido.");
      }

      setResultado(datos);
      if (datos.comprobanteId) setComprobanteId(datos.comprobanteId);

      if (datos.estado === "SIMULADO_EXITOSO") {
        setReferencia("");
      }
    } catch (fallo) {
      setNumeroTarjeta("");
      setVencimiento("");
      setCvv("");

      setError(
        fallo instanceof Error
          ? fallo.message
          : "Ocurrió un error de conexión.",
      );
    } finally {
      envioEnCurso.current = false;
      setProcesando(false);
    }
  }

  if (carga === "cargando") {
    return (
      <EstadoDePagina
        tipo="cargando"
        titulo="Consultando los cargos"
        mensaje="Estamos obteniendo el importe de tu reserva."
      />
    );
  }

  if (carga === "sin-permiso") {
    return (
      <EstadoDePagina
        tipo="sin-permiso"
        titulo="No puedes realizar este pago."
        mensaje="Solo el arrendatario propietario de la reserva puede pagar."
      />
    );
  }

  // Los estados 409 y 422 conservan la estructura de la página.
  // El 409 muestra el resumen a partir de los datos de la reserva,
  // incluso cuando GET resumen-pago no está disponible.

  if (
    carga === "error" ||
    (!resumen && carga !== "ya-pagada" && carga !== "no-disponible")
  ) {
    return (
      <EstadoDePagina
        tipo="error"
        titulo="No pudimos cargar los cargos."
        mensaje={error ?? "Inténtalo nuevamente."}
        accion={
          <Boton
            jerarquia="secundario"
            onClick={() => {
              setCarga("cargando");
              setError(null);
              void cargarResumen();
            }}
          >
            Reintentar
          </Boton>
        }
      />
    );
  }

  const pagoExitoso = resultado?.estado === "SIMULADO_EXITOSO";
  const bloqueado = carga === "ya-pagada" || carga === "no-disponible";
  const enlaceComprobante = resultado?.pagoId ?? comprobanteId;
  const dias =
    fechaInicio && fechaFin
      ? Math.max(
          1,
          Math.round(
            (new Date(fechaFin).getTime() - new Date(fechaInicio).getTime()) /
              86400000,
          ) + 1,
        )
      : null;
  const total = resumen?.total ?? pagoPrevio?.total ?? null;

  const pagoRechazado = resultado?.estado === "SIMULADO_RECHAZADO";

  return (
    <div className="flex flex-col gap-espacio-6">
      <EncabezadoDePagina
        sobretitulo={`RESERVA RSV-${reservaId.slice(0, 8).toUpperCase()}`}
        titulo="Pagar reserva"
        descripcion="Revisa los cargos y elige cómo pagar. Los importes vienen del servidor."
      />

      {pagoExitoso && resultado && (
        <Alerta tono="exito" titulo="Pago aprobado">
          Tu pago fue procesado correctamente.
          {resultado.comprobanteId && (
            <p className="mt-2">
              Comprobante: <strong>{resultado.comprobanteId}</strong>
            </p>
          )}
          <p className="mt-2">Operación: {resultado.pagoId}</p>
          <p>Fecha: {new Date(resultado.fechaHora).toLocaleString("es-SV")}</p>
          <p>Total pagado: {formatearDinero(resultado.total)}</p>
          <Link
            className={clasesBoton({ jerarquia: "secundario" })}
            href={`/pagos/${resultado.pagoId}/comprobante`}
          >
            Ver comprobante
          </Link>
        </Alerta>
      )}

      {pagoRechazado && resultado && (
        <Alerta tono="error" titulo="Pago rechazado">
          {resultado.motivoRechazo ??
            "La pasarela simulada rechazó la operación."}
          <p className="mt-2">
            Puedes revisar los datos e intentarlo nuevamente.
          </p>
        </Alerta>
      )}

      {carga === "ya-pagada" && (
        <Alerta tono="advertencia" titulo="Reserva ya pagada">
          Esta reserva ya tiene un pago completado. No se puede pagar dos veces
          la misma reserva.
          {enlaceComprobante ? (
            <p className="mt-3">
              <Link
                className={clasesBoton({ jerarquia: "secundario" })}
                href={`/pagos/${enlaceComprobante}/comprobante`}
              >
                Ver comprobante
              </Link>
            </p>
          ) : (
            <p className="mt-2">
              El identificador del pago no está disponible en esta respuesta.
              Consulta tus pagos para abrir el comprobante.
            </p>
          )}
        </Alerta>
      )}
      {carga === "no-disponible" && (
        <Alerta tono="advertencia" titulo="Reserva no disponible">
          {mensajeNoDisponible ?? "La reserva no está confirmada para pagar."}
        </Alerta>
      )}
      {error && <Alerta tono="error">{error}</Alerta>}

      <div className="grid grid-cols-1 items-start gap-espacio-6 lg:grid-cols-[minmax(0,1fr)_380px]">
        <section
          className={`order-2 flex flex-col gap-espacio-5 border border-borde-default bg-fondo-superficie p-espacio-5 md:p-espacio-6 lg:order-1 ${pagoExitoso || bloqueado ? "hidden" : ""}`}
        >
          {!pagoExitoso && !bloqueado && (
            <div className="flex flex-col gap-espacio-2">
              <h2 className="texto-h3 text-texto-primario">Método de pago</h2>
              <p className="texto-cuerpo-pequeno text-texto-secundario">
                Selecciona cómo deseas pagar tu reserva.
              </p>
            </div>
          )}

          {!pagoExitoso && !bloqueado && (
            <form onSubmit={enviarPago} className="flex flex-col gap-espacio-5">
              <div className="grid grid-cols-1 gap-espacio-3 sm:grid-cols-2">
                <OpcionEnTarjeta
                  name="modalidad"
                  value="TARJETA"
                  titulo="Tarjeta de prueba"
                  descripcion="Termina en 4242 para aprobar, 0002 para rechazar"
                  checked={modalidad === "TARJETA"}
                  onChange={() => cambiarModalidad("TARJETA")}
                  disabled={procesando}
                />

                <OpcionEnTarjeta
                  name="modalidad"
                  value="TRANSFERENCIA_BANCARIA"
                  titulo="Transferencia bancaria"
                  descripcion="Usa la referencia de prueba SIM-APRUEBA"
                  checked={modalidad === "TRANSFERENCIA_BANCARIA"}
                  onChange={() => cambiarModalidad("TRANSFERENCIA_BANCARIA")}
                  disabled={procesando}
                />
              </div>

              {modalidad === "TARJETA" ? (
                <div className="flex flex-col gap-espacio-4">
                  <CampoDeTexto
                    etiqueta="Número de tarjeta de prueba"
                    placeholder="4242424242424242"
                    inputMode="numeric"
                    autoComplete="off"
                    maxLength={19}
                    value={numeroTarjeta}
                    onChange={(evento) =>
                      setNumeroTarjeta(evento.target.value.replace(/\D/g, ""))
                    }
                    disabled={procesando}
                    required
                  />

                  <div className="grid grid-cols-1 gap-espacio-4 sm:grid-cols-2">
                    <CampoDeTexto
                      etiqueta="Vencimiento (MM/AA)"
                      placeholder="12/28"
                      autoComplete="off"
                      maxLength={5}
                      value={vencimiento}
                      onChange={(evento) => setVencimiento(evento.target.value)}
                      disabled={procesando}
                      required
                    />

                    <CampoDeTexto
                      etiqueta="CVV"
                      placeholder="123"
                      inputMode="numeric"
                      autoComplete="off"
                      maxLength={4}
                      value={cvv}
                      onChange={(evento) =>
                        setCvv(evento.target.value.replace(/\D/g, ""))
                      }
                      disabled={procesando}
                      required
                    />
                  </div>

                  <Alerta tono="info">
                    Esta operación es una simulación. Utiliza únicamente datos
                    de prueba. Nunca ingreses una tarjeta real.
                  </Alerta>
                </div>
              ) : (
                <div className="flex flex-col gap-espacio-4">
                  <CampoDeTexto
                    etiqueta="Referencia de transferencia"
                    placeholder="SIM-APRUEBA"
                    maxLength={20}
                    autoComplete="off"
                    value={referencia}
                    onChange={(evento) => setReferencia(evento.target.value)}
                    disabled={procesando}
                    required
                    ayuda="De 6 a 20 caracteres: letras, números o guiones."
                  />

                  <Alerta tono="info">
                    Utiliza la referencia SIM-APRUEBA para simular una
                    transferencia aprobada.
                  </Alerta>
                </div>
              )}

              <div className="border-t border-borde-sutil pt-espacio-5">
                <Boton
                  type="submit"
                  className="w-full"
                  cargando={procesando}
                  disabled={procesando || pagoExitoso}
                >
                  Pagar {formatearDinero(resumen!.total)}
                </Boton>
              </div>
            </form>
          )}
        </section>

        <aside className="order-1 flex flex-col gap-espacio-5 border border-borde-default bg-fondo-superficie p-espacio-5 md:p-espacio-6 lg:order-2">
          <h2 className="texto-h3 text-texto-primario">
            Resumen de tu reserva
          </h2>

          <div className="flex flex-col gap-espacio-2 border-b border-borde-sutil pb-espacio-4">
            <div className="flex items-center gap-espacio-3">
              <Imagen
                src={fotoBien}
                alt={`Foto de ${tituloBien}`}
                className="h-20 w-24 shrink-0"
                sizes="96px"
              />
              <h3 className="texto-cuerpo-medio text-texto-primario">
                {tituloBien}
              </h3>
            </div>

            <p className="texto-cuerpo-pequeno text-texto-secundario">
              {fechaLegible(fechaInicio)} → {fechaLegible(fechaFin)}
              {dias ? ` · ${dias} días` : ""}
            </p>
          </div>

          <div className="flex flex-col gap-espacio-4">
            {resumen && (
              <>
                <div className="flex justify-between gap-3">
                  <span className="texto-cuerpo text-texto-secundario">
                    Alquiler
                    {dias &&
                    precioUnitario !== null &&
                    precioUnitario !== undefined &&
                    unidadCobro === "DIA"
                      ? ` (${dias} × ${formatearDinero(precioUnitario)})`
                      : ""}
                  </span>
                  <span className="texto-cuerpo-medio text-texto-primario">
                    {formatearDinero(resumen.importeAlquiler)}
                  </span>
                </div>

                <div className="flex justify-between gap-3">
                  <span className="texto-cuerpo text-texto-secundario">
                    Depósito de garantía
                  </span>
                  <span className="texto-cuerpo-medio text-texto-primario">
                    {formatearDinero(resumen.importeDeposito)}
                  </span>
                </div>
              </>
            )}

            <div className="flex items-center justify-between gap-3 border-t border-borde-default pt-espacio-4">
              <span className="texto-cuerpo-medio text-texto-primario">
                Total a pagar
              </span>
              <strong className="texto-h3 text-texto-primario">
                {total === null ? "—" : `${formatearDinero(total)} USD`}
              </strong>
            </div>
          </div>

          <p className="texto-cuerpo-pequeno text-texto-secundario">
            El depósito se devuelve al terminar la renta según el estado del
            bien.
          </p>
        </aside>
      </div>
    </div>
  );
}
