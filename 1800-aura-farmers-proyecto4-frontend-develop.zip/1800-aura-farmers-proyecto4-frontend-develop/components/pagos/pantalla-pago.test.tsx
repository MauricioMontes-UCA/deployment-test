import { afterEach, describe, expect, it, vi } from "vitest";
import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { PantallaPago } from "./pantalla-pago";

const navegacion = vi.hoisted(() => ({ replace: vi.fn() }));
vi.mock("next/navigation", () => ({ useRouter: () => navegacion }));
vi.mock("next/image", () => ({
  default: ({ alt }: { alt: string }) => <span role="img" aria-label={alt} />,
}));

const ID = "5a3f2c10-8d4e-4b1a-9c7e-1f2a3b4c5d6e";
const resumen = {
  reservaId: ID,
  importeAlquiler: 160,
  importeDeposito: 25,
  total: 185,
  moneda: "USD",
};
const props = {
  reservaId: ID,
  tituloBien: "Taladro",
  fechaInicio: "2026-11-24",
  fechaFin: "2026-11-25",
  estadoReserva: "CONFIRMADA",
  fotoBien: null,
  precioUnitario: 80,
  unidadCobro: "DIA",
};
const respuesta = (status: number, datos: unknown) => ({
  status,
  ok: status >= 200 && status < 300,
  json: async () => datos,
});
const fetchMock = vi.fn();

afterEach(() => {
  vi.restoreAllMocks();
  vi.clearAllMocks();
});

async function cargar() {
  vi.stubGlobal("fetch", fetchMock);
  render(<PantallaPago {...props} />);
  await screen.findByRole("heading", { name: "Método de pago" });
}

describe("FE-8.1 pantalla de pago", () => {
  it("muestra resumen y exactamente dos métodos", async () => {
    fetchMock.mockResolvedValue(respuesta(200, resumen));
    await cargar();
    expect(
      screen.getByRole("heading", { name: "Pagar reserva" }),
    ).toBeInTheDocument();
    expect(screen.getAllByRole("radio")).toHaveLength(2);
    expect(screen.getByText(/Alquiler \(2 ×/)).toBeInTheDocument();
    expect(screen.getByText(/2 días/)).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /Pagar/ })).toBeEnabled();
  });

  it("un pago aprobado ofrece enlace al comprobante", async () => {
    fetchMock
      .mockResolvedValueOnce(respuesta(200, resumen))
      .mockResolvedValueOnce(
        respuesta(201, {
          pagoId: "pago-1",
          reservaId: ID,
          fechaHora: "2026-11-20T00:00:00Z",
          total: 185,
          modalidad: "TRANSFERENCIA_BANCARIA",
          estado: "SIMULADO_EXITOSO",
        }),
      );
    await cargar();
    await userEvent.click(
      screen.getByRole("radio", { name: /Transferencia bancaria/ }),
    );
    await userEvent.type(
      screen.getByRole("textbox", { name: /Referencia de transferencia/ }),
      "SIM-APRUEBA",
    );
    await userEvent.click(screen.getByRole("button", { name: /Pagar/ }));
    expect(await screen.findByText("Pago aprobado")).toBeInTheDocument();
    expect(
      screen.getByRole("link", { name: "Ver comprobante" }),
    ).toHaveAttribute("href", "/pagos/pago-1/comprobante");
    expect(
      screen.queryByRole("heading", { name: "Método de pago" }),
    ).not.toBeInTheDocument();
  });

  it("un pago rechazado muestra motivo y no muestra aprobación", async () => {
    fetchMock
      .mockResolvedValueOnce(respuesta(200, resumen))
      .mockResolvedValueOnce(
        respuesta(201, {
          pagoId: "pago-2",
          reservaId: ID,
          fechaHora: "2026-11-20T00:00:00Z",
          total: 185,
          modalidad: "TRANSFERENCIA_BANCARIA",
          estado: "SIMULADO_RECHAZADO",
          motivoRechazo: "Referencia rechazada",
        }),
      );
    await cargar();
    await userEvent.click(
      screen.getByRole("radio", { name: /Transferencia bancaria/ }),
    );
    await userEvent.type(
      screen.getByRole("textbox", { name: /Referencia de transferencia/ }),
      "SIM-RECHAZA",
    );
    await userEvent.click(screen.getByRole("button", { name: /Pagar/ }));
    expect(await screen.findByText("Referencia rechazada")).toBeInTheDocument();
    expect(screen.queryByText("Pago aprobado")).not.toBeInTheDocument();
  });

  it("409 muestra aviso y conserva resumen; 422 muestra no disponible", async () => {
    fetchMock.mockResolvedValue(
      respuesta(409, { message: "Ya pagada", pagoId: "pago-3" }),
    );
    vi.stubGlobal("fetch", fetchMock);
    const { unmount } = render(<PantallaPago {...props} />);
    expect(
      await screen.findByText(/Esta reserva ya tiene un pago completado/),
    ).toBeInTheDocument();
    expect(
      screen.getByRole("heading", { name: "Resumen de tu reserva" }),
    ).toBeInTheDocument();
    expect(
      screen.getByRole("link", { name: "Ver comprobante" }),
    ).toHaveAttribute("href", "/pagos/pago-3/comprobante");
    unmount();
    fetchMock.mockResolvedValue(
      respuesta(422, { message: "Reserva no confirmada" }),
    );
    render(<PantallaPago {...props} />);
    expect(
      await screen.findByText("Reserva no confirmada"),
    ).toBeInTheDocument();
  });

  it("reserva ya pagada: no pide el resumen y ofrece el comprobante", async () => {
    vi.stubGlobal("fetch", fetchMock);
    render(
      <PantallaPago {...props} pagoPrevio={{ id: "pago-7", total: 185 }} />,
    );
    expect(
      await screen.findByText(/Esta reserva ya tiene un pago completado/),
    ).toBeInTheDocument();
    expect(
      screen.getByRole("link", { name: "Ver comprobante" }),
    ).toHaveAttribute("href", "/pagos/pago-7/comprobante");
    expect(
      screen.getByRole("heading", { name: "Resumen de tu reserva" }),
    ).toBeInTheDocument();
    expect(screen.getByText("$185.00 USD")).toBeInTheDocument();
    expect(screen.queryAllByRole("radio")).toHaveLength(0);
    expect(
      screen.queryByRole("button", { name: /Pagar/ }),
    ).not.toBeInTheDocument();
    expect(fetchMock).not.toHaveBeenCalled();
  });

  it("401 redirige y 403 muestra falta de permisos", async () => {
    fetchMock.mockResolvedValue(respuesta(401, {}));
    vi.stubGlobal("fetch", fetchMock);
    const { unmount } = render(<PantallaPago {...props} />);
    await waitFor(() =>
      expect(navegacion.replace).toHaveBeenCalledWith("/sesion-vencida"),
    );
    unmount();
    fetchMock.mockResolvedValue(respuesta(403, {}));
    render(<PantallaPago {...props} />);
    expect(
      await screen.findByText("No puedes realizar este pago."),
    ).toBeInTheDocument();
  });

  it("mantiene una sola petición mientras se procesa el pago", async () => {
    let resolver!: (valor: unknown) => void;
    fetchMock
      .mockResolvedValueOnce(respuesta(200, resumen))
      .mockImplementationOnce(
        () =>
          new Promise((resolve) => {
            resolver = resolve;
          }),
      );
    await cargar();
    await userEvent.click(
      screen.getByRole("radio", { name: /Transferencia bancaria/ }),
    );
    await userEvent.type(
      screen.getByRole("textbox", { name: /Referencia de transferencia/ }),
      "SIM-APRUEBA",
    );
    await userEvent.click(screen.getByRole("button", { name: /Pagar/ }));

    expect(screen.getByRole("button", { name: /Procesando/ })).toBeDisabled();

    expect(fetchMock).toHaveBeenCalledTimes(2);

    resolver(
      respuesta(201, {
        pagoId: "p",
        reservaId: ID,
        fechaHora: "2026-11-20T00:00:00Z",
        total: 185,
        modalidad: "TRANSFERENCIA_BANCARIA",
        estado: "SIMULADO_EXITOSO",
      }),
    );
    await screen.findByText("Pago aprobado");
  });
});
