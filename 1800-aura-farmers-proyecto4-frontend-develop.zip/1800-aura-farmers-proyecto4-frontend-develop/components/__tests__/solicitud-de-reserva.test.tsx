import { act, fireEvent, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { SolicitudDeReserva } from "@/components/solicitud-de-reserva";
import type { BienParaSolicitud } from "@/lib/solicitud/tipos";

vi.mock("@/app/actions/auth", () => ({ cerrarSesion: vi.fn() }));

const BIEN: BienParaSolicitud = {
  id: "5a3f2c10-8d4e-4b1a-9c7e-1f2a3b4c5d6e",
  titulo: "Salón de eventos Las Palmas",
  precio: 80,
  unidadCobro: "DIA",
  deposito: 25,
};
const RESERVA_ID = "20000000-0000-4000-8000-000000000001";

const disponibilidad = {
  bienId: BIEN.id,
  reservados: [{ fechaInicio: "2026-11-20", fechaFin: "2026-11-22" }],
  bloqueados: [],
};

function reserva(estado: string, motivoResolucion: string | null = null) {
  return {
    id: RESERVA_ID,
    bienId: BIEN.id,
    arrendatarioId: "30000000-0000-4000-8000-000000000001",
    fechaInicio: "2026-11-24",
    fechaFin: "2026-11-25",
    estado,
    motivoResolucion,
    creadaEn: "2026-11-19T10:00:00.000Z",
    procesadaEn: null,
  };
}

const json = (cuerpo: unknown, estado = 200) =>
  Promise.resolve(new Response(JSON.stringify(cuerpo), { status: estado }));

/**
 * Backend simulado: `envio` responde al POST y cada consulta toma la siguiente
 * respuesta de `consultas` (la última se repite).
 */
function simularApi({
  envio,
  consultas = [],
}: {
  envio: () => Promise<Response>;
  consultas?: Array<() => Promise<Response>>;
}) {
  let consulta = 0;
  const fetchSimulado = vi.fn((url: string, opciones?: RequestInit) => {
    if (url.includes("/disponibilidad")) return json(disponibilidad);
    if (url === "/api/reservas" && opciones?.method === "POST") return envio();
    if (url.startsWith("/api/reservas/")) {
      const respuesta = consultas[Math.min(consulta, consultas.length - 1)];
      consulta += 1;
      return respuesta();
    }
    throw new Error(`Llamada inesperada: ${url}`);
  });
  vi.stubGlobal("fetch", fetchSimulado);
  return fetchSimulado;
}

const consultasAlApi = (f: ReturnType<typeof simularApi>) =>
  f.mock.calls.filter(([url]) => (url as string).startsWith("/api/reservas/"));

const dia = (nombre: string) => screen.getByRole("button", { name: nombre });
const botonSolicitar = () => screen.getByRole("button", { name: "Solicitar reserva" });

/** Elige el 24 y el 25 de noviembre, el rango de las capturas de Figma. */
async function elegirRango() {
  await screen.findByRole("grid");
  await userEvent.click(dia("martes, 24 de noviembre de 2026"));
  await userEvent.click(dia("miércoles, 25 de noviembre de 2026"));
}

/** Pasa el tiempo y deja resolver las promesas pendientes (consultas simuladas). */
const avanzar = (ms: number) => act(() => vi.advanceTimersByTimeAsync(ms));

beforeEach(() => {
  // «Hoy» fijo: 18 de noviembre de 2026. Los temporizadores se simulan solo
  // en las pruebas que esperan la respuesta (ver `conTemporizadores`).
  vi.useFakeTimers({ toFake: ["Date"], now: new Date("2026-11-18T18:00:00Z") });
});

afterEach(() => {
  vi.useRealTimers();
  vi.unstubAllGlobals();
});

/** Con `setTimeout` simulado, `userEvent` y `findBy*` de Testing Library se cuelgan: desde aquí se usa `fireEvent`. */
function conTemporizadores() {
  vi.useFakeTimers({ toFake: ["Date", "setTimeout", "clearTimeout"], now: new Date("2026-11-18T18:00:00Z") });
}

describe("SolicitudDeReserva", () => {
  it("sin rango pide elegir fechas y deja el botón deshabilitado", async () => {
    simularApi({ envio: () => json({}) });
    render(<SolicitudDeReserva bien={BIEN} />);
    await screen.findByRole("grid");

    expect(screen.getByText("Elige la fecha de inicio y la de fin en el calendario.")).toBeInTheDocument();
    expect(botonSolicitar()).toBeDisabled();
  });

  it("con un rango muestra el resumen con duración, alquiler estimado y depósito", async () => {
    simularApi({ envio: () => json({}) });
    render(<SolicitudDeReserva bien={BIEN} />);
    await elegirRango();

    expect(screen.getByText("24/11/2026 → 25/11/2026")).toBeInTheDocument();
    expect(screen.getByText("2 días")).toBeInTheDocument();
    expect(screen.getByText("$160.00")).toBeInTheDocument();
    expect(screen.getByText("$25.00")).toBeInTheDocument();
    expect(screen.getByText("La respuesta es automática en un máximo de 10 segundos.")).toBeInTheDocument();
    expect(botonSolicitar()).toBeEnabled();
  });

  it("en un bien por noche estima una noche para 2 días, como cobra el backend", async () => {
    simularApi({ envio: () => json({}) });
    render(<SolicitudDeReserva bien={{ ...BIEN, unidadCobro: "NOCHE" }} />);
    await elegirRango();

    expect(screen.getByText("2 días")).toBeInTheDocument();
    expect(screen.getByText("$80.00")).toBeInTheDocument();
  });

  it("envía una sola vez, muestra «en cola» y bloquea el calendario y un segundo envío", async () => {
    let resolverEnvio!: (r: Response) => void;
    const api = simularApi({
      envio: () => new Promise<Response>((resolver) => (resolverEnvio = resolver)),
      consultas: [() => json(reserva("EN_COLA"))],
    });
    render(<SolicitudDeReserva bien={BIEN} />);
    await elegirRango();
    conTemporizadores();

    fireEvent.click(botonSolicitar());
    // Enviando: el botón queda en «Procesando…» y deshabilitado.
    expect(screen.getByRole("button", { name: /Procesando/ })).toBeDisabled();
    expect(dia("lunes, 30 de noviembre de 2026")).toBeDisabled();

    await act(async () => resolverEnvio(new Response(JSON.stringify(reserva("EN_COLA")), { status: 202 })));
    expect(screen.getByText("Tu solicitud está en cola.")).toBeInTheDocument();
    expect(screen.getByText("Consultando cada 2 segundos…")).toBeInTheDocument();
    expect(screen.getByRole("progressbar")).toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "Solicitar reserva" })).not.toBeInTheDocument();

    const envios = api.mock.calls.filter(([, o]) => (o as RequestInit | undefined)?.method === "POST");
    expect(envios).toHaveLength(1);
  });

  it("consulta cada 2 s y al confirmarse muestra el resultado y deja de consultar", async () => {
    const api = simularApi({
      envio: () => json(reserva("EN_COLA"), 202),
      consultas: [() => json(reserva("EN_COLA")), () => json(reserva("CONFIRMADA"))],
    });
    render(<SolicitudDeReserva bien={BIEN} />);
    await elegirRango();
    conTemporizadores();
    fireEvent.click(botonSolicitar());
    await avanzar(0);

    expect(consultasAlApi(api)).toHaveLength(0);
    await avanzar(2_000);
    expect(consultasAlApi(api)).toHaveLength(1);
    expect(screen.getByText("Tu solicitud está en cola.")).toBeInTheDocument();

    await avanzar(2_000);
    expect(consultasAlApi(api)).toHaveLength(2);
    expect(screen.getByText("¡Reserva confirmada!")).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "Ir a pagar" })).toHaveAttribute("href", `/reservas/${RESERVA_ID}/pago`);
    expect(screen.getByRole("link", { name: "Ver mis reservas" })).toHaveAttribute("href", "/reservas");

    await avanzar(60_000);
    expect(consultasAlApi(api)).toHaveLength(2);
  });

  it("al rechazarse muestra el motivo y «Elegir otras fechas» limpia la selección", async () => {
    simularApi({
      envio: () => json(reserva("EN_COLA"), 202),
      consultas: [() => json(reserva("RECHAZADA", "FECHAS_NO_DISPONIBLES"))],
    });
    render(<SolicitudDeReserva bien={BIEN} />);
    await elegirRango();
    conTemporizadores();
    fireEvent.click(botonSolicitar());
    await avanzar(2_000);

    expect(screen.getByText("Solicitud rechazada")).toBeInTheDocument();
    expect(screen.getByText(/Motivo: fechas no disponibles\./)).toBeInTheDocument();

    fireEvent.click(screen.getByRole("button", { name: "Elegir otras fechas" }));
    await avanzar(0);
    expect(screen.getByRole("grid")).toBeInTheDocument();
    expect(screen.getByText("Elige la fecha de inicio y la de fin en el calendario.")).toBeInTheDocument();
    expect(botonSolicitar()).toBeDisabled();
  });

  it("tras 30 s sin resultado deja de consultar y avisa que sigue en proceso", async () => {
    const api = simularApi({
      envio: () => json(reserva("EN_COLA"), 202),
      consultas: [() => json(reserva("EN_COLA"))],
    });
    render(<SolicitudDeReserva bien={BIEN} />);
    await elegirRango();
    conTemporizadores();
    fireEvent.click(botonSolicitar());

    await avanzar(29_000);
    expect(screen.getByText("Tu solicitud está en cola.")).toBeInTheDocument();

    await avanzar(1_000);
    expect(screen.getByText("Tu solicitud sigue en proceso.")).toBeInTheDocument();
    expect(screen.getByText("Revisa Mis reservas.")).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "Ir a Mis reservas" })).toHaveAttribute("href", "/reservas");

    const consultasHechas = consultasAlApi(api).length;
    expect(consultasHechas).toBeGreaterThanOrEqual(14);
    await avanzar(30_000);
    expect(consultasAlApi(api)).toHaveLength(consultasHechas);
  });

  it("un fallo de red al consultar no corta la espera", async () => {
    simularApi({
      envio: () => json(reserva("EN_COLA"), 202),
      consultas: [() => Promise.reject(new TypeError("network")), () => json(reserva("CONFIRMADA"))],
    });
    render(<SolicitudDeReserva bien={BIEN} />);
    await elegirRango();
    conTemporizadores();
    fireEvent.click(botonSolicitar());

    await avanzar(2_000);
    expect(screen.getByText("Tu solicitud está en cola.")).toBeInTheDocument();
    await avanzar(2_000);
    expect(screen.getByText("¡Reserva confirmada!")).toBeInTheDocument();
  });

  it("si la sesión vence mientras espera, ofrece iniciar sesión de nuevo", async () => {
    simularApi({
      envio: () => json(reserva("EN_COLA"), 202),
      consultas: [() => json({}, 401)],
    });
    render(<SolicitudDeReserva bien={BIEN} />);
    await elegirRango();
    conTemporizadores();
    fireEvent.click(botonSolicitar());
    await avanzar(2_000);

    expect(screen.getByText("Tu sesión expiró.")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Iniciar sesión" })).toBeInTheDocument();
  });

  it("409 muestra que las fechas ya no están disponibles y no consulta", async () => {
    const api = simularApi({ envio: () => json({ message: "solapa" }, 409) });
    render(<SolicitudDeReserva bien={BIEN} />);
    await elegirRango();
    conTemporizadores();
    fireEvent.click(botonSolicitar());
    await avanzar(0);

    expect(screen.getByRole("alert")).toHaveTextContent("Esas fechas ya no están disponibles.");
    expect(consultasAlApi(api)).toHaveLength(0);
    expect(screen.getByRole("button", { name: "Elegir otras fechas" })).toBeInTheDocument();
  });

  it("403 VERIFICACION_REQUERIDA enlaza a la verificación de cuenta", async () => {
    simularApi({ envio: () => json({ codigo: "VERIFICACION_REQUERIDA", mensaje: "x" }, 403) });
    render(<SolicitudDeReserva bien={BIEN} />);
    await elegirRango();
    conTemporizadores();
    fireEvent.click(botonSolicitar());
    await avanzar(0);

    expect(screen.getByText("Debes verificar tu cuenta")).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "Verificar mi cuenta" })).toHaveAttribute("href", "/perfil");
  });

  it("422 muestra el mensaje del servicio", async () => {
    simularApi({ envio: () => json({ message: "No puedes reservar un bien propio." }, 422) });
    render(<SolicitudDeReserva bien={BIEN} />);
    await elegirRango();
    conTemporizadores();
    fireEvent.click(botonSolicitar());
    await avanzar(0);

    expect(screen.getByRole("alert")).toHaveTextContent("No puedes reservar un bien propio.");
  });

  it("401 al enviar ofrece iniciar sesión (acción cerrarSesion)", async () => {
    simularApi({ envio: () => json({}, 401) });
    render(<SolicitudDeReserva bien={BIEN} />);
    await elegirRango();
    conTemporizadores();
    fireEvent.click(botonSolicitar());
    await avanzar(0);

    expect(screen.getByText("Tu sesión expiró.")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Iniciar sesión" })).toHaveAttribute("type", "submit");
  });

  it("un error de red o 500 permite reintentar el mismo rango", async () => {
    let intento = 0;
    simularApi({
      envio: () => (++intento === 1 ? json({}, 500) : json(reserva("EN_COLA"), 202)),
      consultas: [() => json(reserva("EN_COLA"))],
    });
    render(<SolicitudDeReserva bien={BIEN} />);
    await elegirRango();
    conTemporizadores();
    fireEvent.click(botonSolicitar());
    await avanzar(0);

    expect(screen.getByRole("alert")).toHaveTextContent("No pudimos enviar tu solicitud. Intenta de nuevo.");
    fireEvent.click(botonSolicitar());
    await avanzar(0);
    expect(screen.getByText("Tu solicitud está en cola.")).toBeInTheDocument();
  });

  it("al desmontar durante la espera cancela las consultas", async () => {
    const api = simularApi({
      envio: () => json(reserva("EN_COLA"), 202),
      consultas: [() => json(reserva("EN_COLA"))],
    });
    const { unmount } = render(<SolicitudDeReserva bien={BIEN} />);
    await elegirRango();
    conTemporizadores();
    fireEvent.click(botonSolicitar());
    await avanzar(2_000);
    const antes = consultasAlApi(api).length;

    unmount();
    await avanzar(10_000);
    expect(consultasAlApi(api)).toHaveLength(antes);
  });
});
