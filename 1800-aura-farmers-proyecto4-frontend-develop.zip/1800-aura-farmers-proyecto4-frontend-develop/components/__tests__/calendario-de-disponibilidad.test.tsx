import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { cerrarSesion } from "@/app/actions/auth";
import { CalendarioDeDisponibilidad } from "@/components/calendario-de-disponibilidad";

// La acción de servidor usa cookies de Next; aquí solo importa que se invoque.
vi.mock("@/app/actions/auth", () => ({ cerrarSesion: vi.fn() }));

const BIEN = "5a3f2c10-8d4e-4b1a-9c7e-1f2a3b4c5d6e";

const respuestaApi = {
  bienId: BIEN,
  reservados: [{ fechaInicio: "2026-11-20", fechaFin: "2026-11-22" }],
  bloqueados: [{ fechaInicio: "2026-11-26", fechaFin: "2026-11-27" }],
};

function responder(cuerpo: unknown, estado = 200) {
  return Promise.resolve(new Response(JSON.stringify(cuerpo), { status: estado }));
}

/** Botón de un día por su fecha completa, como la anuncia el lector de pantalla. */
const dia = (nombre: string) => screen.getByRole("button", { name: nombre });

beforeEach(() => {
  // «Hoy» fijo: 18 de noviembre de 2026 (mediodía en El Salvador). Solo se
  // falsea la fecha para que los temporizadores de las pruebas sigan reales.
  vi.useFakeTimers({ toFake: ["Date"], now: new Date("2026-11-18T18:00:00Z") });
});

afterEach(() => {
  vi.useRealTimers();
  vi.unstubAllGlobals();
});

describe("CalendarioDeDisponibilidad", () => {
  it("muestra el esqueleto mientras carga y luego el calendario", async () => {
    vi.stubGlobal("fetch", vi.fn(() => responder(respuestaApi)));
    render(<CalendarioDeDisponibilidad bienId={BIEN} />);

    expect(screen.getByRole("status", { name: "Cargando disponibilidad" })).toBeInTheDocument();
    expect(await screen.findByRole("grid", { name: "noviembre 2026" })).toBeInTheDocument();
    expect(screen.queryByRole("status", { name: "Cargando disponibilidad" })).not.toBeInTheDocument();
  });

  it("consulta la ventana de 12 meses desde hoy", async () => {
    const fetchSimulado = vi.fn(() => responder(respuestaApi));
    vi.stubGlobal("fetch", fetchSimulado);
    render(<CalendarioDeDisponibilidad bienId={BIEN} />);
    await screen.findByRole("grid");

    const [url] = fetchSimulado.mock.calls[0] as unknown as [string];
    expect(url).toBe(`/api/bienes/${BIEN}/disponibilidad?desde=2026-11-18&hasta=2027-11-17`);
  });

  it("no deja elegir días pasados, reservados ni bloqueados", async () => {
    vi.stubGlobal("fetch", vi.fn(() => responder(respuestaApi)));
    render(<CalendarioDeDisponibilidad bienId={BIEN} />);
    await screen.findByRole("grid");

    expect(dia("martes, 17 de noviembre de 2026")).toBeDisabled();
    expect(dia("viernes, 20 de noviembre de 2026")).toBeDisabled();
    expect(dia("jueves, 26 de noviembre de 2026")).toBeDisabled();
    expect(dia("miércoles, 18 de noviembre de 2026")).toBeEnabled();
    expect(dia("lunes, 23 de noviembre de 2026")).toBeEnabled();
  });

  it("primer clic es el inicio y el segundo el fin, y avisa al padre", async () => {
    vi.stubGlobal("fetch", vi.fn(() => responder(respuestaApi)));
    const alElegir = vi.fn();
    render(<CalendarioDeDisponibilidad bienId={BIEN} onRangoSeleccionado={alElegir} />);
    await screen.findByRole("grid");

    await userEvent.click(dia("martes, 24 de noviembre de 2026"));
    expect(alElegir).not.toHaveBeenCalled();
    expect(dia("martes, 24 de noviembre de 2026")).toHaveAttribute("aria-pressed", "true");

    await userEvent.click(dia("miércoles, 25 de noviembre de 2026"));
    expect(alElegir).toHaveBeenCalledExactlyOnceWith("2026-11-24", "2026-11-25");
    expect(dia("miércoles, 25 de noviembre de 2026")).toHaveAttribute("aria-pressed", "true");
  });

  it("descarta el rango que incluye días no disponibles y muestra el aviso", async () => {
    vi.stubGlobal("fetch", vi.fn(() => responder(respuestaApi)));
    const alElegir = vi.fn();
    render(<CalendarioDeDisponibilidad bienId={BIEN} onRangoSeleccionado={alElegir} />);
    await screen.findByRole("grid");

    await userEvent.click(dia("miércoles, 18 de noviembre de 2026"));
    await userEvent.click(dia("sábado, 28 de noviembre de 2026"));

    expect(screen.getByRole("alert")).toHaveTextContent("El rango incluye fechas no disponibles.");
    expect(alElegir).not.toHaveBeenCalled();
    expect(dia("miércoles, 18 de noviembre de 2026")).toHaveAttribute("aria-pressed", "false");
  });

  it("un tercer clic empieza una selección nueva", async () => {
    vi.stubGlobal("fetch", vi.fn(() => responder(respuestaApi)));
    const alElegir = vi.fn();
    render(<CalendarioDeDisponibilidad bienId={BIEN} onRangoSeleccionado={alElegir} />);
    await screen.findByRole("grid");

    await userEvent.click(dia("martes, 24 de noviembre de 2026"));
    await userEvent.click(dia("miércoles, 25 de noviembre de 2026"));
    await userEvent.click(dia("sábado, 28 de noviembre de 2026"));

    expect(dia("sábado, 28 de noviembre de 2026")).toHaveAttribute("aria-pressed", "true");
    expect(dia("martes, 24 de noviembre de 2026")).toHaveAttribute("aria-pressed", "false");
    // Se avisó del rango y, al empezar otro, de que ya no hay ninguno vigente.
    expect(alElegir).toHaveBeenNthCalledWith(1, "2026-11-24", "2026-11-25");
    expect(alElegir).toHaveBeenNthCalledWith(2, null, null);
    expect(alElegir).toHaveBeenCalledTimes(2);
  });

  it("no avisa de nada al descartar un rango que nunca se comunicó", async () => {
    vi.stubGlobal("fetch", vi.fn(() => responder(respuestaApi)));
    const alElegir = vi.fn();
    render(<CalendarioDeDisponibilidad bienId={BIEN} onRangoSeleccionado={alElegir} />);
    await screen.findByRole("grid");

    await userEvent.click(dia("miércoles, 18 de noviembre de 2026"));
    await userEvent.click(dia("sábado, 28 de noviembre de 2026"));
    await userEvent.click(dia("domingo, 29 de noviembre de 2026"));

    expect(alElegir).not.toHaveBeenCalled();
  });

  it("un segundo clic anterior al inicio reemplaza el inicio", async () => {
    vi.stubGlobal("fetch", vi.fn(() => responder(respuestaApi)));
    const alElegir = vi.fn();
    render(<CalendarioDeDisponibilidad bienId={BIEN} onRangoSeleccionado={alElegir} />);
    await screen.findByRole("grid");

    await userEvent.click(dia("miércoles, 25 de noviembre de 2026"));
    await userEvent.click(dia("martes, 24 de noviembre de 2026"));

    expect(alElegir).not.toHaveBeenCalled();
    expect(dia("martes, 24 de noviembre de 2026")).toHaveAttribute("aria-pressed", "true");
    expect(dia("miércoles, 25 de noviembre de 2026")).toHaveAttribute("aria-pressed", "false");
  });

  it("navega entre meses sin pasar de hoy ni del mes 12", async () => {
    vi.stubGlobal("fetch", vi.fn(() => responder(respuestaApi)));
    render(<CalendarioDeDisponibilidad bienId={BIEN} />);
    await screen.findByRole("grid");

    expect(screen.queryByRole("button", { name: "Mes anterior" })).not.toBeInTheDocument();
    for (let i = 0; i < 12; i += 1) {
      await userEvent.click(screen.getByRole("button", { name: "Mes siguiente" }));
    }
    expect(screen.getByRole("grid", { name: "noviembre 2027" })).toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "Mes siguiente" })).not.toBeInTheDocument();
    // 18 de noviembre de 2027 ya está fuera de la ventana.
    expect(dia("jueves, 18 de noviembre de 2027")).toBeDisabled();
    expect(dia("miércoles, 17 de noviembre de 2027")).toBeEnabled();
  });

  it("muestra el error con reintento y vuelve a consultar", async () => {
    const fetchSimulado = vi
      .fn()
      .mockImplementationOnce(() => responder({ message: "Error" }, 500))
      .mockImplementation(() => responder(respuestaApi));
    vi.stubGlobal("fetch", fetchSimulado);
    render(<CalendarioDeDisponibilidad bienId={BIEN} />);

    expect(await screen.findByRole("alert")).toHaveTextContent("No pudimos cargar la disponibilidad.");
    await userEvent.click(screen.getByRole("button", { name: "Reintentar" }));

    expect(await screen.findByRole("grid")).toBeInTheDocument();
    expect(fetchSimulado).toHaveBeenCalledTimes(2);
  });

  it("también es un error si la red falla o la respuesta no tiene la forma esperada", async () => {
    vi.stubGlobal("fetch", vi.fn(() => Promise.reject(new TypeError("red"))));
    const { unmount } = render(<CalendarioDeDisponibilidad bienId={BIEN} />);
    expect(await screen.findByRole("alert")).toBeInTheDocument();
    unmount();

    vi.stubGlobal("fetch", vi.fn(() => responder({ otra: "cosa" })));
    render(<CalendarioDeDisponibilidad bienId={BIEN} />);
    await waitFor(() => expect(screen.getByRole("alert")).toBeInTheDocument());
  });

  it("el modo gestión usa el texto de ayuda del arrendador y las mismas reglas", async () => {
    vi.stubGlobal("fetch", vi.fn(() => responder(respuestaApi)));
    const alElegir = vi.fn();
    render(<CalendarioDeDisponibilidad bienId={BIEN} modo="gestion" onRangoSeleccionado={alElegir} />);
    await screen.findByRole("grid");

    expect(screen.getByText(/que quieres bloquear/)).toHaveTextContent(
      "Los días pasados, reservados y bloqueados no se pueden seleccionar.",
    );
    await userEvent.click(dia("domingo, 29 de noviembre de 2026"));
    await userEvent.click(dia("lunes, 30 de noviembre de 2026"));
    expect(alElegir).toHaveBeenCalledExactlyOnceWith("2026-11-29", "2026-11-30");

    // Los días reservados siguen sin poder elegirse.
    expect(dia("sábado, 21 de noviembre de 2026")).toBeDisabled();
  });

  describe("errores de carga", () => {
    it("sesión vencida (401): avisa y ofrece volver a iniciar sesión", async () => {
      vi.stubGlobal("fetch", vi.fn(() => responder({ message: "No autenticado." }, 401)));
      render(<CalendarioDeDisponibilidad bienId={BIEN} />);

      expect(await screen.findByText("Tu sesión expiró.")).toBeInTheDocument();
      expect(screen.queryByRole("button", { name: "Reintentar" })).not.toBeInTheDocument();

      await userEvent.click(screen.getByRole("button", { name: "Iniciar sesión" }));
      expect(cerrarSesion).toHaveBeenCalled();
    });

    it("bien inexistente (404): muestra que la publicación ya no está disponible", async () => {
      vi.stubGlobal("fetch", vi.fn(() => responder({ message: "El bien no existe." }, 404)));
      render(<CalendarioDeDisponibilidad bienId={BIEN} />);

      expect(await screen.findByText("Esta publicación ya no está disponible.")).toBeInTheDocument();
      expect(screen.queryByRole("button", { name: "Reintentar" })).not.toBeInTheDocument();
    });

    it.each([
      ["error del servidor (500)", () => responder({ message: "Error" }, 500)],
      ["API no disponible (502)", () => responder({ message: "No se pudo contactar a la API." }, 502)],
      ["petición inválida (400)", () => responder({ message: "Bien inválido." }, 400)],
      ["sin red", () => Promise.reject(new TypeError("red"))],
    ])("%s: mensaje general con reintento", async (_caso, respuesta) => {
      vi.stubGlobal("fetch", vi.fn(respuesta));
      render(<CalendarioDeDisponibilidad bienId={BIEN} />);

      expect(await screen.findByText("No pudimos cargar la disponibilidad.")).toBeInTheDocument();
      expect(screen.getByRole("button", { name: "Reintentar" })).toBeInTheDocument();
    });
  });
});
