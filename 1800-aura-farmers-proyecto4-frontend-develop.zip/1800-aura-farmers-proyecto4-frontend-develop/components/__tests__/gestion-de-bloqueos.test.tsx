import { render, screen, waitFor, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, beforeAll, beforeEach, describe, expect, it, vi } from "vitest";
import { cerrarSesion } from "@/app/actions/auth";
import { GestionDeBloqueos } from "@/components/gestion-de-bloqueos";

vi.mock("@/app/actions/auth", () => ({ cerrarSesion: vi.fn() }));

const BIEN = "5a3f2c10-8d4e-4b1a-9c7e-1f2a3b4c5d6e";
const BLOQUEO = "7b1e0c22-3d4e-4f5a-8b6c-9d0e1f2a3b4c";

type Ruta = { estado: number; cuerpo?: unknown };

const disponibilidad = {
  bienId: BIEN,
  reservados: [{ fechaInicio: "2026-11-20", fechaFin: "2026-11-22" }],
  bloqueados: [{ fechaInicio: "2026-12-24", fechaFin: "2026-12-26" }],
};
const bloqueos = [{ id: BLOQUEO, fechaInicio: "2026-12-24", fechaFin: "2026-12-26", creadoEn: "2026-11-01T00:00:00Z" }];

/** Simula las rutas de Next; `respuestas` permite cambiar lo que devuelve cada una. */
function simular(respuestas: Record<string, Ruta | undefined> = {}) {
  const porDefecto: Record<string, Ruta> = {
    "GET disponibilidad": { estado: 200, cuerpo: disponibilidad },
    "GET bloqueos": { estado: 200, cuerpo: bloqueos },
    "POST bloqueos": { estado: 201, cuerpo: { id: "nuevo", bienId: BIEN } },
    "DELETE bloqueos": { estado: 204 },
  };
  const llamadas: { clave: string; init?: RequestInit }[] = [];
  const simulado = vi.fn((url: string, init?: RequestInit) => {
    const metodo = init?.method ?? "GET";
    const recurso = url.includes("/disponibilidad") ? "disponibilidad" : "bloqueos";
    const clave = `${metodo} ${recurso}`;
    llamadas.push({ clave, init });
    const ruta = respuestas[clave] ?? porDefecto[clave];
    return Promise.resolve(
      ruta.estado === 204 ? new Response(null, { status: 204 }) : new Response(JSON.stringify(ruta.cuerpo ?? {}), { status: ruta.estado }),
    );
  });
  vi.stubGlobal("fetch", simulado);
  return { llamadas, cuenta: (clave: string) => llamadas.filter((l) => l.clave === clave).length };
}

const dia = (nombre: string) => screen.getByRole("button", { name: nombre });

async function elegirRango() {
  await userEvent.click(dia("martes, 24 de noviembre de 2026"));
  await userEvent.click(dia("miércoles, 25 de noviembre de 2026"));
}

beforeAll(() => {
  HTMLDialogElement.prototype.showModal ??= function (this: HTMLDialogElement) {
    this.setAttribute("open", "");
  };
  HTMLDialogElement.prototype.close ??= function (this: HTMLDialogElement) {
    this.removeAttribute("open");
  };
});

beforeEach(() => {
  vi.useFakeTimers({ toFake: ["Date"], now: new Date("2026-11-18T18:00:00Z") });
});

afterEach(() => {
  vi.useRealTimers();
  vi.unstubAllGlobals();
  vi.mocked(cerrarSesion).mockClear();
});

describe("GestionDeBloqueos", () => {
  it("muestra los bloqueos activos con sus días y las reservas en solo lectura", async () => {
    simular();
    render(<GestionDeBloqueos bienId={BIEN} />);

    expect(await screen.findByText("24/12/2026 → 26/12/2026")).toBeInTheDocument();
    expect(screen.getByText("3 días")).toBeInTheDocument();
    const reservas = screen.getByRole("heading", { name: "Reservas confirmadas (solo lectura)" }).closest("section")!;
    expect(await within(reservas).findByText("20/11/2026 → 22/11/2026")).toBeInTheDocument();
    // Las reservas no tienen ninguna acción.
    expect(within(reservas).queryByRole("button")).not.toBeInTheDocument();
  });

  it("deshabilita «Bloquear fechas» hasta elegir un rango y rellena Desde y Hasta", async () => {
    simular();
    render(<GestionDeBloqueos bienId={BIEN} />);
    await screen.findByRole("grid");
    expect(screen.getByRole("button", { name: "Bloquear fechas" })).toBeDisabled();

    await elegirRango();

    expect(screen.getByLabelText("Desde")).toHaveValue("24/11/2026");
    expect(screen.getByLabelText("Hasta")).toHaveValue("25/11/2026");
    expect(screen.getByRole("button", { name: "Bloquear fechas" })).toBeEnabled();
  });

  it("bloquea el rango, avisa y vuelve a consultar el calendario y la lista", async () => {
    const { llamadas, cuenta } = simular();
    render(<GestionDeBloqueos bienId={BIEN} />);
    await screen.findByRole("grid");
    await elegirRango();

    await userEvent.click(screen.getByRole("button", { name: "Bloquear fechas" }));

    expect(await screen.findByText("Fechas bloqueadas")).toBeInTheDocument();
    expect(screen.getByText("Del 24/11/2026 al 25/11/2026. Ya no se pueden reservar.")).toBeInTheDocument();
    const envio = llamadas.find((l) => l.clave === "POST bloqueos")!;
    expect(JSON.parse(String(envio.init?.body))).toEqual({ fechaInicio: "2026-11-24", fechaFin: "2026-11-25" });
    await waitFor(() => {
      expect(cuenta("GET disponibilidad")).toBe(2);
      expect(cuenta("GET bloqueos")).toBe(2);
    });
    // La selección se limpió con la recarga.
    await screen.findByRole("grid");
    expect(screen.getByLabelText("Desde")).toHaveValue("");
    expect(screen.getByRole("button", { name: "Bloquear fechas" })).toBeDisabled();
  });

  it.each([
    [409, { message: "x", reservaId: "r" }, "Hay una reserva confirmada en ese rango."],
    [409, { message: "x", bloqueoId: "b" }, "El rango se solapa con otro bloqueo de este bien."],
    [403, { message: "no" }, "No puedes modificar este bien."],
    [422, { message: "La fecha de inicio no puede ser anterior a hoy." }, "La fecha de inicio no puede ser anterior a hoy."],
  ])("ante un %s muestra su mensaje sin alterar el calendario", async (estado, cuerpo, mensaje) => {
    const { cuenta } = simular({ "POST bloqueos": { estado, cuerpo } });
    render(<GestionDeBloqueos bienId={BIEN} />);
    await screen.findByRole("grid");
    await elegirRango();

    await userEvent.click(screen.getByRole("button", { name: "Bloquear fechas" }));

    expect(await screen.findByRole("alert")).toHaveTextContent(mensaje);
    // No se recarga ni se pierde la selección.
    expect(cuenta("GET disponibilidad")).toBe(1);
    expect(screen.getByLabelText("Desde")).toHaveValue("24/11/2026");
    expect(dia("martes, 24 de noviembre de 2026")).toHaveAttribute("aria-pressed", "true");
  });

  it("un fallo de red al bloquear muestra el mensaje general", async () => {
    simular();
    render(<GestionDeBloqueos bienId={BIEN} />);
    await screen.findByRole("grid");
    await elegirRango();
    vi.stubGlobal("fetch", vi.fn(() => Promise.reject(new TypeError("red"))));

    await userEvent.click(screen.getByRole("button", { name: "Bloquear fechas" }));

    expect(await screen.findByRole("alert")).toHaveTextContent("No pudimos completar la acción.");
  });

  it("con 401 al bloquear ofrece volver a iniciar sesión (cerrarSesion)", async () => {
    simular({ "POST bloqueos": { estado: 401, cuerpo: { message: "No autenticado." } } });
    render(<GestionDeBloqueos bienId={BIEN} />);
    await screen.findByRole("grid");
    await elegirRango();

    await userEvent.click(screen.getByRole("button", { name: "Bloquear fechas" }));

    expect(await screen.findByText("Tu sesión expiró.")).toBeInTheDocument();
    await userEvent.click(screen.getByRole("button", { name: "Iniciar sesión" }));
    expect(cerrarSesion).toHaveBeenCalled();
  });

  it("pide confirmación antes de eliminar y cancelar no llama a la API", async () => {
    const { cuenta } = simular();
    render(<GestionDeBloqueos bienId={BIEN} />);
    await userEvent.click(await screen.findByRole("button", { name: /Eliminar el bloqueo del 24\/12\/2026/ }));

    const dialogo = screen.getByRole("dialog", { name: "¿Eliminar este bloqueo?" });
    expect(dialogo).toHaveTextContent("Las fechas del 24/12/2026 al 26/12/2026 volverán a estar disponibles para reservar.");
    await userEvent.click(within(dialogo).getByRole("button", { name: "Cancelar" }));

    expect(cuenta("DELETE bloqueos")).toBe(0);
    expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
  });

  it("elimina el bloqueo confirmado, avisa y refresca", async () => {
    const { llamadas, cuenta } = simular();
    render(<GestionDeBloqueos bienId={BIEN} />);
    await userEvent.click(await screen.findByRole("button", { name: /Eliminar el bloqueo del 24\/12\/2026/ }));

    await userEvent.click(within(screen.getByRole("dialog")).getByRole("button", { name: "Eliminar" }));

    expect(await screen.findByText("Bloqueo eliminado")).toBeInTheDocument();
    expect(llamadas.some((l) => l.clave === "DELETE bloqueos" && l.init?.method === "DELETE")).toBe(true);
    await waitFor(() => expect(cuenta("GET bloqueos")).toBe(2));
  });

  it("si el bloqueo ya no existe (404) lo informa y refresca la lista", async () => {
    const { cuenta } = simular({ "DELETE bloqueos": { estado: 404, cuerpo: { message: "El bloqueo no existe." } } });
    render(<GestionDeBloqueos bienId={BIEN} />);
    await userEvent.click(await screen.findByRole("button", { name: /Eliminar el bloqueo del 24\/12\/2026/ }));

    await userEvent.click(within(screen.getByRole("dialog")).getByRole("button", { name: "Eliminar" }));

    expect(await screen.findByRole("alert")).toHaveTextContent("Ese bloqueo ya no existe.");
    await waitFor(() => expect(cuenta("GET bloqueos")).toBe(2));
  });

  it("un 403 al eliminar muestra el mensaje y no refresca", async () => {
    const { cuenta } = simular({ "DELETE bloqueos": { estado: 403, cuerpo: {} } });
    render(<GestionDeBloqueos bienId={BIEN} />);
    await userEvent.click(await screen.findByRole("button", { name: /Eliminar el bloqueo del 24\/12\/2026/ }));

    await userEvent.click(within(screen.getByRole("dialog")).getByRole("button", { name: "Eliminar" }));

    expect(await screen.findByRole("alert")).toHaveTextContent("No puedes modificar este bien.");
    expect(cuenta("GET bloqueos")).toBe(1);
  });

  it("sin bloqueos muestra el estado vacío", async () => {
    simular({ "GET bloqueos": { estado: 200, cuerpo: [] } });
    render(<GestionDeBloqueos bienId={BIEN} />);
    expect(await screen.findByText("No tienes bloqueos vigentes.")).toBeInTheDocument();
  });

  it("si la lista falla permite reintentar sin perder el calendario", async () => {
    const { cuenta } = simular({ "GET bloqueos": { estado: 500, cuerpo: {} } });
    render(<GestionDeBloqueos bienId={BIEN} />);

    expect(await screen.findByText("No pudimos cargar los bloqueos.")).toBeInTheDocument();
    expect(screen.getByRole("grid")).toBeInTheDocument();
    await userEvent.click(screen.getByRole("button", { name: "Reintentar" }));
    await waitFor(() => expect(cuenta("GET bloqueos")).toBe(2));
  });

  it("un 403 al listar (bien de otro arrendador o arrendatario) reemplaza la vista", async () => {
    simular({ "GET bloqueos": { estado: 403, cuerpo: {} } });
    render(<GestionDeBloqueos bienId={BIEN} />);

    expect(await screen.findByText("No puedes modificar este bien.")).toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "Bloquear fechas" })).not.toBeInTheDocument();
  });

  it("un 401 al listar ofrece iniciar sesión de nuevo", async () => {
    simular({ "GET bloqueos": { estado: 401, cuerpo: {} } });
    render(<GestionDeBloqueos bienId={BIEN} />);
    expect(await screen.findByText("Tu sesión expiró.")).toBeInTheDocument();
  });
});
