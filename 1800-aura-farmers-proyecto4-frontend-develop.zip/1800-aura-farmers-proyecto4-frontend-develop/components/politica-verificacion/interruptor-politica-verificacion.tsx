"use client";

import Link from "next/link";
import { useRef, useState } from "react";
import { cerrarSesion } from "@/app/actions/auth";
import { Icono, Interruptor, clasesBoton } from "@/components/ui";
import { actualizarPolitica } from "@/lib/politica-verificacion";
import { EtiquetaSoloVerificados } from "./etiqueta-solo-verificados";

type Props = {
  bienId: string;
  /** Valor guardado al cargar la página (`GET /bienes/:id/politica-verificacion`). */
  soloVerificadosInicial: boolean;
  /**
   * Si el arrendador está VERIFICADO (`GET /verificaciones/mi-estado`). Si no, no
   * puede activar la opción (sí desactivarla, si ya estaba activa).
   */
  arrendadorVerificado: boolean;
  /** Enlace a la carga del documento. */
  hrefVerificacion?: string;
  /** Qué hacer si la sesión venció (401). Por defecto, cerrar sesión. */
  alSesionVencida?: () => void;
  /** Se llama con el valor guardado tras cada cambio exitoso. */
  alGuardar?: (soloVerificados: boolean) => void;
};

/**
 * Tarjeta «Quién puede reservar» de la gestión del bien: interruptor de la
 * política «Solo usuarios verificados» (H19, FE-19.1).
 *
 * Al cambiarlo se aplica de inmediato y se guarda con `PUT`. Si falla, vuelve al
 * estado anterior y el error se muestra bajo el interruptor; mientras guarda no
 * admite otro envío.
 */
export function InterruptorPoliticaVerificacion({
  bienId,
  soloVerificadosInicial,
  arrendadorVerificado,
  hrefVerificacion = "/perfil",
  alSesionVencida = () => void cerrarSesion(),
  alGuardar,
}: Props) {
  const [activo, setActivo] = useState(soloVerificadosInicial);
  const [guardando, setGuardando] = useState(false);
  const [error, setError] = useState<string | null>(null);
  // El estado se actualiza tras el render; la referencia corta el doble clic.
  const enCurso = useRef(false);

  async function cambiar(nuevo: boolean) {
    if (enCurso.current) return;
    enCurso.current = true;
    const anterior = activo;
    setActivo(nuevo);
    setGuardando(true);
    setError(null);

    const resultado = await actualizarPolitica(bienId, nuevo);
    if (resultado.ok) {
      setActivo(resultado.politica.soloVerificados);
      alGuardar?.(resultado.politica.soloVerificados);
    } else {
      setActivo(anterior);
      if (resultado.tipo === "sesion") alSesionVencida();
      else setError(resultado.mensaje);
    }
    setGuardando(false);
    enCurso.current = false;
  }

  const bloqueado = !arrendadorVerificado && !activo;

  return (
    <section
      aria-labelledby={`politica-${bienId}`}
      className="flex flex-col items-start gap-espacio-4 border border-borde-default bg-fondo-superficie p-espacio-5"
    >
      <h2 id={`politica-${bienId}`} className="texto-h3 text-texto-primario">
        Quién puede reservar
      </h2>

      <Interruptor
        texto="Solo usuarios verificados"
        checked={activo}
        disabled={guardando || bloqueado}
        aria-busy={guardando}
        aria-describedby={error ? `politica-error-${bienId}` : undefined}
        onChange={(evento) => void cambiar(evento.target.checked)}
      />

      <p className="texto-cuerpo-pequeno text-texto-secundario">
        {activo
          ? 'Activo: solo los arrendatarios con estado "Verificado" pueden enviar solicitudes. El detalle del bien muestra la etiqueta "Solo usuarios verificados".'
          : "Desactivado: cualquier arrendatario puede solicitar este bien."}
      </p>

      {bloqueado && (
        <div className="flex w-full flex-col items-start gap-espacio-2 bg-fondo-info p-espacio-4">
          <p className="texto-etiqueta text-texto-primario">Verifica tu cuenta para activar esta opción.</p>
          <Link href={hrefVerificacion} className={clasesBoton({ jerarquia: "terciario" })}>
            <Icono nombre="verificado" tamano={20} />
            Ir a la verificación de identidad
          </Link>
        </div>
      )}

      {error && (
        <p id={`politica-error-${bienId}`} role="alert" className="texto-cuerpo-pequeno text-texto-error">
          {error}
        </p>
      )}

      {activo && (
        <div className="flex flex-col items-start gap-espacio-2">
          <p className="texto-etiqueta-pequena text-texto-secundario">Así lo ven los arrendatarios en el detalle:</p>
          <EtiquetaSoloVerificados />
        </div>
      )}
    </section>
  );
}
