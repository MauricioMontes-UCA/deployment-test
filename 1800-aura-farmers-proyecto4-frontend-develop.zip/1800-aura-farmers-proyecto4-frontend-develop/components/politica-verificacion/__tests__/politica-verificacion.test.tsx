import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, describe, expect, it, vi } from "vitest";
import { EtiquetaSoloVerificados } from "../etiqueta-solo-verificados";
import { InterruptorPoliticaVerificacion } from "../interruptor-politica-verificacion";
import { MENSAJES_POLITICA } from "@/lib/politica-verificacion";

vi.mock("@/app/actions/auth", () => ({ cerrarSesion: vi.fn() }));

const BIEN = "10000000-0000-4000-8000-000000000001";

function simularPut(status: number, cuerpo: unknown = {}) {
  let resolver!: () => void;
  const espera = new Promise<void>((r) => (resolver = r));
  const fetchSimulado = vi.fn(async () => {
    await espera;
    return new Response(JSON.stringify(cuerpo), { status, headers: { "Content-Type": "application/json" } });
  });
  vi.stubGlobal("fetch", fetchSimulado);
  return { fetchSimulado, liberar: resolver };
}

function renderizar(props: Partial<Parameters<typeof InterruptorPoliticaVerificacion>[0]> = {}) {
  return render(
    <InterruptorPoliticaVerificacion
      bienId={BIEN}
      soloVerificadosInicial={false}
      arrendadorVerificado
      alSesionVencida={vi.fn()}
      {...props}
    />,
  );
}

afterEach(() => vi.unstubAllGlobals());

describe("EtiquetaSoloVerificados", () => {
  it("muestra el texto de la etiqueta", () => {
    render(<EtiquetaSoloVerificados />);
    expect(screen.getByText("Solo usuarios verificados")).toBeInTheDocument();
  });
});

describe("InterruptorPoliticaVerificacion", () => {
  it("empieza desactivado, sin etiqueta de vista previa", () => {
    renderizar();
    expect(screen.getByRole("switch", { name: "Solo usuarios verificados" })).not.toBeChecked();
    expect(screen.getByText(/Desactivado: cualquier arrendatario/)).toBeInTheDocument();
    expect(screen.queryByText(/Así lo ven los arrendatarios/)).not.toBeInTheDocument();
  });

  it("activa, guarda con PUT y muestra la etiqueta", async () => {
    const alGuardar = vi.fn();
    const { fetchSimulado, liberar } = simularPut(200, { bienId: BIEN, soloVerificados: true });
    renderizar({ alGuardar });
    const interruptor = screen.getByRole("switch");

    await userEvent.click(interruptor);
    expect(interruptor).toBeChecked();
    expect(interruptor).toBeDisabled();
    liberar();

    await waitFor(() => expect(interruptor).toBeEnabled());
    expect(interruptor).toBeChecked();
    expect(alGuardar).toHaveBeenCalledWith(true);
    expect(screen.getByText(/Así lo ven los arrendatarios/)).toBeInTheDocument();
    const [url, init] = fetchSimulado.mock.calls[0] as unknown as [string, RequestInit];
    expect(url).toBe(`/api/bienes/${BIEN}/politica-verificacion`);
    expect(JSON.parse(String(init.body))).toEqual({ soloVerificados: true });
  });

  it("con 403 vuelve al estado anterior y muestra el mensaje", async () => {
    const { liberar } = simularPut(403, { message: "El bien no es tuyo." });
    renderizar();
    const interruptor = screen.getByRole("switch");

    await userEvent.click(interruptor);
    liberar();

    expect(await screen.findByRole("alert")).toHaveTextContent("El bien no es tuyo.");
    expect(interruptor).not.toBeChecked();
    expect(interruptor).toBeEnabled();
  });

  it("con fallo general vuelve al estado anterior y permite reintentar", async () => {
    const { liberar } = simularPut(500);
    renderizar({ soloVerificadosInicial: true });
    const interruptor = screen.getByRole("switch");

    await userEvent.click(interruptor);
    liberar();

    expect(await screen.findByRole("alert")).toHaveTextContent(MENSAJES_POLITICA.general);
    expect(interruptor).toBeChecked();
  });

  it("con 401 avisa que la sesión venció y no muestra error", async () => {
    const alSesionVencida = vi.fn();
    const { liberar } = simularPut(401);
    renderizar({ alSesionVencida });

    await userEvent.click(screen.getByRole("switch"));
    liberar();

    await waitFor(() => expect(alSesionVencida).toHaveBeenCalledOnce());
    expect(screen.queryByRole("alert")).not.toBeInTheDocument();
    expect(screen.getByRole("switch")).not.toBeChecked();
  });

  it("no envía dos veces mientras guarda", async () => {
    const { fetchSimulado, liberar } = simularPut(200, { bienId: BIEN, soloVerificados: true });
    renderizar();
    const interruptor = screen.getByRole("switch");

    await userEvent.click(interruptor);
    await userEvent.click(interruptor);
    liberar();

    await waitFor(() => expect(interruptor).toBeEnabled());
    expect(fetchSimulado).toHaveBeenCalledTimes(1);
  });

  it("arrendador sin verificar: interruptor deshabilitado, aviso y enlace", () => {
    renderizar({ arrendadorVerificado: false, hrefVerificacion: "/perfil" });
    expect(screen.getByRole("switch")).toBeDisabled();
    expect(screen.getByText("Verifica tu cuenta para activar esta opción.")).toBeInTheDocument();
    expect(screen.getByRole("link", { name: /verificación de identidad/ })).toHaveAttribute("href", "/perfil");
  });

  it("arrendador sin verificar con la opción ya activa puede desactivarla", () => {
    renderizar({ arrendadorVerificado: false, soloVerificadosInicial: true });
    expect(screen.getByRole("switch")).toBeEnabled();
    expect(screen.queryByText("Verifica tu cuenta para activar esta opción.")).not.toBeInTheDocument();
  });
});
