import { Icono } from "@/components/ui";
import { unirClases } from "@/lib/clases";

/**
 * Etiqueta «Solo usuarios verificados» del detalle del bien (H19). Sin estado
 * propio: el detalle la monta solo cuando `soloVerificados` es true.
 */
export function EtiquetaSoloVerificados({ className }: { className?: string }) {
  return (
    <span
      className={unirClases(
        "inline-flex items-center gap-espacio-2 bg-fondo-info p-espacio-3 text-texto-primario",
        className,
      )}
    >
      <Icono nombre="verificado" tamano={16} />
      <span className="texto-etiqueta-pequena whitespace-nowrap">Solo usuarios verificados</span>
    </span>
  );
}
