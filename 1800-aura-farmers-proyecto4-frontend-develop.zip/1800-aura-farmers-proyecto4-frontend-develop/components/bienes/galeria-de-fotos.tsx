"use client";

import { useRef, useState, type KeyboardEvent, type TouchEvent } from "react";
import { Icono, Imagen, type IconoNombre } from "@/components/ui";
import { unirClases } from "@/lib/clases";
import type { FotoDetalle } from "@/lib/bienes";

/** Píxeles que hay que deslizar para cambiar de foto; menos se toma como un toque. */
export const UMBRAL_DESLIZAMIENTO = 50;

type GaleriaDeFotosProps = {
  fotos: FotoDetalle[];
  /** Título del bien, para el texto alternativo de cada foto. */
  titulo: string;
  className?: string;
};

/**
 * Galería del detalle del bien (FE-2.1): carrusel que se recorre deslizando,
 * con las flechas, con los indicadores o con las flechas del teclado, y que
 * empieza en la foto principal. En escritorio muestra miniaturas; en móvil,
 * puntos. Cada foto usa `Imagen`, que pone el reemplazo «Foto no disponible»
 * si la URL no carga.
 */
export function GaleriaDeFotos({ fotos, titulo, className }: GaleriaDeFotosProps) {
  // El backend ya manda la principal primero; se busca igual para no depender del orden.
  const [actual, setActual] = useState(() => Math.max(0, fotos.findIndex((foto) => foto.esPrincipal)));
  const inicioToque = useRef<number | null>(null);

  if (fotos.length === 0) {
    return <Imagen src={null} alt={titulo} className={unirClases("aspect-4/3 w-full md:aspect-3/2", className)} />;
  }

  const total = fotos.length;
  const varias = total > 1;
  const ir = (indice: number) => setActual(Math.min(Math.max(indice, 0), total - 1));

  function alTocar(evento: TouchEvent) {
    inicioToque.current = evento.touches[0]?.clientX ?? null;
  }

  function alSoltar(evento: TouchEvent) {
    const inicio = inicioToque.current;
    const fin = evento.changedTouches[0]?.clientX;
    inicioToque.current = null;
    if (inicio === null || fin === undefined) return;
    const recorrido = fin - inicio;
    if (Math.abs(recorrido) < UMBRAL_DESLIZAMIENTO) return;
    // Deslizar hacia la izquierda trae la foto siguiente, como en cualquier carrusel táctil.
    ir(recorrido < 0 ? actual + 1 : actual - 1);
  }

  function alTeclear(evento: KeyboardEvent) {
    if (evento.key === "ArrowLeft") ir(actual - 1);
    else if (evento.key === "ArrowRight") ir(actual + 1);
    else return;
    evento.preventDefault();
  }

  return (
    <section
      aria-roledescription="carrusel"
      aria-label={`Fotos de ${titulo}`}
      className={unirClases("flex flex-col gap-espacio-3", className)}
    >
      <div
        tabIndex={varias ? 0 : undefined}
        onKeyDown={varias ? alTeclear : undefined}
        onTouchStart={varias ? alTocar : undefined}
        onTouchEnd={varias ? alSoltar : undefined}
        className="relative aspect-4/3 w-full touch-pan-y overflow-hidden bg-fondo-sutil md:aspect-[19/13]"
      >
        <ul
          className="flex h-full transition-transform duration-300 ease-out motion-reduce:transition-none"
          style={{ transform: `translateX(-${actual * 100}%)` }}
        >
          {fotos.map((foto, indice) => (
            <li
              key={foto.url}
              role="group"
              aria-roledescription="foto"
              aria-label={`${indice + 1} de ${total}`}
              aria-hidden={indice !== actual}
              inert={indice !== actual}
              className="h-full w-full shrink-0"
            >
              <Imagen
                src={foto.url}
                alt={`${titulo}, foto ${indice + 1} de ${total}`}
                sizes="(min-width: 768px) 60vw, 100vw"
                prioridad={indice === actual}
                className="size-full"
              />
            </li>
          ))}
        </ul>

        {varias && (
          <>
            <Flecha
              icono="chevron-izquierda"
              etiqueta="Foto anterior"
              onClick={actual > 0 ? () => ir(actual - 1) : undefined}
              className="left-espacio-4"
            />
            <Flecha
              icono="chevron-derecha"
              etiqueta="Foto siguiente"
              onClick={actual < total - 1 ? () => ir(actual + 1) : undefined}
              className="right-espacio-4"
            />
            {/* Figma no muestra un contador; se conserva para el lector de pantalla. */}
            <p aria-live="polite" className="solo-lector">
              {actual + 1} / {total}
            </p>
            <ul
              aria-label="Elegir foto"
              className="absolute bottom-espacio-2 left-1/2 flex -translate-x-1/2 gap-1.5"
            >
              {fotos.map((foto, indice) => (
                <li key={foto.url}>
                  <button
                    type="button"
                    aria-label={`Ver foto ${indice + 1} de ${total}`}
                    aria-current={indice === actual || undefined}
                    onClick={() => ir(indice)}
                    // El indicador mide 4 px de alto; el botón da un área táctil mayor.
                    className="flex cursor-pointer py-espacio-2"
                  >
                    <span
                      className={unirClases(
                        "h-1",
                        indice === actual ? "w-5 bg-fondo-marca" : "w-2 bg-fondo-superficie",
                      )}
                    />
                  </button>
                </li>
              ))}
            </ul>
          </>
        )}
      </div>

      {varias && (
        <ul aria-label="Miniaturas" className="hidden flex-wrap gap-espacio-3 md:flex">
          {fotos.map((foto, indice) => (
            <li key={foto.url}>
              <button
                type="button"
                aria-label={`Ver foto ${indice + 1} de ${total}`}
                aria-current={indice === actual || undefined}
                onClick={() => ir(indice)}
                className={unirClases(
                  "relative flex h-20 w-28 cursor-pointer",
                  indice === actual ? "" : "opacity-75 hover:opacity-100",
                )}
              >
                <Imagen src={foto.url} alt="" sizes="112px" className="size-full" />
                {indice === actual && (
                  <span aria-hidden className="absolute inset-0 border-2 border-fondo-marca" />
                )}
              </button>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}

function Flecha({
  icono,
  etiqueta,
  onClick,
  className,
}: {
  icono: IconoNombre;
  etiqueta: string;
  onClick?: () => void;
  className: string;
}) {
  return (
    <button
      type="button"
      aria-label={etiqueta}
      onClick={onClick}
      disabled={!onClick}
      className={unirClases(
        "absolute top-1/2 inline-flex -translate-y-1/2 cursor-pointer border border-borde-fuerte bg-fondo-superficie p-2.5 text-texto-primario hover:bg-fondo-sutil disabled:cursor-not-allowed disabled:opacity-40",
        className,
      )}
    >
      <Icono nombre={icono} tamano={20} />
    </button>
  );
}
