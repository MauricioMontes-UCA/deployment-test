import Link from "next/link";
import type { ReactNode } from "react";
import { GaleriaDeFotos } from "@/components/bienes/galeria-de-fotos";
import { ResenasDelBien } from "@/components/bienes/resenas-del-bien";
import { SolicitudDeReserva } from "@/components/solicitud-de-reserva";
import { Alerta, Calificacion, Contenedor, Icono, clasesBoton } from "@/components/ui";
import {
  NOMBRE_TIPO,
  contarResenas,
  formatearDeposito,
  formatearPrecio,
  formatearPromedio,
  type BienDetalle,
  type PaginaResenas,
} from "@/lib/bienes";

type DetalleDelBienProps = {
  bien: BienDetalle;
  /**
   * La disponibilidad pide token: sin sesión, en lugar del calendario se
   * invita a iniciar sesión.
   */
  conSesion: boolean;
  /** Quien mira es el arrendador del bien: no se le ofrece consultarse a sí mismo. */
  esDelUsuario?: boolean;
  /** Primera página de reseñas (BE-15.2); `null` si no se pudo cargar. */
  resenas?: PaginaResenas | null;
  /** Llegó desde «Publicar» (H1): muestra «Tu publicación ya está visible». */
  recienPublicado?: boolean;
};

/** Ruta de la consulta previa al arrendador (H13, `/publicaciones/[bienId]/conversacion`). */
export const rutaDeConsulta = (bienId: string) => `/publicaciones/${bienId}/conversacion`;

/** Márgenes del contenido, como en Figma: 40/96 px en escritorio y 24/48 px en móvil. */
const CLASES_CONTENIDO =
  "flex flex-col gap-espacio-6 pt-espacio-5 pb-espacio-7 md:gap-espacio-7 md:pt-10 md:pb-espacio-9";
/** Galería y resumen: lado a lado en escritorio, con el resumen de 496 px. */
const CLASES_SUPERIOR = "flex flex-col gap-espacio-5 lg:flex-row lg:items-start lg:gap-14";

/**
 * Detalle de un bien publicado (FE-2.1): galería, tipo y categoría, precio con
 * su unidad, depósito («Sin depósito de garantía» si es 0), descripción,
 * condiciones, ubicación, capacidad si aplica y arrendador. Incluye las piezas
 * de otras historias que Figma pone en esta pantalla: la calificación y las
 * reseñas (H15), el calendario con «Tu selección» (H5/H6) y la consulta al
 * arrendador (H13).
 */
export function DetalleDelBien({
  bien,
  conSesion,
  esDelUsuario = false,
  resenas = null,
  recienPublicado = false,
}: DetalleDelBienProps) {
  const promedio = bien.calificacion?.promedio ?? null;
  const [monto, unidad] = formatearPrecio(bien.precio, bien.unidadCobro).split(" / ");

  return (
    <Contenedor className={CLASES_CONTENIDO}>
      {recienPublicado && (
        <Alerta tono="exito" titulo="Tu publicación ya está visible">
          Los arrendatarios ya pueden encontrarla en la búsqueda.
        </Alerta>
      )}

      <nav aria-label="Migas de pan" className="texto-cuerpo-pequeno hidden text-texto-secundario md:block">
        <Link href="/buscar" className="hover:text-texto-primario hover:underline">
          Buscar
        </Link>
        <span aria-hidden className="whitespace-pre">{"  ›  "}</span>
        {bien.categoria}
        <span aria-hidden className="whitespace-pre">{"  ›  "}</span>
        <span aria-current="page">{bien.titulo}</span>
      </nav>

      <div className={CLASES_SUPERIOR}>
        <GaleriaDeFotos fotos={bien.fotos} titulo={bien.titulo} className="min-w-0 lg:flex-1" />

        <div className="flex flex-col gap-espacio-4 lg:w-124 lg:shrink-0">
          <p className="texto-sobretitulo text-texto-acento">
            {NOMBRE_TIPO[bien.tipo]} · {bien.categoria}
          </p>
          <h1 className="texto-h1 break-words text-texto-primario">{bien.titulo}</h1>
          <p className="flex flex-wrap items-baseline gap-espacio-2">
            <span className="texto-precio-grande text-texto-primario">{monto}</span>{" "}
            <span className="texto-cuerpo-grande text-texto-secundario">/ {unidad}</span>
          </p>

          <dl className="flex flex-col border border-borde-default bg-fondo-superficie p-espacio-4">
            <Dato etiqueta="Depósito de garantía" destacado>
              {formatearDeposito(bien.deposito)}
            </Dato>
            <Dato etiqueta="Ubicación">{`${bien.municipio}, ${bien.departamento}`}</Dato>
            {bien.direccionReferencia && <Dato etiqueta="Referencia">{bien.direccionReferencia}</Dato>}
            {bien.capacidad !== null && <Dato etiqueta="Capacidad">{`${bien.capacidad} personas`}</Dato>}
            <Dato etiqueta="Arrendador" destacado>
              {bien.arrendador.nombreUsuario}
            </Dato>
            {bien.calificacion && (
              <div className="flex items-center gap-espacio-2 pt-2.5">
                {promedio !== null ? (
                  <>
                    <Calificacion valor={promedio} etiqueta="Calificación promedio del bien" />
                    <span className="texto-etiqueta text-texto-primario">
                      {formatearPromedio(promedio)} · {contarResenas(bien.calificacion.totalResenas)}
                    </span>
                  </>
                ) : (
                  <span className="texto-cuerpo-pequeno text-texto-secundario">Sin reseñas todavía</span>
                )}
              </div>
            )}
          </dl>

          <a href="#disponibilidad" className={clasesBoton({ className: "w-full" })}>
            <Icono nombre="calendario" tamano={20} />
            Ver disponibilidad y reservar
          </a>
          {!esDelUsuario && (
            <Link href={rutaDeConsulta(bien.id)} className={clasesBoton({ jerarquia: "secundario", className: "w-full" })}>
              <Icono nombre="mensaje" tamano={20} />
              Consultar al arrendador
            </Link>
          )}
        </div>
      </div>

      <div className="grid gap-espacio-5 md:grid-cols-2 md:gap-14">
        <Seccion titulo="Descripción">{bien.descripcion}</Seccion>
        {/* Figma siempre muestra la sección; si el arrendador no puso condiciones, se dice. */}
        <Seccion titulo="Condiciones de uso">
          {bien.condiciones ?? "El arrendador no indicó condiciones de uso."}
        </Seccion>
      </div>

      <hr className="border-borde-sutil" />

      <section id="disponibilidad" aria-label="Disponibilidad" className="flex scroll-mt-espacio-6 flex-col gap-espacio-4">
        {conSesion ? (
          // Trae su propio título «Disponibilidad» y el panel «Tu selección» (H5/H6).
          <SolicitudDeReserva
            bien={{
              id: bien.id,
              titulo: bien.titulo,
              precio: bien.precio,
              unidadCobro: bien.unidadCobro,
              deposito: bien.deposito,
            }}
          />
        ) : (
          <>
          <h2 className="texto-h2 text-texto-primario">Disponibilidad</h2>
          <div className="flex flex-col items-start gap-espacio-3 border border-borde-default bg-fondo-superficie p-espacio-5">
            <p className="texto-cuerpo text-texto-secundario">
              Inicia sesión para ver las fechas disponibles y solicitar una reserva.
            </p>
            <Link href="/login" className={clasesBoton({ jerarquia: "secundario" })}>
              Iniciar sesión
            </Link>
          </div>
          </>
        )}
      </section>

      <hr className="border-borde-sutil" />

      <ResenasDelBien bienId={bien.id} calificacion={bien.calificacion} inicial={resenas} />
    </Contenedor>
  );
}

function Seccion({ titulo, children }: { titulo: string; children: ReactNode }) {
  return (
    <section className="flex min-w-0 flex-col gap-espacio-2">
      <h2 className="texto-h3 text-texto-primario">{titulo}</h2>
      <p className="texto-cuerpo break-words whitespace-pre-line text-texto-secundario">{children}</p>
    </section>
  );
}

/** Fila de la tabla de datos: etiqueta a la izquierda y valor a la derecha, separadas por una línea. */
function Dato({
  etiqueta,
  destacado = false,
  children,
}: {
  etiqueta: string;
  /** En Figma, el depósito y el arrendador van en peso medio. */
  destacado?: boolean;
  children: ReactNode;
}) {
  return (
    <div className="texto-cuerpo-pequeno flex items-start justify-between gap-espacio-3 border-b border-borde-sutil py-2.5 last:border-b-0">
      <dt className="shrink-0 text-texto-secundario">{etiqueta}</dt>
      <dd className={`min-w-0 break-words text-right text-texto-primario ${destacado ? "font-medium" : ""}`}>
        {children}
      </dd>
    </div>
  );
}

/** Esqueleto del detalle mientras llega la respuesta de la API (`loading.tsx`). */
export function DetalleDelBienEsqueleto() {
  return (
    <Contenedor role="status" aria-label="Cargando publicación" className={`animate-pulse ${CLASES_CONTENIDO}`}>
      <div className="hidden h-4 w-80 bg-fondo-sutil md:block" />
      <div className={CLASES_SUPERIOR}>
        <div className="aspect-4/3 w-full bg-fondo-sutil md:aspect-[19/13] lg:flex-1" />
        <div className="flex flex-col gap-espacio-4 lg:w-124 lg:shrink-0">
          <div className="h-4 w-40 bg-fondo-sutil" />
          <div className="h-10 w-3/4 bg-fondo-sutil" />
          <div className="h-10 w-32 bg-fondo-sutil" />
          <div className="h-48 w-full bg-fondo-sutil" />
          <div className="h-12 w-full bg-fondo-sutil" />
        </div>
      </div>
      <div className="flex flex-col gap-espacio-3">
        <div className="h-4 w-full bg-fondo-sutil" />
        <div className="h-4 w-5/6 bg-fondo-sutil" />
      </div>
    </Contenedor>
  );
}
