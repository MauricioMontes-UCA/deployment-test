import { fireEvent, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it } from "vitest";
import { GaleriaDeFotos, UMBRAL_DESLIZAMIENTO } from "@/components/bienes/galeria-de-fotos";
import type { FotoDetalle } from "@/lib/bienes";

const TITULO = "Salón Las Palmas";
const foto = (orden: number, esPrincipal = false): FotoDetalle => ({
  url: `/uploads/bienes/b/${orden}.webp`,
  orden,
  esPrincipal,
});
const TRES = [foto(1, true), foto(2), foto(3)];

/** Foto que se está mostrando: las demás quedan ocultas para el lector de pantalla. */
const fotoVisible = () => screen.getByRole("group").getAttribute("aria-label");

function deslizar(desde: number, hasta: number) {
  const area = screen.getByRole("group").parentElement!.parentElement!;
  fireEvent.touchStart(area, { touches: [{ clientX: desde }] });
  fireEvent.touchEnd(area, { changedTouches: [{ clientX: hasta }] });
}

describe("GaleriaDeFotos", () => {
  it("empieza por la foto principal", () => {
    render(<GaleriaDeFotos fotos={[foto(1), foto(2, true), foto(3)]} titulo={TITULO} />);
    expect(fotoVisible()).toBe("2 de 3");
    expect(screen.getByRole("img", { name: `${TITULO}, foto 2 de 3` })).toBeInTheDocument();
  });

  it("se recorre con las flechas, que se deshabilitan en los extremos", async () => {
    const usuario = userEvent.setup();
    render(<GaleriaDeFotos fotos={TRES} titulo={TITULO} />);
    const anterior = screen.getByRole("button", { name: "Foto anterior" });
    const siguiente = screen.getByRole("button", { name: "Foto siguiente" });

    expect(anterior).toBeDisabled();
    await usuario.click(siguiente);
    expect(fotoVisible()).toBe("2 de 3");
    await usuario.click(siguiente);
    expect(fotoVisible()).toBe("3 de 3");
    expect(siguiente).toBeDisabled();
    await usuario.click(anterior);
    expect(fotoVisible()).toBe("2 de 3");
    expect(screen.getByText("2 / 3")).toBeInTheDocument();
  });

  it("se recorre deslizando e ignora un deslizamiento corto", () => {
    render(<GaleriaDeFotos fotos={TRES} titulo={TITULO} />);

    deslizar(300, 300 - UMBRAL_DESLIZAMIENTO - 10);
    expect(fotoVisible()).toBe("2 de 3");
    deslizar(300, 300 - UMBRAL_DESLIZAMIENTO + 10);
    expect(fotoVisible()).toBe("2 de 3");
    deslizar(100, 100 + UMBRAL_DESLIZAMIENTO + 10);
    expect(fotoVisible()).toBe("1 de 3");
    // Más allá de la primera no hay foto.
    deslizar(100, 300);
    expect(fotoVisible()).toBe("1 de 3");
  });

  it("los indicadores y las miniaturas llevan a su foto", async () => {
    const usuario = userEvent.setup();
    render(<GaleriaDeFotos fotos={TRES} titulo={TITULO} />);
    const [punto, miniatura] = screen.getAllByRole("button", { name: "Ver foto 3 de 3" });

    await usuario.click(punto);
    expect(fotoVisible()).toBe("3 de 3");
    expect(punto).toHaveAttribute("aria-current", "true");
    await usuario.click(screen.getAllByRole("button", { name: "Ver foto 1 de 3" })[1]);
    expect(fotoVisible()).toBe("1 de 3");
    expect(miniatura).not.toHaveAttribute("aria-current");
  });

  it("se recorre con las flechas del teclado", async () => {
    const usuario = userEvent.setup();
    render(<GaleriaDeFotos fotos={TRES} titulo={TITULO} />);
    await usuario.tab();
    await usuario.keyboard("{ArrowRight}{ArrowRight}");
    expect(fotoVisible()).toBe("3 de 3");
    await usuario.keyboard("{ArrowLeft}");
    expect(fotoVisible()).toBe("2 de 3");
  });

  it("una foto rota muestra la imagen de reemplazo", () => {
    render(<GaleriaDeFotos fotos={TRES} titulo={TITULO} />);
    fireEvent.error(screen.getByRole("img", { name: `${TITULO}, foto 1 de 3` }));

    expect(screen.getByRole("group")).toHaveTextContent("Foto no disponible");
    expect(screen.queryByRole("img", { name: `${TITULO}, foto 1 de 3` })).not.toBeInTheDocument();
  });

  it("con una sola foto no muestra controles", () => {
    render(<GaleriaDeFotos fotos={[foto(1, true)]} titulo={TITULO} />);
    expect(screen.getByRole("img", { name: `${TITULO}, foto 1 de 1` })).toBeInTheDocument();
    expect(screen.queryByRole("button")).not.toBeInTheDocument();
  });

  it("sin fotos muestra el reemplazo", () => {
    render(<GaleriaDeFotos fotos={[]} titulo={TITULO} />);
    expect(screen.getByText("Foto no disponible")).toBeInTheDocument();
  });
});
