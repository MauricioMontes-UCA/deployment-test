import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, describe, expect, it, vi } from "vitest";
import { ResenasDelBien } from "@/components/bienes/resenas-del-bien";
import type { PaginaResenas, ResenaDeBien } from "@/lib/bienes";

const BIEN_ID = "7c9e6679-7425-40de-944b-e07fc1f90ae7";

const resena = (n: number, comentario?: string): ResenaDeBien => ({
  id: `r${n}`,
  puntuacion: 5,
  ...(comentario ? { comentario } : {}),
  autor: { nombreUsuario: `usuario_${n}` },
  creadaEn: "2026-11-10T12:00:00.000Z",
});

const pagina = (items: ResenaDeBien[], numero: number, hayMas: boolean): PaginaResenas => ({
  items,
  pagina: numero,
  total: 11,
  hayMas,
});

afterEach(() => vi.unstubAllGlobals());

describe("ResenasDelBien", () => {
  it("muestra el autor, la fecha y el comentario de cada reseña", () => {
    render(
      <ResenasDelBien
        bienId={BIEN_ID}
        calificacion={{ promedio: 4.5, totalResenas: 1 }}
        inicial={pagina([resena(1, "Todo como en las fotos.")], 1, false)}
      />,
    );
    expect(screen.getByText("usuario_1")).toBeInTheDocument();
    expect(screen.getByText("10/11/2026")).toBeInTheDocument();
    expect(screen.getByText("Todo como en las fotos.")).toBeInTheDocument();
    expect(screen.getByText("4.5 / 5 · 1 reseña")).toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "Ver más reseñas" })).not.toBeInTheDocument();
  });

  it("«Ver más reseñas» pide la página siguiente por el puente y la agrega", async () => {
    const fetchFalso = vi.fn().mockResolvedValue(
      new Response(JSON.stringify(pagina([resena(11)], 2, false)), { status: 200 }),
    );
    vi.stubGlobal("fetch", fetchFalso);
    render(
      <ResenasDelBien
        bienId={BIEN_ID}
        inicial={pagina(Array.from({ length: 10 }, (_, i) => resena(i + 1)), 1, true)}
      />,
    );
    await userEvent.click(screen.getByRole("button", { name: "Ver más reseñas" }));

    expect(fetchFalso).toHaveBeenCalledWith(`/api/bienes/${BIEN_ID}/resenas?pagina=2`);
    expect(await screen.findByText("usuario_11")).toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "Ver más reseñas" })).not.toBeInTheDocument();
  });

  it("si no pudo cargar las reseñas lo avisa y permite reintentar", () => {
    render(<ResenasDelBien bienId={BIEN_ID} inicial={null} />);
    expect(screen.getByRole("alert")).toHaveTextContent("No pudimos cargar las reseñas.");
    expect(screen.getByRole("button", { name: "Reintentar" })).toBeInTheDocument();
  });
});
