import { render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import { DetalleDelBien } from "@/components/bienes/detalle-del-bien";
import { BIEN } from "./bien-de-ejemplo";

// El calendario consulta la API y tiene sus propias pruebas.
vi.mock("@/components/calendario-de-disponibilidad", () => ({
  CalendarioDeDisponibilidad: ({ bienId }: { bienId: string }) => <p>Calendario de {bienId}</p>,
}));

describe("DetalleDelBien", () => {
  it("muestra toda la información pública del bien", () => {
    render(<DetalleDelBien bien={BIEN} conSesion />);

    expect(screen.getByRole("heading", { level: 1, name: BIEN.titulo })).toBeInTheDocument();
    expect(screen.getByText("Propiedad · Salón de eventos")).toBeInTheDocument();
    expect(screen.getByText("$80.00").closest("p")).toHaveTextContent("$80.00 / día");
    expect(screen.getByText("$150.00")).toBeInTheDocument();
    expect(screen.getByText("120 personas")).toBeInTheDocument();
    expect(screen.getByText(BIEN.descripcion)).toBeInTheDocument();
    expect(screen.getByText("No se permite pirotecnia")).toBeInTheDocument();
    expect(screen.getByText("Antiguo Cuscatlán, La Libertad")).toBeInTheDocument();
    expect(screen.getByText("Frente al parque central")).toBeInTheDocument();
    expect(screen.getByText("ana_m")).toBeInTheDocument();
    expect(screen.getByText(`Calendario de ${BIEN.id}`)).toBeInTheDocument();
  });

  it("muestra «Sin depósito de garantía» cuando el depósito es 0", () => {
    render(<DetalleDelBien bien={{ ...BIEN, deposito: 0 }} conSesion />);
    expect(screen.getByText("Sin depósito de garantía")).toBeInTheDocument();
    expect(screen.queryByText("$0.00")).not.toBeInTheDocument();
  });

  it("omite la capacidad y la referencia, y avisa cuando no hay condiciones", () => {
    render(
      <DetalleDelBien
        bien={{ ...BIEN, capacidad: null, condiciones: null, direccionReferencia: null }}
        conSesion
      />,
    );
    expect(screen.queryByText("Capacidad")).not.toBeInTheDocument();
    expect(screen.getByRole("heading", { name: "Condiciones de uso" })).toBeInTheDocument();
    expect(screen.getByText("El arrendador no indicó condiciones de uso.")).toBeInTheDocument();
    expect(screen.queryByText("Frente al parque central")).not.toBeInTheDocument();
  });

  it("sin sesión invita a iniciar sesión en lugar del calendario", () => {
    render(<DetalleDelBien bien={BIEN} conSesion={false} />);
    expect(screen.queryByText(/Calendario de/)).not.toBeInTheDocument();
    expect(screen.getByRole("link", { name: "Iniciar sesión" })).toHaveAttribute("href", "/login");
  });

  it("muestra la calificación promedio y el número de reseñas del bien", () => {
    render(<DetalleDelBien bien={{ ...BIEN, calificacion: { promedio: 4.5, totalResenas: 12 } }} conSesion />);
    expect(screen.getByText("4.5 · 12 reseñas")).toBeInTheDocument();
    expect(screen.getByText("4.5 / 5 · 12 reseñas")).toBeInTheDocument();
  });

  it("sin reseñas lo dice en la tabla y en la sección", () => {
    render(
      <DetalleDelBien
        bien={{ ...BIEN, calificacion: { promedio: null, totalResenas: 0 } }}
        conSesion
        resenas={{ items: [], pagina: 1, total: 0, hayMas: false }}
      />,
    );
    expect(screen.getByText("Sin reseñas todavía")).toBeInTheDocument();
    expect(screen.getByText("Este bien todavía no tiene reseñas.")).toBeInTheDocument();
  });

  it("ofrece consultar al arrendador, salvo al propio arrendador", () => {
    const { rerender } = render(<DetalleDelBien bien={BIEN} conSesion />);
    expect(screen.getByRole("link", { name: "Consultar al arrendador" })).toHaveAttribute(
      "href",
      `/publicaciones/${BIEN.id}/conversacion`,
    );
    rerender(<DetalleDelBien bien={BIEN} conSesion esDelUsuario />);
    expect(screen.queryByRole("link", { name: "Consultar al arrendador" })).not.toBeInTheDocument();
  });

  it("con sesión monta el panel «Tu selección» junto al calendario", () => {
    render(<DetalleDelBien bien={BIEN} conSesion />);
    expect(screen.getByRole("heading", { name: "Tu selección" })).toBeInTheDocument();
  });
});
