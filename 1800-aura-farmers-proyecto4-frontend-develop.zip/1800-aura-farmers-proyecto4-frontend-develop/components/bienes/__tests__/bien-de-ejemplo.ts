import type { BienDetalle } from "@/lib/bienes";

/** Bien publicado con todos los campos de `GET /bienes/:bienId`, para las pruebas. */
export const BIEN: BienDetalle = {
  id: "7c9e6679-7425-40de-944b-e07fc1f90ae7",
  tipo: "PROPIEDAD",
  categoria: "Salón de eventos",
  titulo: "Salón de eventos Las Palmas",
  descripcion: "Salón climatizado con cocina y parqueo.",
  precio: 80,
  unidadCobro: "DIA",
  deposito: 150,
  capacidad: 120,
  condiciones: "No se permite pirotecnia",
  departamento: "La Libertad",
  municipio: "Antiguo Cuscatlán",
  direccionReferencia: "Frente al parque central",
  arrendador: { id: "29bda5e8-e0c8-4c1f-9d55-1a2b3c4d5e6f", nombreUsuario: "ana_m" },
  fotos: [{ url: "/uploads/bienes/7c9e/1.webp", orden: 1, esPrincipal: true }],
  creadoEn: "2026-11-10T12:00:00.000Z",
};
