"use client";

import { useState } from "react";
import { Avatar, Boton, Calificacion } from "@/components/ui";
import {
  contarResenas,
  formatearPromedio,
  type CalificacionBien,
  type PaginaResenas,
  type ResenaDeBien,
} from "@/lib/bienes";

const FECHA = new Intl.DateTimeFormat("es-SV", {
  day: "2-digit",
  month: "2-digit",
  year: "numeric",
  timeZone: "America/El_Salvador",
});

type ResenasDelBienProps = {
  bienId: string;
  calificacion?: CalificacionBien;
  /** Primera página que pidió el servidor; `null` si no se pudo cargar. */
  inicial: PaginaResenas | null;
};

/**
 * Reseñas públicas del bien (BE-15.2): el promedio, las tarjetas de dos en dos
 * y «Ver más reseñas», que pide la página siguiente por el puente
 * `/api/bienes/:bienId/resenas`.
 */
export function ResenasDelBien({ bienId, calificacion, inicial }: ResenasDelBienProps) {
  const [resenas, setResenas] = useState<ResenaDeBien[]>(inicial?.items ?? []);
  const [pagina, setPagina] = useState(inicial?.pagina ?? 0);
  const [hayMas, setHayMas] = useState(inicial?.hayMas ?? false);
  const [cargando, setCargando] = useState(false);
  const [error, setError] = useState(inicial === null);

  async function verMas() {
    setCargando(true);
    setError(false);
    try {
      const respuesta = await fetch(`/api/bienes/${bienId}/resenas?pagina=${pagina + 1}`);
      if (!respuesta.ok) throw new Error(String(respuesta.status));
      const datos = (await respuesta.json()) as PaginaResenas;
      // Si entre dos páginas llega una reseña nueva, el desfase repetiría una.
      setResenas((previas) => {
        const vistas = new Set(previas.map((resena) => resena.id));
        return [...previas, ...datos.items.filter((resena) => !vistas.has(resena.id))];
      });
      setPagina(datos.pagina);
      setHayMas(datos.hayMas);
    } catch {
      setError(true);
    } finally {
      setCargando(false);
    }
  }

  const promedio = calificacion?.promedio ?? null;

  return (
    <section aria-labelledby="titulo-resenas" className="flex flex-col gap-espacio-4">
      <div className="flex flex-wrap items-center gap-x-espacio-4 gap-y-1">
        <h2 id="titulo-resenas" className="texto-h2 text-texto-primario">
          Reseñas
        </h2>
        {promedio !== null && calificacion && (
          <p className="texto-etiqueta text-texto-secundario">
            {formatearPromedio(promedio)} / 5 · {contarResenas(calificacion.totalResenas)}
          </p>
        )}
      </div>

      {resenas.length > 0 ? (
        <ul className="grid gap-espacio-4 md:grid-cols-2">
          {resenas.map((resena) => (
            <li
              key={resena.id}
              className="flex flex-col gap-2.5 border border-borde-default bg-fondo-superficie p-5"
            >
              <div className="flex items-center gap-espacio-3">
                <Avatar nombre={resena.autor.nombreUsuario} />
                <p className="flex flex-col">
                  <span className="texto-etiqueta break-all text-texto-primario">
                    {resena.autor.nombreUsuario}
                  </span>
                  <span className="texto-etiqueta-pequena text-texto-secundario">
                    {FECHA.format(new Date(resena.creadaEn))}
                  </span>
                </p>
              </div>
              <Calificacion valor={resena.puntuacion} etiqueta="Calificación de la reseña" />
              {resena.comentario && (
                <p className="texto-cuerpo break-words whitespace-pre-line text-texto-secundario">
                  {resena.comentario}
                </p>
              )}
            </li>
          ))}
        </ul>
      ) : (
        !error && <p className="texto-cuerpo text-texto-secundario">Este bien todavía no tiene reseñas.</p>
      )}

      {error && (
        <p role="alert" className="texto-cuerpo-pequeno text-texto-secundario">
          No pudimos cargar las reseñas.
        </p>
      )}

      {(hayMas || (error && resenas.length > 0) || inicial === null) && (
        <div>
          <Boton jerarquia="secundario" cargando={cargando} onClick={verMas}>
            {error ? "Reintentar" : "Ver más reseñas"}
          </Boton>
        </div>
      )}
    </section>
  );
}
