"use client";

import { useEffect, useRef, useState } from "react";
import { Boton } from "@/components/ui";
import { chipsDeFiltros, type CriteriosBusqueda } from "@/lib/busqueda";
import { PanelDeFiltros } from "./panel-de-filtros";

type FiltrosDeBusquedaProps = { criterios: CriteriosBusqueda };

/** Desde aquí se ve el panel lateral y la hoja ya no aplica (`lg` de Tailwind). */
const DESDE_LG = "(min-width: 64rem)";

/**
 * Filtros de /buscar según el ancho (FE-4.1): panel lateral desde `lg` y, en
 * pantallas menores, el botón «Filtros (n)» que abre el panel como hoja a
 * pantalla completa. `n` es la cantidad de chips activos.
 *
 * La hoja es un `<dialog>` abierto con `showModal()`, como
 * `DialogoDeConfirmacion`: el navegador atrapa el foco dentro y Escape la
 * cierra. Mientras está abierta, el fondo no se desplaza.
 */
export function FiltrosDeBusqueda({ criterios }: FiltrosDeBusquedaProps) {
  const [abierta, setAbierta] = useState(false);
  const hoja = useRef<HTMLDialogElement>(null);
  const boton = useRef<HTMLButtonElement>(null);
  const activos = chipsDeFiltros(criterios).length;

  useEffect(() => {
    const elemento = hoja.current;
    const disparador = boton.current;
    if (!abierta || !elemento) return;

    if (!elemento.open) elemento.showModal();
    const overflowPrevio = document.body.style.overflow;
    document.body.style.overflow = "hidden";

    // Si la pantalla crece hasta `lg`, la hoja se oculta: se cierra para que no
    // quede un modal invisible bloqueando la página.
    const consulta = typeof window.matchMedia === "function" ? window.matchMedia(DESDE_LG) : null;
    const alCambiarAncho = (evento: MediaQueryListEvent) => {
      if (evento.matches) setAbierta(false);
    };
    consulta?.addEventListener("change", alCambiarAncho);

    return () => {
      consulta?.removeEventListener("change", alCambiarAncho);
      document.body.style.overflow = overflowPrevio;
      if (elemento.open) elemento.close();
      disparador?.focus();
    };
  }, [abierta]);

  return (
    <>
      <aside aria-label="Filtros" className="hidden w-80 shrink-0 lg:block">
        <PanelDeFiltros criterios={criterios} />
      </aside>

      <Boton
        ref={boton}
        type="button"
        jerarquia="secundario"
        icono="filtros"
        aria-haspopup="dialog"
        aria-expanded={abierta}
        onClick={() => setAbierta(true)}
        className="w-full lg:hidden"
      >
        {activos > 0 ? `Filtros (${activos})` : "Filtros"}
      </Boton>

      {abierta && (
        <dialog
          ref={hoja}
          aria-label="Filtros"
          onCancel={(evento) => {
            // Escape cierra el diálogo nativo; el estado lo desmonta.
            evento.preventDefault();
            setAbierta(false);
          }}
          className="fixed inset-0 z-50 m-0 h-dvh max-h-none w-full max-w-none overflow-y-auto overscroll-contain border-0 bg-fondo-base px-espacio-4 py-5 text-texto-primario lg:hidden"
        >
          <PanelDeFiltros criterios={criterios} alCerrar={() => setAbierta(false)} />
        </dialog>
      )}
    </>
  );
}
