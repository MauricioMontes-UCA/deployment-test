"use client";

import { useRouter } from "next/navigation";
import { useId, useState, type FormEvent } from "react";
import { Alerta, Boton, CampoDeTexto, Icono, Radio, Selector } from "@/components/ui";
import {
  categoriasDe,
  sinFiltros,
  urlDeBusqueda,
  type CriteriosBusqueda,
  type FiltrosBusqueda,
} from "@/lib/busqueda";
import { TIPOS_BIEN, esTipoBien } from "@/lib/catalogos/bienes";
import { unirClases } from "@/lib/clases";
import { hoyEnElSalvador } from "@/lib/disponibilidad";
import { validarFiltros } from "@/lib/validaciones/filtros";

type PanelDeFiltrosProps = {
  criterios: CriteriosBusqueda;
  /**
   * En móvil el panel es una hoja: muestra la X para cerrarla y se cierra al
   * aplicar o limpiar.
   */
  alCerrar?: () => void;
  className?: string;
};

/**
 * «Todos» (sin filtro de tipo) va primero y marcado por defecto: con solo dos
 * radios sin marcar no se entendía que se buscaban los dos tipos, y una vez
 * elegido uno no había cómo volver atrás desde el panel.
 */
const OPCIONES_TIPO = [{ valor: "", etiqueta: "Todos" }, ...TIPOS_BIEN];

/** Texto de error bajo un grupo de campos (precio o fechas). */
function ErrorDeGrupo({ id, texto }: { id: string; texto?: string }) {
  if (!texto) return null;
  return (
    <p id={id} className="texto-cuerpo-pequeno text-texto-error">
      {texto}
    </p>
  );
}

/**
 * Panel de filtros de /buscar (FE-4.1): precio mínimo y máximo, tipo,
 * categoría (las del tipo elegido), capacidad mínima (solo para propiedades)
 * y fechas disponibles, sin fechas pasadas.
 *
 * «Aplicar» valida antes de enviar y escribe los filtros en la URL con
 * `router.replace`; la lista vuelve a la página 1 porque cambia su `key`.
 * «Limpiar filtros» quita solo los filtros y conserva el texto y la
 * ubicación. Arranca con los filtros de la URL.
 */
export function PanelDeFiltros({ criterios, alCerrar, className }: PanelDeFiltrosProps) {
  const router = useRouter();
  const idTitulo = useId();
  const idErrorPrecio = useId();
  const idErrorFechas = useId();

  const [filtros, setFiltros] = useState<FiltrosBusqueda>(() => ({
    precioMin: criterios.precioMin ?? "",
    precioMax: criterios.precioMax ?? "",
    tipo: criterios.tipo,
    categoria: criterios.categoria ?? "",
    capacidadMin: criterios.capacidadMin ?? "",
    fechaInicio: criterios.fechaInicio ?? "",
    fechaFin: criterios.fechaFin ?? "",
  }));
  // Los errores aparecen al intentar aplicar y se recalculan mientras se corrige.
  const [intentado, setIntentado] = useState(false);
  const hoy = hoyEnElSalvador();
  const errores = intentado ? validarFiltros(filtros, hoy) : {};
  const hayErrores = Object.keys(errores).length > 0;

  const cambiar = (campo: keyof FiltrosBusqueda) => (valor: string) =>
    setFiltros((previos) => ({ ...previos, [campo]: valor }));

  /** `valor` vacío es «Todos»: sin filtro de tipo. */
  function alCambiarTipo(valor: string) {
    const tipo = esTipoBien(valor) ? valor : undefined;
    setFiltros((previos) => ({
      ...previos,
      tipo,
      // La categoría tiene que ser del tipo nuevo (con «Todos» sirve
      // cualquiera) y la capacidad es solo de propiedades.
      categoria: categoriasDe(tipo).includes(previos.categoria ?? "") ? previos.categoria : "",
      capacidadMin: tipo === "PROPIEDAD" ? previos.capacidadMin : "",
    }));
  }

  function navegar(nuevos: CriteriosBusqueda) {
    router.replace(urlDeBusqueda(nuevos));
    alCerrar?.();
  }

  function alAplicar(evento: FormEvent<HTMLFormElement>) {
    evento.preventDefault();
    if (Object.keys(validarFiltros(filtros, hoy)).length > 0) {
      setIntentado(true);
      return;
    }
    navegar({ ...sinFiltros(criterios), ...filtros });
  }

  const opcionesCategoria = [
    { valor: "", etiqueta: "Todas" },
    ...categoriasDe(filtros.tipo).map((categoria) => ({ valor: categoria, etiqueta: categoria })),
  ];
  // Solo con Propiedad: con «Todos», el backend descartaría en silencio los
  // equipos (no tienen capacidad) aunque el usuario no eligió un tipo.
  const conCapacidad = filtros.tipo === "PROPIEDAD";

  return (
    <form
      aria-labelledby={idTitulo}
      onSubmit={alAplicar}
      noValidate
      className={unirClases(
        "flex flex-col gap-5 border border-borde-default bg-fondo-superficie p-espacio-5",
        className,
      )}
    >
      <div className="flex items-center justify-between gap-espacio-3">
        <h2 id={idTitulo} className="texto-h3 text-texto-primario">
          Filtros
        </h2>
        {alCerrar && (
          <button
            type="button"
            onClick={alCerrar}
            aria-label="Cerrar filtros"
            className="inline-flex cursor-pointer text-texto-primario"
          >
            <Icono nombre="cerrar" />
          </button>
        )}
      </div>

      {hayErrores && (
        <Alerta tono="error" titulo="Revisa los filtros marcados.">
          Corrige los campos marcados para aplicar los filtros.
        </Alerta>
      )}

      <fieldset className="flex flex-col gap-espacio-3">
        <legend className="texto-etiqueta mb-espacio-3 text-texto-primario">
          Precio por unidad
        </legend>
        <div className="grid grid-cols-2 gap-espacio-3">
          <CampoDeTexto
            etiqueta="Mínimo"
            type="number"
            inputMode="decimal"
            min={0}
            step="0.01"
            placeholder="$0"
            value={filtros.precioMin}
            onChange={(evento) => cambiar("precioMin")(evento.target.value)}
            invalido={Boolean(errores.precio)}
            aria-describedby={errores.precio ? idErrorPrecio : undefined}
          />
          <CampoDeTexto
            etiqueta="Máximo"
            type="number"
            inputMode="decimal"
            min={0}
            step="0.01"
            placeholder="Sin límite"
            value={filtros.precioMax}
            onChange={(evento) => cambiar("precioMax")(evento.target.value)}
            invalido={Boolean(errores.precio)}
            aria-describedby={errores.precio ? idErrorPrecio : undefined}
          />
        </div>
        <ErrorDeGrupo id={idErrorPrecio} texto={errores.precio} />
      </fieldset>

      <fieldset className="flex flex-col gap-2.5">
        <legend className="texto-etiqueta mb-2.5 text-texto-primario">Tipo de bien</legend>
        {OPCIONES_TIPO.map(({ valor, etiqueta }) => (
          <Radio
            key={valor || "todos"}
            name="tipo"
            value={valor}
            texto={etiqueta}
            checked={(filtros.tipo ?? "") === valor}
            onChange={(evento) => alCambiarTipo(evento.target.value)}
          />
        ))}
      </fieldset>

      <Selector
        etiqueta="Categoría"
        opciones={opcionesCategoria}
        valor={filtros.categoria || null}
        onCambiar={cambiar("categoria")}
        placeholder="Todas"
      />

      {conCapacidad && (
        <CampoDeTexto
          etiqueta="Capacidad mínima"
          type="number"
          inputMode="numeric"
          min={1}
          step={1}
          placeholder="Personas"
          ayuda="Solo para propiedades."
          error={errores.capacidad}
          value={filtros.capacidadMin}
          onChange={(evento) => cambiar("capacidadMin")(evento.target.value)}
        />
      )}

      <fieldset className="flex flex-col gap-espacio-3">
        <legend className="texto-etiqueta mb-espacio-3 text-texto-primario">
          Fechas disponibles
        </legend>
        <div className="grid grid-cols-2 gap-espacio-3">
          <CampoDeTexto
            etiqueta="Inicio"
            type="date"
            min={hoy}
            value={filtros.fechaInicio}
            onChange={(evento) => cambiar("fechaInicio")(evento.target.value)}
            invalido={Boolean(errores.fechas)}
            aria-describedby={errores.fechas ? idErrorFechas : undefined}
          />
          <CampoDeTexto
            etiqueta="Fin"
            type="date"
            min={filtros.fechaInicio || hoy}
            value={filtros.fechaFin}
            onChange={(evento) => cambiar("fechaFin")(evento.target.value)}
            invalido={Boolean(errores.fechas)}
            aria-describedby={errores.fechas ? idErrorFechas : undefined}
          />
        </div>
        {errores.fechas ? (
          <ErrorDeGrupo id={idErrorFechas} texto={errores.fechas} />
        ) : (
          <p className="texto-cuerpo-pequeno text-texto-secundario">No permite fechas pasadas.</p>
        )}
      </fieldset>

      <div className="flex flex-col gap-5">
        <Boton type="submit">Aplicar</Boton>
        <Boton
          type="button"
          jerarquia="secundario"
          onClick={() => navegar(sinFiltros(criterios))}
        >
          Limpiar filtros
        </Boton>
      </div>
    </form>
  );
}
