"use client";

import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";
import { Boton, CampoDeTexto, Selector } from "@/components/ui";
import { MAX_LARGO_TEXTO_BUSQUEDA, urlDeBusqueda, type CriteriosBusqueda } from "@/lib/busqueda";
import { unirClases } from "@/lib/clases";
import { DEPARTAMENTOS, municipiosDe } from "@/lib/ubicaciones";

const TODOS = { valor: "", etiqueta: "Todos" };
const OPCIONES_DEPARTAMENTO = [
  TODOS,
  ...DEPARTAMENTOS.map((departamento) => ({ valor: departamento, etiqueta: departamento })),
];

/** La portada enmarca la barra y pregunta; en /buscar va suelta, como en Figma. */
const POR_VARIANTE = {
  portada: {
    etiqueta: "¿Qué necesitas rentar?",
    clases: "border border-borde-default bg-fondo-superficie p-3 md:p-espacio-4",
    iconoBoton: "buscar",
  },
  // En /buscar el botón va sin ícono, como en Figma.
  resultados: { etiqueta: "Buscar", clases: "", iconoBoton: undefined },
} as const;

type BarraDeBusquedaProps = {
  /** Criterios con los que arranca la barra (en /buscar, los de la URL). */
  criterios?: CriteriosBusqueda;
  variante?: keyof typeof POR_VARIANTE;
};

/**
 * Barra de búsqueda: texto, departamento y municipio. «Buscar» lleva a
 * /buscar con los criterios en la URL. El municipio queda deshabilitado hasta
 * elegir un departamento y se vacía al cambiarlo. Los filtros que ya traía la
 * búsqueda (FE-4.1) se conservan, porque la barra no los muestra.
 *
 * Toma los criterios solo al montarse: en /buscar se le pone como `key` la URL
 * para que vuelva a tomarlos al navegar entre búsquedas.
 */
export function BarraDeBusqueda({ criterios = {}, variante = "portada" }: BarraDeBusquedaProps) {
  const router = useRouter();
  const [texto, setTexto] = useState(criterios.q ?? "");
  const [departamento, setDepartamento] = useState<string | null>(criterios.departamento ?? null);
  const [municipio, setMunicipio] = useState<string | null>(criterios.municipio ?? null);
  const { etiqueta, clases, iconoBoton } = POR_VARIANTE[variante];

  const opcionesMunicipio = departamento
    ? [TODOS, ...municipiosDe(departamento).map((nombre) => ({ valor: nombre, etiqueta: nombre }))]
    : [];

  function alCambiarDepartamento(valor: string) {
    setDepartamento(valor || null);
    setMunicipio(null);
  }

  function alBuscar(evento: FormEvent<HTMLFormElement>) {
    evento.preventDefault();
    router.push(
      urlDeBusqueda({
        ...criterios,
        q: texto,
        departamento: departamento ?? "",
        municipio: municipio ?? "",
      }),
    );
  }

  return (
    <form
      role="search"
      aria-label="Buscar bienes"
      onSubmit={alBuscar}
      className={unirClases("flex w-full flex-col gap-espacio-3 md:flex-row md:items-end", clases)}
    >
      <CampoDeTexto
        etiqueta={etiqueta}
        icono="buscar"
        type="search"
        placeholder="Salón, cámara, taladro…"
        maxLength={MAX_LARGO_TEXTO_BUSQUEDA}
        value={texto}
        onChange={(evento) => setTexto(evento.target.value)}
        className="md:flex-1"
      />
      {/* En móvil van uno sobre otro: lado a lado, «Elige un departamento» se corta a 360 px. */}
      <div className="flex flex-col gap-espacio-3 sm:flex-row">
        <Selector
          etiqueta="Departamento"
          opciones={OPCIONES_DEPARTAMENTO}
          valor={departamento}
          onCambiar={alCambiarDepartamento}
          placeholder="Todos"
          className="min-w-0 flex-1 md:w-60 md:flex-none"
        />
        <Selector
          etiqueta="Municipio"
          opciones={opcionesMunicipio}
          valor={municipio}
          onCambiar={(valor) => setMunicipio(valor || null)}
          placeholder={departamento ? "Todos" : "Elige un departamento"}
          deshabilitado={!departamento}
          className="min-w-0 flex-1 md:w-60 md:flex-none"
        />
      </div>
      <Boton type="submit" icono={iconoBoton} className="w-full md:w-auto">
        Buscar
      </Boton>
    </form>
  );
}
