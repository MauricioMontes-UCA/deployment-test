import { act, cleanup, render, screen, waitFor, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { ResultadosDeBusqueda } from "@/components/busqueda/resultados-de-busqueda";
import type { BienEncontrado } from "@/lib/bienes";

/** IntersectionObserver de jsdom no existe: este deja disparar el «final a la vista». */
class ObservadorFalso {
  static activos = new Set<ObservadorFalso>();
  constructor(private readonly alCambiar: IntersectionObserverCallback) {}
  observe() {
    ObservadorFalso.activos.add(this);
  }
  disconnect() {
    ObservadorFalso.activos.delete(this);
  }
  unobserve() {}
  takeRecords() {
    return [];
  }
  disparar() {
    this.alCambiar(
      [{ isIntersecting: true } as IntersectionObserverEntry],
      this as unknown as IntersectionObserver,
    );
  }
}

/**
 * Simula que el usuario baja hasta el final de la lista. Primero espera a que
 * el componente observe el final: el observador se crea en un efecto, después
 * de pintar la página.
 */
async function llegarAlFinal() {
  await waitFor(() => expect(ObservadorFalso.activos.size).toBeGreaterThan(0));
  act(() => {
    for (const observador of [...ObservadorFalso.activos]) observador.disparar();
  });
}

const bien = (numero: number): BienEncontrado => ({
  id: `00000000-0000-4000-8000-${String(numero).padStart(12, "0")}`,
  titulo: `Salón ${numero}`,
  precio: 80,
  unidadCobro: "DIA",
  departamento: "San Salvador",
  municipio: "Soyapango",
  fotoPrincipal: `/uploads/bienes/${numero}.jpg`,
});

const CATALOGO = Array.from({ length: 45 }, (_, indice) => bien(indice + 1));

/** Backend falso de `GET /bienes`: pagina el catálogo igual que BE-3.1. */
function respuestaDe(url: string, catalogo = CATALOGO) {
  const parametros = new URL(url, "http://localhost").searchParams;
  const pagina = Number(parametros.get("pagina"));
  const tamano = Number(parametros.get("tamano"));
  const resultados = catalogo.slice((pagina - 1) * tamano, pagina * tamano);
  return Response.json({
    pagina,
    tamanoPagina: tamano,
    total: catalogo.length,
    hayMas: pagina * tamano < catalogo.length,
    resultados,
  });
}

const fetchSimulado = vi.fn();
const tarjetas = () => screen.queryAllByRole("listitem");

beforeEach(() => {
  ObservadorFalso.activos.clear();
  vi.stubGlobal("IntersectionObserver", ObservadorFalso);
  fetchSimulado.mockReset();
  fetchSimulado.mockImplementation(async (url: string) => respuestaDe(url));
  vi.stubGlobal("fetch", fetchSimulado);
});

afterEach(() => {
  cleanup();
  vi.unstubAllGlobals();
});

describe("ResultadosDeBusqueda", () => {
  it("con 45 resultados carga 20, luego 40 y luego 45, y avisa el fin", async () => {
    render(<ResultadosDeBusqueda criterios={{ q: "salón" }} />);

    expect(await screen.findAllByRole("listitem")).toHaveLength(20);
    expect(screen.getByRole("heading", { name: "Resultados para «salón»" })).toBeInTheDocument();
    expect(screen.getByText("45 resultados")).toBeInTheDocument();

    await llegarAlFinal();
    expect(screen.getByText("Cargando más resultados…")).toBeInTheDocument();
    await waitFor(() => expect(tarjetas()).toHaveLength(40));

    await llegarAlFinal();
    await waitFor(() => expect(tarjetas()).toHaveLength(45));
    expect(screen.getByText("No hay más resultados.")).toBeInTheDocument();

    // Sin `hayMas` ya no se observa el final: no se piden más páginas.
    expect(ObservadorFalso.activos.size).toBe(0);
    expect(fetchSimulado).toHaveBeenCalledTimes(3);
    expect(fetchSimulado.mock.calls.map(([url]) => new URL(url, "http://x").searchParams.get("pagina")))
      .toEqual(["1", "2", "3"]);
  });

  it("no lanza otra petición si ya hay una en curso", async () => {
    render(<ResultadosDeBusqueda criterios={{}} />);
    await screen.findAllByRole("listitem");

    let responder: (respuesta: Response) => void = () => {};
    fetchSimulado.mockImplementationOnce(() => new Promise<Response>((resolver) => (responder = resolver)));

    // El final queda a la vista varias veces mientras la página 2 no llega.
    await waitFor(() => expect(ObservadorFalso.activos.size).toBe(1));
    const [observador] = ObservadorFalso.activos;
    act(() => {
      observador.disparar();
      observador.disparar();
      observador.disparar();
    });
    expect(fetchSimulado).toHaveBeenCalledTimes(2);

    await act(async () => responder(respuestaDe("/api/bienes?pagina=2&tamano=20")));
    expect(tarjetas()).toHaveLength(40);
  });

  it("cada tarjeta muestra precio y ubicación y abre el detalle del bien", async () => {
    render(<ResultadosDeBusqueda criterios={{}} />);
    const [primera] = await screen.findAllByRole("listitem");

    const enlace = within(primera).getByRole("link");
    expect(enlace).toHaveAttribute("href", `/bienes/${CATALOGO[0].id}`);
    expect(within(primera).getByText("Salón 1")).toBeInTheDocument();
    expect(within(primera).getByText("$80.00 / día")).toBeInTheDocument();
    expect(within(primera).getByText("Soyapango, San Salvador")).toBeInTheDocument();
    expect(within(primera).getByRole("img", { name: "Salón 1" })).toBeInTheDocument();
  });

  it("muestra tarjetas esqueleto mientras llega la primera página", async () => {
    fetchSimulado.mockImplementationOnce(() => new Promise<Response>(() => {}));
    render(<ResultadosDeBusqueda criterios={{}} />);

    expect(screen.getByRole("status", { name: "Cargando resultados" })).toBeInTheDocument();
    expect(tarjetas()).toHaveLength(0);
  });

  it("sin resultados muestra el estado vacío con el término buscado", async () => {
    fetchSimulado.mockImplementation(async (url: string) => respuestaDe(url, []));
    render(<ResultadosDeBusqueda criterios={{ q: "salón con piscina" }} />);

    expect(
      await screen.findByRole("heading", {
        name: "No encontramos bienes que coincidan con «salón con piscina».",
      }),
    ).toBeInTheDocument();
    expect(screen.queryByText(/resultados?$/)).not.toBeInTheDocument();
    expect(ObservadorFalso.activos.size).toBe(0);
  });

  it("si falla la primera página muestra el error y «Reintentar» vuelve a pedirla", async () => {
    fetchSimulado.mockResolvedValueOnce(Response.json({ message: "Error" }, { status: 500 }));
    render(<ResultadosDeBusqueda criterios={{ q: "salón" }} />);

    const alerta = await screen.findByRole("alert");
    expect(within(alerta).getByText("No pudimos cargar los resultados.")).toBeInTheDocument();

    await userEvent.click(within(alerta).getByRole("button", { name: "Reintentar" }));

    expect(await screen.findAllByRole("listitem")).toHaveLength(20);
    expect(screen.queryByRole("alert")).not.toBeInTheDocument();
  });

  it("si falla una página siguiente conserva lo cargado y deja reintentar", async () => {
    render(<ResultadosDeBusqueda criterios={{}} />);
    await screen.findAllByRole("listitem");

    fetchSimulado.mockRejectedValueOnce(new TypeError("Failed to fetch"));
    await llegarAlFinal();

    const alerta = await screen.findByRole("alert");
    expect(within(alerta).getByText("No pudimos cargar los resultados.")).toBeInTheDocument();
    expect(tarjetas()).toHaveLength(20);

    await userEvent.click(within(alerta).getByRole("button", { name: "Reintentar" }));
    await waitFor(() => expect(tarjetas()).toHaveLength(40));
    expect(new URL(fetchSimulado.mock.lastCall![0], "http://x").searchParams.get("pagina")).toBe("2");
  });

  describe("con filtros (FE-4.1)", () => {
    const conFiltros = { q: "salón", tipo: "PROPIEDAD", precioMin: "100", precioMax: "20" } as const;

    it("un 400 muestra «Revisa los filtros marcados.» con el mensaje del backend", async () => {
      fetchSimulado.mockResolvedValueOnce(
        Response.json(
          { message: ["El precio mínimo no puede ser mayor que el máximo."], statusCode: 400 },
          { status: 400 },
        ),
      );
      render(<ResultadosDeBusqueda criterios={conFiltros} />);

      const alerta = await screen.findByRole("alert");
      expect(within(alerta).getByText("Revisa los filtros marcados.")).toBeInTheDocument();
      expect(
        within(alerta).getByText("El precio mínimo no puede ser mayor que el máximo."),
      ).toBeInTheDocument();
      // Reintentar no cambiaría nada: ofrece quitar los filtros.
      expect(within(alerta).queryByRole("button", { name: "Reintentar" })).not.toBeInTheDocument();
      expect(within(alerta).getByRole("link", { name: "Limpiar filtros" })).toHaveAttribute(
        "href",
        "/buscar?q=sal%C3%B3n",
      );
    });

    it("un 500 o la red caída muestran «No pudimos aplicar los filtros.» con «Reintentar»", async () => {
      fetchSimulado.mockRejectedValueOnce(new TypeError("Failed to fetch"));
      render(<ResultadosDeBusqueda criterios={conFiltros} />);

      const alerta = await screen.findByRole("alert");
      expect(
        within(alerta).getByText("No pudimos aplicar los filtros. Intenta de nuevo."),
      ).toBeInTheDocument();
      await userEvent.click(within(alerta).getByRole("button", { name: "Reintentar" }));
      expect(await screen.findAllByRole("listitem")).toHaveLength(20);
    });

    it("sin resultados ofrece «Limpiar filtros»", async () => {
      fetchSimulado.mockImplementation(async (url: string) => respuestaDe(url, []));
      render(<ResultadosDeBusqueda criterios={{ q: "salón", tipo: "EQUIPO" }} />);

      expect(
        await screen.findByText("Prueba con otro término o quita algunos filtros."),
      ).toBeInTheDocument();
      expect(screen.getByRole("link", { name: "Limpiar filtros" })).toHaveAttribute(
        "href",
        "/buscar?q=sal%C3%B3n",
      );
    });

    it("muestra los chips de los filtros activos junto al total", async () => {
      render(
        <ResultadosDeBusqueda
          criterios={{ tipo: "PROPIEDAD" }}
          filtrosActivos={<p>Chip Propiedad</p>}
        />,
      );

      expect(await screen.findByText("45 resultados")).toBeInTheDocument();
      expect(screen.getByText("Chip Propiedad")).toBeInTheDocument();
    });
  });
});
