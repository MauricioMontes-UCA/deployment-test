import { fireEvent, render, screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { beforeAll, beforeEach, describe, expect, it, vi } from "vitest";
import { ChipsDeFiltros } from "@/components/busqueda/chips-de-filtros";
import { FiltrosDeBusqueda } from "@/components/busqueda/filtros-de-busqueda";
import { PanelDeFiltros } from "@/components/busqueda/panel-de-filtros";

const { replace } = vi.hoisted(() => ({ replace: vi.fn() }));
vi.mock("next/navigation", () => ({ useRouter: () => ({ replace }) }));
// «Hoy» fijo para las fechas mínimas y la validación de fechas pasadas.
vi.mock("@/lib/disponibilidad", () => ({ hoyEnElSalvador: () => "2026-11-19" }));

const BUSQUEDA = { q: "salón", departamento: "San Salvador" };

const campo = (nombre: string) => screen.getByLabelText(nombre);
const aplicar = () => userEvent.click(screen.getByRole("button", { name: "Aplicar" }));

async function elegirCategoria(opcion: string) {
  await userEvent.click(screen.getByRole("combobox", { name: "Categoría" }));
  await userEvent.click(screen.getByRole("option", { name: opcion }));
}

beforeEach(() => replace.mockReset());

describe("PanelDeFiltros", () => {
  it("«Aplicar» escribe los filtros en la URL y conserva el texto y la ubicación", async () => {
    render(<PanelDeFiltros criterios={BUSQUEDA} />);

    await userEvent.type(campo("Mínimo"), "20");
    await userEvent.type(campo("Máximo"), "100");
    await userEvent.click(screen.getByRole("radio", { name: "Propiedad" }));
    await elegirCategoria("Salón de eventos");
    await userEvent.type(campo("Capacidad mínima"), "80");
    fireEvent.change(campo("Inicio"), { target: { value: "2026-11-20" } });
    fireEvent.change(campo("Fin"), { target: { value: "2026-11-22" } });
    await aplicar();

    expect(replace).toHaveBeenCalledWith(
      "/buscar?q=sal%C3%B3n&departamento=San+Salvador&precioMin=20&precioMax=100&tipo=PROPIEDAD" +
        "&categoria=Sal%C3%B3n+de+eventos&capacidadMin=80&fechaInicio=2026-11-20&fechaFin=2026-11-22",
    );
  });

  it("arranca con los filtros de la URL", () => {
    render(
      <PanelDeFiltros
        criterios={{ ...BUSQUEDA, precioMin: "20", tipo: "EQUIPO", categoria: "Herramientas" }}
      />,
    );

    expect(campo("Mínimo")).toHaveValue(20);
    expect(screen.getByRole("radio", { name: "Equipo" })).toBeChecked();
    expect(screen.getByRole("combobox", { name: "Categoría" })).toHaveTextContent("Herramientas");
  });

  it("«Limpiar filtros» quita solo los filtros", async () => {
    const alCerrar = vi.fn();
    render(
      <PanelDeFiltros
        criterios={{ ...BUSQUEDA, municipio: "Soyapango", tipo: "PROPIEDAD", precioMax: "50" }}
        alCerrar={alCerrar}
      />,
    );

    await userEvent.click(screen.getByRole("button", { name: "Limpiar filtros" }));

    expect(replace).toHaveBeenCalledWith(
      "/buscar?q=sal%C3%B3n&departamento=San+Salvador&municipio=Soyapango",
    );
    expect(alCerrar).toHaveBeenCalled();
  });

  it("no aplica un rango de precio inválido y marca el error bajo el campo", async () => {
    render(<PanelDeFiltros criterios={BUSQUEDA} />);

    await userEvent.type(campo("Mínimo"), "120");
    await userEvent.type(campo("Máximo"), "100");
    await aplicar();

    expect(replace).not.toHaveBeenCalled();
    expect(screen.getByRole("alert")).toHaveTextContent("Revisa los filtros marcados.");
    expect(screen.getByText("El precio mínimo no puede ser mayor que el máximo.")).toBeInTheDocument();
    expect(campo("Mínimo")).toHaveAccessibleDescription(
      expect.stringContaining("El precio mínimo no puede ser mayor que el máximo."),
    );

    // Al corregirlo, el error desaparece y ya se puede aplicar.
    await userEvent.clear(campo("Máximo"));
    await userEvent.type(campo("Máximo"), "150");
    expect(screen.queryByRole("alert")).not.toBeInTheDocument();
    await aplicar();
    expect(replace).toHaveBeenCalledWith(
      "/buscar?q=sal%C3%B3n&departamento=San+Salvador&precioMin=120&precioMax=150",
    );
  });

  it("no aplica un rango de fechas inválido", async () => {
    render(<PanelDeFiltros criterios={BUSQUEDA} />);

    fireEvent.change(campo("Inicio"), { target: { value: "2026-11-22" } });
    fireEvent.change(campo("Fin"), { target: { value: "2026-11-20" } });
    await aplicar();

    expect(replace).not.toHaveBeenCalled();
    expect(
      screen.getByText("La fecha de fin no puede ser anterior a la de inicio."),
    ).toBeInTheDocument();
  });

  it("no permite fechas pasadas", async () => {
    render(<PanelDeFiltros criterios={BUSQUEDA} />);
    expect(campo("Inicio")).toHaveAttribute("min", "2026-11-19");

    fireEvent.change(campo("Inicio"), { target: { value: "2026-11-01" } });
    fireEvent.change(campo("Fin"), { target: { value: "2026-11-02" } });
    await aplicar();

    expect(replace).not.toHaveBeenCalled();
    expect(screen.getByText("La fecha de inicio no puede ser anterior a hoy.")).toBeInTheDocument();
  });

  it("el tipo arranca en «Todos» y entonces no se filtra por tipo", async () => {
    render(<PanelDeFiltros criterios={BUSQUEDA} />);

    expect(screen.getByRole("radio", { name: "Todos" })).toBeChecked();
    expect(screen.queryByLabelText("Capacidad mínima")).not.toBeInTheDocument();
    await userEvent.click(screen.getByRole("combobox", { name: "Categoría" }));
    // Con «Todos» se ofrecen las categorías de los dos tipos.
    expect(screen.getByRole("option", { name: "Casa" })).toBeInTheDocument();
    expect(screen.getByRole("option", { name: "Herramientas" })).toBeInTheDocument();
  });

  it("volver a «Todos» quita el tipo y la capacidad, y conserva la categoría", async () => {
    render(
      <PanelDeFiltros
        criterios={{
          ...BUSQUEDA,
          tipo: "PROPIEDAD",
          categoria: "Salón de eventos",
          capacidadMin: "80",
        }}
      />,
    );
    expect(campo("Capacidad mínima")).toHaveValue(80);

    await userEvent.click(screen.getByRole("radio", { name: "Todos" }));
    expect(screen.queryByLabelText("Capacidad mínima")).not.toBeInTheDocument();
    await aplicar();

    expect(replace).toHaveBeenCalledWith(
      "/buscar?q=sal%C3%B3n&departamento=San+Salvador&categoria=Sal%C3%B3n+de+eventos",
    );
  });

  it("la categoría depende del tipo y la capacidad es solo para propiedades", async () => {
    render(<PanelDeFiltros criterios={BUSQUEDA} />);

    await userEvent.click(screen.getByRole("radio", { name: "Propiedad" }));
    await elegirCategoria("Salón de eventos");
    await userEvent.type(campo("Capacidad mínima"), "80");

    await userEvent.click(screen.getByRole("radio", { name: "Equipo" }));
    // La categoría de propiedad ya no aplica y la capacidad desaparece.
    expect(screen.getByRole("combobox", { name: "Categoría" })).toHaveTextContent("Todas");
    expect(screen.queryByLabelText("Capacidad mínima")).not.toBeInTheDocument();

    await userEvent.click(screen.getByRole("combobox", { name: "Categoría" }));
    expect(screen.getByRole("option", { name: "Herramientas" })).toBeInTheDocument();
    expect(screen.queryByRole("option", { name: "Casa" })).not.toBeInTheDocument();
  });
});

describe("ChipsDeFiltros", () => {
  const criterios = {
    ...BUSQUEDA,
    tipo: "PROPIEDAD",
    precioMin: "20",
    precioMax: "100",
    fechaInicio: "2026-11-20",
    fechaFin: "2026-11-22",
  } as const;

  it("muestra un chip por filtro activo", () => {
    render(<ChipsDeFiltros criterios={criterios} />);
    const chips = within(screen.getByRole("list", { name: "Filtros activos" }));
    expect(chips.getAllByRole("listitem").map((chip) => chip.textContent)).toEqual([
      "Propiedad",
      "$20 a $100",
      "20/11 a 22/11",
    ]);
  });

  it("la X de un chip quita ese filtro de la URL", async () => {
    render(<ChipsDeFiltros criterios={criterios} />);

    await userEvent.click(screen.getByRole("button", { name: "Quitar filtro $20 a $100" }));

    expect(replace).toHaveBeenCalledWith(
      "/buscar?q=sal%C3%B3n&departamento=San+Salvador&tipo=PROPIEDAD" +
        "&fechaInicio=2026-11-20&fechaFin=2026-11-22",
    );
  });

  it("quitar «Propiedad» también quita la capacidad mínima", async () => {
    render(<ChipsDeFiltros criterios={{ ...BUSQUEDA, tipo: "PROPIEDAD", capacidadMin: "80" }} />);

    await userEvent.click(screen.getByRole("button", { name: "Quitar filtro Propiedad" }));

    expect(replace).toHaveBeenCalledWith("/buscar?q=sal%C3%B3n&departamento=San+Salvador");
  });

  it("sin filtros no muestra nada", () => {
    const { container } = render(<ChipsDeFiltros criterios={BUSQUEDA} />);
    expect(container).toBeEmptyDOMElement();
  });
});

describe("FiltrosDeBusqueda en móvil", () => {
  beforeAll(() => {
    // jsdom no implementa showModal/close de <dialog>; se simula lo mínimo.
    HTMLDialogElement.prototype.showModal ??= function (this: HTMLDialogElement) {
      this.setAttribute("open", "");
    };
    HTMLDialogElement.prototype.close ??= function (this: HTMLDialogElement) {
      this.removeAttribute("open");
    };
  });

  it("«Filtros (n)» abre la hoja y la X o Escape la cierran", async () => {
    render(<FiltrosDeBusqueda criterios={{ ...BUSQUEDA, tipo: "EQUIPO", precioMax: "50" }} />);

    await userEvent.click(screen.getByRole("button", { name: "Filtros (2)" }));
    const hoja = screen.getByRole("dialog", { name: "Filtros" });
    await userEvent.click(within(hoja).getByRole("button", { name: "Cerrar filtros" }));
    expect(screen.queryByRole("dialog")).not.toBeInTheDocument();

    await userEvent.click(screen.getByRole("button", { name: "Filtros (2)" }));
    // Escape en un <dialog> modal dispara «cancel».
    fireEvent(screen.getByRole("dialog"), new Event("cancel", { cancelable: true }));
    expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
  });

  it("la hoja se abre como modal, bloquea el scroll del fondo y al cerrar devuelve el foco", async () => {
    render(<FiltrosDeBusqueda criterios={BUSQUEDA} />);
    const boton = screen.getByRole("button", { name: "Filtros" });

    await userEvent.click(boton);
    expect(screen.getByRole("dialog", { name: "Filtros" })).toHaveAttribute("open");
    expect(document.body.style.overflow).toBe("hidden");

    await userEvent.click(screen.getByRole("button", { name: "Cerrar filtros" }));
    expect(document.body.style.overflow).toBe("");
    expect(boton).toHaveFocus();
  });

  it("aplicar desde la hoja la cierra", async () => {
    render(<FiltrosDeBusqueda criterios={BUSQUEDA} />);

    await userEvent.click(screen.getByRole("button", { name: "Filtros" }));
    const hoja = within(screen.getByRole("dialog", { name: "Filtros" }));
    await userEvent.click(hoja.getByRole("radio", { name: "Equipo" }));
    await userEvent.click(hoja.getByRole("button", { name: "Aplicar" }));

    expect(replace).toHaveBeenCalledWith(
      "/buscar?q=sal%C3%B3n&departamento=San+Salvador&tipo=EQUIPO",
    );
    expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
  });
});
