import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { BarraDeBusqueda } from "@/components/busqueda/barra-de-busqueda";

const { push } = vi.hoisted(() => ({ push: vi.fn() }));
vi.mock("next/navigation", () => ({ useRouter: () => ({ push }) }));

const combo = (nombre: string) => screen.getByRole("combobox", { name: nombre });

async function elegir(selector: string, opcion: string) {
  await userEvent.click(combo(selector));
  await userEvent.click(screen.getByRole("option", { name: opcion }));
}

beforeEach(() => push.mockReset());

describe("BarraDeBusqueda", () => {
  it("el municipio queda deshabilitado hasta elegir departamento", async () => {
    render(<BarraDeBusqueda />);
    expect(combo("Municipio")).toBeDisabled();
    expect(combo("Municipio")).toHaveTextContent("Elige un departamento");

    await elegir("Departamento", "La Libertad");
    expect(combo("Municipio")).toBeEnabled();

    await userEvent.click(combo("Municipio"));
    expect(screen.getByRole("option", { name: "Santa Tecla" })).toBeInTheDocument();
    expect(screen.queryByRole("option", { name: "Soyapango" })).not.toBeInTheDocument();
  });

  it("busca con los criterios en la URL de /buscar", async () => {
    render(<BarraDeBusqueda />);
    await userEvent.type(screen.getByRole("searchbox", { name: "¿Qué necesitas rentar?" }), "salón");
    await elegir("Departamento", "La Libertad");
    await elegir("Municipio", "Santa Tecla");
    await userEvent.click(screen.getByRole("button", { name: "Buscar" }));

    expect(push).toHaveBeenCalledWith(
      "/buscar?q=sal%C3%B3n&departamento=La+Libertad&municipio=Santa+Tecla",
    );
  });

  it("Enter en el texto también busca", async () => {
    render(<BarraDeBusqueda />);
    await userEvent.type(screen.getByRole("searchbox"), "taladro{Enter}");
    expect(push).toHaveBeenCalledWith("/buscar?q=taladro");
  });

  it("al cambiar de departamento se vacía el municipio", async () => {
    render(<BarraDeBusqueda />);
    await elegir("Departamento", "La Libertad");
    await elegir("Municipio", "Santa Tecla");
    await elegir("Departamento", "San Salvador");
    expect(combo("Municipio")).toHaveTextContent("Todos");

    await userEvent.click(screen.getByRole("button", { name: "Buscar" }));
    expect(push).toHaveBeenCalledWith("/buscar?departamento=San+Salvador");
  });

  it("volver a «Todos» quita el departamento y deshabilita el municipio", async () => {
    render(<BarraDeBusqueda />);
    await elegir("Departamento", "La Libertad");
    await elegir("Departamento", "Todos");
    expect(combo("Municipio")).toBeDisabled();

    await userEvent.click(screen.getByRole("button", { name: "Buscar" }));
    expect(push).toHaveBeenCalledWith("/buscar");
  });

  describe("en /buscar", () => {
    const criterios = { q: "salón", departamento: "La Libertad", municipio: "Santa Tecla" };

    it("arranca con los criterios de la URL", () => {
      render(<BarraDeBusqueda variante="resultados" criterios={criterios} />);

      expect(screen.getByRole("searchbox", { name: "Buscar" })).toHaveValue("salón");
      expect(combo("Departamento")).toHaveTextContent("La Libertad");
      expect(combo("Municipio")).toHaveTextContent("Santa Tecla");
    });

    it("al buscar de nuevo conserva la categoría que traía la URL", async () => {
      render(
        <BarraDeBusqueda variante="resultados" criterios={{ ...criterios, categoria: "Casa" }} />,
      );
      const texto = screen.getByRole("searchbox", { name: "Buscar" });
      await userEvent.clear(texto);
      await userEvent.type(texto, "casa de playa{Enter}");

      expect(push).toHaveBeenCalledWith(
        "/buscar?q=casa+de+playa&departamento=La+Libertad&municipio=Santa+Tecla&categoria=Casa",
      );
    });

    it("no deja escribir más de 100 caracteres, el máximo del backend", () => {
      render(<BarraDeBusqueda variante="resultados" />);
      expect(screen.getByRole("searchbox")).toHaveAttribute("maxLength", "100");
    });
  });
});
