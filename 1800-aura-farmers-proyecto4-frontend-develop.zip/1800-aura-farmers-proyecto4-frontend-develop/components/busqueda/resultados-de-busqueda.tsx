"use client";

import Link from "next/link";
import { useCallback, useEffect, useRef, useState, type ReactNode } from "react";
import {
  Boton,
  EstadoDePagina,
  Icono,
  TarjetaDeBien,
  TarjetaDeBienEsqueleto,
  clasesBoton,
} from "@/components/ui";
import { formatearPrecio, type BienEncontrado } from "@/lib/bienes";
import {
  ErrorDeBusqueda,
  buscarBienes,
  hayFiltros,
  sinFiltros,
  urlDeBusqueda,
  type CriteriosBusqueda,
} from "@/lib/busqueda";

/** Tres columnas en escritorio, junto al panel de filtros, como en Figma. */
const CLASES_GRILLA =
  "grid grid-cols-1 gap-x-espacio-5 gap-y-espacio-6 sm:grid-cols-2 xl:grid-cols-3";

/** Esqueletos mientras llega la primera página: dos filas de escritorio. */
const ESQUELETOS = 6;

/**
 * Margen con el que el observador «ve» el final antes de que entre en
 * pantalla, para que la página siguiente llegue sin que el usuario espere.
 */
const ANTICIPO = "0px 0px 400px 0px";

const MENSAJE_ERROR = "No pudimos cargar los resultados.";

type Estado = {
  resultados: BienEncontrado[];
  /** Última página recibida; 0 antes de la primera. */
  pagina: number;
  total: number;
  hayMas: boolean;
  fase: "cargando" | "listo" | "error";
  /** Código del último error (0 si no hubo respuesta) y mensajes del backend. */
  error?: { status: number; mensajes: string[] };
};

const INICIAL: Estado = { resultados: [], pagina: 0, total: 0, hayMas: true, fase: "cargando" };

const unResultado = (total: number) => (total === 1 ? "1 resultado" : `${total} resultados`);

/**
 * Error de la primera página. Con filtros, un 400 es un filtro que el backend
 * rechazó (no sirve reintentar) y lo demás, que no se pudieron aplicar
 * (FE-4.1). Sin filtros, el error general de FE-3.1.
 */
function estadoDeError(criterios: CriteriosBusqueda, error: Estado["error"]) {
  if (!hayFiltros(criterios)) {
    return { titulo: MENSAJE_ERROR, mensaje: "Revisa tu conexión e intenta de nuevo.", reintentar: true };
  }
  if (error?.status === 400) {
    return {
      titulo: "Revisa los filtros marcados.",
      mensaje: error.mensajes.join(" ") || "Alguno de los filtros no es válido.",
      reintentar: false,
    };
  }
  return {
    titulo: "No pudimos aplicar los filtros. Intenta de nuevo.",
    mensaje: "Revisa tu conexión e intenta de nuevo.",
    reintentar: true,
  };
}

type ResultadosDeBusquedaProps = {
  criterios: CriteriosBusqueda;
  /** Chips de los filtros activos: van bajo el título (en móvil, sobre él). */
  filtrosActivos?: ReactNode;
};

/**
 * Resultados de /buscar (FE-3.1) con carga continua: pide la primera página al
 * montarse y la siguiente cuando el final de la lista se acerca a la
 * pantalla, mientras `hayMas` sea verdadero. Nunca hay dos peticiones a la
 * vez. Muestra esqueletos, vacío, error con «Reintentar» y el fin de la lista.
 *
 * Arranca desde cero al cambiar los criterios: la página le pone la URL de la
 * búsqueda como `key`.
 */
export function ResultadosDeBusqueda({ criterios, filtrosActivos }: ResultadosDeBusquedaProps) {
  const [estado, setEstado] = useState<Estado>(INICIAL);
  const enCurso = useRef<AbortController | null>(null);
  const final = useRef<HTMLDivElement>(null);

  /** Pide `pagina` y la agrega. No hace nada si ya hay una petición en curso. */
  const cargar = useCallback(
    (pagina: number) => {
      if (enCurso.current) return;
      const control = new AbortController();
      enCurso.current = control;
      // La petición se libera antes de actualizar el estado: el observador que
      // se crea con la página nueva puede avisar enseguida y debe poder pedir
      // la siguiente. Una respuesta de una petición cancelada se ignora.
      const terminar = () => {
        if (enCurso.current !== control) return false;
        enCurso.current = null;
        return true;
      };
      buscarBienes(criterios, pagina, control.signal).then(
        (datos) => {
          if (!terminar()) return;
          setEstado((previo) => {
            // Si entre dos páginas se publica un bien, el desfase repetiría
            // uno: se descarta para no tener dos tarjetas (y dos `key`) iguales.
            const vistos = new Set(previo.resultados.map((bien) => bien.id));
            return {
              resultados: [
                ...previo.resultados,
                ...datos.resultados.filter((bien) => !vistos.has(bien.id)),
              ],
              pagina: datos.pagina,
              total: datos.total,
              hayMas: datos.hayMas,
              fase: "listo",
            };
          });
        },
        (motivo: unknown) => {
          if (!terminar()) return;
          const error =
            motivo instanceof ErrorDeBusqueda
              ? { status: motivo.status, mensajes: motivo.mensajes }
              : { status: 0, mensajes: [] };
          setEstado((previo) => ({ ...previo, fase: "error", error }));
        },
      );
    },
    [criterios],
  );

  /**
   * La página siguiente, desde el observador o desde «Reintentar». Si falló
   * la primera, `pagina` sigue en 0 y vuelve a pedir la 1.
   */
  const cargarSiguiente = useCallback(() => {
    if (enCurso.current) return;
    setEstado((previo) => ({ ...previo, fase: "cargando" }));
    cargar(estado.pagina + 1);
  }, [cargar, estado.pagina]);

  useEffect(() => {
    cargar(1);
    return () => {
      enCurso.current?.abort();
      enCurso.current = null;
    };
  }, [cargar]);

  // Se crea un observador nuevo tras cada página: al observar, avisa enseguida
  // si el final sigue a la vista (pantallas altas) y se pide la próxima sin
  // esperar a que el usuario se mueva.
  const { fase, hayMas, pagina } = estado;
  useEffect(() => {
    const nodo = final.current;
    if (!nodo || fase !== "listo" || !hayMas || pagina === 0) return;
    const observador = new IntersectionObserver(
      (entradas) => {
        if (entradas.some((entrada) => entrada.isIntersecting)) cargarSiguiente();
      },
      { rootMargin: ANTICIPO },
    );
    observador.observe(nodo);
    return () => observador.disconnect();
  }, [fase, hayMas, pagina, cargarSiguiente]);

  const { resultados, total } = estado;
  const titulo = criterios.q ? `Resultados para «${criterios.q}»` : "Bienes disponibles";
  const conFiltros = hayFiltros(criterios);
  // Quita los filtros y conserva el texto y la ubicación, igual que el panel.
  const enlaceLimpiar = conFiltros && (
    <Link replace href={urlDeBusqueda(sinFiltros(criterios))} className={clasesBoton({})}>
      Limpiar filtros
    </Link>
  );

  let contenido;
  if (resultados.length === 0 && fase === "cargando") {
    contenido = (
      <div role="status" aria-label="Cargando resultados" className={CLASES_GRILLA}>
        {Array.from({ length: ESQUELETOS }, (_, indice) => (
          <TarjetaDeBienEsqueleto key={indice} />
        ))}
      </div>
    );
  } else if (resultados.length === 0 && fase === "error") {
    const { titulo, mensaje, reintentar } = estadoDeError(criterios, estado.error);
    contenido = (
      <EstadoDePagina
        tipo="error"
        titulo={titulo}
        mensaje={mensaje}
        accion={
          reintentar ? (
            <Boton jerarquia="secundario" onClick={cargarSiguiente}>
              Reintentar
            </Boton>
          ) : (
            enlaceLimpiar
          )
        }
      />
    );
  } else if (resultados.length === 0) {
    contenido = (
      <EstadoDePagina
        tipo="vacio"
        titulo={
          criterios.q
            ? `No encontramos bienes que coincidan con «${criterios.q}».`
            : "No encontramos bienes con esos criterios."
        }
        mensaje={
          conFiltros
            ? "Prueba con otro término o quita algunos filtros."
            : "Prueba con otro término o cambia la ubicación."
        }
        accion={enlaceLimpiar}
      />
    );
  } else {
    contenido = (
      <>
        <ul className={CLASES_GRILLA}>
          {resultados.map((bien) => (
            <li key={bien.id}>
              <TarjetaDeBien
                titulo={bien.titulo}
                precio={formatearPrecio(bien.precio, bien.unidadCobro)}
                ubicacion={`${bien.municipio}, ${bien.departamento}`}
                foto={bien.fotoPrincipal}
                href={`/bienes/${bien.id}`}
              />
            </li>
          ))}
        </ul>
        <FinDeLaLista fase={fase} hayMas={hayMas} alReintentar={cargarSiguiente} />
      </>
    );
  }

  return (
    <section aria-labelledby="titulo-resultados" className="flex flex-col gap-5">
      <div className="flex flex-col gap-1 md:flex-row md:items-baseline md:gap-espacio-3">
        <h1 id="titulo-resultados" className="texto-h3 text-texto-primario md:texto-h2">
          {titulo}
        </h1>
        {resultados.length > 0 && (
          <p className="texto-cuerpo-pequeno text-texto-secundario">{unResultado(total)}</p>
        )}
      </div>
      {filtrosActivos && <div className="max-lg:order-first">{filtrosActivos}</div>}
      {contenido}
      {/* El observador vigila este punto: está justo después de la última tarjeta. */}
      <div ref={final} aria-hidden />
    </section>
  );
}

type FinDeLaListaProps = {
  fase: Estado["fase"];
  hayMas: boolean;
  alReintentar: () => void;
};

/** Pie de la lista: cargando más, error al pedir la siguiente o el fin. */
function FinDeLaLista({ fase, hayMas, alReintentar }: FinDeLaListaProps) {
  if (fase === "error") {
    return (
      <div
        role="alert"
        className="flex flex-col items-center gap-espacio-3 text-center sm:flex-row sm:justify-center"
      >
        <p className="texto-cuerpo-pequeno text-texto-secundario">{MENSAJE_ERROR}</p>
        <Boton jerarquia="secundario" onClick={alReintentar}>
          Reintentar
        </Boton>
      </div>
    );
  }
  if (fase === "cargando") {
    return (
      <p
        role="status"
        className="texto-cuerpo-pequeno flex items-center justify-center gap-espacio-2 text-texto-secundario"
      >
        <Icono nombre="cargando" tamano={20} className="animate-spin" />
        Cargando más resultados…
      </p>
    );
  }
  if (!hayMas) {
    return (
      <p className="texto-cuerpo-pequeno text-center text-texto-secundario">
        No hay más resultados.
      </p>
    );
  }
  return null;
}
