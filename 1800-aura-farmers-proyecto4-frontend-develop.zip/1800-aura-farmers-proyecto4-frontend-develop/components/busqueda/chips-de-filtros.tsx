"use client";

import { useRouter } from "next/navigation";
import { ChipDeFiltro } from "@/components/ui";
import { chipsDeFiltros, urlDeBusqueda, type CriteriosBusqueda } from "@/lib/busqueda";
import { unirClases } from "@/lib/clases";

type ChipsDeFiltrosProps = {
  criterios: CriteriosBusqueda;
  className?: string;
};

/**
 * Filtros activos de /buscar (FE-4.1). La X de cada chip quita ese filtro de
 * la URL con `router.replace`, y la lista vuelve a la página 1. Sin filtros no
 * muestra nada.
 */
export function ChipsDeFiltros({ criterios, className }: ChipsDeFiltrosProps) {
  const router = useRouter();
  const chips = chipsDeFiltros(criterios);
  if (chips.length === 0) return null;

  function quitar(campos: (keyof CriteriosBusqueda)[]) {
    const nuevos = { ...criterios };
    for (const campo of campos) delete nuevos[campo];
    router.replace(urlDeBusqueda(nuevos));
  }

  return (
    <ul aria-label="Filtros activos" className={unirClases("flex flex-wrap gap-2", className)}>
      {chips.map((chip) => (
        <li key={chip.campos.join()}>
          <ChipDeFiltro texto={chip.texto} onQuitar={() => quitar(chip.campos)} />
        </li>
      ))}
    </ul>
  );
}
