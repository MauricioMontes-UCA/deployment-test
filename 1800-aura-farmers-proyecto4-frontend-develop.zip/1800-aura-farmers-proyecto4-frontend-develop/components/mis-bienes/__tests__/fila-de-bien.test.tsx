import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { beforeEach, describe, expect, it, vi } from "vitest";
import type { MiBien } from "@/lib/mis-bienes";
import { FilaDeBien } from "../fila-de-bien";

const { actualizarPolitica } = vi.hoisted(() => ({ actualizarPolitica: vi.fn() }));
vi.mock("@/app/actions/auth", () => ({ cerrarSesion: vi.fn() }));
vi.mock("@/lib/politica-verificacion", async (importar) => ({
  ...(await importar<typeof import("@/lib/politica-verificacion")>()),
  actualizarPolitica,
}));

function bien(cambios: Partial<MiBien> = {}): MiBien {
  return {
    id: "b1",
    titulo: "Salón de eventos",
    tipo: "SALON",
    categoria: "Eventos",
    estado: "ACTIVA",
    precio: 150,
    unidadCobro: "DIA",
    deposito: 50,
    departamento: "La Libertad",
    municipio: "Santa Tecla",
    fotoPrincipalUrl: null,
    soloVerificados: false,
    creadoEn: "2026-11-01T00:00:00.000Z",
    ...cambios,
  };
}

const NOMBRE = "Solo usuarios verificados";

beforeEach(() => actualizarPolitica.mockReset());

describe("FilaDeBien", () => {
  it("muestra estado, título, ubicación y enlaces", () => {
    render(<FilaDeBien bien={bien()} arrendadorVerificado />);
    expect(screen.getByText("Activa")).toBeInTheDocument();
    expect(screen.getByRole("heading", { name: "Salón de eventos" })).toBeInTheDocument();
    expect(screen.getByText("Santa Tecla, La Libertad")).toBeInTheDocument();
    expect(screen.getByRole("link", { name: /Bloquear fechas/ })).toHaveAttribute(
      "href",
      "/mis-bienes/b1/bloqueos",
    );
    expect(screen.getByRole("link", { name: "Ver publicación" })).toHaveAttribute("href", "/bienes/b1");
  });

  it("marca Inactiva en las publicaciones inactivas", () => {
    render(<FilaDeBien bien={bien({ estado: "INACTIVA" })} arrendadorVerificado />);
    expect(screen.getByText("Inactiva")).toBeInTheDocument();
  });

  it("activa la política y la deja guardada", async () => {
    actualizarPolitica.mockResolvedValue({ ok: true, politica: { soloVerificados: true } });
    render(<FilaDeBien bien={bien()} arrendadorVerificado />);
    const interruptor = screen.getByRole("switch", { name: NOMBRE });

    await userEvent.click(interruptor);

    expect(actualizarPolitica).toHaveBeenCalledWith("b1", true);
    await waitFor(() => expect(interruptor).toBeChecked());
    expect(interruptor).toBeEnabled();
  });

  it("si falla vuelve al valor anterior y muestra el error", async () => {
    actualizarPolitica.mockResolvedValue({ ok: false, tipo: "general", mensaje: "No se pudo guardar." });
    render(<FilaDeBien bien={bien()} arrendadorVerificado />);
    const interruptor = screen.getByRole("switch", { name: NOMBRE });

    await userEvent.click(interruptor);

    expect(await screen.findByRole("alert")).toHaveTextContent("No se pudo guardar.");
    expect(interruptor).not.toBeChecked();
  });

  it("con 401 avisa que la sesión venció", async () => {
    actualizarPolitica.mockResolvedValue({ ok: false, tipo: "sesion", mensaje: "" });
    const alSesionVencida = vi.fn();
    render(<FilaDeBien bien={bien()} arrendadorVerificado alSesionVencida={alSesionVencida} />);

    await userEvent.click(screen.getByRole("switch", { name: NOMBRE }));

    await waitFor(() => expect(alSesionVencida).toHaveBeenCalled());
    expect(screen.queryByRole("alert")).not.toBeInTheDocument();
  });

  it("sin verificar no deja activarlo y enlaza a /perfil", () => {
    render(<FilaDeBien bien={bien()} arrendadorVerificado={false} />);
    expect(screen.getByRole("switch", { name: NOMBRE })).toBeDisabled();
    expect(screen.getByRole("link", { name: "Ir a verificación" })).toHaveAttribute("href", "/perfil");
  });

  it("sin verificar sí deja desactivarlo si ya estaba activo", async () => {
    actualizarPolitica.mockResolvedValue({ ok: true, politica: { soloVerificados: false } });
    render(<FilaDeBien bien={bien({ soloVerificados: true })} arrendadorVerificado={false} />);
    const interruptor = screen.getByRole("switch", { name: NOMBRE });
    expect(interruptor).toBeEnabled();

    await userEvent.click(interruptor);

    expect(actualizarPolitica).toHaveBeenCalledWith("b1", false);
    await waitFor(() => expect(interruptor).not.toBeChecked());
  });
});
