"use client";

import Link from "next/link";
import { useRef, useState } from "react";
import { cerrarSesion } from "@/app/actions/auth";
import { Icono, Imagen, InsigniaDeEstado, Interruptor, clasesBoton } from "@/components/ui";
import { formatearPrecio } from "@/lib/bienes";
import {
  ESTADO_BIEN,
  hrefBloqueos,
  hrefPublicacion,
  ubicacionDelBien,
  type MiBien,
} from "@/lib/mis-bienes";
import { actualizarPolitica } from "@/lib/politica-verificacion";

type Props = {
  bien: MiBien;
  /**
   * Si el arrendador está VERIFICADO (`GET /verificaciones/mi-estado`). Si no,
   * no puede activar «Solo usuarios verificados» (sí desactivarlo).
   */
  arrendadorVerificado: boolean;
  /** Qué hacer si la sesión venció (401). Por defecto, cerrar sesión. */
  alSesionVencida?: () => void;
};

/**
 * Fila de «Mis bienes» (FE-1.2): foto, estado, título, precio y ubicación, el
 * interruptor «Solo usuarios verificados» (H19) y las acciones «Bloquear
 * fechas» (H7) y «Ver publicación».
 *
 * El interruptor se aplica de inmediato y se guarda con `PUT`; si falla vuelve
 * al valor anterior y el error se muestra bajo la fila.
 */
export function FilaDeBien({
  bien,
  arrendadorVerificado,
  alSesionVencida = () => void cerrarSesion(),
}: Props) {
  const [activo, setActivo] = useState(bien.soloVerificados);
  const [guardando, setGuardando] = useState(false);
  const [error, setError] = useState<string | null>(null);
  // El estado se actualiza tras el render; la referencia corta el doble clic.
  const enCurso = useRef(false);

  async function cambiar(nuevo: boolean) {
    if (enCurso.current) return;
    enCurso.current = true;
    const anterior = activo;
    setActivo(nuevo);
    setGuardando(true);
    setError(null);

    const resultado = await actualizarPolitica(bien.id, nuevo);
    if (resultado.ok) {
      setActivo(resultado.politica.soloVerificados);
    } else {
      setActivo(anterior);
      if (resultado.tipo === "sesion") alSesionVencida();
      else setError(resultado.mensaje);
    }
    setGuardando(false);
    enCurso.current = false;
  }

  const bloqueado = !arrendadorVerificado && !activo;
  const estado = ESTADO_BIEN[bien.estado];

  return (
    <article
      aria-label={bien.titulo}
      className="flex flex-col gap-espacio-4 border border-borde-default bg-fondo-superficie p-espacio-4 md:flex-row md:items-center md:gap-espacio-5 md:p-5"
    >
      <div className="flex min-w-0 flex-1 items-center gap-espacio-4">
        <Imagen
          src={bien.fotoPrincipalUrl}
          alt={bien.titulo}
          sizes="120px"
          className="size-24 shrink-0 md:size-30"
        />
        <div className="flex min-w-0 flex-1 flex-col items-start gap-1.5">
          <InsigniaDeEstado texto={estado.texto} tono={estado.tono} />
          <h2 className="texto-h4 text-texto-primario">{bien.titulo}</h2>
          <p className="texto-precio text-texto-primario">
            {formatearPrecio(bien.precio, bien.unidadCobro)}
          </p>
          <p className="flex items-center gap-espacio-1">
            <Icono nombre="ubicacion" tamano={16} className="text-texto-secundario" />
            <span className="texto-cuerpo-pequeno text-texto-secundario">
              {ubicacionDelBien(bien)}
            </span>
          </p>
        </div>
      </div>

      <div className="flex flex-col items-start gap-espacio-2 md:shrink-0">
        <Interruptor
          texto="Solo usuarios verificados"
          checked={activo}
          disabled={guardando || bloqueado}
          aria-busy={guardando}
          aria-describedby={error ? `error-${bien.id}` : bloqueado ? `aviso-${bien.id}` : undefined}
          onChange={(evento) => void cambiar(evento.target.checked)}
        />
        {bloqueado && (
          <p id={`aviso-${bien.id}`} className="texto-cuerpo-pequeno text-texto-secundario">
            Verifica tu cuenta para activarlo.{" "}
            <Link href="/perfil" className="text-texto-acento underline">
              Ir a verificación
            </Link>
          </p>
        )}
      </div>

      <div className="flex flex-col gap-espacio-2 md:w-50 md:shrink-0">
        <Link href={hrefBloqueos(bien.id)} className={clasesBoton({ jerarquia: "secundario" })}>
          <Icono nombre="calendario" tamano={20} />
          Bloquear fechas
        </Link>
        <Link href={hrefPublicacion(bien.id)} className={clasesBoton({ jerarquia: "terciario" })}>
          Ver publicación
        </Link>
      </div>

      {error && (
        <p id={`error-${bien.id}`} role="alert" className="texto-cuerpo-pequeno text-texto-error">
          {error}
        </p>
      )}
    </article>
  );
}
