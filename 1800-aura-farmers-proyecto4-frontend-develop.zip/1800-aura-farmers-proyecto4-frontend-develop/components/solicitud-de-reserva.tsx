"use client";

import Link from "next/link";
import { useState, type ReactNode } from "react";
import { cerrarSesion } from "@/app/actions/auth";
import { CalendarioDeDisponibilidad } from "@/components/calendario-de-disponibilidad";
import { Alerta, BarraDeProgreso, Boton, clasesBoton } from "@/components/ui";
import { MENSAJE_CONFLICTO, MENSAJE_ERROR_DE_ENVIO } from "@/lib/solicitud/cliente";
import {
  alquilerEstimado,
  diasDelRango,
  formatearDia,
  formatearMoneda,
  textoDuracion,
  textoMotivo,
} from "@/lib/solicitud/formato";
import type { BienParaSolicitud } from "@/lib/solicitud/tipos";
import {
  INTERVALO_DE_CONSULTA_MS,
  LIMITE_DE_ESPERA_MS,
  useSolicitudDeReserva,
  type Fase,
  type Rango,
} from "@/lib/solicitud/use-solicitud-de-reserva";

/**
 * Rutas a las que enlaza el flujo. `/reservas/:id` y `/reservas` las crea
 * FE-6.2 (Mis reservas) y el pago FE-8.1; `/perfil` es FE-17.1.
 */
export const RUTA_MIS_RESERVAS = "/reservas";
export const RUTA_VERIFICACION = "/perfil";
export const rutaDePago = (reservaId: string) => `/reservas/${reservaId}/pago`;

type SolicitudDeReservaProps = {
  bien: BienParaSolicitud;
};

function Fila({ etiqueta, valor }: { etiqueta: string; valor: ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-espacio-4 border-b border-borde-default py-2.5">
      <dt className="texto-cuerpo-pequeno text-texto-secundario">{etiqueta}</dt>
      <dd className="texto-cuerpo-medio text-right text-texto-primario">{valor}</dd>
    </div>
  );
}

/**
 * Calendario de disponibilidad (FE-5.1, modo selección) + panel «Tu selección»
 * con el flujo de solicitud de FE-6.1: solicitar, indicador «en cola» con
 * consulta cada 2 s (máx. 30 s) y resultado final.
 */
export function SolicitudDeReserva({ bien }: SolicitudDeReservaProps) {
  const { fase, solicitar, reiniciar } = useSolicitudDeReserva(bien.id);
  const [rango, setRango] = useState<Rango | null>(null);
  // Cambiarla vuelve a montar el calendario: limpia la selección y consulta de nuevo la disponibilidad.
  const [claveCalendario, setClaveCalendario] = useState(0);

  const bloqueado = fase.tipo !== "libre" && fase.tipo !== "fallo";

  function alElegirRango(inicio: string | null, fin: string | null) {
    setRango(inicio && fin ? { inicio, fin } : null);
    // Elegir otras fechas deja atrás el aviso de un envío fallido.
    if (fase.tipo === "fallo") reiniciar();
  }

  function elegirOtrasFechas() {
    reiniciar();
    setRango(null);
    setClaveCalendario((valor) => valor + 1);
  }

  // Mientras hay una solicitud en curso o resuelta, el panel muestra el rango enviado.
  const rangoDelPanel = fase.tipo === "libre" ? rango : fase.rango;

  return (
    <div className="grid w-full gap-espacio-6 lg:grid-cols-[minmax(0,560px)_400px] lg:items-start">
      {/* fieldset deshabilitado: bloquea los días del calendario mientras se envía o se espera. */}
      <fieldset disabled={bloqueado} className="min-w-0 border-0 p-0">
        <h2 className="texto-h3 mb-espacio-3 text-texto-primario">Disponibilidad</h2>
        <CalendarioDeDisponibilidad
          key={claveCalendario}
          bienId={bien.id}
          modo="seleccion"
          onRangoSeleccionado={alElegirRango}
        />
      </fieldset>

      <section
        aria-labelledby="titulo-seleccion"
        className="flex flex-col gap-espacio-4 border border-borde-default bg-fondo-superficie p-espacio-5"
      >
        <h2 id="titulo-seleccion" className="texto-h4 text-texto-primario">
          Tu selección
        </h2>
        {rangoDelPanel ? (
          <Resumen bien={bien} rango={rangoDelPanel} />
        ) : (
          <p className="texto-cuerpo text-texto-secundario">
            Elige la fecha de inicio y la de fin en el calendario.
          </p>
        )}
        <Accion
          fase={fase}
          rango={rango}
          onSolicitar={() => rango && solicitar(rango)}
          onElegirOtras={elegirOtrasFechas}
        />
      </section>
    </div>
  );
}

function Resumen({ bien, rango }: { bien: BienParaSolicitud; rango: Rango }) {
  const dias = diasDelRango(rango.inicio, rango.fin);
    return (
    <dl className="flex flex-col border-t border-borde-default">
      <Fila etiqueta="Fechas" valor={`${formatearDia(rango.inicio)} → ${formatearDia(rango.fin)}`} />
      {dias !== null && <Fila etiqueta="Duración" valor={textoDuracion(dias)} />}
      {dias !== null && (
        <Fila etiqueta="Alquiler estimado" valor={formatearMoneda(alquilerEstimado(bien, dias))} />
      )}
      <Fila etiqueta="Depósito de garantía" valor={formatearMoneda(bien.deposito)} />
    </dl>
  );
}

type AccionProps = {
  fase: Fase;
  rango: Rango | null;
  onSolicitar: () => void;
  onElegirOtras: () => void;
};

const AYUDA_RESPUESTA = "La respuesta es automática en un máximo de 10 segundos.";

function Accion({ fase, rango, onSolicitar, onElegirOtras }: AccionProps) {
  switch (fase.tipo) {
    case "libre":
      return <BotonSolicitar rango={rango} onSolicitar={onSolicitar} />;

    case "enviando":
      return <Boton cargando className="w-full" />;

    case "en-cola": {
      const avance = Math.max(5, ((fase.consultas * INTERVALO_DE_CONSULTA_MS) / LIMITE_DE_ESPERA_MS) * 100);
      return (
        <>
          <Alerta tono="info" titulo="Tu solicitud está en cola.">
            Estamos revisando la disponibilidad. Te avisamos aquí mismo en unos segundos.
          </Alerta>
          <BarraDeProgreso valor={avance} etiqueta="Esperando la respuesta de tu solicitud" />
          <p className="texto-cuerpo-pequeno text-texto-secundario">Consultando cada 2 segundos…</p>
        </>
      );
    }

    case "confirmada":
      return (
        <>
          <Alerta tono="exito" titulo="¡Reserva confirmada!">
            Las fechas quedaron reservadas. Paga para completar tu reserva.
          </Alerta>
          <Link href={rutaDePago(fase.reservaId)} className={clasesBoton({ className: "w-full" })}>
            Ir a pagar
          </Link>
          <Link
            href={RUTA_MIS_RESERVAS}
            className={clasesBoton({ jerarquia: "secundario", className: "w-full" })}
          >
            Ver mis reservas
          </Link>
        </>
      );

    case "rechazada": {
      const motivo = textoMotivo(fase.motivo);
      return (
        <>
          <Alerta tono="error" titulo="Solicitud rechazada">
            {motivo ? `Motivo: ${motivo}.` : "No pudimos reservar esas fechas."}
            {fase.motivo === "FECHAS_NO_DISPONIBLES" && " Otra persona reservó esas fechas antes."}
          </Alerta>
          <Boton jerarquia="secundario" className="w-full" onClick={onElegirOtras}>
            Elegir otras fechas
          </Boton>
        </>
      );
    }

    case "sin-respuesta":
      return (
        <>
          <Alerta tono="info" titulo="Tu solicitud sigue en proceso.">
            Revisa Mis reservas.
          </Alerta>
          <Link
            href={RUTA_MIS_RESERVAS}
            className={clasesBoton({ jerarquia: "secundario", className: "w-full" })}
          >
            Ir a Mis reservas
          </Link>
        </>
      );

    case "fallo":
      return <AccionTrasFallo fase={fase} rango={rango} onSolicitar={onSolicitar} onElegirOtras={onElegirOtras} />;
  }
}

function BotonSolicitar({ rango, onSolicitar }: { rango: Rango | null; onSolicitar: () => void }) {
  return (
    <>
      <Boton className="w-full" disabled={!rango} onClick={onSolicitar}>
        Solicitar reserva
      </Boton>
      {rango && <p className="texto-cuerpo-pequeno text-texto-secundario">{AYUDA_RESPUESTA}</p>}
    </>
  );
}

function AccionTrasFallo({
  fase,
  rango,
  onSolicitar,
  onElegirOtras,
}: AccionProps & { fase: Extract<Fase, { tipo: "fallo" }> }) {
  switch (fase.causa) {
    case "sesion":
      return (
        <>
          <Alerta tono="advertencia" titulo="Tu sesión expiró.">
            Inicia sesión de nuevo para solicitar la reserva.
          </Alerta>
          {/* Cerrar sesión borra la cookie y lleva al login (/login redirige mientras haya cookie). */}
          <form action={cerrarSesion}>
            <Boton type="submit" jerarquia="secundario" className="w-full">
              Iniciar sesión
            </Boton>
          </form>
        </>
      );

    case "verificacion":
      return (
        <>
          <Alerta tono="advertencia" titulo="Debes verificar tu cuenta">
            Este bien solo acepta usuarios verificados. Sube tu documento de identidad para poder solicitarlo.
          </Alerta>
          <Link href={RUTA_VERIFICACION} className={clasesBoton({ className: "w-full" })}>
            Verificar mi cuenta
          </Link>
        </>
      );

    case "conflicto":
      return (
        <>
          <Alerta tono="error" titulo={MENSAJE_CONFLICTO}>
            Elige otro rango en el calendario.
          </Alerta>
          <Boton jerarquia="secundario" className="w-full" onClick={onElegirOtras}>
            Elegir otras fechas
          </Boton>
        </>
      );

    case "validacion":
      // La misma selección volvería a fallar: el usuario corrige las fechas en el calendario.
      return (
        <Alerta tono="error" titulo="No pudimos enviar tu solicitud.">
          {fase.mensaje}
        </Alerta>
      );

    case "general":
      return (
        <>
          <Alerta tono="error">{MENSAJE_ERROR_DE_ENVIO}</Alerta>
          <BotonSolicitar rango={rango} onSolicitar={onSolicitar} />
        </>
      );
  }
}
