"use client";

import { useCallback, useEffect, useState } from "react";
import { cerrarSesion } from "@/app/actions/auth";
import { CalendarioDeDisponibilidad } from "@/components/calendario-de-disponibilidad";
import {
  Alerta,
  Boton,
  CampoDeTexto,
  DialogoDeConfirmacion,
  EstadoDePagina,
  type TonoAlerta,
} from "@/components/ui";
import {
  ERROR_GENERAL,
  esListaDeBloqueos,
  formatearFecha,
  mensajeDeError,
  ordenarPorInicio,
  textoDeDias,
  textoDelRango,
  type Bloqueo,
} from "@/lib/bloqueos";
import type { Disponibilidad, RangoFechas } from "@/lib/disponibilidad";

type GestionDeBloqueosProps = {
  bienId: string;
};

type Rango = { inicio: string; fin: string };

type Aviso = { tono: TonoAlerta; titulo: string; detalle: string };

/** Estado de la lista de bloqueos; `clave` identifica la consulta a la que responde. */
type ListaDeBloqueos = {
  clave: string;
  bloqueos: Bloqueo[] | null;
  /** HTTP del fallo, o 0 si fue de red o de formato. */
  fallo: number | null;
};

type Respuesta = { estado: number; cuerpo: unknown };

/** Llama a las rutas de Next; un fallo de red se informa como estado 0. */
async function llamar(url: string, init?: RequestInit): Promise<Respuesta> {
  try {
    const respuesta = await fetch(url, { cache: "no-store", ...init });
    const cuerpo: unknown = await respuesta.json().catch(() => null);
    return { estado: respuesta.status, cuerpo };
  } catch {
    return { estado: 0, cuerpo: null };
  }
}

function Panel({ titulo, children }: { titulo: string; children: React.ReactNode }) {
  return (
    <section className="flex flex-col gap-espacio-4 border border-borde-default bg-fondo-superficie p-espacio-6">
      <h2 className="texto-h3 text-texto-primario">{titulo}</h2>
      {children}
    </section>
  );
}

/**
 * Gestión de bloqueos de fechas del arrendador (FE-7.1, H7): elige un rango en
 * el calendario y lo bloquea, ve los bloqueos vigentes y los elimina con
 * confirmación, y ve las reservas confirmadas en solo lectura.
 *
 * Datos: `GET/POST /api/bienes/[bienId]/bloqueos` y
 * `DELETE /api/bienes/[bienId]/bloqueos/[id]`, puentes de Next al backend. Un
 * error al bloquear o eliminar solo muestra su mensaje: el calendario y la
 * selección no cambian.
 */
export function GestionDeBloqueos({ bienId }: GestionDeBloqueosProps) {
  const [actualizacion, setActualizacion] = useState(0);
  const [intento, setIntento] = useState(0);
  const [rango, setRango] = useState<Rango | null>(null);
  const [disponibilidad, setDisponibilidad] = useState<Disponibilidad | null>(null);
  const [lista, setLista] = useState<ListaDeBloqueos | null>(null);
  const [aviso, setAviso] = useState<Aviso | null>(null);
  const [guardando, setGuardando] = useState(false);
  const [porEliminar, setPorEliminar] = useState<Bloqueo | null>(null);
  const [eliminando, setEliminando] = useState(false);
  const [sesionVencida, setSesionVencida] = useState(false);

  const clave = `${bienId}:${actualizacion}:${intento}`;
  const cargandoLista = lista?.clave !== clave;

  useEffect(() => {
    const control = new AbortController();
    llamar(`/api/bienes/${encodeURIComponent(bienId)}/bloqueos`, { signal: control.signal }).then(
      ({ estado, cuerpo }) => {
        if (control.signal.aborted) return;
        if (estado === 200 && esListaDeBloqueos(cuerpo)) {
          setLista({ clave, bloqueos: ordenarPorInicio(cuerpo), fallo: null });
        } else {
          setLista({ clave, bloqueos: null, fallo: estado === 200 ? 0 : estado });
        }
      },
    );
    return () => control.abort();
  }, [bienId, clave]);

  const registrarDisponibilidad = useCallback((datos: Disponibilidad) => setDisponibilidad(datos), []);

  function recargar() {
    setRango(null);
    setActualizacion((valor) => valor + 1);
  }

  function falloDeAccion(estado: number, cuerpo: unknown) {
    if (estado === 401) {
      setSesionVencida(true);
      return;
    }
    const mensaje = estado === 0 ? ERROR_GENERAL : mensajeDeError(estado, cuerpo);
    setAviso({ tono: "error", titulo: mensaje, detalle: "El calendario no cambió. Revisa el rango e intenta de nuevo." });
  }

  async function bloquear() {
    if (!rango || guardando) return;
    setGuardando(true);
    setAviso(null);
    const { estado, cuerpo } = await llamar(`/api/bienes/${encodeURIComponent(bienId)}/bloqueos`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ fechaInicio: rango.inicio, fechaFin: rango.fin }),
    });
    setGuardando(false);
    if (estado !== 201) {
      falloDeAccion(estado, cuerpo);
      return;
    }
    setAviso({
      tono: "exito",
      titulo: "Fechas bloqueadas",
      detalle: `Del ${formatearFecha(rango.inicio)} al ${formatearFecha(rango.fin)}. Ya no se pueden reservar.`,
    });
    recargar();
  }

  async function eliminar() {
    if (!porEliminar || eliminando) return;
    const bloqueo = porEliminar;
    setEliminando(true);
    setAviso(null);
    const { estado, cuerpo } = await llamar(
      `/api/bienes/${encodeURIComponent(bienId)}/bloqueos/${encodeURIComponent(bloqueo.id)}`,
      { method: "DELETE" },
    );
    setEliminando(false);
    setPorEliminar(null);
    if (estado === 204) {
      setAviso({
        tono: "exito",
        titulo: "Bloqueo eliminado",
        detalle: `Del ${formatearFecha(bloqueo.fechaInicio)} al ${formatearFecha(bloqueo.fechaFin)}. Ya se puede reservar.`,
      });
      recargar();
    } else if (estado === 404) {
      // Ya no existe (otro dispositivo, otra pestaña): se actualiza lo que se ve.
      falloDeAccion(estado, cuerpo);
      recargar();
    } else {
      falloDeAccion(estado, cuerpo);
    }
  }

  if (sesionVencida || lista?.fallo === 401) {
    return (
      <EstadoDePagina
        tipo="sin-permiso"
        titulo="Tu sesión expiró."
        mensaje="Inicia sesión de nuevo para gestionar los bloqueos."
        accion={
          <form action={cerrarSesion}>
            <Boton type="submit" jerarquia="secundario">
              Iniciar sesión
            </Boton>
          </form>
        }
      />
    );
  }
  if (lista?.fallo === 403) {
    return <EstadoDePagina tipo="sin-permiso" mensaje="No puedes modificar este bien." />;
  }
  if (lista?.fallo === 404) {
    return <EstadoDePagina tipo="no-encontrado" />;
  }

  const reservas: RangoFechas[] = disponibilidad ? ordenarPorInicio(disponibilidad.reservados) : [];

  return (
    <div className="flex flex-col gap-espacio-6">
      {aviso && (
        <Alerta tono={aviso.tono} titulo={aviso.titulo}>
          {aviso.detalle}
        </Alerta>
      )}

      <div className="grid items-start gap-espacio-6 lg:grid-cols-[560px_minmax(0,1fr)]">
        <CalendarioDeDisponibilidad
          bienId={bienId}
          modo="gestion"
          actualizacion={actualizacion}
          onDisponibilidad={registrarDisponibilidad}
          onRangoSeleccionado={(inicio, fin) => setRango(inicio && fin ? { inicio, fin } : null)}
        />

        <div className="flex flex-col gap-espacio-6">
          <Panel titulo="Nuevo bloqueo">
            <div className="grid gap-espacio-3 sm:grid-cols-2">
              <CampoDeTexto
                etiqueta="Desde"
                readOnly
                placeholder="DD/MM/AAAA"
                value={rango ? formatearFecha(rango.inicio) : ""}
              />
              <CampoDeTexto
                etiqueta="Hasta"
                readOnly
                placeholder="DD/MM/AAAA"
                value={rango ? formatearFecha(rango.fin) : ""}
              />
            </div>
            <p className="texto-cuerpo-pequeno text-texto-secundario">
              También puedes elegir el rango directamente en el calendario.
            </p>
            <Boton icono="candado" onClick={bloquear} disabled={!rango} cargando={guardando}>
              Bloquear fechas
            </Boton>
          </Panel>

          <Panel titulo="Bloqueos activos">
            {cargandoLista ? (
              <p role="status" className="texto-cuerpo text-texto-secundario">
                Cargando bloqueos…
              </p>
            ) : lista?.bloqueos ? (
              lista.bloqueos.length === 0 ? (
                <p className="texto-cuerpo text-texto-secundario">No tienes bloqueos vigentes.</p>
              ) : (
                <ul className="flex flex-col">
                  {lista.bloqueos.map((bloqueo) => (
                    <li
                      key={bloqueo.id}
                      className="flex items-center justify-between gap-espacio-4 border-b border-borde-sutil py-espacio-3 last:border-b-0"
                    >
                      <div className="flex flex-col">
                        <span className="texto-cuerpo-medio text-texto-primario">{textoDelRango(bloqueo)}</span>
                        <span className="texto-cuerpo-pequeno text-texto-secundario">{textoDeDias(bloqueo)}</span>
                      </div>
                      <Boton
                        jerarquia="terciario"
                        icono="basura"
                        aria-label={`Eliminar el bloqueo del ${textoDelRango(bloqueo)}`}
                        onClick={() => setPorEliminar(bloqueo)}
                      >
                        Eliminar
                      </Boton>
                    </li>
                  ))}
                </ul>
              )
            ) : (
              <div className="flex flex-col items-start gap-espacio-3">
                <Alerta tono="error" titulo="No pudimos cargar los bloqueos.">
                  Revisa tu conexión e intenta de nuevo.
                </Alerta>
                <Boton jerarquia="secundario" onClick={() => setIntento((valor) => valor + 1)}>
                  Reintentar
                </Boton>
              </div>
            )}
          </Panel>

          <Panel titulo="Reservas confirmadas (solo lectura)">
            {reservas.length === 0 ? (
              <p className="texto-cuerpo text-texto-secundario">
                {disponibilidad ? "No hay reservas confirmadas en los próximos 12 meses." : "Cargando reservas…"}
              </p>
            ) : (
              <ul className="flex flex-col">
                {reservas.map((reserva) => (
                  <li
                    key={`${reserva.fechaInicio}:${reserva.fechaFin}`}
                    className="texto-cuerpo border-b border-borde-sutil py-espacio-3 text-texto-primario last:border-b-0"
                  >
                    {textoDelRango(reserva)}
                  </li>
                ))}
              </ul>
            )}
          </Panel>
        </div>
      </div>

      <DialogoDeConfirmacion
        abierto={porEliminar !== null}
        titulo="¿Eliminar este bloqueo?"
        mensaje={
          porEliminar
            ? `Las fechas del ${formatearFecha(porEliminar.fechaInicio)} al ${formatearFecha(porEliminar.fechaFin)} volverán a estar disponibles para reservar.`
            : ""
        }
        textoConfirmar="Eliminar"
        peligro
        cargando={eliminando}
        onConfirmar={eliminar}
        onCancelar={() => setPorEliminar(null)}
      />
    </div>
  );
}
