"use client";

import { useState } from "react";
import { consultaDePeriodo, type PeriodoAplicado } from "@/lib/periodo-reporte";
import { descargarArchivo } from "@/lib/reportes/descarga";
import { exportarResumen } from "@/lib/reportes/exportar";
import { irASesionVencida } from "@/lib/reportes/sesion-vencida";

/**
 * Exporta el resumen a CSV con el periodo dado (el de la tabla en pantalla).
 * `descargando` impide un segundo clic mientras la descarga está en curso. El
 * error de una exportación se muestra hasta que se intenta otra o cambia el
 * periodo; nunca toca la tabla.
 */
export function useExportarResumen(periodo: PeriodoAplicado) {
  const clave = consultaDePeriodo(periodo).toString();
  const [descargando, setDescargando] = useState(false);
  const [fallo, setFallo] = useState<{ clave: string; mensaje: string } | null>(null);

  async function exportar() {
    if (descargando) return;
    setDescargando(true);
    setFallo(null);
    const resultado = await exportarResumen(periodo);
    setDescargando(false);

    if (resultado.tipo === "ok") descargarArchivo(resultado.archivo, resultado.nombre);
    else if (resultado.tipo === "sesion") irASesionVencida();
    else setFallo({ clave, mensaje: resultado.mensaje });
  }

  return {
    exportar,
    descargando,
    error: fallo?.clave === clave ? fallo.mensaje : null,
  };
}
