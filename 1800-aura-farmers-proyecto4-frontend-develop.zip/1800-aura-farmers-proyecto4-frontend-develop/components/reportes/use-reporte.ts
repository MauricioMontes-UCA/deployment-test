"use client";

import { useEffect, useState } from "react";
import { consultaDePeriodo } from "@/lib/periodo-reporte";
import {
  consultarReporte,
  type ErrorReporte,
  type Reporte,
} from "@/lib/reportes/cliente";
import { irASesionVencida } from "@/lib/reportes/sesion-vencida";
import { usePeriodoReporte } from "./periodo-compartido";

export type EstadoReporte<T> = {
  /** La última respuesta exitosa; se conserva si una consulta nueva falla. */
  datos: T | null;
  /** Hay una consulta en curso (la primera o la de un periodo nuevo). */
  cargando: boolean;
  /** Por qué falló la última consulta; `null` si salió bien o sigue en curso. */
  error: Exclude<ErrorReporte, { tipo: "sesion" }> | null;
  reintentar: () => void;
};

/**
 * Consulta un reporte con el periodo compartido del panel: al abrir la sección
 * y cada vez que el periodo cambia. Si el periodo cambia con una consulta en
 * curso, se cancela y solo cuenta la del último periodo. Una respuesta 401
 * lleva a `/sesion-vencida`.
 *
 * Mientras carga conserva `datos` (la tabla anterior) y, si la consulta falla,
 * también: la pantalla decide cómo mostrar el error sobre ella.
 */
export function useReporte<T>(reporte: Reporte): EstadoReporte<T> {
  const periodo = usePeriodoReporte();
  const [intento, setIntento] = useState(0);
  const [datos, setDatos] = useState<T | null>(null);
  const [resuelta, setResuelta] = useState<{
    clave: string;
    error: EstadoReporte<T>["error"];
  } | null>(null);

  // Identifica la consulta pedida. «Cargando» es no haber resuelto aún esa clave.
  const clave = `${reporte}?${consultaDePeriodo(periodo)}#${intento}`;

  useEffect(() => {
    const cancelable = new AbortController();
    void consultarReporte<T>(reporte, periodo, cancelable.signal).then((resultado) => {
      if (cancelable.signal.aborted) return;
      if (resultado.tipo === "sesion") return irASesionVencida();
      if (resultado.tipo === "ok") {
        setDatos(resultado.datos);
        setResuelta({ clave, error: null });
      } else {
        setResuelta({ clave, error: resultado });
      }
    });
    return () => cancelable.abort();
    // `clave` ya resume reporte, periodo e intento.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [clave]);

  const vigente = resuelta?.clave === clave;
  return {
    datos,
    cargando: !vigente,
    error: vigente ? resuelta.error : null,
    reintentar: () => setIntento((n) => n + 1),
  };
}
