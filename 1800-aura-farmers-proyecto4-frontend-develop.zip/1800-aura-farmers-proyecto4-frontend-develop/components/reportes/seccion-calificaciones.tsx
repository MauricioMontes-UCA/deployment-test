"use client";

import { Tabla, TablaCelda, TablaEncabezado } from "@/components/ui";
import {
  formatearPromedio,
  formatearResenas,
} from "@/lib/reportes/formato";
import { MarcoDeReporte } from "./marco-de-reporte";
import { useReporte } from "./use-reporte";

/** Respuesta de `GET /reportes/calificaciones` (solo lo que usa la pantalla). */
export type CalificacionesResponse = {
  periodo: { desde: string; hasta: string };
  escalaMaxima: number;
  totalBienes: number;
  bienes: { bienId: string; titulo: string; promedio: number | null; totalResenas: number }[];
};

/**
 * Sección «Calificaciones» del panel de reportes (FE-25.1): promedio y número
 * de reseñas de cada bien, en el orden del servicio (de menor a mayor
 * calificación, con «Sin calificaciones» al final). Un promedio `null` nunca
 * se muestra como 0.
 */
export function SeccionCalificaciones() {
  const estado = useReporte<CalificacionesResponse>("calificaciones");

  return (
    <MarcoDeReporte estado={estado} sinBienes={(datos) => datos.bienes.length === 0}>
      {(datos) => (
        <>
          <Tabla>
            <thead>
              <tr>
                <TablaEncabezado>Bien</TablaEncabezado>
                <TablaEncabezado alineacion="derecha">Calificación promedio</TablaEncabezado>
                <TablaEncabezado alineacion="derecha">Reseñas</TablaEncabezado>
              </tr>
            </thead>
            <tbody>
              {datos.bienes.map((bien) => (
                <tr key={bien.bienId}>
                  <TablaCelda className="max-md:whitespace-nowrap">{bien.titulo}</TablaCelda>
                  <TablaCelda
                    alineacion="derecha"
                    enfasis={bien.promedio === null ? "atenuada" : "normal"}
                  >
                    {formatearPromedio(bien.promedio, datos.escalaMaxima)}
                  </TablaCelda>
                  <TablaCelda alineacion="derecha">{formatearResenas(bien.totalResenas)}</TablaCelda>
                </tr>
              ))}
            </tbody>
          </Tabla>
          <p className="texto-cuerpo-pequeno text-texto-secundario">
            Solo reseñas del bien de reservas finalizadas en el periodo. Orden de menor a mayor
            calificación; «Sin calificaciones» al final.
          </p>
        </>
      )}
    </MarcoDeReporte>
  );
}
