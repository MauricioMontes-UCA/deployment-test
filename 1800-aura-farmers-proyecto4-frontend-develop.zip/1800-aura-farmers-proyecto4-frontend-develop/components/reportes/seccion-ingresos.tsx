"use client";

import { Tabla, TablaCelda, TablaEncabezado } from "@/components/ui";
import { formatearMoneda } from "@/lib/reportes/formato";
import { MarcoDeReporte } from "./marco-de-reporte";
import { useReporte } from "./use-reporte";

/** Respuesta de `GET /reportes/ingresos` (solo lo que usa la pantalla). */
export type IngresosResponse = {
  periodo: { desde: string; hasta: string };
  totalIngresos: number;
  totalDepositoRetenido: number;
  totalBienes: number;
  bienes: { bienId: string; titulo: string; ingresos: number; depositoRetenido: number }[];
};

function Total({ etiqueta, valor, ayuda }: { etiqueta: string; valor: number; ayuda: string }) {
  return (
    <div className="flex flex-1 flex-col gap-espacio-2 border border-borde-default bg-fondo-superficie p-espacio-5">
      <p className="texto-sobretitulo text-texto-primario">{etiqueta}</p>
      <p className="texto-h3 text-texto-primario">{formatearMoneda(valor)}</p>
      <p className="texto-cuerpo-pequeno text-texto-secundario">{ayuda}</p>
    </div>
  );
}

/**
 * Sección «Ingresos» del panel de reportes (FE-23.2): una fila por bien con
 * sus ingresos y el depósito retenido en una columna aparte, y la fila Total
 * que devuelve el servicio. El depósito nunca se suma a los ingresos.
 */
export function SeccionIngresos() {
  const estado = useReporte<IngresosResponse>("ingresos");

  return (
    <MarcoDeReporte estado={estado} sinBienes={(datos) => datos.bienes.length === 0}>
      {(datos) => (
        <>
          <div className="flex flex-col gap-espacio-4 md:flex-row">
            <Total
              etiqueta="Ingreso total"
              valor={datos.totalIngresos}
              ayuda="Solo alquiler de pagos aprobados en el periodo."
            />
            <Total
              etiqueta="Depósito retenido"
              valor={datos.totalDepositoRetenido}
              ayuda="Se muestra aparte; no se suma al ingreso."
            />
          </div>
          <Tabla>
            <thead>
              <tr>
                <TablaEncabezado>Bien</TablaEncabezado>
                <TablaEncabezado alineacion="derecha">Ingresos</TablaEncabezado>
                <TablaEncabezado alineacion="derecha">Depósito retenido</TablaEncabezado>
              </tr>
            </thead>
            <tbody>
              {datos.bienes.map((bien) => (
                <tr key={bien.bienId}>
                  <TablaCelda className="max-md:whitespace-nowrap">{bien.titulo}</TablaCelda>
                  <TablaCelda alineacion="derecha">{formatearMoneda(bien.ingresos)}</TablaCelda>
                  <TablaCelda alineacion="derecha">
                    {formatearMoneda(bien.depositoRetenido)}
                  </TablaCelda>
                </tr>
              ))}
              <tr>
                <TablaCelda enfasis="total">Total</TablaCelda>
                <TablaCelda enfasis="total" alineacion="derecha">
                  {formatearMoneda(datos.totalIngresos)}
                </TablaCelda>
                <TablaCelda enfasis="total" alineacion="derecha">
                  {formatearMoneda(datos.totalDepositoRetenido)}
                </TablaCelda>
              </tr>
            </tbody>
          </Tabla>
        </>
      )}
    </MarcoDeReporte>
  );
}
