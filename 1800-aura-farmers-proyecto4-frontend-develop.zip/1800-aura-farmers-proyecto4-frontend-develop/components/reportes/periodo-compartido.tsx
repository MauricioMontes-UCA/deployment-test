"use client";

import { createContext, useContext, type ReactNode } from "react";
import { PERIODO_INICIAL, type PeriodoAplicado } from "@/lib/periodo-reporte";

const ContextoPeriodo = createContext<PeriodoAplicado | null>(null);

/**
 * Comparte el periodo elegido con las secciones del panel. Lo monta
 * `PanelDeReportes` dentro del layout de /reportes, que no se desmonta al
 * cambiar de pestaña: por eso el periodo se conserva entre secciones.
 */
export function ProveedorDePeriodo({
  periodo,
  children,
}: {
  periodo: PeriodoAplicado;
  children: ReactNode;
}) {
  return <ContextoPeriodo.Provider value={periodo}>{children}</ContextoPeriodo.Provider>;
}

/**
 * Periodo vigente del panel de reportes. Las secciones (ingresos, ocupación,
 * calificaciones y resumen) consultan su endpoint con él, por ejemplo con
 * `consultaDePeriodo(periodo)` de `@/lib/periodo-reporte`. Fuera del panel
 * devuelve el periodo por defecto.
 */
export function usePeriodoReporte(): PeriodoAplicado {
  return useContext(ContextoPeriodo) ?? PERIODO_INICIAL;
}
