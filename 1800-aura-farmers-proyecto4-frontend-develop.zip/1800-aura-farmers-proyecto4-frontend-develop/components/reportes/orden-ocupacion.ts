/** Una fila de `GET /reportes/ocupacion`. */
export type BienOcupacion = {
  bienId: string;
  titulo: string;
  diasDisponibles: number;
  diasOcupados: number;
  /** Porcentaje con un decimal; `null` si no hay días disponibles. */
  tasaOcupacion: number | null;
};

export type SentidoOrden = "descendente" | "ascendente";

const porTitulo = (a: BienOcupacion, b: BienOcupacion) =>
  a.titulo.localeCompare(b.titulo, "es", { sensitivity: "base" });

/**
 * Ordena los bienes por tasa de ocupación. Los bienes sin tasa («Sin días
 * disponibles») quedan al final en los dos sentidos y, a igual tasa, se
 * ordena por título de la A a la Z. No modifica el arreglo recibido.
 */
export function ordenarPorTasa(bienes: BienOcupacion[], sentido: SentidoOrden): BienOcupacion[] {
  const factor = sentido === "descendente" ? -1 : 1;
  return [...bienes].sort((a, b) => {
    if (a.tasaOcupacion === null && b.tasaOcupacion === null) return porTitulo(a, b);
    if (a.tasaOcupacion === null) return 1;
    if (b.tasaOcupacion === null) return -1;
    return factor * (a.tasaOcupacion - b.tasaOcupacion) || porTitulo(a, b);
  });
}
