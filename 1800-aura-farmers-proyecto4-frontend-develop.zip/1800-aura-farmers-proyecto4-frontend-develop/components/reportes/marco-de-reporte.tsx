import type { ReactNode } from "react";
import { Alerta, Boton, Icono } from "@/components/ui";
import { unirClases } from "@/lib/clases";
import { MENSAJES_REPORTE } from "@/lib/reportes/cliente";
import type { EstadoReporte } from "./use-reporte";

type Props<T> = {
  estado: EstadoReporte<T>;
  /** El reporte no trae bienes: se muestra «Aún no tienes bienes publicados.». */
  sinBienes: (datos: T) => boolean;
  /** Contenido con datos (tablas, tarjetas, botones). */
  children: (datos: T) => ReactNode;
  className?: string;
};

/**
 * Estados comunes de las secciones del panel de reportes: cargando (con la
 * tabla anterior atenuada), vacío y los errores 400, 403 y de red o 500 (con
 * «Reintentar»). Con un error y una tabla anterior, el mensaje va encima y la
 * tabla se conserva.
 */
export function MarcoDeReporte<T>({ estado, sinBienes, children, className }: Props<T>) {
  const { datos, cargando, error, reintentar } = estado;

  const alerta = error && (
    <Alerta tono="error">
      {error.tipo === "acceso" && MENSAJES_REPORTE.sinAcceso}
      {error.tipo === "validacion" && error.mensaje}
      {error.tipo === "fallo" && MENSAJES_REPORTE.fallo}
      {datos !== null && error.tipo !== "acceso" && " Se muestra la última tabla consultada."}
      {error.tipo === "fallo" && (
        <span className="mt-espacio-2 block">
          <Boton jerarquia="secundario" onClick={reintentar}>
            Reintentar
          </Boton>
        </span>
      )}
    </Alerta>
  );

  // Sin permiso no hay nada que conservar: solo el mensaje.
  if (error?.tipo === "acceso") return <div className={className}>{alerta}</div>;

  if (datos === null) {
    return (
      <div className={unirClases("flex flex-col gap-espacio-4", className)}>
        {alerta}
        {cargando && <Cargando texto="Cargando el reporte…" />}
      </div>
    );
  }

  return (
    <div className={unirClases("flex flex-col gap-espacio-4", className)}>
      {alerta}
      {cargando && <Cargando texto="Actualizando el reporte…" />}
      {sinBienes(datos) ? (
        <Alerta tono="info">{MENSAJES_REPORTE.sinBienes}</Alerta>
      ) : (
        <div
          aria-busy={cargando}
          className={unirClases(
            "flex flex-col gap-espacio-4 transition-opacity",
            cargando && "opacity-50",
          )}
        >
          {children(datos)}
          <p className="texto-cuerpo-pequeno text-texto-secundario md:hidden">
            Desliza la tabla para ver todas las columnas →
          </p>
        </div>
      )}
    </div>
  );
}

function Cargando({ texto }: { texto: string }) {
  return (
    <p role="status" className="texto-cuerpo-pequeno flex items-center gap-espacio-2 text-texto-secundario">
      <Icono nombre="cargando" tamano={16} className="animate-spin" />
      {texto}
    </p>
  );
}
