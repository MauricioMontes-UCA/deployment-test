"use client";

import { Alerta, Boton, Tabla, TablaCelda, TablaEncabezado } from "@/components/ui";
import { formatearMoneda, formatearPromedio, formatearResenas, formatearTasa } from "@/lib/reportes/formato";
import { MarcoDeReporte } from "./marco-de-reporte";
import { usePeriodoReporte } from "./periodo-compartido";
import { useExportarResumen } from "./use-exportar-resumen";
import { useReporte } from "./use-reporte";

/** Respuesta de `GET /reportes/resumen` (solo lo que usa la pantalla). */
export type ResumenResponse = {
  periodo: { desde: string; hasta: string };
  escalaMaxima: number;
  totalBienes: number;
  bienes: {
    bienId: string;
    titulo: string;
    ingresos: number;
    tasaOcupacion: number | null;
    calificacionPromedio: number | null;
    totalResenas: number;
  }[];
};

/** «4.5 / 5 (2 reseñas)» o «Sin calificaciones». */
function calificacion(
  promedio: number | null,
  totalResenas: number,
  escalaMaxima: number,
): string {
  return promedio === null
    ? formatearPromedio(null, escalaMaxima)
    : `${formatearPromedio(promedio, escalaMaxima)} (${formatearResenas(totalResenas)})`;
}

/**
 * Sección «Resumen» del panel de reportes (FE-26.1): una fila por bien con
 * ingresos, tasa de ocupación y calificación del mismo periodo compartido,
 * en el orden del servicio. No tiene un selector de periodo propio.
 *
 * FE-26.2: «Exportar CSV» descarga el mismo resumen del periodo en pantalla.
 * Queda deshabilitado sin filas, si la última consulta falló, mientras se
 * actualiza la tabla (para que el archivo no sea de otro periodo que el que se
 * ve) y mientras la descarga está en curso.
 */
export function SeccionResumen() {
  const estado = useReporte<ResumenResponse>("resumen");
  const periodo = usePeriodoReporte();
  const exportacion = useExportarResumen(periodo);

  const sinFilas = estado.datos === null || estado.datos.bienes.length === 0;

  return (
    <div className="flex flex-col gap-espacio-4">
      <div className="flex flex-col gap-espacio-3 sm:flex-row sm:items-center sm:justify-between">
        <p className="texto-cuerpo-pequeno text-texto-primario">
          {estado.datos && `Periodo: ${estado.datos.periodo.desde} a ${estado.datos.periodo.hasta}`}
        </p>
        <Boton
          jerarquia="secundario"
          icono="descargar"
          cargando={exportacion.descargando}
          disabled={sinFilas || estado.error !== null || estado.cargando}
          onClick={exportacion.exportar}
          className="w-full sm:w-auto"
        >
          Exportar CSV
        </Boton>
      </div>
      {exportacion.error && <Alerta tono="error">{exportacion.error}</Alerta>}
      <MarcoDeReporte estado={estado} sinBienes={(datos) => datos.bienes.length === 0}>
        {(datos) => (
          <Tabla>
            <thead>
              <tr>
                <TablaEncabezado>Bien</TablaEncabezado>
                <TablaEncabezado alineacion="derecha">Ingresos</TablaEncabezado>
                <TablaEncabezado alineacion="derecha">Tasa de ocupación</TablaEncabezado>
                <TablaEncabezado alineacion="derecha">Calificación promedio</TablaEncabezado>
              </tr>
            </thead>
            <tbody>
              {datos.bienes.map((bien) => (
                <tr key={bien.bienId}>
                  <TablaCelda className="max-md:whitespace-nowrap">{bien.titulo}</TablaCelda>
                  <TablaCelda alineacion="derecha">{formatearMoneda(bien.ingresos)}</TablaCelda>
                  <TablaCelda
                    alineacion="derecha"
                    enfasis={bien.tasaOcupacion === null ? "atenuada" : "normal"}
                  >
                    {formatearTasa(bien.tasaOcupacion)}
                  </TablaCelda>
                  <TablaCelda
                    alineacion="derecha"
                    enfasis={bien.calificacionPromedio === null ? "atenuada" : "normal"}
                  >
                    {calificacion(bien.calificacionPromedio, bien.totalResenas, datos.escalaMaxima)}
                  </TablaCelda>
                </tr>
              ))}
            </tbody>
          </Tabla>
        )}
      </MarcoDeReporte>
    </div>
  );
}
