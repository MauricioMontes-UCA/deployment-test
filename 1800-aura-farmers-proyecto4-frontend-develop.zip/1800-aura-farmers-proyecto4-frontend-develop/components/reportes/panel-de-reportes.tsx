"use client";

import { usePathname, useRouter } from "next/navigation";
import { useState, type ReactNode } from "react";
import {
  PanelDePestana,
  Pestana,
  Pestanas,
  SelectorDePeriodo,
  type PeriodoReporte,
} from "@/components/ui";
import {
  PERIODO_INICIAL,
  periodoFijo,
  validarRango,
  type PeriodoAplicado,
} from "@/lib/periodo-reporte";
import { ProveedorDePeriodo } from "./periodo-compartido";

/** Secciones del panel, en el orden de las pestañas. */
export const SECCIONES_REPORTES = [
  { ruta: "/reportes/ingresos", texto: "Ingresos" },
  { ruta: "/reportes/ocupacion", texto: "Ocupación" },
  { ruta: "/reportes/calificaciones", texto: "Calificaciones" },
  { ruta: "/reportes/resumen", texto: "Resumen" },
] as const;

const ID_PANEL = "panel-reportes";
const idPestana = (ruta: string) => `pestana-${ruta.split("/").pop()}`;

/**
 * Selector de periodo y pestañas del panel de reportes (FE-23.1). Vive en el
 * layout de /reportes, así que al cambiar de pestaña no se desmonta y conserva
 * el periodo elegido. Las secciones lo leen con `usePeriodoReporte()`.
 *
 * - Último mes, Últimos 3 meses y Último año cambian el periodo al elegirlos.
 * - Rango de fechas solo lo cambia al presionar «Aplicar» con un rango válido;
 *   si no lo es, muestra el error y no toca el periodo (no se consulta al
 *   servidor).
 */
export function PanelDeReportes({ children }: { children: ReactNode }) {
  const ruta = usePathname();
  const router = useRouter();

  // Lo que muestra el selector: la opción y las fechas que se están escribiendo.
  const [opcion, setOpcion] = useState<PeriodoReporte>("ultimo-mes");
  const [desde, setDesde] = useState("");
  const [hasta, setHasta] = useState("");
  const [error, setError] = useState<string>();
  // Lo que ven las secciones: el último periodo válido.
  const [periodo, setPeriodo] = useState<PeriodoAplicado>(PERIODO_INICIAL);

  function alCambiarOpcion(nueva: PeriodoReporte) {
    setOpcion(nueva);
    setError(undefined);
    if (nueva !== "rango") setPeriodo(periodoFijo(nueva));
  }

  function alAplicar() {
    const mensaje = validarRango(desde, hasta);
    setError(mensaje ?? undefined);
    if (!mensaje) setPeriodo({ periodo: "RANGO", desde: desde.trim(), hasta: hasta.trim() });
  }

  const activa = SECCIONES_REPORTES.find((seccion) => seccion.ruta === ruta);

  return (
    <ProveedorDePeriodo periodo={periodo}>
      <SelectorDePeriodo
        periodo={opcion}
        onCambiarPeriodo={alCambiarOpcion}
        desde={desde}
        hasta={hasta}
        onCambiarDesde={setDesde}
        onCambiarHasta={setHasta}
        onAplicar={alAplicar}
        error={error}
      />
      {/* En móvil las pestañas pasan a una segunda fila, como en el diseño. */}
      <Pestanas etiqueta="Secciones del panel de reportes" className="flex-wrap gap-y-0">
        {SECCIONES_REPORTES.map((seccion) => (
          <Pestana
            key={seccion.ruta}
            id={idPestana(seccion.ruta)}
            panel={ID_PANEL}
            activa={seccion === activa}
            onClick={() => seccion !== activa && router.push(seccion.ruta)}
          >
            {seccion.texto}
          </Pestana>
        ))}
      </Pestanas>
      <PanelDePestana
        id={ID_PANEL}
        pestana={idPestana(activa?.ruta ?? SECCIONES_REPORTES[0].ruta)}
        activo
        className="flex flex-col gap-espacio-5 outline-none"
      >
        {children}
      </PanelDePestana>
    </ProveedorDePeriodo>
  );
}
