"use client";

import { useState } from "react";
import { Tabla, TablaCelda, TablaEncabezado } from "@/components/ui";
import { formatearTasa } from "@/lib/reportes/formato";
import { MarcoDeReporte } from "./marco-de-reporte";
import { ordenarPorTasa, type BienOcupacion, type SentidoOrden } from "./orden-ocupacion";
import { useReporte } from "./use-reporte";

/** Respuesta de `GET /reportes/ocupacion` (solo lo que usa la pantalla). */
export type OcupacionResponse = {
  periodo: { desde: string; hasta: string };
  totalBienes: number;
  bienes: BienOcupacion[];
};

/**
 * Sección «Ocupación» del panel de reportes (FE-24.1): días disponibles, días
 * ocupados y tasa de cada bien. El encabezado «Tasa de ocupación» alterna el
 * orden (de mayor a menor por defecto) en el cliente, sin volver a consultar,
 * y el orden elegido se conserva al cambiar de periodo.
 */
export function SeccionOcupacion() {
  const estado = useReporte<OcupacionResponse>("ocupacion");
  const [sentido, setSentido] = useState<SentidoOrden>("descendente");

  return (
    <MarcoDeReporte estado={estado} sinBienes={(datos) => datos.bienes.length === 0}>
      {(datos) => (
        <>
          <Tabla>
            <thead>
              <tr>
                <TablaEncabezado>Bien</TablaEncabezado>
                <TablaEncabezado alineacion="derecha">Días disponibles</TablaEncabezado>
                <TablaEncabezado alineacion="derecha">Días ocupados</TablaEncabezado>
                <TablaEncabezado
                  alineacion="derecha"
                  orden={sentido}
                  onOrdenar={() =>
                    setSentido((actual) => (actual === "descendente" ? "ascendente" : "descendente"))
                  }
                >
                  Tasa de ocupación
                </TablaEncabezado>
              </tr>
            </thead>
            <tbody>
              {ordenarPorTasa(datos.bienes, sentido).map((bien) => (
                <tr key={bien.bienId}>
                  <TablaCelda className="max-md:whitespace-nowrap">{bien.titulo}</TablaCelda>
                  <TablaCelda alineacion="derecha">{bien.diasDisponibles}</TablaCelda>
                  <TablaCelda alineacion="derecha">{bien.diasOcupados}</TablaCelda>
                  <TablaCelda
                    alineacion="derecha"
                    enfasis={bien.tasaOcupacion === null ? "atenuada" : "normal"}
                  >
                    {formatearTasa(bien.tasaOcupacion)}
                  </TablaCelda>
                </tr>
              ))}
            </tbody>
          </Tabla>
          <p className="texto-cuerpo-pequeno text-texto-secundario">
            Tasa = días ocupados ÷ días disponibles × 100. Los días bloqueados no cuentan como
            disponibles. «Sin días disponibles» va siempre al final.
          </p>
        </>
      )}
    </MarcoDeReporte>
  );
}
