import { render, screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { ProveedorDePeriodo } from "@/components/reportes/periodo-compartido";
import { SeccionIngresos, type IngresosResponse } from "@/components/reportes/seccion-ingresos";
import type { PeriodoAplicado } from "@/lib/periodo-reporte";

const { irASesionVencida } = vi.hoisted(() => ({ irASesionVencida: vi.fn() }));
vi.mock("@/lib/reportes/sesion-vencida", () => ({ irASesionVencida }));

const fetchFalso = vi.fn();

const RESPUESTA: IngresosResponse = {
  periodo: { desde: "2026-10-17", hasta: "2026-11-15" },
  totalIngresos: 1721,
  totalDepositoRetenido: 65,
  totalBienes: 3,
  bienes: [
    { bienId: "1", titulo: "Salón de eventos Las Palmas", ingresos: 1250, depositoRetenido: 50 },
    { bienId: "2", titulo: "Cámara Canon EOS", ingresos: 471, depositoRetenido: 15 },
    { bienId: "3", titulo: "Proyector Epson 4K", ingresos: 0, depositoRetenido: 0 },
  ],
};

const json = (cuerpo: unknown, status = 200) =>
  new Response(JSON.stringify(cuerpo), { status });

function montar(periodo: PeriodoAplicado = { periodo: "ULTIMO_MES" }) {
  const vista = (p: PeriodoAplicado) => (
    <ProveedorDePeriodo periodo={p}>
      <SeccionIngresos />
    </ProveedorDePeriodo>
  );
  const resultado = render(vista(periodo));
  return { ...resultado, cambiarPeriodo: (p: PeriodoAplicado) => resultado.rerender(vista(p)) };
}

const filas = () => within(screen.getByRole("table")).getAllByRole("row").slice(1);
const celdas = (fila: HTMLElement) =>
  within(fila).getAllByRole("cell").map((celda) => celda.textContent);

beforeEach(() => vi.stubGlobal("fetch", fetchFalso));
afterEach(() => {
  vi.unstubAllGlobals();
  fetchFalso.mockReset();
  irASesionVencida.mockReset();
});

describe("SeccionIngresos", () => {
  it("consulta al abrir y muestra la tabla con la fila Total", async () => {
    fetchFalso.mockResolvedValue(json(RESPUESTA));
    montar();

    expect(await screen.findByText("Salón de eventos Las Palmas")).toBeInTheDocument();
    expect(String(fetchFalso.mock.calls[0][0])).toBe("/api/reportes/ingresos?periodo=ULTIMO_MES");
    expect(celdas(filas()[0])).toEqual(["Salón de eventos Las Palmas", "$1,250.00", "$50.00"]);
    expect(celdas(filas()[1])).toEqual(["Cámara Canon EOS", "$471.00", "$15.00"]);
    expect(celdas(filas()[3])).toEqual(["Total", "$1,721.00", "$65.00"]);
    expect(screen.getByRole("columnheader", { name: "Depósito retenido" })).toBeInTheDocument();
  });

  it("muestra un valor 0.00 como $0.00", async () => {
    fetchFalso.mockResolvedValue(json(RESPUESTA));
    montar();
    await screen.findByText("Proyector Epson 4K");
    expect(celdas(filas()[2])).toEqual(["Proyector Epson 4K", "$0.00", "$0.00"]);
  });

  it("el depósito retenido no se suma al ingreso", async () => {
    fetchFalso.mockResolvedValue(json(RESPUESTA));
    montar();
    await screen.findByText("Ingreso total");
    expect(screen.getAllByText("$1,721.00").length).toBeGreaterThan(0);
    expect(screen.getAllByText("$65.00").length).toBeGreaterThan(0);
    expect(screen.queryByText("$1,786.00")).not.toBeInTheDocument();
  });

  it("sin bienes muestra «Aún no tienes bienes publicados.»", async () => {
    fetchFalso.mockResolvedValue(
      json({ ...RESPUESTA, totalIngresos: 0, totalDepositoRetenido: 0, totalBienes: 0, bienes: [] }),
    );
    montar();
    expect(await screen.findByText("Aún no tienes bienes publicados.")).toBeInTheDocument();
    expect(screen.queryByRole("table")).not.toBeInTheDocument();
  });

  it("con 400 muestra el texto del servidor", async () => {
    fetchFalso.mockResolvedValue(
      json({ message: "El rango no puede ser mayor a 365 días." }, 400),
    );
    montar();
    expect(await screen.findByRole("alert")).toHaveTextContent(
      "El rango no puede ser mayor a 365 días.",
    );
  });

  it("con 403 muestra «No tienes acceso a este panel.»", async () => {
    fetchFalso.mockResolvedValue(json({ message: "Forbidden" }, 403));
    montar();
    expect(await screen.findByRole("alert")).toHaveTextContent("No tienes acceso a este panel.");
    expect(screen.queryByRole("button", { name: "Reintentar" })).not.toBeInTheDocument();
  });

  it("con 500 o red caída muestra el mensaje y «Reintentar» que vuelve a consultar", async () => {
    fetchFalso.mockResolvedValueOnce(json({ message: "boom" }, 500));
    montar();
    expect(await screen.findByRole("alert")).toHaveTextContent(
      "No pudimos cargar el reporte. Intenta de nuevo.",
    );

    fetchFalso.mockResolvedValueOnce(json(RESPUESTA));
    await userEvent.click(screen.getByRole("button", { name: "Reintentar" }));

    expect(await screen.findByText("Salón de eventos Las Palmas")).toBeInTheDocument();
    expect(screen.queryByRole("alert")).not.toBeInTheDocument();
    expect(fetchFalso).toHaveBeenCalledTimes(2);
  });

  it("con una caída de red conserva la tabla anterior y avisa encima", async () => {
    fetchFalso.mockResolvedValueOnce(json(RESPUESTA));
    const { cambiarPeriodo } = montar();
    await screen.findByText("Salón de eventos Las Palmas");

    fetchFalso.mockRejectedValueOnce(new TypeError("fetch failed"));
    cambiarPeriodo({ periodo: "ULTIMOS_3_MESES" });

    expect(await screen.findByRole("alert")).toHaveTextContent(
      "No pudimos cargar el reporte. Intenta de nuevo.",
    );
    expect(screen.getByText("Salón de eventos Las Palmas")).toBeInTheDocument();
    expect(celdas(filas()[3])).toEqual(["Total", "$1,721.00", "$65.00"]);
  });

  it("mientras carga un periodo nuevo atenúa la tabla anterior", async () => {
    fetchFalso.mockResolvedValueOnce(json(RESPUESTA));
    const { cambiarPeriodo } = montar();
    await screen.findByText("Salón de eventos Las Palmas");

    fetchFalso.mockReturnValueOnce(new Promise(() => {}));
    cambiarPeriodo({ periodo: "ULTIMO_ANIO" });

    expect(await screen.findByText("Actualizando el reporte…")).toBeInTheDocument();
    expect(screen.getByText("Salón de eventos Las Palmas")).toBeInTheDocument();
    expect(screen.getByRole("table").closest("[aria-busy]")).toHaveAttribute("aria-busy", "true");
  });

  it("al cambiar el periodo dos veces seguidas muestra el del último", async () => {
    let resolverPrimera: (respuesta: Response) => void = () => {};
    fetchFalso.mockResolvedValueOnce(json(RESPUESTA));
    const { cambiarPeriodo } = montar();
    await screen.findByText("Salón de eventos Las Palmas");

    fetchFalso.mockReturnValueOnce(new Promise<Response>((r) => (resolverPrimera = r)));
    cambiarPeriodo({ periodo: "ULTIMOS_3_MESES" });
    fetchFalso.mockResolvedValueOnce(
      json({
        ...RESPUESTA,
        totalIngresos: 90,
        totalDepositoRetenido: 0,
        bienes: [{ bienId: "9", titulo: "Bien del último periodo", ingresos: 90, depositoRetenido: 0 }],
      }),
    );
    cambiarPeriodo({ periodo: "ULTIMO_ANIO" });

    expect(await screen.findByText("Bien del último periodo")).toBeInTheDocument();
    // La respuesta tardía del periodo anterior se descarta.
    resolverPrimera(json(RESPUESTA));
    await Promise.resolve();
    expect(screen.queryByText("Salón de eventos Las Palmas")).not.toBeInTheDocument();
    expect(String(fetchFalso.mock.calls[2][0])).toBe("/api/reportes/ingresos?periodo=ULTIMO_ANIO");
    expect(fetchFalso.mock.calls[1][1].signal.aborted).toBe(true);
  });

  it("con un rango propio consulta con desde y hasta", async () => {
    fetchFalso.mockResolvedValue(json(RESPUESTA));
    montar({ periodo: "RANGO", desde: "2026-11-01", hasta: "2026-11-15" });
    await screen.findByText("Salón de eventos Las Palmas");
    expect(String(fetchFalso.mock.calls[0][0])).toBe(
      "/api/reportes/ingresos?periodo=RANGO&desde=2026-11-01&hasta=2026-11-15",
    );
  });

  it("con 401 lleva a la sesión vencida", async () => {
    fetchFalso.mockResolvedValue(json({ message: "Unauthorized" }, 401));
    montar();
    await vi.waitFor(() => expect(irASesionVencida).toHaveBeenCalledTimes(1));
    expect(screen.queryByRole("alert")).not.toBeInTheDocument();
  });
});
