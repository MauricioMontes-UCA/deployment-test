import { render, screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { ProveedorDePeriodo } from "@/components/reportes/periodo-compartido";
import { SeccionResumen, type ResumenResponse } from "@/components/reportes/seccion-resumen";
import type { PeriodoAplicado } from "@/lib/periodo-reporte";

vi.mock("@/lib/reportes/sesion-vencida", () => ({ irASesionVencida: vi.fn() }));

const fetchFalso = vi.fn();

const RESPUESTA: ResumenResponse = {
  periodo: { desde: "2026-10-17", hasta: "2026-11-15" },
  escalaMaxima: 5,
  totalBienes: 4,
  bienes: [
    { bienId: "1", titulo: "Mesa de sonido", ingresos: 0, tasaOcupacion: 100, calificacionPromedio: 3, totalResenas: 1 },
    { bienId: "2", titulo: "Proyector 4K", ingresos: 0, tasaOcupacion: 0, calificacionPromedio: null, totalResenas: 0 },
    { bienId: "3", titulo: "Salón de eventos", ingresos: 1250, tasaOcupacion: 75.6, calificacionPromedio: 4.5, totalResenas: 12 },
    { bienId: "4", titulo: "Taladro industrial", ingresos: 96, tasaOcupacion: null, calificacionPromedio: null, totalResenas: 0 },
  ],
};

const json = (cuerpo: unknown, status = 200) => new Response(JSON.stringify(cuerpo), { status });

function montar(periodo: PeriodoAplicado = { periodo: "ULTIMO_MES" }) {
  const vista = (p: PeriodoAplicado) => (
    <ProveedorDePeriodo periodo={p}>
      <SeccionResumen />
    </ProveedorDePeriodo>
  );
  const resultado = render(vista(periodo));
  return { ...resultado, cambiarPeriodo: (p: PeriodoAplicado) => resultado.rerender(vista(p)) };
}

const filas = () => within(screen.getByRole("table")).getAllByRole("row").slice(1);
const celdas = (fila: HTMLElement) => within(fila).getAllByRole("cell").map((c) => c.textContent);

beforeEach(() => vi.stubGlobal("fetch", fetchFalso));
afterEach(() => {
  vi.unstubAllGlobals();
  fetchFalso.mockReset();
});

describe("SeccionResumen", () => {
  it("consulta el resumen con el periodo compartido y muestra una fila por bien con las cuatro columnas", async () => {
    fetchFalso.mockResolvedValue(json(RESPUESTA));
    montar({ periodo: "RANGO", desde: "2026-10-17", hasta: "2026-11-15" });

    await screen.findByText("Mesa de sonido");
    expect(String(fetchFalso.mock.calls[0][0])).toBe(
      "/api/reportes/resumen?periodo=RANGO&desde=2026-10-17&hasta=2026-11-15",
    );
    expect(
      screen.getAllByRole("columnheader").map((encabezado) => encabezado.textContent),
    ).toEqual(["Bien", "Ingresos", "Tasa de ocupación", "Calificación promedio"]);
    expect(filas()).toHaveLength(4);
    expect(celdas(filas()[0])).toEqual(["Mesa de sonido", "$0.00", "100.0 %", "3.0 / 5 (1 reseña)"]);
    expect(celdas(filas()[2])).toEqual(["Salón de eventos", "$1,250.00", "75.6 %", "4.5 / 5 (12 reseñas)"]);
  });

  it("muestra el periodo una sola vez y no tiene otro selector de periodo", async () => {
    fetchFalso.mockResolvedValue(json(RESPUESTA));
    montar();
    expect(await screen.findByText("Periodo: 2026-10-17 a 2026-11-15")).toBeInTheDocument();
    expect(screen.queryByRole("combobox")).not.toBeInTheDocument();
  });

  it("muestra los valores nulos como «Sin días disponibles» y «Sin calificaciones»", async () => {
    fetchFalso.mockResolvedValue(json(RESPUESTA));
    montar();
    await screen.findByText("Taladro industrial");

    expect(celdas(filas()[1])).toEqual(["Proyector 4K", "$0.00", "0.0 %", "Sin calificaciones"]);
    expect(celdas(filas()[3])).toEqual(["Taladro industrial", "$96.00", "Sin días disponibles", "Sin calificaciones"]);
  });

  it("con un error conserva la última tabla exitosa y muestra el mensaje encima", async () => {
    fetchFalso.mockResolvedValueOnce(json(RESPUESTA));
    const { cambiarPeriodo } = montar();
    await screen.findByText("Mesa de sonido");

    fetchFalso.mockResolvedValueOnce(
      json({ message: "El rango no puede ser mayor a 365 días." }, 400),
    );
    cambiarPeriodo({ periodo: "RANGO", desde: "2025-01-01", hasta: "2026-11-15" });

    expect(await screen.findByRole("alert")).toHaveTextContent(
      "El rango no puede ser mayor a 365 días.",
    );
    expect(screen.getByRole("table")).toBeInTheDocument();
    expect(filas()).toHaveLength(4);
    expect(screen.getByText("Salón de eventos")).toBeInTheDocument();
  });

  it("con red o 500 conserva la tabla, avisa y permite reintentar", async () => {
    fetchFalso.mockResolvedValueOnce(json(RESPUESTA));
    const { cambiarPeriodo } = montar();
    await screen.findByText("Mesa de sonido");

    fetchFalso.mockRejectedValueOnce(new TypeError("fetch failed"));
    cambiarPeriodo({ periodo: "ULTIMO_ANIO" });
    expect(await screen.findByRole("alert")).toHaveTextContent(
      "No pudimos cargar el reporte. Intenta de nuevo.",
    );
    expect(screen.getByText("Mesa de sonido")).toBeInTheDocument();

    fetchFalso.mockResolvedValueOnce(json({ ...RESPUESTA, bienes: [RESPUESTA.bienes[2]] }));
    await userEvent.click(screen.getByRole("button", { name: "Reintentar" }));
    await vi.waitFor(() => expect(screen.queryByRole("alert")).not.toBeInTheDocument());
    expect(filas()).toHaveLength(1);
  });

  it("sin bienes muestra «Aún no tienes bienes publicados.»", async () => {
    fetchFalso.mockResolvedValue(json({ ...RESPUESTA, totalBienes: 0, bienes: [] }));
    montar();
    expect(await screen.findByText("Aún no tienes bienes publicados.")).toBeInTheDocument();
    expect(screen.queryByRole("table")).not.toBeInTheDocument();
  });

  it("con 403 muestra «No tienes acceso a este panel.»", async () => {
    fetchFalso.mockResolvedValue(json({ message: "Forbidden" }, 403));
    montar();
    expect(await screen.findByRole("alert")).toHaveTextContent("No tienes acceso a este panel.");
  });

  it("mientras carga un periodo nuevo atenúa la tabla anterior", async () => {
    fetchFalso.mockResolvedValueOnce(json(RESPUESTA));
    const { cambiarPeriodo } = montar();
    await screen.findByText("Mesa de sonido");

    fetchFalso.mockReturnValueOnce(new Promise(() => {}));
    cambiarPeriodo({ periodo: "ULTIMOS_3_MESES" });

    expect(await screen.findByText("Actualizando el reporte…")).toBeInTheDocument();
    expect(screen.getByRole("table").closest("[aria-busy]")).toHaveAttribute("aria-busy", "true");
  });
});
