import { render, screen, within } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { ProveedorDePeriodo } from "@/components/reportes/periodo-compartido";
import {
  SeccionCalificaciones,
  type CalificacionesResponse,
} from "@/components/reportes/seccion-calificaciones";

vi.mock("@/lib/reportes/sesion-vencida", () => ({ irASesionVencida: vi.fn() }));

const fetchFalso = vi.fn();

const RESPUESTA: CalificacionesResponse = {
  periodo: { desde: "2026-10-17", hasta: "2026-11-15" },
  escalaMaxima: 5,
  totalBienes: 4,
  bienes: [
    { bienId: "1", titulo: "Mesa de sonido", promedio: 3, totalResenas: 1 },
    { bienId: "2", titulo: "Salón de eventos", promedio: 4.5, totalResenas: 2 },
    { bienId: "3", titulo: "Proyector 4K", promedio: null, totalResenas: 0 },
    { bienId: "4", titulo: "Taladro industrial", promedio: null, totalResenas: 0 },
  ],
};

const json = (cuerpo: unknown, status = 200) => new Response(JSON.stringify(cuerpo), { status });

function montar() {
  return render(
    <ProveedorDePeriodo periodo={{ periodo: "ULTIMOS_3_MESES" }}>
      <SeccionCalificaciones />
    </ProveedorDePeriodo>,
  );
}

const filas = () => within(screen.getByRole("table")).getAllByRole("row").slice(1);
const celdas = (fila: HTMLElement) => within(fila).getAllByRole("cell").map((c) => c.textContent);

beforeEach(() => vi.stubGlobal("fetch", fetchFalso));
afterEach(() => {
  vi.unstubAllGlobals();
  fetchFalso.mockReset();
});

describe("SeccionCalificaciones", () => {
  it("consulta con el periodo y muestra el promedio con un decimal y las reseñas, en el orden del servicio", async () => {
    fetchFalso.mockResolvedValue(json(RESPUESTA));
    montar();

    await screen.findByText("Mesa de sonido");
    expect(String(fetchFalso.mock.calls[0][0])).toBe("/api/reportes/calificaciones?periodo=ULTIMOS_3_MESES");
    expect(celdas(filas()[0])).toEqual(["Mesa de sonido", "3.0 / 5", "1 reseña"]);
    expect(celdas(filas()[1])).toEqual(["Salón de eventos", "4.5 / 5", "2 reseñas"]);
  });

  it("un promedio null dice «Sin calificaciones» y nunca 0", async () => {
    fetchFalso.mockResolvedValue(json(RESPUESTA));
    montar();
    await screen.findByText("Proyector 4K");

    expect(celdas(filas()[2])).toEqual(["Proyector 4K", "Sin calificaciones", "0 reseñas"]);
    expect(screen.getAllByText("Sin calificaciones")).toHaveLength(2);
    expect(screen.queryByText(/^0(\.0)? \/ 5$/)).not.toBeInTheDocument();
  });

  it("usa la escala máxima de la respuesta", async () => {
    fetchFalso.mockResolvedValue(
      json({ ...RESPUESTA, escalaMaxima: 10, bienes: [RESPUESTA.bienes[1]] }),
    );
    montar();
    expect(await screen.findByText("4.5 / 10")).toBeInTheDocument();
  });

  it("con 1 reseña dice «1 reseña» y con 2 o más «N reseñas»", async () => {
    fetchFalso.mockResolvedValue(
      json({
        ...RESPUESTA,
        bienes: [
          { bienId: "a", titulo: "Uno", promedio: 5, totalResenas: 1 },
          { bienId: "b", titulo: "Dos", promedio: 4, totalResenas: 2 },
          { bienId: "c", titulo: "Doce", promedio: 4.2, totalResenas: 12 },
        ],
      }),
    );
    montar();
    await screen.findByText("Uno");
    expect(celdas(filas()[0])[2]).toBe("1 reseña");
    expect(celdas(filas()[1])[2]).toBe("2 reseñas");
    expect(celdas(filas()[2])[2]).toBe("12 reseñas");
  });

  it("sin bienes muestra «Aún no tienes bienes publicados.»", async () => {
    fetchFalso.mockResolvedValue(json({ ...RESPUESTA, totalBienes: 0, bienes: [] }));
    montar();
    expect(await screen.findByText("Aún no tienes bienes publicados.")).toBeInTheDocument();
    expect(screen.queryByRole("table")).not.toBeInTheDocument();
  });

  it.each([
    ["400", json({ message: "El rango no puede ser mayor a 365 días." }, 400), "El rango no puede ser mayor a 365 días."],
    ["403", json({ message: "Forbidden" }, 403), "No tienes acceso a este panel."],
    ["500", json({ message: "boom" }, 500), "No pudimos cargar el reporte. Intenta de nuevo."],
  ])("con %s muestra el mensaje definido", async (_caso, respuesta, mensaje) => {
    fetchFalso.mockResolvedValue(respuesta);
    montar();
    expect(await screen.findByRole("alert")).toHaveTextContent(mensaje);
  });

  it("con una caída de red muestra el mensaje con «Reintentar»", async () => {
    fetchFalso.mockRejectedValueOnce(new TypeError("fetch failed"));
    montar();
    expect(await screen.findByRole("alert")).toHaveTextContent(
      "No pudimos cargar el reporte. Intenta de nuevo.",
    );
    expect(screen.getByRole("button", { name: "Reintentar" })).toBeInTheDocument();
  });
});
