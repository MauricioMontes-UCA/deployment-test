import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { PanelDeReportes } from "@/components/reportes/panel-de-reportes";
import { usePeriodoReporte } from "@/components/reportes/periodo-compartido";
import { consultaDePeriodo } from "@/lib/periodo-reporte";

const { navegacion } = vi.hoisted(() => ({
  navegacion: { ruta: "/reportes/ingresos", push: vi.fn() },
}));

vi.mock("next/navigation", () => ({
  usePathname: () => navegacion.ruta,
  useRouter: () => ({ push: navegacion.push }),
}));

/** Lo que recibiría una sección: el periodo vigente como consulta a la API. */
function SeccionDePrueba() {
  return <output aria-label="Periodo vigente">{consultaDePeriodo(usePeriodoReporte()).toString()}</output>;
}

const periodoVigente = () => screen.getByRole("status", { name: "Periodo vigente" });

function montar() {
  return render(
    <PanelDeReportes>
      <SeccionDePrueba />
    </PanelDeReportes>,
  );
}

async function elegir(opcion: string) {
  await userEvent.click(screen.getByRole("combobox", { name: "Periodo" }));
  await userEvent.click(screen.getByRole("option", { name: opcion }));
}

async function aplicarRango(desde: string, hasta: string) {
  await elegir("Rango de fechas");
  if (desde) await userEvent.type(screen.getByRole("textbox", { name: "Desde" }), desde);
  if (hasta) await userEvent.type(screen.getByRole("textbox", { name: "Hasta" }), hasta);
  await userEvent.click(screen.getByRole("button", { name: "Aplicar" }));
}

beforeEach(() => {
  navegacion.ruta = "/reportes/ingresos";
  navegacion.push.mockReset();
});

describe("PanelDeReportes · selector de periodo", () => {
  it("empieza en «Último mes (30 días)»", () => {
    montar();
    expect(screen.getByRole("combobox", { name: "Periodo" })).toHaveTextContent("Último mes (30 días)");
    expect(periodoVigente()).toHaveTextContent("periodo=ULTIMO_MES");
  });

  it.each([
    ["Últimos 3 meses (90 días)", "periodo=ULTIMOS_3_MESES"],
    ["Último año (365 días)", "periodo=ULTIMO_ANIO"],
  ])("«%s» entrega %s al elegirlo", async (opcion, consulta) => {
    montar();
    await elegir(opcion);
    expect(periodoVigente()).toHaveTextContent(consulta);
  });

  it("vuelve a «Último mes» después de otra opción", async () => {
    montar();
    await elegir("Último año (365 días)");
    await elegir("Último mes (30 días)");
    expect(periodoVigente()).toHaveTextContent("periodo=ULTIMO_MES");
  });

  it("«Rango de fechas» muestra Desde, Hasta y Aplicar, y no cambia el periodo hasta aplicar", async () => {
    montar();
    expect(screen.queryByRole("button", { name: "Aplicar" })).not.toBeInTheDocument();

    await elegir("Rango de fechas");
    expect(screen.getByRole("textbox", { name: "Desde" })).toHaveValue("");
    expect(screen.getByRole("textbox", { name: "Hasta" })).toHaveValue("");
    expect(screen.getByRole("button", { name: "Aplicar" })).toBeEnabled();
    expect(periodoVigente()).toHaveTextContent("periodo=ULTIMO_MES");
  });

  it("un rango válido entrega el periodo con sus fechas al aplicar", async () => {
    montar();
    await aplicarRango("2026-08-01", "2026-10-31");
    expect(screen.queryByRole("alert")).not.toBeInTheDocument();
    expect(periodoVigente()).toHaveTextContent("periodo=RANGO&desde=2026-08-01&hasta=2026-10-31");
  });

  it.each([
    ["2026-08-01", "2026-07-01", "La fecha final no puede ser anterior a la inicial."],
    ["2025-01-01", "2026-06-30", "El rango no puede ser mayor a 365 días."],
    ["2026-08-01", "", "Completa las fechas del rango."],
    ["", "2026-08-01", "Completa las fechas del rango."],
  ])(
    "desde «%s» y hasta «%s» muestra «%s» sin consultar al servidor",
    async (desde, hasta, mensaje) => {
      const fetchSimulado = vi.fn();
      vi.stubGlobal("fetch", fetchSimulado);
      montar();

      await aplicarRango(desde, hasta);

      expect(screen.getByRole("alert")).toHaveTextContent(mensaje);
      expect(screen.getByRole("textbox", { name: "Hasta" })).toHaveAttribute("aria-invalid", "true");
      // El periodo vigente sigue siendo el anterior y nadie llamó a la API.
      expect(periodoVigente()).toHaveTextContent("periodo=ULTIMO_MES");
      expect(fetchSimulado).not.toHaveBeenCalled();
      vi.unstubAllGlobals();
    },
  );

  it("el error desaparece al corregir el rango y aplicar", async () => {
    montar();
    await aplicarRango("2026-08-01", "2026-07-01");
    const hasta = screen.getByRole("textbox", { name: "Hasta" });
    await userEvent.clear(hasta);
    await userEvent.type(hasta, "2026-09-01");
    await userEvent.click(screen.getByRole("button", { name: "Aplicar" }));

    expect(screen.queryByRole("alert")).not.toBeInTheDocument();
    expect(periodoVigente()).toHaveTextContent("periodo=RANGO&desde=2026-08-01&hasta=2026-09-01");
  });
});

describe("PanelDeReportes · pestañas", () => {
  it("marca la sección de la ruta actual", () => {
    navegacion.ruta = "/reportes/calificaciones";
    montar();
    expect(screen.getByRole("tab", { name: "Calificaciones" })).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("tab", { name: "Ingresos" })).toHaveAttribute("aria-selected", "false");
    expect(screen.getByRole("tabpanel")).toHaveAttribute("aria-labelledby", "pestana-calificaciones");
  });

  it("navega a la sección de la pestaña", async () => {
    montar();
    await userEvent.click(screen.getByRole("tab", { name: "Ocupación" }));
    expect(navegacion.push).toHaveBeenCalledWith("/reportes/ocupacion");

    await userEvent.click(screen.getByRole("tab", { name: "Ingresos" }));
    expect(navegacion.push).toHaveBeenCalledTimes(1);
  });

  it("al cambiar de sección conserva el periodo elegido", async () => {
    const { rerender } = montar();
    await aplicarRango("2026-08-01", "2026-10-31");

    // Como el layout no se desmonta, cambiar de ruta solo cambia la página hija.
    navegacion.ruta = "/reportes/resumen";
    rerender(
      <PanelDeReportes>
        <SeccionDePrueba />
      </PanelDeReportes>,
    );

    expect(screen.getByRole("tab", { name: "Resumen" })).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("combobox", { name: "Periodo" })).toHaveTextContent("Rango de fechas");
    expect(periodoVigente()).toHaveTextContent("periodo=RANGO&desde=2026-08-01&hasta=2026-10-31");
  });
});
