import { render, screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { ProveedorDePeriodo } from "@/components/reportes/periodo-compartido";
import { SeccionResumen, type ResumenResponse } from "@/components/reportes/seccion-resumen";
import type { PeriodoAplicado } from "@/lib/periodo-reporte";

const { descargarArchivo, irASesionVencida } = vi.hoisted(() => ({
  descargarArchivo: vi.fn(),
  irASesionVencida: vi.fn(),
}));
vi.mock("@/lib/reportes/descarga", () => ({ descargarArchivo }));
vi.mock("@/lib/reportes/sesion-vencida", () => ({ irASesionVencida }));

const fetchFalso = vi.fn();

const RESPUESTA: ResumenResponse = {
  periodo: { desde: "2026-10-17", hasta: "2026-11-15" },
  escalaMaxima: 5,
  totalBienes: 1,
  bienes: [
    { bienId: "1", titulo: "Salón de eventos", ingresos: 250, tasaOcupacion: 50, calificacionPromedio: 4.5, totalResenas: 2 },
  ],
};

const json = (cuerpo: unknown, status = 200) => new Response(JSON.stringify(cuerpo), { status });
const csv = () =>
  new Response("Bien,Ingresos (USD)\r\n", {
    status: 200,
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": 'attachment; filename="resumen-desempeno_2026-10-17_2026-11-15.csv"',
    },
  });

/** Responde el resumen o el CSV según la URL; `exportar` define la respuesta del CSV. */
function responder(exportar: () => Promise<Response> | Response, resumen = () => json(RESPUESTA)) {
  fetchFalso.mockImplementation((url: string) =>
    String(url).startsWith("/api/reportes/resumen/exportar")
      ? Promise.resolve(exportar())
      : Promise.resolve(resumen()),
  );
}

function montar(periodo: PeriodoAplicado = { periodo: "ULTIMO_MES" }) {
  const vista = (p: PeriodoAplicado) => (
    <ProveedorDePeriodo periodo={p}>
      <SeccionResumen />
    </ProveedorDePeriodo>
  );
  const resultado = render(vista(periodo));
  return { ...resultado, cambiarPeriodo: (p: PeriodoAplicado) => resultado.rerender(vista(p)) };
}

const boton = () => screen.getByRole("button", { name: /Exportar CSV|Procesando/ });
const exportaciones = () =>
  fetchFalso.mock.calls.filter(([url]) => String(url).startsWith("/api/reportes/resumen/exportar"));

beforeEach(() => vi.stubGlobal("fetch", fetchFalso));
afterEach(() => {
  vi.unstubAllGlobals();
  fetchFalso.mockReset();
  descargarArchivo.mockReset();
  irASesionVencida.mockReset();
});

describe("Exportar CSV", () => {
  it("descarga el archivo del periodo en pantalla con el nombre del servidor", async () => {
    responder(csv);
    montar({ periodo: "RANGO", desde: "2026-10-17", hasta: "2026-11-15" });
    await screen.findByText("Salón de eventos");

    await userEvent.click(boton());

    await vi.waitFor(() => expect(descargarArchivo).toHaveBeenCalledTimes(1));
    expect(exportaciones()[0][0]).toBe(
      "/api/reportes/resumen/exportar?periodo=RANGO&desde=2026-10-17&hasta=2026-11-15",
    );
    const [archivo, nombre] = descargarArchivo.mock.calls[0];
    expect(nombre).toBe("resumen-desempeno_2026-10-17_2026-11-15.csv");
    expect(await (archivo as Blob).text()).toBe("Bien,Ingresos (USD)\r\n");
    expect(screen.queryByRole("alert")).not.toBeInTheDocument();
  });

  it("exporta el periodo elegido, no uno anterior", async () => {
    responder(csv);
    const { cambiarPeriodo } = montar({ periodo: "ULTIMO_MES" });
    await screen.findByText("Salón de eventos");

    cambiarPeriodo({ periodo: "ULTIMO_ANIO" });
    await vi.waitFor(() => expect(boton()).toBeEnabled());
    await userEvent.click(boton());

    await vi.waitFor(() => expect(exportaciones()).toHaveLength(1));
    expect(exportaciones()[0][0]).toBe("/api/reportes/resumen/exportar?periodo=ULTIMO_ANIO");
  });

  it("queda deshabilitado mientras la descarga está en curso y no permite un segundo clic", async () => {
    let terminar: (respuesta: Response) => void = () => {};
    responder(() => new Promise<Response>((r) => (terminar = r)) as unknown as Response);
    montar();
    await screen.findByText("Salón de eventos");

    await userEvent.click(boton());
    expect(await screen.findByRole("button", { name: /Procesando/ })).toBeDisabled();
    await userEvent.click(boton());
    expect(exportaciones()).toHaveLength(1);

    terminar(csv());
    await vi.waitFor(() => expect(descargarArchivo).toHaveBeenCalledTimes(1));
    expect(await screen.findByRole("button", { name: "Exportar CSV" })).toBeEnabled();
  });

  it("queda deshabilitado sin filas", async () => {
    responder(csv, () => json({ ...RESPUESTA, totalBienes: 0, bienes: [] }));
    montar();
    await screen.findByText("Aún no tienes bienes publicados.");
    expect(boton()).toBeDisabled();
  });

  it("queda deshabilitado si la última consulta falló, aunque se conserve la tabla", async () => {
    responder(csv);
    const { cambiarPeriodo } = montar();
    await screen.findByText("Salón de eventos");
    expect(boton()).toBeEnabled();

    responder(csv, () => json({ message: "El rango no puede ser mayor a 365 días." }, 400));
    cambiarPeriodo({ periodo: "RANGO", desde: "2025-01-01", hasta: "2026-11-15" });

    expect(await screen.findByRole("alert")).toBeInTheDocument();
    expect(screen.getByText("Salón de eventos")).toBeInTheDocument();
    expect(boton()).toBeDisabled();
  });

  it("queda deshabilitado mientras se actualiza la tabla", async () => {
    responder(csv);
    const { cambiarPeriodo } = montar();
    await screen.findByText("Salón de eventos");

    fetchFalso.mockImplementation(() => new Promise(() => {}));
    cambiarPeriodo({ periodo: "ULTIMOS_3_MESES" });

    expect(await screen.findByText("Actualizando el reporte…")).toBeInTheDocument();
    expect(boton()).toBeDisabled();
  });

  it.each([
    ["400", () => json({ message: "El rango no puede ser mayor a 365 días." }, 400), "El rango no puede ser mayor a 365 días."],
    ["403", () => json({ message: "Forbidden" }, 403), "No tienes acceso a este panel."],
    ["500", () => json({ message: "boom" }, 500), "No pudimos exportar el archivo. Intenta de nuevo."],
  ])("con %s muestra el mensaje definido y la tabla no cambia", async (_caso, respuesta, mensaje) => {
    responder(respuesta);
    montar();
    await screen.findByText("Salón de eventos");

    await userEvent.click(boton());

    expect(await screen.findByRole("alert")).toHaveTextContent(mensaje);
    expect(descargarArchivo).not.toHaveBeenCalled();
    expect(within(screen.getByRole("table")).getAllByRole("row")).toHaveLength(2);
    expect(screen.getByText("Salón de eventos")).toBeInTheDocument();
    // Tras el error se puede volver a intentar.
    expect(boton()).toBeEnabled();
  });

  it("con una caída de red muestra «No pudimos exportar el archivo. Intenta de nuevo.»", async () => {
    responder(() => Promise.reject(new TypeError("fetch failed")) as unknown as Response);
    montar();
    await screen.findByText("Salón de eventos");

    await userEvent.click(boton());

    expect(await screen.findByRole("alert")).toHaveTextContent(
      "No pudimos exportar el archivo. Intenta de nuevo.",
    );
    expect(descargarArchivo).not.toHaveBeenCalled();
  });

  it("con 401 lleva a la sesión vencida", async () => {
    responder(() => json({ message: "Unauthorized" }, 401));
    montar();
    await screen.findByText("Salón de eventos");
    await userEvent.click(boton());
    await vi.waitFor(() => expect(irASesionVencida).toHaveBeenCalledTimes(1));
  });

  it("el error de una exportación se quita al cambiar de periodo", async () => {
    responder(() => json({ message: "boom" }, 500));
    const { cambiarPeriodo } = montar();
    await screen.findByText("Salón de eventos");
    await userEvent.click(boton());
    expect(await screen.findByRole("alert")).toBeInTheDocument();

    cambiarPeriodo({ periodo: "ULTIMO_ANIO" });
    await vi.waitFor(() => expect(screen.queryByRole("alert")).not.toBeInTheDocument());
  });
});
