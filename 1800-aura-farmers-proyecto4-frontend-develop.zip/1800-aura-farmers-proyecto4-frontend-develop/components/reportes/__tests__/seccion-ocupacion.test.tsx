import { render, screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { ProveedorDePeriodo } from "@/components/reportes/periodo-compartido";
import {
  SeccionOcupacion,
  type OcupacionResponse,
} from "@/components/reportes/seccion-ocupacion";
import { ordenarPorTasa, type BienOcupacion } from "@/components/reportes/orden-ocupacion";
import type { PeriodoAplicado } from "@/lib/periodo-reporte";

vi.mock("@/lib/reportes/sesion-vencida", () => ({ irASesionVencida: vi.fn() }));

const fetchFalso = vi.fn();

const bien = (titulo: string, disponibles: number, ocupados: number, tasa: number | null) => ({
  bienId: titulo,
  titulo,
  diasDisponibles: disponibles,
  diasOcupados: ocupados,
  tasaOcupacion: tasa,
});

const RESPUESTA: OcupacionResponse = {
  periodo: { desde: "2026-10-17", hasta: "2026-11-15" },
  totalBienes: 4,
  bienes: [
    bien("Mesa de sonido", 30, 30, 100),
    bien("Salón de eventos", 20, 10, 50),
    bien("Proyector 4K", 30, 0, 0),
    bien("Taladro industrial", 0, 0, null),
  ],
};

const json = (cuerpo: unknown, status = 200) => new Response(JSON.stringify(cuerpo), { status });

function montar(periodo: PeriodoAplicado = { periodo: "ULTIMO_MES" }) {
  const vista = (p: PeriodoAplicado) => (
    <ProveedorDePeriodo periodo={p}>
      <SeccionOcupacion />
    </ProveedorDePeriodo>
  );
  const resultado = render(vista(periodo));
  return { ...resultado, cambiarPeriodo: (p: PeriodoAplicado) => resultado.rerender(vista(p)) };
}

const filas = () => within(screen.getByRole("table")).getAllByRole("row").slice(1);
const titulos = () => filas().map((fila) => within(fila).getAllByRole("cell")[0].textContent);
const encabezadoTasa = () => screen.getByRole("columnheader", { name: /Tasa de ocupación/ });

beforeEach(() => vi.stubGlobal("fetch", fetchFalso));
afterEach(() => {
  vi.unstubAllGlobals();
  fetchFalso.mockReset();
});

describe("ordenarPorTasa", () => {
  const bienes: BienOcupacion[] = [
    bien("B", 10, 5, 50),
    bien("A", 10, 5, 50),
    bien("Sin tasa 2", 0, 0, null),
    bien("C", 10, 9, 90),
    bien("Sin tasa 1", 0, 0, null),
    bien("D", 10, 0, 0),
  ];

  it("de mayor a menor deja los nulos al final y desempata por título", () => {
    expect(ordenarPorTasa(bienes, "descendente").map((b) => b.titulo)).toEqual([
      "C", "A", "B", "D", "Sin tasa 1", "Sin tasa 2",
    ]);
  });

  it("de menor a mayor también deja los nulos al final y desempata por título", () => {
    expect(ordenarPorTasa(bienes, "ascendente").map((b) => b.titulo)).toEqual([
      "D", "A", "B", "C", "Sin tasa 1", "Sin tasa 2",
    ]);
  });

  it("no modifica el arreglo original y compara los títulos en español", () => {
    const original = [bien("Zorro", 1, 1, 10), bien("árbol", 1, 1, 10)];
    expect(ordenarPorTasa(original, "descendente").map((b) => b.titulo)).toEqual(["árbol", "Zorro"]);
    expect(original.map((b) => b.titulo)).toEqual(["Zorro", "árbol"]);
  });
});

describe("SeccionOcupacion", () => {
  it("consulta al abrir y muestra días disponibles, ocupados y la tasa con un decimal", async () => {
    fetchFalso.mockResolvedValue(json(RESPUESTA));
    montar();

    await screen.findByText("Salón de eventos");
    expect(String(fetchFalso.mock.calls[0][0])).toBe("/api/reportes/ocupacion?periodo=ULTIMO_MES");
    const fila = filas().find((f) => within(f).queryByText("Salón de eventos"))!;
    expect(within(fila).getAllByRole("cell").map((c) => c.textContent)).toEqual([
      "Salón de eventos", "20", "10", "50.0 %",
    ]);
  });

  it("un bien sin tasa dice «Sin días disponibles» y queda al final", async () => {
    fetchFalso.mockResolvedValue(json(RESPUESTA));
    montar();
    await screen.findByText("Taladro industrial");
    expect(screen.getByText("Sin días disponibles")).toBeInTheDocument();
    expect(titulos()).toEqual(["Mesa de sonido", "Salón de eventos", "Proyector 4K", "Taladro industrial"]);
  });

  it("el encabezado de la tasa alterna el orden en los dos sentidos con aria-sort", async () => {
    fetchFalso.mockResolvedValue(json(RESPUESTA));
    montar();
    await screen.findByText("Taladro industrial");

    // Por defecto, de mayor a menor.
    expect(encabezadoTasa()).toHaveAttribute("aria-sort", "descending");

    await userEvent.click(within(encabezadoTasa()).getByRole("button"));
    expect(encabezadoTasa()).toHaveAttribute("aria-sort", "ascending");
    expect(titulos()).toEqual(["Proyector 4K", "Salón de eventos", "Mesa de sonido", "Taladro industrial"]);

    await userEvent.click(within(encabezadoTasa()).getByRole("button"));
    expect(encabezadoTasa()).toHaveAttribute("aria-sort", "descending");
    expect(titulos()).toEqual(["Mesa de sonido", "Salón de eventos", "Proyector 4K", "Taladro industrial"]);
    // Alternar el orden no vuelve a consultar.
    expect(fetchFalso).toHaveBeenCalledTimes(1);
  });

  it("conserva el orden elegido al cambiar de periodo", async () => {
    fetchFalso.mockResolvedValue(json(RESPUESTA));
    const { cambiarPeriodo } = montar();
    await screen.findByText("Taladro industrial");
    await userEvent.click(within(encabezadoTasa()).getByRole("button"));

    cambiarPeriodo({ periodo: "ULTIMO_ANIO" });
    await vi.waitFor(() => expect(fetchFalso).toHaveBeenCalledTimes(2));
    await vi.waitFor(() => expect(screen.queryByText("Actualizando el reporte…")).not.toBeInTheDocument());

    expect(String(fetchFalso.mock.calls[1][0])).toBe("/api/reportes/ocupacion?periodo=ULTIMO_ANIO");
    expect(encabezadoTasa()).toHaveAttribute("aria-sort", "ascending");
    expect(titulos()[0]).toBe("Proyector 4K");
  });

  it("sin bienes muestra «Aún no tienes bienes publicados.»", async () => {
    fetchFalso.mockResolvedValue(json({ ...RESPUESTA, totalBienes: 0, bienes: [] }));
    montar();
    expect(await screen.findByText("Aún no tienes bienes publicados.")).toBeInTheDocument();
    expect(screen.queryByRole("table")).not.toBeInTheDocument();
  });

  it.each([
    ["400", json({ message: "El rango no puede ser mayor a 365 días." }, 400), "El rango no puede ser mayor a 365 días."],
    ["403", json({ message: "Forbidden" }, 403), "No tienes acceso a este panel."],
    ["500", json({ message: "boom" }, 500), "No pudimos cargar el reporte. Intenta de nuevo."],
  ])("con %s muestra el mensaje definido", async (_caso, respuesta, mensaje) => {
    fetchFalso.mockResolvedValue(respuesta);
    montar();
    expect(await screen.findByRole("alert")).toHaveTextContent(mensaje);
  });

  it("con una caída de red muestra el mensaje con «Reintentar»", async () => {
    fetchFalso.mockRejectedValueOnce(new TypeError("fetch failed"));
    montar();
    expect(await screen.findByRole("alert")).toHaveTextContent(
      "No pudimos cargar el reporte. Intenta de nuevo.",
    );
    expect(screen.getByRole("button", { name: "Reintentar" })).toBeInTheDocument();
  });
});
