import { Alerta } from "@/components/ui";

/**
 * Contenido provisional de una sección del panel de reportes mientras su
 * historia (H23 a H26) no la conecta con su endpoint.
 */
export function SeccionPendiente({ seccion }: { seccion: string }) {
  return (
    <Alerta tono="info" titulo={`${seccion}: muy pronto`}>
      Esta sección todavía no está disponible. El periodo que elijas arriba se aplicará aquí.
    </Alerta>
  );
}
