import { fireEvent, render, screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, beforeEach, describe, expect, it, vi, type MockInstance } from "vitest";
import type { MensajeConversacion, ResultadoEnvioMensaje } from "@/lib/mensajes";
import { ConversacionPrevia } from "@/app/publicaciones/[bienId]/conversacion/conversacion-previa";
import { PanelDeConversacion } from "../panel-de-conversacion";

// El comportamiento común (validación, «enviando…», doble envío, errores,
// foco, teclado) ya lo cubren las pruebas de la consulta previa (FE-13.1),
// que usan este mismo panel. Aquí se prueba lo configurable.

const BLOQUEO = "La coordinación está disponible cuando la reserva está confirmada o en curso.";
const MARIANA = { id: "u2", nombreUsuario: "mariana_rivas" };
type Enviar = (contenido: string) => Promise<ResultadoEnvioMensaje>;

let errorDeConsola: MockInstance<typeof console.error>;
beforeEach(() => {
  errorDeConsola = vi.spyOn(console, "error");
});
afterEach(() => {
  expect(errorDeConsola).not.toHaveBeenCalled();
  errorDeConsola.mockRestore();
});

function renderizar({
  enviar = vi.fn<Enviar>(),
  bloqueos,
  mensajes = [],
}: { enviar?: Enviar; bloqueos?: Partial<Record<number, string>>; mensajes?: MensajeConversacion[] } = {}) {
  render(
    <PanelDeConversacion
      usuario={MARIANA}
      titulo={{ movil: "Coordinación con luis.perez", escritorio: "Mensajes sobre la entrega" }}
      vacio={{ titulo: "Aún no hay mensajes", mensaje: "Acuerda aquí la fecha, la hora y el lugar de la entrega." }}
      mensajesIniciales={mensajes}
      enviar={enviar}
      bloqueos={bloqueos}
    />,
  );
  return enviar;
}
const campo = () => screen.getByRole("textbox", { name: /Mensaje/ });
const boton = () => screen.getByRole("button", { name: /Enviar mensaje|Procesando/ });

describe("PanelDeConversacion", () => {
  it("usa los títulos de móvil y escritorio y los textos de vacío que recibe", () => {
    renderizar();
    const titulo = screen.getByRole("heading", { level: 2 });
    expect(within(titulo).getByText("Coordinación con luis.perez")).toHaveClass("lg:hidden");
    expect(within(titulo).getByText("Mensajes sobre la entrega")).toHaveClass("hidden", "lg:inline");
    expect(screen.getByText("Acuerda aquí la fecha, la hora y el lugar de la entrega.")).toBeInTheDocument();
  });

  it("un código de `bloqueos` (422): muestra su aviso, conserva el texto e impide nuevos envíos", async () => {
    const enviar = renderizar({ enviar: vi.fn<Enviar>(async () => ({ ok: false, status: 422 })), bloqueos: { 422: BLOQUEO } });
    fireEvent.change(campo(), { target: { value: "  El martes a las 8 🚚" } });
    await userEvent.click(boton());

    expect(await screen.findByRole("alert")).toHaveTextContent(BLOQUEO);
    expect(screen.queryByText("No se pudo enviar el mensaje")).not.toBeInTheDocument();
    expect(campo()).toHaveValue("  El martes a las 8 🚚");
    expect(campo()).toHaveAttribute("readonly");
    expect(boton()).toBeDisabled();
    expect(screen.queryByText(/enviando…/)).not.toBeInTheDocument();

    // Ni con clic ni con Enter en el formulario se vuelve a enviar.
    await userEvent.click(boton());
    fireEvent.submit(campo().closest("form")!);
    expect(enviar).toHaveBeenCalledTimes(1);
  });

  it("un código que no está en `bloqueos` usa el aviso genérico y deja reintentar", async () => {
    const enviar = renderizar({
      enviar: vi.fn<Enviar>().mockResolvedValueOnce({ ok: false, status: 500 }).mockResolvedValueOnce({ ok: false, status: 409 }),
      bloqueos: { 422: BLOQUEO },
    });
    fireEvent.change(campo(), { target: { value: "Hola" } });
    await userEvent.click(boton());
    expect(await screen.findByRole("alert")).toHaveTextContent(/^No se pudo enviar el mensaje$/);
    expect(boton()).toBeEnabled();
    await userEvent.click(boton());
    expect(enviar).toHaveBeenCalledTimes(2);
  });

  it("sin `bloqueos` (consulta previa), un 422 es un error genérico y se puede reintentar", async () => {
    renderizar({ enviar: vi.fn<Enviar>(async () => ({ ok: false, status: 422 })) });
    fireEvent.change(campo(), { target: { value: "Hola" } });
    await userEvent.click(boton());
    expect(await screen.findByRole("alert")).toHaveTextContent(/^No se pudo enviar el mensaje$/);
    expect(boton()).toBeEnabled();
    expect(campo()).not.toHaveAttribute("readonly");
  });

  it("regresión de FE-13.1: la consulta previa conserva sus títulos por ancho y su texto vacío", () => {
    render(<ConversacionPrevia usuario={MARIANA} arrendador="mariana_rivas" mensajesIniciales={[]} enviar={vi.fn<Enviar>()} />);
    const titulo = screen.getByRole("heading", { level: 2 });
    expect(within(titulo).getByText("Conversación con mariana_rivas")).toHaveClass("lg:hidden");
    expect(within(titulo).getByText("Mensajes")).toHaveClass("hidden", "lg:inline");
    expect(screen.getByText("Escribe tu primera pregunta sobre esta publicación.")).toBeInTheDocument();
  });

  it("muestra autor y fecha del historial; los propios a la derecha", () => {
    renderizar({
      mensajes: [
        { id: "m1", remitente: MARIANA, contenido: "Podemos el martes 24", creadoEn: "2026-11-20T15:10:00.000Z" },
        { id: "m2", remitente: { id: "u1", nombreUsuario: "luis.perez" }, contenido: "Me funciona", creadoEn: "2026-11-20T15:18:00.000Z" },
      ],
    });
    expect(screen.getByText("mariana_rivas · 20/11/2026 09:10").parentElement).toHaveClass("self-end");
    expect(screen.getByText("luis.perez · 20/11/2026 09:18").parentElement).toHaveClass("self-start");
  });
});
