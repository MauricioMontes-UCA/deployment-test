"use client";

import { unstable_rethrow } from "next/navigation";
import { useId, useRef, useState, useTransition, type FormEvent, type ReactNode } from "react";
import { Alerta, AreaDeTexto, Boton, Mensaje } from "@/components/ui";
import { unirClases } from "@/lib/clases";
import {
  LIMITE_MENSAJE,
  MENSAJE_ERROR_ENVIO,
  contarCaracteresMensaje,
  formatearFechaHora,
  validarMensaje,
  type MensajeConversacion,
  type ResultadoEnvioMensaje,
} from "@/lib/mensajes";

export type PanelDeConversacionProps = {
  /** Usuario de la sesión: sus mensajes van a la derecha. */
  usuario: { id: string; nombreUsuario: string };
  /** Título del panel: en móvil y desde `lg` (Figma usa uno distinto en cada ancho). */
  titulo: { movil: ReactNode; escritorio: ReactNode };
  /** Textos del historial vacío. */
  vacio: { titulo: string; mensaje: string };
  /** Historial en orden cronológico. */
  mensajesIniciales: MensajeConversacion[];
  /** Server action que envía el texto (con el id de la conversación o de la reserva ya aplicado). */
  enviar: (contenido: string) => Promise<ResultadoEnvioMensaje>;
  /**
   * Códigos del backend que cierran la conversación, con el aviso que se
   * muestra (por ejemplo, 422 en la coordinación cuando la reserva cambió de
   * estado). Al recibir uno, el texto se conserva y no se permiten más envíos.
   * Son datos y no una función, para poder pasarlos desde un server component.
   */
  bloqueos?: Partial<Record<number, string>>;
  className?: string;
};

/** Aviso tras un 201 cuya respuesta no se pudo leer: el mensaje se guardó, pero no se inventa. */
const MENSAJE_ENVIADO_SIN_DATOS = "Tu mensaje se envió. Recarga la página para verlo en el historial.";

/**
 * Panel de mensajes compartido por la consulta previa (FE-13.1) y la
 * coordinación por reserva (FE-14.1): historial, estado vacío y redacción.
 *
 * - Valida de 1 a 1000 caracteres por punto de código (`lib/mensajes.ts`).
 * - El mensaje en curso se muestra aparte, con «enviando…», y solo pasa al
 *   historial con los datos reales del 201.
 * - Si el envío falla, el texto se conserva para reintentar.
 * - Un candado síncrono evita el doble envío aunque se pulse dos veces antes
 *   de que React vuelva a pintar.
 * - Un 401 lleva a /sesion-vencida desde la server action (`redirect`).
 */
export function PanelDeConversacion({
  usuario,
  titulo,
  vacio,
  mensajesIniciales,
  enviar,
  bloqueos,
  className,
}: PanelDeConversacionProps) {
  const idCampo = useId();
  const idTitulo = useId();
  const [mensajes, setMensajes] = useState(mensajesIniciales);
  const [texto, setTexto] = useState("");
  const [intentado, setIntentado] = useState(false);
  const [pendiente, setPendiente] = useState<string | null>(null);
  const [errorEnvio, setErrorEnvio] = useState(false);
  const [avisoSinDatos, setAvisoSinDatos] = useState(false);
  const [bloqueo, setBloqueo] = useState<string | null>(null);
  const enviandoAhora = useRef(false);
  const [, startTransition] = useTransition();

  const errorTexto = validarMensaje(texto);
  // El vacío se avisa al intentar enviar; pasarse del límite, mientras se escribe.
  const errorVisible =
    errorTexto && (intentado || contarCaracteresMensaje(texto) > LIMITE_MENSAJE) ? errorTexto : undefined;
  const enviando = pendiente !== null;

  const enfocarCampo = () => document.getElementById(idCampo)?.focus();

  function alEnviar(evento: FormEvent<HTMLFormElement>) {
    evento.preventDefault();
    if (enviandoAhora.current || bloqueo !== null) return;
    setIntentado(true);
    if (errorTexto) {
      enfocarCampo();
      return;
    }

    // El texto va tal cual: sin recortar espacios ni saltos de línea.
    const contenido = texto;
    enviandoAhora.current = true;
    setPendiente(contenido);
    setErrorEnvio(false);
    setAvisoSinDatos(false);

    startTransition(async () => {
      let resultado: ResultadoEnvioMensaje;
      try {
        resultado = await enviar(contenido);
      } catch (excepcion) {
        // El redirect a /sesion-vencida (401) debe seguir su curso.
        unstable_rethrow(excepcion);
        resultado = { ok: false, status: null };
      }

      if (resultado.ok) {
        const { mensaje } = resultado;
        if (mensaje) setMensajes((anteriores) => [...anteriores, mensaje]);
        else setAvisoSinDatos(true);
        setTexto("");
        setIntentado(false);
      } else {
        const cierre = resultado.status !== null ? bloqueos?.[resultado.status] : undefined;
        if (cierre) setBloqueo(cierre);
        else setErrorEnvio(true);
      }
      setPendiente(null);
      enviandoAhora.current = false;
      enfocarCampo();
    });
  }

  const sinMensajes = mensajes.length === 0 && !enviando;

  return (
    <section
      aria-labelledby={idTitulo}
      className={unirClases("flex w-full min-w-0 flex-col border border-borde-default bg-fondo-superficie", className)}
    >
      <h2 id={idTitulo} className="texto-h4 border-b border-borde-sutil px-espacio-5 py-espacio-4 text-texto-primario">
        <span className="lg:hidden">{titulo.movil}</span>
        <span className="hidden lg:inline">{titulo.escritorio}</span>
      </h2>

      <div role="log" aria-label="Historial de mensajes" className="flex flex-col gap-espacio-3 p-espacio-5">
        {sinMensajes ? (
          <div className="flex flex-col items-center gap-espacio-2 py-10 text-center">
            <p className="texto-h4 text-texto-primario">{vacio.titulo}</p>
            <p className="texto-cuerpo text-texto-secundario">{vacio.mensaje}</p>
          </div>
        ) : (
          <>
            {mensajes.map((mensaje) => (
              <Mensaje
                key={mensaje.id}
                autor={mensaje.remitente.nombreUsuario}
                fecha={formatearFechaHora(mensaje.creadoEn)}
                propio={mensaje.remitente.id === usuario.id}
              >
                <p className="whitespace-pre-wrap">{mensaje.contenido}</p>
              </Mensaje>
            ))}
            {pendiente !== null && (
              <Mensaje autor={usuario.nombreUsuario} fecha="enviando…" propio className="opacity-70">
                <p className="whitespace-pre-wrap">{pendiente}</p>
              </Mensaje>
            )}
          </>
        )}
      </div>

      <form
        noValidate
        onSubmit={alEnviar}
        aria-busy={enviando || undefined}
        className="flex flex-col gap-espacio-3 border-t border-borde-sutil px-espacio-5 pt-espacio-4 pb-espacio-5"
      >
        {bloqueo !== null && <Alerta tono="error">{bloqueo}</Alerta>}
        {errorEnvio && <Alerta tono="error">{MENSAJE_ERROR_ENVIO}</Alerta>}
        {avisoSinDatos && <Alerta tono="info">{MENSAJE_ENVIADO_SIN_DATOS}</Alerta>}
        <AreaDeTexto
          id={idCampo}
          name="contenido"
          etiqueta="Mensaje"
          placeholder="Escribe tu mensaje…"
          value={texto}
          onChange={(evento) => setTexto(evento.target.value)}
          limite={LIMITE_MENSAJE}
          contarCaracteres={contarCaracteresMensaje}
          error={errorVisible}
          // Solo lectura y no deshabilitado: el foco se queda en el campo y el texto se puede copiar.
          readOnly={enviando || bloqueo !== null}
        />
        {/* Figma (30:460, 30:2 y 30:1088): a la derecha y con ancho automático en todos los tamaños. */}
        <Boton type="submit" icono="enviar" cargando={enviando} disabled={bloqueo !== null} className="self-end">
          Enviar mensaje
        </Boton>
      </form>
    </section>
  );
}
