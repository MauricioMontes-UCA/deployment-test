"use client";

import { useEffect, useState } from "react";
import { cerrarSesion } from "@/app/actions/auth";
import { Alerta, Boton, EstadoDePagina, LeyendaDeCalendario, MesDeCalendario } from "@/components/ui";
import {
  MENSAJE_RANGO_NO_DISPONIBLE,
  MESES_DE_VENTANA,
  esDisponibilidad,
  estadoDelDia,
  hoyEnElSalvador,
  mesDesplazado,
  mesesEntre,
  rangoEsValido,
  ultimoDiaDeVentana,
  type Disponibilidad,
} from "@/lib/disponibilidad";
import { unirClases } from "@/lib/clases";

export type ModoCalendario = "seleccion" | "gestion";

type CalendarioDeDisponibilidadProps = {
  bienId: string;
  /**
   * `seleccion`: el arrendatario elige las fechas de su reserva (H5, H6).
   * `gestion`: el arrendador elige fechas para bloquearlas (H7, FE-7.1).
   * La selección y las reglas son las mismas; cambia el texto de ayuda.
   */
  modo?: ModoCalendario;
  /**
   * Se llama con AAAA-MM-DD cuando el rango elegido es válido, y con
   * `(null, null)` cuando ese rango deja de estar vigente (por ejemplo, al
   * empezar una selección nueva). Así el padre puede deshabilitar su acción.
   */
  onRangoSeleccionado?: (inicio: string | null, fin: string | null) => void;
  /**
   * Al cambiar este número se vuelve a consultar la disponibilidad y se
   * descarta la selección. Úsalo tras crear o eliminar un bloqueo.
   */
  actualizacion?: number;
  /** Se llama con la disponibilidad cada vez que se carga correctamente. */
  onDisponibilidad?: (disponibilidad: Disponibilidad) => void;
  className?: string;
};

/** Por qué falló la carga: sesión vencida, bien inexistente u otro fallo (red, 5xx). */
type ErrorDeCarga = "sesion" | "no-encontrado" | "general";

type Resultado = {
  clave: string;
  disponibilidad: Disponibilidad | null;
  error: ErrorDeCarga | null;
};

const AYUDA: Record<ModoCalendario, string> = {
  seleccion: `Próximos ${MESES_DE_VENTANA} meses. Usa las flechas para cambiar de mes. Los días pasados, reservados y bloqueados no se pueden seleccionar.`,
  gestion: `Próximos ${MESES_DE_VENTANA} meses. Usa las flechas para cambiar de mes y elige el primer y el último día que quieres bloquear. Los días pasados, reservados y bloqueados no se pueden seleccionar.`,
};

function errorSegunEstado(estado: number): ErrorDeCarga {
  if (estado === 401) return "sesion";
  if (estado === 404) return "no-encontrado";
  return "general";
}

/**
 * Calendario de disponibilidad de un bien (FE-5.1): 12 meses desde hoy con el
 * estado de cada día según las reservas y bloqueos de la API. Primer clic =
 * inicio, segundo = fin. Si el rango incluye algún día no seleccionable se
 * descarta y se avisa. Un tercer clic empieza una selección nueva.
 */
export function CalendarioDeDisponibilidad({
  bienId,
  modo = "seleccion",
  onRangoSeleccionado,
  actualizacion = 0,
  onDisponibilidad,
  className,
}: CalendarioDeDisponibilidadProps) {
  // «Hoy» se fija al montar: el calendario no debe cambiar de ventana a media selección.
  const [hoy] = useState(() => hoyEnElSalvador());
  const ultimoDia = ultimoDiaDeVentana(hoy);
  // Último mes con días elegibles: 12 meses desde hoy terminan en el mes siguiente al de hoy, un año después.
  const ultimoDesplazamiento = mesesEntre(hoy, ultimoDia);

  const [intento, setIntento] = useState(0);
  const [resultado, setResultado] = useState<Resultado | null>(null);
  const [desplazamiento, setDesplazamiento] = useState(0);
  const [inicio, setInicio] = useState<string | null>(null);
  const [fin, setFin] = useState<string | null>(null);
  const [aviso, setAviso] = useState<string | null>(null);

  const [actualizacionVista, setActualizacionVista] = useState(actualizacion);
  if (actualizacionVista !== actualizacion) {
    // Datos nuevos: la selección anterior ya no corresponde a lo que se pinta.
    setActualizacionVista(actualizacion);
    setInicio(null);
    setFin(null);
    setAviso(null);
  }

  const clave = `${bienId}:${intento}:${actualizacion}`;
  // Mientras la respuesta guardada no sea la de esta consulta, se está cargando.
  const cargando = resultado?.clave !== clave;
  const disponibilidad = cargando ? null : resultado.disponibilidad;

  useEffect(() => {
    if (disponibilidad) onDisponibilidad?.(disponibilidad);
  }, [disponibilidad, onDisponibilidad]);

  useEffect(() => {
    const control = new AbortController();
    const consulta = new URLSearchParams({ desde: hoy, hasta: ultimoDia });
    fetch(`/api/bienes/${encodeURIComponent(bienId)}/disponibilidad?${consulta}`, {
      signal: control.signal,
      cache: "no-store",
    })
      .then(async (respuesta) => {
        if (!respuesta.ok) {
          setResultado({ clave, disponibilidad: null, error: errorSegunEstado(respuesta.status) });
          return;
        }
        const datos: unknown = await respuesta.json();
        setResultado(
          esDisponibilidad(datos)
            ? { clave, disponibilidad: datos, error: null }
            : { clave, disponibilidad: null, error: "general" },
        );
      })
      .catch((error: unknown) => {
        if ((error as Error).name === "AbortError") return;
        setResultado({ clave, disponibilidad: null, error: "general" });
      });
    return () => control.abort();
  }, [bienId, clave, hoy, ultimoDia]);

  function reintentar() {
    setInicio(null);
    setFin(null);
    setAviso(null);
    setIntento((valor) => valor + 1);
  }

  function seleccionarDia(fecha: string) {
    if (!disponibilidad) return;
    const contexto = { hoy, ultimoDia, disponibilidad };
    setAviso(null);

    // Sin inicio, o con un rango ya completo: se empieza una selección nueva.
    if (!inicio || fin) {
      // El rango que ya se había comunicado deja de estar vigente.
      if (fin) onRangoSeleccionado?.(null, null);
      setInicio(fecha);
      setFin(null);
      return;
    }
    // Un segundo clic anterior al inicio reemplaza el inicio.
    if (fecha < inicio) {
      setInicio(fecha);
      return;
    }
    if (!rangoEsValido(inicio, fecha, contexto)) {
      setInicio(null);
      setFin(null);
      setAviso(MENSAJE_RANGO_NO_DISPONIBLE);
      return;
    }
    setFin(fecha);
    onRangoSeleccionado?.(inicio, fecha);
  }

  if (cargando) {
    return (
      <div className={unirClases("flex flex-col gap-espacio-4", className)}>
        <p className="texto-cuerpo text-texto-secundario">{AYUDA[modo]}</p>
        <div
          role="status"
          aria-busy="true"
          aria-label="Cargando disponibilidad"
          className="flex h-[388px] w-full max-w-[366px] animate-pulse flex-col gap-espacio-3 border border-borde-default bg-fondo-superficie p-espacio-4"
        >
          <div className="h-5 w-1/2 self-center bg-fondo-sutil" />
          <div className="grid flex-1 grid-cols-7 gap-1">
            {Array.from({ length: 35 }, (_, indice) => (
              <div key={indice} className="bg-fondo-sutil" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!disponibilidad) {
    if (resultado?.error === "sesion") {
      // El token vence a los 15 min pero la cookie dura más, y /login redirige
      // mientras haya cookie: cerrar sesión la borra y lleva al login.
      return (
        <EstadoDePagina
          tipo="sin-permiso"
          titulo="Tu sesión expiró."
          mensaje="Inicia sesión de nuevo para ver la disponibilidad."
          accion={
            <form action={cerrarSesion}>
              <Boton type="submit" jerarquia="secundario">
                Iniciar sesión
              </Boton>
            </form>
          }
          className={className}
        />
      );
    }
    if (resultado?.error === "no-encontrado") {
      return <EstadoDePagina tipo="no-encontrado" className={className} />;
    }
    return (
      <EstadoDePagina
        tipo="error"
        titulo="No pudimos cargar la disponibilidad."
        mensaje="Revisa tu conexión e intenta de nuevo."
        accion={
          <Boton jerarquia="secundario" onClick={reintentar}>
            Reintentar
          </Boton>
        }
        className={className}
      />
    );
  }

  const { anio, mes } = mesDesplazado(hoy, desplazamiento);

  return (
    <div className={unirClases("flex flex-col gap-espacio-4", className)}>
      <p className="texto-cuerpo text-texto-secundario">{AYUDA[modo]}</p>
      <MesDeCalendario
        anio={anio}
        mes={mes}
        estadoDe={(fecha) => estadoDelDia(fecha, { hoy, ultimoDia, disponibilidad, inicio, fin })}
        onSeleccionarDia={seleccionarDia}
        onMesAnterior={desplazamiento > 0 ? () => setDesplazamiento((valor) => valor - 1) : undefined}
        onMesSiguiente={
          desplazamiento < ultimoDesplazamiento ? () => setDesplazamiento((valor) => valor + 1) : undefined
        }
      />
      {aviso && <Alerta tono="error">{aviso}</Alerta>}
      <LeyendaDeCalendario />
    </div>
  );
}
