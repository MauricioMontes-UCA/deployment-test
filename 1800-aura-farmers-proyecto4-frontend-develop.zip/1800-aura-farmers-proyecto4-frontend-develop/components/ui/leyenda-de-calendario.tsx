import { unirClases } from "@/lib/clases";

const ELEMENTOS = [
  { texto: "Disponible", muestra: "border border-borde-default bg-fondo-superficie" },
  { texto: "Seleccionado", muestra: "bg-fondo-marca" },
  { texto: "Reservado", muestra: "bg-fondo-error" },
  { texto: "Bloqueado", muestra: "bg-fondo-sutil" },
  { texto: "No disponible (pasado)", muestra: "border border-borde-sutil bg-fondo-base" },
];

/** Leyenda bajo el calendario de disponibilidad. */
export function LeyendaDeCalendario({ className }: { className?: string }) {
  return (
    <ul className={unirClases("flex flex-wrap gap-x-5 gap-y-espacio-2", className)}>
      {ELEMENTOS.map((elemento) => (
        <li key={elemento.texto} className="flex items-center gap-espacio-2">
          <span aria-hidden className={unirClases("size-3.5 shrink-0", elemento.muestra)} />
          <span className="texto-cuerpo-pequeno whitespace-nowrap text-texto-secundario">
            {elemento.texto}
          </span>
        </li>
      ))}
    </ul>
  );
}
