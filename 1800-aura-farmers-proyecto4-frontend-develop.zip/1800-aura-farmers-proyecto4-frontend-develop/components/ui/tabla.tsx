import type { ComponentPropsWithoutRef, ReactNode } from "react";
import { unirClases } from "@/lib/clases";
import { Icono } from "./icono";

/**
 * Tabla de Arre (reportes H23–H26, bloqueos). Se arma con `TablaEncabezado` y
 * `TablaCelda` dentro de `<thead>`/`<tbody>` normales. En pantallas angostas
 * se desplaza en horizontal.
 */
export function Tabla({ className, children, ...props }: ComponentPropsWithoutRef<"table">) {
  return (
    <div className="w-full overflow-x-auto">
      <table className={unirClases("w-full border-collapse", className)} {...props}>
        {children}
      </table>
    </div>
  );
}

export type OrdenTabla = "ninguno" | "ascendente" | "descendente";

type TablaEncabezadoProps = Omit<ComponentPropsWithoutRef<"th">, "children"> & {
  children: ReactNode;
  alineacion?: "izquierda" | "derecha";
  /** Dirección actual cuando la columna es ordenable. */
  orden?: OrdenTabla;
  /** Si se pasa, la columna es ordenable y el encabezado es un botón. */
  onOrdenar?: () => void;
};

const ARIA_SORT = {
  ninguno: "none",
  ascendente: "ascending",
  descendente: "descending",
} as const;

/** Celda de encabezado: fondo crema y borde inferior fuerte, 48 px de alto. */
export function TablaEncabezado({
  children,
  alineacion = "izquierda",
  orden = "ninguno",
  onOrdenar,
  className,
  ...props
}: TablaEncabezadoProps) {
  const contenido = (
    <>
      {children}
      {orden !== "ninguno" && (
        <Icono
          nombre={orden === "ascendente" ? "flecha-arriba" : "flecha-abajo"}
          tamano={16}
          className="text-texto-acento"
        />
      )}
    </>
  );
  const fila = "inline-flex items-center gap-1.5";

  return (
    <th
      scope="col"
      aria-sort={onOrdenar ? ARIA_SORT[orden] : undefined}
      className={unirClases(
        "texto-etiqueta h-12 border-b border-borde-fuerte bg-fondo-sutil px-espacio-4 whitespace-nowrap text-texto-primario",
        alineacion === "derecha" ? "text-right" : "text-left",
        className,
      )}
      {...props}
    >
      {onOrdenar ? (
        <button type="button" onClick={onOrdenar} className={unirClases(fila, "cursor-pointer")}>
          {contenido}
        </button>
      ) : (
        <span className={fila}>{contenido}</span>
      )}
    </th>
  );
}

type TablaCeldaProps = ComponentPropsWithoutRef<"td"> & {
  /** Derecha para importes y porcentajes. */
  alineacion?: "izquierda" | "derecha";
  /**
   * Total para la fila final (fondo crema y borde superior). Atenuada para
   * valores como «Sin días disponibles» o «Sin calificaciones».
   */
  enfasis?: "normal" | "total" | "atenuada";
};

/** Celda de tabla, 52 px de alto. */
export function TablaCelda({
  alineacion = "izquierda",
  enfasis = "normal",
  className,
  ...props
}: TablaCeldaProps) {
  return (
    <td
      className={unirClases(
        "h-13 px-espacio-4",
        alineacion === "derecha" ? "text-right tabular-nums" : "text-left",
        enfasis === "total"
          ? "texto-cuerpo-medio border-t border-borde-fuerte bg-fondo-sutil text-texto-primario"
          : unirClases(
              "texto-cuerpo border-b border-borde-sutil bg-fondo-superficie",
              enfasis === "atenuada" ? "text-texto-secundario" : "text-texto-primario",
            ),
        className,
      )}
      {...props}
    />
  );
}
