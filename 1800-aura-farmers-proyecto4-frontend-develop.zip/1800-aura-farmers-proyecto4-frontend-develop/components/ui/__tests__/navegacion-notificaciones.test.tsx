import { act, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { reiniciarContador } from "@/lib/notificaciones/contador";
import { CampanaDeNotificaciones } from "../campana-de-notificaciones";
import { NavegacionSuperior } from "../navegacion-superior";

const ruta = vi.hoisted(() => ({ actual: "/" }));
vi.mock("next/navigation", () => ({ usePathname: () => ruta.actual }));

const fetchSimulado = vi.fn();
const listado = (noLeidas: number) =>
  new Response(JSON.stringify({ noLeidas, total: 0, pagina: 1, tamanoPagina: 20, notificaciones: [] }), { status: 200 });
/** Deja salir la primera consulta del contador y espera su respuesta. */
const esperarContador = () => act(() => new Promise((r) => setTimeout(r, 0)));

beforeEach(() => {
  reiniciarContador();
  ruta.actual = "/";
  fetchSimulado.mockReset();
  fetchSimulado.mockImplementation(async () => listado(3));
  vi.stubGlobal("fetch", fetchSimulado);
});
afterEach(() => vi.unstubAllGlobals());

const campana = () => screen.getByRole("link", { name: /^Notificaciones/ });

describe("NavegacionSuperior + contador global (FE-21.1)", () => {
  it("con sesión y sin `noLeidas`: muestra el contador global y la campana lleva a /notificaciones", async () => {
    render(<NavegacionSuperior rol="arrendatario" nombreUsuario="ana_m" />);
    expect(fetchSimulado).not.toHaveBeenCalled();
    await esperarContador();
    expect(fetchSimulado).toHaveBeenCalledWith("/api/notificaciones?pagina=1", { cache: "no-store" });
    expect(campana()).toHaveAccessibleName("Notificaciones, 3 sin leer");
    expect(campana()).toHaveAttribute("href", "/notificaciones");
    expect(campana()).toHaveTextContent("3");
  });

  it.each([
    [0, "Notificaciones", null],
    [3, "Notificaciones, 3 sin leer", "3"],
    [99, "Notificaciones, 99 sin leer", "99"],
    [100, "Notificaciones, 100 sin leer", "99+"],
    [120, "Notificaciones, 120 sin leer", "99+"],
  ])("contador %i → «%s», insignia %s", async (n, nombre, insignia) => {
    fetchSimulado.mockImplementation(async () => listado(n));
    render(<NavegacionSuperior rol="arrendador" nombreUsuario="jose_r" />);
    await esperarContador();
    expect(campana()).toHaveAccessibleName(nombre);
    if (insignia === null) expect(campana()).toHaveTextContent("");
    else expect(campana()).toHaveTextContent(insignia);
  });

  it("visitante: sin campana y sin consultas", async () => {
    render(<NavegacionSuperior rol="visitante" />);
    await esperarContador();
    expect(screen.queryByRole("link", { name: /^Notificaciones/ })).not.toBeInTheDocument();
    expect(screen.queryByRole("button", { name: /^Notificaciones/ })).not.toBeInTheDocument();
    expect(fetchSimulado).not.toHaveBeenCalled();
  });

  it("visitante aunque reciba un nombre: tampoco consulta", async () => {
    render(<NavegacionSuperior rol="visitante" nombreUsuario="ana_m" />);
    await esperarContador();
    expect(fetchSimulado).not.toHaveBeenCalled();
  });

  it("compatibilidad: con `noLeidas` explícito muestra ese valor y no consulta nada", async () => {
    render(<NavegacionSuperior rol="arrendatario" nombreUsuario="ana_m" noLeidas={7} />);
    await esperarContador();
    expect(campana()).toHaveAccessibleName("Notificaciones, 7 sin leer");
    expect(fetchSimulado).not.toHaveBeenCalled();
  });

  it("compatibilidad: con `onAbrirNotificaciones` la campana sigue siendo un botón con esa acción", async () => {
    const abrir = vi.fn();
    render(<NavegacionSuperior rol="arrendatario" nombreUsuario="ana_m" noLeidas={2} onAbrirNotificaciones={abrir} />);
    await userEvent.click(screen.getByRole("button", { name: "Notificaciones, 2 sin leer" }));
    expect(abrir).toHaveBeenCalledOnce();
  });

  it("en /notificaciones la campana se marca como página actual", async () => {
    ruta.actual = "/notificaciones";
    render(<NavegacionSuperior rol="arrendatario" nombreUsuario="ana_m" />);
    await esperarContador();
    expect(campana()).toHaveAttribute("aria-current", "page");
  });

  it("un 401 del contador oculta la insignia sin romper la barra", async () => {
    fetchSimulado.mockImplementation(async () => new Response("{}", { status: 401 }));
    render(<NavegacionSuperior rol="arrendatario" nombreUsuario="ana_m" />);
    await esperarContador();
    expect(campana()).toHaveAccessibleName("Notificaciones");
  });
});

describe("CampanaDeNotificaciones", () => {
  it("sin `href` sigue siendo un botón que acepta sus props", async () => {
    const alPulsar = vi.fn();
    render(<CampanaDeNotificaciones noLeidas={1} onClick={alPulsar} title="Avisos" />);
    const boton = screen.getByRole("button", { name: "Notificaciones, 1 sin leer" });
    expect(boton).toHaveAttribute("type", "button");
    expect(boton).toHaveAttribute("title", "Avisos");
    await userEvent.click(boton);
    expect(alPulsar).toHaveBeenCalledOnce();
  });

  it("con `href` es un enlace con el mismo nombre accesible e insignia", () => {
    render(<CampanaDeNotificaciones noLeidas={150} href="/notificaciones" />);
    const enlace = screen.getByRole("link", { name: "Notificaciones, 150 sin leer" });
    expect(enlace).toHaveAttribute("href", "/notificaciones");
    expect(enlace).toHaveTextContent("99+");
  });
});
