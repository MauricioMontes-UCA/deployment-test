import { fireEvent, render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { Imagen } from "../imagen";

const reemplazo = () => screen.getByText("Foto no disponible");

describe("Imagen", () => {
  it("por defecto, sin foto, muestra el ícono y el texto «Foto no disponible» visible", () => {
    const { container } = render(<Imagen alt="Salón" className="size-60" />);
    expect(reemplazo()).toHaveClass("texto-etiqueta-pequena", "text-texto-secundario");
    expect(reemplazo()).not.toHaveClass("sr-only");
    expect(container.firstElementChild).toHaveClass("flex", "items-center", "justify-center", "bg-fondo-sutil", "size-60");
    expect(container.querySelector('[aria-hidden="true"]')).toBeInTheDocument();
  });

  it("compacta, sin foto: solo el ícono centrado; el texto queda para lectores de pantalla", () => {
    const { container } = render(<Imagen src={null} alt="Salón" compacta className="size-14" />);
    expect(reemplazo()).toHaveClass("sr-only");
    expect(reemplazo()).not.toHaveClass("texto-etiqueta-pequena");
    expect(container.firstElementChild).toHaveClass("flex", "items-center", "justify-center", "bg-fondo-sutil", "size-14");
    expect(container.querySelector('[aria-hidden="true"]')).toBeInTheDocument();
  });

  it.each([false, true])("con foto (compacta=%s) muestra la imagen y ningún reemplazo", (compacta) => {
    render(<Imagen src="/uploads/bienes/salon.jpg" alt="Salón" compacta={compacta} />);
    expect(screen.getByRole("img", { name: "Salón" })).toBeInTheDocument();
    expect(screen.queryByText("Foto no disponible")).not.toBeInTheDocument();
  });

  it.each([
    [false, "texto-etiqueta-pequena"],
    [true, "sr-only"],
  ])("si la foto no carga (compacta=%s), usa el reemplazo de su variante", (compacta, clase) => {
    render(<Imagen src="/uploads/bienes/rota.jpg" alt="Salón" compacta={compacta} />);
    fireEvent.error(screen.getByRole("img", { name: "Salón" }));
    expect(reemplazo()).toHaveClass(clase);
  });
});
