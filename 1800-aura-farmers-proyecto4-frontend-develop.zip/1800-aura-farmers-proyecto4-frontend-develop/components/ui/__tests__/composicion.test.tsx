import { fireEvent, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { beforeAll, describe, expect, it, vi } from "vitest";
import { CargadorDeArchivos, DialogoDeConfirmacion, MesDeCalendario } from "@/components/ui";

beforeAll(() => {
  // jsdom no implementa showModal/close de <dialog>; se simula lo mínimo.
  HTMLDialogElement.prototype.showModal ??= function (this: HTMLDialogElement) {
    this.setAttribute("open", "");
  };
  HTMLDialogElement.prototype.close ??= function (this: HTMLDialogElement) {
    this.removeAttribute("open");
  };
});

describe("DialogoDeConfirmacion", () => {
  function renderizar(props: Partial<Parameters<typeof DialogoDeConfirmacion>[0]> = {}) {
    const onConfirmar = vi.fn();
    const onCancelar = vi.fn();
    render(
      <DialogoDeConfirmacion
        abierto
        titulo="¿Enviar tu reseña?"
        mensaje="No podrás editarla después de enviarla."
        onConfirmar={onConfirmar}
        onCancelar={onCancelar}
        {...props}
      />,
    );
    return { onConfirmar, onCancelar };
  }

  it("se abre con título y mensaje accesibles", () => {
    renderizar();
    const dialogo = screen.getByRole("dialog", { name: "¿Enviar tu reseña?" });
    expect(dialogo).toHaveAccessibleDescription("No podrás editarla después de enviarla.");
  });

  it("confirma y cancela", async () => {
    const { onConfirmar, onCancelar } = renderizar();
    await userEvent.click(screen.getByRole("button", { name: "Confirmar" }));
    await userEvent.click(screen.getByRole("button", { name: "Cancelar" }));
    expect(onConfirmar).toHaveBeenCalledOnce();
    expect(onCancelar).toHaveBeenCalledOnce();
  });

  it("mientras procesa no se puede cancelar ni confirmar dos veces", async () => {
    const { onConfirmar, onCancelar } = renderizar({ cargando: true });
    expect(screen.getByRole("button", { name: "Cancelar" })).toBeDisabled();
    expect(screen.getByRole("button", { name: "Procesando…" })).toBeDisabled();
    fireEvent(screen.getByRole("dialog"), new Event("cancel", { cancelable: true }));
    expect(onCancelar).not.toHaveBeenCalled();
    expect(onConfirmar).not.toHaveBeenCalled();
  });
});

describe("CargadorDeArchivos", () => {
  it("entrega los archivos elegidos", async () => {
    const onArchivos = vi.fn();
    const { container } = render(<CargadorDeArchivos onArchivos={onArchivos} accept="image/png" />);
    const archivo = new File(["foto"], "foto.png", { type: "image/png" });
    await userEvent.upload(container.querySelector('input[type="file"]')!, archivo);
    expect(onArchivos).toHaveBeenCalledWith([archivo]);
  });

  it("entrega los archivos soltados y muestra el error en lugar de la ayuda", () => {
    const onArchivos = vi.fn();
    render(
      <CargadorDeArchivos
        onArchivos={onArchivos}
        ayuda="JPG o PNG, máximo 5 MB cada una"
        error="La foto supera los 5 MB."
      />,
    );
    expect(screen.getByText("La foto supera los 5 MB.")).toBeInTheDocument();
    expect(screen.queryByText("JPG o PNG, máximo 5 MB cada una")).not.toBeInTheDocument();

    const zona = screen.getByText(/Arrastra tus archivos/).closest("label")!;
    const archivo = new File(["doc"], "dui.pdf", { type: "application/pdf" });
    fireEvent.drop(zona, { dataTransfer: { files: [archivo] } });
    expect(onArchivos).toHaveBeenCalledWith([archivo]);
  });
});

describe("MesDeCalendario", () => {
  it("empieza la semana en lunes y no deja elegir días reservados", async () => {
    const onSeleccionarDia = vi.fn();
    render(
      <MesDeCalendario
        anio={2026}
        mes={10}
        estadoDe={(fecha) => (fecha === "2026-11-20" ? "reservado" : "disponible")}
        onSeleccionarDia={onSeleccionarDia}
      />,
    );
    // El 1 de noviembre de 2026 es domingo: va en la séptima columna.
    const primeraSemana = screen.getAllByRole("row")[1];
    expect(primeraSemana.lastElementChild).toHaveTextContent("1");

    await userEvent.click(screen.getByRole("button", { name: /20 de noviembre/ }));
    expect(onSeleccionarDia).not.toHaveBeenCalled();

    await userEvent.click(screen.getByRole("button", { name: /19 de noviembre/ }));
    expect(onSeleccionarDia).toHaveBeenCalledWith("2026-11-19");
  });
});
