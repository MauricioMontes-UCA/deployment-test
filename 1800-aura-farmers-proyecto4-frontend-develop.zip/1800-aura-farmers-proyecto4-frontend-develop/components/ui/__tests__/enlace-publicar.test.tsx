import { render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import { NavegacionSuperior, PieDePagina } from "@/components/ui";

vi.mock("next/navigation", () => ({ usePathname: () => "/mis-bienes" }));

describe("«Publicar un bien»", () => {
  it("en la barra del arrendador lleva a /publicar", () => {
    render(<NavegacionSuperior rol="arrendador" nombreUsuario="carlos" />);
    const enlaces = screen.getAllByRole("link", { name: "Publicar un bien" });
    expect(enlaces.length).toBeGreaterThan(0);
    for (const enlace of enlaces) expect(enlace).toHaveAttribute("href", "/publicar");
  });

  it("en el pie de página lleva a /publicar", () => {
    render(<PieDePagina />);
    expect(screen.getByRole("link", { name: "Publicar un bien" })).toHaveAttribute("href", "/publicar");
  });
});
