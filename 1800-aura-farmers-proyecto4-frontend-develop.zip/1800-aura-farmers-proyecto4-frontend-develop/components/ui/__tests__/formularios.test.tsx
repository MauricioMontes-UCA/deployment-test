import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { useState } from "react";
import { afterEach, beforeEach, describe, expect, it, vi, type MockInstance } from "vitest";
import { AreaDeTexto, Boton, CampoDeTexto, Selector } from "@/components/ui";

describe("Boton", () => {
  it("dispara onClick cuando está habilitado", async () => {
    const alHacerClic = vi.fn();
    render(<Boton onClick={alHacerClic}>Guardar</Boton>);
    await userEvent.click(screen.getByRole("button", { name: "Guardar" }));
    expect(alHacerClic).toHaveBeenCalledOnce();
  });

  it("no dispara onClick deshabilitado", async () => {
    const alHacerClic = vi.fn();
    render(
      <Boton onClick={alHacerClic} disabled>
        Guardar
      </Boton>,
    );
    await userEvent.click(screen.getByRole("button", { name: "Guardar" }));
    expect(alHacerClic).not.toHaveBeenCalled();
  });

  it("cargando muestra «Procesando…», se marca ocupado y bloquea el doble envío", async () => {
    const alHacerClic = vi.fn();
    render(
      <Boton onClick={alHacerClic} cargando>
        Guardar
      </Boton>,
    );
    const boton = screen.getByRole("button", { name: "Procesando…" });
    expect(boton).toBeDisabled();
    expect(boton).toHaveAttribute("aria-busy", "true");
    await userEvent.click(boton);
    expect(alHacerClic).not.toHaveBeenCalled();
  });
});

describe("CampoDeTexto", () => {
  it("asocia la etiqueta con el input", () => {
    render(<CampoDeTexto etiqueta="Correo electrónico" />);
    expect(screen.getByLabelText("Correo electrónico")).toBeInTheDocument();
  });

  it("actualiza el contador n/max al escribir", async () => {
    render(<CampoDeTexto etiqueta="Nombre de usuario" contador maxLength={30} />);
    expect(screen.getByText("0/30")).toBeInTheDocument();
    await userEvent.type(screen.getByLabelText("Nombre de usuario"), "ana_m");
    expect(screen.getByText("5/30")).toBeInTheDocument();
  });

  it("con error marca el campo como inválido y lo describe con el mensaje", () => {
    render(<CampoDeTexto etiqueta="Nombre de usuario" ayuda="De 3 a 30 caracteres." error="Es muy corto." />);
    const campo = screen.getByLabelText("Nombre de usuario");
    expect(campo).toHaveAttribute("aria-invalid", "true");
    expect(campo).toHaveAccessibleDescription("Es muy corto.");
    expect(screen.queryByText("De 3 a 30 caracteres.")).not.toBeInTheDocument();
  });

  it("invalido marca el error sin mostrar mensaje", () => {
    render(<CampoDeTexto etiqueta="Hasta" invalido />);
    expect(screen.getByLabelText("Hasta")).toHaveAttribute("aria-invalid", "true");
  });
});

describe("AreaDeTexto", () => {
  // React avisa por console.error (props controladas sin onChange, keys, etc.):
  // ninguna de estas pruebas debe dejar advertencias.
  let errorDeConsola: MockInstance<typeof console.error>;
  beforeEach(() => {
    errorDeConsola = vi.spyOn(console, "error");
  });
  afterEach(() => {
    expect(errorDeConsola).not.toHaveBeenCalled();
    errorDeConsola.mockRestore();
  });

  const texto = (longitud: number) => "a".repeat(longitud);

  it("sin contador ni límite no muestra contador ni pone maxLength", () => {
    render(<AreaDeTexto etiqueta="Observaciones" />);
    const campo = screen.getByLabelText("Observaciones");
    expect(campo.tagName).toBe("TEXTAREA");
    expect(campo).not.toHaveAttribute("maxlength");
    expect(screen.queryByText(/^\d+\/\d+$/)).not.toBeInTheDocument();
  });

  it("maxLength sin contador conserva el límite nativo y no muestra contador", () => {
    render(<AreaDeTexto etiqueta="Observaciones" maxLength={500} />);
    expect(screen.getByLabelText("Observaciones")).toHaveAttribute("maxlength", "500");
    expect(screen.queryByText("0/500")).not.toBeInTheDocument();
  });

  it("contador con maxLength muestra n/maxLength y el navegador corta en el máximo", async () => {
    render(<AreaDeTexto etiqueta="Descripción" contador maxLength={500} />);
    const campo = screen.getByLabelText("Descripción");
    expect(screen.getByText("0/500")).toBeInTheDocument();

    await userEvent.click(campo);
    await userEvent.paste(texto(501));

    expect(campo).toHaveValue(texto(500));
    expect(screen.getByText("500/500")).toBeInTheDocument();
  });

  it("limite muestra n/limite sin contador y sin poner maxLength nativo", async () => {
    render(<AreaDeTexto etiqueta="Comentario (opcional)" limite={500} />);
    const campo = screen.getByLabelText("Comentario (opcional)");
    expect(campo).not.toHaveAttribute("maxlength");
    expect(screen.getByText("0/500")).toBeInTheDocument();

    await userEvent.type(campo, "Hola");
    expect(screen.getByText("4/500")).toBeInTheDocument();
  });

  it("con limite={500} deja escribir 501 caracteres y el contador lo refleja", async () => {
    render(<AreaDeTexto etiqueta="Comentario (opcional)" limite={500} />);
    const campo = screen.getByLabelText("Comentario (opcional)");

    await userEvent.click(campo);
    await userEvent.paste(texto(501));

    expect(campo).toHaveValue(texto(501));
    expect(screen.getByText("501/500")).toBeInTheDocument();
  });

  it("con limite y maxLength el navegador corta en maxLength y el contador usa limite", async () => {
    render(<AreaDeTexto etiqueta="Comentario" limite={500} maxLength={600} contador />);
    const campo = screen.getByLabelText("Comentario");
    expect(campo).toHaveAttribute("maxlength", "600");
    expect(screen.getByText("0/500")).toBeInTheDocument();

    await userEvent.click(campo);
    await userEvent.paste(texto(650));

    expect(campo).toHaveValue(texto(600));
    expect(screen.getByText("600/500")).toBeInTheDocument();
  });

  it("con error pinta el contador en rojo, marca el campo inválido y lo describe con el mensaje", () => {
    render(
      <AreaDeTexto
        etiqueta="Comentario (opcional)"
        ayuda="Opcional."
        limite={500}
        defaultValue={texto(512)}
        error="Tu comentario supera los 500 caracteres por 12."
      />,
    );
    const campo = screen.getByLabelText("Comentario (opcional)");
    expect(screen.getByText("512/500")).toHaveClass("text-texto-error");
    expect(campo).toHaveClass("border-2", "border-borde-error");
    expect(campo).toHaveAttribute("aria-invalid", "true");
    expect(campo).toHaveAccessibleDescription("Tu comentario supera los 500 caracteres por 12.");
    expect(screen.queryByText("Opcional.")).not.toBeInTheDocument();
  });

  it("pasar el límite sin error no pinta nada en rojo: lo decide la pantalla", () => {
    render(<AreaDeTexto etiqueta="Comentario" limite={500} defaultValue={texto(501)} />);
    const campo = screen.getByLabelText("Comentario");
    expect(screen.getByText("501/500")).toHaveClass("text-texto-secundario");
    expect(campo).not.toHaveAttribute("aria-invalid");
  });

  it("sin error usa la ayuda como descripción y no marca el campo inválido", () => {
    render(<AreaDeTexto etiqueta="Comentario" ayuda="Cuéntanos cómo te fue." limite={500} />);
    const campo = screen.getByLabelText("Comentario");
    expect(campo).not.toHaveAttribute("aria-invalid");
    expect(campo).toHaveAccessibleDescription("Cuéntanos cómo te fue.");
  });

  it("sin ayuda ni error no apunta aria-describedby a nada", () => {
    render(<AreaDeTexto etiqueta="Comentario" limite={500} />);
    expect(screen.getByLabelText("Comentario")).not.toHaveAttribute("aria-describedby");
  });

  it("deshabilitado no deja escribir y no pinta el contador en rojo aunque haya error", async () => {
    render(
      <AreaDeTexto etiqueta="Comentario" limite={500} defaultValue="Hola" error="Error." disabled />,
    );
    const campo = screen.getByLabelText("Comentario");
    expect(campo).toBeDisabled();
    expect(screen.getByText("4/500")).toHaveClass("text-texto-secundario");
    expect(screen.getByText("4/500")).not.toHaveClass("text-texto-error");

    await userEvent.type(campo, "xyz");
    expect(campo).toHaveValue("Hola");
  });

  it("no controlado: cuenta desde defaultValue y se actualiza al escribir", async () => {
    const alCambiar = vi.fn();
    render(<AreaDeTexto etiqueta="Comentario" limite={500} defaultValue="Hola" onChange={alCambiar} />);
    expect(screen.getByText("4/500")).toBeInTheDocument();

    await userEvent.type(screen.getByLabelText("Comentario"), "!!");
    expect(screen.getByText("6/500")).toBeInTheDocument();
    expect(alCambiar).toHaveBeenCalledTimes(2);
  });

  it("controlado: el contador sigue a value, también cuando el padre lo cambia", async () => {
    function Controlado() {
      const [valor, setValor] = useState("Hola");
      return (
        <>
          <AreaDeTexto
            etiqueta="Comentario"
            limite={500}
            value={valor}
            onChange={(evento) => setValor(evento.target.value)}
          />
          <button type="button" onClick={() => setValor(texto(510))}>
            Llenar
          </button>
        </>
      );
    }
    render(<Controlado />);
    expect(screen.getByText("4/500")).toBeInTheDocument();

    await userEvent.type(screen.getByLabelText("Comentario"), "!");
    expect(screen.getByText("5/500")).toBeInTheDocument();

    await userEvent.click(screen.getByRole("button", { name: "Llenar" }));
    expect(screen.getByLabelText("Comentario")).toHaveValue(texto(510));
    expect(screen.getByText("510/500")).toBeInTheDocument();
  });

  describe("contarCaracteres", () => {
    const porCodePoint = (valor: string) => Array.from(valor).length;
    const recortadoPorCodePoint = (valor: string) => Array.from(valor.trim()).length;

    it("sin la prop cuenta con String.length (un emoji cuenta 2)", () => {
      render(<AreaDeTexto etiqueta="Comentario" limite={500} defaultValue="😀👍🏽" />);
      expect(screen.getByText("6/500")).toBeInTheDocument();
    });

    it("con la prop usa la función recibida para el número del contador", () => {
      const contar = vi.fn(() => 42);
      render(<AreaDeTexto etiqueta="Comentario" limite={500} defaultValue="Hola" contarCaracteres={contar} />);
      expect(screen.getByText("42/500")).toBeInTheDocument();
      expect(contar).toHaveBeenCalledWith("Hola");
    });

    it.each([
      ["ASCII", "hola", "4/500"],
      ["acentos precompuestos", "éxito", "5/500"],
      ["acento combinado (e + U+0301)", "é", "2/500"],
      ["emoji", "😀", "1/500"],
      ["emoji con tono de piel", "👍🏽", "2/500"],
      ["familia con ZWJ", "👨‍👩‍👧", "5/500"],
    ])("cuenta por code point con %s", (_caso, valor, esperado) => {
      render(<AreaDeTexto etiqueta="Comentario" limite={500} defaultValue={valor} contarCaracteres={porCodePoint} />);
      expect(screen.getByText(esperado)).toBeInTheDocument();
    });

    it("puede no contar los espacios del principio y del final", async () => {
      render(<AreaDeTexto etiqueta="Comentario" limite={500} contarCaracteres={recortadoPorCodePoint} />);
      await userEvent.type(screen.getByLabelText("Comentario"), "  Hola  ");
      expect(screen.getByText("4/500")).toBeInTheDocument();
    });

    it("no controlado: recuenta con la función al escribir y pegar", async () => {
      render(<AreaDeTexto etiqueta="Comentario" limite={500} contarCaracteres={porCodePoint} />);
      const campo = screen.getByLabelText("Comentario");
      await userEvent.click(campo);
      await userEvent.paste("😀".repeat(501));
      expect(campo).toHaveValue("😀".repeat(501));
      expect(screen.getByText("501/500")).toBeInTheDocument();
    });

    it("controlado: recuenta con la función cuando cambia value", async () => {
      function Controlado() {
        const [valor, setValor] = useState("😀");
        return (
          <AreaDeTexto
            etiqueta="Comentario"
            limite={500}
            value={valor}
            contarCaracteres={porCodePoint}
            onChange={(evento) => setValor(evento.target.value)}
          />
        );
      }
      render(<Controlado />);
      expect(screen.getByText("1/500")).toBeInTheDocument();
      await userEvent.type(screen.getByLabelText("Comentario"), "👍🏽");
      expect(screen.getByText("3/500")).toBeInTheDocument();
    });

    it("con maxLength el navegador sigue cortando por String.length; solo cambia el número", async () => {
      render(<AreaDeTexto etiqueta="Comentario" contador maxLength={4} contarCaracteres={porCodePoint} />);
      const campo = screen.getByLabelText("Comentario");
      expect(campo).toHaveAttribute("maxlength", "4");
      await userEvent.click(campo);
      await userEvent.paste("😀😀😀");
      // maxLength nativo cuenta unidades UTF-16: caben dos emojis (4 unidades).
      expect(campo).toHaveValue("😀😀");
      expect(screen.getByText("2/4")).toBeInTheDocument();
    });

    it("con limite no impone maxLength aunque se pase la función", () => {
      render(<AreaDeTexto etiqueta="Comentario" limite={500} contarCaracteres={porCodePoint} />);
      expect(screen.getByLabelText("Comentario")).not.toHaveAttribute("maxlength");
    });

    it("conserva el estado de error: contador en rojo, aria-invalid y descripción", () => {
      render(
        <AreaDeTexto
          etiqueta="Comentario"
          limite={500}
          defaultValue={"😀".repeat(512)}
          contarCaracteres={porCodePoint}
          error="Tu comentario supera los 500 caracteres por 12."
        />,
      );
      const campo = screen.getByLabelText("Comentario");
      expect(screen.getByText("512/500")).toHaveClass("text-texto-error");
      expect(campo).toHaveAttribute("aria-invalid", "true");
      expect(campo).toHaveAccessibleDescription("Tu comentario supera los 500 caracteres por 12.");
    });
  });

  it("los usos del catálogo siguen igual (contador + maxLength, error y deshabilitado)", () => {
    render(
      <>
        <AreaDeTexto etiqueta="Descripción" placeholder="Escribe aquí" ayuda="Texto de ayuda opcional." contador maxLength={500} />
        <AreaDeTexto etiqueta="Con error" defaultValue="Muy corta" error="La descripción es obligatoria." contador maxLength={500} />
        <AreaDeTexto etiqueta="Deshabilitado" placeholder="Escribe aquí" disabled />
      </>,
    );
    expect(screen.getByLabelText("Descripción")).toHaveAttribute("maxlength", "500");
    expect(screen.getByText("0/500")).toHaveClass("text-texto-secundario");

    expect(screen.getByLabelText("Con error")).toHaveAttribute("maxlength", "500");
    expect(screen.getByText("9/500")).toHaveClass("text-texto-error");
    expect(screen.getByLabelText("Con error")).toHaveAccessibleDescription("La descripción es obligatoria.");

    expect(screen.getByLabelText("Deshabilitado")).toBeDisabled();
    expect(screen.getByLabelText("Deshabilitado")).not.toHaveAttribute("maxlength");
  });
});

describe("Selector", () => {
  const opciones = [
    { valor: "espacio", etiqueta: "Espacio" },
    { valor: "equipo", etiqueta: "Equipo" },
    { valor: "vehiculo", etiqueta: "Vehículo" },
  ];

  it("abre la lista al hacer clic y elige una opción", async () => {
    const alCambiar = vi.fn();
    render(<Selector etiqueta="Tipo de bien" opciones={opciones} onCambiar={alCambiar} />);
    const combo = screen.getByRole("combobox", { name: "Tipo de bien" });
    expect(combo).toHaveTextContent("Selecciona una opción");

    await userEvent.click(combo);
    await userEvent.click(screen.getByRole("option", { name: "Equipo" }));

    expect(alCambiar).toHaveBeenCalledWith("equipo");
    expect(combo).toHaveTextContent("Equipo");
    expect(screen.queryByRole("listbox")).not.toBeInTheDocument();
  });

  it("se maneja con teclado y se cierra con Escape", async () => {
    const alCambiar = vi.fn();
    render(<Selector etiqueta="Tipo de bien" opciones={opciones} onCambiar={alCambiar} />);
    const combo = screen.getByRole("combobox", { name: "Tipo de bien" });

    combo.focus();
    await userEvent.keyboard("{ArrowDown}");
    expect(screen.getByRole("listbox")).toBeInTheDocument();
    await userEvent.keyboard("{Escape}");
    expect(screen.queryByRole("listbox")).not.toBeInTheDocument();

    await userEvent.keyboard("{ArrowDown}{ArrowDown}{ArrowDown}{Enter}");
    expect(alCambiar).toHaveBeenCalledWith("vehiculo");
  });

  it("envía el valor en un formulario con un input oculto", async () => {
    const { container } = render(
      <Selector etiqueta="Tipo" opciones={opciones} valorInicial="equipo" name="tipo" />,
    );
    expect(container.querySelector('input[name="tipo"]')).toHaveValue("equipo");
  });

  const departamentos = [
    "Ahuachapán", "Cabañas", "Chalatenango", "Cuscatlán", "La Libertad", "La Paz",
    "La Unión", "Morazán", "San Miguel", "San Salvador", "San Vicente", "Santa Ana",
    "Sonsonate", "Usulután",
  ].map((nombre) => ({ valor: nombre, etiqueta: nombre }));

  it("salta con letras a la opción que empieza así, sin importar tildes", async () => {
    const alCambiar = vi.fn();
    render(<Selector etiqueta="Departamento" opciones={departamentos} onCambiar={alCambiar} />);
    screen.getByRole("combobox", { name: "Departamento" }).focus();

    await userEvent.keyboard("u");
    expect(screen.getByRole("option", { name: "Usulután" })).toHaveClass("bg-fondo-sutil");

    // Varias letras seguidas buscan el prefijo completo.
    await userEvent.keyboard("{Escape}san v{Enter}");
    expect(alCambiar).toHaveBeenLastCalledWith("San Vicente");
  });

  it("una misma letra recorre las opciones que empiezan con ella", async () => {
    render(<Selector etiqueta="Departamento" opciones={departamentos} />);
    screen.getByRole("combobox", { name: "Departamento" }).focus();
    vi.useFakeTimers({ shouldAdvanceTime: true });
    try {
      await userEvent.keyboard("l");
      expect(screen.getByRole("option", { name: "La Libertad" })).toHaveClass("bg-fondo-sutil");
      vi.advanceTimersByTime(600);
      await userEvent.keyboard("l");
      expect(screen.getByRole("option", { name: "La Paz" })).toHaveClass("bg-fondo-sutil");
    } finally {
      vi.useRealTimers();
    }
  });

  it("lleva a la vista la opción activa al navegar con teclado", async () => {
    const scrollIntoView = vi.fn();
    Element.prototype.scrollIntoView = scrollIntoView;
    render(<Selector etiqueta="Departamento" opciones={departamentos} />);
    screen.getByRole("combobox", { name: "Departamento" }).focus();
    await userEvent.keyboard("{ArrowDown}{End}");
    expect(scrollIntoView).toHaveBeenLastCalledWith({ block: "nearest" });
    expect(scrollIntoView.mock.contexts.at(-1)).toHaveTextContent("Usulután");
  });

  it("solo apunta aria-controls a la lista cuando está abierta", async () => {
    render(<Selector etiqueta="Tipo" opciones={opciones} />);
    const combo = screen.getByRole("combobox", { name: "Tipo" });
    expect(combo).not.toHaveAttribute("aria-controls");
    await userEvent.click(combo);
    expect(combo).toHaveAttribute("aria-controls", screen.getByRole("listbox").id);
  });

  it("si las opciones se reducen con el menú abierto, elige una que existe", async () => {
    const alCambiar = vi.fn();
    const { rerender } = render(
      <Selector etiqueta="Municipio" opciones={departamentos} onCambiar={alCambiar} />,
    );
    screen.getByRole("combobox", { name: "Municipio" }).focus();
    await userEvent.keyboard("{ArrowDown}{End}");
    rerender(<Selector etiqueta="Municipio" opciones={opciones} onCambiar={alCambiar} />);
    await userEvent.keyboard("{Enter}");
    expect(alCambiar).toHaveBeenCalledWith("vehiculo");
  });

  it("deshabilitado no abre la lista", async () => {
    render(<Selector etiqueta="Tipo" opciones={opciones} deshabilitado />);
    await userEvent.click(screen.getByRole("combobox", { name: "Tipo" }));
    expect(screen.queryByRole("listbox")).not.toBeInTheDocument();
  });
});
