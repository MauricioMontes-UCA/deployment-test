import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";
import {
  Calificacion,
  CampanaDeNotificaciones,
  Casilla,
  ChipDeFiltro,
  Interruptor,
  OpcionEnTarjeta,
  Radio,
  inicialesDe,
} from "@/components/ui";

describe("OpcionEnTarjeta y Radio", () => {
  it("las opciones con el mismo name se excluyen entre sí", async () => {
    render(
      <>
        <OpcionEnTarjeta name="rol" value="ARRENDADOR" titulo="Quiero publicar mis bienes" descripcion="Arrendador" />
        <OpcionEnTarjeta name="rol" value="ARRENDATARIO" titulo="Quiero rentar bienes" descripcion="Arrendatario" />
      </>,
    );
    const publicar = screen.getByRole("radio", { name: /Quiero publicar mis bienes/ });
    const rentar = screen.getByRole("radio", { name: /Quiero rentar bienes/ });
    expect(publicar).not.toBeChecked();
    expect(rentar).not.toBeChecked();

    await userEvent.click(screen.getByText("Quiero publicar mis bienes"));
    expect(publicar).toBeChecked();

    await userEvent.click(screen.getByText("Quiero rentar bienes"));
    expect(rentar).toBeChecked();
    expect(publicar).not.toBeChecked();
  });

  it("el radio deshabilitado no se puede marcar", async () => {
    render(<Radio name="accion" texto="RETENER" disabled />);
    await userEvent.click(screen.getByText("RETENER"));
    expect(screen.getByRole("radio", { name: "RETENER" })).not.toBeChecked();
  });
});

describe("Casilla", () => {
  it("se marca y desmarca al hacer clic en el texto", async () => {
    const alCambiar = vi.fn();
    render(<Casilla texto="Acepto las condiciones" onChange={alCambiar} />);
    const casilla = screen.getByRole("checkbox", { name: "Acepto las condiciones" });
    await userEvent.click(screen.getByText("Acepto las condiciones"));
    expect(casilla).toBeChecked();
    await userEvent.click(screen.getByText("Acepto las condiciones"));
    expect(casilla).not.toBeChecked();
    expect(alCambiar).toHaveBeenCalledTimes(2);
  });
});

describe("Interruptor", () => {
  it("es un switch accesible que cambia con la barra espaciadora", async () => {
    render(<Interruptor texto="Solo usuarios verificados" />);
    const interruptor = screen.getByRole("switch", { name: "Solo usuarios verificados" });
    expect(interruptor).not.toBeChecked();
    interruptor.focus();
    await userEvent.keyboard(" ");
    expect(interruptor).toBeChecked();
  });

  it("deshabilitado no cambia", async () => {
    render(<Interruptor texto="Solo usuarios verificados" disabled />);
    await userEvent.click(screen.getByText("Solo usuarios verificados"));
    expect(screen.getByRole("switch")).not.toBeChecked();
  });
});

describe("Calificacion", () => {
  it("en solo lectura anuncia el valor", () => {
    render(<Calificacion valor={4} />);
    expect(screen.getByRole("img", { name: "4 de 5 estrellas" })).toBeInTheDocument();
  });

  it("en solo lectura dibuja media estrella y anuncia el promedio", () => {
    const { container } = render(<Calificacion valor={4.5} />);
    expect(screen.getByRole("img", { name: "4,5 de 5 estrellas" })).toBeInTheDocument();
    expect(container.querySelectorAll('[data-estrella="media"]')).toHaveLength(1);
  });

  it("redondea a la media estrella más cercana", () => {
    const { container, rerender } = render(<Calificacion valor={4.2} />);
    expect(container.querySelectorAll('[data-estrella="media"]')).toHaveLength(0);
    expect(screen.getByRole("img", { name: "4,2 de 5 estrellas" })).toBeInTheDocument();
    rerender(<Calificacion valor={3.3} />);
    expect(container.querySelectorAll('[data-estrella="media"]')).toHaveLength(1);
  });

  it("editable avisa la estrella elegida", async () => {
    const alCambiar = vi.fn();
    render(<Calificacion valor={0} onCambiar={alCambiar} etiqueta="Calificación del bien" />);
    expect(screen.getByRole("radiogroup", { name: "Calificación del bien" })).toBeInTheDocument();
    await userEvent.click(screen.getByRole("radio", { name: "3 estrellas" }));
    expect(alCambiar).toHaveBeenCalledWith(3);
  });
});

describe("ChipDeFiltro", () => {
  it("la X quita el filtro", async () => {
    const alQuitar = vi.fn();
    render(<ChipDeFiltro texto="Propiedad" onQuitar={alQuitar} />);
    await userEvent.click(screen.getByRole("button", { name: "Quitar filtro Propiedad" }));
    expect(alQuitar).toHaveBeenCalledOnce();
  });
});

describe("CampanaDeNotificaciones", () => {
  it("sin no leídas no muestra insignia", () => {
    render(<CampanaDeNotificaciones noLeidas={0} />);
    expect(screen.getByRole("button", { name: "Notificaciones" })).toBeInTheDocument();
  });

  it("muestra 99+ cuando hay más de 99", () => {
    render(<CampanaDeNotificaciones noLeidas={150} />);
    expect(screen.getByRole("button", { name: "Notificaciones, 150 sin leer" })).toHaveTextContent("99+");
  });
});

describe("inicialesDe", () => {
  it("toma la primera letra de dos partes o las dos primeras de una palabra", () => {
    expect(inicialesDe("ana_m")).toBe("AM");
    expect(inicialesDe("mariana.rivas")).toBe("MR");
    expect(inicialesDe("mauricio")).toBe("MA");
  });
});
