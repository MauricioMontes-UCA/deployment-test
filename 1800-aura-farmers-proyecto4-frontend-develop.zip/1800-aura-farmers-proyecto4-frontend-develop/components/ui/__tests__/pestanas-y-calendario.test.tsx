import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";
import { MesDeCalendario, PanelDePestana, Pestana, Pestanas } from "@/components/ui";

describe("Pestanas", () => {
  it("con una pestaña activa, solo esa entra en el orden de Tab", async () => {
    render(
      <Pestanas etiqueta="Reportes">
        <Pestana>Ingresos</Pestana>
        <Pestana activa>Ocupación</Pestana>
        <Pestana>Calificaciones</Pestana>
      </Pestanas>,
    );
    await userEvent.tab();
    expect(screen.getByRole("tab", { name: "Ocupación" })).toHaveFocus();
  });

  it("sin pestaña activa, la primera queda alcanzable con Tab", async () => {
    render(
      <Pestanas etiqueta="Filtrar por estado">
        <Pestana>Todas</Pestana>
        <Pestana>Confirmadas</Pestana>
      </Pestanas>,
    );
    await userEvent.tab();
    expect(screen.getByRole("tab", { name: "Todas" })).toHaveFocus();
    expect(screen.getByRole("tab", { name: "Confirmadas" })).toHaveAttribute("tabindex", "-1");
  });

  it("salta las deshabilitadas al elegir la de respaldo", async () => {
    render(
      <Pestanas etiqueta="Filtros">
        <Pestana disabled>Archivadas</Pestana>
        <Pestana>Vigentes</Pestana>
      </Pestanas>,
    );
    await userEvent.tab();
    expect(screen.getByRole("tab", { name: "Vigentes" })).toHaveFocus();
  });

  it("las flechas, Inicio y Fin mueven el foco", async () => {
    render(
      <Pestanas etiqueta="Reportes">
        <Pestana activa>Ingresos</Pestana>
        <Pestana>Ocupación</Pestana>
        <Pestana>Calificaciones</Pestana>
      </Pestanas>,
    );
    await userEvent.tab();
    await userEvent.keyboard("{ArrowRight}");
    expect(screen.getByRole("tab", { name: "Ocupación" })).toHaveFocus();
    await userEvent.keyboard("{End}");
    expect(screen.getByRole("tab", { name: "Calificaciones" })).toHaveFocus();
    await userEvent.keyboard("{ArrowRight}");
    expect(screen.getByRole("tab", { name: "Ingresos" })).toHaveFocus();
    await userEvent.keyboard("{ArrowLeft}{Home}");
    expect(screen.getByRole("tab", { name: "Ingresos" })).toHaveFocus();
  });

  it("asocia cada pestaña con su panel", () => {
    render(
      <>
        <Pestanas etiqueta="Reportes">
          <Pestana id="tab-ingresos" panel="panel-ingresos" activa>
            Ingresos
          </Pestana>
          <Pestana id="tab-ocupacion" panel="panel-ocupacion">
            Ocupación
          </Pestana>
        </Pestanas>
        <PanelDePestana id="panel-ingresos" pestana="tab-ingresos" activo>
          Tabla de ingresos
        </PanelDePestana>
        <PanelDePestana id="panel-ocupacion" pestana="tab-ocupacion" activo={false}>
          Tabla de ocupación
        </PanelDePestana>
      </>,
    );
    expect(screen.getByRole("tab", { name: "Ingresos" })).toHaveAttribute("aria-controls", "panel-ingresos");
    expect(screen.getByRole("tabpanel", { name: "Ingresos" })).toHaveTextContent("Tabla de ingresos");
    expect(screen.queryByText("Tabla de ocupación")).not.toBeVisible();
  });
});

describe("MesDeCalendario", () => {
  it("un mes que empieza en lunes no tiene huecos iniciales", () => {
    // El 1 de junio de 2026 es lunes.
    render(<MesDeCalendario anio={2026} mes={5} />);
    const primeraSemana = screen.getAllByRole("row")[1];
    expect(primeraSemana.firstElementChild).toHaveTextContent("1");
    expect(screen.getByRole("heading")).toHaveTextContent(/junio 2026/i);
  });

  it("dibuja todos los días del mes, también en febrero de año bisiesto", () => {
    render(<MesDeCalendario anio={2028} mes={1} />);
    expect(screen.getAllByRole("button", { name: /de febrero de 2028/ })).toHaveLength(29);
  });

  it("las flechas avisan el cambio de mes y se ocultan sin callback", async () => {
    const onMesAnterior = vi.fn();
    const onMesSiguiente = vi.fn();
    const { rerender } = render(
      <MesDeCalendario anio={2026} mes={10} onMesAnterior={onMesAnterior} onMesSiguiente={onMesSiguiente} />,
    );
    await userEvent.click(screen.getByRole("button", { name: "Mes anterior" }));
    await userEvent.click(screen.getByRole("button", { name: "Mes siguiente" }));
    expect(onMesAnterior).toHaveBeenCalledOnce();
    expect(onMesSiguiente).toHaveBeenCalledOnce();

    rerender(<MesDeCalendario anio={2026} mes={10} onMesSiguiente={onMesSiguiente} />);
    expect(screen.queryByRole("button", { name: "Mes anterior" })).not.toBeInTheDocument();
  });
});
