"use client";

import { Boton } from "./boton";
import { CampoDeTexto } from "./campo-de-texto";
import { Selector } from "./selector";

export type PeriodoReporte = "ultimo-mes" | "ultimos-3-meses" | "ultimo-anio" | "rango";

/**
 * Opciones del periodo en el orden de Figma. Las fijas dicen cuántos días
 * cubren (contando hoy), como en la especificación de FE-23.1.
 */
export const OPCIONES_PERIODO: { valor: PeriodoReporte; etiqueta: string }[] = [
  { valor: "ultimo-mes", etiqueta: "Último mes (30 días)" },
  { valor: "ultimos-3-meses", etiqueta: "Últimos 3 meses (90 días)" },
  { valor: "ultimo-anio", etiqueta: "Último año (365 días)" },
  { valor: "rango", etiqueta: "Rango de fechas" },
];

type SelectorDePeriodoProps = {
  periodo: PeriodoReporte;
  onCambiarPeriodo: (periodo: PeriodoReporte) => void;
  /** Fechas en AAAA-MM-DD; solo aplican con el periodo «rango». */
  desde?: string;
  hasta?: string;
  onCambiarDesde?: (valor: string) => void;
  onCambiarHasta?: (valor: string) => void;
  onAplicar?: () => void;
  /** Error del rango (validado sin llamar al servidor). Marca el campo Hasta. */
  error?: string;
};

/**
 * Selector de periodo compartido del panel de reportes (FE-23.1). Con
 * «Rango de fechas» aparecen Desde, Hasta (AAAA-MM-DD) y Aplicar. La
 * validación del rango es de la pantalla; aquí solo se muestra el error.
 */
export function SelectorDePeriodo({
  periodo,
  onCambiarPeriodo,
  desde = "",
  hasta = "",
  onCambiarDesde,
  onCambiarHasta,
  onAplicar,
  error,
}: SelectorDePeriodoProps) {
  const rango = periodo === "rango";
  return (
    <div className="flex flex-col gap-espacio-2">
      <div className="flex flex-wrap items-end gap-espacio-4">
        <Selector
          etiqueta="Periodo"
          opciones={OPCIONES_PERIODO}
          valor={periodo}
          onCambiar={(valor) => onCambiarPeriodo(valor as PeriodoReporte)}
          className="w-full sm:w-60"
        />
        {rango && (
          <>
            <CampoDeTexto
              etiqueta="Desde"
              icono="calendario"
              placeholder="AAAA-MM-DD"
              inputMode="numeric"
              value={desde}
              onChange={(evento) => onCambiarDesde?.(evento.target.value)}
              className="w-full sm:w-45"
            />
            <CampoDeTexto
              etiqueta="Hasta"
              icono="calendario"
              placeholder="AAAA-MM-DD"
              inputMode="numeric"
              value={hasta}
              invalido={Boolean(error)}
              onChange={(evento) => onCambiarHasta?.(evento.target.value)}
              className="w-full sm:w-45"
            />
            <Boton onClick={onAplicar} className="w-full sm:w-auto">
              Aplicar
            </Boton>
          </>
        )}
      </div>
      {rango && error && (
        <p role="alert" className="texto-cuerpo-pequeno text-texto-error">
          {error}
        </p>
      )}
    </div>
  );
}
