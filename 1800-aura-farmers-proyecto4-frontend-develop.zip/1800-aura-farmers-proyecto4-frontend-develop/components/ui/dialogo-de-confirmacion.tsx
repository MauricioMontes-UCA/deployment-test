"use client";

import { useEffect, useId, useRef, type ReactNode } from "react";
import { Boton } from "./boton";

type DialogoDeConfirmacionProps = {
  abierto: boolean;
  titulo: string;
  mensaje: ReactNode;
  textoConfirmar?: string;
  textoCancelar?: string;
  /** Acción destructiva: el botón de confirmar usa la jerarquía Peligro. */
  peligro?: boolean;
  /** Mientras se procesa, el botón muestra «Procesando…» y no se puede cerrar. */
  cargando?: boolean;
  onConfirmar: () => void;
  onCancelar: () => void;
};

/**
 * Confirmación previa a acciones irreversibles (enviar reseña, registrar
 * devolución, resolver depósito, eliminar bloqueo). Se muestra centrada sobre
 * un velo café tinta al 40 %.
 *
 * Usa `<dialog>` con `showModal()`, que ya atrapa el foco y cierra con Escape.
 */
export function DialogoDeConfirmacion({
  abierto,
  titulo,
  mensaje,
  textoConfirmar = "Confirmar",
  textoCancelar = "Cancelar",
  peligro = false,
  cargando = false,
  onConfirmar,
  onCancelar,
}: DialogoDeConfirmacionProps) {
  const dialogo = useRef<HTMLDialogElement>(null);
  const idTitulo = useId();
  const idMensaje = useId();

  useEffect(() => {
    const elemento = dialogo.current;
    if (!elemento) return;
    if (abierto && !elemento.open) elemento.showModal();
    if (!abierto && elemento.open) elemento.close();
  }, [abierto]);

  return (
    <dialog
      ref={dialogo}
      aria-labelledby={idTitulo}
      aria-describedby={idMensaje}
      onCancel={(evento) => {
        // Escape cierra el diálogo nativo; aquí se avisa al padre para que su
        // estado no quede desfasado, salvo que se esté procesando.
        evento.preventDefault();
        if (!cargando) onCancelar();
      }}
      className="m-auto w-[calc(100%-2*var(--spacing-espacio-4))] max-w-[440px] border border-borde-fuerte bg-fondo-superficie p-0 text-texto-primario backdrop:bg-fondo-inverso/40"
    >
      <div className="flex flex-col gap-espacio-4 px-espacio-6 pt-espacio-6 pb-7">
        <h2 id={idTitulo} className="texto-h3 text-texto-primario">
          {titulo}
        </h2>
        <div id={idMensaje} className="texto-cuerpo text-texto-secundario">
          {mensaje}
        </div>
        <div className="flex flex-wrap justify-end gap-espacio-3 pt-espacio-2">
          <Boton jerarquia="secundario" onClick={onCancelar} disabled={cargando}>
            {textoCancelar}
          </Boton>
          <Boton
            jerarquia={peligro ? "peligro" : "primario"}
            onClick={onConfirmar}
            cargando={cargando}
          >
            {textoConfirmar}
          </Boton>
        </div>
      </div>
    </dialog>
  );
}
