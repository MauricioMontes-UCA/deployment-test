import type { ComponentPropsWithoutRef, ReactNode } from "react";
import { unirClases } from "@/lib/clases";

type OpcionEnTarjetaProps = Omit<ComponentPropsWithoutRef<"input">, "type"> & {
  titulo: ReactNode;
  descripcion?: ReactNode;
};

/**
 * Opción excluyente con título y descripción, para elegir el rol en el
 * registro (H0) o la modalidad de pago (H8). Es un `<input type="radio">`
 * nativo: varias opciones con el mismo `name` se excluyen entre sí.
 *
 * El indicador es cuadrado porque Arre no usa círculos ni esquinas redondas.
 */
export function OpcionEnTarjeta({
  titulo,
  descripcion,
  className,
  disabled,
  ...props
}: OpcionEnTarjetaProps) {
  return (
    <label
      className={unirClases(
        "group flex w-full items-center gap-espacio-4 border border-borde-default bg-fondo-superficie px-5 py-espacio-4",
        "has-checked:border-2 has-checked:border-borde-foco has-checked:bg-fondo-acento",
        "has-focus-visible:outline-2 has-focus-visible:outline-offset-2 has-focus-visible:outline-borde-foco",
        disabled ? "cursor-not-allowed opacity-60" : "cursor-pointer",
        className,
      )}
    >
      <input type="radio" disabled={disabled} className="solo-lector" {...props} />
      <IndicadorCuadrado />
      <span className="flex min-w-0 flex-1 flex-col gap-0.5">
        <span className="texto-cuerpo-medio text-texto-primario">{titulo}</span>
        {descripcion && (
          <span className="texto-cuerpo-pequeno text-texto-secundario">{descripcion}</span>
        )}
      </span>
    </label>
  );
}

/**
 * Indicador cuadrado de 20 px con punto de 10 px. Lee el estado del input
 * hermano mediante `group-has-checked`, así que debe ir dentro de un `group`.
 */
export function IndicadorCuadrado({ deshabilitado }: { deshabilitado?: boolean }) {
  return (
    <span
      aria-hidden
      className={unirClases(
        "relative size-5 shrink-0 border-[1.5px] border-borde-fuerte group-has-checked:border-borde-foco",
        deshabilitado ? "bg-fondo-deshabilitado" : "bg-fondo-superficie",
      )}
    >
      <span className="absolute top-[3.5px] left-[3.5px] hidden size-2.5 bg-fondo-marca group-has-checked:block" />
    </span>
  );
}
