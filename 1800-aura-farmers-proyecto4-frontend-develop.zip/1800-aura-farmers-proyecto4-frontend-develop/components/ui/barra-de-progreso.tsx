import { unirClases } from "@/lib/clases";

type BarraDeProgresoProps = {
  /** Avance de 0 a 100. */
  valor: number;
  /** Nombre accesible, por ejemplo «Subiendo fotos». */
  etiqueta: string;
  className?: string;
};

/** Progreso de carga (publicar con fotos, subir documento). 4 px de alto. */
export function BarraDeProgreso({ valor, etiqueta, className }: BarraDeProgresoProps) {
  const avance = Math.min(100, Math.max(0, valor));
  return (
    <div
      role="progressbar"
      aria-label={etiqueta}
      aria-valuemin={0}
      aria-valuemax={100}
      aria-valuenow={Math.round(avance)}
      className={unirClases("h-1 w-full bg-fondo-sutil", className)}
    >
      <div className="h-full bg-fondo-marca transition-[width]" style={{ width: `${avance}%` }} />
    </div>
  );
}
