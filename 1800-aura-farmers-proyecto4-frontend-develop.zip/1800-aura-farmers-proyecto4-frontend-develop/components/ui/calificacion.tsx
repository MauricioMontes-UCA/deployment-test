"use client";

import { useId, useState } from "react";
import { unirClases } from "@/lib/clases";
import { Icono } from "./icono";

const ESTRELLAS = [1, 2, 3, 4, 5] as const;

const formatoValor = new Intl.NumberFormat("es", { maximumFractionDigits: 1 });

type CalificacionProps = {
  /**
   * De 0 a 5. 0 es «sin selección». En solo lectura acepta decimales (el
   * promedio de un bien): se dibuja redondeado a la media estrella más cercana.
   */
  valor: number;
  /** Si se pasa, la calificación es editable (H15, H16). */
  onCambiar?: (valor: number) => void;
  /** Nombre del grupo de radios cuando es editable, para enviarlo en un form. */
  name?: string;
  /** Nombre accesible del grupo, por ejemplo «Calificación del bien». */
  etiqueta?: string;
  className?: string;
};

/**
 * Visualización y selector de 1 a 5 estrellas. Llenas en oliva dorado,
 * vacías en dorado arena. Editable, es un grupo de radios nativos: se maneja
 * con las flechas del teclado.
 */
export function Calificacion({
  valor,
  onCambiar,
  name,
  etiqueta = "Calificación",
  className,
}: CalificacionProps) {
  const idGrupo = useId();
  const [previa, setPrevia] = useState<number | null>(null);
  const mostrado = previa ?? valor;

  if (!onCambiar) {
    const redondeado = Math.round(valor * 2) / 2;
    return (
      <span
        role="img"
        aria-label={`${formatoValor.format(valor)} de 5 estrellas`}
        className={unirClases("inline-flex gap-espacio-1", className)}
      >
        {ESTRELLAS.map((estrella) =>
          estrella - 0.5 === redondeado ? (
            <MediaEstrella key={estrella} />
          ) : (
            <Estrella key={estrella} llena={estrella <= redondeado} />
          ),
        )}
      </span>
    );
  }

  return (
    <div
      role="radiogroup"
      aria-label={etiqueta}
      onPointerLeave={() => setPrevia(null)}
      className={unirClases("inline-flex gap-espacio-1", className)}
    >
      {ESTRELLAS.map((estrella) => (
        <label
          key={estrella}
          onPointerEnter={() => setPrevia(estrella)}
          className="cursor-pointer has-focus-visible:outline-2 has-focus-visible:outline-borde-foco"
        >
          <input
            type="radio"
            name={name ?? idGrupo}
            value={estrella}
            checked={valor === estrella}
            onChange={() => onCambiar(estrella)}
            aria-label={estrella === 1 ? "1 estrella" : `${estrella} estrellas`}
            className="solo-lector"
          />
          <Estrella llena={estrella <= mostrado} />
        </label>
      ))}
    </div>
  );
}

/**
 * Media estrella: Figma no tiene ese ícono, así que se superpone la estrella
 * llena, recortada a la mitad izquierda, sobre la vacía.
 */
function MediaEstrella() {
  return (
    <span data-estrella="media" className="relative inline-flex">
      <Estrella llena={false} />
      <span className="absolute inset-y-0 left-0 w-1/2 overflow-hidden">
        <Estrella llena />
      </span>
    </span>
  );
}

function Estrella({ llena }: { llena: boolean }) {
  return (
    <Icono
      nombre={llena ? "estrella-llena" : "estrella"}
      tamano={28}
      className={llena ? "text-fondo-marca" : "text-borde-default"}
    />
  );
}
