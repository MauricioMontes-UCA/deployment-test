import Link from "next/link";
import type { ReactNode } from "react";
import { unirClases } from "@/lib/clases";
import { Icono } from "./icono";
import { Imagen } from "./imagen";

type TarjetaDeBienProps = {
  titulo: string;
  /** Precio ya formateado con su unidad, por ejemplo «$80.00 / día». */
  precio: ReactNode;
  /** «Municipio, Departamento». */
  ubicacion: string;
  foto?: string | null;
  /** Si se pasa, toda la tarjeta enlaza al detalle del bien. */
  href?: string;
  className?: string;
};

/**
 * Resultado de búsqueda (H3): foto principal 1:1, título truncado a dos
 * líneas, precio con unidad y ubicación. El ancho lo define el contenedor; la
 * foto siempre queda cuadrada.
 */
export function TarjetaDeBien({
  titulo,
  precio,
  ubicacion,
  foto,
  href,
  className,
}: TarjetaDeBienProps) {
  const contenido = (
    <>
      <Imagen
        src={foto}
        alt={titulo}
        sizes="(min-width: 768px) 280px, 100vw"
        className="aspect-square w-full"
      />
      <div className="flex w-full flex-col gap-espacio-1">
        <p className="texto-cuerpo-medio line-clamp-2 h-12 text-texto-primario">{titulo}</p>
        <p className="texto-precio text-texto-primario">{precio}</p>
        <p className="flex items-center gap-espacio-1">
          <Icono nombre="ubicacion" tamano={16} className="text-texto-secundario" />
          <span className="texto-cuerpo-pequeno truncate text-texto-secundario">{ubicacion}</span>
        </p>
      </div>
    </>
  );

  const clases = unirClases("flex w-full flex-col gap-espacio-3", className);
  return href ? (
    <Link href={href} className={unirClases(clases, "group hover:[&_p:first-child]:underline")}>
      {contenido}
    </Link>
  ) : (
    <article className={clases}>{contenido}</article>
  );
}

/** Estado de carga de la tarjeta de bien. */
export function TarjetaDeBienEsqueleto({ className }: { className?: string }) {
  return (
    <div
      aria-hidden
      className={unirClases("flex w-full animate-pulse flex-col gap-espacio-3", className)}
    >
      <div className="aspect-square w-full bg-fondo-sutil" />
      <div className="h-4 w-[86%] bg-fondo-sutil" />
      <div className="h-4 w-[57%] bg-fondo-sutil" />
      <div className="h-5 w-[36%] bg-fondo-sutil" />
      <div className="h-3 w-[64%] bg-fondo-sutil" />
    </div>
  );
}
