import type { ReactNode } from "react";
import { unirClases } from "@/lib/clases";

type EncabezadoDePaginaProps = {
  titulo: ReactNode;
  /** Módulo o migas, en mayúsculas y color oliva. */
  sobretitulo?: ReactNode;
  descripcion?: ReactNode;
  className?: string;
};

/**
 * Encabezado de pantalla: sobretítulo, título serif (H1) y descripción. Va
 * dentro de un `Contenedor` para respetar los márgenes de 64 y 16 px.
 */
export function EncabezadoDePagina({
  titulo,
  sobretitulo,
  descripcion,
  className,
}: EncabezadoDePaginaProps) {
  return (
    <header className={unirClases("flex w-full flex-col items-start gap-espacio-2", className)}>
      {sobretitulo && <p className="texto-sobretitulo text-texto-acento">{sobretitulo}</p>}
      <h1 className="texto-h1 text-texto-primario">{titulo}</h1>
      {descripcion && <p className="texto-cuerpo-grande text-texto-secundario">{descripcion}</p>}
    </header>
  );
}
