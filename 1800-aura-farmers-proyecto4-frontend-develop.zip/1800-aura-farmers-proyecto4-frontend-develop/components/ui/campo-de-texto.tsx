"use client";

import { useId, useState, type ComponentPropsWithoutRef, type ReactNode } from "react";
import { unirClases } from "@/lib/clases";
import { AyudaCampo, EncabezadoCampo, clasesCaja } from "./campo-base";
import { Icono, type IconoNombre } from "./icono";

type CampoDeTextoProps = Omit<ComponentPropsWithoutRef<"input">, "size"> & {
  etiqueta: ReactNode;
  /** Texto de ayuda bajo el campo. */
  ayuda?: ReactNode;
  /** Mensaje de error. Reemplaza a la ayuda y pinta el campo en rojo. */
  error?: ReactNode;
  /**
   * Pinta el campo en rojo sin mensaje propio, para cuando el error se muestra
   * en otro lugar (por ejemplo, debajo de un grupo de campos).
   */
  invalido?: boolean;
  /** Muestra el contador `n/maxLength`. Requiere `maxLength`. */
  contador?: boolean;
  /** Ícono a la izquierda (por ejemplo `buscar` en la búsqueda). */
  icono?: IconoNombre;
};

/**
 * Campo de una línea de Arre, 48 px de alto.
 *
 * Usa el ícono para la búsqueda y el contador para los límites (nombre de
 * usuario n/30, título n/100). El error se escribe donde va la ayuda, en color
 * de error.
 */
export function CampoDeTexto({
  etiqueta,
  ayuda,
  error,
  invalido = false,
  contador,
  icono,
  id,
  className,
  disabled,
  maxLength,
  value,
  defaultValue,
  onChange,
  ...props
}: CampoDeTextoProps) {
  const idGenerado = useId();
  const idCampo = id ?? idGenerado;
  const idAyuda = `${idCampo}-ayuda`;
  const conError = Boolean(error) || invalido;
  const [longitudInterna, setLongitudInterna] = useState(
    String(defaultValue ?? "").length,
  );
  const longitud = value !== undefined ? String(value).length : longitudInterna;
  const textoAyuda = error ?? ayuda;

  return (
    <div className={unirClases("flex w-full flex-col gap-espacio-2", className)}>
      <EncabezadoCampo
        htmlFor={idCampo}
        etiqueta={etiqueta}
        contador={contador && maxLength ? `${longitud}/${maxLength}` : undefined}
        error={conError}
        deshabilitado={disabled}
      />
      <div
        className={unirClases(
          "flex h-12 w-full items-center gap-espacio-3 px-espacio-4",
          clasesCaja({ error: conError, deshabilitado: disabled }),
        )}
      >
        {icono && (
          <Icono
            nombre={icono}
            tamano={20}
            className={disabled ? "text-texto-deshabilitado" : "text-texto-primario"}
          />
        )}
        <input
          id={idCampo}
          disabled={disabled}
          maxLength={maxLength}
          value={value}
          defaultValue={defaultValue}
          aria-invalid={conError || undefined}
          aria-describedby={textoAyuda ? idAyuda : undefined}
          onChange={(evento) => {
            setLongitudInterna(evento.target.value.length);
            onChange?.(evento);
          }}
          className="texto-cuerpo min-w-0 flex-1 bg-transparent text-texto-primario outline-none placeholder:text-texto-secundario disabled:cursor-not-allowed disabled:text-texto-deshabilitado disabled:placeholder:text-texto-deshabilitado"
          {...props}
        />
      </div>
      <AyudaCampo id={idAyuda} texto={textoAyuda} error={conError} deshabilitado={disabled} />
    </div>
  );
}
