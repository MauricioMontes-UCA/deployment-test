import type { ReactNode } from "react";
import { unirClases } from "@/lib/clases";

type NotificacionProps = {
  titulo: string;
  mensaje: ReactNode;
  /** Módulo de origen, por ejemplo «Reservas». */
  modulo: string;
  /** Fecha ya formateada como dd/mm/aaaa hh:mm. */
  fecha: string;
  leida?: boolean;
  /** Acción al abrir la notificación (por ejemplo, marcarla como leída). */
  onAbrir?: () => void;
  className?: string;
};

/**
 * Aviso del centro de notificaciones (H21). Sin leer: superficie marfil,
 * barra lateral y marcador oliva. Leída: fondo base y borde sutil.
 */
export function Notificacion({
  titulo,
  mensaje,
  modulo,
  fecha,
  leida = false,
  onAbrir,
  className,
}: NotificacionProps) {
  const clases = unirClases(
    "flex w-full items-start gap-espacio-4 px-5 py-espacio-4 text-left",
    leida
      ? "border border-borde-sutil bg-fondo-base"
      : "border border-l-4 border-fondo-marca bg-fondo-superficie",
    onAbrir && "cursor-pointer hover:bg-fondo-sutil",
    className,
  );

  const contenido = (
    <>
      <span className="flex pt-espacio-2">
        <span
          aria-hidden
          className={unirClases(
            "size-2 shrink-0",
            leida ? "border border-borde-default" : "bg-fondo-marca",
          )}
        />
      </span>
      <span className="flex min-w-0 flex-1 flex-col gap-espacio-1">
        <span
          className={unirClases(
            "text-texto-primario",
            leida ? "texto-cuerpo" : "texto-cuerpo-medio",
          )}
        >
          {titulo}
        </span>
        <span
          className={unirClases(
            "texto-cuerpo-pequeno",
            leida ? "text-texto-secundario" : "text-texto-primario",
          )}
        >
          {mensaje}
        </span>
        <span className="texto-etiqueta-pequena flex flex-wrap items-center gap-espacio-3 text-texto-secundario">
          <span className="border border-borde-default px-1.5 py-0.5">{modulo}</span>
          <span>{fecha}</span>
          <span className={leida ? undefined : "text-texto-acento"}>
            {leida ? "Leída" : "No leída"}
          </span>
        </span>
      </span>
    </>
  );

  return onAbrir ? (
    <button type="button" onClick={onAbrir} className={clases}>
      {contenido}
    </button>
  ) : (
    <article className={clases}>{contenido}</article>
  );
}
