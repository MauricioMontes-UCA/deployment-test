"use client";

import { useId, useState, type ComponentPropsWithoutRef, type ReactNode } from "react";
import { unirClases } from "@/lib/clases";
import { AyudaCampo, EncabezadoCampo } from "./campo-base";

type AreaDeTextoProps = ComponentPropsWithoutRef<"textarea"> & {
  etiqueta: ReactNode;
  ayuda?: ReactNode;
  /** Mensaje de error. Reemplaza a la ayuda y pinta el campo en rojo. */
  error?: ReactNode;
  /** Muestra el contador `n/maxLength` (n/500, n/1000 o n/2000 según el límite). */
  contador?: boolean;
  /**
   * Límite que se muestra en el contador (`n/limite`) sin cortar la escritura:
   * el texto puede pasarlo para que la pantalla muestre el error (por ejemplo,
   * «supera los 500 caracteres por 12»). Muestra el contador aunque no se pase
   * `contador`. Quién decide si pasarse es un error es la pantalla, con `error`.
   *
   * Si también se pasa `maxLength`, el navegador sigue cortando en `maxLength`
   * (nunca se quita un límite nativo pedido) y el contador muestra `limite`.
   */
  limite?: number;
  /**
   * Cómo se cuentan los caracteres del contador. Por defecto `texto.length`.
   * Sirve para que el contador use el mismo criterio que la validación de la
   * pantalla (por ejemplo, contar un emoji como 1). Solo cambia el número que
   * se muestra: no afecta a `maxLength`, que el navegador sigue aplicando.
   */
  contarCaracteres?: (texto: string) => number;
};

const contarPorDefecto = (texto: string) => texto.length;

/**
 * Campo multilínea de Arre (120 px de alto) para descripción, condiciones,
 * observaciones, justificación y comentarios.
 */
export function AreaDeTexto({
  etiqueta,
  ayuda,
  error,
  contador,
  limite,
  contarCaracteres = contarPorDefecto,
  id,
  className,
  disabled,
  maxLength,
  value,
  defaultValue,
  onChange,
  ...props
}: AreaDeTextoProps) {
  const idGenerado = useId();
  const idCampo = id ?? idGenerado;
  const idAyuda = `${idCampo}-ayuda`;
  const conError = Boolean(error);
  // Sin `value` (no controlado) se guarda el texto para poder contarlo con `contarCaracteres`.
  const [textoInterno, setTextoInterno] = useState(String(defaultValue ?? ""));
  const longitud = contarCaracteres(value !== undefined ? String(value) : textoInterno);
  const textoAyuda = error ?? ayuda;
  // `limite` manda en el contador; sin él, se conserva el `n/maxLength` de siempre.
  const textoContador = limite
    ? `${longitud}/${limite}`
    : contador && maxLength
      ? `${longitud}/${maxLength}`
      : undefined;

  return (
    <div className={unirClases("flex w-full flex-col gap-espacio-2", className)}>
      <EncabezadoCampo
        htmlFor={idCampo}
        etiqueta={etiqueta}
        contador={textoContador}
        error={conError}
        deshabilitado={disabled}
      />
      <textarea
        id={idCampo}
        disabled={disabled}
        maxLength={maxLength}
        value={value}
        defaultValue={defaultValue}
        aria-invalid={conError || undefined}
        aria-describedby={textoAyuda ? idAyuda : undefined}
        onChange={(evento) => {
          setTextoInterno(evento.target.value);
          onChange?.(evento);
        }}
        className={unirClases(
          "texto-cuerpo h-30 w-full resize-y px-espacio-4 py-espacio-3 text-texto-primario outline-none placeholder:text-texto-secundario disabled:cursor-not-allowed disabled:text-texto-deshabilitado disabled:placeholder:text-texto-deshabilitado",
          disabled
            ? "border border-borde-default bg-fondo-deshabilitado"
            : conError
              ? "border-2 border-borde-error bg-fondo-superficie"
              : "border border-borde-default bg-fondo-superficie focus:border-2 focus:border-borde-foco",
        )}
        {...props}
      />
      <AyudaCampo id={idAyuda} texto={textoAyuda} error={conError} deshabilitado={disabled} />
    </div>
  );
}
