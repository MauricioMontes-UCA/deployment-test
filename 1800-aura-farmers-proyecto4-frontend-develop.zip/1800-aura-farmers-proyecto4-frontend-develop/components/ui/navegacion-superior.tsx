"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { unirClases } from "@/lib/clases";
import { useNoLeidas } from "@/lib/notificaciones/contador";
import { Avatar } from "./avatar";
import { clasesBoton } from "./boton";
import { CampanaDeNotificaciones } from "./campana-de-notificaciones";
import { Contenedor } from "./contenedor";
import { Icono } from "./icono";
import { Logo } from "./logo";

export type RolNavegacion = "visitante" | "arrendatario" | "arrendador";

export type EnlaceNavegacion = { texto: string; href: string };

/**
 * Enlaces por rol según Figma. Las rutas son una propuesta: cada historia las
 * ajusta (o pasa `enlaces`) cuando crea su página.
 */
export const ENLACES_POR_ROL: Record<RolNavegacion, EnlaceNavegacion[]> = {
  visitante: [
    { texto: "Buscar bienes", href: "/" },
    { texto: "Cómo funciona", href: "/como-funciona" },
  ],
  arrendatario: [
    { texto: "Explorar", href: "/" },
    { texto: "Mis reservas", href: "/reservas" },
    { texto: "Mensajes", href: "/mensajes" },
  ],
  arrendador: [
    { texto: "Mis bienes", href: "/mis-bienes" },
    { texto: "Reservas recibidas", href: "/reservas-recibidas" },
    { texto: "Mensajes", href: "/mensajes" },
    { texto: "Reportes", href: "/reportes" },
  ],
};

const NOMBRE_ROL = { arrendatario: "Arrendatario", arrendador: "Arrendador" } as const;

type NavegacionSuperiorProps = {
  rol: RolNavegacion;
  /** Usuario con sesión. No aplica al visitante. */
  nombreUsuario?: string;
  /**
   * Contador de notificaciones no leídas (H21). Sin este valor, la barra usa el
   * contador global del usuario (se consulta cada 30 s); con él, muestra el
   * número dado y no consulta nada (catálogo del design system, pruebas).
   */
  noLeidas?: number;
  /** Acción propia de la campana. Sin ella, la campana lleva a `/notificaciones`. */
  onAbrirNotificaciones?: () => void;
  /** Agrega «Cerrar sesión» al menú del usuario. */
  onCerrarSesion?: () => void;
  /** Reemplaza los enlaces por defecto del rol. */
  enlaces?: EnlaceNavegacion[];
};

/**
 * Barra superior global. Visitante: buscar y acceso. Arrendatario: Explorar,
 * Mis reservas y Mensajes. Arrendador: Mis bienes, Reservas recibidas,
 * Mensajes, Reportes y «Publicar un bien». El enlace activo va subrayado en
 * café tinta. En móvil: logo, campana (o «Ingresar») y menú hamburguesa.
 */
export function NavegacionSuperior({
  rol,
  nombreUsuario,
  noLeidas,
  onAbrirNotificaciones,
  onCerrarSesion,
  enlaces = ENLACES_POR_ROL[rol],
}: NavegacionSuperiorProps) {
  const ruta = usePathname();
  // Se guarda la ruta en la que se abrió el menú móvil: al navegar deja de
  // coincidir con la actual y el menú queda cerrado sin un efecto aparte.
  const [rutaMenu, setRutaMenu] = useState<string | null>(null);
  const menuMovil = rutaMenu === ruta;
  const visitante = rol === "visitante";
  // Contador global (H21): solo con sesión y si no se pasó un valor fijo.
  const contadorGlobal = useNoLeidas(!visitante && noLeidas === undefined ? (nombreUsuario ?? null) : null);
  const sinLeer = noLeidas ?? contadorGlobal ?? 0;

  const enlacesNav = (
    <ul className="flex flex-col gap-espacio-4 md:flex-row md:items-center md:gap-espacio-6">
      {enlaces.map((enlace) => {
        const activo = ruta === enlace.href;
        return (
          <li key={enlace.href}>
            <Link
              href={enlace.href}
              aria-current={activo ? "page" : undefined}
              className={unirClases(
                "whitespace-nowrap",
                activo
                  ? "texto-cuerpo-medio text-texto-primario underline"
                  : "texto-cuerpo text-texto-secundario hover:text-texto-primario",
              )}
            >
              {enlace.texto}
            </Link>
          </li>
        );
      })}
    </ul>
  );

  return (
    <header className="w-full border-b border-borde-sutil bg-fondo-base">
      <Contenedor className="flex h-16 items-center justify-between md:h-18">
        <div className="flex items-center gap-espacio-7">
          <Link href="/" aria-label="Arre, inicio">
            <Logo className="[&>span]:text-[35.2px] [&>span]:leading-[38.4px] md:[&>span]:text-[44px] md:[&>span]:leading-[48px]" />
          </Link>
          <nav aria-label="Principal" className="hidden md:block">
            {enlacesNav}
          </nav>
        </div>

        <div className="flex items-center gap-espacio-2 md:gap-5">
          {visitante ? (
            <>
              <Link href="/login" className={clasesBoton({ jerarquia: "terciario" })}>
                <span className="md:hidden">Ingresar</span>
                <span className="hidden md:inline">Iniciar sesión</span>
              </Link>
              {/* El contenedor oculta el botón en móvil: `hidden` en el propio
                  enlace pierde contra el `inline-flex` de clasesBoton. */}
              <span className="hidden md:contents">
                <Link href="/registro" className={clasesBoton({ jerarquia: "primario" })}>
                  Crear cuenta
                </Link>
              </span>
            </>
          ) : (
            <>
              {rol === "arrendador" && (
                <span className="hidden md:contents">
                  <Link href="/publicar" className={clasesBoton({ jerarquia: "secundario" })}>
                    Publicar un bien
                  </Link>
                </span>
              )}
              {onAbrirNotificaciones ? (
                <CampanaDeNotificaciones noLeidas={sinLeer} onClick={onAbrirNotificaciones} />
              ) : (
                <CampanaDeNotificaciones
                  noLeidas={sinLeer}
                  href="/notificaciones"
                  aria-current={ruta === "/notificaciones" ? "page" : undefined}
                />
              )}
              {nombreUsuario && (
                <MenuUsuario
                  nombreUsuario={nombreUsuario}
                  rol={NOMBRE_ROL[rol]}
                  onCerrarSesion={onCerrarSesion}
                />
              )}
            </>
          )}
          <button
            type="button"
            aria-label={menuMovil ? "Cerrar menú" : "Abrir menú"}
            aria-expanded={menuMovil}
            aria-controls="menu-movil"
            onClick={() => setRutaMenu(menuMovil ? null : ruta)}
            className="inline-flex size-10 cursor-pointer items-center justify-center text-texto-primario md:hidden"
          >
            <Icono nombre={menuMovil ? "cerrar" : "menu"} />
          </button>
        </div>
      </Contenedor>

      {menuMovil && (
        <nav
          id="menu-movil"
          aria-label="Principal"
          className="border-t border-borde-sutil bg-fondo-base md:hidden"
        >
          <Contenedor className="flex flex-col gap-espacio-5 py-espacio-5">
            {enlacesNav}
            {visitante && (
              <Link href="/registro" className={clasesBoton({ className: "w-full" })}>
                Crear cuenta
              </Link>
            )}
            {rol === "arrendador" && (
              <Link
                href="/publicar"
                className={clasesBoton({ jerarquia: "secundario", className: "w-full" })}
              >
                Publicar un bien
              </Link>
            )}
            {!visitante && nombreUsuario && (
              <div className="flex items-center justify-between gap-espacio-3 border-t border-borde-sutil pt-espacio-4">
                <span className="flex items-center gap-espacio-3">
                  <Avatar nombre={nombreUsuario} />
                  <NombreYRol nombreUsuario={nombreUsuario} rol={NOMBRE_ROL[rol]} />
                </span>
                {onCerrarSesion && (
                  <button
                    type="button"
                    onClick={onCerrarSesion}
                    className={clasesBoton({ jerarquia: "terciario" })}
                  >
                    Cerrar sesión
                  </button>
                )}
              </div>
            )}
          </Contenedor>
        </nav>
      )}
    </header>
  );
}

function NombreYRol({ nombreUsuario, rol }: { nombreUsuario: string; rol: string }) {
  return (
    <span className="flex flex-col text-left">
      <span className="texto-etiqueta text-texto-primario">{nombreUsuario}</span>
      <span className="texto-etiqueta-pequena text-texto-secundario">{rol}</span>
    </span>
  );
}

function MenuUsuario({
  nombreUsuario,
  rol,
  onCerrarSesion,
}: {
  nombreUsuario: string;
  rol: string;
  onCerrarSesion?: () => void;
}) {
  const [abierto, setAbierto] = useState(false);
  const raiz = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!abierto) return;
    const alClicFuera = (evento: PointerEvent) => {
      if (!raiz.current?.contains(evento.target as Node)) setAbierto(false);
    };
    const alEscape = (evento: KeyboardEvent) => evento.key === "Escape" && setAbierto(false);
    document.addEventListener("pointerdown", alClicFuera);
    document.addEventListener("keydown", alEscape);
    return () => {
      document.removeEventListener("pointerdown", alClicFuera);
      document.removeEventListener("keydown", alEscape);
    };
  }, [abierto]);

  return (
    <div ref={raiz} className="relative hidden md:block">
      <button
        type="button"
        aria-haspopup="menu"
        aria-expanded={abierto}
        onClick={() => setAbierto((actual) => !actual)}
        className="flex cursor-pointer items-center gap-espacio-3"
      >
        <Avatar nombre={nombreUsuario} />
        <NombreYRol nombreUsuario={nombreUsuario} rol={rol} />
        <Icono nombre="chevron-abajo" tamano={16} className="text-texto-primario" />
      </button>
      {abierto && onCerrarSesion && (
        <div
          role="menu"
          className="absolute top-[calc(100%+8px)] right-0 z-20 min-w-48 border border-borde-default bg-fondo-superficie"
        >
          <button
            type="button"
            role="menuitem"
            onClick={onCerrarSesion}
            className="texto-cuerpo flex w-full cursor-pointer items-center gap-espacio-3 px-espacio-4 py-espacio-3 text-left text-texto-primario hover:bg-fondo-sutil"
          >
            <Icono nombre="salir" tamano={20} />
            Cerrar sesión
          </button>
        </div>
      )}
    </div>
  );
}
