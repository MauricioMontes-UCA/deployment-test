import { unirClases } from "@/lib/clases";

/**
 * Iniciales a partir del nombre de usuario: la primera letra de las dos
 * primeras partes («ana_m» → «AM»), o las dos primeras letras si es una sola
 * palabra («mauricio» → «MA»).
 */
export function inicialesDe(nombre: string): string {
  const partes = nombre.trim().split(/[\s._-]+/).filter(Boolean);
  const iniciales =
    partes.length >= 2 ? partes[0][0] + partes[1][0] : (partes[0] ?? "").slice(0, 2);
  return iniciales.toUpperCase();
}

type AvatarProps = {
  /** Nombre de usuario; se muestra como iniciales. */
  nombre: string;
  tamano?: "pequeno" | "grande";
  className?: string;
};

/**
 * Iniciales del nombre de usuario sobre café oliva. Cuadrado y sin foto: el
 * sistema no guarda fotos de usuario.
 */
export function Avatar({ nombre, tamano = "pequeno", className }: AvatarProps) {
  const grande = tamano === "grande";
  return (
    <span
      role="img"
      aria-label={nombre}
      className={unirClases(
        "inline-flex shrink-0 items-center justify-center bg-fondo-marca-hover text-texto-sobre-marca",
        grande ? "texto-h3 size-14" : "texto-etiqueta size-8",
        className,
      )}
    >
      {inicialesDe(nombre)}
    </span>
  );
}
