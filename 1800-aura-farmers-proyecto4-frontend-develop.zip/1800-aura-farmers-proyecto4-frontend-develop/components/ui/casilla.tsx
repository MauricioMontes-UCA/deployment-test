import type { ComponentPropsWithoutRef, ReactNode } from "react";
import { unirClases } from "@/lib/clases";
import { Icono } from "./icono";

type CasillaProps = Omit<ComponentPropsWithoutRef<"input">, "type"> & {
  texto: ReactNode;
};

/** Casilla de verificación cuadrada de Arre, sobre un checkbox nativo. */
export function Casilla({ texto, className, disabled, ...props }: CasillaProps) {
  return (
    <label
      className={unirClases(
        "group inline-flex items-center gap-espacio-3",
        "has-focus-visible:outline-2 has-focus-visible:outline-offset-2 has-focus-visible:outline-borde-foco",
        disabled ? "cursor-not-allowed opacity-60" : "cursor-pointer",
        className,
      )}
    >
      <input type="checkbox" disabled={disabled} className="solo-lector" {...props} />
      <span
        aria-hidden
        className={unirClases(
          "relative size-5 shrink-0 border-[1.5px] border-borde-fuerte",
          "group-has-checked:border-borde-foco group-has-checked:bg-fondo-marca",
          disabled ? "bg-fondo-deshabilitado" : "bg-fondo-superficie",
        )}
      >
        <Icono
          nombre="check"
          tamano={16}
          className="absolute top-[0.5px] left-[0.5px] hidden text-texto-sobre-marca group-has-checked:block"
        />
      </span>
      <span
        className={unirClases(
          "texto-cuerpo",
          disabled ? "text-texto-deshabilitado" : "text-texto-primario",
        )}
      >
        {texto}
      </span>
    </label>
  );
}
