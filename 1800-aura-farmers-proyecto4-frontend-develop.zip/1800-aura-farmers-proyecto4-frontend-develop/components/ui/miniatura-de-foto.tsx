import { unirClases } from "@/lib/clases";
import { Icono, type IconoNombre } from "./icono";
import { Imagen } from "./imagen";

type MiniaturaDeFotoProps = {
  src: string;
  alt: string;
  principal?: boolean;
  onMarcarPrincipal?: () => void;
  onMoverIzquierda?: () => void;
  onMoverDerecha?: () => void;
  onQuitar?: () => void;
  className?: string;
};

/**
 * Vista previa de una foto subida en el formulario de publicación (H1):
 * reordenar con flechas, marcar como principal (borde oliva) y quitar. Un
 * control sin callback se muestra deshabilitado (por ejemplo, mover a la
 * izquierda la primera foto).
 */
export function MiniaturaDeFoto({
  src,
  alt,
  principal = false,
  onMarcarPrincipal,
  onMoverIzquierda,
  onMoverDerecha,
  onQuitar,
  className,
}: MiniaturaDeFotoProps) {
  return (
    <div className={unirClases("flex w-30 flex-col items-start gap-espacio-2", className)}>
      <div className="relative size-30">
        <Imagen src={src} alt={alt} sizes="120px" className="size-full" />
        {principal && (
          <span aria-hidden className="absolute inset-0 border-3 border-borde-foco" />
        )}
      </div>
      {principal ? (
        <span className="texto-etiqueta-pequena text-texto-acento">Principal</span>
      ) : (
        <button
          type="button"
          onClick={onMarcarPrincipal}
          className="texto-etiqueta-pequena cursor-pointer text-texto-secundario hover:text-texto-primario hover:underline"
        >
          Marcar principal
        </button>
      )}
      <div className="flex gap-espacio-1">
        <Control icono="chevron-izquierda" etiqueta="Mover a la izquierda" onClick={onMoverIzquierda} />
        <Control icono="chevron-derecha" etiqueta="Mover a la derecha" onClick={onMoverDerecha} />
        <Control icono="basura" etiqueta="Quitar foto" onClick={onQuitar} peligro />
      </div>
    </div>
  );
}

function Control({
  icono,
  etiqueta,
  onClick,
  peligro,
}: {
  icono: IconoNombre;
  etiqueta: string;
  onClick?: () => void;
  peligro?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={!onClick}
      aria-label={etiqueta}
      className={unirClases(
        "inline-flex cursor-pointer border border-borde-default p-1.5 hover:bg-fondo-sutil disabled:cursor-not-allowed disabled:opacity-40",
        peligro ? "text-estado-error" : "text-texto-primario",
      )}
    >
      <Icono nombre={icono} tamano={16} />
    </button>
  );
}
