import type { ComponentPropsWithoutRef } from "react";
import { unirClases } from "@/lib/clases";

/**
 * Contenedor de página de Arre: 1312 px de ancho útil en escritorio con
 * márgenes de 64 px, y márgenes de 16 px en móvil (328 px en una pantalla de
 * 360 px).
 */
export function Contenedor({
  className,
  ...props
}: ComponentPropsWithoutRef<"div">) {
  return (
    <div
      className={unirClases(
        "mx-auto w-full max-w-[calc(var(--container-pagina)+2*var(--spacing-espacio-8))] px-espacio-4 md:px-espacio-8",
        className,
      )}
      {...props}
    />
  );
}
