import type { ComponentPropsWithoutRef, ReactNode } from "react";
import { unirClases } from "@/lib/clases";
import { IndicadorCuadrado } from "./opcion-en-tarjeta";

type RadioProps = Omit<ComponentPropsWithoutRef<"input">, "type"> & {
  texto: ReactNode;
};

/**
 * Radio cuadrado para opciones excluyentes en listas (tipo de bien en
 * filtros, acción LIBERAR/RETENER). Agrupa varios con el mismo `name`.
 */
export function Radio({ texto, className, disabled, ...props }: RadioProps) {
  return (
    <label
      className={unirClases(
        "group inline-flex items-center gap-espacio-3",
        "has-focus-visible:outline-2 has-focus-visible:outline-offset-2 has-focus-visible:outline-borde-foco",
        disabled ? "cursor-not-allowed opacity-60" : "cursor-pointer",
        className,
      )}
    >
      <input type="radio" disabled={disabled} className="solo-lector" {...props} />
      <IndicadorCuadrado deshabilitado={disabled} />
      <span
        className={unirClases(
          "texto-cuerpo",
          disabled ? "text-texto-deshabilitado" : "text-texto-primario",
        )}
      >
        {texto}
      </span>
    </label>
  );
}
