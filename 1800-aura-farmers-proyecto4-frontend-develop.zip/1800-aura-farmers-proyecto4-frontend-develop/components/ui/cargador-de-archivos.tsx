"use client";

import { useId, useState, type DragEvent, type ReactNode } from "react";
import { unirClases } from "@/lib/clases";
import { Icono } from "./icono";

type CargadorDeArchivosProps = {
  /** Recibe los archivos elegidos o soltados. La validación es de cada pantalla. */
  onArchivos: (archivos: File[]) => void;
  titulo?: string;
  /** Formatos y límites, por ejemplo «JPG o PNG, máximo 5 MB cada una». */
  ayuda?: ReactNode;
  /** Mensaje de error; reemplaza a la ayuda y pinta el borde en rojo. */
  error?: ReactNode;
  /** Tipos aceptados, como en `<input accept>`: "image/jpeg,image/png". */
  accept?: string;
  multiple?: boolean;
  deshabilitado?: boolean;
  name?: string;
  className?: string;
};

/**
 * Zona para arrastrar o seleccionar archivos: fotos del bien (H1, JPG/PNG de
 * 5 MB, de 1 a 10) y documento de identidad (H17, JPG/PNG/PDF de 5 MB). Borde
 * punteado; al arrastrar encima se pinta en mantequilla.
 */
export function CargadorDeArchivos({
  onArchivos,
  titulo = "Arrastra tus archivos o haz clic para seleccionarlos",
  ayuda,
  error,
  accept,
  multiple = true,
  deshabilitado = false,
  name,
  className,
}: CargadorDeArchivosProps) {
  const id = useId();
  const [arrastrando, setArrastrando] = useState(false);
  const conError = Boolean(error);

  function alSoltar(evento: DragEvent<HTMLLabelElement>) {
    evento.preventDefault();
    setArrastrando(false);
    if (deshabilitado) return;
    const archivos = Array.from(evento.dataTransfer.files);
    if (archivos.length) onArchivos(multiple ? archivos : archivos.slice(0, 1));
  }

  return (
    <label
      htmlFor={id}
      onDragOver={(evento) => {
        evento.preventDefault();
        if (!deshabilitado) setArrastrando(true);
      }}
      onDragLeave={() => setArrastrando(false)}
      onDrop={alSoltar}
      className={unirClases(
        "flex h-40 w-full flex-col items-center justify-center gap-espacio-2 border-[1.5px] border-dashed px-espacio-4 text-center",
        "has-focus-visible:outline-2 has-focus-visible:outline-offset-2 has-focus-visible:outline-borde-foco",
        arrastrando
          ? "border-borde-foco bg-fondo-acento"
          : conError
            ? "border-borde-error bg-fondo-superficie"
            : "border-borde-default bg-fondo-superficie",
        deshabilitado ? "cursor-not-allowed opacity-60" : "cursor-pointer",
        className,
      )}
    >
      <input
        id={id}
        type="file"
        name={name}
        accept={accept}
        multiple={multiple}
        disabled={deshabilitado}
        aria-invalid={conError || undefined}
        className="solo-lector"
        onChange={(evento) => {
          const archivos = Array.from(evento.target.files ?? []);
          if (archivos.length) onArchivos(archivos);
          // Permite volver a elegir el mismo archivo después de quitarlo.
          evento.target.value = "";
        }}
      />
      <Icono
        nombre="subir"
        tamano={28}
        className={conError && !arrastrando ? "text-estado-error" : "text-texto-acento"}
      />
      <span className="texto-cuerpo-medio text-texto-primario">
        {arrastrando ? "Suelta los archivos aquí" : titulo}
      </span>
      {(error ?? ayuda) && (
        <span
          className={unirClases(
            "texto-cuerpo-pequeno",
            conError && !arrastrando ? "text-texto-error" : "text-texto-secundario",
          )}
        >
          {arrastrando ? ayuda : (error ?? ayuda)}
        </span>
      )}
    </label>
  );
}
