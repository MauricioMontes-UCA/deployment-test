import type { ReactNode } from "react";
import { unirClases } from "@/lib/clases";
import { Icono, type IconoNombre } from "./icono";

export type TipoEstadoDePagina = "vacio" | "error" | "sin-permiso" | "no-encontrado" | "cargando";

const POR_TIPO: Record<TipoEstadoDePagina, { icono: IconoNombre; titulo: string; mensaje: string }> = {
  vacio: {
    icono: "bienes",
    titulo: "Aún no tienes reservas",
    mensaje: "Cuando solicites un bien, lo verás aquí con su estado.",
  },
  error: {
    icono: "alerta",
    titulo: "No pudimos cargar la información",
    mensaje: "Revisa tu conexión e intenta de nuevo.",
  },
  "sin-permiso": {
    icono: "candado",
    titulo: "No tienes acceso a este panel.",
    mensaje: "Esta sección es solo para arrendadores.",
  },
  "no-encontrado": {
    icono: "buscar",
    titulo: "Esta publicación ya no está disponible.",
    mensaje: "Es posible que el arrendador la haya retirado.",
  },
  cargando: {
    icono: "cargando",
    titulo: "Cargando…",
    mensaje: "Esto puede tardar unos segundos.",
  },
};

type EstadoDePaginaProps = {
  tipo: TipoEstadoDePagina;
  /** Reemplaza el título de ejemplo de Figma. */
  titulo?: ReactNode;
  mensaje?: ReactNode;
  /**
   * Acción opcional. Figma usa Primario en Vacío y Secundario en Error, Sin
   * permiso y No encontrado. Cargando no lleva acción.
   */
  accion?: ReactNode;
  /** Ícono distinto al del tipo (por ejemplo `mensaje` en una bandeja vacía). */
  icono?: IconoNombre;
  className?: string;
};

/**
 * Estado de pantalla completa o de sección: vacío, error con reintento, sin
 * permiso (rol incorrecto), no encontrado (404) y cargando. Título, mensaje y
 * acción cambian según la pantalla.
 */
export function EstadoDePagina({
  tipo,
  titulo,
  mensaje,
  accion,
  icono,
  className,
}: EstadoDePaginaProps) {
  const base = POR_TIPO[tipo];
  const cargando = tipo === "cargando";
  return (
    <section
      role={cargando ? "status" : tipo === "error" ? "alert" : undefined}
      aria-busy={cargando || undefined}
      className={unirClases(
        "flex w-full flex-col items-center gap-espacio-3 border border-borde-sutil bg-fondo-superficie px-espacio-6 py-espacio-7 text-center",
        className,
      )}
    >
      <span className={unirClases("flex p-3.5", tipo === "error" ? "bg-fondo-error" : "bg-fondo-sutil")}>
        <Icono
          nombre={icono ?? base.icono}
          tamano={28}
          className={unirClases(
            tipo === "error" ? "text-estado-error" : "text-texto-primario",
            cargando && "animate-spin",
          )}
        />
      </span>
      <h2 className="texto-h3 text-texto-primario">{titulo ?? base.titulo}</h2>
      <p className="texto-cuerpo text-texto-secundario">{mensaje ?? base.mensaje}</p>
      {accion && !cargando && <div className="pt-espacio-2">{accion}</div>}
    </section>
  );
}
