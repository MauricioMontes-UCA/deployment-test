import { unirClases } from "@/lib/clases";

type LogoProps = {
  /** Claro para superficies crema; Oscuro para el pie de página en café tinta. */
  fondo?: "claro" | "oscuro";
  /** «Con lema» para portada y pie; «Solo nombre» para la barra de navegación. */
  version?: "solo-nombre" | "con-lema";
  className?: string;
};

/** Logotipo de Arre en Great Vibes, con el lema «Renta con confianza» opcional. */
export function Logo({
  fondo = "claro",
  version = "solo-nombre",
  className,
}: LogoProps) {
  const oscuro = fondo === "oscuro";
  const conLema = version === "con-lema";
  const colorLinea = oscuro ? "bg-texto-inverso-secundario" : "bg-borde-default";

  return (
    <div
      className={unirClases(
        "inline-flex flex-col",
        conLema ? "items-center gap-0.5 pb-1" : "items-start",
        className,
      )}
    >
      <span
        className={unirClases(
          "texto-logo whitespace-nowrap",
          oscuro ? "text-texto-inverso" : "text-texto-acento",
        )}
      >
        Arre
      </span>
      {conLema && (
        <span className="flex items-center gap-espacio-2">
          <span className={unirClases("h-px w-4", colorLinea)} />
          <span
            className={unirClases(
              "text-[9px] font-semibold uppercase tracking-[0.24em] whitespace-nowrap",
              oscuro ? "text-texto-inverso-secundario" : "text-texto-secundario",
            )}
          >
            Renta con confianza
          </span>
          <span className={unirClases("h-px w-4", colorLinea)} />
        </span>
      )}
    </div>
  );
}
