import type { ReactNode } from "react";
import { unirClases } from "@/lib/clases";
import { Icono, type IconoNombre } from "./icono";

export type TonoAlerta = "exito" | "advertencia" | "error" | "info";

const ESTILO: Record<TonoAlerta, { caja: string; icono: IconoNombre; color: string }> = {
  exito: { caja: "border-estado-exito bg-fondo-exito", icono: "check", color: "text-estado-exito" },
  advertencia: {
    caja: "border-estado-advertencia bg-fondo-advertencia",
    icono: "alerta",
    color: "text-estado-advertencia",
  },
  error: { caja: "border-estado-error bg-fondo-error", icono: "alerta", color: "text-estado-error" },
  info: { caja: "border-estado-info bg-fondo-info", icono: "info", color: "text-estado-info" },
};

type AlertaProps = {
  tono?: TonoAlerta;
  titulo?: ReactNode;
  children: ReactNode;
  className?: string;
};

/**
 * Mensaje en línea de éxito, advertencia, error o información (respuestas del
 * servidor, estados de cola, avisos de permisos). Ancho ajustable; el texto va
 * en café tinta y el color en la barra lateral y el ícono.
 *
 * Los errores usan `role="alert"` para que el lector de pantalla los anuncie de
 * inmediato; los demás tonos, `role="status"`.
 */
export function Alerta({ tono = "info", titulo, children, className }: AlertaProps) {
  const estilo = ESTILO[tono];
  return (
    <div
      role={tono === "error" ? "alert" : "status"}
      className={unirClases(
        "flex w-full items-start gap-espacio-3 border-l-4 px-espacio-4 py-3.5",
        estilo.caja,
        className,
      )}
    >
      <Icono nombre={estilo.icono} tamano={20} className={estilo.color} />
      <div className="flex min-w-0 flex-1 flex-col gap-0.5 text-texto-primario">
        {titulo && <p className="texto-cuerpo-medio">{titulo}</p>}
        <div className="texto-cuerpo-pequeno">{children}</div>
      </div>
    </div>
  );
}
