import type { ReactNode } from "react";
import { unirClases } from "@/lib/clases";

export type TonoInsignia = "neutro" | "marca" | "exito" | "advertencia" | "error" | "info";

const FONDO: Record<TonoInsignia, string> = {
  neutro: "bg-fondo-sutil",
  marca: "bg-fondo-acento",
  exito: "bg-fondo-exito",
  advertencia: "bg-fondo-advertencia",
  error: "bg-fondo-error",
  info: "bg-fondo-info",
};

const MARCADOR: Record<TonoInsignia, string> = {
  neutro: "bg-borde-fuerte",
  marca: "bg-fondo-marca",
  exito: "bg-estado-exito",
  advertencia: "bg-estado-advertencia",
  error: "bg-estado-error",
  info: "bg-estado-info",
};

/**
 * Tono de cada estado que devuelve el backend, según la guía de Figma. Así
 * todas las pantallas pintan igual una reserva CONFIRMADA o un depósito
 * RETENIDO.
 */
export const TONO_POR_ESTADO: Record<string, TonoInsignia> = {
  EN_COLA: "neutro",
  CONFIRMADA: "exito",
  EN_CURSO: "marca",
  FINALIZADA: "neutro",
  RECHAZADA: "error",
  PENDIENTE: "advertencia",
  LIBERADO: "exito",
  RETENIDO: "error",
  PARCIALMENTE_RETENIDO: "advertencia",
  EN_REVISION: "info",
  VERIFICADO: "exito",
};

type InsigniaDeEstadoProps = {
  texto: ReactNode;
  tono?: TonoInsignia;
  className?: string;
};

/**
 * Estado de reservas, pagos, depósitos, verificación y notificaciones. El
 * texto va siempre en café tinta; el color va en el fondo y en el marcador.
 */
export function InsigniaDeEstado({ texto, tono = "neutro", className }: InsigniaDeEstadoProps) {
  return (
    <span
      className={unirClases(
        "inline-flex items-center gap-1.5 py-espacio-1 pr-2.5 pl-espacio-2",
        FONDO[tono],
        className,
      )}
    >
      <span aria-hidden className={unirClases("size-1.5 shrink-0", MARCADOR[tono])} />
      <span className="texto-etiqueta-pequena whitespace-nowrap text-texto-primario">{texto}</span>
    </span>
  );
}
