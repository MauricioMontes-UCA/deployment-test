import Link from "next/link";
import { unirClases } from "@/lib/clases";
import { Avatar } from "./avatar";

type ConversacionProps = {
  /** Nombre de usuario del otro participante. */
  usuario: string;
  /** Bien y tipo de conversación: «Cámara profesional Canon EOS · Consulta». */
  bien: string;
  hora: string;
  ultimoMensaje: string;
  activa?: boolean;
  href: string;
  className?: string;
};

/**
 * Elemento de la bandeja de mensajes: otro participante, bien, tipo (Consulta
 * o Entrega) y último mensaje. La activa se marca en mantequilla con barra
 * oliva a la izquierda.
 */
export function Conversacion({
  usuario,
  bien,
  hora,
  ultimoMensaje,
  activa = false,
  href,
  className,
}: ConversacionProps) {
  return (
    <Link
      href={href}
      aria-current={activa ? "page" : undefined}
      className={unirClases(
        "flex w-full items-start gap-espacio-3 border-b px-espacio-4 py-3.5",
        activa
          ? "border-l-3 border-fondo-marca bg-fondo-acento"
          : "border-borde-sutil bg-fondo-superficie hover:bg-fondo-sutil",
        className,
      )}
    >
      <Avatar nombre={usuario} />
      <span className="flex min-w-0 flex-1 flex-col gap-0.5">
        <span className="flex items-start justify-between gap-espacio-2">
          <span className="texto-etiqueta truncate text-texto-primario">{usuario}</span>
          <span className="texto-etiqueta-pequena shrink-0 text-texto-secundario">{hora}</span>
        </span>
        <span className="texto-etiqueta-pequena truncate text-texto-acento">{bien}</span>
        <span className="texto-cuerpo-pequeno truncate text-texto-secundario">{ultimoMensaje}</span>
      </span>
    </Link>
  );
}
