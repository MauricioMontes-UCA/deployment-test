"use client";

import NextImage from "next/image";
import { useState } from "react";
import { unirClases } from "@/lib/clases";
import { Icono } from "./icono";

type ImagenProps = {
  /** URL de la foto. Si falta o no carga, se muestra «Foto no disponible». */
  src?: string | null;
  alt: string;
  /** Tamaños para `next/image` (la imagen llena su contenedor). */
  sizes?: string;
  prioridad?: boolean;
  /**
   * Sin foto, muestra solo el ícono centrado (el texto queda para lectores de
   * pantalla). Para miniaturas donde «Foto no disponible» no cabe.
   */
  compacta?: boolean;
  className?: string;
};

/**
 * Foto de un bien. Llena su contenedor con `object-cover` (FILL en Figma), así
 * que el tamaño lo define `className`. Cuando no hay foto o falla la carga,
 * muestra el reemplazo «No disponible» (H2).
 */
export function Imagen({ src, alt, sizes = "100vw", prioridad, compacta = false, className }: ImagenProps) {
  const [fallo, setFallo] = useState(false);
  const disponible = Boolean(src) && !fallo;

  return (
    <div
      className={unirClases(
        "relative overflow-hidden",
        !disponible && "flex flex-col items-center justify-center gap-espacio-2 bg-fondo-sutil",
        className,
      )}
    >
      {disponible ? (
        <NextImage
          src={src!}
          alt={alt}
          fill
          sizes={sizes}
          priority={prioridad}
          className="object-cover"
          onError={() => setFallo(true)}
        />
      ) : (
        <>
          <Icono nombre="imagen" className="text-texto-primario" />
          <span className={compacta ? "sr-only" : "texto-etiqueta-pequena text-texto-secundario"}>
            Foto no disponible
          </span>
        </>
      )}
    </div>
  );
}
