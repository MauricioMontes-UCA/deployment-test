import { unirClases } from "@/lib/clases";

export type EstadoDia =
  | "disponible"
  | "hoy"
  | "seleccionado"
  | "en-rango"
  | "reservado"
  | "bloqueado"
  | "pasado";

const ESTILO: Record<EstadoDia, string> = {
  disponible: "texto-cuerpo-pequeno bg-fondo-superficie text-texto-primario hover:bg-fondo-sutil",
  hoy: "texto-etiqueta border-[1.5px] border-borde-fuerte bg-fondo-superficie text-texto-primario hover:bg-fondo-sutil",
  seleccionado: "texto-etiqueta bg-fondo-marca text-texto-sobre-marca",
  "en-rango": "texto-cuerpo-pequeno bg-fondo-acento text-texto-primario",
  reservado: "texto-cuerpo-pequeno bg-fondo-error text-texto-error",
  bloqueado: "texto-cuerpo-pequeno bg-fondo-sutil text-texto-secundario",
  pasado: "texto-cuerpo-pequeno bg-fondo-base text-texto-deshabilitado",
};

/** Estados en los que el día no se puede elegir. */
const NO_SELECCIONABLE: EstadoDia[] = ["reservado", "bloqueado", "pasado"];

type DiaDeCalendarioProps = {
  dia: number;
  estado?: EstadoDia;
  /** Fecha completa para lectores de pantalla, por ejemplo «14 de noviembre de 2026». */
  etiqueta: string;
  onSeleccionar?: () => void;
  className?: string;
};

/**
 * Celda de 44×44 del calendario de disponibilidad (H5, H7). Seleccionado
 * marca el inicio y el fin; En rango, los días intermedios. Reservado,
 * Bloqueado (con trama diagonal) y Pasado no se pueden elegir.
 */
export function DiaDeCalendario({
  dia,
  estado = "disponible",
  etiqueta,
  onSeleccionar,
  className,
}: DiaDeCalendarioProps) {
  const deshabilitado = NO_SELECCIONABLE.includes(estado);
  return (
    <button
      type="button"
      disabled={deshabilitado}
      onClick={onSeleccionar}
      aria-label={etiqueta}
      aria-pressed={estado === "seleccionado" || estado === "en-rango"}
      aria-current={estado === "hoy" ? "date" : undefined}
      className={unirClases(
        "relative flex size-11 items-center justify-center overflow-hidden",
        deshabilitado ? "cursor-not-allowed" : "cursor-pointer",
        ESTILO[estado],
        className,
      )}
    >
      {dia}
      {estado === "bloqueado" && (
        <span
          aria-hidden
          className="absolute top-1/2 left-1/2 h-px w-[52px] -translate-x-1/2 -translate-y-1/2 -rotate-45 bg-borde-default"
        />
      )}
    </button>
  );
}
