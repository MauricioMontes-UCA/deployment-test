import type { ComponentPropsWithRef } from "react";
import { unirClases } from "@/lib/clases";
import { Icono, type IconoNombre } from "./icono";

export type JerarquiaBoton = "primario" | "secundario" | "terciario" | "peligro";

const POR_JERARQUIA: Record<JerarquiaBoton, string> = {
  primario:
    "px-espacio-5 bg-fondo-marca text-texto-sobre-marca hover:bg-fondo-marca-hover",
  secundario:
    "px-espacio-5 border border-borde-fuerte text-texto-primario hover:bg-fondo-sutil",
  terciario: "px-espacio-1 text-texto-acento hover:text-texto-secundario",
  peligro:
    "px-espacio-5 border border-transparent bg-estado-error text-texto-sobre-marca hover:border-estado-error hover:bg-fondo-error hover:text-texto-error",
};

const DESHABILITADO: Record<JerarquiaBoton, string> = {
  primario: "px-espacio-5 bg-fondo-deshabilitado text-texto-deshabilitado",
  secundario: "px-espacio-5 bg-fondo-deshabilitado text-texto-deshabilitado",
  terciario: "px-espacio-1 text-texto-deshabilitado",
  peligro: "px-espacio-5 bg-fondo-deshabilitado text-texto-deshabilitado",
};

const CARGANDO: Record<JerarquiaBoton, string> = {
  primario: "px-espacio-5 bg-fondo-marca text-texto-sobre-marca opacity-85",
  secundario: "px-espacio-5 border border-borde-fuerte text-texto-primario opacity-85",
  terciario: "px-espacio-1 text-texto-acento opacity-85",
  peligro: "px-espacio-5 bg-estado-error text-texto-sobre-marca opacity-85",
};

/**
 * Clases del botón de Arre, para aplicarlas a otro elemento (por ejemplo un
 * `<Link>` que debe verse como botón).
 */
export function clasesBoton({
  jerarquia = "primario",
  deshabilitado = false,
  cargando = false,
  className,
}: {
  jerarquia?: JerarquiaBoton;
  deshabilitado?: boolean;
  cargando?: boolean;
  className?: string;
} = {}) {
  return unirClases(
    "texto-boton inline-flex h-12 items-center justify-center gap-espacio-2 whitespace-nowrap transition-colors",
    cargando
      ? unirClases(CARGANDO[jerarquia], "cursor-progress")
      : deshabilitado
        ? unirClases(DESHABILITADO[jerarquia], "cursor-not-allowed")
        : unirClases(POR_JERARQUIA[jerarquia], "cursor-pointer"),
    className,
  );
}

type BotonProps = ComponentPropsWithRef<"button"> & {
  jerarquia?: JerarquiaBoton;
  /** Muestra «Procesando…» y bloquea el doble envío. */
  cargando?: boolean;
  icono?: IconoNombre;
};

/**
 * Botón de Arre. Sin esquinas redondeadas y 48 px de alto.
 *
 * Primario: acción principal (una por pantalla). Secundario: acciones
 * alternativas. Terciario: acciones de bajo peso o enlaces. Peligro: acciones
 * destructivas (eliminar bloqueo, retener depósito).
 */
export function Boton({
  jerarquia = "primario",
  cargando = false,
  icono,
  disabled,
  className,
  children,
  type = "button",
  ...props
}: BotonProps) {
  return (
    <button
      type={type}
      disabled={disabled || cargando}
      aria-busy={cargando || undefined}
      className={clasesBoton({ jerarquia, deshabilitado: disabled, cargando, className })}
      {...props}
    >
      {cargando ? (
        <>
          <Icono nombre="cargando" tamano={20} className="animate-spin" />
          Procesando…
        </>
      ) : (
        <>
          {icono && <Icono nombre={icono} tamano={20} />}
          {children}
        </>
      )}
    </button>
  );
}
