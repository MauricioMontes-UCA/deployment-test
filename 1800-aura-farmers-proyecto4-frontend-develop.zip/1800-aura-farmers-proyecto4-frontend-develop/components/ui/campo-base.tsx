import type { ReactNode } from "react";
import { unirClases } from "@/lib/clases";

/**
 * Piezas compartidas por los campos de formulario (campo de texto, área de
 * texto y selector): el encabezado con etiqueta y contador, y el texto de
 * ayuda, que en Figma también es donde se escribe el error.
 */

type EncabezadoCampoProps = {
  htmlFor?: string;
  id?: string;
  etiqueta: ReactNode;
  contador?: string;
  error?: boolean;
  deshabilitado?: boolean;
};

export function EncabezadoCampo({
  htmlFor,
  id,
  etiqueta,
  contador,
  error,
  deshabilitado,
}: EncabezadoCampoProps) {
  return (
    <div className="flex w-full items-center gap-espacio-2">
      <label
        htmlFor={htmlFor}
        id={id}
        className={unirClases(
          "texto-etiqueta min-w-0 flex-1",
          deshabilitado ? "text-texto-deshabilitado" : "text-texto-primario",
        )}
      >
        {etiqueta}
      </label>
      {contador && (
        <span
          aria-hidden
          className={unirClases(
            "texto-etiqueta-pequena shrink-0 whitespace-nowrap",
            error && !deshabilitado ? "text-texto-error" : "text-texto-secundario",
          )}
        >
          {contador}
        </span>
      )}
    </div>
  );
}

type AyudaCampoProps = {
  id: string;
  texto?: ReactNode;
  error?: boolean;
  deshabilitado?: boolean;
};

export function AyudaCampo({ id, texto, error, deshabilitado }: AyudaCampoProps) {
  if (!texto) return null;
  return (
    <p
      id={id}
      className={unirClases(
        "texto-cuerpo-pequeno w-full",
        deshabilitado
          ? "text-texto-deshabilitado"
          : error
            ? "text-texto-error"
            : "text-texto-secundario",
      )}
    >
      {texto}
    </p>
  );
}

/** Clases de la caja de un campo según su estado (el foco sale de CSS). */
export function clasesCaja({
  error,
  deshabilitado,
}: {
  error?: boolean;
  deshabilitado?: boolean;
}) {
  if (deshabilitado) return "border border-borde-default bg-fondo-deshabilitado";
  if (error) return "border-2 border-borde-error bg-fondo-superficie";
  return "border border-borde-default bg-fondo-superficie focus-within:border-2 focus-within:border-borde-foco";
}
