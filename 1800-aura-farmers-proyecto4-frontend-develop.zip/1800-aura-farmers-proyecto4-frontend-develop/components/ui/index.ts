/**
 * Design System «Arre». Importar desde aquí:
 * `import { Boton, CampoDeTexto } from "@/components/ui";`
 */

// Estructura y marca
export { Contenedor } from "./contenedor";
export { Icono, NOMBRES_ICONO, type IconoNombre } from "./icono";
export { Logo } from "./logo";
export { Imagen } from "./imagen";

// Formularios
export { Boton, clasesBoton, type JerarquiaBoton } from "./boton";
export { CampoDeTexto } from "./campo-de-texto";
export { AreaDeTexto } from "./area-de-texto";
export { Selector, type OpcionSelector } from "./selector";

// Selección e indicadores
export { OpcionEnTarjeta } from "./opcion-en-tarjeta";
export { Radio } from "./radio";
export { Casilla } from "./casilla";
export { Interruptor } from "./interruptor";
export {
  InsigniaDeEstado,
  TONO_POR_ESTADO,
  type TonoInsignia,
} from "./insignia-de-estado";
export { ChipDeFiltro } from "./chip-de-filtro";
export { Alerta, type TonoAlerta } from "./alerta";
export { Pestanas, Pestana, PanelDePestana } from "./pestanas";
export { Avatar, inicialesDe } from "./avatar";
export { CampanaDeNotificaciones } from "./campana-de-notificaciones";
export { BarraDeProgreso } from "./barra-de-progreso";

// Contenido
export { TarjetaDeBien, TarjetaDeBienEsqueleto } from "./tarjeta-de-bien";
export { Notificacion } from "./notificacion";
export { DiaDeCalendario, type EstadoDia } from "./dia-de-calendario";
export { Calificacion } from "./calificacion";
export { Mensaje } from "./mensaje";
export {
  Tabla,
  TablaEncabezado,
  TablaCelda,
  type OrdenTabla,
} from "./tabla";

// Navegación y estructura
export {
  NavegacionSuperior,
  ENLACES_POR_ROL,
  type RolNavegacion,
  type EnlaceNavegacion,
} from "./navegacion-superior";
export { PieDePagina } from "./pie-de-pagina";

// Composición
export { DialogoDeConfirmacion } from "./dialogo-de-confirmacion";
export { CargadorDeArchivos } from "./cargador-de-archivos";
export { MiniaturaDeFoto } from "./miniatura-de-foto";
export { TarjetaDeReserva } from "./tarjeta-de-reserva";
export { Conversacion } from "./conversacion";

// Patrones
export { EstadoDePagina, type TipoEstadoDePagina } from "./estado-de-pagina";
export {
  SelectorDePeriodo,
  OPCIONES_PERIODO,
  type PeriodoReporte,
} from "./selector-de-periodo";
export { MesDeCalendario, fechaISO } from "./mes-de-calendario";
export { LeyendaDeCalendario } from "./leyenda-de-calendario";
export { EncabezadoDePagina } from "./encabezado-de-pagina";
