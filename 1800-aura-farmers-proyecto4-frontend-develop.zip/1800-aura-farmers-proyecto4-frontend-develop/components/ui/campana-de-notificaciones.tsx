import Link from "next/link";
import type { ComponentPropsWithoutRef } from "react";
import { unirClases } from "@/lib/clases";
import { Icono } from "./icono";

type Comun = {
  /** Notificaciones no leídas. Con 0 no hay insignia; más de 99 muestra «99+». */
  noLeidas?: number;
  className?: string;
};

/** Sin `href`: botón, como siempre (la acción la decide quien lo usa). */
type ComoBoton = Comun &
  Omit<ComponentPropsWithoutRef<"button">, "children" | "className"> & { href?: undefined };

/** Con `href`: enlace (la barra superior lleva al centro de notificaciones). */
type ComoEnlace = Comun & { href: string; "aria-current"?: "page" };

type CampanaDeNotificacionesProps = ComoBoton | ComoEnlace;

/** Ícono de la barra superior con el contador de no leídas (H21). */
export function CampanaDeNotificaciones(props: CampanaDeNotificacionesProps) {
  const { noLeidas = 0, className } = props;
  const texto = noLeidas > 99 ? "99+" : String(noLeidas);
  const etiqueta = noLeidas > 0 ? `Notificaciones, ${noLeidas} sin leer` : "Notificaciones";
  const clases = unirClases(
    "relative inline-flex size-10 shrink-0 cursor-pointer items-center justify-center text-texto-primario hover:bg-fondo-sutil",
    className,
  );
  const contenido = (
    <>
      <Icono nombre="campana" />
      {noLeidas > 0 && (
        <span
          aria-hidden
          className="texto-etiqueta-pequena absolute top-0.5 left-[22px] bg-estado-error px-espacio-1 py-px text-texto-sobre-marca"
        >
          {texto}
        </span>
      )}
    </>
  );

  if (props.href !== undefined) {
    return (
      <Link href={props.href} aria-label={etiqueta} aria-current={props["aria-current"]} className={clases}>
        {contenido}
      </Link>
    );
  }

  // eslint-disable-next-line @typescript-eslint/no-unused-vars -- se separan las props propias de las del <button>.
  const { noLeidas: _noLeidas, className: _className, href: _href, ...boton } = props;
  return (
    <button type="button" aria-label={etiqueta} className={clases} {...boton}>
      {contenido}
    </button>
  );
}
