import type { CSSProperties } from "react";
import { unirClases } from "@/lib/clases";

/** Nombres de los íconos de Arre (Figma: Components › Íconos). */
export const NOMBRES_ICONO = [
  "buscar",
  "campana",
  "cerrar",
  "chevron-izquierda",
  "chevron-derecha",
  "chevron-abajo",
  "chevron-arriba",
  "check",
  "calendario",
  "subir",
  "descargar",
  "estrella",
  "estrella-llena",
  "flecha-arriba",
  "flecha-abajo",
  "usuario",
  "menu",
  "mensaje",
  "mas",
  "basura",
  "info",
  "alerta",
  "ubicacion",
  "candado",
  "verificado",
  "documento",
  "filtros",
  "imagen",
  "salir",
  "reloj",
  "tarjeta",
  "banco",
  "editar",
  "inicio",
  "reportes",
  "bienes",
  "actualizar",
  "enviar",
  "cargando",
] as const;

export type IconoNombre = (typeof NOMBRES_ICONO)[number];

type IconoProps = {
  nombre: IconoNombre;
  /** Lado en píxeles. En Figma los íconos miden 24; dentro de componentes, 20. */
  tamano?: number;
  /** Texto para lectores de pantalla. Sin él, el ícono es decorativo. */
  etiqueta?: string;
  className?: string;
};

/**
 * Ícono de Arre: 24×24, trazo 1.5 y esquinas rectas.
 *
 * El SVG se usa como máscara y se pinta con `currentColor`, así que el color se
 * cambia con una clase de texto (`text-estado-error`), igual que en Figma se
 * «sobrescribe el trazo», sin tocar el archivo de `public/iconos`.
 */
export function Icono({ nombre, tamano = 24, etiqueta, className }: IconoProps) {
  const estilo = {
    width: tamano,
    height: tamano,
    maskImage: `url(/iconos/${nombre}.svg)`,
    WebkitMaskImage: `url(/iconos/${nombre}.svg)`,
  } satisfies CSSProperties;

  return (
    <span
      role={etiqueta ? "img" : undefined}
      aria-label={etiqueta}
      aria-hidden={etiqueta ? undefined : true}
      className={unirClases(
        "inline-block shrink-0 bg-current [mask-repeat:no-repeat] [mask-size:100%_100%]",
        className,
      )}
      style={estilo}
    />
  );
}
