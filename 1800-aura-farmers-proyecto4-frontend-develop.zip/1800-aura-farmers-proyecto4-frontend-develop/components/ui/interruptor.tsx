import type { ComponentPropsWithoutRef, ReactNode } from "react";
import { unirClases } from "@/lib/clases";

type InterruptorProps = Omit<ComponentPropsWithoutRef<"input">, "type" | "role"> & {
  /** Texto a la derecha. Si se omite, pasar `aria-label`. */
  texto?: ReactNode;
};

/**
 * Interruptor de encendido y apagado («Solo usuarios verificados», H19). Va
 * deshabilitado cuando el arrendador no está verificado.
 *
 * Es un checkbox nativo con `role="switch"`, así que se envía en formularios
 * y responde a la barra espaciadora sin código extra.
 */
export function Interruptor({ texto, className, disabled, ...props }: InterruptorProps) {
  return (
    <label
      className={unirClases(
        "group inline-flex items-center gap-espacio-3",
        "has-focus-visible:outline-2 has-focus-visible:outline-offset-2 has-focus-visible:outline-borde-foco",
        disabled ? "cursor-not-allowed" : "cursor-pointer",
        className,
      )}
    >
      <input
        type="checkbox"
        role="switch"
        disabled={disabled}
        className="solo-lector"
        {...props}
      />
      <span
        aria-hidden
        className={unirClases(
          "flex h-6 w-11 shrink-0 p-0.5 group-has-checked:justify-end",
          disabled
            ? "bg-fondo-deshabilitado"
            : "bg-borde-default group-has-checked:bg-fondo-marca",
        )}
      >
        <span className="size-5 bg-fondo-superficie" />
      </span>
      {texto && (
        <span
          className={unirClases(
            "texto-cuerpo-medio",
            disabled ? "text-texto-deshabilitado" : "text-texto-primario",
          )}
        >
          {texto}
        </span>
      )}
    </label>
  );
}
