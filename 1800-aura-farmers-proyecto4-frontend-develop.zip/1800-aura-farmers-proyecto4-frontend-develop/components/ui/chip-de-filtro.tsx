import { unirClases } from "@/lib/clases";
import { Icono } from "./icono";

type ChipDeFiltroProps = {
  texto: string;
  /** Quita el filtro. */
  onQuitar?: () => void;
  className?: string;
};

/** Filtro activo en la búsqueda (H4). La X quita el filtro. */
export function ChipDeFiltro({ texto, onQuitar, className }: ChipDeFiltroProps) {
  return (
    <span
      className={unirClases(
        "inline-flex items-center gap-1.5 border border-borde-default bg-fondo-sutil py-1.5 pr-espacio-2 pl-espacio-3",
        className,
      )}
    >
      <span className="texto-etiqueta whitespace-nowrap text-texto-primario">{texto}</span>
      <button
        type="button"
        onClick={onQuitar}
        aria-label={`Quitar filtro ${texto}`}
        className="inline-flex cursor-pointer text-texto-primario hover:text-texto-error"
      >
        <Icono nombre="cerrar" tamano={16} />
      </button>
    </span>
  );
}
