import { unirClases } from "@/lib/clases";
import { DiaDeCalendario, type EstadoDia } from "./dia-de-calendario";
import { Icono } from "./icono";

const DIAS_SEMANA = ["L", "M", "M", "J", "V", "S", "D"];
const NOMBRES_DIA = ["lunes", "martes", "miércoles", "jueves", "viernes", "sábado", "domingo"];

const formatoMes = new Intl.DateTimeFormat("es", { month: "long", year: "numeric" });
const formatoDia = new Intl.DateTimeFormat("es", {
  weekday: "long",
  day: "numeric",
  month: "long",
  year: "numeric",
});

/** Fecha local en formato AAAA-MM-DD, el mismo que usa el backend. */
export function fechaISO(fecha: Date): string {
  const mes = String(fecha.getMonth() + 1).padStart(2, "0");
  const dia = String(fecha.getDate()).padStart(2, "0");
  return `${fecha.getFullYear()}-${mes}-${dia}`;
}

type MesDeCalendarioProps = {
  anio: number;
  /** Mes de 0 (enero) a 11 (diciembre), como en `Date`. */
  mes: number;
  /**
   * Estado de cada día. La regla (reservas, bloqueos, días pasados, rango
   * elegido) la decide la pantalla; este componente solo la pinta.
   */
  estadoDe?: (fecha: string) => EstadoDia;
  onSeleccionarDia?: (fecha: string) => void;
  /** Sin callback, la flecha correspondiente no se muestra. */
  onMesAnterior?: () => void;
  onMesSiguiente?: () => void;
  className?: string;
};

/**
 * Un mes del calendario de disponibilidad (FE-5.1). Semanas de lunes a
 * domingo. Sirve en modo selección (arrendatario) y en modo gestión
 * (arrendador, H7): la diferencia está en `estadoDe` y `onSeleccionarDia`.
 */
export function MesDeCalendario({
  anio,
  mes,
  estadoDe = () => "disponible",
  onSeleccionarDia,
  onMesAnterior,
  onMesSiguiente,
  className,
}: MesDeCalendarioProps) {
  const primerDia = new Date(anio, mes, 1);
  const diasDelMes = new Date(anio, mes + 1, 0).getDate();
  // getDay() empieza en domingo; se corre para que la semana empiece en lunes.
  const huecosIniciales = (primerDia.getDay() + 6) % 7;
  const titulo = formatoMes.format(primerDia).replace(/ de /, " ");

  const celdas: Array<Date | null> = [
    ...Array.from({ length: huecosIniciales }, () => null),
    ...Array.from({ length: diasDelMes }, (_, indice) => new Date(anio, mes, indice + 1)),
  ];

  return (
    <div
      className={unirClases(
        "flex w-full max-w-[366px] flex-col gap-espacio-3 border border-borde-default bg-fondo-superficie p-espacio-4",
        className,
      )}
    >
      <div className="flex items-center justify-between">
        <BotonMes direccion="anterior" onClick={onMesAnterior} />
        <h3 className="texto-h4 text-texto-primario first-letter:uppercase" aria-live="polite">
          {titulo}
        </h3>
        <BotonMes direccion="siguiente" onClick={onMesSiguiente} />
      </div>
      <div role="grid" aria-label={titulo} className="flex flex-col gap-0.5 md:gap-espacio-1">
        <div role="row" className="grid grid-cols-7 gap-0.5 md:gap-espacio-1">
          {DIAS_SEMANA.map((inicial, indice) => (
            <abbr
              key={NOMBRES_DIA[indice]}
              role="columnheader"
              title={NOMBRES_DIA[indice]}
              className="texto-etiqueta-pequena flex h-5 justify-center text-texto-secundario no-underline"
            >
              {inicial}
            </abbr>
          ))}
        </div>
        {Array.from({ length: Math.ceil(celdas.length / 7) }, (_, semana) => (
          <div key={semana} role="row" className="grid grid-cols-7 gap-0.5 md:gap-espacio-1">
            {celdas.slice(semana * 7, semana * 7 + 7).map((fecha, indice) =>
              fecha ? (
                <div key={fechaISO(fecha)} role="gridcell">
                  <DiaDeCalendario
                    dia={fecha.getDate()}
                    estado={estadoDe(fechaISO(fecha))}
                    etiqueta={formatoDia.format(fecha)}
                    onSeleccionar={onSeleccionarDia && (() => onSeleccionarDia(fechaISO(fecha)))}
                    className="aspect-square size-auto w-full md:size-11"
                  />
                </div>
              ) : (
                <div key={`vacio-${indice}`} role="gridcell" />
              ),
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

function BotonMes({
  direccion,
  onClick,
}: {
  direccion: "anterior" | "siguiente";
  onClick?: () => void;
}) {
  if (!onClick) return <span className="size-5" />;
  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={direccion === "anterior" ? "Mes anterior" : "Mes siguiente"}
      className="inline-flex cursor-pointer text-texto-primario hover:text-texto-acento"
    >
      <Icono nombre={direccion === "anterior" ? "chevron-izquierda" : "chevron-derecha"} tamano={20} />
    </button>
  );
}
