"use client";

import {
  Children,
  cloneElement,
  isValidElement,
  type ComponentPropsWithoutRef,
  type KeyboardEvent,
  type ReactElement,
  type ReactNode,
} from "react";
import { unirClases } from "@/lib/clases";

type PestanasProps = {
  /** Nombre accesible de la fila de pestañas. */
  etiqueta: string;
  children: ReactNode;
  className?: string;
};

/**
 * Fila de pestañas con borde inferior sutil (panel de reportes, filtros por
 * estado). Las flechas izquierda y derecha, Inicio y Fin mueven el foco entre
 * pestañas.
 *
 * Solo una pestaña entra en el orden de Tab (la activa). Si ninguna está
 * activa, por ejemplo unos filtros sin selección, entra la primera; si no,
 * nadie con teclado podría llegar a la fila.
 */
export function Pestanas({ etiqueta, children, className }: PestanasProps) {
  const lista = Children.toArray(children);
  const hayActiva = lista.some(
    (hijo) => isValidElement<PestanaProps>(hijo) && hijo.props.activa,
  );
  const indiceRespaldo = hayActiva
    ? -1
    : lista.findIndex((hijo) => isValidElement<PestanaProps>(hijo) && !hijo.props.disabled);
  const pestanas = lista.map((hijo, indice) =>
    indice === indiceRespaldo
      ? cloneElement(hijo as ReactElement<PestanaProps>, { enfocable: true })
      : hijo,
  );

  function alPresionarTecla(evento: KeyboardEvent<HTMLDivElement>) {
    if (!["ArrowLeft", "ArrowRight", "Home", "End"].includes(evento.key)) return;
    const botones = Array.from(
      evento.currentTarget.querySelectorAll<HTMLButtonElement>('[role="tab"]:not(:disabled)'),
    );
    const actual = botones.indexOf(document.activeElement as HTMLButtonElement);
    const ultima = botones.length - 1;
    const siguiente =
      evento.key === "Home"
        ? 0
        : evento.key === "End"
          ? ultima
          : evento.key === "ArrowRight"
            ? (actual + 1) % botones.length
            : (actual - 1 + botones.length) % botones.length;
    evento.preventDefault();
    botones[siguiente]?.focus();
  }

  return (
    <div
      role="tablist"
      aria-label={etiqueta}
      onKeyDown={alPresionarTecla}
      className={unirClases(
        // overflow-y-hidden: las pestañas bajan 1 px (-mb-px) para tapar el borde, y
        // sin él ese píxel crea una barra de scroll vertical donde no es superpuesta.
        "flex gap-espacio-5 overflow-x-auto overflow-y-hidden border-b border-borde-sutil",
        className,
      )}
    >
      {pestanas}
    </div>
  );
}

type PestanaProps = ComponentPropsWithoutRef<"button"> & {
  activa?: boolean;
  /** Id del `PanelDePestana` que muestra esta pestaña (para `aria-controls`). */
  panel?: string;
  /** Uso interno de `Pestanas`: la hace alcanzable con Tab cuando no hay activa. */
  enfocable?: boolean;
};

/** Pestaña de navegación entre secciones. */
export function Pestana({
  activa = false,
  panel,
  enfocable = false,
  className,
  children,
  ...props
}: PestanaProps) {
  return (
    <button
      type="button"
      role="tab"
      aria-selected={activa}
      aria-controls={panel}
      tabIndex={activa || enfocable ? 0 : -1}
      className={unirClases(
        "-mb-px shrink-0 cursor-pointer px-espacio-1 py-espacio-3 whitespace-nowrap",
        activa
          ? "texto-cuerpo-medio border-b-2 border-fondo-marca text-texto-primario"
          : "texto-cuerpo border-b border-borde-sutil text-texto-secundario hover:text-texto-primario",
        className,
      )}
      {...props}
    >
      {children}
    </button>
  );
}

type PanelDePestanaProps = ComponentPropsWithoutRef<"div"> & {
  /** Id del panel; es el que recibe la pestaña en `panel`. */
  id: string;
  /** Id de la pestaña que lo controla (para `aria-labelledby`). */
  pestana: string;
  /** Si es falso, el panel queda oculto. */
  activo: boolean;
};

/** Contenido asociado a una pestaña. */
export function PanelDePestana({ id, pestana, activo, ...props }: PanelDePestanaProps) {
  return (
    <div
      role="tabpanel"
      id={id}
      aria-labelledby={pestana}
      hidden={!activo}
      tabIndex={0}
      {...props}
    />
  );
}
