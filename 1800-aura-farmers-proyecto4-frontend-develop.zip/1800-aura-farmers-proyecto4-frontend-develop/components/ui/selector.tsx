"use client";

import {
  useEffect,
  useId,
  useRef,
  useState,
  type KeyboardEvent,
  type ReactNode,
} from "react";
import { unirClases } from "@/lib/clases";
import { AyudaCampo, EncabezadoCampo, clasesCaja } from "./campo-base";
import { Icono } from "./icono";

export type OpcionSelector = { valor: string; etiqueta: string };

type SelectorProps = {
  etiqueta: ReactNode;
  opciones: OpcionSelector[];
  /** Valor elegido (controlado). */
  valor?: string | null;
  /** Valor inicial cuando no es controlado. */
  valorInicial?: string | null;
  onCambiar?: (valor: string) => void;
  placeholder?: string;
  ayuda?: ReactNode;
  error?: ReactNode;
  deshabilitado?: boolean;
  /** Si se pasa, agrega un input oculto para enviar el valor en un `<form>`. */
  name?: string;
  id?: string;
  className?: string;
};

/**
 * Lista desplegable de Arre (tipo de bien, categoría, unidad de cobro,
 * departamento, municipio, periodo). Abierta, marca la opción elegida en
 * amarillo mantequilla.
 *
 * Es un listbox propio y no un `<select>` nativo porque el menú nativo no se
 * puede pintar con el estilo de Arre. Se maneja con teclado: flechas, Inicio,
 * Fin, Enter o Espacio para elegir, Escape para cerrar y letras para saltar a
 * la opción que empieza así (como en un `<select>`).
 */

/** Tiempo para seguir escribiendo una búsqueda por letras, en milisegundos. */
const PAUSA_BUSQUEDA = 500;

/** Compara sin mayúsculas ni tildes: «Ahuachapán» empieza con «ahua». */
function normalizar(texto: string) {
  return texto.normalize("NFD").replace(/\p{Diacritic}/gu, "").toLowerCase();
}
export function Selector({
  etiqueta,
  opciones,
  valor,
  valorInicial = null,
  onCambiar,
  placeholder = "Selecciona una opción",
  ayuda,
  error,
  deshabilitado = false,
  name,
  id,
  className,
}: SelectorProps) {
  const idGenerado = useId();
  const idCampo = id ?? idGenerado;
  const idEtiqueta = `${idCampo}-etiqueta`;
  const idLista = `${idCampo}-lista`;
  const idAyuda = `${idCampo}-ayuda`;
  const [valorInterno, setValorInterno] = useState(valorInicial);
  const elegido = valor !== undefined ? valor : valorInterno;
  const [abierto, setAbierto] = useState(false);
  const [activo, setActivo] = useState(0);
  const raiz = useRef<HTMLDivElement>(null);
  const boton = useRef<HTMLButtonElement>(null);
  const busqueda = useRef({ texto: "", hasta: 0 });
  // Si las opciones cambian con el menú abierto, el índice guardado puede
  // quedar fuera de rango; se acota al renderizar.
  const indiceActivo = Math.min(activo, Math.max(opciones.length - 1, 0));
  const conError = Boolean(error);
  const textoAyuda = error ?? ayuda;
  const opcionElegida = opciones.find((opcion) => opcion.valor === elegido);

  // Cierra el menú al hacer clic fuera del componente.
  useEffect(() => {
    if (!abierto) return;
    const alClicFuera = (evento: PointerEvent) => {
      if (!raiz.current?.contains(evento.target as Node)) setAbierto(false);
    };
    document.addEventListener("pointerdown", alClicFuera);
    return () => document.removeEventListener("pointerdown", alClicFuera);
  }, [abierto]);

  // Mantiene visible la opción activa al navegar con teclado en listas largas.
  useEffect(() => {
    if (!abierto) return;
    document
      .getElementById(`${idLista}-${indiceActivo}`)
      ?.scrollIntoView?.({ block: "nearest" });
  }, [abierto, indiceActivo, idLista]);

  /**
   * Busca la opción que empieza con lo escrito. Una letra sola avanza a la
   * siguiente coincidencia (para recorrer «San Salvador», «San Miguel»…);
   * varias letras seguidas buscan el prefijo completo.
   */
  function buscarPorLetra(tecla: string): number | null {
    const ahora = Date.now();
    const texto =
      ahora < busqueda.current.hasta ? busqueda.current.texto + tecla : tecla;
    busqueda.current = { texto, hasta: ahora + PAUSA_BUSQUEDA };
    const buscado = normalizar(texto);
    const desde = texto.length === 1 ? indiceActivo + 1 : indiceActivo;
    for (let paso = 0; paso < opciones.length; paso++) {
      const indice = (desde + paso) % opciones.length;
      if (normalizar(opciones[indice].etiqueta).startsWith(buscado)) return indice;
    }
    return null;
  }

  function abrir() {
    const indice = opciones.findIndex((opcion) => opcion.valor === elegido);
    setActivo(indice >= 0 ? indice : 0);
    setAbierto(true);
  }

  function elegir(indice: number) {
    const opcion = opciones[indice];
    if (!opcion) return;
    if (valor === undefined) setValorInterno(opcion.valor);
    onCambiar?.(opcion.valor);
    setAbierto(false);
    boton.current?.focus();
  }

  function alPresionarTecla(evento: KeyboardEvent<HTMLButtonElement>) {
    const ultimo = opciones.length - 1;
    const escribiendo = Date.now() < busqueda.current.hasta;
    const esLetra =
      evento.key.length === 1 &&
      !evento.ctrlKey &&
      !evento.metaKey &&
      !evento.altKey &&
      (evento.key !== " " || escribiendo);
    if (esLetra) {
      evento.preventDefault();
      const encontrada = buscarPorLetra(evento.key);
      if (encontrada !== null) {
        setActivo(encontrada);
        setAbierto(true);
      }
      return;
    }
    // Cualquier otra tecla corta la palabra que se estaba escribiendo.
    busqueda.current = { texto: "", hasta: 0 };
    if (!abierto) {
      if (["ArrowDown", "ArrowUp", "Enter", " "].includes(evento.key)) {
        evento.preventDefault();
        abrir();
      }
      return;
    }
    switch (evento.key) {
      case "ArrowDown":
        evento.preventDefault();
        setActivo((actual) => Math.min(actual + 1, ultimo));
        break;
      case "ArrowUp":
        evento.preventDefault();
        setActivo((actual) => Math.max(actual - 1, 0));
        break;
      case "Home":
        evento.preventDefault();
        setActivo(0);
        break;
      case "End":
        evento.preventDefault();
        setActivo(ultimo);
        break;
      case "Enter":
      case " ":
        evento.preventDefault();
        elegir(indiceActivo);
        break;
      case "Escape":
      case "Tab":
        setAbierto(false);
        break;
    }
  }

  return (
    <div ref={raiz} className={unirClases("flex w-full flex-col gap-espacio-2", className)}>
      <EncabezadoCampo
        id={idEtiqueta}
        etiqueta={etiqueta}
        error={conError}
        deshabilitado={deshabilitado}
      />
      <div className="relative">
      <button
        ref={boton}
        id={idCampo}
        type="button"
        role="combobox"
        aria-haspopup="listbox"
        aria-expanded={abierto}
        aria-controls={abierto ? idLista : undefined}
        aria-labelledby={idEtiqueta}
        aria-activedescendant={abierto ? `${idLista}-${indiceActivo}` : undefined}
        aria-invalid={conError || undefined}
        aria-describedby={textoAyuda ? idAyuda : undefined}
        disabled={deshabilitado}
        onClick={() => (abierto ? setAbierto(false) : abrir())}
        onKeyDown={alPresionarTecla}
        className={unirClases(
          "flex h-12 w-full items-center gap-espacio-3 px-espacio-4 text-left outline-none disabled:cursor-not-allowed",
          abierto
            ? "border-2 border-borde-foco bg-fondo-superficie"
            : clasesCaja({ error: conError, deshabilitado }),
        )}
      >
        <span
          className={unirClases(
            "texto-cuerpo min-w-0 flex-1 truncate",
            deshabilitado
              ? "text-texto-deshabilitado"
              : opcionElegida
                ? "text-texto-primario"
                : "text-texto-secundario",
          )}
        >
          {opcionElegida?.etiqueta ?? placeholder}
        </span>
        <Icono
          nombre={abierto ? "chevron-arriba" : "chevron-abajo"}
          tamano={20}
          className={deshabilitado ? "text-texto-deshabilitado" : "text-texto-primario"}
        />
      </button>
      {abierto && (
        <ul
          id={idLista}
          role="listbox"
          aria-labelledby={idEtiqueta}
          className="absolute inset-x-0 top-[calc(100%+4px)] z-20 max-h-72 overflow-y-auto border border-borde-default bg-fondo-superficie"
        >
          {opciones.map((opcion, indice) => (
            <li
              key={opcion.valor}
              id={`${idLista}-${indice}`}
              role="option"
              aria-selected={opcion.valor === elegido}
              onPointerEnter={() => setActivo(indice)}
              onPointerDown={(evento) => evento.preventDefault()}
              onClick={() => elegir(indice)}
              className={unirClases(
                "texto-cuerpo cursor-pointer px-espacio-4 py-espacio-3 text-texto-primario",
                opcion.valor === elegido
                  ? "bg-fondo-acento"
                  : indice === indiceActivo && "bg-fondo-sutil",
              )}
            >
              {opcion.etiqueta}
            </li>
          ))}
        </ul>
      )}
      </div>
      {name && <input type="hidden" name={name} value={elegido ?? ""} />}
      <AyudaCampo id={idAyuda} texto={textoAyuda} error={conError} deshabilitado={deshabilitado} />
    </div>
  );
}
