import type { ReactNode } from "react";
import { unirClases } from "@/lib/clases";

type MensajeProps = {
  /** Nombre de usuario del remitente. */
  autor: string;
  /** Fecha y hora ya formateadas (dd/mm/aaaa hh:mm). */
  fecha: string;
  children: ReactNode;
  /** Mensaje del usuario actual: mantequilla y a la derecha. */
  propio?: boolean;
  className?: string;
};

/**
 * Mensaje de una conversación (H13, H14). Propio: mantequilla, a la derecha.
 * Otro: marfil con borde, a la izquierda. Ancho máximo 420 px (85 % en móvil).
 */
export function Mensaje({ autor, fecha, children, propio = false, className }: MensajeProps) {
  return (
    <div
      className={unirClases(
        "flex w-fit max-w-[85%] flex-col gap-espacio-1 px-espacio-4 py-espacio-3 md:max-w-[420px]",
        propio
          ? "self-end bg-fondo-acento"
          : "self-start border border-borde-default bg-fondo-superficie",
        className,
      )}
    >
      <p className="texto-etiqueta-pequena text-texto-secundario">
        {autor} · {fecha}
      </p>
      <div className="texto-cuerpo break-words text-texto-primario">{children}</div>
    </div>
  );
}
