import type { ReactNode } from "react";
import { unirClases } from "@/lib/clases";
import { Imagen } from "./imagen";
import { InsigniaDeEstado, type TonoInsignia } from "./insignia-de-estado";

type TarjetaDeReservaProps = {
  titulo: string;
  foto?: string | null;
  /** Fechas ya formateadas: «20/11/2026 → 22/11/2026 · 3 días». */
  fechas: string;
  /** El otro participante: «Arrendador: carlos_mendez» o «Arrendatario: ana_m». */
  participante: string;
  estado: { texto: string; tono: TonoInsignia };
  /** Motivo de rechazo; se muestra debajo de las fechas. */
  motivoRechazo?: ReactNode;
  /** Dato extra al final de la fila, por ejemplo el pago y el depósito. */
  detalle?: ReactNode;
  /**
   * Acción de la fila: «Ver detalle» (arrendatario) o «Gestionar»
   * (arrendador). Normalmente un `<Link>` con `clasesBoton({ jerarquia: "terciario" })`.
   */
  accion?: ReactNode;
  className?: string;
};

/**
 * Fila de reserva para «Mis reservas» (arrendatario) y «Reservas recibidas»
 * (arrendador): foto, título, fechas, el otro participante, insignia de estado
 * y acción. En móvil la insignia y la acción bajan a una fila propia.
 */
export function TarjetaDeReserva({
  titulo,
  foto,
  fechas,
  participante,
  estado,
  motivoRechazo,
  detalle,
  accion,
  className,
}: TarjetaDeReservaProps) {
  return (
    <article
      className={unirClases(
        "flex w-full flex-col gap-espacio-3 border border-borde-default bg-fondo-superficie p-espacio-4 md:flex-row md:items-center md:gap-5",
        className,
      )}
    >
      <div className="flex min-w-0 flex-1 items-center gap-espacio-4">
        <Imagen src={foto} alt={titulo} sizes="88px" className="size-16 shrink-0 md:size-22" />
        <div className="flex min-w-0 flex-1 flex-col gap-espacio-1">
          <h3 className="texto-h4 text-texto-primario">{titulo}</h3>
          <p className="texto-cuerpo-pequeno text-texto-secundario">{fechas}</p>
          {motivoRechazo && (
            <p className="texto-cuerpo-pequeno text-texto-error">{motivoRechazo}</p>
          )}
          <p className="texto-cuerpo-pequeno text-texto-secundario">{participante}</p>
          {detalle && <p className="texto-cuerpo-pequeno text-texto-secundario">{detalle}</p>}
        </div>
      </div>
      <div className="flex items-center justify-between gap-espacio-3 md:flex-col md:items-end">
        <InsigniaDeEstado texto={estado.texto} tono={estado.tono} />
        {accion}
      </div>
    </article>
  );
}
