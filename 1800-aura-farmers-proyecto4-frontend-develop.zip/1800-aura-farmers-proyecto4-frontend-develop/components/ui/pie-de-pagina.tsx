import Link from "next/link";
import { Contenedor } from "./contenedor";
import { Logo } from "./logo";

const COLUMNAS = [
  {
    titulo: "Explorar",
    enlaces: [
      { texto: "Buscar bienes", href: "/" },
      { texto: "Publicar un bien", href: "/publicar" },
    ],
  },
  {
    titulo: "Tu cuenta",
    enlaces: [
      { texto: "Mis reservas", href: "/reservas" },
      { texto: "Notificaciones", href: "/notificaciones" },
      { texto: "Verificación", href: "/verificacion" },
    ],
  },
];

/**
 * Pie de página en café tinta, con el logo para fondo oscuro. Es la única
 * superficie oscura de la interfaz.
 */
export function PieDePagina() {
  return (
    <footer className="w-full bg-fondo-inverso">
      <Contenedor className="flex flex-col gap-espacio-6 pt-10 pb-espacio-6 md:gap-10 md:pt-14">
        <div className="flex flex-col gap-7 md:flex-row md:items-start md:justify-between">
          <div className="flex flex-col items-start gap-espacio-3">
            <Logo fondo="oscuro" version="con-lema" />
            <p className="texto-cuerpo-pequeno max-w-80 text-texto-inverso-secundario">
              Renta espacios y equipo de personas cerca de ti, con pagos y depósitos claros.
            </p>
          </div>
          <nav aria-label="Pie de página" className="flex gap-espacio-7 md:gap-20">
            {COLUMNAS.map((columna) => (
              <div key={columna.titulo} className="flex flex-col gap-espacio-3">
                <p className="texto-sobretitulo text-texto-inverso-secundario">{columna.titulo}</p>
                <ul className="flex flex-col gap-espacio-3">
                  {columna.enlaces.map((enlace) => (
                    <li key={enlace.texto}>
                      <Link
                        href={enlace.href}
                        className="texto-cuerpo-pequeno whitespace-nowrap text-texto-inverso hover:underline"
                      >
                        {enlace.texto}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </nav>
        </div>
        <hr className="h-px w-full border-0 bg-borde-fuerte" />
        <p className="texto-etiqueta-pequena text-texto-inverso-secundario">
          © 2026 Arre. Proyecto académico — pagos y verificación simulados.
        </p>
      </Contenedor>
    </footer>
  );
}
