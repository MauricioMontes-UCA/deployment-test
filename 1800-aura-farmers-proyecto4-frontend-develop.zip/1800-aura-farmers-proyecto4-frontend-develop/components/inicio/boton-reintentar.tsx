"use client";

import { useRouter } from "next/navigation";
import { useTransition } from "react";
import { clasesBoton } from "@/components/ui";

/**
 * «Reintentar» de la grilla de recientes: vuelve a renderizar la portada en el
 * servidor para pedir de nuevo los datos. Un enlace a `/` no lo lograba, porque
 * ya se está en esa URL.
 */
export function BotonReintentar() {
  const router = useRouter();
  const [pendiente, iniciar] = useTransition();

  return (
    <button
      type="button"
      disabled={pendiente}
      onClick={() => iniciar(() => router.refresh())}
      className={clasesBoton({ jerarquia: "secundario" })}
    >
      {pendiente ? "Reintentando…" : "Reintentar"}
    </button>
  );
}
