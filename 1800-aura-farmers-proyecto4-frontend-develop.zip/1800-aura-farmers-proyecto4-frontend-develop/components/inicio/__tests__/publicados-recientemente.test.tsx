import { render, screen, waitFor, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { beforeEach, describe, expect, it, vi } from "vitest";
import {
  PublicadosRecientemente,
  PublicadosRecientementeCargando,
} from "@/components/inicio/publicados-recientemente";
import { obtenerBienesRecientes, type BienEncontrado } from "@/lib/bienes";

const refrescar = vi.fn();
vi.mock("next/navigation", () => ({ useRouter: () => ({ refresh: refrescar }) }));
vi.mock("@/lib/bienes", async (original) => ({
  ...(await original<typeof import("@/lib/bienes")>()),
  obtenerBienesRecientes: vi.fn(),
}));

const bien = (id: string, titulo: string, extra: Partial<BienEncontrado> = {}): BienEncontrado => ({
  id,
  titulo,
  precio: 80,
  unidadCobro: "DIA",
  departamento: "San Salvador",
  municipio: "San Salvador",
  fotoPrincipal: null,
  ...extra,
});

async function montar() {
  render(await PublicadosRecientemente());
}

beforeEach(() => {
  vi.mocked(obtenerBienesRecientes).mockReset();
  refrescar.mockReset();
  vi.spyOn(console, "error").mockImplementation(() => {});
});

describe("PublicadosRecientemente", () => {
  it("muestra una tarjeta por bien con precio, ubicación y enlace al detalle", async () => {
    vi.mocked(obtenerBienesRecientes).mockResolvedValue([
      bien("a", "Salón de eventos Las Palmas"),
      bien("b", "Cámara profesional Canon EOS", {
        precio: 25,
        municipio: "Antiguo Cuscatlán",
        departamento: "La Libertad",
      }),
    ]);
    await montar();

    const enlaces = screen.getAllByRole("link");
    expect(enlaces).toHaveLength(2);
    expect(enlaces[1]).toHaveAttribute("href", "/bienes/b");
    expect(within(enlaces[1]).getByText("Cámara profesional Canon EOS")).toBeInTheDocument();
    expect(within(enlaces[1]).getByText("$25.00 / día")).toBeInTheDocument();
    expect(within(enlaces[1]).getByText("Antiguo Cuscatlán, La Libertad")).toBeInTheDocument();
  });

  it("en móvil oculta la tercera y la cuarta tarjeta", async () => {
    vi.mocked(obtenerBienesRecientes).mockResolvedValue([
      bien("a", "Uno"),
      bien("b", "Dos"),
      bien("c", "Tres"),
      bien("d", "Cuatro"),
    ]);
    await montar();

    const items = screen.getAllByRole("listitem");
    expect(items.map((item) => item.classList.contains("max-md:hidden"))).toEqual([
      false,
      false,
      true,
      true,
    ]);
  });

  it("sin bienes muestra el estado vacío", async () => {
    vi.mocked(obtenerBienesRecientes).mockResolvedValue([]);
    await montar();
    expect(screen.getByRole("heading", { name: "Aún no hay bienes publicados" })).toBeInTheDocument();
  });

  it("si la API falla muestra el error con «Reintentar»", async () => {
    vi.mocked(obtenerBienesRecientes).mockRejectedValue(new Error("GET /bienes respondió 500"));
    await montar();
    expect(screen.getByRole("alert")).toHaveTextContent("No pudimos cargar las publicaciones");
    expect(screen.getByRole("button", { name: "Reintentar" })).toBeInTheDocument();
  });

  it("«Reintentar» vuelve a pedir los datos refrescando la ruta", async () => {
    vi.mocked(obtenerBienesRecientes).mockRejectedValue(new Error("GET /bienes respondió 500"));
    await montar();

    await userEvent.click(screen.getByRole("button", { name: "Reintentar" }));
    await waitFor(() => expect(refrescar).toHaveBeenCalledTimes(1));
  });

  it("mientras carga muestra los esqueletos", () => {
    render(<PublicadosRecientementeCargando />);
    expect(screen.getByRole("status", { name: "Cargando publicaciones recientes" })).toBeInTheDocument();
  });
});
