import { BotonReintentar } from "@/components/inicio/boton-reintentar";
import { EstadoDePagina, TarjetaDeBien, TarjetaDeBienEsqueleto } from "@/components/ui";
import { CANTIDAD_RECIENTES, formatearPrecio, obtenerBienesRecientes, type BienEncontrado } from "@/lib/bienes";

/** En móvil la grilla muestra solo las dos primeras tarjetas, como el diseño. */
const CLASES_GRILLA = "grid grid-cols-1 gap-x-espacio-5 gap-y-espacio-6 md:grid-cols-4";
const soloEscritorio = (indice: number) => (indice >= 2 ? "max-md:hidden" : undefined);

/**
 * Grilla de «Publicados recientemente» (FE-3.2): `GET /bienes` sin término.
 * Se renderiza en el servidor dentro de un `<Suspense>` con
 * `PublicadosRecientementeCargando` de respaldo.
 */
export async function PublicadosRecientemente() {
  let bienes: BienEncontrado[];
  try {
    bienes = await obtenerBienesRecientes();
  } catch (error) {
    console.error("No se pudieron cargar los bienes recientes:", error);
    return (
      <EstadoDePagina
        tipo="error"
        titulo="No pudimos cargar las publicaciones"
        mensaje="Revisa tu conexión e intenta de nuevo."
        accion={<BotonReintentar />}
      />
    );
  }

  if (bienes.length === 0) {
    return (
      <EstadoDePagina
        tipo="vacio"
        titulo="Aún no hay bienes publicados"
        mensaje="Cuando alguien publique un espacio o equipo, aparecerá aquí."
      />
    );
  }

  return (
    <ul className={CLASES_GRILLA}>
      {bienes.map((bien, indice) => (
        <li key={bien.id} className={soloEscritorio(indice)}>
          <TarjetaDeBien
            titulo={bien.titulo}
            precio={formatearPrecio(bien.precio, bien.unidadCobro)}
            ubicacion={`${bien.municipio}, ${bien.departamento}`}
            foto={bien.fotoPrincipal}
            href={`/bienes/${bien.id}`}
          />
        </li>
      ))}
    </ul>
  );
}

/** Estado de carga de la grilla: esqueletos de la tarjeta de bien. */
export function PublicadosRecientementeCargando() {
  return (
    <div role="status" aria-label="Cargando publicaciones recientes" className={CLASES_GRILLA}>
      {Array.from({ length: CANTIDAD_RECIENTES }, (_, indice) => (
        <TarjetaDeBienEsqueleto key={indice} className={soloEscritorio(indice)} />
      ))}
    </div>
  );
}
