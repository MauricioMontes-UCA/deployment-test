import "@testing-library/jest-dom/vitest";
import { cleanup } from "@testing-library/react";
import { afterEach, vi } from "vitest";

// `server-only` lanza fuera del entorno de React Server; en las pruebas se
// importan módulos de servidor directamente.
vi.mock("server-only", () => ({}));

afterEach(() => {
  cleanup();
});
