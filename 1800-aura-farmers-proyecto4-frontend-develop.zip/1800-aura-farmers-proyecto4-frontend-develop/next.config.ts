import type { NextConfig } from "next";

// Las fotos de los bienes las sirve el backend en /uploads (fuera del prefijo
// /api/v1) y la API las devuelve como rutas relativas: «/uploads/bienes/…».
// Se reenvían a su origen para que `next/image` las trate como imágenes
// locales, sin exponer otro host ni abrir remotePatterns.
const origenApi = process.env.API_URL ? new URL(process.env.API_URL).origin : null;

const nextConfig: NextConfig = {
  // Servidor mínimo autocontenido para la imagen de Docker (ver Dockerfile).
  output: "standalone",
  images: {
    // Solo se optimizan las fotos del backend y las imágenes propias, sin
    // parámetros de búsqueda.
    localPatterns: [
      { pathname: "/uploads/**", search: "" },
      { pathname: "/imagenes/**", search: "" },
    ],
  },
  async rewrites() {
    if (!origenApi) return [];
    return [{ source: "/uploads/:ruta*", destination: `${origenApi}/uploads/:ruta*` }];
  },
};

export default nextConfig;
