import { validarEntorno } from "@/lib/config";

/**
 * Corre una vez al arrancar el servidor de Next, antes de atender peticiones.
 * Si falta configuración, el servidor no levanta: es mejor que fallar
 * después de que el backend ya rotó un refresh token.
 */
export function register() {
  validarEntorno();
}
