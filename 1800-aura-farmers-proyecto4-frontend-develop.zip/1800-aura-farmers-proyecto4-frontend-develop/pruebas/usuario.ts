import type { UsuarioActual } from "@/lib/usuario-actual";

/**
 * Usuario de `GET /auth/me` para pruebas, con todos los campos de `UsuarioActual`.
 * Por defecto es un arrendatario; cada prueba cambia solo lo que le importa. Si
 * `UsuarioActual` gana un campo, se agrega aquí y no en cada prueba.
 */
export function usuarioDePrueba(cambios: Partial<UsuarioActual> = {}): UsuarioActual {
  return {
    id: "u1",
    nombreUsuario: "ana_m",
    email: "ana_m@example.com",
    rol: "ARRENDATARIO",
    createdAt: "2026-11-01T12:00:00.000Z",
    ...cambios,
  };
}
