/** Arma un JWT con firma falsa para pruebas: el frontend no verifica la firma. */
export function tokenDePrueba(payload: Record<string, unknown>) {
  const codificar = (objeto: unknown) => Buffer.from(JSON.stringify(objeto)).toString("base64url");
  return `${codificar({ alg: "HS256", typ: "JWT" })}.${codificar(payload)}.firma`;
}
