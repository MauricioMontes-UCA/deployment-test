import type { INestApplication } from '@nestjs/common';
import request from 'supertest';
import { formatDia, hoyEn, ZONA_HORARIA } from '@Bienes/utils';
import { PrismaService } from '@Prisma/services';
import { crearApp } from './helpers/crear-app.js';

/**
 * GET /bienes/:bienId/bloqueos (BE-7.3) contra el Postgres de docker-compose
 * (`DATABASE_URL`): autorización, formato, orden, solo vigentes o futuros y
 * que el id devuelto sirve para `DELETE` de BE-7.1.
 *
 * Crea dos arrendadores, un arrendatario y dos bienes con sufijo único, y
 * borra todo al terminar. Los bloqueos se insertan directo en la base para
 * poder crear también los vencidos, que el endpoint de creación no permite.
 * Las fechas son relativas a "hoy" en El Salvador.
 */
describe('GET /bienes/:bienId/bloqueos (e2e)', () => {
  let app: INestApplication;
  let prisma: PrismaService;

  const sufijo = Date.now().toString(36);
  const nuevoUsuario = (
    prefijo: string,
    rol: 'ARRENDADOR' | 'ARRENDATARIO',
  ) => ({
    nombreUsuario: `${prefijo}_${sufijo}`,
    email: `${prefijo}_${sufijo}@example.com`,
    password: 'Str0ngPass',
    rol,
  });
  const dueno = nuevoUsuario('blq_dueno', 'ARRENDADOR');
  const otro = nuevoUsuario('blq_otro', 'ARRENDADOR');
  const inquilino = nuevoUsuario('blq_inq', 'ARRENDATARIO');

  const tokens = { dueno: '', otro: '', inquilino: '' };
  const ids = { dueno: '', otro: '' };
  let bienId = '';
  let bienAjenoId = '';
  let bienVacioId = '';
  const bienes = () => [bienId, bienAjenoId, bienVacioId].filter(Boolean);

  const UUID_INEXISTENTE = '00000000-0000-4000-8000-000000000000';
  const http = () => request(app.getHttpServer());
  const listar = (token: string | null, id = bienId) => {
    const peticion = http().get(`/api/v1/bienes/${id}/bloqueos`);
    return token ? peticion.set('Authorization', `Bearer ${token}`) : peticion;
  };

  /** Día relativo a hoy en El Salvador: `desplazar(0)` es hoy. */
  const desplazar = (dias: number) => {
    const fecha = hoyEn(ZONA_HORARIA);
    fecha.setUTCDate(fecha.getUTCDate() + dias);
    return fecha;
  };
  const insertar = (bien: string, inicio: number, fin: number) =>
    prisma.bloqueoFecha.create({
      data: {
        bienId: bien,
        fechaInicio: desplazar(inicio),
        fechaFin: desplazar(fin),
      },
    });

  async function registrar(usuario: ReturnType<typeof nuevoUsuario>) {
    await http().post('/api/v1/users').send(usuario).expect(201);
    const login = await http()
      .post('/api/v1/auth/login')
      .send({ email: usuario.email, password: usuario.password })
      .expect(200);
    return {
      token: login.body.accessToken as string,
      id: login.body.user.id as string,
    };
  }

  const crearBien = async (arrendadorId: string, titulo: string) =>
    (
      await prisma.bien.create({
        data: {
          arrendadorId,
          tipo: 'PROPIEDAD',
          categoria: 'Casa',
          titulo: `${titulo} ${sufijo}`,
          descripcion: 'Bien de prueba e2e',
          precio: 50,
          unidadCobro: 'NOCHE',
          departamento: 'San Salvador',
          municipio: 'San Salvador',
        },
      })
    ).id;

  beforeAll(async () => {
    app = await crearApp();
    prisma = app.get(PrismaService);

    const d = await registrar(dueno);
    tokens.dueno = d.token;
    ids.dueno = d.id;
    const o = await registrar(otro);
    tokens.otro = o.token;
    ids.otro = o.id;
    tokens.inquilino = (await registrar(inquilino)).token;

    bienId = await crearBien(ids.dueno, 'Bien con bloqueos');
    bienVacioId = await crearBien(ids.dueno, 'Bien sin bloqueos');
    bienAjenoId = await crearBien(ids.otro, 'Bien ajeno');
  }, 60000);

  afterAll(async () => {
    await prisma.bloqueoFecha.deleteMany({
      where: { bienId: { in: bienes() } },
    });
    await prisma.bien.deleteMany({ where: { id: { in: bienes() } } });
    await prisma.usuario.deleteMany({
      where: { email: { in: [dueno.email, otro.email, inquilino.email] } },
    });
    await app.close();
  });

  beforeEach(async () => {
    await prisma.bloqueoFecha.deleteMany({
      where: { bienId: { in: bienes() } },
    });
  });

  describe('autorización y validación', () => {
    it('sin token responde 401', async () => {
      await listar(null).expect(401);
    });

    it('un arrendatario recibe 403', async () => {
      await listar(tokens.inquilino).expect(403);
    });

    it('otro arrendador recibe 403 aunque el bien tenga bloqueos', async () => {
      await insertar(bienId, 5, 7);
      await listar(tokens.otro).expect(403);
    });

    it('un bien inexistente responde 404', async () => {
      await listar(tokens.dueno, UUID_INEXISTENTE).expect(404);
    });

    it('un id que no es UUID responde 400', async () => {
      await listar(tokens.dueno, 'no-es-un-uuid').expect(400);
    });

    it('el otro arrendador sí ve los de su propio bien, no los del primero', async () => {
      await insertar(bienId, 5, 7);
      const propio = await insertar(bienAjenoId, 10, 12);

      const respuesta = await listar(tokens.otro, bienAjenoId).expect(200);

      expect(respuesta.body.map((b: { id: string }) => b.id)).toEqual([
        propio.id,
      ]);
    });
  });

  describe('contenido', () => {
    it('un bien sin bloqueos devuelve una lista vacía', async () => {
      const respuesta = await listar(tokens.dueno, bienVacioId).expect(200);

      expect(respuesta.body).toEqual([]);
    });

    it('devuelve id, fechaInicio, fechaFin y creadoEn, y nada más', async () => {
      const creado = await insertar(bienId, 5, 7);

      const respuesta = await listar(tokens.dueno).expect(200);

      expect(respuesta.body).toHaveLength(1);
      const [bloqueo] = respuesta.body;
      expect(Object.keys(bloqueo).sort()).toEqual([
        'creadoEn',
        'fechaFin',
        'fechaInicio',
        'id',
      ]);
      expect(bloqueo.id).toBe(creado.id);
      expect(bloqueo.fechaInicio).toBe(formatDia(desplazar(5)));
      expect(bloqueo.fechaFin).toBe(formatDia(desplazar(7)));
      expect(new Date(bloqueo.creadoEn).toISOString()).toBe(bloqueo.creadoEn);
    });

    it('los ordena por fecha de inicio ascendente sin importar el orden de creación', async () => {
      const lejano = await insertar(bienId, 40, 41);
      const cercano = await insertar(bienId, 3, 4);
      const medio = await insertar(bienId, 15, 20);

      const respuesta = await listar(tokens.dueno).expect(200);

      expect(respuesta.body.map((b: { id: string }) => b.id)).toEqual([
        cercano.id,
        medio.id,
        lejano.id,
      ]);
    });

    it('no incluye los bloqueos de otros bienes', async () => {
      const mio = await insertar(bienId, 5, 6);
      await insertar(bienAjenoId, 5, 6);
      await insertar(bienVacioId, 8, 9);

      const respuesta = await listar(tokens.dueno).expect(200);

      expect(respuesta.body.map((b: { id: string }) => b.id)).toEqual([mio.id]);
    });
  });

  describe('solo vigentes o futuros (fechaFin ≥ hoy en El Salvador)', () => {
    it('excluye el bloqueo que terminó ayer', async () => {
      await insertar(bienId, -5, -1);

      const respuesta = await listar(tokens.dueno).expect(200);

      expect(respuesta.body).toEqual([]);
    });

    it('incluye el bloqueo de un solo día que es hoy', async () => {
      const hoy = await insertar(bienId, 0, 0);

      const respuesta = await listar(tokens.dueno).expect(200);

      expect(respuesta.body.map((b: { id: string }) => b.id)).toEqual([hoy.id]);
    });

    it('incluye el bloqueo en curso: empezó antes de hoy y termina hoy o después', async () => {
      const terminaHoy = await insertar(bienId, -3, 0);
      const enCurso = await insertar(bienId, -2, 4);

      const respuesta = await listar(tokens.dueno).expect(200);

      expect(respuesta.body.map((b: { id: string }) => b.id)).toEqual([
        terminaHoy.id,
        enCurso.id,
      ]);
    });

    it('mezcla vencidos, en curso y futuros: solo quedan los vigentes, en orden', async () => {
      await insertar(bienId, -30, -20);
      await insertar(bienId, -10, -1);
      const enCurso = await insertar(bienId, -1, 2);
      const futuro = await insertar(bienId, 10, 12);

      const respuesta = await listar(tokens.dueno).expect(200);

      expect(respuesta.body.map((b: { id: string }) => b.id)).toEqual([
        enCurso.id,
        futuro.id,
      ]);
    });
  });

  describe('integración con BE-7.1', () => {
    it('un bloqueo creado con POST aparece, y su id sirve para DELETE', async () => {
      const inicio = formatDia(desplazar(20));
      const fin = formatDia(desplazar(22));
      const creado = await http()
        .post(`/api/v1/bienes/${bienId}/bloqueos`)
        .set('Authorization', `Bearer ${tokens.dueno}`)
        .send({ fechaInicio: inicio, fechaFin: fin })
        .expect(201);

      const antes = await listar(tokens.dueno).expect(200);
      expect(antes.body).toHaveLength(1);
      expect(antes.body[0]).toMatchObject({
        id: creado.body.id,
        fechaInicio: inicio,
        fechaFin: fin,
      });

      await http()
        .delete(`/api/v1/bienes/${bienId}/bloqueos/${antes.body[0].id}`)
        .set('Authorization', `Bearer ${tokens.dueno}`)
        .expect(204);

      const despues = await listar(tokens.dueno).expect(200);
      expect(despues.body).toEqual([]);
    });
  });
});
