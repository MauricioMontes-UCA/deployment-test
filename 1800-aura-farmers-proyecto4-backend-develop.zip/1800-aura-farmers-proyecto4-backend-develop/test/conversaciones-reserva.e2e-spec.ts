import type { INestApplication } from '@nestjs/common';
import request from 'supertest';
import { Prisma } from '@PrismaClient';
import { PrismaService } from '@Prisma/services';
import { crearApp } from './helpers/crear-app.js';

/**
 * Conversación de coordinación de la entrega por reserva (H14, BE-14.1) contra
 * la base real (DATABASE_URL).
 *
 * Los usuarios se registran por la API para tener tokens reales; los bienes y
 * las reservas se crean directo en la base, cada reserva en su propio bien
 * para no chocar con la restricción de solape. Todo lleva un sufijo único y se
 * borra al final.
 */
describe('Conversación de coordinación por reserva (e2e)', () => {
  let app: INestApplication;
  let prisma: PrismaService;

  const sufijo = Date.now().toString(36);
  const password = 'Str0ngPass';
  const ISO_8601 = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/;
  const ESTADO_NO_PERMITIDO =
    'La coordinación está disponible cuando la reserva está confirmada o en curso';
  const LONGITUD_INVALIDA =
    'El mensaje debe contener entre 1 y 1000 caracteres';
  const RESERVA_INEXISTENTE = '00000000-0000-4000-8000-0000000000ff';

  const usuario = (prefijo: string, rol: string) => ({
    nombreUsuario: `${prefijo}_${sufijo}`,
    email: `${prefijo}_${sufijo}@example.com`,
    password,
    rol,
  });
  const dueno = usuario('coord_dueno', 'ARRENDADOR');
  const inquilino = usuario('coord_inq', 'ARRENDATARIO');
  const ajeno = usuario('coord_ajeno', 'ARRENDATARIO');
  const otroDueno = usuario('coord_dueno2', 'ARRENDADOR');
  const otroInquilino = usuario('coord_inq2', 'ARRENDATARIO');
  const todos = [dueno, inquilino, ajeno, otroDueno, otroInquilino];
  const emails = todos.map((u) => u.email);

  const tokens: Record<string, string> = {};
  const ids: Record<string, string> = {};

  /** Reservas de prueba por nombre. */
  const reservas: Record<string, string> = {};
  const bienes: Record<string, string> = {};

  const servidor = () => app.getHttpServer();
  const token = (datos: ReturnType<typeof usuario>) =>
    `Bearer ${tokens[datos.nombreUsuario]}`;
  const id = (datos: ReturnType<typeof usuario>) => ids[datos.nombreUsuario]!;

  const registrarse = async (datos: ReturnType<typeof usuario>) => {
    await request(servidor()).post('/api/v1/users').send(datos).expect(201);
    const login = await request(servidor())
      .post('/api/v1/auth/login')
      .send({ email: datos.email, password: datos.password })
      .expect(200);
    tokens[datos.nombreUsuario] = login.body.accessToken as string;
    ids[datos.nombreUsuario] = login.body.user.id as string;
  };

  const crearReserva = async (
    nombre: string,
    arrendador: ReturnType<typeof usuario>,
    arrendatario: ReturnType<typeof usuario>,
    estado:
      | 'EN_COLA'
      | 'CONFIRMADA'
      | 'RECHAZADA'
      | 'EN_CURSO'
      | 'FINALIZADA'
      | 'CANCELADA',
  ) => {
    bienes[nombre] = (
      await prisma.bien.create({
        data: {
          arrendadorId: id(arrendador),
          tipo: 'PROPIEDAD',
          categoria: 'Casa',
          titulo: `Coordinación ${nombre} ${sufijo}`,
          descripcion: 'Bien de prueba e2e',
          precio: 30,
          unidadCobro: 'DIA',
          departamento: 'San Salvador',
          municipio: 'San Salvador',
        },
      })
    ).id;
    reservas[nombre] = (
      await prisma.reserva.create({
        data: {
          bienId: bienes[nombre]!,
          arrendatarioId: id(arrendatario),
          fechaInicio: new Date('2026-12-20T00:00:00.000Z'),
          fechaFin: new Date('2026-12-22T00:00:00.000Z'),
          estado,
        },
      })
    ).id;
  };

  const conversacion = (reservaId: string, autorizacion?: string) => {
    const peticion = request(servidor()).get(
      `/api/v1/reservas/${reservaId}/conversacion`,
    );
    return autorizacion
      ? peticion.set('Authorization', autorizacion)
      : peticion;
  };

  const enviar = (
    reservaId: string,
    autorizacion: string,
    cuerpo: Record<string, unknown>,
  ) =>
    request(servidor())
      .post(`/api/v1/reservas/${reservaId}/conversacion/mensajes`)
      .set('Authorization', autorizacion)
      .send(cuerpo);

  const historial = (reservaId: string, autorizacion: string, query = '') =>
    request(servidor())
      .get(`/api/v1/reservas/${reservaId}/conversacion/mensajes${query}`)
      .set('Authorization', autorizacion);

  const filasDeReserva = (reservaId: string) =>
    prisma.conversacion.count({ where: { reservaId } });

  const avisosDe = (mensajeId: string) =>
    prisma.notificacion.findMany({
      where: { tipoReferencia: 'MENSAJE', referenciaId: mensajeId },
    });

  beforeAll(async () => {
    app = await crearApp();
    prisma = app.get(PrismaService);

    for (const datos of todos) await registrarse(datos);

    await crearReserva('principal', dueno, inquilino, 'CONFIRMADA');
    await crearReserva('enCurso', otroDueno, otroInquilino, 'EN_CURSO');
    await crearReserva('primeraVez', dueno, inquilino, 'CONFIRMADA');
    await crearReserva('concurrente', dueno, inquilino, 'EN_CURSO');
    for (const estado of [
      'EN_COLA',
      'RECHAZADA',
      'FINALIZADA',
      'CANCELADA',
    ] as const) {
      await crearReserva(estado, dueno, inquilino, estado);
    }
  });

  afterAll(async () => {
    // Si beforeAll falló a medias, `prisma` y los ids pueden no existir.
    try {
      if (prisma) {
        const usuarios = { email: { in: emails } };
        const conversaciones = {
          OR: [{ arrendador: usuarios }, { arrendatario: usuarios }],
        };
        await prisma.mensaje.deleteMany({
          where: { conversacion: conversaciones },
        });
        // Las conversaciones apuntan a las reservas (Restrict): van antes.
        await prisma.conversacion.deleteMany({ where: conversaciones });
        await prisma.notificacion.deleteMany({
          where: { destinatario: usuarios },
        });
        await prisma.reserva.deleteMany({ where: { arrendatario: usuarios } });
        await prisma.bien.deleteMany({ where: { arrendador: usuarios } });
        await prisma.usuario.deleteMany({ where: usuarios });
      }
    } finally {
      await app?.close();
    }
  });

  describe('acceso', () => {
    it('sin token responde 401 en las tres rutas', async () => {
      await conversacion(reservas.principal!).expect(401);
      await request(servidor())
        .post(`/api/v1/reservas/${reservas.principal}/conversacion/mensajes`)
        .send({ contenido: 'Hola' })
        .expect(401);
      await request(servidor())
        .get(`/api/v1/reservas/${reservas.principal}/conversacion/mensajes`)
        .expect(401);
    });

    it('con un reservaId que no es UUID responde 400', async () => {
      await conversacion('no-es-uuid', token(inquilino)).expect(400);
      await historial('no-es-uuid', token(inquilino)).expect(400);
    });

    it('una reserva inexistente responde 404 "La reserva no existe."', async () => {
      const res = await conversacion(
        RESERVA_INEXISTENTE,
        token(inquilino),
      ).expect(404);

      expect(res.body.message).toBe('La reserva no existe.');
    });

    it('un usuario externo recibe 403 y no se crea ninguna conversación', async () => {
      const res = await conversacion(reservas.principal!, token(ajeno)).expect(
        403,
      );

      expect(JSON.stringify(res.body)).not.toContain(dueno.nombreUsuario);
      await enviar(reservas.principal!, token(ajeno), {
        contenido: 'Hola',
      }).expect(403);
      await historial(reservas.principal!, token(ajeno)).expect(403);
    });

    it('a un externo no le revela el estado: 403 aunque la reserva esté CANCELADA', async () => {
      await conversacion(reservas.CANCELADA!, token(ajeno)).expect(403);
    });

    it('el arrendador de otra reserva no entra en esta', async () => {
      await conversacion(reservas.principal!, token(otroDueno)).expect(403);
    });
  });

  describe('GET /reservas/:reservaId/conversacion', () => {
    it('la primera vez la crea y responde 200 con el resumen de la reserva', async () => {
      expect(await filasDeReserva(reservas.primeraVez!)).toBe(0);

      const res = await conversacion(
        reservas.primeraVez!,
        token(inquilino),
      ).expect(200);

      expect(res.body).toEqual({
        id: expect.any(String),
        reservaId: reservas.primeraVez,
        estado: 'CONFIRMADA',
        fechaInicio: '2026-12-20',
        fechaFin: '2026-12-22',
        bien: {
          id: bienes.primeraVez,
          titulo: `Coordinación primeraVez ${sufijo}`,
        },
        arrendador: { id: id(dueno), nombreUsuario: dueno.nombreUsuario },
        arrendatario: {
          id: id(inquilino),
          nombreUsuario: inquilino.nombreUsuario,
        },
        creadaEn: expect.stringMatching(ISO_8601),
      });
      expect(await filasDeReserva(reservas.primeraVez!)).toBe(1);
    });

    it('arrendador y arrendatario reciben la misma conversación, con 200', async () => {
      const deInquilino = await conversacion(
        reservas.principal!,
        token(inquilino),
      ).expect(200);
      const deDueno = await conversacion(
        reservas.principal!,
        token(dueno),
      ).expect(200);
      const otraVez = await conversacion(
        reservas.principal!,
        token(inquilino),
      ).expect(200);

      expect(deDueno.body.id).toBe(deInquilino.body.id);
      expect(otraVez.body.id).toBe(deInquilino.body.id);
      expect(await filasDeReserva(reservas.principal!)).toBe(1);
    });

    it('guarda en la base el bien y los participantes de la reserva', async () => {
      const fila = await prisma.conversacion.findUniqueOrThrow({
        where: { reservaId: reservas.principal },
      });

      expect(fila).toMatchObject({
        bienId: bienes.principal,
        arrendadorId: id(dueno),
        arrendatarioId: id(inquilino),
      });
    });

    it('con la reserva EN_CURSO también se puede coordinar', async () => {
      const res = await conversacion(
        reservas.enCurso!,
        token(otroInquilino),
      ).expect(200);

      expect(res.body.estado).toBe('EN_CURSO');
    });

    it('cinco peticiones simultáneas reciben 200 y la misma conversación, con una sola fila', async () => {
      const respuestas = await Promise.all(
        [inquilino, dueno, inquilino, dueno, inquilino].map((quien) =>
          conversacion(reservas.concurrente!, token(quien)),
        ),
      );

      expect(respuestas.map((r) => r.status)).toEqual([
        200, 200, 200, 200, 200,
      ]);
      expect(new Set(respuestas.map((r) => r.body.id)).size).toBe(1);
      expect(await filasDeReserva(reservas.concurrente!)).toBe(1);
    });

    it.each(['EN_COLA', 'RECHAZADA', 'FINALIZADA', 'CANCELADA'])(
      'con la reserva %s y sin conversación responde 422 con el mensaje de H14 y no crea nada',
      async (estado) => {
        const reservaId = reservas[estado]!;

        for (const res of [
          await conversacion(reservaId, token(inquilino)),
          await enviar(reservaId, token(dueno), { contenido: 'Hola' }),
          await historial(reservaId, token(inquilino)),
        ]) {
          expect(res.status).toBe(422);
          expect(res.body.message).toBe(ESTADO_NO_PERMITIDO);
        }
        expect(await filasDeReserva(reservaId)).toBe(0);
      },
    );

    it('las respuestas no llevan correos, contraseñas ni roles', async () => {
      const res = await conversacion(reservas.principal!, token(dueno)).expect(
        200,
      );
      const texto = JSON.stringify(res.body);

      for (const email of emails) expect(texto).not.toContain(email);
      expect(texto).not.toMatch(/password|email|"rol"|arrendadorId|precio/i);
    });
  });

  describe('POST /reservas/:reservaId/conversacion/mensajes', () => {
    it.each([
      ['vacío', ''],
      ['solo espacios', '   \n\t '],
      ['de 1001 caracteres', 'a'.repeat(1001)],
    ])('un mensaje %s responde 400', async (_caso, contenido) => {
      const res = await enviar(reservas.principal!, token(inquilino), {
        contenido,
      }).expect(400);

      expect(res.body.message).toEqual([LONGITUD_INVALIDA]);
    });

    it('sin contenido responde 400', async () => {
      await enviar(reservas.principal!, token(inquilino), {}).expect(400);
    });

    it('un remitenteId en el cuerpo responde 400: el remitente sale del token', async () => {
      await enviar(reservas.principal!, token(inquilino), {
        contenido: 'Hola',
        remitenteId: id(dueno),
      }).expect(400);
    });

    it('un mensaje de 1 carácter se guarda con 201', async () => {
      const res = await enviar(reservas.principal!, token(inquilino), {
        contenido: 'a',
      }).expect(201);

      expect(res.body.contenido).toBe('a');
    });

    it('un mensaje de 1000 caracteres (con emoji) se guarda con 201', async () => {
      const contenido = `${'x'.repeat(999)}😀`;

      const res = await enviar(reservas.principal!, token(dueno), {
        contenido,
      }).expect(201);

      expect(res.body.contenido).toBe(contenido);
    });

    it('el remitente es el usuario del token y se avisa solo al otro participante', async () => {
      const res = await enviar(reservas.principal!, token(dueno), {
        contenido: 'Entrego el sábado a las 9 en la entrada principal',
      }).expect(201);

      expect(res.body).toEqual({
        id: expect.any(String),
        conversacionId: expect.any(String),
        remitente: { id: id(dueno), nombreUsuario: dueno.nombreUsuario },
        contenido: 'Entrego el sábado a las 9 en la entrada principal',
        creadoEn: expect.stringMatching(ISO_8601),
      });

      const avisos = await avisosDe(res.body.id as string);
      expect(avisos).toHaveLength(1);
      expect(avisos[0]).toMatchObject({
        destinatarioId: id(inquilino),
        titulo: 'Mensaje sobre la entrega',
        mensaje: `${dueno.nombreUsuario}: Entrego el sábado a las 9 en la entrada principal`,
        moduloOrigen: 'MENSAJERIA',
        tipoReferencia: 'MENSAJE',
        referenciaId: res.body.id,
      });
      expect(
        await prisma.notificacion.count({
          where: { destinatarioId: id(dueno), referenciaId: res.body.id },
        }),
      ).toBe(0);
    });

    it('cada mensaje genera su propio aviso', async () => {
      const primero = await enviar(reservas.principal!, token(inquilino), {
        contenido: '¿Puede ser a las 10?',
      }).expect(201);
      const segundo = await enviar(reservas.principal!, token(inquilino), {
        contenido: 'Llevo a un ayudante.',
      }).expect(201);

      expect(await avisosDe(primero.body.id as string)).toHaveLength(1);
      expect(await avisosDe(segundo.body.id as string)).toHaveLength(1);
      expect(
        await prisma.notificacion.count({
          where: {
            destinatarioId: id(dueno),
            referenciaId: { in: [primero.body.id, segundo.body.id] },
          },
        }),
      ).toBe(2);
    });

    it('el mensaje queda en la conversación de la reserva', async () => {
      const { body: abierta } = await conversacion(
        reservas.principal!,
        token(dueno),
      ).expect(200);
      const res = await enviar(reservas.principal!, token(inquilino), {
        contenido: 'Confirmado',
      }).expect(201);

      expect(res.body.conversacionId).toBe(abierta.id);
    });
  });

  describe('GET /reservas/:reservaId/conversacion/mensajes', () => {
    const contenidos = ['primero', 'segundo', 'tercero'];

    beforeAll(async () => {
      for (const contenido of contenidos) {
        await enviar(reservas.enCurso!, token(otroDueno), {
          contenido,
        }).expect(201);
      }
    });

    it('por defecto lista en orden cronológico, con autor y fecha', async () => {
      const res = await historial(
        reservas.enCurso!,
        token(otroInquilino),
      ).expect(200);

      expect(res.body.orden).toBe('asc');
      expect(
        res.body.mensajes.map((m: { contenido: string }) => m.contenido),
      ).toEqual(contenidos);
      expect(res.body.mensajes[0]).toMatchObject({
        remitente: {
          id: id(otroDueno),
          nombreUsuario: otroDueno.nombreUsuario,
        },
        creadoEn: expect.stringMatching(ISO_8601),
      });
    });

    it('con orden=desc lista del más reciente al más antiguo', async () => {
      const res = await historial(
        reservas.enCurso!,
        token(otroDueno),
        '?orden=desc',
      ).expect(200);

      expect(
        res.body.mensajes.map((m: { contenido: string }) => m.contenido),
      ).toEqual([...contenidos].reverse());
    });

    it('un orden inválido responde 400', async () => {
      await historial(reservas.enCurso!, token(otroDueno), '?orden=x').expect(
        400,
      );
    });

    it('cada reserva ve solo sus mensajes', async () => {
      const deEnCurso = await historial(
        reservas.enCurso!,
        token(otroDueno),
      ).expect(200);
      const dePrincipal = await historial(
        reservas.principal!,
        token(dueno),
      ).expect(200);

      expect(deEnCurso.body.conversacionId).not.toBe(
        dePrincipal.body.conversacionId,
      );
      const textosEnCurso = deEnCurso.body.mensajes.map(
        (m: { contenido: string }) => m.contenido,
      );
      expect(textosEnCurso).not.toContain('Confirmado');
      expect(textosEnCurso).toEqual(contenidos);
      // Los participantes de una reserva no entran en la otra.
      await historial(reservas.principal!, token(otroInquilino)).expect(403);
      await historial(reservas.enCurso!, token(inquilino)).expect(403);
    });

    it('una reserva sin mensajes devuelve la lista vacía', async () => {
      const res = await historial(reservas.primeraVez!, token(dueno)).expect(
        200,
      );

      expect(res.body.mensajes).toEqual([]);
    });
  });

  describe('reservas cerradas: el historial se conserva y no se escribe', () => {
    const CERRADAS = ['FINALIZADA', 'CANCELADA'] as const;
    const textos = ['Entrego el sábado a las 9.', 'Perfecto, ahí estaré.'];
    /** Por reserva cerrada: id de la conversación y de sus mensajes. */
    const previo: Record<
      string,
      { conversacionId: string; mensajes: string[] }
    > = {};

    const contar = async (reservaId: string, conversacionId: string) => ({
      conversaciones: await filasDeReserva(reservaId),
      mensajes: await prisma.mensaje.count({ where: { conversacionId } }),
      avisos: await prisma.notificacion.count({
        where: {
          tipoReferencia: 'MENSAJE',
          referenciaId: { in: previo[reservaId]!.mensajes },
        },
      }),
      avisosTotales: await prisma.notificacion.count({
        where: { destinatarioId: { in: [id(dueno), id(inquilino)] } },
      }),
    });

    beforeAll(async () => {
      for (const estado of CERRADAS) {
        const nombre = `cerrada${estado}`;
        // Se crea activa, se coordina y luego se cierra.
        await crearReserva(nombre, dueno, inquilino, 'CONFIRMADA');
        const reservaId = reservas[nombre]!;
        const { body } = await conversacion(reservaId, token(inquilino)).expect(
          200,
        );
        const mensajes: string[] = [];
        for (const [i, contenido] of textos.entries()) {
          const autor = i === 0 ? dueno : inquilino;
          const res = await enviar(reservaId, token(autor), {
            contenido,
          }).expect(201);
          mensajes.push(res.body.id as string);
        }
        previo[reservaId] = { conversacionId: body.id as string, mensajes };
        await prisma.reserva.update({
          where: { id: reservaId },
          data: { estado },
        });
      }
    });

    it.each(CERRADAS)(
      'reserva %s: los dos participantes reciben la misma conversación con 200 y el estado nuevo',
      async (estado) => {
        const reservaId = reservas[`cerrada${estado}`]!;

        for (const quien of [dueno, inquilino]) {
          const res = await conversacion(reservaId, token(quien)).expect(200);
          expect(res.body).toMatchObject({
            id: previo[reservaId]!.conversacionId,
            reservaId,
            estado,
          });
        }
        expect(await filasDeReserva(reservaId)).toBe(1);
      },
    );

    it.each(CERRADAS)(
      'reserva %s: el historial completo se lee en asc y desc',
      async (estado) => {
        const reservaId = reservas[`cerrada${estado}`]!;

        const asc = await historial(reservaId, token(dueno)).expect(200);
        const desc = await historial(
          reservaId,
          token(inquilino),
          '?orden=desc',
        ).expect(200);

        expect(asc.body.conversacionId).toBe(previo[reservaId]!.conversacionId);
        expect(asc.body.mensajes.map((m: { id: string }) => m.id)).toEqual(
          previo[reservaId]!.mensajes,
        );
        expect(
          asc.body.mensajes.map((m: { contenido: string }) => m.contenido),
        ).toEqual(textos);
        expect(desc.body.mensajes.map((m: { id: string }) => m.id)).toEqual(
          [...previo[reservaId]!.mensajes].reverse(),
        );
      },
    );

    it.each(CERRADAS)(
      'reserva %s: enviar responde 422 y no crea mensajes, avisos ni conversaciones',
      async (estado) => {
        const reservaId = reservas[`cerrada${estado}`]!;
        const { conversacionId } = previo[reservaId]!;
        const antes = await contar(reservaId, conversacionId);

        for (const quien of [dueno, inquilino]) {
          const res = await enviar(reservaId, token(quien), {
            contenido: 'Un mensaje después del cierre',
          }).expect(422);
          expect(res.body.message).toBe(ESTADO_NO_PERMITIDO);
        }

        expect(await contar(reservaId, conversacionId)).toEqual(antes);
        expect(antes.mensajes).toBe(2);
        expect(antes.avisos).toBe(2);
      },
    );

    it.each(CERRADAS)(
      'reserva %s: un usuario externo recibe 403 en las tres rutas',
      async (estado) => {
        const reservaId = reservas[`cerrada${estado}`]!;

        await conversacion(reservaId, token(ajeno)).expect(403);
        await historial(reservaId, token(ajeno)).expect(403);
        await enviar(reservaId, token(ajeno), { contenido: 'Hola' }).expect(
          403,
        );
        await historial(reservaId, token(otroDueno)).expect(403);
      },
    );

    it.each(CERRADAS)(
      'reserva %s: cinco lecturas simultáneas devuelven la misma conversación y no crean otra',
      async (estado) => {
        const reservaId = reservas[`cerrada${estado}`]!;

        const respuestas = await Promise.all(
          [dueno, inquilino, dueno, inquilino, dueno].map((quien) =>
            conversacion(reservaId, token(quien)),
          ),
        );

        expect(respuestas.map((r) => r.status)).toEqual([
          200, 200, 200, 200, 200,
        ]);
        expect(new Set(respuestas.map((r) => r.body.id))).toEqual(
          new Set([previo[reservaId]!.conversacionId]),
        );
        expect(await filasDeReserva(reservaId)).toBe(1);
      },
    );
  });

  describe('integridad con H13 y la base', () => {
    it('las rutas de H13 no atienden la conversación de una reserva (404)', async () => {
      const { body } = await conversacion(
        reservas.principal!,
        token(inquilino),
      ).expect(200);

      await request(servidor())
        .post(`/api/v1/conversaciones/${body.id}/mensajes`)
        .set('Authorization', token(inquilino))
        .send({ contenido: 'Hola' })
        .expect(404);
      await request(servidor())
        .get(`/api/v1/conversaciones/${body.id}/mensajes`)
        .set('Authorization', token(dueno))
        .expect(404);
    });

    it('la base rechaza una segunda conversación para la misma reserva (UNIQUE reserva_id)', async () => {
      const error = await prisma.conversacion
        .create({
          data: {
            reservaId: reservas.principal!,
            bienId: bienes.principal!,
            arrendadorId: id(dueno),
            arrendatarioId: id(inquilino),
          },
        })
        .catch((e: unknown) => e);

      expect(error).toBeInstanceOf(Prisma.PrismaClientKnownRequestError);
      expect((error as Prisma.PrismaClientKnownRequestError).code).toBe(
        'P2002',
      );
      expect(await filasDeReserva(reservas.principal!)).toBe(1);
    });
  });
});
