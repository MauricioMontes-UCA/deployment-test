import type { INestApplication } from '@nestjs/common';
import request from 'supertest';
import { formatDia, hoyEn, ZONA_HORARIA } from '@Bienes/utils';
import { PrismaService } from '@Prisma/services';
import type { EstadoReserva } from '@PrismaClient';
import { ProcesadorColaService } from '@Reservas/services';
import { crearApp } from './helpers/crear-app.js';

/**
 * Bloqueos de fechas contra el Postgres de docker-compose (DATABASE_URL):
 * creación, eliminación, conflictos, autorización y su efecto sobre la cola de
 * reservas.
 *
 * Crea dos arrendadores, un arrendatario y dos bienes con sufijo único. Antes
 * de cada caso se borran las reservas y los bloqueos de esos bienes, así que
 * cada prueba parte de la base limpia y crea lo que necesita; no se toca el
 * resto de la base. Al final se borra todo lo creado.
 *
 * Las fechas de los bloqueos están en 2031 para no chocar con datos reales ni
 * con la regla de "inicio no anterior a hoy". Las solicitudes de reserva van a
 * pocos días de hoy porque POST /reservas no acepta más de 12 meses.
 */
describe('POST y DELETE /bienes/:bienId/bloqueos (e2e)', () => {
  let app: INestApplication;
  let prisma: PrismaService;
  let procesador: ProcesadorColaService;

  const sufijo = Date.now().toString(36);
  const nuevoUsuario = (
    prefijo: string,
    rol: 'ARRENDADOR' | 'ARRENDATARIO',
  ) => ({
    nombreUsuario: `${prefijo}_${sufijo}`,
    email: `${prefijo}_${sufijo}@example.com`,
    password: 'Str0ngPass',
    rol,
  });
  const dueno = nuevoUsuario('bloq_dueno', 'ARRENDADOR');
  const otro = nuevoUsuario('bloq_otro', 'ARRENDADOR');
  const arrendatario = nuevoUsuario('bloq_inq', 'ARRENDATARIO');

  const tokens = { dueno: '', otro: '', arrendatario: '' };
  let duenoId = '';
  let otroId = '';
  let arrendatarioId = '';
  let bienId = '';
  /** Bien del otro arrendador, para probar bloqueos que no son de `bienId`. */
  let bienAjenoId = '';
  const bienes = () => [bienId, bienAjenoId].filter(Boolean);

  const UUID_INEXISTENTE = '00000000-0000-4000-8000-000000000000';
  const dia = (valor: string) => new Date(`${valor}T00:00:00.000Z`);

  const http = () => request(app.getHttpServer());
  const bloquear = (token: string, body: object, id = bienId) =>
    http()
      .post(`/api/v1/bienes/${id}/bloqueos`)
      .set('Authorization', `Bearer ${token}`)
      .send(body);
  const desbloquear = (token: string, bloqueoId: string, id = bienId) =>
    http()
      .delete(`/api/v1/bienes/${id}/bloqueos/${bloqueoId}`)
      .set('Authorization', `Bearer ${token}`);
  /** Rangos bloqueados del bien según la disponibilidad pública. */
  const bloqueados = async (desde = '2031-01-01', hasta = '2031-12-31') =>
    (
      await http()
        .get(`/api/v1/bienes/${bienId}/disponibilidad`)
        .query({ desde, hasta })
        .set('Authorization', `Bearer ${tokens.dueno}`)
        .expect(200)
    ).body.bloqueados as { fechaInicio: string; fechaFin: string }[];

  /** Inserta una reserva del arrendatario en el bien, en el estado dado. */
  const reservar = async (
    estado: EstadoReserva,
    fechaInicio: string,
    fechaFin: string,
  ) =>
    (
      await prisma.reserva.create({
        data: {
          bienId,
          arrendatarioId,
          fechaInicio: dia(fechaInicio),
          fechaFin: dia(fechaFin),
          estado,
        },
      })
    ).id;

  async function registrar(usuario: ReturnType<typeof nuevoUsuario>) {
    await http().post('/api/v1/users').send(usuario).expect(201);
    const login = await http()
      .post('/api/v1/auth/login')
      .send({ email: usuario.email, password: usuario.password })
      .expect(200);
    return {
      token: login.body.accessToken as string,
      id: login.body.user.id as string,
    };
  }

  const datosBien = (arrendadorId: string, titulo: string) => ({
    arrendadorId,
    tipo: 'PROPIEDAD' as const,
    categoria: 'Casa',
    titulo,
    descripcion: 'Bien de prueba e2e',
    precio: 50,
    unidadCobro: 'NOCHE' as const,
    departamento: 'San Salvador',
    municipio: 'San Salvador',
  });

  beforeAll(async () => {
    // Las pruebas de la cola deciden cuándo se procesa una solicitud. Un .env
    // copiado de .env.example enciende el procesador de fondo, que la
    // resolvería antes de que exista el bloqueo; se apaga antes de crear la app.
    process.env.COLA_RESERVAS_ACTIVA = 'false';
    app = await crearApp();
    prisma = app.get(PrismaService);
    procesador = app.get(ProcesadorColaService);

    const d = await registrar(dueno);
    tokens.dueno = d.token;
    duenoId = d.id;
    const o = await registrar(otro);
    tokens.otro = o.token;
    otroId = o.id;
    const a = await registrar(arrendatario);
    tokens.arrendatario = a.token;
    arrendatarioId = a.id;

    bienId = (
      await prisma.bien.create({
        data: datosBien(duenoId, `Bien bloqueos ${sufijo}`),
      })
    ).id;
    bienAjenoId = (
      await prisma.bien.create({
        data: datosBien(otroId, `Bien ajeno bloqueos ${sufijo}`),
      })
    ).id;
  });

  beforeEach(async () => {
    // Base limpia para cada caso: nada de lo que dejó la prueba anterior.
    if (bienes().length > 0) {
      await prisma.reserva.deleteMany({ where: { bienId: { in: bienes() } } });
      await prisma.bloqueoFecha.deleteMany({
        where: { bienId: { in: bienes() } },
      });
    }
  });

  afterAll(async () => {
    // Si beforeAll falló antes de crear algo, los ids siguen vacíos y filtrar
    // una columna UUID con '' taparía el error original.
    if (bienes().length > 0) {
      await prisma.reserva.deleteMany({ where: { bienId: { in: bienes() } } });
      // Los bloqueos se borran en cascada con el bien.
      await prisma.bien.deleteMany({ where: { id: { in: bienes() } } });
    }
    // Solicitar una reserva le genera un aviso al arrendador, y el aviso impide
    // borrar a su destinatario.
    const usuarios = [duenoId, otroId, arrendatarioId].filter(Boolean);
    if (usuarios.length > 0) {
      await prisma.notificacion.deleteMany({
        where: { destinatarioId: { in: usuarios } },
      });
    }
    await prisma?.usuario.deleteMany({
      where: { email: { in: [dueno.email, otro.email, arrendatario.email] } },
    });
    delete process.env.COLA_RESERVAS_ACTIVA;
    await app?.close();
  });

  describe('crear un bloqueo', () => {
    it('201 con el bloqueo creado, que aparece en la disponibilidad del bien', async () => {
      const res = await bloquear(tokens.dueno, {
        fechaInicio: '2031-01-10',
        fechaFin: '2031-01-15',
      }).expect(201);

      expect(res.body).toEqual({
        id: expect.any(String),
        bienId,
        fechaInicio: '2031-01-10',
        fechaFin: '2031-01-15',
      });
      expect(await bloqueados()).toEqual([
        { fechaInicio: '2031-01-10', fechaFin: '2031-01-15' },
      ]);
    });

    it('201 con un solo día (inicio igual a fin)', async () => {
      await bloquear(tokens.dueno, {
        fechaInicio: '2031-02-01',
        fechaFin: '2031-02-01',
      }).expect(201);
    });

    it('401 sin sesión', async () => {
      await http()
        .post(`/api/v1/bienes/${bienId}/bloqueos`)
        .send({ fechaInicio: '2031-02-01', fechaFin: '2031-02-02' })
        .expect(401);
    });

    it('400 con formato inválido', async () => {
      await bloquear(tokens.dueno, {
        fechaInicio: '01/02/2031',
        fechaFin: '2031-02-02',
      }).expect(400);
      await bloquear(tokens.dueno, {
        fechaInicio: '2031-02-30',
        fechaFin: '2031-03-02',
      }).expect(400);
      await bloquear(
        tokens.dueno,
        { fechaInicio: '2031-02-01', fechaFin: '2031-02-02' },
        'no-es-uuid',
      ).expect(400);
    });

    it('403 si el bien es de otro arrendador, y no crea nada', async () => {
      await bloquear(tokens.otro, {
        fechaInicio: '2031-02-01',
        fechaFin: '2031-02-02',
      }).expect(403);

      expect(await prisma.bloqueoFecha.count({ where: { bienId } })).toBe(0);
    });

    it('403 a un ARRENDATARIO', async () => {
      await bloquear(tokens.arrendatario, {
        fechaInicio: '2031-02-01',
        fechaFin: '2031-02-02',
      }).expect(403);
    });

    it('404 si el bien no existe', async () => {
      const res = await bloquear(
        tokens.dueno,
        { fechaInicio: '2031-02-01', fechaFin: '2031-02-02' },
        UUID_INEXISTENTE,
      ).expect(404);

      expect(res.body.message).toBe('El bien no existe.');
    });

    it('422 si el inicio es anterior a hoy', async () => {
      const res = await bloquear(tokens.dueno, {
        fechaInicio: '2020-01-01',
        fechaFin: '2031-01-01',
      }).expect(422);

      expect(res.body.message).toBe(
        'La fecha de inicio no puede ser anterior a hoy.',
      );
    });

    it('422 si el fin es anterior al inicio', async () => {
      const res = await bloquear(tokens.dueno, {
        fechaInicio: '2031-02-10',
        fechaFin: '2031-02-01',
      }).expect(422);

      expect(res.body.message).toBe(
        'La fecha de fin no puede ser anterior a la de inicio.',
      );
    });
  });

  describe('conflictos al crear', () => {
    it.each(['CONFIRMADA', 'EN_CURSO'] as const)(
      '409 con el id de la reserva %s que cae en el rango',
      async (estado) => {
        const reservaId = await reservar(estado, '2031-03-10', '2031-03-12');

        const res = await bloquear(tokens.dueno, {
          fechaInicio: '2031-03-01',
          fechaFin: '2031-03-10',
        }).expect(409);

        expect(res.body).toEqual({
          message: 'El rango incluye una reserva confirmada o en curso.',
          error: 'Conflict',
          statusCode: 409,
          reservaId,
        });
        expect(await prisma.bloqueoFecha.count({ where: { bienId } })).toBe(0);
      },
    );

    it('409 con el id del bloqueo con el que se solapa', async () => {
      const existente = await bloquear(tokens.dueno, {
        fechaInicio: '2031-01-10',
        fechaFin: '2031-01-15',
      }).expect(201);

      const res = await bloquear(tokens.dueno, {
        fechaInicio: '2031-01-15',
        fechaFin: '2031-01-20',
      }).expect(409);

      expect(res.body).toEqual({
        message: 'El rango se solapa con otro bloqueo del bien.',
        error: 'Conflict',
        statusCode: 409,
        bloqueoId: existente.body.id,
      });
    });

    it('un rango contiguo a otro bloqueo no es conflicto', async () => {
      await bloquear(tokens.dueno, {
        fechaInicio: '2031-01-10',
        fechaFin: '2031-01-15',
      }).expect(201);

      await bloquear(tokens.dueno, {
        fechaInicio: '2031-01-16',
        fechaFin: '2031-01-20',
      }).expect(201);
    });

    it.each(['EN_COLA', 'RECHAZADA', 'CANCELADA'] as const)(
      'una reserva %s no impide bloquear sus días',
      async (estado) => {
        await reservar(estado, '2031-04-10', '2031-04-12');

        await bloquear(tokens.dueno, {
          fechaInicio: '2031-04-11',
          fechaFin: '2031-04-11',
        }).expect(201);
      },
    );

    it('de dos bloqueos solapados enviados a la vez solo se crea uno', async () => {
      const body = { fechaInicio: '2031-06-01', fechaFin: '2031-06-05' };
      const respuestas = await Promise.all([
        bloquear(tokens.dueno, body),
        bloquear(tokens.dueno, {
          fechaInicio: '2031-06-03',
          fechaFin: '2031-06-08',
        }),
        bloquear(tokens.dueno, body),
      ]);

      const codigos = respuestas.map((r) => r.status).sort((a, b) => a - b);
      expect(codigos).toEqual([201, 409, 409]);
      expect(await prisma.bloqueoFecha.count({ where: { bienId } })).toBe(1);
    });

    it('espera el candado del procesador de la cola y ve la reserva que confirmó', async () => {
      // Hace lo mismo que el procesador al confirmar una solicitud: toma el
      // candado del bien con la misma expresión, escribe la reserva CONFIRMADA y
      // tarda en terminar. El bloqueo que llega mientras tanto tiene que esperar
      // y, al ver la reserva, responder 409. Si los candados fueran distintos,
      // el bloqueo no esperaría y se crearía encima de la reserva.
      let candadoTomado!: () => void;
      const tomado = new Promise<void>((resolve) => (candadoTomado = resolve));
      let confirmadaId = '';

      const confirmacion = prisma.$transaction(async (tx) => {
        await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${bienId}))`;
        candadoTomado();
        confirmadaId = (
          await tx.reserva.create({
            data: {
              bienId,
              arrendatarioId,
              fechaInicio: dia('2031-09-10'),
              fechaFin: dia('2031-09-12'),
              estado: 'CONFIRMADA',
            },
          })
        ).id;
        await new Promise((resolve) => setTimeout(resolve, 600));
      });

      await tomado;
      const [res] = await Promise.all([
        bloquear(tokens.dueno, {
          fechaInicio: '2031-09-01',
          fechaFin: '2031-09-15',
        }),
        confirmacion,
      ]);

      expect(res.status).toBe(409);
      expect(res.body.reservaId).toBe(confirmadaId);
      expect(await prisma.bloqueoFecha.count({ where: { bienId } })).toBe(0);
    });
  });

  describe('eliminar un bloqueo', () => {
    it('204 y sus fechas vuelven a estar disponibles', async () => {
      const rango = { fechaInicio: '2031-08-01', fechaFin: '2031-08-03' };
      const creado = await bloquear(tokens.dueno, rango).expect(201);
      expect(await bloqueados()).toContainEqual(rango);

      const res = await desbloquear(
        tokens.dueno,
        creado.body.id as string,
      ).expect(204);

      expect(res.body).toEqual({});
      expect(await bloqueados()).toEqual([]);
      // Las fechas se pueden volver a bloquear.
      await bloquear(tokens.dueno, rango).expect(201);
    });

    it('401 sin sesión', async () => {
      await http()
        .delete(`/api/v1/bienes/${bienId}/bloqueos/${UUID_INEXISTENTE}`)
        .expect(401);
    });

    it('400 si un id no es un UUID', async () => {
      await desbloquear(tokens.dueno, 'no-es-uuid').expect(400);
      await desbloquear(tokens.dueno, UUID_INEXISTENTE, 'no-es-uuid').expect(
        400,
      );
    });

    it('403 si el bien es de otro arrendador, y el bloqueo sigue', async () => {
      const creado = await bloquear(tokens.dueno, {
        fechaInicio: '2031-09-01',
        fechaFin: '2031-09-01',
      }).expect(201);

      await desbloquear(tokens.otro, creado.body.id as string).expect(403);

      expect(
        await prisma.bloqueoFecha.count({ where: { id: creado.body.id } }),
      ).toBe(1);
    });

    it('404 si el bloqueo no existe', async () => {
      const res = await desbloquear(tokens.dueno, UUID_INEXISTENTE).expect(404);
      expect(res.body.message).toBe('El bloqueo no existe.');
    });

    it('404 si el bien no existe', async () => {
      const res = await desbloquear(
        tokens.dueno,
        UUID_INEXISTENTE,
        UUID_INEXISTENTE,
      ).expect(404);
      expect(res.body.message).toBe('El bien no existe.');
    });

    it('404 si el bloqueo es de otro bien, y no lo borra', async () => {
      const ajeno = await bloquear(
        tokens.otro,
        { fechaInicio: '2031-10-01', fechaFin: '2031-10-02' },
        bienAjenoId,
      ).expect(201);

      // El dueño de `bienId` pide borrar, bajo su bien, un bloqueo del otro bien.
      await desbloquear(tokens.dueno, ajeno.body.id as string).expect(404);

      expect(
        await prisma.bloqueoFecha.count({ where: { id: ajeno.body.id } }),
      ).toBe(1);
    });
  });

  describe('solicitud EN_COLA y bloqueo nuevo', () => {
    /**
     * El procesador toma la solicitud EN_COLA más antigua de toda la tabla. Se
     * mueve `creadaEn` de la solicitud al año 2000 para que sea la primera y no
     * se procesen las de otros datos, y el procesador recibe un "ahora" de ese
     * año para que no venza por el plazo de 5 minutos.
     */
    const BASE = new Date('2000-01-01T00:00:00.000Z');
    const AHORA = new Date(BASE.getTime() + 60 * 1000);

    /** Día a `n` días de hoy (El Salvador), dentro del horizonte de reservas. */
    const enDias = (n: number) => {
      const hoy = hoyEn(ZONA_HORARIA);
      return formatDia(new Date(hoy.getTime() + n * 24 * 60 * 60 * 1000));
    };
    const rango = () => ({ fechaInicio: enDias(60), fechaFin: enDias(62) });

    /** El arrendatario solicita la reserva por HTTP: queda EN_COLA. */
    const solicitar = async () => {
      const res = await http()
        .post('/api/v1/reservas')
        .set('Authorization', `Bearer ${tokens.arrendatario}`)
        .send({ bienId, ...rango() })
        .expect(202);
      expect(res.body.estado).toBe('EN_COLA');
      const id = res.body.id as string;
      await prisma.reserva.update({
        where: { id },
        data: { creadaEn: BASE },
      });
      return id;
    };

    /** Lo que ve el arrendatario al consultar su reserva. */
    const consultar = async (id: string) =>
      (
        await http()
          .get(`/api/v1/reservas/${id}`)
          .set('Authorization', `Bearer ${tokens.arrendatario}`)
          .expect(200)
      ).body as {
        estado: string;
        motivoResolucion: string | null;
        procesadaEn: string | null;
      };

    it('queda RECHAZADA con "Fechas no disponibles" al procesarse', async () => {
      const solicitudId = await solicitar();

      // La solicitud en cola no impide bloquear sus días.
      await bloquear(tokens.dueno, rango()).expect(201);

      const resultado = await procesador.procesarSiguiente(AHORA);

      expect(resultado).toMatchObject({
        tipo: 'PROCESADA',
        reserva: { id: solicitudId },
      });
      expect(await consultar(solicitudId)).toMatchObject({
        estado: 'RECHAZADA',
        motivoResolucion: 'FECHAS_NO_DISPONIBLES',
        procesadaEn: expect.any(String),
      });
      // El bloqueo se mantiene y las fechas siguen sin reservas.
      const { fechaInicio, fechaFin } = rango();
      expect(await bloqueados(fechaInicio, fechaFin)).toEqual([
        { fechaInicio, fechaFin },
      ]);
    });

    it('si el bloqueo se elimina antes de procesarla, queda CONFIRMADA', async () => {
      const solicitudId = await solicitar();
      const bloqueo = await bloquear(tokens.dueno, rango()).expect(201);
      await desbloquear(tokens.dueno, bloqueo.body.id as string).expect(204);

      await procesador.procesarSiguiente(AHORA);

      expect(await consultar(solicitudId)).toMatchObject({
        estado: 'CONFIRMADA',
        motivoResolucion: null,
      });
    });
  });
});
