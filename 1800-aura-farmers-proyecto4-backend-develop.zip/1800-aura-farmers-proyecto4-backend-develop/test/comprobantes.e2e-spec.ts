import type { INestApplication } from '@nestjs/common';
import request from 'supertest';
import { PrismaService } from '@Prisma/services';
import type { EstadoPago } from '@PrismaClient';
import { crearApp } from './helpers/crear-app.js';

/**
 * Comprobante de un pago (H9, BE-9.1) contra la base real (DATABASE_URL).
 *
 * El pago exitoso se crea con el endpoint de pago (BE-8.1), para comprobar que
 * el comprobante coincide con lo que quedó guardado. Los pagos rechazados o
 * pendientes se insertan directo. Todo lleva un sufijo único y se borra al
 * final.
 */
describe('GET /pagos/:pagoId/comprobante (e2e)', () => {
  let app: INestApplication;
  let prisma: PrismaService;

  const sufijo = Date.now().toString(36);
  const password = 'Str0ngPass';
  const usuario = (prefijo: string, rol: string) => ({
    nombreUsuario: `${prefijo}_${sufijo}`,
    email: `${prefijo}_${sufijo}@example.com`,
    password,
    rol,
  });
  const dueno = usuario('cmp_dueno', 'ARRENDADOR');
  const inquilino = usuario('cmp_inq', 'ARRENDATARIO');
  const ajeno = usuario('cmp_ajeno', 'ARRENDATARIO');

  let tokenDueno = '';
  let tokenInquilino = '';
  let tokenAjeno = '';
  let duenoId = '';
  let inquilinoId = '';

  const registrarse = async (datos: ReturnType<typeof usuario>) => {
    await request(app.getHttpServer())
      .post('/api/v1/users')
      .send(datos)
      .expect(201);
    const login = await request(app.getHttpServer())
      .post('/api/v1/auth/login')
      .send({ email: datos.email, password: datos.password })
      .expect(200);
    return {
      token: login.body.accessToken as string,
      id: login.body.user.id as string,
    };
  };

  /** Bien del dueño ($20.00 por día, depósito $25.00) y reserva CONFIRMADA. */
  const crearReserva = async () => {
    const bien = await prisma.bien.create({
      data: {
        arrendadorId: duenoId,
        tipo: 'PROPIEDAD',
        categoria: 'Casa',
        titulo: `Bien comprobante ${sufijo}`,
        descripcion: 'Bien de prueba e2e',
        precio: 20,
        unidadCobro: 'DIA',
        deposito: 25,
        departamento: 'San Salvador',
        municipio: 'San Salvador',
      },
    });
    const reserva = await prisma.reserva.create({
      data: {
        bienId: bien.id,
        arrendatarioId: inquilinoId,
        fechaInicio: new Date(Date.UTC(2027, 1, 10)),
        fechaFin: new Date(Date.UTC(2027, 1, 12)),
        estado: 'CONFIRMADA',
      },
    });
    return reserva.id;
  };

  /** Paga la reserva por la API y devuelve la respuesta del pago. */
  const pagarPorApi = async (reservaId: string) => {
    const res = await request(app.getHttpServer())
      .post(`/api/v1/reservas/${reservaId}/pagos`)
      .set('Authorization', `Bearer ${tokenInquilino}`)
      .send({
        modalidad: 'TARJETA',
        numeroTarjeta: '4242424242424242',
        vencimiento: '12/30',
        codigoSeguridad: '123',
      })
      .expect(201);
    return res.body as { pagoId: string; comprobanteId: string };
  };

  /** Inserta un pago sin comprobante en el estado dado. */
  const pagoSinComprobante = async (
    estado: Exclude<EstadoPago, 'SIMULADO_EXITOSO'>,
  ) => {
    const reservaId = await crearReserva();
    const pago = await prisma.pago.create({
      data: {
        reservaId,
        modalidad: 'TARJETA',
        importeAlquiler: 60,
        importeDeposito: 25,
        total: 85,
        estado,
        ultimosCuatro: '0002',
        motivoRechazo:
          estado === 'SIMULADO_RECHAZADO'
            ? 'Tarjeta rechazada por la pasarela simulada.'
            : null,
      },
    });
    return pago.id;
  };

  const comprobante = (
    pagoId: string,
    token: string | null = tokenInquilino,
  ) => {
    const peticion = request(app.getHttpServer()).get(
      `/api/v1/pagos/${pagoId}/comprobante`,
    );
    if (token) peticion.set('Authorization', `Bearer ${token}`);
    return peticion;
  };

  beforeAll(async () => {
    // Antes de crear la app: ConfigModule lee el entorno al importarse.
    process.env.PAGO_SIMULADO_DEMORA_MS = '0';
    app = await crearApp();
    prisma = app.get(PrismaService);

    ({ token: tokenDueno, id: duenoId } = await registrarse(dueno));
    ({ token: tokenInquilino, id: inquilinoId } = await registrarse(inquilino));
    ({ token: tokenAjeno } = await registrarse(ajeno));
  });

  afterAll(async () => {
    try {
      if (prisma && duenoId) {
        const deLosBienes = { bien: { arrendadorId: duenoId } };
        await prisma.pago.deleteMany({ where: { reserva: deLosBienes } });
        await prisma.deposito.deleteMany({ where: { reserva: deLosBienes } });
        await prisma.reserva.deleteMany({ where: deLosBienes });
        await prisma.bien.deleteMany({ where: { arrendadorId: duenoId } });
      }
      if (prisma) {
        await prisma.notificacion.deleteMany({
          where: {
            destinatario: {
              email: {
                in: [dueno.email, inquilino.email, ajeno.email],
              },
            },
          },
        });

        await prisma.usuario.deleteMany({
          where: {
            email: { in: [dueno.email, inquilino.email, ajeno.email] },
          },
        });
      }
    } finally {
      delete process.env.PAGO_SIMULADO_DEMORA_MS;
      await app?.close();
    }
  });

  it('devuelve el comprobante de un pago exitoso, igual a lo guardado', async () => {
    const reservaId = await crearReserva();
    const pagado = await pagarPorApi(reservaId);

    const res = await comprobante(pagado.pagoId).expect(200);

    const guardado = await prisma.pago.findUniqueOrThrow({
      where: { id: pagado.pagoId },
    });
    expect(res.body).toEqual({
      pagoId: guardado.id,
      comprobanteId: guardado.comprobanteId,
      reservaId,
      fechaHora: guardado.fechaHora.toISOString(),
      importeAlquiler: 60,
      importeDeposito: 25,
      total: 85,
      modalidad: 'TARJETA',
      estado: 'SIMULADO_EXITOSO',
    });
    expect(res.body.comprobanteId).toBe(pagado.comprobanteId);
  });

  it('el comprobante no expone datos de la tarjeta', async () => {
    const pagado = await pagarPorApi(await crearReserva());

    const res = await comprobante(pagado.pagoId).expect(200);

    expect(res.body).not.toHaveProperty('ultimosCuatro');
    expect(JSON.stringify(res.body)).not.toContain('4242');
  });

  it.each(['SIMULADO_RECHAZADO', 'PENDIENTE'] as const)(
    '409 si el pago está %s',
    async (estado) => {
      const pagoId = await pagoSinComprobante(estado);

      const res = await comprobante(pagoId).expect(409);

      expect(res.body.message).toBe(
        'El pago no cuenta con un comprobante de éxito.',
      );
    },
  );

  it('403 si el pago es de otro arrendatario, sin revelar datos', async () => {
    const pagado = await pagarPorApi(await crearReserva());

    const res = await comprobante(pagado.pagoId, tokenAjeno).expect(403);

    expect(res.body).not.toHaveProperty('total');
    expect(JSON.stringify(res.body)).not.toContain(pagado.comprobanteId);
  });

  it('403 para un arrendador, aunque sea el dueño del bien', async () => {
    const pagado = await pagarPorApi(await crearReserva());

    await comprobante(pagado.pagoId, tokenDueno).expect(403);
  });

  it('401 sin token', async () => {
    const pagado = await pagarPorApi(await crearReserva());

    await comprobante(pagado.pagoId, null).expect(401);
  });

  it('404 si el pago no existe', async () => {
    await comprobante('00000000-0000-4000-8000-0000000000ff').expect(404);
  });

  it('400 si el id no es un UUID', async () => {
    await comprobante('no-es-uuid').expect(400);
  });
});
