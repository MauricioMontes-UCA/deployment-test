import type { INestApplication } from '@nestjs/common';
import request from 'supertest';
import { PrismaService } from '@Prisma/services';
import { crearApp } from './helpers/crear-app.js';

/** Ejecuta el SQL real de la bandeja (LATERAL, COALESCE y OFFSET). */
describe('AF-167 / BE-13.2 Bandeja de conversaciones (e2e)', () => {
  let app: INestApplication;
  let prisma: PrismaService;

  const sufijo = `${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
  const password = 'Str0ngPass';
  const datos = (nombre: string, rol: 'ARRENDADOR' | 'ARRENDATARIO') => ({
    nombreUsuario: `${nombre}_${sufijo}`,
    email: `${nombre}_${sufijo}@example.com`,
    password,
    rol,
  });
  const dueno = datos('bd_dueno', 'ARRENDADOR');
  const inquilino = datos('bd_inq', 'ARRENDATARIO');
  const ajeno = datos('bd_ajeno', 'ARRENDATARIO');
  const usuarios = [dueno, inquilino, ajeno];
  const ids = new Map<string, string>();
  const tokens = new Map<string, string>();
  const conversaciones: string[] = [];
  let coordinacionId = '';
  let conMensajeId = '';
  let bienConFotoId = '';

  const servidor = () => app.getHttpServer();
  const id = (nombre: string) => {
    const valor = ids.get(nombre);
    if (!valor) throw new Error(`Usuario no registrado: ${nombre}`);
    return valor;
  };
  const token = (nombre: string) => {
    const valor = tokens.get(nombre);
    if (!valor) throw new Error(`Token no disponible: ${nombre}`);
    return `Bearer ${valor}`;
  };
  const bandeja = (nombre: string, query = '') =>
    request(servidor())
      .get(`/api/v1/conversaciones${query}`)
      .set('Authorization', token(nombre));

  beforeAll(async () => {
    app = await crearApp();
    prisma = app.get(PrismaService);

    for (const usuario of usuarios) {
      await request(servidor()).post('/api/v1/users').send(usuario).expect(201);
      const respuesta = await request(servidor())
        .post('/api/v1/auth/login')
        .send({ email: usuario.email, password })
        .expect(200);
      ids.set(usuario.nombreUsuario, respuesta.body.user.id as string);
      tokens.set(usuario.nombreUsuario, respuesta.body.accessToken as string);
    }

    // 25 conversaciones visibles: 24 CONSULTA y 1 COORDINACION.
    // Los timestamps controlados permiten verificar el orden sin depender del reloj.
    for (let i = 0; i < 25; i++) {
      const bien = await prisma.bien.create({
        data: {
          arrendadorId: id(dueno.nombreUsuario),
          tipo: 'PROPIEDAD',
          categoria: 'Casa',
          titulo: `Bandeja ${i} ${sufijo}`,
          descripcion: 'Bien de prueba e2e',
          precio: 30,
          unidadCobro: 'DIA',
          departamento: 'San Salvador',
          municipio: 'San Salvador',
        },
      });
      if (i === 0) {
        bienConFotoId = bien.id;
        await prisma.fotoBien.create({
          data: {
            bienId: bien.id,
            url: '/principal.jpg',
            orden: 0,
            esPrincipal: true,
          },
        });
      }

      const reserva =
        i === 24
          ? await prisma.reserva.create({
              data: {
                bienId: bien.id,
                arrendatarioId: id(inquilino.nombreUsuario),
                fechaInicio: new Date('2030-12-20T00:00:00.000Z'),
                fechaFin: new Date('2030-12-22T00:00:00.000Z'),
                estado: 'CONFIRMADA',
              },
            })
          : null;

      const conversacion = await prisma.conversacion.create({
        data: {
          bienId: bien.id,
          arrendadorId: id(dueno.nombreUsuario),
          arrendatarioId: id(inquilino.nombreUsuario),
          reservaId: reserva?.id ?? null,
          creadaEn: new Date(Date.UTC(2026, 0, 1, 0, i)),
        },
      });
      conversaciones.push(conversacion.id);
      if (i === 24) coordinacionId = conversacion.id;
      if (i === 0) conMensajeId = conversacion.id;
    }

    // El mensaje hace que la conversación más antigua pase al primer lugar.
    await prisma.mensaje.create({
      data: {
        conversacionId: conMensajeId,
        remitenteId: id(inquilino.nombreUsuario),
        contenido: '😀'.repeat(125),
        creadoEn: new Date('2027-01-01T00:00:00.000Z'),
      },
    });

    // Conversación de otro arrendador/arrendatario: no debe aparecer.
    const bienAjeno = await prisma.bien.create({
      data: {
        arrendadorId: id(dueno.nombreUsuario),
        tipo: 'PROPIEDAD',
        categoria: 'Casa',
        titulo: `Aislada ${sufijo}`,
        descripcion: 'Bien de prueba e2e',
        precio: 30,
        unidadCobro: 'DIA',
        departamento: 'San Salvador',
        municipio: 'San Salvador',
      },
    });
    const aislada = await prisma.conversacion.create({
      data: {
        bienId: bienAjeno.id,
        arrendadorId: id(dueno.nombreUsuario),
        arrendatarioId: id(ajeno.nombreUsuario),
      },
    });
    conversaciones.push(aislada.id);
  }, 60000);

  afterAll(async () => {
    try {
      if (!prisma) return;
      
      const usuariosIds = [...ids.values()];

      // 1. Eliminar mensajes de las conversaciones de esta prueba.
      if (conversaciones.length > 0) {
        await prisma.mensaje.deleteMany({
          where: {
            conversacionId: {
              in: conversaciones,
            },
          },
        });

        // 2. Eliminar las conversaciones creadas.
        await prisma.conversacion.deleteMany({
          where: {
            id: {
              in: conversaciones,
            },
          },
        });
      }
      
      if (usuariosIds.length > 0) {
        // 3. Eliminar notificaciones de los usuarios de prueba.
        await prisma.notificacion.deleteMany({
          where: {
            destinatarioId: {
              in: usuariosIds,
            },
          },
        });

        // 4. Eliminar reservas de los arrendatarios de prueba.
        await prisma.reserva.deleteMany({
          where: {
            arrendatarioId: {
              in: usuariosIds,
            },
          },
        });
        
        // 5. Eliminar los bienes creados por los arrendadores.
        // Las fotografías se eliminan mediante ON DELETE CASCADE.
        await prisma.bien.deleteMany({
          where: {
            arrendadorId: {
              in: usuariosIds,
            },
          },
        });

        // 6. Finalmente, eliminar los usuarios.
        await prisma.usuario.deleteMany({
          where: {
            id: {
              in: usuariosIds,
            },
          },
        });
      }
    } finally {
      await app?.close();
    }
  }, 60000);
  
  it('rechaza peticiones sin token (401)', async () => {
    await request(servidor()).get('/api/v1/conversaciones').expect(401);
  });

  it.each([
    '?tipo=OTRO',
    '?pagina=0',
    '?pagina=-1',
    '?pagina=1.5',
    '?pagina=10001',
  ])('rechaza parámetros inválidos: %s', async (query) => {
    await bandeja(inquilino.nombreUsuario, query).expect(400);
  });

  it('aísla participantes y mapea otroParticipante según el rol', async () => {
    const inq = await bandeja(inquilino.nombreUsuario, '?pagina=1').expect(200);
    expect(inq.body.total).toBe(25);
    expect(inq.body.items).toHaveLength(20);
    expect(
      inq.body.items.every(
        (item: { id: string }) => item.id !== conversaciones[25],
      ),
    ).toBe(true);
    expect(inq.body.items[0].otroParticipante).toMatchObject({
      id: id(dueno.nombreUsuario),
      nombreUsuario: dueno.nombreUsuario,
    });

    const tercero = await bandeja(ajeno.nombreUsuario).expect(200);
    expect(tercero.body.total).toBe(1);
    expect(tercero.body.items).toHaveLength(1);
    expect(tercero.body.items[0].id).toBe(conversaciones[25]);
    expect(tercero.body.items[0].otroParticipante.id).toBe(
      id(dueno.nombreUsuario),
    );

    const propietario = await bandeja(
      dueno.nombreUsuario,
      '?tipo=CONSULTA',
    ).expect(200);
    expect(propietario.body.items[0].otroParticipante.id).toBe(
      id(inquilino.nombreUsuario),
    );
  });

  it('aplica filtros CONSULTA y COORDINACION con total correcto', async () => {
    const consulta = await bandeja(
      inquilino.nombreUsuario,
      '?tipo=CONSULTA',
    ).expect(200);
    expect(consulta.body.total).toBe(24);
    expect(
      consulta.body.items.every(
        (item: { tipo: string }) => item.tipo === 'CONSULTA',
      ),
    ).toBe(true);

    const coordinacion = await bandeja(
      inquilino.nombreUsuario,
      '?tipo=COORDINACION',
    ).expect(200);
    expect(coordinacion.body.total).toBe(1);
    expect(coordinacion.body.items).toHaveLength(1);
    expect(coordinacion.body.items[0]).toMatchObject({
      id: coordinacionId,
      tipo: 'COORDINACION',
    });
  });

  it('ordena por último mensaje y, si no existe, por creadaEn', async () => {
    const primera = await bandeja(inquilino.nombreUsuario, '?pagina=1').expect(
      200,
    );
    expect(primera.body.items[0].id).toBe(conMensajeId);
    expect(primera.body.items[0].ultimoMensaje.contenido).toBe(
      '😀'.repeat(120),
    );
    expect(primera.body.items[1].id).toBe(coordinacionId);
    expect(primera.body.items[0].bien.fotoPrincipalUrl).toBe('/principal.jpg');
    expect(primera.body.items[0].bien.id).toBe(bienConFotoId);
  });

  it('pagina 20 + 5 + vacía sin duplicados y conserva total/hayMas', async () => {
    const primera = await bandeja(inquilino.nombreUsuario, '?pagina=1').expect(
      200,
    );
    const segunda = await bandeja(inquilino.nombreUsuario, '?pagina=2').expect(
      200,
    );
    const tercera = await bandeja(inquilino.nombreUsuario, '?pagina=3').expect(
      200,
    );

    expect(primera.body).toMatchObject({ pagina: 1, total: 25, hayMas: true });
    expect(segunda.body).toMatchObject({ pagina: 2, total: 25, hayMas: false });
    expect(tercera.body).toEqual({
      items: [],
      pagina: 3,
      total: 25,
      hayMas: false,
    });
    expect(primera.body.items).toHaveLength(20);
    expect(segunda.body.items).toHaveLength(5);
    const todos = [...primera.body.items, ...segunda.body.items] as {
      id: string;
    }[];
    expect(new Set(todos.map((item) => item.id)).size).toBe(25);
  });
});
