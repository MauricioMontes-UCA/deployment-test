import { randomUUID } from 'node:crypto';
import { INestApplication, ValidationPipe } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import request from 'supertest';
import { AppModule } from './../src/app.module.js';
import { PrismaService } from '@Prisma/services';
import { ProcesadorColaService } from '@Reservas/services';
import { ReservaRepository } from '@Reservas/repositories';
import { esViolacionDeSolape } from '@Reservas/utils';
import { EstadoReserva } from '@PrismaClient';

/**
 * Procesador de la cola de reservas contra la base real (DATABASE_URL).
 *
 * El procesador toma la solicitud EN_COLA más antigua de toda la tabla, así que
 * las solicitudes de estas pruebas se insertan con `creadaEn` en el año 2000:
 * son siempre las primeras de la cola y no se tocan las de otros datos. Para que
 * no venzan por el plazo de 5 minutos, el procesador recibe un "ahora" de ese
 * mismo año. Cada prueba procesa exactamente las solicitudes que creó.
 *
 * El procesador de fondo (evento y temporizador) está apagado con NODE_ENV=test,
 * así que nada resuelve la cola salvo lo que llamen las propias pruebas.
 */
describe('Procesador de la cola de reservas (e2e)', () => {
  let app: INestApplication;
  let prisma: PrismaService;
  let procesador: ProcesadorColaService;
  let repositorio: ReservaRepository;

  const sufijo = Date.now().toString(36);
  const password = 'Str0ngPass';

  const arrendador = {
    nombreUsuario: `cola_dueno_${sufijo}`,
    email: `cola_dueno_${sufijo}@example.com`,
    password,
    rol: 'ARRENDADOR',
  };
  const arrendatario = {
    nombreUsuario: `cola_inq_${sufijo}`,
    email: `cola_inq_${sufijo}@example.com`,
    password,
    rol: 'ARRENDATARIO',
  };

  let arrendadorId = '';
  let arrendatarioId = '';
  let bienId = '';
  let bienVerificadosId = '';

  const BASE = new Date('2000-01-01T00:00:00.000Z');
  /** "Ahora" del procesador: un minuto después de la primera solicitud. */
  const AHORA = new Date(BASE.getTime() + 60 * 1000);

  /** Día de 2032: dia(0) = 2032-03-01. */
  const dia = (offset: number) => new Date(Date.UTC(2032, 2, 1 + offset));

  const datosBien = (titulo: string) => ({
    arrendadorId,
    tipo: 'PROPIEDAD' as const,
    categoria: 'Casa',
    titulo,
    descripcion: 'Bien de prueba e2e',
    precio: 50,
    unidadCobro: 'NOCHE' as const,
    departamento: 'San Salvador',
    municipio: 'San Salvador',
  });

  /** Encola una solicitud directamente; `orden` fija quién llegó primero. */
  const encolar = (
    id: string,
    inicio: Date,
    fin: Date,
    orden: number,
    destino = bienId,
  ) =>
    prisma.reserva.create({
      data: {
        id,
        bienId: destino,
        arrendatarioId,
        fechaInicio: inicio,
        fechaFin: fin,
        creadaEn: new Date(BASE.getTime() + orden * 1000),
      },
    });

  /** Procesa exactamente `cantidad` solicitudes y devuelve lo que pasó con cada una. */
  const procesar = async (cantidad: number) => {
    const resultados = [];
    for (let i = 0; i < cantidad; i++) {
      resultados.push(await procesador.procesarSiguiente(AHORA));
    }
    return resultados;
  };

  const estadoDe = async (id: string) =>
    prisma.reserva.findUniqueOrThrow({
      where: { id },
      select: { estado: true, motivoResolucion: true, procesadaEn: true },
    });

  const nuevoId = () => randomUUID();

  /** Sigue procesando mientras quede alguna de estas solicitudes en cola. */
  const terminar = async (ids: string[]) => {
    for (let i = 0; i < ids.length; i++) {
      const pendientes = await prisma.reserva.count({
        where: { id: { in: ids }, estado: 'EN_COLA' },
      });
      if (pendientes === 0) return;
      await procesador.procesarSiguiente(AHORA);
    }
  };

  beforeAll(async () => {
    const moduleFixture = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();
    app = moduleFixture.createNestApplication();
    app.setGlobalPrefix('api/v1');
    app.useGlobalPipes(
      new ValidationPipe({
        whitelist: true,
        forbidNonWhitelisted: true,
        transform: true,
      }),
    );
    await app.init();
    prisma = app.get(PrismaService);
    procesador = app.get(ProcesadorColaService);
    repositorio = app.get(ReservaRepository);

    for (const usuario of [arrendador, arrendatario]) {
      await request(app.getHttpServer())
        .post('/api/v1/users')
        .send(usuario)
        .expect(201);
    }
    arrendadorId = (
      await prisma.usuario.findUniqueOrThrow({
        where: { email: arrendador.email },
      })
    ).id;
    arrendatarioId = (
      await prisma.usuario.findUniqueOrThrow({
        where: { email: arrendatario.email },
      })
    ).id;

    bienId = (await prisma.bien.create({ data: datosBien(`Bien ${sufijo}`) }))
      .id;
    bienVerificadosId = (
      await prisma.bien.create({
        data: {
          ...datosBien(`Verificados ${sufijo}`),
          politicaVerificacion: { create: { soloVerificados: true } },
        },
      })
    ).id;
  });

  afterEach(async () => {
    const bienes = [bienId, bienVerificadosId].filter(Boolean);
    if (bienes.length > 0) {
      await prisma.reserva.deleteMany({ where: { bienId: { in: bienes } } });
      await prisma.bloqueoFecha.deleteMany({
        where: { bienId: { in: bienes } },
      });
    }
    if (arrendatarioId) {
      await prisma.solicitudVerificacion.deleteMany({
        where: { usuarioId: arrendatarioId },
      });
    }
  });

  afterAll(async () => {
    // Si beforeAll falló antes de crear algo, los ids siguen vacíos: filtrarlos
    // evita un segundo error que taparía el original.
    const bienes = [bienId, bienVerificadosId].filter(Boolean);
    if (bienes.length > 0) {
      await prisma.reserva.deleteMany({ where: { bienId: { in: bienes } } });
      await prisma.bien.deleteMany({ where: { id: { in: bienes } } });
    }
    const emails = [arrendador.email, arrendatario.email];
    await prisma.solicitudVerificacion.deleteMany({
      where: { usuario: { email: { in: emails } } },
    });
    await prisma.usuario.deleteMany({ where: { email: { in: emails } } });
    await app.close();
  });

  it('con tres solicitudes solapadas confirma la primera por creadaEn y rechaza las otras dos', async () => {
    // Se insertan fuera de orden para comprobar que manda creadaEn, no el insert.
    const [a, b, c] = [nuevoId(), nuevoId(), nuevoId()];
    await encolar(c, dia(0), dia(5), 3);
    await encolar(a, dia(0), dia(5), 1);
    await encolar(b, dia(2), dia(7), 2);

    await procesar(3);

    expect(await estadoDe(a)).toMatchObject({
      estado: 'CONFIRMADA',
      motivoResolucion: null,
    });
    for (const id of [b, c]) {
      expect(await estadoDe(id)).toMatchObject({
        estado: 'RECHAZADA',
        motivoResolucion: 'FECHAS_NO_DISPONIBLES',
      });
    }
    for (const id of [a, b, c]) {
      expect((await estadoDe(id)).procesadaEn).not.toBeNull();
    }
  });

  it('con solicitudes sin solape sobre el mismo bien confirma todas', async () => {
    const ids = [nuevoId(), nuevoId(), nuevoId()];
    await encolar(ids[0], dia(0), dia(2), 1);
    await encolar(ids[1], dia(3), dia(5), 2);
    await encolar(ids[2], dia(6), dia(8), 3);

    await procesar(3);

    for (const id of ids) {
      expect((await estadoDe(id)).estado).toBe('CONFIRMADA');
    }
  });

  it('rechaza con VERIFICACION_REQUERIDA si la verificación se revocó antes de procesarla', async () => {
    const id = nuevoId();
    // Estaba aprobada al encolar y se revocó después: la más reciente manda.
    await prisma.solicitudVerificacion.create({
      data: {
        usuarioId: arrendatarioId,
        estado: 'APROBADA',
        creadaEn: new Date('2000-01-01T00:00:00.000Z'),
      },
    });
    await prisma.solicitudVerificacion.create({
      data: {
        usuarioId: arrendatarioId,
        estado: 'RECHAZADA',
        creadaEn: new Date('2000-01-02T00:00:00.000Z'),
      },
    });
    await encolar(id, dia(0), dia(2), 1, bienVerificadosId);

    await procesar(1);

    expect(await estadoDe(id)).toMatchObject({
      estado: 'RECHAZADA',
      motivoResolucion: 'VERIFICACION_REQUERIDA',
    });
  });

  it('confirma en un bien solo para verificados si el usuario sigue verificado', async () => {
    const id = nuevoId();
    await prisma.solicitudVerificacion.create({
      data: { usuarioId: arrendatarioId, estado: 'APROBADA' },
    });
    await encolar(id, dia(0), dia(2), 1, bienVerificadosId);

    await procesar(1);

    expect((await estadoDe(id)).estado).toBe('CONFIRMADA');
  });

  it.each(['CONFIRMADA', 'EN_CURSO', 'FINALIZADA'] as const)(
    'rechaza si una reserva %s ya ocupa los días',
    async (estado) => {
      const id = nuevoId();
      await prisma.reserva.create({
        data: {
          bienId,
          arrendatarioId,
          fechaInicio: dia(1),
          fechaFin: dia(3),
          estado,
        },
      });
      await encolar(id, dia(3), dia(5), 1);

      await procesar(1);

      expect(await estadoDe(id)).toMatchObject({
        estado: 'RECHAZADA',
        motivoResolucion: 'FECHAS_NO_DISPONIBLES',
      });
    },
  );

  it('rechaza si un bloqueo del arrendador cubre los días', async () => {
    const id = nuevoId();
    await prisma.bloqueoFecha.create({
      data: { bienId, fechaInicio: dia(4), fechaFin: dia(6) },
    });
    await encolar(id, dia(5), dia(7), 1);

    await procesar(1);

    expect(await estadoDe(id)).toMatchObject({
      estado: 'RECHAZADA',
      motivoResolucion: 'FECHAS_NO_DISPONIBLES',
    });
  });

  it('las reservas RECHAZADA y CANCELADA no bloquean', async () => {
    const id = nuevoId();
    await prisma.reserva.createMany({
      data: (['RECHAZADA', 'CANCELADA'] as const).map((estado) => ({
        bienId,
        arrendatarioId,
        fechaInicio: dia(0),
        fechaFin: dia(2),
        estado,
      })),
    });
    await encolar(id, dia(0), dia(2), 1);

    await procesar(1);

    expect((await estadoDe(id)).estado).toBe('CONFIRMADA');
  });

  it('rechaza con ERROR_DE_PROCESAMIENTO una solicitud que lleva más de 5 minutos en cola', async () => {
    const id = nuevoId();
    await encolar(id, dia(0), dia(2), 1);

    // "Ahora" a 6 minutos de que se encoló.
    await procesador.procesarSiguiente(
      new Date(BASE.getTime() + 1000 + 6 * 60 * 1000),
    );

    expect(await estadoDe(id)).toMatchObject({
      estado: 'RECHAZADA',
      motivoResolucion: 'ERROR_DE_PROCESAMIENTO',
    });
  });

  it('una solicitud insertada sin ningún evento, como tras un reinicio, se procesa igual', async () => {
    const id = nuevoId();
    await encolar(id, dia(0), dia(2), 1);

    const [resultado] = await procesar(1);

    expect(resultado).toMatchObject({ tipo: 'PROCESADA' });
    expect((await estadoDe(id)).estado).toBe('CONFIRMADA');
  });

  describe('con procesadores simultáneos', () => {
    it('cada solicitud se resuelve una sola vez, sin duplicados ni pérdidas', async () => {
      const ids = [nuevoId(), nuevoId(), nuevoId(), nuevoId()];
      await Promise.all(
        ids.map((id, i) => encolar(id, dia(i * 3), dia(i * 3 + 1), i + 1)),
      );

      // Cuatro procesadores a la vez sobre cuatro solicitudes sin solape.
      const resultados = await Promise.all(
        ids.map(() => procesador.procesarSiguiente(AHORA)),
      );

      type ResultadoProcesamiento = Awaited<
        ReturnType<typeof procesador.procesarSiguiente>
      >;

      const procesadas = resultados.flatMap((r: ResultadoProcesamiento) =>
        r.tipo === 'PROCESADA' ? [r.reserva.id] : [],
      );
      expect(new Set(procesadas).size).toBe(procesadas.length);
      // Lo que se aplazó o llegó con la cola ya vacía se completa después.
      await terminar(ids);

      for (const id of ids) {
        expect((await estadoDe(id)).estado).toBe('CONFIRMADA');
      }
    });

    it('con solicitudes solapadas gana la más antigua aunque se procesen a la vez', async () => {
      const [primera, segunda, tercera] = [nuevoId(), nuevoId(), nuevoId()];
      await encolar(primera, dia(0), dia(4), 1);
      await encolar(segunda, dia(1), dia(5), 2);
      await encolar(tercera, dia(2), dia(6), 3);

      await Promise.all([
        procesador.procesarSiguiente(AHORA),
        procesador.procesarSiguiente(AHORA),
        procesador.procesarSiguiente(AHORA),
      ]);
      // Si alguna quedó aplazada (la anterior estaba en manos de otro), se termina aquí.
      await terminar([primera, segunda, tercera]);

      expect((await estadoDe(primera)).estado).toBe('CONFIRMADA');
      expect((await estadoDe(segunda)).estado).toBe('RECHAZADA');
      expect((await estadoDe(tercera)).estado).toBe('RECHAZADA');
    });

    it('BE-6.4: con 20 solicitudes solapadas en paralelo solo una queda CONFIRMADA', async () => {
      const CANTIDAD = 20;

      // Cada solicitud tiene un UUID diferente.
      const ids = Array.from({ length: CANTIDAD }, () => nuevoId());

      // Todas solicitan exactamente las mismas fechas
      // sobre el mismo bien.
      const fechaInicio = dia(20);
      const fechaFin = dia(25);

      // Insertar las 20 solicitudes simultáneamente.
      // Se utiliza el repositorio real de Prisma/PostgreSQL.
      await Promise.all(
        ids.map((id, indice) => encolar(id, fechaInicio, fechaFin, indice + 1)),
      );

      // Comprobar que las 20 solicitudes existen
      // inicialmente con estado EN_COLA.
      const inicialmenteEnCola = await prisma.reserva.count({
        where: {
          id: { in: ids },
          estado: 'EN_COLA',
        },
      });

      expect(inicialmenteEnCola).toBe(CANTIDAD);

      // Simular 20 procesadores intentando resolver
      // las solicitudes al mismo tiempo.
      //
      // allSettled permite inspeccionar el resultado
      // incluso si alguna transacción falla.
      const resultados = await Promise.allSettled(
        ids.map(() => procesador.procesarSiguiente(AHORA)),
      );

      // Aplazar o rechazar una solicitud es un resultado normal; que el
      // procesador lance un error no lo es. Si alguna llamada falla, sale aquí
      // con su motivo y no se esconde detrás del estado final. Antes de que el
      // procesador usara su propia transacción para leer la verificación, las
      // 20 llamadas fallaban aquí por falta de conexiones (P2028) y el test
      // solo terminaba bien porque la ronda siguiente las procesaba una a una.
      expect(resultados.filter((r) => r.status === 'rejected')).toEqual([]);

      // El procesador puede aplazar una solicitud cuando
      // otra transacción está trabajando sobre el mismo bien.
      //
      // Completamos las pendientes en nuevas rondas.
      // No se crea una segunda solicitud ni se repite
      // una reserva que ya fue procesada.
      let pendientes = CANTIDAD;

      for (
        let intento = 0;
        intento < CANTIDAD * 5 && pendientes > 0;
        intento++
      ) {
        pendientes = await prisma.reserva.count({
          where: {
            id: { in: ids },
            estado: 'EN_COLA',
          },
        });

        if (pendientes === 0) {
          break;
        }

        await procesador.procesarSiguiente(AHORA);
      }

      type ReservaConsultada = {
        id: string;
        estado: EstadoReserva;
        motivoResolucion: string | null;
        procesadaEn: Date | null;
        fechaInicio: Date;
        fechaFin: Date;
      };

      const reservas: ReservaConsultada[] = await prisma.reserva.findMany({
        where: {
          id: { in: ids },
        },
        select: {
          id: true,
          estado: true,
          motivoResolucion: true,
          procesadaEn: true,
          fechaInicio: true,
          fechaFin: true,
        },
      });

      const confirmadas = reservas.filter(
        (reserva) => reserva.estado === EstadoReserva.CONFIRMADA,
      );

      const rechazadas = reservas.filter(
        (reserva) => reserva.estado === EstadoReserva.RECHAZADA,
      );

      const enCola = reservas.filter(
        (reserva) => reserva.estado === EstadoReserva.EN_COLA,
      );

      // Deben existir exactamente las 20 reservas.
      expect(reservas).toHaveLength(CANTIDAD);

      // Ninguna solicitud debe perderse o permanecer pendiente.
      expect(enCola).toHaveLength(0);

      // La regla principal de concurrencia:
      // exactamente una reserva puede ocupar esas fechas.
      expect(confirmadas).toHaveLength(1);

      // Y es la más antigua: `encolar` da a ids[0] la `creadaEn` menor.
      expect(confirmadas[0].id).toBe(ids[0]);

      // Las otras 19 deben rechazarse.
      expect(rechazadas).toHaveLength(19);

      // Todas las rechazadas deben indicar conflicto de fechas.
      for (const reserva of rechazadas) {
        expect(reserva.motivoResolucion).toBe('FECHAS_NO_DISPONIBLES');
      }

      // Todas deben tener registrada su fecha de procesamiento.
      for (const reserva of reservas) {
        expect(reserva.procesadaEn).not.toBeNull();
      }

      // Comprobación adicional directamente contra PostgreSQL:
      // no puede haber más de una CONFIRMADA para ese rango.
      const totalConfirmadas = await prisma.reserva.count({
        where: {
          id: { in: ids },
          estado: 'CONFIRMADA',
          fechaInicio: {
            lte: fechaFin,
          },
          fechaFin: {
            gte: fechaInicio,
          },
        },
      });

      expect(totalConfirmadas).toBe(1);
    }, 60_000);
  });

  describe('restricción reserva_sin_solape', () => {
    it('el error real de Prisma 7 al chocar con la restricción se reconoce', async () => {
      await prisma.reserva.create({
        data: {
          bienId,
          arrendatarioId,
          fechaInicio: dia(0),
          fechaFin: dia(4),
          estado: 'CONFIRMADA',
        },
      });
      const solicitud = await encolar(nuevoId(), dia(2), dia(6), 1);

      const error: unknown = await prisma.reserva
        .update({
          where: { id: solicitud.id },
          data: { estado: 'CONFIRMADA' },
        })
        .then(
          () => null,
          (e: unknown) => e,
        );

      expect(error).not.toBeNull();
      expect(esViolacionDeSolape(error)).toBe(true);
    });

    it('si la base la rechaza al confirmar, la solicitud queda RECHAZADA por fechas', async () => {
      await prisma.reserva.create({
        data: {
          bienId,
          arrendatarioId,
          fechaInicio: dia(0),
          fechaFin: dia(4),
          estado: 'CONFIRMADA',
        },
      });
      const id = nuevoId();
      await encolar(id, dia(2), dia(6), 1);

      // Un resolver que confirma sin mirar las fechas fuerza el choque en la base.
      const resultado = await repositorio.procesarSiguiente(AHORA, () =>
        Promise.resolve({ estado: 'CONFIRMADA' }),
      );

      expect(resultado).toMatchObject({ tipo: 'PROCESADA' });
      expect(await estadoDe(id)).toMatchObject({
        estado: 'RECHAZADA',
        motivoResolucion: 'FECHAS_NO_DISPONIBLES',
      });
    });
  });
});
