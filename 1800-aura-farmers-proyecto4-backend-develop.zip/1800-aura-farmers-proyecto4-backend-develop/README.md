# Aura Farmers API

API REST de Aura Farmers, la plataforma de renta de propiedades y equipo entre arrendadores y arrendatarios. Construida con **NestJS 12**, **Prisma 7** y **PostgreSQL 18**.

---

## Tabla de contenidos

- [Guía de uso](#guía-de-uso)
- [Stack técnico](#stack-técnico)
- [Requisitos previos](#requisitos-previos)
- [Variables de entorno](#variables-de-entorno)
- [Cómo levantar el proyecto](#cómo-levantar-el-proyecto)
  - [Opción A: todo con Docker](#opción-a-todo-con-docker)
  - [Opción B: Postgres en Docker + API en el host](#opción-b-postgres-en-docker--api-en-el-host-recomendado-para-desarrollar)
- [Docker en detalle](#docker-en-detalle)
- [Prisma en detalle](#prisma-en-detalle)
- [Autenticación](#autenticación)
- [Endpoints](#endpoints)
- [Arquitectura por capas](#arquitectura-por-capas)
- [Path aliases](#path-aliases)
- [Estructura del proyecto](#estructura-del-proyecto)
- [Scripts disponibles](#scripts-disponibles)

---

## Guía de uso

La guía para usar Aura Farmers desde el navegador, por rol y por módulo, está en [docs/01-guia-de-uso.md](docs/01-guia-de-uso.md).

---

## Stack técnico

| Tecnología | Versión | Para qué se usa |
|---|---|---|
| [NestJS](https://nestjs.com) | 12 | Framework HTTP. Módulos, inyección de dependencias, guards y pipes |
| [TypeScript](https://www.typescriptlang.org) | 6 | Tipado estático. El proyecto es **ESM puro** (`"type": "module"`) |
| [Prisma ORM](https://www.prisma.io) | 7 | ORM y motor de migraciones versionadas |
| [PostgreSQL](https://www.postgresql.org) | 18 | Base de datos relacional |
| [@nestjs/jwt](https://github.com/nestjs/jwt) | 12 | Firma y verificación de los JWT de acceso |
| [bcrypt](https://github.com/kelektiv/node.bcrypt.js) | 6 | Hasheo de contraseñas (cost 12 por defecto) |
| [class-validator](https://github.com/typestack/class-validator) | 0.15 | Validación declarativa de los DTO de entrada |
| [Swagger](https://docs.nestjs.com/openapi/introduction) | 12 | Documentación OpenAPI en `/api/docs` |
| [tsc-alias](https://github.com/justkey007/tsc-alias) | 1 | Reescribe los path aliases del JS compilado (ver [Path aliases](#path-aliases)) |
| [Vitest](https://vitest.dev) | 4 | Tests unitarios y e2e |
| [oxlint](https://oxc.rs) | 1 | Linter (con chequeos type-aware) |

### Dos detalles del stack que conviene saber

**El proyecto es ESM puro.** `package.json` declara `"type": "module"` y el `tsconfig.json` usa `moduleResolution: nodenext`. En la práctica: **todo import relativo lleva la extensión `.js`**, incluso apuntando a un archivo `.ts`.

```ts
import { AuthService } from './auth.service.js'; // ✅
import { AuthService } from './auth.service';    // ❌ falla en runtime
```

**Prisma 7 no lee la conexión desde `schema.prisma`.** A diferencia de versiones anteriores, la connection string se entrega en tiempo de ejecución mediante un *driver adapter* (`@prisma/adapter-pg`). Eso ocurre en [prisma.service.ts](src/prisma/prisma.service.ts). El CLI, por su lado, la toma de [prisma.config.ts](prisma.config.ts).

---

## Requisitos previos

- **Node.js ≥ 20.19** (recomendado 22 o 24). Prisma 7 requiere `^20.19 || ^22.12 || >=24`
- **Docker** y **Docker Compose v2+**
- **npm**, **yarn** o **pnpm**

---

## Variables de entorno

Copiá la plantilla y ajustá lo que necesites:

```bash
cp .env.example .env
```

| Variable | Default | Descripción |
|---|---|---|
| `NODE_ENV` | `development` | Entorno de ejecución |
| `PORT` | `3000` | Puerto HTTP de la API |
| `POSTGRES_USER` | `postgres` | Usuario que crea el contenedor de Postgres |
| `POSTGRES_PASSWORD` | `postgres` | Contraseña de ese usuario |
| `POSTGRES_DB` | `si_be_boilerplate` | Base que se crea al inicializar |
| `POSTGRES_PORT` | `5432` | Puerto publicado en el host |
| `DATABASE_URL` | — | **Obligatoria.** Connection string de Prisma |
| `JWT_SECRET` | — | **Obligatoria.** Mínimo 32 caracteres |
| `JWT_EXPIRES_IN` | `15m` | Vigencia del access token |
| `REFRESH_TOKEN_EXPIRES_IN_DAYS` | `7` | Vigencia del refresh token |
| `BCRYPT_SALT_ROUNDS` | `12` | Cost factor de bcrypt |
| `UPLOADS_DIR` | `uploads` | Carpeta donde se guardan las fotos de los bienes. Se sirve en `/uploads` |
| `PAGO_SIMULADO_DEMORA_MS` | `2000` | Milisegundos que tarda la pasarela de pago simulada. `0` la desactiva |
| `COLA_RESERVAS_ACTIVA` | `true` (`false` con `NODE_ENV=test`) | Si este proceso resuelve la cola de solicitudes de reserva |
| `COLA_RESERVAS_INTERVALO_MS` | `30000` | Cada cuántos milisegundos se revisa la cola, además de al encolar |
| `CORS_ORIGINS` | `http://localhost:5173` fuera de producción (**obligatoria** con `NODE_ENV=production`) | Orígenes, separados por coma, que pueden llamar a la API desde el navegador. En despliegue, la URL del frontend (`https://...`, sin ruta ni barra final). No acepta `*` |
| `REVISION_VERIFICACION_ACTIVA` | `true` fuera de las pruebas (se apaga con `false`; siempre `false` con `NODE_ENV=test`) | Si este proceso ejecuta la revisión simulada de documentos de identidad (H18) |

> La app **valida el entorno al arrancar** ([env.validation.ts](src/config/env.validation.ts)). Si falta `DATABASE_URL` o `JWT_SECRET`, o si el secreto es más corto que 32 caracteres, falla de inmediato con un mensaje claro en lugar de romperse más tarde.

Generá un secreto real con:

```bash
openssl rand -base64 32
```

> **Ojo con el host de la base.** Si corrés la API en tu máquina, `DATABASE_URL` apunta a `localhost`. Si la corrés dentro de Compose, el host es el nombre del servicio (`postgres`); eso ya lo resuelve `docker-compose.yml` sobreescribiendo la variable.

---

## Cómo levantar el proyecto

### Opción A: todo con Docker

Levanta Postgres y la API juntos. La API aplica las migraciones pendientes al arrancar.

```bash
cp .env.example .env
docker compose up --build
```

Listo: la API queda en `http://localhost:3000/api/v1` y la documentación en `http://localhost:3000/api/docs`.

Para cargar el usuario de prueba:

```bash
docker compose exec api npx prisma db seed
```

### Opción B: Postgres en Docker + API en el host (recomendado para desarrollar)

Te da hot reload y stack traces directos, usando el mismo Postgres del contenedor.

```bash
# 1. Variables de entorno
cp .env.example .env

# 2. Solo la base
docker compose up -d postgres

# 3. Dependencias (el postinstall genera el cliente de Prisma)
npm install          # o: yarn install  /  pnpm install

# 4. Aplicar migraciones y cargar el usuario demo
npm run prisma:migrate
npm run db:seed

# 5. Arrancar en watch mode
npm run start:dev
```

<details>
<summary>Equivalencias con yarn y pnpm</summary>

| npm | yarn | pnpm |
|---|---|---|
| `npm install` | `yarn install` | `pnpm install` |
| `npm run start:dev` | `yarn start:dev` | `pnpm start:dev` |
| `npm run prisma:migrate` | `yarn prisma:migrate` | `pnpm prisma:migrate` |
| `npm run db:seed` | `yarn db:seed` | `pnpm db:seed` |

</details>

Verificá que responde:

```bash
curl http://localhost:3000/api/v1
# Hello World!
```

---

## Docker en detalle

Hay dos piezas, con responsabilidades distintas:

### `docker-compose.yml` — orquesta el entorno

Define dos servicios:

**`postgres`** levanta el motor de base de datos para desarrollo local, usando la imagen oficial `postgres:18-alpine`. Tiene tres detalles importantes:

- **Volumen nombrado `pgdata`**, así los datos sobreviven a `docker compose down`.
- **Montado en `/var/lib/postgresql`**, *no* en `/var/lib/postgresql/data`. Postgres 18 cambió el layout y guarda los datos en un subdirectorio con el número de major version; usar la ruta vieja hace que el contenedor entre en un loop de reinicios.
- **`healthcheck` con `pg_isready`**, para que el servicio `api` no arranque hasta que la base acepte conexiones. Sin esto las migraciones fallan de forma intermitente al levantar todo junto.

**`api`** construye y corre la aplicación a partir del `Dockerfile`, espera el healthcheck de `postgres` (`condition: service_healthy`) y al arrancar ejecuta `prisma migrate deploy && node dist/main.js`.

### `Dockerfile` — construye la imagen de la API

Es multi-stage, en tres etapas:

1. **`deps`** — instala dependencias. Copia `prisma/` y `prisma.config.ts` **antes** de `npm ci`, porque el `postinstall` corre `prisma generate` y necesita el schema. Usa un `DATABASE_URL` placeholder: `generate` lee la variable aunque no se conecte a la base.
2. **`builder`** — compila TypeScript a `dist/` y elimina las devDependencies.
3. **`runner`** — imagen final sobre `node:24-alpine`, corriendo como el usuario sin privilegios `node`.

> **Por qué `prisma` y `dotenv` son `dependencies` y no `devDependencies`:** el contenedor ejecuta `prisma migrate deploy` al arrancar, y el `npm prune --omit=dev` del build se las llevaría. Es la diferencia entre la imagen arrancando y quedándose en un loop de reinicios.

> El schema usa `engineType = "client"`, que no descarga el motor nativo de Rust. Por eso Alpine funciona sin tener que instalar `libssl`.

### Comandos útiles

```bash
docker compose up -d postgres        # solo la base
docker compose up --build            # todo, reconstruyendo la imagen
docker compose ps                    # estado y healthchecks
docker compose logs -f api           # logs de la API
docker compose down                  # parar (los datos se conservan)
docker compose down -v               # parar y BORRAR los datos

# Abrir una consola psql dentro del contenedor
docker compose exec postgres psql -U postgres -d si_be_boilerplate
```

**Resetear la base desde cero:**

```bash
docker compose down -v && docker compose up -d postgres
npm run prisma:migrate && npm run db:seed
```

---

## Prisma en detalle

El schema vive en [prisma/schema.prisma](prisma/schema.prisma) y define dos modelos: `User` y `RefreshToken`.

La configuración del CLI está en [prisma.config.ts](prisma.config.ts) (rutas del schema y las migraciones, comando de seed, y de dónde sale `DATABASE_URL`).

### El cliente generado no se commitea

El generador `prisma-client` escribe en `src/generated/prisma`, que está en `.gitignore`. Se regenera solo en cada `npm install` gracias al script `postinstall`. Si tocás el schema:

```bash
npm run prisma:generate
```

> El `output` tiene que caer dentro de `src/` porque `tsconfig.build.json` compila únicamente ese directorio.

### Flujo de trabajo con migraciones

```bash
# Crear y aplicar una migración nueva (desarrollo)
npm run prisma:migrate -- --name agrega_campo_x

# Aplicar migraciones pendientes sin generar ninguna (producción / CI)
npm run prisma:deploy

# Explorar los datos en una UI web
npm run prisma:studio

# Borrar la base, re-aplicar todas las migraciones y correr el seed
npm run db:reset
```

### Seed

[prisma/seed.ts](prisma/seed.ts) crea un usuario de prueba mediante `upsert`, así que se puede correr las veces que haga falta:

| Email | Contraseña |
|---|---|
| `demo@example.com` | `Demo1234!` |

---

## Autenticación

Esquema **access token + refresh token**, solo con email y contraseña.

- **Access token** — JWT firmado con HS256, vida corta (15 min). Viaja en `Authorization: Bearer <token>`. Es stateless: no se consulta la base para validar la firma.
- **Refresh token** — string opaco de 32 bytes aleatorios, con vida larga (7 días). Sirve únicamente para pedir un access token nuevo.

### Decisiones de seguridad

**Las contraseñas se hashean con bcrypt** (cost 12, configurable). Nunca se guardan ni se devuelven en claro: los controladores responden un DTO explícito ([user-response.dto.ts](src/users/dto/user-response.dto.ts)) en vez de la fila de Prisma, para que `passwordHash` no pueda filtrarse por descuido.

**Los refresh tokens se guardan hasheados con SHA-256**, no con bcrypt. Es deliberado: son 32 bytes aleatorios, o sea alta entropía, así que no hay un espacio de búsqueda que justifique un KDF lento; además hace falta buscarlos por hash en un índice (bcrypt usa un salt distinto por hash, así que no se puede indexar). bcrypt queda para las contraseñas, que sí son de baja entropía. Si se filtra la base, los refresh tokens emitidos no son utilizables.

**El email se normaliza a minúsculas y sin espacios.** El índice único de Postgres es sensible a mayúsculas, así que sin normalizar `Demo@mail.com` y `demo@mail.com` serían dos cuentas distintas y el login fallaría según cómo el usuario escribiera su email. Se normaliza en dos lugares a propósito: el decorador [`@IsNormalizedEmail()`](src/common/decorators/is-normalized-email.decorator.ts) cubre lo que entra por HTTP —y tiene que correr **antes** de `@IsEmail`, o un email con espacios se rechaza con un 400 antes de poder limpiarlo—, y `UserRepository` normaliza de nuevo al leer y escribir, para cubrir a cualquier llamador interno que no pase por un DTO.

**Rotación con detección de reúso.** Cada `POST /auth/refresh` revoca el token usado y emite uno nuevo. Si llega un refresh token que ya fue canjeado, se asume robo y se revocan **todas** las sesiones del usuario.

**Login que no filtra información.** Email no registrado, contraseña incorrecta y cuenta inactiva devuelven exactamente el mismo `401` con el mismo mensaje. Cuando el email no existe igual se ejecuta un `bcrypt.compare` contra un hash descartable, para que la diferencia de tiempo de respuesta no permita enumerar qué emails tienen cuenta.

**Todo cerrado por defecto.** `JwtAuthGuard` está registrado como guard global; las rutas públicas se abren explícitamente con `@Public()`. Olvidarse del decorador deja el endpoint protegido, que es el error seguro.

**El usuario se relee en cada request**, así una cuenta desactivada o borrada deja de funcionar al instante, sin esperar a que expire el token.

### Autorización por roles 

La API utiliza dos guards globales registrados en `AppModule`:

1. `JwtAuthGuard`: valida el JWT y carga el usuario autenticado en `request.user`.
2. `RolesGuard`: comprueba que el rol del usuario esté autorizado para acceder a la ruta.

El decorador `@Roles()` se encuentra en `src/auth/decorators/roles.decorator.ts` y utiliza el enum `Rol` generado por Prisma.

#### Uso en controladores

```typescript
import { Controller, Post } from '@nestjs/common';
import { Roles } from '@Auth/decorators';
import { Rol } from '@PrismaClient';

@Controller('bienes')
export class BienesController {
  @Post()
  @Roles(Rol.ARRENDADOR)
  crearBien() {
    // Implementación correspondiente a BE-1.1
  }
}
```

Este ejemplo es ilustrativo. La autorización por roles no modifica ni implementa el endpoint de bienes.

#### Reglas de autorización

- `@Public()`: permite acceder sin token y omite la validación de roles.
- Sin `@Roles()`: exige autenticación, pero permite cualquier rol válido.
- `@Roles(Rol.ARRENDADOR)`: permite únicamente arrendadores.
- `@Roles(Rol.ARRENDATARIO)`: permite únicamente arrendatarios.
- `@Roles(Rol.ARRENDADOR, Rol.ARRENDATARIO)`: permite cualquiera de los dos roles.
- `@Roles()` sin argumentos: no permite ningún rol.

#### Roles a nivel de clase

```typescript
import { Controller, Get, Post } from '@nestjs/common';
import { Roles } from '@Auth/decorators';
import { Rol } from '@PrismaClient';

@Roles(Rol.ARRENDADOR)
@Controller('ejemplo')
export class EjemploController {
  @Get()
  consultar() {
    // Solo ARRENDADOR.
  }

  @Post()
  @Roles(Rol.ARRENDATARIO)
  accion() {
    // Solo ARRENDATARIO.
    // Sobrescribe el rol definido en la clase.
  }
}
```

El guard obtiene los metadatos mediante `Reflector.getAllAndOverride`, dando prioridad al método y después a la clase.

#### Respuestas HTTP

**401 Unauthorized:** no se proporcionó un token válido en una ruta protegida. Lo gestiona `JwtAuthGuard`.

**403 Forbidden:** el usuario está autenticado, pero su rol no está autorizado. Lo gestiona `RolesGuard`.

```json
{
  "message": "No tienes permiso para realizar esta acción.",
  "error": "Forbidden",
  "statusCode": 403
}
```

#### Pruebas

```bash
npx vitest run src/auth/guards/roles.guard.spec.ts
npm test
```

Los guards se comparten entre los módulos de la aplicación. No es necesario implementar guards de roles específicos para cada módulo.


### Buenas prácticas REST aplicadas

- **Versionado en la URI:** todo cuelga de `/api/v1`.
- **Sustantivos en plural para los recursos:** crear un usuario es `POST /users`, no `POST /createUser`.
- **Códigos de estado correctos:** `201` al crear, `200` en login, `204` en logout (sin cuerpo), `400` de validación, `401` de autenticación, `409` de conflicto.
- **Validación estricta de la entrada:** `whitelist` descarta propiedades no declaradas y `forbidNonWhitelisted` rechaza la request si vienen de más, en vez de ignorarlas en silencio.
- **Errores con forma consistente:** `{ message, error, statusCode }`.

---

## Endpoints

Base: `http://localhost:3000/api/v1` · Documentación interactiva: `http://localhost:3000/api/docs`

| Método | Ruta | Auth | Código | Descripción |
|---|---|---|---|---|
| `GET` | `/` | — | `200` | Health check |
| `POST` | `/users` | — | `201` | Registra un usuario con email y contraseña |
| `POST` | `/auth/login` | — | `200` | Inicia sesión con email y contraseña |
| `POST` | `/auth/refresh` | — | `200` | Renueva el par de tokens |
| `POST` | `/auth/logout` | — | `204` | Cierra la sesión |
| `GET` | `/auth/me` | Bearer | `200` | Usuario autenticado |
| `GET` | `/bienes` | — | `200` | Busca bienes por texto, ubicación, precio, tipo, categoría, capacidad y disponibilidad, paginado |
| `POST` | `/bienes` | Bearer, rol `ARRENDADOR` | `201` | Publica un bien con sus fotos (multipart) |
| `GET` | `/bienes/mios` | Bearer, rol `ARRENDADOR` | `200` | Lista los bienes del arrendador, también los `INACTIVA`, paginado de a 20 |
| `GET` | `/bienes/:bienId` | — | `200` | Detalle público de un bien activo, con su arrendador y sus fotos |
| `GET` | `/bienes/:bienId/resenas` | — | `200` | Reseñas de tipo bien, paginadas de 10 en 10, de la más reciente a la más antigua |
| `GET` | `/bienes/:bienId/disponibilidad` | Bearer | `200` | Rangos reservados y bloqueados de un bien |
| `GET` | `/bienes/:bienId/bloqueos` | Bearer, rol `ARRENDADOR` dueño | `200` | Lista los bloqueos vigentes o futuros del bien, con su `id` |
| `POST` | `/bienes/:bienId/bloqueos` | Bearer, rol `ARRENDADOR` dueño | `201` | Bloquea un rango de fechas del bien |
| `DELETE` | `/bienes/:bienId/bloqueos/:id` | Bearer, rol `ARRENDADOR` dueño | `204` | Elimina un bloqueo y libera sus fechas |
| `POST` | `/bienes/:bienId/conversacion` | Bearer, rol `ARRENDATARIO` | `201` / `200` | Abre la conversación con el arrendador, o recupera la que ya existía |
| `POST` | `/conversaciones/:id/mensajes` | Bearer, participante | `201` | Envía un mensaje; el remitente es el usuario del token |
| `GET` | `/conversaciones/:id/mensajes` | Bearer, participante | `200` | Historial de la conversación (`?orden=asc` por defecto, o `desc`) |
| `GET` | `/reservas/:reservaId/conversacion` | Bearer, participante de la reserva | `200` | Recupera o crea la conversación de coordinación de la entrega |
| `POST` | `/reservas/:reservaId/conversacion/mensajes` | Bearer, participante de la reserva | `201` | Envía un mensaje sobre la entrega; el remitente es el usuario del token |
| `GET` | `/reservas/:reservaId/conversacion/mensajes` | Bearer, participante de la reserva | `200` | Historial de la coordinación (`?orden=asc` por defecto, o `desc`) |
| `POST` | `/verificaciones` | Bearer, rol `ARRENDADOR` o `ARRENDATARIO` | `201` | Envía el documento de identidad (multipart) y crea la solicitud `EN_REVISION` |
| `GET` | `/verificaciones/mi-estado` | Bearer, rol `ARRENDADOR` o `ARRENDATARIO` | `200` | Estado de verificación del usuario autenticado, con el motivo si fue rechazado |
| `GET` | `/bienes/:bienId/politica-verificacion` | Bearer | `200` | Indica si el bien solo acepta usuarios verificados (`false` sin registro) |
| `PUT` | `/bienes/:bienId/politica-verificacion` | Bearer, rol `ARRENDADOR` dueño | `200` | Activa o desactiva "Solo usuarios verificados"; activarla exige estar `VERIFICADO` |
| `GET` | `/reservas/mias` | Bearer, rol `ARRENDATARIO` | `200` | Lista las reservas propias, con filtro opcional por estado |
| `GET` | `/reservas/recibidas` | Bearer, rol `ARRENDADOR` | `200` | Reservas recibidas en los bienes propios, paginadas de a 20 y con filtro opcional por estado |
| `GET` | `/reservas/:id` | Bearer, rol `ARRENDATARIO` o `ARRENDADOR`, participante de la reserva | `200` | Consulta una reserva por UUID: su arrendatario o el arrendador dueño del bien |
| `POST` | `/reservas` | Bearer (`ARRENDATARIO`) | `202` | Solicita la reserva de un bien; queda `EN_COLA` |
| `GET` | `/reportes/periodo` | Bearer, rol `ARRENDADOR` | `200` | Resuelve el periodo de un reporte a un rango de fechas |
| `GET` | `/reportes/ingresos` | Bearer, rol `ARRENDADOR` | `200` | Ingresos y depósito retenido de cada bien del arrendador en un periodo |
| `GET` | `/reportes/calificaciones` | Bearer, rol `ARRENDADOR` | `200` | Calificación promedio y número de reseñas de cada bien |
| `GET` | `/reportes/ocupacion` | Bearer, rol `ARRENDADOR` | `200` | Días disponibles, días ocupados y tasa de ocupación de cada bien |
| `GET` | `/reportes/resumen` | Bearer, rol `ARRENDADOR` | `200` | Ingresos, tasa de ocupación y calificación de cada bien en una sola tabla |
| `GET` | `/reportes/resumen/exportar` | Bearer, rol `ARRENDADOR` | `200` | El mismo resumen como archivo CSV |
| `POST` | `/reservas/:reservaId/devolucion` | Bearer, rol `ARRENDADOR` | `201` | Registra la devolución del bien y finaliza la reserva |
| `POST` | `/reservas/:reservaId/resenas` | Bearer, rol `ARRENDATARIO` | `201` | Califica el bien y al arrendador de una reserva finalizada |
| `GET` | `/reservas/:reservaId/resumen-pago` | Bearer, rol `ARRENDATARIO` | `200` | Alquiler, depósito y total de una reserva pagable |
| `POST` | `/reservas/:reservaId/pagos` | Bearer, rol `ARRENDATARIO` | `201` | Simula el pago de una reserva y guarda el resultado |
| `GET` | `/pagos/:pagoId/comprobante` | Bearer, rol `ARRENDATARIO` | `200` | Comprobante de un pago exitoso propio |
| `GET` | `/reservas/:reservaId/deposito` | Bearer, `ARRENDATARIO` de la reserva o `ARRENDADOR` del bien | `200` | Consulta el estado y el detalle del depósito |
| `POST` | `/reservas/:reservaId/deposito/resolucion` | Bearer, rol `ARRENDADOR` | `200` | Libera el depósito o retiene una parte o su totalidad |

### Ejemplos

```bash
BASE=http://localhost:3000/api/v1
```

**Registro**

```bash
curl -X POST $BASE/users \
  -H 'Content-Type: application/json' \
  -d '{"email":"nestor@example.com","password":"Str0ngPass"}'
```

```jsonc
// 201 Created
{
  "id": "29bda5e8-e0c8-4ec2-bc7f-94c41c3c0140",
  "email": "nestor@example.com",
  "isActive": true,
  "createdAt": "2026-09-20T17:29:59.852Z"
}
```

La contraseña debe tener entre 8 y 72 caracteres, con al menos una minúscula, una mayúscula y un número. Si el email ya está registrado, la respuesta es `409 Conflict`.

**Login**

```bash
curl -X POST $BASE/auth/login \
  -H 'Content-Type: application/json' \
  -d '{"email":"demo@example.com","password":"Demo1234!"}'
```

```jsonc
// 200 OK
{
  "accessToken": "eyJhbGciOiJIUzI1NiIs...",
  "refreshToken": "dbfcf084b4a238cf9afaaa2f800ee216...",
  "expiresIn": 900,
  "user": { "id": "...", "email": "demo@example.com", "isActive": true, "createdAt": "..." }
}
```

**Ruta protegida**

```bash
curl $BASE/auth/me -H "Authorization: Bearer $ACCESS_TOKEN"
```

**Disponibilidad de un bien**

```bash
curl "$BASE/bienes/$BIEN_ID/disponibilidad?desde=2026-11-01&hasta=2027-10-31" \
  -H "Authorization: Bearer $ACCESS_TOKEN"
```

```jsonc
// 200 OK
{
  "bienId": "7c9e6679-7425-40de-944b-e07fc1f90ae7",
  "reservados": [{ "fechaInicio": "2026-12-10", "fechaFin": "2026-12-12" }],
  "bloqueados": [{ "fechaInicio": "2026-12-20", "fechaFin": "2026-12-25" }]
}
```

- `desde` y `hasta` van en formato `YYYY-MM-DD` y ambos días están incluidos. Si se omiten, `desde` es hoy (día de El Salvador) y `hasta` cierra la ventana de 12 meses.
- Cuentan como reservados los estados que ocupan días: `CONFIRMADA`, `EN_CURSO` y `FINALIZADA`, los mismos que la base impide solapar. `EN_COLA`, `RECHAZADA` y `CANCELADA` no aparecen.
- Se devuelve todo rango que se cruce con la ventana, aunque empiece antes de `desde` o termine después de `hasta`.
- La respuesta solo trae fechas: nunca datos del arrendatario ni de la solicitud.
- Errores: `400` (fecha inválida, `desde` posterior a `hasta` o ventana mayor a 12 meses), `401` sin sesión y `404` si el bien no existe o está inactivo.

**Bloquear fechas de un bien**

```bash
curl -X POST $BASE/bienes/$BIEN_ID/bloqueos \
  -H "Authorization: Bearer $ACCESS_TOKEN" \
  -H 'Content-Type: application/json' \
  -d '{"fechaInicio":"2026-12-20","fechaFin":"2026-12-25"}'
```

```jsonc
// 201 Created
{
  "id": "9b2d4c6e-1a3f-4b5c-8d7e-6f5a4b3c2d1e",
  "bienId": "7c9e6679-7425-40de-944b-e07fc1f90ae7",
  "fechaInicio": "2026-12-20",
  "fechaFin": "2026-12-25"
}

// 409 Conflict: el rango incluye una reserva confirmada
{
  "message": "El rango incluye una reserva confirmada o en curso.",
  "error": "Conflict",
  "statusCode": 409,
  "reservaId": "3f1e2d3c-4b5a-4968-8776-655443322110"
}
```

```bash
# Eliminar el bloqueo: 204 No Content, y sus fechas vuelven a estar disponibles
curl -X DELETE $BASE/bienes/$BIEN_ID/bloqueos/$BLOQUEO_ID \
  -H "Authorization: Bearer $ACCESS_TOKEN"
```

**Listar los bloqueos de un bien (BE-7.3)**

`GET /api/v1/bienes/:bienId/bloqueos` devuelve los bloqueos del bien con el `id` que necesita el `DELETE`, porque `GET /bienes/:bienId/disponibilidad` solo trae los rangos, sin id. La pantalla de gestión de bloqueos (FE-7.1) lo usa para poder eliminarlos.

```bash
curl $BASE/bienes/$BIEN_ID/bloqueos -H "Authorization: Bearer $ACCESS_TOKEN"
```

```jsonc
// 200 OK
[
  {
    "id": "9b2d4c6e-1a3f-4b5c-8d7e-6f5a4b3c2d1e",
    "fechaInicio": "2026-12-20",
    "fechaFin": "2026-12-25",
    "creadoEn": "2026-11-13T15:04:05.000Z"
  }
]
```

- Solo incluye los bloqueos **vigentes o futuros**: los que terminan hoy o después (`fechaFin ≥ hoy`, con "hoy" en `America/El_Salvador`). Uno que termina hoy sigue apareciendo; uno que terminó ayer, no.
- Van ordenados por `fechaInicio` ascendente. Un bien sin bloqueos devuelve `[]`.
- Es una lectura: no toma el candado del bien.
- Errores: `400` id que no es UUID, `401` sin sesión, `403` sin rol `ARRENDADOR` o bien de otro arrendador, y `404` si el bien no existe. Las pruebas e2e están en [test/bloqueos-listar.e2e-spec.ts](test/bloqueos-listar.e2e-spec.ts).

- Solo el arrendador dueño del bien puede crear o eliminar sus bloqueos. Los rangos son de días completos e inclusivos, igual que en la disponibilidad, y un bloqueo creado aparece de inmediato en `bloqueados`.
- No se puede bloquear un rango que incluya una reserva `CONFIRMADA` o `EN_CURSO` (409 con `reservaId`) ni uno que se solape con otro bloqueo (409 con `bloqueoId`). Las reservas `EN_COLA` no impiden bloquear: el procesador las rechaza después por falta de fechas.
- La revisión de conflictos y el insert o delete corren en una transacción con `pg_advisory_xact_lock(hashtext(bienId))`, el mismo candado que toma el procesador de la cola antes de confirmar una solicitud. Así un bloqueo y una confirmación del mismo bien nunca se cruzan: el que llega segundo espera y ve lo que escribió el primero. Cualquier código que serialice por bien debe usar esa misma expresión (`tomarCandadoDelBien`, en `@Bloqueos/repositories`).
- Errores: `400` formato inválido (fecha que no es `YYYY-MM-DD` o no existe, id que no es UUID), `401` sin sesión, `403` sin rol `ARRENDADOR` o bien de otro arrendador, `404` bien o bloqueo inexistente, `409` conflicto y `422` inicio anterior a hoy (día de El Salvador) o fin anterior al inicio.

#### Pruebas de integración de bloqueos (BE-7.2)

Están en [test/bloqueos.e2e-spec.ts](test/bloqueos.e2e-spec.ts) y usan Vitest y Supertest contra el Postgres de `docker-compose` (`DATABASE_URL`):

```bash
docker compose up -d postgres
npm run prisma:deploy
npx vitest run --config ./vitest.config.e2e.ts test/bloqueos.e2e-spec.ts   # solo esta suite
npm run test:e2e                                                            # todas
```

La suite crea sus propios usuarios (dos arrendadores y un arrendatario) y dos bienes. Antes de cada caso borra las reservas y los bloqueos de esos bienes, así que cada caso parte de la base limpia y no depende del orden. No toca el resto de la base. Al terminar borra todo lo que creó, incluidos los avisos que genera solicitar una reserva.

| Código | Casos |
|---|---|
| `201` | Crear un bloqueo (también de un solo día), que aparece en `bloqueados` de la disponibilidad; un rango contiguo a otro bloqueo; un rango con reservas `EN_COLA`, `RECHAZADA` o `CANCELADA` |
| `204` | Eliminar un bloqueo: desaparece de la disponibilidad y sus fechas se pueden volver a bloquear |
| `400` | Fecha que no es `YYYY-MM-DD` o no existe, id de bien o de bloqueo que no es UUID |
| `401` | Crear o eliminar sin sesión |
| `403` | Bien de otro arrendador (al crear y al eliminar; no se crea ni se borra nada) y token de un `ARRENDATARIO` |
| `404` | Bien inexistente (al crear y al eliminar), bloqueo inexistente o bloqueo de otro bien (no se borra) |
| `409` | Rango con una reserva `CONFIRMADA` o `EN_CURSO` (trae su `reservaId`), rango solapado con otro bloqueo (trae su `bloqueoId`), bloqueos solapados enviados a la vez (solo se crea uno) y bloqueo que espera el candado del procesador mientras confirma una reserva |
| `422` | Inicio anterior a hoy o fin anterior al inicio, con su mensaje |

**Solicitud en cola que choca con un bloqueo nuevo.** El arrendatario solicita una reserva por `POST /reservas` (`202`, `EN_COLA`), el dueño bloquea esas fechas (`201`) y se procesa la cola. Al consultarla, `GET /reservas/:id` responde `RECHAZADA` con `motivoResolucion: "FECHAS_NO_DISPONIBLES"` (fechas no disponibles) y con `procesadaEn`. Como control, si el bloqueo se elimina antes de procesarla, la solicitud queda `CONFIRMADA`.

- La suite procesa la cola a mano con `ProcesadorColaService.procesarSiguiente`. Para eso fija `COLA_RESERVAS_ACTIVA=false` antes de crear la app, aunque el `.env` lo tenga en `true`; si no, el procesador de fondo resolvería la solicitud antes de que exista el bloqueo.
- Igual que en las pruebas de la cola, la solicitud se mueve a `creadaEn` del año 2000 para que sea la primera de la tabla, y el procesador recibe un "ahora" de ese año para que no venza el plazo de 5 minutos.
- Las solicitudes van a unos 60 días de hoy porque `POST /reservas` no acepta fechas a más de 12 meses. Los demás bloqueos usan fechas de 2031.

**Mis reservas**

```bash
curl "$BASE/reservas/mias?estado=EN_COLA" \
  -H "Authorization: Bearer $ACCESS_TOKEN"
```

```jsonc
// 200 OK
[
  {
    "id": "3f2504e0-4f89-41d3-9a0c-0305e82c3301",
    "bienId": "7c9e6679-7425-40de-944b-e07fc1f90ae7",
    "arrendatarioId": "9c2a7e4d-93b2-4fa1-8e72-66bd44b0c159",
    "fechaInicio": "2026-12-10",
    "fechaFin": "2026-12-12",
    "estado": "EN_COLA",
    "motivoResolucion": null,
    "creadaEn": "2026-11-14T12:00:00.000Z",
    "procesadaEn": null
  }
]
```

- `estado` es opcional. Admite `EN_COLA`, `CONFIRMADA`, `RECHAZADA`, `EN_CURSO`, `FINALIZADA` y `CANCELADA`.
- Solo devuelve reservas del arrendatario autenticado, ordenadas de la más reciente a la más antigua.
- Sin coincidencias devuelve `200` con `[]`.
- Errores: `400` (estado inválido), `401` sin sesión y `403` si el rol no es `ARRENDATARIO`.

**Consultar una reserva**

```bash
curl "$BASE/reservas/$RESERVA_ID" \
  -H "Authorization: Bearer $ACCESS_TOKEN"
```

```jsonc
// 200 OK
{
  "id": "3f2504e0-4f89-41d3-9a0c-0305e82c3301",
  "bienId": "7c9e6679-7425-40de-944b-e07fc1f90ae7",
  "arrendatarioId": "9c2a7e4d-93b2-4fa1-8e72-66bd44b0c159",
  "fechaInicio": "2026-12-10",
  "fechaFin": "2026-12-12",
  "estado": "RECHAZADA",
  "motivoResolucion": "FECHAS_NO_DISPONIBLES",
  "creadaEn": "2026-11-14T12:00:00.000Z",
  "procesadaEn": "2026-11-14T12:00:05.000Z"
}
```

- `RESERVA_ID` debe ser un UUID válido.
- Pueden consultar su detalle sus dos participantes: el arrendatario que la solicitó y el arrendador dueño del bien reservado (BE-27.2). La pertenencia se comprueba en la misma consulta a la base.
- Errores: `400` (UUID inválido), `401` sin sesión y `404` (reserva inexistente o ajena). Una reserva ajena responde igual que una inexistente, con el mismo mensaje, para no revelar que existe.

#### Respuestas enriquecidas de reservas

Los endpoints `GET /api/v1/reservas/mias` y `GET /api/v1/reservas/{id}`
incluyen información adicional para mostrar las reservas en el frontend
sin realizar consultas individuales por cada bien.

Además de los campos existentes, cada reserva incorpora:

| Campo | Descripción |
|---|---|
| `bien` | ID, título, fotografía principal, precio y unidad de cobro. |
| `arrendatario` | ID y nombre de usuario del arrendatario. |
| `arrendador` | ID y nombre de usuario del propietario del bien. |
| `pago` | ID, estado y total del pago exitoso o del último intento. |
| `deposito` | Estado e importe original del depósito, cuando existe. |
| `finalizadaEn` | Fecha y hora de finalización de la reserva. |

**Reglas de respuesta:**

- Se prioriza el pago `SIMULADO_EXITOSO`. Si no existe, se devuelve el intento más reciente.
- `pago`, `deposito` y `finalizadaEn` son `null` cuando no existen.
- `bien.fotoPrincipalUrl` es `null` si el bien no tiene fotografía principal.
- Los importes decimales se representan como cadenas para preservar su precisión.
- Se conservan todos los campos originales de `ReservaResponseDto` para mantener la compatibilidad.

**Implementación:** las relaciones se cargan mediante Prisma utilizando
`select` y consultas relacionadas, evitando consultas individuales por
cada reserva (N+1).

**Documentación:** los campos adicionales están definidos en
`ReservaResponseDto` y disponibles en Swagger.

**Solicitar una reserva**

```bash
curl -X POST $BASE/reservas \
  -H "Authorization: Bearer $ACCESS_TOKEN" \
  -H 'Content-Type: application/json' \
  -d '{"bienId":"7c9e6679-7425-40de-944b-e07fc1f90ae7","fechaInicio":"2026-12-10","fechaFin":"2026-12-12"}'
```

```jsonc
// 202 Accepted
{
  "id": "3f2504e0-4f89-41d3-9a0c-0305e82c3301",
  "bienId": "7c9e6679-7425-40de-944b-e07fc1f90ae7",
  "arrendatarioId": "9c2a7e4d-93b2-4fa1-8e72-66bd44b0c159",
  "fechaInicio": "2026-12-10",
  "fechaFin": "2026-12-12",
  "estado": "EN_COLA",
  "motivoResolucion": null,
  "creadaEn": "2026-11-14T18:00:00.000Z",
  "procesadaEn": null
}
```

`arrendatarioId` corresponde al usuario autenticado que solicita la reserva. Se obtiene del token de acceso y no se recibe en el cuerpo de la petición. motivoResolucion y procesadaEn son inicialmente null, porque la solicitud todavía está pendiente de procesamiento.

Responde `202` y no `201` porque la solicitud queda en cola: todavía no es una reserva y **no retiene fechas**. El procesador de la cola la confirmará o rechazará después (ver [Procesador de la cola](#procesador-de-la-cola-de-reservas)). Solo el rol `ARRENDATARIO` puede usarlo. Las fechas son días completos y ambos extremos cuentan.

Los errores, en el orden en que se evalúan:

| Código | Cuándo |
|---|---|
| `401` | Sin sesión |
| `403` | El rol no es `ARRENDATARIO` |
| `400` | Formato de fecha inválido, día inexistente o `bienId` que no es UUID |
| `422` | Inicio anterior a hoy (día de El Salvador), inicio a más de 12 meses de hoy (el mismo horizonte que el calendario de disponibilidad), fin anterior a inicio, o más de 30 días. Los 30 días son inclusivos: del 10 al 39 es válido y del 10 al 40 no. Cada caso trae un mensaje con el motivo |
| `404` | El bien no existe o está inactivo |
| `422` | El bien es del propio usuario |
| `403` | El bien solo se renta a usuarios verificados y el usuario no lo está. El cuerpo es `{ "codigo": "VERIFICACION_REQUERIDA", "mensaje": "Este bien solo se renta a usuarios verificados." }` |
| `409` | Las fechas se solapan con una reserva `CONFIRMADA`, `EN_CURSO` o `FINALIZADA` (los mismos estados que muestra la disponibilidad), con un bloqueo, o con una solicitud `EN_COLA` propia del mismo bien |

- Un usuario está verificado si su solicitud de verificación más reciente está `APROBADA`. Un bien sin política se trata como si no exigiera verificación.
- Las solicitudes `EN_COLA` de **otros** usuarios no bloquean: pueden solicitar las mismas fechas. La validación de solape al encolar es una comprobación temprana, no una garantía; la decisión final es del procesador.
- Al encolar se emite el evento interno `solicitud.encolada` (`SolicitudEncoladaEvent`, con los ids y las fechas), que despierta al procesador de la cola.

#### Reservas recibidas por el arrendador (BE-27.1)

`GET /api/v1/reservas/recibidas` lista las reservas de los bienes del arrendador autenticado. Solo para `ARRENDADOR`: el arrendador sale del token, nunca de la petición.

```bash
curl "$BASE/reservas/recibidas?estado=CONFIRMADA&pagina=1"   -H "Authorization: Bearer $ACCESS_TOKEN"
```

```jsonc
// 200 OK
{
  "items": [
    {
      "id": "3f2504e0-4f89-41d3-9a0c-0305e82c3301",
      "bienId": "7c9e6679-7425-40de-944b-e07fc1f90ae7",
      "arrendatarioId": "9c2a7e4d-93b2-4fa1-8e72-66bd44b0c159",
      "fechaInicio": "2026-12-10",
      "fechaFin": "2026-12-12",
      "estado": "CONFIRMADA",
      "motivoResolucion": null,
      "creadaEn": "2026-11-14T12:00:00.000Z",
      "procesadaEn": "2026-11-14T12:00:05.000Z"
    }
  ],
  "pagina": 1,
  "total": 1,
  "hayMas": false
}
```

- Cada elemento de `items` usa el mismo formato que `GET /reservas/mias` y `GET /reservas/{id}` (`ReservaResponseDto`).
- `estado` es opcional: `EN_COLA`, `CONFIRMADA`, `RECHAZADA`, `EN_CURSO` o `FINALIZADA`. `estado=` vacío equivale a no filtrar. `CANCELADA` no es un filtro válido, pero sin filtro las reservas canceladas sí aparecen.
- `pagina` es opcional (por defecto `1`) y debe ser un entero de 1 a `Number.MAX_SAFE_INTEGER` (9007199254740991). Ese máximo es técnico, no de negocio: un número mayor ya no se representa exacto y responde `400` en lugar de devolver otra página. Se escribe solo con dígitos decimales y sin ceros a la izquierda: `1e2`, `0x10`, ` 2`, `1.0`, `+1` o `01` responden `400` (a diferencia de `GET /bienes`, que convierte cualquier escritura de un número). Cada página tiene 20 reservas.
- Orden: `fechaInicio` ascendente; ante empate, `creadaEn` descendente y, por último, `id`, para que la paginación sea estable.
- `total` cuenta las reservas que cumplen el filtro y `hayMas` indica si quedan más después de esta página. Sin reservas responde `200` con `items: []` y `total: 0`. Una página posterior a la última (dentro del rango admitido) responde `200` con `items: []`, la página pedida, el `total` real y `hayMas: false`.
- Errores: `400` (estado no permitido, página inválida o parámetro desconocido), `401` sin sesión y `403` si el rol no es `ARRENDADOR`. Un parámetro desconocido normal, como `arrendadorId`, responde `400`; los nombres de propiedades de `Object.prototype`, como `__proto__` o `constructor`, los descarta el parser de la query de Express antes de la validación, así que se ignoran (la respuesta es la misma que sin ellos).

#### Procesador de la cola de reservas

Resuelve cada solicitud `EN_COLA` como `CONFIRMADA` o `RECHAZADA`, de la más antigua a la más nueva (`creadaEn`). No tiene endpoint: corre dentro de la aplicación ([ColaReservasWorker](src/reservas/workers/cola-reservas.worker.ts)) y se despierta al arrancar, cuando se encola una solicitud y cada `COLA_RESERVAS_INTERVALO_MS`. Así, las solicitudes que quedaron pendientes tras un reinicio se procesan al volver.

Cada solicitud se resuelve en una transacción. Las reglas, en orden:

| Resultado | `motivoResolucion` | Cuándo |
|---|---|---|
| `RECHAZADA` | `ERROR_DE_PROCESAMIENTO` | Lleva más de 5 minutos `EN_COLA` |
| `RECHAZADA` | `VERIFICACION_REQUERIDA` | El bien exige verificación y el usuario ya no la tiene (se revalida con `puedeReservar`) |
| `RECHAZADA` | `FECHAS_NO_DISPONIBLES` | Se solapa con una reserva `CONFIRMADA`, `EN_CURSO` o `FINALIZADA`, o con un bloqueo; también si la base rechaza la confirmación con `reserva_sin_solape` (SQLSTATE `23P01`) |
| `CONFIRMADA` | — | Ninguna de las anteriores |

En todos los casos se guarda `procesadaEn`.

- **Sin duplicados con varias instancias.** La solicitud se toma con `FOR UPDATE SKIP LOCKED` y se serializa por bien con `pg_advisory_xact_lock`. Si otra instancia tiene una solicitud más antigua del mismo bien con días en común, la solicitud se aplaza para respetar el orden de llegada.
- **El plazo de 5 minutos se aplica al procesar.** Si el servicio estuvo caído más de 5 minutos, las solicitudes que esperaban pasan a `RECHAZADA` con `ERROR_DE_PROCESAMIENTO` en vez de confirmarse.
- **Un error no se pierde.** Si el procesamiento falla, la solicitud sigue `EN_COLA` y se reintenta en la siguiente revisión; si ya pasó de 5 minutos, se rechaza.
- **Todavía no notifica.** Quien consulte el resultado debe leer el estado de la reserva; no hay notificación al arrendatario en esta entrega.

#### Pruebas de integración del procesador de reservas (BE-6.4)

Las pruebas de BE-6.4 verifican las validaciones del encolado, el orden FIFO y la ausencia de reservas confirmadas con fechas solapadas bajo concurrencia.

Se ejecutan contra PostgreSQL real utilizando Prisma y los servicios de NestJS.

**Archivos de prueba:**

- `test/reservas.e2e-spec.ts`: validaciones de la solicitud de reserva y códigos HTTP.
- `test/cola-reservas.e2e-spec.ts`: procesamiento FIFO, verificación, expiración y concurrencia.

**Escenarios cubiertos:**

1. Validaciones de BE-6.1: respuestas HTTP 400, 401, 403, 404, 409 y 422.
2. Tres solicitudes solapadas: se confirma la primera por fecha de creación y se rechazan las otras dos.
3. Solicitudes sin solape: todas se confirman.
4. Verificación revocada: la solicitud se rechaza con `VERIFICACION_REQUERIDA`.
5. Recuperación de cola pendiente: una solicitud persistida sin evento puede procesarse posteriormente.
6. Expiración: una solicitud que supera cinco minutos en cola se rechaza con `ERROR_DE_PROCESAMIENTO`.
7. Concurrencia: 20 solicitudes solapadas se procesan en paralelo y exactamente una queda `CONFIRMADA`.
8. Restricción PostgreSQL `reserva_sin_solape`: impide confirmaciones incompatibles.

**Ejecutar las pruebas:**

```bash
npm run test:e2e -- test/reservas.e2e-spec.ts test/cola-reservas.e2e-spec.ts
```

**Verificar repetibilidad:**

La suite debe completarse correctamente tres veces consecutivas.

```bash
for i in 1 2 3; do
  echo "Ejecución $i de 3"
  npm run test:e2e -- test/reservas.e2e-spec.ts test/cola-reservas.e2e-spec.ts || exit 1
done
```

**Criterios de aceptación:**

- Las validaciones y los escenarios del procesador pasan contra PostgreSQL.
- Las tres ejecuciones consecutivas finalizan sin errores.
- Nunca existen dos reservas `CONFIRMADA` con fechas solapadas para el mismo bien.
- Las solicitudes concurrentes terminan procesadas sin duplicados ni pérdidas.

**Consideraciones:**

- Las pruebas crean datos temporales y los eliminan al finalizar.
- Se requiere PostgreSQL con las migraciones aplicadas.
- El procesador automático de fondo está deshabilitado en el entorno de pruebas.
- Las pruebas no modifican las reglas de negocio del procesador.
- La recuperación tras reinicio se comprueba de forma lógica, sin reiniciar el proceso NestJS.

### Tarea diaria de reservas y depósitos

Se ejecuta diariamente a las **00:05** en `America/El_Salvador` mediante `@nestjs/schedule`. Un candado de sesión PostgreSQL (`pg_try_advisory_lock`) impide que dos instancias ejecuten el barrido a la vez. Se utiliza una conexión dedicada al candado, independiente de las transacciones Prisma.

Variables en `.env` (`.env.example` contiene valores de referencia):

- `PLAZO_DEVOLUCION_DIAS=3`: días completos tras el fin para cerrar automáticamente.
- `PLAZO_DEPOSITO_DIAS=3`: días completos tras la finalización manual para liberar el depósito.
- `TAREA_RESERVAS_ACTIVA=true`: desactivada por defecto con `NODE_ENV=test`.

Reglas: `CONFIRMADA` a `EN_CURSO` cuando inicia; `EN_CURSO` sin devolución a `FINALIZADA` cuando se vence el plazo (con `cierreAutomatico` y `finalizadaEn`); depósitos pendientes de reservas finalizadas automáticamente se liberan inmediatamente, y los de finalización manual se liberan cuando vence su plazo. El vencimiento se evalúa por fecha de calendario de El Salvador: se procesa cuando `fecha + plazo < hoy`.

Cada reserva se actualiza en una transacción propia; cada depósito se resuelve mediante `DepositoService.resolver()` (actor `SISTEMA`), que registra su notificación BE-22.2 fuera de la transacción. Los errores se registran y no impiden procesar los siguientes elementos. La siguiente ejecución recupera depósitos pendientes de cierres automáticos anteriores. El barrido es idempotente porque consulta únicamente estados pendientes y las actualizaciones verifican el estado actual.

#### Notificación al solicitar una reserva

Cuando un arrendatario solicita una reserva, el sistema registra
la solicitud y genera una notificación para el propietario del bien.

La notificación se procesa mediante el evento interno
`solicitud.encolada`, emitido después de guardar la reserva.

### Flujo

1. El arrendatario solicita una reserva.
2. `ReservasService.solicitar()` valida los datos.
3. `ReservaRepository.encolar()` persiste la reserva.
4. Se emite `solicitud.encolada` fuera de la transacción.
5. `NotificarSolicitudReservaListener` recibe el evento.
6. El repositorio consulta el bien y el arrendatario.
7. `NotificacionesService.crear()` registra el aviso.

### Datos de la notificación

- Destinatario: `Bien.arrendadorId`.
- Título: `Nueva solicitud de reserva`.
- Módulo de origen: `RESERVAS`.
- Estado inicial: `NO_LEIDA`.
- Tipo de referencia: `RESERVA_SOLICITADA`.
- Referencia: UUID de la reserva.
- Mensaje: `{usuario} solicitó {bien} del {fechaInicio} al {fechaFin}.`

Las fechas tienen formato `dd/mm/aaaa`.

El mensaje no supera 300 caracteres.

### Reglas de negocio

- El destinatario se obtiene de la base de datos.
- El cliente no puede seleccionar quién recibe la notificación.
- El aviso se genera después de guardar la reserva.
- Los errores de notificaciones se registran mediante Logger.
- Un error de notificaciones no revierte la reserva.
- La referencia evita generar avisos duplicados.
- No se requieren migraciones adicionales.

### Pruebas unitarias

```bash 
npx vitest run src/reservas/listeners/notificar-solicitud-reserva.listener.spec.ts
```

### Pruebas de integración

Requieren PostgreSQL con las migraciones aplicadas.

```bash
RUN_DB_INTEGRATION=1 NODE_OPTIONS="--env-file=.env" npx vitest run src/reservas/listeners/notificar-solicitud-reserva.integration.spec.ts
```

### Limitación de entrega

Los eventos internos no son una cola persistente.

Si falla la creación del aviso, la reserva permanece guardada y
el error queda registrado, pero no existe un reintento automático.

Para garantizar la entrega ante reinicios o fallos persistentes,
sería necesario implementar reintentos o un patrón transactional outbox.

**Registrar la devolución de un bien**

```bash
curl -X POST $BASE/reservas/$RESERVA_ID/devolucion \
  -H "Authorization: Bearer $ACCESS_TOKEN" \
  -H 'Content-Type: application/json' \
  -d '{"fechaDevolucion":"2026-12-12T15:30:00Z","estadoFinalBien":"BUEN_ESTADO","observaciones":"Sin novedades."}'
```

```jsonc
// 201 Created
{
  "devolucionId": "5d0c4a9e-2f6b-4b1c-9a37-1f8e6d7c0b42",
  "reservaId": "3f2504e0-4f89-41d3-9a0c-0305e82c3301",
  "fechaDevolucion": "2026-12-12T15:30:00.000Z",
  "estadoFinalBien": "BUEN_ESTADO",
  "registradoPor": "7c9e6679-7425-40de-944b-e07fc1f90ae7",
  "estadoReserva": "FINALIZADA"
}
```

Solo el arrendador dueño del bien puede registrarla. `registradoPor` sale del token y no se acepta en el cuerpo.

| Campo | Regla |
|---|---|
| `fechaDevolucion` | Obligatoria. ISO 8601: una fecha (`2026-12-12`, que cuenta como medianoche UTC) o fecha y hora con zona (`Z` o `±hh:mm`). No puede ser futura |
| `estadoFinalBien` | Obligatorio: `BUEN_ESTADO`, `DANADO` o `INCOMPLETO` |
| `observaciones` | Opcional, hasta 500 caracteres |

En una sola transacción se inserta la devolución, la reserva pasa a `FINALIZADA` con `finalizadaEn` en el momento del registro y, si la reserva tiene un depósito `PENDIENTE`, se le fija el plazo de resolución a 3 días desde `finalizadaEn` (`plazoResolucion`). Un depósito que no está `PENDIENTE`, o la ausencia de depósito, no impide registrar. La fila de la reserva se bloquea durante la operación, así que dos peticiones simultáneas no pueden registrar la devolución dos veces.

Los errores, en el orden en que se evalúan:

| Código | Cuándo |
|---|---|
| `401` | Sin sesión |
| `403` | El rol no es `ARRENDADOR` |
| `400` | `reservaId` que no es UUID, campo faltante, fecha inválida o sin zona, estado final desconocido, observaciones de más de 500 caracteres o un campo desconocido |
| `422` | La fecha de devolución es futura |
| `404` | La reserva no existe |
| `403` | El bien de la reserva es de otro arrendador |
| `409` | La reserva no está `EN_CURSO`: «No se puede registrar la devolución porque el alquiler no ha iniciado.» |
| `409` | Ya tiene devolución: «La devolución de esta reserva ya fue registrada.» |
| `409` | Se cerró automáticamente: «La reserva ya fue cerrada automáticamente por vencimiento del plazo.» |

El plazo de 3 días es la constante `PLAZO_DEPOSITO_DIAS`. El cierre automático y la liberación del depósito al vencer los aplica BE-10.2. Las pruebas e2e están en [test/devoluciones.e2e-spec.ts](test/devoluciones.e2e-spec.ts).

**Calificar el bien y al arrendador de una reserva**

```bash
curl -X POST $BASE/reservas/$RESERVA_ID/resenas \
  -H "Authorization: Bearer $ACCESS_TOKEN" \
  -H 'Content-Type: application/json' \
  -d '{"bien":{"puntuacion":5,"comentario":"Todo en orden."},"arrendador":{"puntuacion":4}}'
```

```jsonc
// 201 Created
{
  "reservaId": "3f2504e0-4f89-41d3-9a0c-0305e82c3301",
  "resenaBienId": "6a1f0c2e-8b4d-4e7a-9c31-5d2e8f7a1b90",
  "resenaArrendadorId": "0e9b7c5a-3d1f-4a2b-8e6c-4f7a9b2d1c08",
  "creadaEn": "2026-12-05T16:00:00.000Z"
}
```

Solo el arrendatario de la reserva puede calificarla, y una sola vez: las dos reseñas van juntas. El autor sale del token y no se acepta en el cuerpo.

| Campo | Regla |
|---|---|
| `bien.puntuacion`, `arrendador.puntuacion` | Obligatorias. Enteros de 1 a 5 |
| `bien.comentario`, `arrendador.comentario` | Opcionales, hasta 500 caracteres. Se recortan, y uno vacío cuenta como no enviado |

Las dos reseñas (tipos `BIEN` y `ARRENDADOR`) se guardan en una sola transacción: si falla una, no queda ninguna. Dos envíos simultáneos pueden pasar la validación a la vez, pero el índice único `(reserva_id, tipo)` hace fallar al segundo, que recibe `409` sin dejar ninguna reseña suya.

El plazo es de 14 días completos desde `finalizada_en`, que es la fecha de la devolución registrada o del cierre automático. Los días se cuentan por fecha de calendario en la zona de El Salvador: el día de la finalización es el día 0, el día 14 se permite y el 15 no. Es la constante `PLAZO_RESENA_DIAS`, en [plazo-resena.ts](src/resenas/utils/plazo-resena.ts). Una reserva `FINALIZADA` sin `finalizada_en` no tiene desde dónde contar el plazo y se trata como fuera de plazo.

**Consultar el resumen de pago de una reserva**

```bash
curl $BASE/reservas/$RESERVA_ID/resumen-pago \
  -H "Authorization: Bearer $ACCESS_TOKEN"
```

```jsonc
// 200 OK
{
  "reservaId": "30000000-0000-4000-8000-000000000001",
  "importeAlquiler": 240,
  "importeDeposito": 0,
  "total": 240,
  "moneda": "USD"
}
```

Solo el arrendatario dueño de la reserva puede consultarlo, y solo mientras la reserva es pagable: `CONFIRMADA` y sin un pago `SIMULADO_EXITOSO`. Los importes se calculan en el servidor con los datos guardados de la reserva y su bien; el cliente nunca los envía.

Ninguna tarea fija cómo se convierte una reserva por días a la unidad de cobro del bien. Es una decisión técnica de BE-8.1, en [calcular-cargos.ts](src/pagos/utils/calcular-cargos.ts):

| `unidadCobro` | Importe del alquiler (con `dias` = días de la reserva, contando el primero y el último) |
|---|---|
| `DIA` | `precio × dias` |
| `NOCHE` | `precio × (dias − 1)`, mínimo una noche |
| `SEMANA` | `precio × semanas iniciadas` (`dias / 7` redondeado hacia arriba) |
| `HORA` | `precio × dias × 24` |

El depósito es el `deposito` del bien (0 si no lo pide) y el total es alquiler más depósito. Se calcula con `Decimal` y se redondea a dos decimales.

Los errores, en el orden en que se evalúan:

| Código | Cuándo |
|---|---|
| `401` | Sin sesión |
| `403` | El rol no es `ARRENDATARIO` |
| `400` | `reservaId` que no es UUID, falta una reseña, puntuación que no es un entero de 1 a 5, comentario de más de 500 caracteres o un campo desconocido |
| `404` | La reserva no existe o es de otro arrendatario: «La reserva no existe.» No se distingue un caso del otro |
| `409` | La reserva ya fue calificada: «Esta reserva ya fue calificada.» |
| `422` | La reserva no está `FINALIZADA`: «Solo se puede calificar una reserva finalizada.» |
| `422` | Pasaron más de 14 días desde la finalización: «El plazo de 14 días para calificar esta reserva ya venció.» |

Las pruebas e2e están en [test/resenas.e2e-spec.ts](test/resenas.e2e-spec.ts).
| `400` | `reservaId` que no es UUID |
| `404` | La reserva no existe |
| `403` | La reserva es de otro arrendatario. No se devuelve ningún dato de ella |
| `422` | La reserva no está `CONFIRMADA` o ya tiene un pago completado |

**Pagar una reserva**

```bash
curl -X POST $BASE/reservas/$RESERVA_ID/pagos \
  -H "Authorization: Bearer $ACCESS_TOKEN" \
  -H 'Content-Type: application/json' \
  -d '{"modalidad":"TARJETA","numeroTarjeta":"4242424242424242","vencimiento":"12/28","codigoSeguridad":"123"}'
```

```jsonc
// 201 Created (aprobado)
{
  "pagoId": "b9d1c7a2-6f0e-4c3b-8a51-2e7f9d4c6a10",
  "reservaId": "30000000-0000-4000-8000-000000000001",
  "fechaHora": "2026-11-15T20:30:00.000Z",
  "importeAlquiler": 240,
  "importeDeposito": 0,
  "total": 240,
  "modalidad": "TARJETA",
  "estado": "SIMULADO_EXITOSO",
  "comprobanteId": "4e8a2f61-93c7-4d05-b1a8-6c2d0f7e9b34"
}

// 201 Created (rechazado): el pago queda registrado, sin comprobante
{
  "pagoId": "…",
  "reservaId": "30000000-0000-4000-8000-000000000001",
  "fechaHora": "2026-11-15T20:29:00.000Z",
  "importeAlquiler": 240,
  "importeDeposito": 0,
  "total": 240,
  "modalidad": "TARJETA",
  "estado": "SIMULADO_RECHAZADO",
  "motivoRechazo": "Tarjeta rechazada por la pasarela simulada."
}
```

Responde `201` tanto si la pasarela aprueba como si rechaza, porque el intento siempre se guarda: hay que revisar `estado`. El cuerpo no lleva importes ni usuario; si los trae, responde `400`. El arrendatario sale del token.

| Campo | Regla |
|---|---|
| `modalidad` | Obligatoria: `TARJETA` o `TRANSFERENCIA_BANCARIA` |
| `numeroTarjeta` | Obligatorio con `TARJETA`. De 12 a 19 dígitos, sin espacios |
| `vencimiento` | Obligatorio con `TARJETA`. `MM/AA`, no vencido (vale hasta el último día de ese mes, en la zona de El Salvador) |
| `codigoSeguridad` | Obligatorio con `TARJETA`. 3 o 4 dígitos |
| `referenciaSimulada` | Obligatoria con `TRANSFERENCIA_BANCARIA`. De 6 a 20 letras, números o guiones |

Reglas de la pasarela simulada ([pasarela-simulada.ts](src/pagos/utils/pasarela-simulada.ts)). No hay ninguna integración financiera real:

| Entrada | Resultado | `motivoRechazo` |
|---|---|---|
| Tarjeta terminada en `4242` | `SIMULADO_EXITOSO` | — |
| Tarjeta terminada en `0002` | `SIMULADO_RECHAZADO` | «Tarjeta rechazada por la pasarela simulada.» |
| Cualquier otra tarjeta | `SIMULADO_RECHAZADO` | «Tarjeta no reconocida por la pasarela simulada.» |
| Referencia `SIM-APRUEBA` | `SIMULADO_EXITOSO` | — |
| Cualquier otra referencia | `SIMULADO_RECHAZADO` | «Referencia de transferencia no reconocida.» |

Cómo se procesa:

1. Se valida la reserva sin bloquearla, para no hacer esperar a quien no puede pagar.
2. Se calculan los importes, se consulta la pasarela y se espera `PAGO_SIMULADO_DEMORA_MS` (2 segundos por defecto). La espera ocurre antes de abrir la transacción, para no tener la reserva bloqueada mientras tanto.
3. En una transacción se bloquea la fila de la reserva (`FOR UPDATE`), se vuelve a validar y se guarda el pago. Si fue aprobado lleva un `comprobanteId` nuevo y, si el bien pide depósito, se crea en la misma transacción el depósito `PENDIENTE` por ese importe.

Con el bloqueo, de dos pagos simultáneos el segundo espera, ve el pago completado del primero y recibe `409`. Si aun así el índice único parcial `Pagos_un_exitoso_por_reserva_key` rechaza el insert, también se responde `409`. Un pago rechazado no crea comprobante ni depósito: el cobro queda pendiente y el reintento es un pago nuevo.

De la tarjeta solo se guardan los últimos cuatro dígitos (`ultimos_cuatro`). El número completo y el código de seguridad no llegan al repositorio ni a la base.

Los errores, en el orden en que se evalúan:

| Código | Cuándo |
|---|---|
| `401` | Sin sesión |
| `403` | El rol no es `ARRENDATARIO` |
| `400` | `reservaId` que no es UUID, campo faltante o con formato inválido, modalidad desconocida o un campo no permitido (como importes o `userId`) |
| `400` | La tarjeta está vencida: «La tarjeta está vencida.» |
| `404` | La reserva no existe |
| `403` | La reserva es de otro arrendatario |
| `409` | Ya tiene un pago completado, también si llegan dos pagos a la vez: «Esta reserva ya tiene un pago completado.» |
| `422` | La reserva no está `CONFIRMADA`: «La reserva no se puede pagar porque no está confirmada.» |

El criterio de aceptación de H8 exige `409` para un segundo pago exitoso, así que al pagar una reserva ya pagada se responde `409`. En el resumen, esa misma reserva simplemente deja de ser pagable y responde `422`. El aviso al arrendador cuando se aprueba un pago es de BE-22.2. El comprobante se puede volver a consultar después con `GET /pagos/:pagoId/comprobante`. Las pruebas e2e están en [test/pagos.e2e-spec.ts](test/pagos.e2e-spec.ts).

**Consultar el comprobante de un pago**

```bash
curl $BASE/pagos/$PAGO_ID/comprobante \
  -H "Authorization: Bearer $ACCESS_TOKEN"
```

```jsonc
// 200 OK
{
  "pagoId": "b9d1c7a2-6f0e-4c3b-8a51-2e7f9d4c6a10",
  "comprobanteId": "4e8a2f61-93c7-4d05-b1a8-6c2d0f7e9b34",
  "reservaId": "30000000-0000-4000-8000-000000000001",
  "fechaHora": "2026-11-15T20:30:00.000Z",
  "importeAlquiler": 240,
  "importeDeposito": 0,
  "total": 240,
  "modalidad": "TARJETA",
  "estado": "SIMULADO_EXITOSO"
}
```

Solo el arrendatario dueño de la reserva del pago puede consultarlo. Todos los datos se leen de `Pagos` tal como quedaron al pagar: nada viene del cliente ni se recalcula. El comprobante no incluye los últimos dígitos de la tarjeta ni la referencia de la transferencia.

Los errores, en el orden en que se evalúan:

| Código | Cuándo |
|---|---|
| `401` | Sin sesión |
| `403` | El rol no es `ARRENDATARIO` |
| `400` | `pagoId` que no es UUID |
| `404` | El pago no existe |
| `403` | El pago es de una reserva de otro arrendatario. No se devuelve ningún dato del pago |
| `409` | El pago está `SIMULADO_RECHAZADO` o `PENDIENTE`: «El pago no cuenta con un comprobante de éxito.» |

Las pruebas e2e están en [test/comprobantes.e2e-spec.ts](test/comprobantes.e2e-spec.ts).

**Resolver el depósito de garantía**

```bash
# Retener una parte (el resto se libera)
curl -X POST $BASE/reservas/$RESERVA_ID/deposito/resolucion \
  -H "Authorization: Bearer $ACCESS_TOKEN" \
  -H 'Content-Type: application/json' \
  -d '{"accion":"RETENER","importeRetenido":25.5,"justificacion":"La puerta quedó dañada."}'

# O liberarlo por completo
curl -X POST $BASE/reservas/$RESERVA_ID/deposito/resolucion \
  -H "Authorization: Bearer $ACCESS_TOKEN" \
  -H 'Content-Type: application/json' \
  -d '{"accion":"LIBERAR"}'
```

```jsonc
// 200 OK (POST)
{
  "depositoId": "9b2f8c1e-6d34-4a0b-8f55-2c7e1d3a9b10",
  "estado": "PARCIALMENTE_RETENIDO",
  "importeOriginal": 100,
  "importeRetenido": 25.5,
  "importeLiberado": 74.5,
  "justificacion": "La puerta quedó dañada.",
  "fechaResolucion": "2026-12-13T16:02:11.000Z",
  "resueltoPor": "7c9e6679-7425-40de-944b-e07fc1f90ae7"
}
```

`resolver` es solo del arrendador dueño del bien. `resueltoPor` sale del token y es `null` si lo resolvió el sistema. La consulta del depósito está en la sección siguiente.

| Campo | Regla |
|---|---|
| `accion` | Obligatoria: `LIBERAR` o `RETENER` |
| `importeRetenido` | Obligatorio al `RETENER`: mayor que cero, hasta 2 decimales y no mayor que el saldo. Al `LIBERAR` se omite (o es `0`) |
| `justificacion` | Obligatoria al `RETENER` (1–500 caracteres, se recorta). Al `LIBERAR` es opcional |

`LIBERAR` deja `importeRetenido` en 0 y libera todo el saldo (`LIBERADO`). `RETENER` retiene el importe y libera el resto, así que retenido + liberado siempre suma el original; retener todo el saldo da `RETENIDO` y una parte, `PARCIALMENTE_RETENIDO`. La resolución corre en una transacción con la fila del depósito bloqueada (`FOR UPDATE`): dos resoluciones simultáneas, o una del arrendador y otra de la tarea diaria, se serializan y solo la primera gana.

Los errores, en el orden en que se evalúan:

| Código | Cuándo |
|---|---|
| `401` | Sin sesión |
| `403` | El rol no es `ARRENDADOR` |
| `400` | `reservaId` que no es UUID, acción desconocida, `RETENER` sin importe positivo o sin justificación, más de 2 decimales, `LIBERAR` con importe a retener, justificación de más de 500 caracteres o un campo desconocido |
| `404` | La reserva no existe, o no tiene depósito |
| `403` | El bien de la reserva es de otro arrendador |
| `409` | Ya se resolvió: «El depósito ya fue resuelto.» |
| `409` | Se liberó automáticamente: «El plazo para resolver el depósito venció y fue liberado» |
| `422` | La renta no está `FINALIZADA` o no tiene devolución: «Debe registrarse la devolución antes de resolver el depósito» |
| `422` | El importe a retener supera el saldo |

La lógica vive en `DepositoService.resolver(depositoId, actor, accion, importeRetenido?, justificacion?)`, con actor `ARRENDADOR` o `SISTEMA`. La tarea diaria BE-10.2 la usará con `SISTEMA`, que solo puede liberar y no necesita devolución (el cierre automático finaliza reservas que nunca la tuvieron); el aviso al arrendatario es BE-22.2. Las pruebas e2e están en [test/depositos.e2e-spec.ts](test/depositos.e2e-spec.ts).

**Consultar el depósito de una reserva**

```bash
curl $BASE/reservas/$RESERVA_ID/deposito \
  -H "Authorization: Bearer $ACCESS_TOKEN"
```

```jsonc
// 200 OK: depósito PARCIALMENTE_RETENIDO
{
  "depositoId": "9b2f8c1e-6d34-4a0b-8f55-2c7e1d3a9b10",
  "reservaId": "3f2504e0-4f89-41d3-9a0c-0305e82c3301",
  "importeOriginal": 100,
  "importeDisponible": 0,
  "importeRetenido": 25.5,
  "importeLiberado": 74.5,
  "estado": "PARCIALMENTE_RETENIDO",
  "resolucionAutomatica": false,
  "justificacion": "La puerta quedó dañada.",
  "fechaResolucion": "2026-12-13T16:02:11.000Z"
}
```

Es de solo lectura y lo consultan los dos participantes de la reserva: su arrendatario y el arrendador dueño del bien. Quién consulta sale del token; no se acepta ningún `userId` del cliente.

- `importeDisponible` es lo que aún se puede liberar o retener (original menos retenido y liberado): el importe completo mientras está `PENDIENTE` y `0` una vez resuelto.
- `justificacion` y `fechaResolucion` solo aparecen cuando existen. Un depósito `PENDIENTE` no lleva fecha de resolución.
- `resolucionAutomatica: true` indica que el sistema lo liberó por vencimiento del plazo. No se expone quién lo resolvió.
- Los textos que ve el usuario («El depósito aún está pendiente de resolución», «Liberado automáticamente por vencimiento del plazo») los arma el frontend a partir de `estado` y `resolucionAutomatica`.

| Código | Cuándo |
|---|---|
| `401` | Sin sesión |
| `400` | `reservaId` que no es UUID |
| `404` | La reserva no existe, o no tiene depósito |
| `403` | No es el arrendatario de la reserva ni el arrendador del bien. No se devuelve ningún dato del depósito |

Las pruebas e2e están en [test/depositos-consulta.e2e-spec.ts](test/depositos-consulta.e2e-spec.ts).

**Renovar tokens**

```bash
curl -X POST $BASE/auth/refresh \
  -H 'Content-Type: application/json' \
  -d "{\"refreshToken\":\"$REFRESH_TOKEN\"}"
```

Devuelve un par nuevo y revoca el anterior. Reusar un refresh token ya canjeado responde `401` y cierra todas las sesiones del usuario.

**Logout**

```bash
curl -X POST $BASE/auth/logout \
  -H 'Content-Type: application/json' \
  -d "{\"refreshToken\":\"$REFRESH_TOKEN\"}"
```

Responde `204 No Content`. Es idempotente: repetirlo con un token ya revocado también devuelve `204`, para no convertirse en un oráculo que revele qué tokens existen.

**Publicar un bien**

```bash
curl -X POST $BASE/bienes \
  -H "Authorization: Bearer $ACCESS_TOKEN" \
  -F tipo=PROPIEDAD \
  -F 'categoria=Salón de eventos' \
  -F 'titulo=Salón de eventos Las Palmas' \
  -F 'descripcion=Salón climatizado con cocina y parqueo.' \
  -F precio=80.00 \
  -F unidadCobro=DIA \
  -F deposito=50 \
  -F 'departamento=San Salvador' \
  -F 'municipio=San Salvador' \
  -F indicePrincipal=0 \
  -F fotos=@frente.webp \
  -F fotos=@interior.jpg
```

```jsonc
// 201 Created
{
  "id": "7c9e6679-7425-40de-944b-e07fc1f90ae7",
  "titulo": "Salón de eventos Las Palmas",
  "precio": 80,
  "unidadCobro": "DIA",
  "estado": "ACTIVA",
  "fotos": [
    { "id": "...", "url": "/uploads/bienes/7c9e6679-7425-40de-944b-e07fc1f90ae7/1.webp", "orden": 1, "esPrincipal": true },
    { "id": "...", "url": "/uploads/bienes/7c9e6679-7425-40de-944b-e07fc1f90ae7/2.jpg", "orden": 2, "esPrincipal": false }
  ],
  "creadoEn": "2026-11-02T15:00:00.000Z"
}
```

**Detalle de un bien**

Es una ruta pública: no lleva `Authorization: Bearer` y en Swagger aparece sin candado.

```bash
curl $BASE/bienes/$BIEN_ID
```

```jsonc
// 200 OK
{
  "id": "7c9e6679-7425-40de-944b-e07fc1f90ae7",
  "tipo": "PROPIEDAD",
  "categoria": "Salón de eventos",
  "titulo": "Salón de eventos Las Palmas",
  "descripcion": "Salón climatizado con cocina y parqueo.",
  "precio": 80,
  "unidadCobro": "DIA",
  "deposito": 50,
  "capacidad": 120,
  "condiciones": null,
  "departamento": "San Salvador",
  "municipio": "San Salvador",
  "direccionReferencia": null,
  "arrendador": { "id": "29bda5e8-e0c8-4ec2-bc7f-94c41c3c0140", "nombreUsuario": "ana_m" },
  "fotos": [
    { "url": "/uploads/bienes/7c9e6679-7425-40de-944b-e07fc1f90ae7/1.webp", "orden": 1, "esPrincipal": true },
    { "url": "/uploads/bienes/7c9e6679-7425-40de-944b-e07fc1f90ae7/2.jpg", "orden": 2, "esPrincipal": false }
  ],
  "calificacion": { "promedio": 4.5, "totalResenas": 12 },
  "creadoEn": "2026-11-02T15:00:00.000Z"
}
```

- `calificacion.promedio` lleva un decimal y es `null` (con `totalResenas: 0`) si el bien no tiene reseñas; no es `0`, para que el frontend no lo muestre como una calificación real. (La calificación del arrendatario de H16 sí vale `0` sin calificaciones.) Solo cuenta reseñas de tipo `BIEN`: las del arrendador y las del arrendatario no entran.
- Del arrendador solo se exponen `id` y `nombreUsuario`: nunca el email ni datos de autenticación.
- La foto principal va primero y las demás siguen por `orden`.
- `precio` y `deposito` son números; `deposito` vale `0` si el bien no pide depósito. `capacidad`, `condiciones` y `direccionReferencia` son `null` cuando no se cargaron.
- Errores: `400` si `bienId` no es un UUID y `404` con `"La publicación ya no está disponible."` si el bien no existe, está `INACTIVA` o su arrendador está desactivado. El mensaje es el mismo en los tres casos para no revelar cuál es.

**Reseñas de un bien (H15)**

Pública, como el detalle: sin `Authorization` y sin candado en Swagger. Devuelve solo reseñas de tipo `BIEN`, de la más reciente a la más antigua, 10 por página (`?pagina=`, por defecto 1).

```bash
curl "$BASE/bienes/$BIEN_ID/resenas?pagina=1"
```

```jsonc
// 200 OK
{
  "items": [
    {
      "id": "3f1c2a40-6b7d-4c1e-9a52-8d0e7b6f1a23",
      "puntuacion": 5,
      "comentario": "Muy limpio y bien ubicado.",
      "autor": { "nombreUsuario": "carlos_r" },
      "creadaEn": "2026-11-10T15:00:00.000Z"
    }
  ],
  "pagina": 1,
  "total": 12,
  "hayMas": true
}
```

- `comentario` se omite si la reseña no lo tiene. Del autor solo se expone `nombreUsuario`.
- Una página sin resultados devuelve `items: []`; un bien sin reseñas, `total: 0`.
- Errores: `400` si `bienId` no es un UUID o `pagina` no es un entero de 1 a 10 000; `404` con el mismo mensaje del detalle si el bien no existe, está `INACTIVA` o su arrendador está desactivado.
- El promedio y el conteo salen de `ResenaRepository.calificacionDeBien()` (vía `ResenasService`) y el listado de `ResenaRepository.listarDeBien()`; las dos usan el mismo filtro de reseñas `BIEN`. `ResenasModule` es el dueño de la calificación y `BienesModule` lo importa (nunca al revés). El controlador del listado vive en `bienes/controllers` porque comprueba la publicación con `BienesService.verificarPublicado()`. Las pruebas e2e están en [test/bienes-resenas.e2e-spec.ts](test/bienes-resenas.e2e-spec.ts).

**Consultar al arrendador sobre una publicación (H13)**

El arrendatario abre la conversación; el arrendador sale de la publicación y el arrendatario del token. Hay una sola conversación previa por bien y arrendatario, garantizada por el índice único parcial `Conversaciones_previa_unica_idx` (`bien_id`, `arrendatario_id`, solo filas sin reserva).

```bash
curl -X POST $BASE/bienes/$BIEN_ID/conversacion \
  -H "Authorization: Bearer $ACCESS_TOKEN"
```

```jsonc
// 201 Created la primera vez; 200 OK si ya existía
{
  "id": "9b2f1c3e-5a4d-4e6f-8a7b-1c2d3e4f5a6b",
  "bienId": "7c9e6679-7425-40de-944b-e07fc1f90ae7",
  "arrendador": { "id": "29bda5e8-e0c8-4ec2-bc7f-94c41c3c0140", "nombreUsuario": "ana_m" },
  "arrendatario": { "id": "5d1e2f3a-4b5c-4d6e-8f70-8192a3b4c5d6", "nombreUsuario": "luis_r" },
  "creadaEn": "2026-11-15T15:00:00.000Z"
}
```

- Si dos peticiones la abren al mismo tiempo, el índice deja crear solo una; la otra recupera esa misma conversación y responde `200`. `409` queda solo para el caso en que, tras el choque, no se pueda leer la conversación ganadora.
- Errores: `400` si `bienId` no es un UUID, `401` sin sesión, `403` si el rol no es `ARRENDATARIO`, `404` si la publicación no existe o su arrendador está desactivado, `422` si la publicación no está `ACTIVA` o es del propio usuario.

Después, los dos participantes escriben y leen con el `id` de la conversación:

```bash
curl -X POST $BASE/conversaciones/$CONVERSACION_ID/mensajes \
  -H "Authorization: Bearer $ACCESS_TOKEN" \
  -H 'Content-Type: application/json' \
  -d '{"contenido":"¿Está disponible el 20 de diciembre?"}'

curl "$BASE/conversaciones/$CONVERSACION_ID/mensajes?orden=asc" \
  -H "Authorization: Bearer $ACCESS_TOKEN"
```

```jsonc
// 200 OK (el POST responde 201 con un solo mensaje con esta misma forma)
{
  "conversacionId": "9b2f1c3e-5a4d-4e6f-8a7b-1c2d3e4f5a6b",
  "orden": "asc",
  "mensajes": [
    {
      "id": "c3d4e5f6-a7b8-4c9d-8e0f-1a2b3c4d5e6f",
      "conversacionId": "9b2f1c3e-5a4d-4e6f-8a7b-1c2d3e4f5a6b",
      "remitente": { "id": "5d1e2f3a-4b5c-4d6e-8f70-8192a3b4c5d6", "nombreUsuario": "luis_r" },
      "contenido": "¿Está disponible el 20 de diciembre?",
      "creadoEn": "2026-11-15T15:05:00.000Z"
    }
  ]
}
```

- `contenido` debe tener de 1 a 1000 caracteres y no puede ser solo espacios; si no, `400` con `"El mensaje debe contener entre 1 y 1000 caracteres"`. Se guarda tal como llega, sin recortar. Un emoji cuenta como un carácter, igual que en la columna `VARCHAR(1000)`.
- El remitente es siempre el usuario del token: un `remitenteId` en el cuerpo responde `400`.
- Solo los dos participantes leen y escriben, sea cual sea su rol. A cualquier otro usuario se le responde `403` sin datos del historial; una conversación inexistente responde `404`.
- Estas rutas (`/conversaciones/:id/mensajes`) solo operan sobre conversaciones previas, las que no tienen reserva. Una conversación vinculada a una reserva responde `404` con `"La conversación no existe."` a cualquier usuario, incluidos sus participantes, y no se guarda ningún mensaje ni se pide ningún aviso.
- Si la publicación pasa a `INACTIVA`, la conversación ya abierta sigue funcionando: se conserva el historial. Lo que ya no se puede es abrir una nueva sobre ella.
- El historial se ordena por fecha y luego por `id`, así el orden es estable aunque dos mensajes tengan la misma fecha. No está paginado.
- **Aviso al otro participante.** Después de guardar el mensaje se llama a `NotificacionesService.crear` (Módulo 8) con el otro participante como destinatario, el título `"Nuevo mensaje"`, el texto `"<nombreUsuario>: <contenido>"` recortado a 300 caracteres, `ModuloOrigen.MENSAJERIA` y la referencia `{ tipoReferencia: "MENSAJE", referenciaId: <id del mensaje> }`.
- **Un aviso por mensaje.** Cada mensaje guardado es un evento distinto y genera su propio aviso para el otro participante. El Módulo 8 deduplica por destinatario y referencia, así que solo descarta un segundo aviso del **mismo** mensaje (por ejemplo, en un reintento), que devuelve `creada: false` y no es un error. La conversación del aviso se obtiene del mensaje (`Mensajes.conversacion_id`); no hizo falta agregar columnas.
- Si el aviso falla, el mensaje no se revierte: ya quedó guardado, la respuesta es `201` y el error se registra en el log, igual que en los avisos de pagos y depósitos.

**Bandeja de conversaciones**

`GET /api/v1/conversaciones?tipo=CONSULTA&pagina=1`

Permite consultar las conversaciones en las que participa
el usuario autenticado, tanto como arrendador como arrendatario.

No tiene restricción por rol, pero requiere autenticación JWT.

**Parámetros opcionales:**

- `tipo`: `CONSULTA` o `COORDINACION`.
- `pagina`: entero positivo, por defecto `1`.

Cada página contiene hasta 20 conversaciones.

**Clasificación:**

- `CONSULTA`: conversación sin reserva asociada.
- `COORDINACION`: conversación asociada a una reserva.

**Respuesta:**

- `items`: conversaciones de la página.
- `pagina`: número de página consultada.
- `total`: cantidad total de conversaciones coincidentes.
- `hayMas`: indica si existen páginas posteriores.

Cada conversación incluye:

- `id` y `tipo`.
- `bien`: ID, título y fotografía principal.
- `reservaId`: ID de reserva o `null`.
- `otroParticipante`: ID y nombre de usuario.
- `ultimoMensaje`: contenido, fecha y remitente, o `null`.
- `actualizadaEn`: fecha de la última actividad.

El contenido del último mensaje se limita a 120 caracteres.

Las conversaciones se ordenan por la fecha del último mensaje,
o por su fecha de creación cuando todavía no tienen mensajes.

La paginación se realiza después del ordenamiento global.

**Errores:**

- `400`: tipo o página inválidos.
- `401`: usuario no autenticado.

Las consultas se restringen a conversaciones donde el usuario
autenticado participa como arrendador o arrendatario.

**Coordinar la entrega en la conversación de la reserva (H14)**

Una vez confirmada la reserva, el arrendatario y el arrendador (dueño del bien) acuerdan fecha, hora, lugar y condiciones de entrega en una conversación propia de esa reserva. Los participantes salen siempre de la reserva guardada: el arrendatario de `Reservas.arrendatario_id` y el arrendador del bien de la reserva. Nunca vienen del cliente.

```bash
curl $BASE/reservas/$RESERVA_ID/conversacion \
  -H "Authorization: Bearer $ACCESS_TOKEN"
```

```jsonc
// 200 OK, también la primera vez, cuando la crea
{
  "id": "6a1b2c3d-4e5f-4a6b-8c7d-9e0f1a2b3c4d",
  "reservaId": "3f1a2b4c-5d6e-4f70-8a91-b2c3d4e5f607",
  "estado": "CONFIRMADA",
  "fechaInicio": "2026-12-20",
  "fechaFin": "2026-12-22",
  "bien": { "id": "7c9e6679-7425-40de-944b-e07fc1f90ae7", "titulo": "Salón de eventos" },
  "arrendador": { "id": "29bda5e8-e0c8-4ec2-bc7f-94c41c3c0140", "nombreUsuario": "ana_m" },
  "arrendatario": { "id": "5d1e2f3a-4b5c-4d6e-8f70-8192a3b4c5d6", "nombreUsuario": "luis_r" },
  "creadaEn": "2026-11-15T15:00:00.000Z"
}
```

```bash
curl -X POST $BASE/reservas/$RESERVA_ID/conversacion/mensajes \
  -H "Authorization: Bearer $ACCESS_TOKEN" \
  -H 'Content-Type: application/json' \
  -d '{"contenido":"Entrego el sábado a las 9 en la entrada principal."}'
# 201 Created con el mensaje: id, conversacionId, remitente { id, nombreUsuario }, contenido y creadoEn

curl "$BASE/reservas/$RESERVA_ID/conversacion/mensajes?orden=asc" \
  -H "Authorization: Bearer $ACCESS_TOKEN"
# 200 OK con { conversacionId, orden, mensajes: [...] }, la misma forma que el historial de H13
```

- **Quién entra.** Solo el arrendatario de la reserva y el arrendador dueño del bien, sea cual sea su rol (la ruta no usa `@Roles`). Cualquier otro usuario recibe `403` `"No participas en la coordinación de esta reserva."`, sin datos de la reserva ni del historial.
- **Cuándo.** Leer y escribir tienen reglas distintas:
  - **Leer** (`GET` de la conversación y del historial): si la conversación ya existe, se devuelve en **cualquier** estado de la reserva, también `FINALIZADA` o `CANCELADA`, porque el historial es la evidencia de lo acordado para la entrega. Si todavía no existe, solo se crea con la reserva `CONFIRMADA` o `EN_CURSO`; en otro estado responde `422`.
  - **Escribir** (`POST` de mensajes): solo con la reserva `CONFIRMADA` o `EN_CURSO`, aunque la conversación ya exista. En otro estado responde `422` sin crear conversación, mensaje ni aviso.
  - El `422` lleva siempre `"La coordinación está disponible cuando la reserva está confirmada o en curso"`. El participante se comprueba antes que el estado, así un tercero no averigua en qué estado está la reserva.
- **Una conversación por reserva, idempotente.** Las tres rutas recuperan la conversación de la reserva o la crean con el bien y los participantes leídos de la reserva. El índice único `Conversaciones_reserva_id_key` (DB-14.1) deja crear solo una: si dos peticiones llegan a la vez, la segunda recibe el choque, relee la que ganó y responde igual que la primera. `409` `"No se pudo recuperar la conversación. Intenta de nuevo."` queda solo para el caso en que, tras el choque, no se pueda leer la ganadora. El trigger de DB-14.1 sigue comprobando que bien y participantes coincidan con la reserva.
- **Respuesta de la conversación.** Incluye un resumen de la reserva (`estado`, `fechaInicio` y `fechaFin` como `AAAA-MM-DD`, y el `bien` con `id` y `titulo`) para que los dos participantes lo vean, aunque `GET /reservas/:id` solo esté disponible para el arrendatario. Los participantes van solo con `id` y `nombreUsuario`: nunca correos, roles ni datos de pago.
- **Mensajes.** El mismo `CrearMensajeDto` de H13: `contenido` de 1 a 1000 caracteres, sin ser vacío ni solo espacios, o `400` con `"El mensaje debe contener entre 1 y 1000 caracteres"`. El remitente es siempre el usuario del token: un `remitenteId` en el cuerpo responde `400`. El historial se ordena por fecha y luego por `id` (`?orden=asc` por defecto, `desc` al revés) y solo contiene los mensajes de esa reserva.
- **Aviso al otro participante.** Después de guardar el mensaje se llama a `NotificacionesService.crear` (Módulo 8) con el otro participante como destinatario (nunca el remitente), el título `"Mensaje sobre la entrega"`, el texto `"<nombreUsuario>: <contenido>"` recortado a 300 caracteres, `ModuloOrigen.MENSAJERIA` (el Módulo 5 en la especificación) y la referencia `{ tipoReferencia: "MENSAJE", referenciaId: <id del mensaje> }`. Cada mensaje genera su propio aviso; con la reserva o la conversación como referencia, la deduplicación del Módulo 8 dejaría un solo aviso por participante en toda la reserva. La conversación y la reserva se obtienen del mensaje.
- Si el aviso falla, el mensaje no se revierte: la respuesta es `201`, el error se registra en el log y no se reintenta.
- Errores: `400` (`reservaId` no es UUID, contenido u `orden` inválidos, campos de más), `401` sin sesión, `403` no participante, `404` `"La reserva no existe."`, `409` choque irrecuperable al crear, `422` si hay que crear la conversación o enviar un mensaje y la reserva no está `CONFIRMADA` ni `EN_CURSO`.
- Las rutas de H13 (`/conversaciones/:id/mensajes`) siguen sin atender estas conversaciones: responden `404`.
- Pruebas: unitarias en `src/conversaciones` (`coordinacion.service.spec.ts`, `coordinacion.controller.spec.ts`, `coordinacion.spec.ts` y el repositorio) y e2e en [test/conversaciones-reserva.e2e-spec.ts](test/conversaciones-reserva.e2e-spec.ts) (acceso, estados, concurrencia, mensajes, avisos, aislamiento entre reservas y la unicidad de la base).

### Reportes del arrendador (base)

`ReportesModule` reúne lo que comparten los reportes del arrendador (ingresos, ocupación, calificaciones y resumen): el periodo, el filtro por arrendador y el control de acceso. Todo el módulo lleva `@Roles(Rol.ARRENDADOR)`: sin sesión responde `401` y con rol `ARRENDATARIO`, `403`. Ninguna ruta recibe un `arrendadorId`; el arrendador sale siempre de la sesión, y una query con ese campo responde `400`.

`GET /reportes/periodo` devuelve el rango que usará un reporte, para mostrarlo antes de consultarlo:

```bash
curl "$BASE/reportes/periodo?periodo=ULTIMO_MES" -H "Authorization: Bearer $TOKEN"
```

```json
{ "periodo": "ULTIMO_MES", "desde": "2026-10-17", "hasta": "2026-11-15" }
```

| Parámetro | Valores | Notas |
|---|---|---|
| `periodo` | `ULTIMO_MES` (por defecto), `ULTIMOS_3_MESES`, `ULTIMO_ANIO`, `RANGO` | Los tres primeros cuentan hoy: 30, 90 y 365 días (de `hoy-29`, `hoy-89` y `hoy-364` a `hoy`) |
| `desde`, `hasta` | `AAAA-MM-DD` | Obligatorias solo con `RANGO`; con otro periodo se ignoran, aunque vengan mal escritas |

"Hoy" es el día de El Salvador, no el de UTC. Los errores `400` del rango traen este mensaje exacto en `message`, evaluados en este orden:

| Cuándo | `message` |
|---|---|
| `RANGO` sin `desde` o sin `hasta` | `Completa las fechas del rango.` |
| Fecha que no es `AAAA-MM-DD` o no existe (`2026-02-30`) | `Usa el formato AAAA-MM-DD.` |
| `hasta` anterior a `desde` | `La fecha final no puede ser anterior a la inicial.` |
| Más de 365 días (inclusivos) | `El rango no puede ser mayor a 365 días.` |

Un rango de 1 día y uno de 365 días son válidos; 366 es `400`. Para los reportes que se añadan, el módulo expone `ReportesService.resolverPeriodo()` y `ReportesService.bienesActivosDelArrendador()` (los bienes `ACTIVA` del arrendador, ordenados por título; lista vacía si no tiene).

#### Ingresos por bien (`GET /reportes/ingresos`)

Recibe los mismos parámetros que `/reportes/periodo` (`periodo`, `desde`, `hasta`) y los mismos `400`. Devuelve, para **cada bien `ACTIVA` del arrendador de la sesión**, lo que ingresó en el periodo y el depósito que retuvo:

```bash
curl "$BASE/reportes/ingresos?periodo=ULTIMO_MES" -H "Authorization: Bearer $TOKEN"
```

```json
{
  "periodo": { "desde": "2026-10-17", "hasta": "2026-11-15" },
  "moneda": "USD",
  "totalIngresos": 250,
  "totalDepositoRetenido": 50,
  "totalBienes": 4,
  "bienes": [
    { "bienId": "00000000-0000-4000-8000-000000000001", "titulo": "Salón de eventos", "ingresos": 250, "depositoRetenido": 50 },
    { "bienId": "00000000-0000-4000-8000-000000000004", "titulo": "Mesa de sonido", "ingresos": 0, "depositoRetenido": 0 }
  ]
}
```

| Campo | Cómo se calcula |
|---|---|
| `ingresos` | Suma de `importe_alquiler` de los pagos `SIMULADO_EXITOSO` de las reservas del bien, según la fecha del pago. El depósito del pago (`importe_deposito`) **nunca** se suma, y los pagos `SIMULADO_RECHAZADO` o `PENDIENTE` tampoco |
| `depositoRetenido` | Suma de `importe_retenido` de los depósitos `RETENIDO` o `PARCIALMENTE_RETENIDO`, según su fecha de resolución. No se suma al ingreso, y un depósito `LIBERADO` no cuenta |
| `totalIngresos`, `totalDepositoRetenido` | Suma de los valores de los bienes devueltos |
| `bienes` | De mayor a menor ingreso y, a igual ingreso, por título de la A a la Z (comparación en español). Incluye también los bienes sin pagos, con `0`. No hay paginación: `totalBienes` es su cantidad |

- **Los días son de El Salvador.** `desde` y `hasta` se interpretan en la zona `America/El_Salvador`: un pago de las 23:59 del último día suma y uno de las 00:00 del día siguiente, no.
- **Dos decimales exactos.** Los importes se suman en centavos enteros y se dividen entre 100 al final, así `0.10 + 0.20` da `0.3` y no `0.30000000000000004`. En JSON un `250.00` viaja como `250`: son números redondeados a dos decimales, no cadenas.
- **Una sola consulta de solo lectura.** Pagos y depósitos se agregan por bien con un `UNION ALL` (no un `JOIN` entre ellos, que repetiría filas) y `$queryRaw` con parámetros; los índices parciales de DB-23.1 la respaldan. Si el arrendador no tiene bienes activos, responde `bienes: []` y totales en `0` sin consultar.
- **Los bienes inactivos no cuentan.** Los pagos de un bien `INACTIVA` salen del reporte, porque los totales son la suma de los bienes de la lista.
- **Errores:** `400` (los de `/reportes/periodo`), `401` sin sesión y `403` con otro rol. No hay `404` ni `409`: el endpoint no recibe identificadores.

#### Calificaciones por bien (`GET /reportes/calificaciones`)

```bash
curl "$BASE/reportes/calificaciones?periodo=ULTIMO_MES" -H "Authorization: Bearer $TOKEN"
```

```json
{
  "periodo": { "desde": "2026-10-17", "hasta": "2026-11-15" },
  "escalaMaxima": 5,
  "totalBienes": 4,
  "bienes": [
    { "bienId": "00000000-0000-4000-8000-000000000004", "titulo": "Mesa de sonido", "promedio": 3, "totalResenas": 1 },
    { "bienId": "00000000-0000-4000-8000-000000000001", "titulo": "Salón de eventos", "promedio": 4.5, "totalResenas": 2 },
    { "bienId": "00000000-0000-4000-8000-000000000003", "titulo": "Proyector 4K", "promedio": null, "totalResenas": 0 },
    { "bienId": "00000000-0000-4000-8000-000000000002", "titulo": "Taladro industrial", "promedio": null, "totalResenas": 0 }
  ]
}
```

El ejemplo son los bienes 1 a 4 del seed de DB-25.1. En `develop` el arrendador de prueba tiene además los bienes de otras historias, que aparecen sin calificaciones (y por título) entre los `null`.

Acepta la misma query y responde los mismos `400` que `/reportes/periodo`. Por cada bien `ACTIVA` del arrendador de la sesión:

- `promedio` es el promedio de las reseñas de tipo `BIEN` de reservas `FINALIZADA` cuya `fechaFin` cae en el periodo (ambos días cuentan), redondeado a un decimal con `promedioConUnDecimal`. Las reseñas sobre el arrendador o el arrendatario no entran.
- Sin reseñas en el periodo, `promedio` es `null` y `totalResenas` es `0`: el frontend muestra «Sin calificaciones».
- La lista va de menor a mayor promedio; a igual promedio, por título de la A a la Z en español (sin distinguir mayúsculas ni tildes); los bienes sin calificaciones, al final.

Es solo lectura: una consulta con `LEFT JOIN` sobre Bienes, Reservas y Resenas en `ReportesRepository.calificacionesDeBienes()`, que suma y cuenta las reseñas; el promedio y su redondeo los calcula `promedioConUnDecimal` (pruebas unitarias en `src/reportes/utils/calificaciones.spec.ts`). Las pruebas e2e están en [test/reportes-calificaciones.e2e-spec.ts](test/reportes-calificaciones.e2e-spec.ts) (datos propios) y [test/reportes-calificaciones-seed.e2e-spec.ts](test/reportes-calificaciones-seed.e2e-spec.ts) (integración con el seed: lo carga con `npm run db:seed` antes de probar).

#### Ocupación por bien (`GET /reportes/ocupacion`)

Recibe los mismos parámetros que `/reportes/periodo` y responde los mismos `400`, `401` y `403`.

```bash
curl "$BASE/reportes/ocupacion?periodo=ULTIMO_MES" -H "Authorization: Bearer $TOKEN"
```

```json
{
  "periodo": { "desde": "2026-10-17", "hasta": "2026-11-15" },
  "totalBienes": 4,
  "bienes": [
    { "bienId": "00000000-0000-4000-8000-000000000004", "titulo": "Mesa de sonido", "diasDisponibles": 30, "diasOcupados": 30, "tasaOcupacion": 100 },
    { "bienId": "00000000-0000-4000-8000-000000000001", "titulo": "Salón de eventos", "diasDisponibles": 20, "diasOcupados": 10, "tasaOcupacion": 50 },
    { "bienId": "00000000-0000-4000-8000-000000000003", "titulo": "Proyector 4K", "diasDisponibles": 30, "diasOcupados": 0, "tasaOcupacion": 0 },
    { "bienId": "00000000-0000-4000-8000-000000000002", "titulo": "Taladro industrial", "diasDisponibles": 0, "diasOcupados": 0, "tasaOcupacion": null }
  ]
}
```

Por cada bien `ACTIVA` del arrendador de la sesión, los días se cuentan con `calcularOcupacion` (sección siguiente):

- `diasDisponibles`: los días del periodo menos los bloqueados.
- `diasOcupados`: los días disponibles cubiertos por reservas `CONFIRMADA`, `EN_CURSO` o `FINALIZADA` (`ESTADOS_QUE_OCUPAN`, los mismos del calendario y la búsqueda). Las `EN_COLA`, `RECHAZADA` y `CANCELADA` no se consultan. Cada día cuenta una vez y una reserva que cruza el borde del periodo solo cuenta los días de adentro.
- `tasaOcupacion`: ocupados ÷ disponibles × 100, con un decimal y sin pasar de 100. `null` significa «Sin días disponibles». Un bien sin reservas ni bloqueos da `0`.
- Orden: de mayor a menor tasa; a igual tasa, por título de la A a la Z en español; los `null` al final. El orden de menor a mayor lo aplica el frontend.

Es solo lectura: dos consultas (reservas y bloqueos que se cruzan con el periodo) para todos los bienes, no una por bien, filtradas por el arrendador de la sesión (`ReportesRepository.intervalosDeOcupacion()`). Las pruebas e2e están en [test/reportes-ocupacion.e2e-spec.ts](test/reportes-ocupacion.e2e-spec.ts).

#### Cálculo de ocupación

`calcularOcupacion(periodo, reservas, bloqueos)` (`src/reportes/utils/ocupacion.ts`) es una función pura: no usa la base ni conoce estados, así que quien la llame entrega solo las reservas `CONFIRMADA`, `EN_CURSO` o `FINALIZADA`. Devuelve `diasPeriodo`, `diasBloqueados`, `diasDisponibles`, `diasOcupados` y `tasa`.

- Fechas de calendario a medianoche UTC, con **ambos extremos incluidos**: un periodo de `desde` = `hasta` es 1 día.
- Cada intervalo se recorta al periodo y los que quedan fuera se descartan. Bloqueos solapados y reservas solapadas cuentan cada día una vez.
- Una reserva sobre un día bloqueado no cuenta como ocupada, y los días bloqueados salen del denominador (`diasDisponibles = diasPeriodo - diasBloqueados`).
- `tasa = diasOcupados / diasDisponibles × 100`, con un decimal y **tope de 100**. Sin días disponibles es `null` (no se divide entre cero).
- Lanza `Error` si el periodo o un intervalo tiene el fin antes del inicio.
- Pruebas: `npx vitest run src/reportes/utils/ocupacion.spec.ts`.

#### Resumen comparativo (`GET /reportes/resumen`)

Junta en una fila por bien los ingresos, la tasa de ocupación y la calificación promedio del mismo periodo, para comparar los bienes en una sola tabla. Recibe los mismos parámetros que `/reportes/periodo` y responde los mismos `400`, `401` y `403`.

```bash
curl "$BASE/reportes/resumen?periodo=ULTIMO_MES" -H "Authorization: Bearer $TOKEN"
```

```json
{
  "periodo": { "desde": "2026-10-17", "hasta": "2026-11-15" },
  "moneda": "USD",
  "escalaMaxima": 5,
  "totalBienes": 4,
  "bienes": [
    { "bienId": "00000000-0000-4000-8000-000000000004", "titulo": "Mesa de sonido", "ingresos": 0, "tasaOcupacion": 100, "calificacionPromedio": 3, "totalResenas": 1 },
    { "bienId": "00000000-0000-4000-8000-000000000003", "titulo": "Proyector 4K", "ingresos": 0, "tasaOcupacion": 0, "calificacionPromedio": null, "totalResenas": 0 },
    { "bienId": "00000000-0000-4000-8000-000000000001", "titulo": "Salón de eventos", "ingresos": 250, "tasaOcupacion": 50, "calificacionPromedio": 4.5, "totalResenas": 2 },
    { "bienId": "00000000-0000-4000-8000-000000000002", "titulo": "Taladro industrial", "ingresos": 0, "tasaOcupacion": null, "calificacionPromedio": null, "totalResenas": 0 }
  ]
}
```

- **No calcula nada por su cuenta.** `ResumenService.resumen()` llama a los mismos servicios que `/reportes/ingresos`, `/reportes/ocupacion` y `/reportes/calificaciones`, y une sus filas por `bienId` (`armarResumen`, en `src/reportes/utils/resumen.ts`). Por eso cada valor es igual al de su reporte individual: `ingresos` con dos decimales, `tasaOcupacion` y `calificacionPromedio` (el `promedio` de calificaciones) con uno.
- **Un solo periodo.** El instante de la consulta se fija una vez y se pasa a los tres servicios, así que los tres resuelven las mismas fechas aunque la consulta cruce la medianoche. Un rango inválido responde `400` antes de consultar la base.
- **Filas:** una por bien `ACTIVA` del arrendador de la sesión, también los que no tienen movimientos. Orden por título de la A a la Z en español (sin distinguir mayúsculas ni tildes).
- **Nulos:** `tasaOcupacion = null` es «Sin días disponibles» y `calificacionPromedio = null` es «Sin calificaciones». Un bien sin pagos, sin reseñas y sin días disponibles sale con `0`, `null` y `null`. Un arrendador sin bienes recibe `bienes: []`.
- Es solo lectura. Las pruebas e2e están en [test/reportes-resumen.e2e-spec.ts](test/reportes-resumen.e2e-spec.ts) (datos propios; compara cada fila con los tres endpoints en cuatro periodos) y [test/reportes-resumen-seed.e2e-spec.ts](test/reportes-resumen-seed.e2e-spec.ts) (con el seed).

#### Exportar el resumen a CSV (`GET /reportes/resumen/exportar`)

Descarga como archivo CSV la misma tabla que `GET /reportes/resumen`. Solo para el rol `ARRENDADOR`, con los bienes del arrendador de la sesión. Recibe los mismos parámetros (`periodo`, y `desde` y `hasta` solo con `periodo=RANGO`) y responde los mismos `400`, `401` y `403`, **siempre en JSON**, nunca como CSV.

```bash
curl -OJ "$BASE/reportes/resumen/exportar?periodo=ULTIMO_MES" \
  -H "Authorization: Bearer $TOKEN"
# Ejemplo con hoy = 2026-11-05: guarda resumen-desempeno_2026-10-07_2026-11-05.csv
# (el nombre cambia según el día: lleva las fechas del periodo resuelto).
```

```
Content-Type: text/csv; charset=utf-8
Content-Disposition: attachment; filename="resumen-desempeno_2026-10-07_2026-11-05.csv"
Cache-Control: no-store
```

Líneas de los bienes de reportes del seed del arrendador A para ese último mes (el BOM inicial no se ve; el seed completo le da además bienes de otras historias):

```csv
Bien,Ingresos (USD),Tasa de ocupación (%),Calificación promedio,Reseñas
Mesa de sonido,0.00,100.0,3.0,1
Proyector 4K,0.00,0.0,Sin calificaciones,0
Salón de eventos,250.00,50.0,4.5,2
Taladro industrial,0.00,Sin días disponibles,Sin calificaciones,0
```

- **Mismos datos.** El endpoint llama a `ResumenService.resumen()` y convierte su respuesta (`generarResumenCsv`, en `src/reportes/utils/resumen-csv.ts`): mismas filas, mismo orden y mismos valores que el JSON del mismo periodo. No vuelve a calcular ni a ordenar. El archivo se arma en memoria y no se guarda en disco.
- **Nombre:** `resumen-desempeno_AAAA-MM-DD_AAAA-MM-DD.csv`, con `desde` y `hasta` del periodo **resuelto** (para `ULTIMO_MES` son hoy-29 y hoy; fuera de `RANGO`, los `desde` y `hasta` de la query se ignoran).
- **Formato:** UTF-8 con BOM (para que las tildes y la eñe se vean bien en una hoja de cálculo), separador coma, CRLF al final de **cada** línea (también de la última) y punto decimal. Ingresos con dos decimales; tasa y promedio con uno.
- **Nulos:** con el texto que ve el usuario, `Sin días disponibles` y `Sin calificaciones`.
- **Escape:** un campo con coma, comillas o salto de línea va entre comillas dobles, con las comillas internas duplicadas (`Casa, "grande"` → `"Casa, ""grande"""`).
- **Fórmulas:** si un título empieza con `=`, `+`, `-`, `@`, un tabulador o un retorno de carro, se le antepone una comilla simple antes de escapar, para que la hoja de cálculo lo trate como texto (`=SUMA(1+1)` → `'=SUMA(1+1)`). Los cuatro primeros son los de BE-26.2; el tabulador y el retorno de carro son los que OWASP añade (CSV Injection). Por la API ningún título puede empezar con ellos, porque se recorta al crear el bien, así que cubrirlos es defensa en profundidad para datos que lleguen por otra vía. Solo cambia el archivo: el título guardado y el JSON del resumen no se modifican.
- **Sin caché:** la respuesta lleva `Cache-Control: no-store`, para que ni el navegador ni un intermediario guarden una copia del archivo, que contiene los ingresos del arrendador. Solo esta ruta lo envía; el JSON de los reportes no cambia.
- **Sin bienes:** el archivo tiene solo la línea del encabezado.
- Pruebas: unitarias del generador en `src/reportes/utils/resumen-csv.spec.ts`; e2e en [test/reportes-resumen-exportar.e2e-spec.ts](test/reportes-resumen-exportar.e2e-spec.ts) (cabeceras, BOM, comparación con el JSON en los cuatro periodos, escape, fórmulas y errores) y [test/reportes-resumen-exportar-seed.e2e-spec.ts](test/reportes-resumen-exportar-seed.e2e-spec.ts) (con el seed).

### Verificación de identidad: carga del documento (H17)

`POST /verificaciones` (BE-17.1) recibe el documento de identidad del usuario autenticado (rol `ARRENDADOR` o `ARRENDATARIO`) y crea su solicitud `EN_REVISION`, que queda a la espera de la revisión automática de BE-18.1.

```bash
curl -X POST $BASE/verificaciones \
  -H "Authorization: Bearer $ACCESS_TOKEN" \
  -F "documento=@dui.pdf"
```

```jsonc
// 201 Created
{
  "id": "5d8e1f2a-7b9c-4d3e-a1b2-c3d4e5f60718",
  "estado": "EN_REVISION",
  "creadaEn": "2026-11-16T15:00:00.000Z"
}
```

- **Formato:** JPG, PNG o PDF, detectado por los primeros bytes del archivo (`FF D8 FF`, `89 50 4E 47 0D 0A 1A 0A` o `%PDF-`). La extensión y el `Content-Type` no cuentan: un GIF llamado `dui.jpg` responde `415`, y en `mime_type` se guarda el tipo detectado.
- **Tamaño:** hasta 5 MB (5 242 880 bytes, inclusive), igual que el CHECK `DocumentosVerificacion_tamano_check`.
- **Almacenamiento:** el archivo se recibe en memoria (multer memory storage) y se guarda en `DocumentosVerificacion.contenido` (BYTEA). No se escribe en disco ni se sirve como archivo estático.
- **Nombre original:** se guarda sin ruta (se corta en `/` y `\`), sin caracteres de control y sin espacios en los extremos. Los acentos se conservan.
- **Usuario:** sale siempre del token. Un `usuarioId` u otro campo de texto en el formulario se ignora.
- **Una sola solicitud `EN_REVISION` por usuario,** garantizada por el índice único parcial `solicitud_una_en_revision`: con envíos simultáneos solo uno se guarda y los demás responden `409`. Tras una solicitud `APROBADA` (renovación) o `RECHAZADA` se puede enviar otra.
- **Atomicidad:** la solicitud y su documento se crean en un solo `create` anidado. Si falla el documento, la solicitud tampoco queda.
- **Lo que no se expone:** la respuesta solo trae `id`, `estado` y `creadaEn`, nunca el contenido ni el nombre del archivo, y los mensajes de error tampoco lo repiten.
- El estado de verificación se deriva de la solicitud más reciente. Mientras una renovación está `EN_REVISION`, el usuario deja de contar como verificado (por ejemplo, en `VerificacionService.puedeReservar`) hasta que BE-18.1 la resuelva.

| Código | Cuándo |
|---|---|
| `201` | Solicitud creada `EN_REVISION` |
| `400` | Falta el documento, viene más de un archivo o en otro campo, el formulario está mal formado, o el nombre del archivo queda vacío o supera 255 caracteres |
| `401` | Sin sesión, token inválido o cuenta inactiva |
| `409` | `"Ya tienes un documento en revisión."` |
| `413` | `"El archivo supera 5 MB."` |
| `415` | Archivo vacío o con un formato distinto de JPG, PNG o PDF |

El archivo se valida antes de comprobar la solicitud en revisión: un archivo inválido responde `400`, `413` o `415` aunque ya exista una `EN_REVISION`.

Pruebas: `npx vitest run src/verificaciones` (unitarias), `test/verificaciones-carga.e2e-spec.ts` (e2e) y `src/verificaciones/repositories/solicitud-verificacion.repository.integration.spec.ts` (concurrencia y atomicidad contra PostgreSQL, con `RUN_DB_INTEGRATION=1`).

**Consultar mi estado de verificación (BE-17.2)**

`GET /verificaciones/mi-estado` devuelve el estado del usuario autenticado. El usuario sale del token: la ruta no recibe ningún identificador, un `usuarioId` en la URL se ignora y no existe una consulta del estado de otro usuario.

```bash
curl $BASE/verificaciones/mi-estado \
  -H "Authorization: Bearer $ACCESS_TOKEN"
```

```jsonc
// 200 OK
{
  "estado": "RECHAZADO",
  "motivo": "Documento no válido (revisión simulada).",
  "solicitudId": "5d8e1f2a-7b9c-4d3e-a1b2-c3d4e5f60718",
  "revisadoEn": "2026-11-16T15:00:10.000Z"
}
```

El estado no se guarda: se deriva de la solicitud **más reciente** del usuario (por `creadaEn`, con desempate por `id`).

| `estado` | Cuándo | `motivo` | `solicitudId` | `revisadoEn` |
|---|---|---|---|---|
| `NO_VERIFICADO` | Nunca envió un documento | `null` | `null` | `null` |
| `EN_REVISION` | La más reciente está `EN_REVISION` | `null` | id de esa solicitud | `null` |
| `VERIFICADO` | La más reciente está `APROBADA` | `null` | id de esa solicitud | Fecha de la revisión |
| `RECHAZADO` | La más reciente está `RECHAZADA` | El de la base (`null` si no tiene) | id de esa solicitud | Fecha de la revisión |

- Las cuatro propiedades están siempre presentes. La respuesta nunca incluye el documento ni su nombre: la consulta no lee `DocumentosVerificacion`.
- Una renovación tras una `APROBADA`, o un nuevo envío tras una `RECHAZADA`, deja al usuario `EN_REVISION` hasta que se revise.
- `revisadoEn` cubre el criterio de H18 que pide ver la fecha y hora de la revisión. Amplía el ejemplo de BE-17.2 y está pendiente de validarse con el equipo.
- Errores: `401` sin sesión, token inválido o cuenta inactiva.
- El cálculo es la función pura `derivarEstadoVerificacion` (`src/verificaciones/utils/estado-verificacion.ts`). `VerificacionesModule` exporta `EstadoVerificacionService` para que otros módulos usen la misma regla.

Pruebas: `npx vitest run src/verificaciones` (unitarias), `test/verificaciones-estado.e2e-spec.ts` (e2e) y `src/verificaciones/repositories/estado-verificacion.integration.spec.ts` (orden, desempate y aislamiento contra PostgreSQL, con `RUN_DB_INTEGRATION=1`).

**Revisión simulada de documentos (H18, BE-18.1)**

No hay administrador que revise: un proceso programado resuelve las solicitudes. No tiene endpoint; corre dentro de la aplicación ([RevisionSimuladaWorker](src/verificaciones/workers/revision-simulada.worker.ts)) con `@nestjs/schedule`.

- **Cuándo:** un `@Cron` cada 10 segundos toma las solicitudes `EN_REVISION` con **al menos 10 segundos** de antigüedad (la espera simulada). Un documento se resuelve, en el peor caso, unos 20 segundos después de subirlo, dentro de los 30 que pide H18.
- **Reloj:** la antigüedad la mide PostgreSQL con su propio reloj (`s.creada_en <= CURRENT_TIMESTAMP - make_interval(secs => …)`). La espera sale de `ESPERA_MINIMA_REVISION_MS`, que se pasa como parámetro en segundos: no hay un segundo valor escrito a mano. Un reloj desfasado en el servidor de la aplicación no acorta la espera.
- **Sesiones en UTC.** Las columnas son `timestamptz`, pero el adaptador `pg` de Prisma da por hecho que la sesión está en UTC: escribe los `Date` como hora UTC sin desplazamiento (la sesión los interpreta en su zona) y, al leer, cambia el desplazamiento por `+00:00`. Fuera de UTC, los instantes que guarda Prisma quedan corridos respecto del reloj de PostgreSQL (en El Salvador, 6 horas en el futuro) y la espera no se mediría bien. Por eso `PrismaService` abre **cada sesión en UTC** (`options=-c TimeZone=UTC`, [conexionEnUtc](src/prisma/services/prisma.service.ts)), sin importar la zona que tenga el servidor. Si `DATABASE_URL` ya trae `options`, se les añade; si ya fija `TimeZone`, se respeta.
- **Protección:** cada lote comprueba igualmente la zona efectiva de su conexión (`current_setting('TimeZone')`) dentro de la misma transacción en la que toma y resuelve las solicitudes. Solo falla si algo impone otra zona (una `DATABASE_URL` con `options=-c TimeZone=…` o un `SET`): si no es UTC (o un equivalente: `Etc/UTC`, `UCT`, `Universal`, `Zulu`, `GMT`…), no procesa ninguna solicitud y registra un error: `La sesión de PostgreSQL usa la zona horaria "<zona>" y la revisión simulada de documentos requiere UTC…`. Las solicitudes quedan `EN_REVISION` hasta que se corrija la configuración.
- **Comprobar la zona de la aplicación:** al arrancar, cada conexión de `PrismaService` responde `UTC` a `SHOW TimeZone`, aunque el servidor tenga otra zona por defecto.
- **Advertencia al arrancar:** `PrismaService.onModuleInit` consulta una vez `current_setting('TimeZone')` y, si no es UTC (por ejemplo, porque `DATABASE_URL` fija otra zona o un pooler no reenvía la opción), registra un `warn`: `La sesión de PostgreSQL usa la zona horaria "<zona>" en lugar de UTC…`. No detiene la aplicación, no cambia la zona y nunca registra la URL ni las credenciales; si la consulta falla, lo advierte solo con el tipo de error. Es un diagnóstico, no una garantía: mira una sesión en el arranque, y otras sesiones del pool o de un pooler podrían tener otra zona. Por eso la revisión simulada sigue comprobándola en cada lote. No agrega consultas por solicitud.
- **Regla:** si `DocumentosVerificacion.nombreArchivo` contiene `rechazar`, sin distinguir mayúsculas (`rechazar_1.png`, `RECHAZAR.pdf`), la solicitud pasa a `RECHAZADA` con el motivo `"Documento no válido (revisión simulada)."`. Con cualquier otro nombre, como `cedula.jpg`, pasa a `APROBADA`. En los dos casos se guarda `revisadoEn`, que `GET /verificaciones/mi-estado` muestra.
- **Sin documento:** una solicitud `EN_REVISION` sin documento, o con el nombre vacío, no se aprueba ni se rechaza. Queda `EN_REVISION`, se registra una advertencia en el log y la corrida sigue con las demás.
- **Transacción y bloqueo:** cada lote de 20 se toma con `SELECT … FOR UPDATE OF s SKIP LOCKED` dentro de `prisma.$transaction`. Si hay varias instancias o corridas a la vez, cada solicitud la toma una sola. La consulta solo lee el nombre del archivo, nunca su contenido.
- **Idempotencia:** cada solicitud se actualiza con `updateMany({ where: { id, estado: 'EN_REVISION' } })` y solo cuenta como resuelta si cambió una fila. Una segunda ejecución no cambia el resultado ni `revisadoEn`, ni genera otro aviso.
- **Aviso:** después del commit de cada lote se llama a `NotificacionesService.crear` (Módulo 8) con el usuario de la solicitud, `ModuloOrigen.VERIFICACION`, el título `"Resultado de tu verificación"`, el mensaje `"Tu documento fue aprobado. Ya estás verificado."` o `"Tu documento fue rechazado: <motivo>"` y la referencia `{ tipoReferencia: "SOLICITUD_VERIFICACION", referenciaId: <id de la solicitud> }`. El Módulo 8 deduplica por destinatario y referencia, así que nunca hay dos avisos de la misma solicitud.
- **Si el aviso falla,** la resolución no se revierte: el error se registra y se siguen enviando los demás avisos.
- **Conciliación de avisos.** En cada corrida, después de revisar, el procesador recupera los avisos que no llegaron a crearse, por un fallo del Módulo 8 o por una caída entre el commit de un lote y sus avisos. No hace falta una cola ni una tabla nueva: el propio aviso es la marca.
  - **Qué busca:** solicitudes `APROBADA`, o `RECHAZADA` con el motivo de la revisión simulada (`MOTIVO_RECHAZO_SIMULADO`, pasado como parámetro), de usuarios activos sin aviso, buscado por la misma clave con la que el Módulo 8 deduplica (`destinatario_id`, `tipo_referencia = 'SOLICITUD_VERIFICACION'`, `referencia_id = <id de la solicitud>`, índice `Notificaciones_referencia_key`). Solo lee: no cambia ningún estado. Un rechazo con otro motivo no lo resolvió el procesador, así que no se concilia: no recibe un aviso de la revisión simulada ni se reintenta en cada corrida.
  - **Cuáles y cuántas:** las más antiguas primero, **20 por corrida** y **sin antigüedad máxima**: tras una caída larga se recuperan todas, de a 20 cada 10 segundos. Solo concilia las resueltas hace al menos 1 minuto (`GRACIA_CONCILIACION_MS`, con el reloj de PostgreSQL), para no competir con el aviso normal de otra instancia.
  - **Mismo aviso:** se crea con `NotificacionesService.crear` y el mismo título, mensaje, módulo y referencia que el original. Con dos procesadores a la vez, el Módulo 8 crea uno solo; el otro recibe `creada: false`, que no es un error.
  - **Fallos:** un aviso que falla se registra y no detiene los demás; su solicitud espera 5 minutos (`ESPERA_REINTENTO_AVISO_MS`) antes de volver a intentarse, así que un fallo pasajero se recupera y uno permanente no ocupa el lote. Un usuario inactivo no se intenta (el Módulo 8 lo rechazaría siempre). Si la propia consulta falla, se registra y lo ya revisado no cambia.
  - **Costo:** no hay índice por `estado` y `revisado_en`; con el volumen del proyecto, recorrer las solicitudes resueltas es barato. Si creciera, un índice parcial sobre las resueltas sería la mejora (requiere una migración).
- **Reinicios:** la base es la fuente de verdad. El primer cron después de arrancar toma lo que quedó pendiente.
- **Corridas superpuestas:** dentro de una instancia, el cron no se vuelve a disparar mientras una corrida sigue en curso (`waitForCompletion`), y el servicio no abre dos corridas a la vez.

**Activar o desactivar:** está **activa por defecto** fuera de las pruebas, igual que la cola y la tarea diaria de reservas: sin definir, vacía o con `true`, revisa cada 10 segundos. Se desactiva explícitamente con `REVISION_VERIFICACION_ACTIVA=false`; así no revisa nada y los documentos quedan `EN_REVISION`. Con `NODE_ENV=test` siempre queda desactivada, aunque la variable diga `true`, y `vitest.config.e2e.ts` además la fija en `false`. Un valor distinto de `true` o `false` impide arrancar la aplicación.

Pruebas:

- Unitarias: `npx vitest run src/verificaciones src/config` (regla, mensajes, lotes, avisos después del commit, fallos del aviso, corridas superpuestas e interruptor).
- Integración contra PostgreSQL: `RUN_DB_INTEGRATION=1 npx vitest run src/verificaciones/repositories/revision-verificacion.repository.integration.spec.ts` (espera mínima con solicitudes creadas por el flujo real y envejecidas con `creada_en - INTERVAL`, rechazo de una sesión fuera de UTC, dos procesadores a la vez, fila bloqueada con `SKIP LOCKED`, lotes, solicitud sin documento, aviso único y conciliación: aviso faltante, sin duplicados, dos procesadores, fallo pasajero, caída entre commit y aviso, resoluciones antiguas, lote máximo, usuario inactivo, contenido igual al original y rechazos con un motivo ajeno excluidos) y `src/prisma/services/prisma.service.integration.spec.ts` (con un rol temporal en America/El_Salvador: `PrismaService` abre la sesión en UTC, los instantes guardados son correctos y una conexión sin la opción queda corrida y se rechaza; `onModuleInit` no advierte en UTC y sí advierte si `DATABASE_URL` fija otra zona). Usa una base desechable **en UTC**, no la del `docker-compose` de desarrollo. Para un clúster local: `pg_ctl … -o "-c timezone=UTC"`.
- e2e: `test/verificaciones-revision.e2e-spec.ts` (subir, revisar y consultar `mi-estado`, con el cron apagado y la revisión ejecutada a mano) y `test/verificaciones-revision-cron.e2e-spec.ts`. Este último levanta `dist/main.js` en un proceso aparte, con `NODE_ENV=development` y `REVISION_VERIFICACION_ACTIVA=true`, y comprueba con el reloj real que los documentos se resuelven en menos de 30 segundos. **Requiere `npm run build` antes** y tarda unos 20 segundos.

**Política "Solo usuarios verificados" de un bien (H19, BE-19.1)**

Cada bien puede exigir que solo los arrendatarios `VERIFICADO` lo soliciten. La política vive en `PoliticasVerificacionBien` (DB-19.1), aparte del modelo `Bien`, y estos endpoints están en el módulo de verificación ([PoliticaVerificacionController](src/verificaciones/controllers/politica-verificacion.controller.ts)).

```bash
# Consultar: cualquier usuario autenticado
curl $BASE/bienes/$BIEN_ID/politica-verificacion \
  -H "Authorization: Bearer $ACCESS_TOKEN"

# Activar o desactivar: solo el ARRENDADOR dueño del bien
curl -X PUT $BASE/bienes/$BIEN_ID/politica-verificacion \
  -H "Authorization: Bearer $ACCESS_TOKEN" \
  -H 'Content-Type: application/json' \
  -d '{"soloVerificados":true}'
```

```jsonc
// 200 OK, en el GET y en el PUT (el PUT devuelve lo que quedó guardado)
{ "bienId": "7c9e6679-7425-40de-944b-e07fc1f90ae7", "soloVerificados": true }
```

- **Valor por defecto:** un bien sin registro de política devuelve `soloVerificados: false`.
- **Activar exige estar verificado:** un `PUT` con `soloVerificados: true` requiere que el arrendador esté `VERIFICADO` según su solicitud de verificación más reciente (`EstadoVerificacionService`, BE-17.2). Se exige en cada activación, también si la política ya estaba activa. **Desactivar** (`false`) no lo exige.
- El `PUT` crea la política o actualiza la existente (`upsert` por `bienId`): nunca hay dos registros del mismo bien.
- Los bienes `INACTIVA` también se consultan y se modifican.
- **Reservas:** cambiar la política no modifica las reservas existentes. Las `CONFIRMADA` quedan igual; la política solo se aplica al solicitar una reserva y al procesar las que siguen `EN_COLA`.

| Código | `GET` | `PUT` |
|---|---|---|
| `200` | Política del bien (`false` sin registro) | Política guardada |
| `400` | `bienId` no es un UUID | `bienId` no es un UUID, o `soloVerificados` falta, no es booleano (`"true"`, `1` o `null` no valen) o viene con campos de más |
| `401` | Sin sesión | Sin sesión |
| `403` | — | El rol no es `ARRENDADOR`; `"El bien no es tuyo."`; o `"Debes estar verificado para exigir usuarios verificados."` |
| `404` | `"El bien no existe."` | `"El bien no existe."` |

En el `PUT`, las comprobaciones van en este orden: sesión, rol, formato del `bienId` y del cuerpo, existencia del bien, propiedad y, solo al activar, el estado `VERIFICADO`.

Pruebas: `npx vitest run src/verificaciones` (unitarias), `test/verificaciones-politica.e2e-spec.ts` (e2e) y `src/verificaciones/repositories/politica-verificacion.repository.integration.spec.ts` (creación, actualización, valor por defecto, guardados simultáneos y cascada al borrar el bien, con `RUN_DB_INTEGRATION=1`).

**`VerificacionService.puedeReservar` para reservas (H19, BE-19.2)**

`VerificacionesModule` exporta `VerificacionService`, que decide si un arrendatario puede reservar un bien según su política. No tiene endpoint propio: lo usa el módulo de reservas, que importa `VerificacionesModule`.

```ts
interface ConsultaPuedeReservar { arrendatarioId: string; bienId: string }

puedeReservar({ arrendatarioId, bienId }: ConsultaPuedeReservar, tx?: Prisma.TransactionClient): Promise<boolean>
// Uso: puedeReservar({ arrendatarioId, bienId }) o, en una transacción, puedeReservar({ arrendatarioId, bienId }, tx)
```

Los dos ids van **con nombre**, en un objeto, porque los dos son UUID de tipo `string`: con argumentos posicionales, un orden invertido compilaría y leería la política con el id del arrendatario, que no tiene ninguna, así que dejaría reservar a cualquiera. Con el objeto, el orden de las propiedades da igual y una llamada posicional no compila.

| Política del bien | Estado del arrendatario | Resultado |
|---|---|---|
| Sin registro o `soloVerificados: false` | Cualquiera (no se consulta) | `true` |
| `soloVerificados: true` | `VERIFICADO` (su solicitud más reciente está `APROBADA`) | `true` |
| `soloVerificados: true` | `EN_REVISION`, `RECHAZADO` o `NO_VERIFICADO` | `false` |

- El estado del arrendatario se calcula con la misma regla de BE-17.2 (`derivarEstadoVerificacion` sobre la solicitud más reciente, por `creadaEn` y luego `id`); no hay una segunda implementación en reservas.
- `puedeReservar` solo mira la política y al arrendatario. Que el bien exista y esté `ACTIVA` lo valida reservas antes (`404 "El bien no existe."`).
- **Transacción opcional (`tx`):** si se pasa, la política y la solicitud se leen con ese mismo cliente, dentro de la transacción de quien llama; si no, con el pool. `puedeReservar` nunca abre una transacción propia.
- **En reservas:**
  - Al **solicitar** (`POST /reservas`), `ReservasService` lo llama sin `tx`. Si devuelve `false`, responde `403` con `{ "codigo": "VERIFICACION_REQUERIDA", "mensaje": "Este bien solo se renta a usuarios verificados." }` y no crea la solicitud.
  - Al **procesar** una solicitud `EN_COLA`, `ProcesadorColaService` lo vuelve a llamar con la transacción que ya tiene la solicitud tomada (así no pide otra conexión del pool). Si devuelve `false`, la solicitud queda `RECHAZADA` con motivo `VERIFICACION_REQUERIDA`.
  - Las reservas `CONFIRMADA` no se vuelven a evaluar.

Pruebas: `npx vitest run src/verificaciones/services/verificacion.service.spec.ts` (unitarias) y `src/verificaciones/services/verificacion.service.integration.spec.ts` (combinaciones de política y estado, solicitud más reciente, desempate y lectura dentro de una transacción real, con `RUN_DB_INTEGRATION=1`). Los e2e `reservas` y `cola-reservas` cubren el `403` y el rechazo al procesar.

### Registro interno de notificaciones

`NotificacionesModule` exporta `NotificacionesService` para otros módulos. **No existe endpoint HTTP** para crear avisos.

```ts
await notificacionesService.crear(
  destinatarioId,
  'Reserva confirmada',
  'Tu solicitud fue confirmada.',
  ModuloOrigen.RESERVAS,
  { tipoReferencia: 'RESERVA', referenciaId: reservaId },
);
// { creada: true, notificacionId: 'uuid' }
// Repetición de la misma referencia: { creada: false, notificacionId: 'uuid existente' }
```

- `titulo`: obligatorio, máximo 100 caracteres; `mensaje`: máximo 300 caracteres.
- `moduloOrigen`: `RESERVAS`, `PAGOS`, `MENSAJERIA`, `RESENAS` o `VERIFICACION`.
- `referencia` opcional: `tipoReferencia` (máx. 40) y `referenciaId` (máx. 36), ambos obligatorios si se proporciona.
- El destinatario debe existir y estar activo. Se registra con estado `NO_LEIDA`.
- Errores de dominio (`NotificacionDomainError.codigo`): `DESTINATARIO_REQUERIDO`, `DESTINATARIO_INEXISTENTE`, `TITULO_REQUERIDO`, `TITULO_MUY_LARGO`, `MENSAJE_MUY_LARGO`, `MODULO_ORIGEN_INVALIDO`, `REFERENCIA_INCOMPLETA`.
- Pruebas unitarias: `npx vitest run src/notificaciones/services/notificaciones.service.spec.ts`.
- Integración PostgreSQL: `RUN_DB_INTEGRATION=1 npx vitest run src/notificaciones/repositories/notificaciones.repository.integration.spec.ts` (requiere `DATABASE_URL` y migraciones aplicadas; crea y limpia su usuario de prueba).


Solo un usuario con rol `ARRENDADOR` puede publicar (`403` para los demás), y el arrendador es siempre el del token. Se aceptan de 1 a 10 fotos JPG, PNG o WEBP de hasta 5 MB. El formato se detecta por el contenido del archivo y no por su extensión. Las fotos se muestran en el orden en que se envían, e `indicePrincipal` (desde 0) elige la portada; si no se envía, la portada es la primera. La categoría tiene que ser una de las de su tipo. Cualquier dato inválido responde `400` con el motivo.

Las fotos se escriben en `UPLOADS_DIR` y el bien se crea en una transacción. Si falla cualquiera de los dos pasos, no queda ni el bien ni las fotos ya escritas.

#### Notificaciones de pagos y depósitos (BE-22.2)

BE-22.2 integra el registro interno de notificaciones con los servicios de pagos y depósitos.

**Pago aprobado**

Cuando `PagosService.pagar()` registra un pago con estado `SIMULADO_EXITOSO`, crea un aviso para el arrendador propietario del bien.

- Destinatario: `Reserva.Bien.arrendadorId`.
- Título: `Pago recibido`.
- Módulo: `PAGOS`.
- Estado: `NO_LEIDA`.
- Referencia: `PAGO_APROBADO` e ID del pago.
- Mensaje: `Se aprobó el pago de $125.00 de carlos23 por Cámara Sony.`

El total se presenta con dos decimales y el mensaje no supera 300 caracteres.

Los pagos `SIMULADO_RECHAZADO` no generan avisos.

**Depósito resuelto**

Cuando `DepositoService.resolver()` resuelve correctamente un depósito, crea un aviso para el arrendatario de la reserva.

- Destinatario: `Reserva.arrendatarioId`.
- Título: `Depósito resuelto`.
- Módulo: `PAGOS`.
- Estado: `NO_LEIDA`.
- Referencia: `DEPOSITO_RESUELTO` e ID del depósito.

El mensaje distingue entre liberación completa, retención parcial, retención completa y liberación automática.

La integración funciona tanto para el endpoint del arrendador como para las llamadas de la futura tarea diaria BE-10.2 mediante el actor `SISTEMA`.

**Transacciones y errores**

Las notificaciones se crean después de guardar el pago o la resolución del depósito, fuera de la transacción correspondiente.

Si falla el servicio de avisos, se registra el error mediante `Logger` sin revertir la operación principal.

Las referencias únicas evitan duplicar notificaciones para el mismo pago o depósito.

**Pruebas unitarias**

```bash
npx vitest run src/pagos/utils/notificacion-pago.spec.ts
npx vitest run src/depositos/utils/notificacion-deposito.spec.ts
npx vitest run src/pagos/services/pagos-notificaciones.spec.ts
npx vitest run src/depositos/services/deposito-notificaciones.spec.ts
```

**Pruebas E2E con PostgreSQL**

```bash
npm run test:e2e -- test/pagos.e2e-spec.ts test/depositos.e2e-spec.ts
```

No se requieren nuevas migraciones ni endpoints HTTP.

#### Mis bienes (BE-1.3)

`GET /api/v1/bienes/mios?pagina=1` lista los bienes publicados por el arrendador autenticado, para la pantalla «Mis bienes», desde donde se gestionan los bloqueos (H7) y la opción «Solo usuarios verificados» (H19). Solo para `ARRENDADOR`: el arrendador sale del token, nunca de la petición.

```bash
curl "$BASE/bienes/mios?pagina=1" -H "Authorization: Bearer $ACCESS_TOKEN"
```

```jsonc
// 200 OK
{
  "items": [
    {
      "id": "7c9e6679-7425-40de-944b-e07fc1f90ae7",
      "titulo": "Salón de eventos Las Palmas",
      "tipo": "PROPIEDAD",
      "categoria": "Salón de eventos",
      "estado": "ACTIVA",
      "precio": 80,
      "unidadCobro": "DIA",
      "deposito": 25,
      "departamento": "San Salvador",
      "municipio": "San Salvador",
      "fotoPrincipalUrl": "/uploads/bienes/7c9e6679-7425-40de-944b-e07fc1f90ae7/1.webp",
      "soloVerificados": false,
      "creadoEn": "2026-11-02T15:00:00.000Z"
    }
  ],
  "pagina": 1,
  "total": 45,
  "hayMas": true
}
```

- Devuelve **todos** sus bienes, `ACTIVA` e `INACTIVA` (a diferencia de la búsqueda pública, que solo muestra los activos). Nunca los de otro arrendador.
- De a 20 por página, del más reciente al más antiguo (`creadoEn` descendente, con `id` de desempate para que la paginación sea estable). `hayMas` es verdadero si quedan bienes después de la página. Una página posterior a la última responde `200` con `items: []` y el `total` real. Un arrendador sin bienes recibe `items: []` y `total: 0`.
- `fotoPrincipalUrl` es la foto marcada como principal, o `null` si el bien no tiene fotos.
- `soloVerificados` sale de `PoliticaVerificacionBien` (H19) y es `false` si el bien nunca configuró la política.
- `pagina` es opcional (por defecto 1) y solo acepta dígitos decimales sin ceros a la izquierda, de 1 a 10 000 (`PAGINA_MAXIMA`). `0`, `-1`, `1.5`, `abc`, vacía, `01`, `1e2`, `0x10`, `+1`, ` 2`, mayor que 10 000 o repetida responden `400`.
- Errores: `400` página inválida o parámetro desconocido (por ejemplo `arrendadorId`), `401` sin sesión y `403` rol `ARRENDATARIO`.
- La ruta `mios` se declara en `BienesController`, que `BienesModule` registra antes que `BienesPublicosController` (`GET /bienes/:bienId`), para que `mios` no se interprete como un id. Las pruebas e2e están en [test/bienes-mios.e2e-spec.ts](test/bienes-mios.e2e-spec.ts).

#### Buscar bienes

```bash
curl "$BASE/bienes?q=salon&departamento=San%20Salvador&municipio=Antiguo%20Cuscatl%C3%A1n&pagina=1&tamano=20"
```

```json
{
  "pagina": 1,
  "tamanoPagina": 20,
  "total": 45,
  "hayMas": true,
  "resultados": [
    {
      "id": "7c9e6679-7425-40de-944b-e07fc1f90ae7",
      "titulo": "Salón de eventos Las Palmas",
      "fotoPrincipal": "/uploads/bienes/7c9e6679-7425-40de-944b-e07fc1f90ae7/1.webp",
      "precio": 80,
      "unidadCobro": "DIA",
      "departamento": "San Salvador",
      "municipio": "San Salvador"
    }
  ]
}
```

Es público: no pide token. Todos los parámetros son opcionales.

| Parámetro | Por defecto | Regla |
|---|---|---|
| `q` | — | Texto en el título y la descripción, de hasta 100 caracteres. Ignora mayúsculas y tildes. Vacío o de solo espacios equivale a no buscar por texto |
| `departamento`, `municipio` | — | Coincidencia exacta con el valor guardado en el bien |
| `pagina` | `1` | Entero de 1 a 10 000 |
| `tamano` | `20` | Entero de 1 a 50 |
| `precioMin`, `precioMax` | — | Número no negativo con hasta 2 decimales, inclusivo. `precioMin` no puede ser mayor que `precioMax`. Vacío equivale a no filtrar |
| `tipo` | — | `PROPIEDAD` o `EQUIPO` |
| `categoria` | — | Una categoría del catálogo de H1 (`CATEGORIAS_POR_TIPO`). No distingue mayúsculas ni tildes: `salon de eventos` equivale a `Salón de eventos`. Fuera del catálogo responde `400` |
| `capacidadMin` | — | Entero de 1 en adelante. Excluye los bienes sin capacidad registrada. Vacío equivale a no filtrar |
| `fechaInicio`, `fechaFin` | — | `YYYY-MM-DD`, las dos juntas. `fechaFin` no puede ser anterior a `fechaInicio`, ni `fechaInicio` anterior a hoy (hora de El Salvador). Ambos días cuentan |

- Solo aparecen bienes `ACTIVA`.
- Con `q`, primero salen los bienes cuyo título coincide y después los que coinciden solo en la descripción. Dentro de cada grupo, y cuando no hay `q`, del más reciente al más antiguo; el `id` desempata para que las páginas no repitan ni salten resultados.
- `total` cuenta todos los resultados sin la paginación y `hayMas` indica si queda otra página. Una página fuera de rango devuelve `resultados: []`.
- `fotoPrincipal` es `null` si el bien no tiene fotos.
- Un `q` con comillas u operadores no rompe la búsqueda: se interpreta como texto. Un parámetro fuera de rango, un `q` de más de 100 caracteres o un parámetro desconocido responden `400`.

**Filtros (H4).** Todos son opcionales y se combinan con AND; `total` cuenta solo los bienes que cumplen todos. Con `fechaInicio` y `fechaFin` se excluye cualquier bien que tenga en ese periodo una reserva `CONFIRMADA`, `EN_CURSO` o `FINALIZADA`, o un bloqueo de fechas: basta un día en común (`fecha_inicio <= fechaFin AND fecha_fin >= fechaInicio`, con `NOT EXISTS`). Son los mismos estados (`ESTADOS_QUE_OCUPAN`) que usan el calendario de disponibilidad y la solicitud de reservas, así que los tres coinciden; una solicitud `EN_COLA` no oculta el bien. Las combinaciones inválidas responden `400` con el motivo:

| Caso | Mensaje |
|---|---|
| Precio negativo | «El precio mínimo no puede ser negativo.» (o máximo) |
| `precioMin` > `precioMax` | «El precio mínimo no puede ser mayor que el precio máximo.» |
| Tipo desconocido | «El tipo debe ser PROPIEDAD o EQUIPO.» |
| Categoría fuera del catálogo | «La categoría no existe. Opciones: …» |
| `capacidadMin` < 1 | «La capacidad mínima debe ser 1 o mayor.» |
| Solo una de las dos fechas | «Para filtrar por disponibilidad indica la fecha de inicio y la fecha de fin.» |
| Fecha con otro formato o que no existe | «La fecha de inicio debe tener el formato YYYY-MM-DD.» / «La fecha de inicio no es un día válido.» |
| `fechaFin` < `fechaInicio` | «La fecha de fin no puede ser anterior a la fecha de inicio.» |
| `fechaInicio` anterior a hoy | «La fecha de inicio no puede ser anterior a hoy.» |

En todos los casos `message` es una lista de mensajes, venga el error de la validación de cada parámetro o de las reglas entre parámetros. La regla de cruce de fechas es la misma del calendario (`cruzaConPeriodo` y `ocupadoEnPeriodoSql`, juntas en [disponibilidad.repository.ts](src/bienes/repositories/disponibilidad.repository.ts)), y las pruebas e2e comprueban que el calendario y la búsqueda coinciden.

La consulta vive en `BienRepository.buscar()` y usa `$queryRaw` con parámetros. Detalles de la columna y los índices: [docs/busqueda-bienes.md](docs/busqueda-bienes.md). Las pruebas e2e están en [test/bienes-buscar.e2e-spec.ts](test/bienes-buscar.e2e-spec.ts) (texto y paginación) y [test/bienes-filtros.e2e-spec.ts](test/bienes-filtros.e2e-spec.ts) (filtros y disponibilidad).

#### Pruebas de integración de la publicación (BE-1.2)

Están en [test/bienes-publicar.e2e-spec.ts](test/bienes-publicar.e2e-spec.ts) y usan Vitest y Supertest contra el Postgres de `docker-compose` (`DATABASE_URL`). Antes de correrlas, levantá la base y aplicá las migraciones:

```bash
docker compose up -d postgres
npm run prisma:deploy
npm run test:e2e
```

Las fotos de la prueba se guardan en una carpeta temporal, no en `uploads/`. Antes de cada caso se borran los bienes de los usuarios de la prueba y esa carpeta, así que cada caso parte limpio sin tocar el resto de la base. Al terminar se borra todo lo creado. La suite tarda unos 2 segundos.

| # | Caso | Resultado esperado |
|---|---|---|
| 1 | Publicación válida con 3 fotos | `201`; queda 1 bien con 3 fotos, la primera es la portada y las 3 están en disco |
| 2 | Sin fotos | `400`; no se crea el bien |
| 3 | Precio `0` | `400` con «El precio debe ser mayor que 0.» |
| 4 | Título de 101 caracteres | `400` con «El título no puede superar los 100 caracteres.» |
| 5 | Archivo `.gif` | `400` con «debe ser JPG, PNG o WEBP»; no se escribe nada |
| 6 | Archivo de 6 MB | `400` con el límite de 5 MB; no se escribe nada |
| 7 | 11 fotos | `400` con «máximo 10 fotos»; no se escribe nada |
| 8 | Usuario con rol `ARRENDATARIO` | `403`; no se crea el bien |
| 9 | Sin token | `401`; no se crea el bien |
| 10 | Falla forzada al guardar la tercera foto | `500`; no quedan filas ni archivos, aunque las dos primeras fotos ya se habían escrito |

---

## Arquitectura por capas

Cada módulo se organiza en carpetas por responsabilidad, y **cada carpeta expone un barrel `index.ts`**. El flujo de una request es siempre el mismo:

```
HTTP  →  controllers/  →  services/  →  repositories/  →  Prisma  →  PostgreSQL
            (HTTP)         (negocio)      (acceso a datos)
```

| Capa | Responsabilidad | No debe |
|---|---|---|
| `controllers/` | Traducir HTTP a llamadas de servicio: rutas, códigos de estado, Swagger | Contener lógica de negocio ni tocar Prisma |
| `services/` | Lógica de negocio y reglas del dominio | Conocer Prisma ni sus códigos de error |
| `repositories/` | **Todo** el acceso a datos. Es el único lugar que inyecta `PrismaService` | Lanzar excepciones HTTP |
| `dto/` | Forma y validación de lo que entra y sale | — |
| `errors/` | Errores de dominio que cruzan de repositorio a servicio | — |

### Por qué los repositorios

Antes los servicios inyectaban `PrismaService` directamente. Moverlo a repositorios da tres cosas concretas:

1. **Un solo lugar por tabla.** Toda query sobre `users` vive en [user.repository.ts](src/users/repositories/user.repository.ts); toda query sobre `refresh_tokens`, en [refresh-token.repository.ts](src/auth/repositories/refresh-token.repository.ts). Buscar "dónde se actualiza esto" deja de ser un grep por todo el proyecto.
2. **Servicios testeables sin base de datos.** Como `UsersService` depende de `UserRepository` y no de Prisma, un test unitario le pasa un doble y listo.
3. **Métodos reutilizables.** Los repositorios se exportan desde su módulo, así que otro módulo puede reutilizar el acceso a datos sin pasar por la lógica del servicio.

### Errores de dominio en lugar de códigos del ORM

El repositorio traduce el código `P2002` de Prisma (violación de unicidad) a un `EmailAlreadyTakenError`, y el servicio lo convierte en un `409 Conflict`:

```ts
// repositories/user.repository.ts — sabe de Prisma, no sabe de HTTP
if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === 'P2002') {
  throw new EmailAlreadyTakenError(email);
}

// services/users.service.ts — sabe de HTTP, no sabe de Prisma
if (error instanceof EmailAlreadyTakenError) {
  throw new ConflictException('El email ya está registrado.');
}
```

Así ninguna capa filtra sus detalles hacia la otra: si mañana se cambia de ORM, solo se toca el repositorio.

---

## Path aliases

Cada módulo tiene un alias `@NombreModulo`, y como cada carpeta tiene su barrel, el import apunta directo a la capa:

```ts
import { AuthService, TokenService } from '@Auth/services';
import { UserRepository }            from '@Users/repositories';
import { CreateUserDto }             from '@Users/dto';
import { Public, CurrentUser }       from '@Auth/decorators';
import { IsNormalizedEmail }        from '@Common/decorators';
import type { EnvConfig }            from '@Config';
import type { User }                 from '@PrismaClient';
```

Definidos en [tsconfig.json](tsconfig.json):

| Alias | Resuelve a |
|---|---|
| `@Auth`, `@Auth/*` | `src/auth/index.ts`, `src/auth/*/index.ts` |
| `@Users`, `@Users/*` | `src/users/…` |
| `@Bienes`, `@Bienes/*` | `src/bienes/…` |
| `@Bloqueos`, `@Bloqueos/*` | `src/bloqueos/…` |
| `@Reservas`, `@Reservas/*` | `src/reservas/…` |
| `@Reportes`, `@Reportes/*` | `src/reportes/…` |
| `@Resenas`, `@Resenas/*` | `src/resenas/…` |
| `@Pagos`, `@Pagos/*` | `src/pagos/…` |
| `@Depositos`, `@Depositos/*` | `src/depositos/…` |
| `@Conversaciones`, `@Conversaciones/*` | `src/conversaciones/…` |
| `@Health`, `@Health/*` | `src/health/…` |
| `@Prisma`, `@Prisma/*` | `src/prisma/…` |
| `@Common/*` | `src/common/*/index.ts` |
| `@Config` | `src/config/index.ts` |
| `@PrismaClient` | Cliente generado de Prisma |

### Dos detalles que hacen que esto funcione

**El comodín termina en `/index.ts`**, no en `/*`:

```jsonc
"@Auth/*": ["./src/auth/*/index.ts"]   // ✅
"@Auth/*": ["./src/auth/*"]            // ❌ TS2307
```

Con `moduleResolution: nodenext` TypeScript **no** resuelve un directorio a su `index`, así que la segunda forma no encuentra el módulo. Apuntar explícitamente al barrel lo resuelve, y además deja una sola entrada por módulo en el tsconfig.

**El build reescribe los alias con `tsc-alias`.** `tsc` emite `from '@Auth/services'` tal cual, y Node ESM falla con `ERR_INVALID_MODULE_SPECIFIER` porque no es un nombre de paquete válido. Por eso el build es:

```
nest build && tsc-alias -p tsconfig.build.json
```

`tsc-alias` reescribe el JS emitido a rutas relativas reales (`./auth/services/index.js`). En watch mode el `start:dev` corre ambos procesos con `concurrently`. Vitest resuelve los alias por su cuenta con `vite-tsconfig-paths`, así que los tests no necesitan el paso extra.

> Si agregás un módulo nuevo, sumá su par de entradas al `paths` del tsconfig. Si agregás una carpeta dentro de un módulo existente, con crear su `index.ts` alcanza: el comodín ya la cubre.

---

## Estructura del proyecto

```
.
├── docker-compose.yml            # Postgres + API para desarrollo local
├── Dockerfile                    # Imagen multi-stage de la API
├── prisma.config.ts              # Configuración del CLI de Prisma
├── prisma/
│   ├── schema.prisma             # Modelos User y RefreshToken
│   ├── migrations/               # Migraciones versionadas
│   └── seed.ts                   # Usuario demo
└── src/
    ├── main.ts                   # Bootstrap: prefijo, validación, Swagger
    ├── app.module.ts             # Módulo raíz y guard global
    ├── common/
    │   └── decorators/           # IsNormalizedEmail (validación compartida)
    ├── config/
    │   ├── env.validation.ts     # Validación de variables de entorno
    │   ├── uploads.ts            # Ruta pública de UPLOADS_DIR (/uploads)
    │   └── index.ts
    ├── prisma/
    │   ├── services/             # PrismaService (cliente + driver adapter)
    │   ├── prisma.module.ts      # Módulo global
    │   └── index.ts
    ├── health/
    │   ├── controllers/          # GET /
    │   ├── services/
    │   ├── health.module.ts
    │   └── index.ts
    ├── users/
    │   ├── controllers/          # POST /users
    │   ├── services/             # Lógica de negocio, hasheo bcrypt
    │   ├── repositories/         # UserRepository: acceso a la tabla users
    │   ├── errors/               # EmailAlreadyTakenError
    │   ├── dto/
    │   ├── users.module.ts
    │   └── index.ts
    ├── conversaciones/
    │   ├── controllers/          # POST /bienes/:bienId/conversacion y POST/GET /conversaciones/:id/mensajes (H13); GET /reservas/:reservaId/conversacion y POST/GET .../mensajes (H14)
    │   ├── services/             # ConversacionesService (H13) y CoordinacionService (H14): abrir, enviar (con el aviso al Módulo 8) y listar, con el control de participantes
    │   ├── repositories/         # ConversacionRepository: Conversaciones y Mensajes, y la lectura de la reserva para H14
    │   ├── utils/                # Título, tipo de referencia y texto de los avisos "Nuevo mensaje" (H13) y "Mensaje sobre la entrega" (H14)
    │   ├── dto/
    │   ├── conversaciones.module.ts
    │   └── index.ts
    ├── verificaciones/
    │   ├── controllers/          # POST /verificaciones y GET /verificaciones/mi-estado (H17); GET y PUT /bienes/:bienId/politica-verificacion (H19)
    │   ├── services/             # SolicitudesVerificacionService (crea la solicitud), EstadoVerificacionService (estado derivado, exportado), RevisionSimuladaService (H18), PoliticaVerificacionService (H19) y VerificacionService (puedeReservar, exportado, BE-19.2)
    │   ├── repositories/         # SolicitudVerificacionRepository (solicitud y documento; la más reciente), RevisionVerificacionRepository (lotes con SKIP LOCKED) y PoliticaVerificacionRepository (upsert por bienId)
    │   ├── interceptors/         # DocumentoVerificacionInterceptor: multer en memoria, 5 MB, 413
    │   ├── pipes/                # DocumentoVerificacionPipe: firma JPG/PNG/PDF (415) y nombre sin rutas (400)
    │   ├── utils/                # Detección de formato por magic bytes, limpieza del nombre, derivarEstadoVerificacion y la regla de la revisión simulada
    │   ├── constants/            # Campo, límites, mensajes de error y constantes de la revisión simulada
    │   ├── workers/              # RevisionSimuladaWorker: @Cron cada 10 segundos (H18)
    │   ├── types/                # DocumentoSubido y EstadoVerificacion
    │   ├── dto/
    │   ├── verificaciones.module.ts
    │   └── index.ts
    ├── reportes/
    │   ├── controllers/          # GET /reportes/periodo, /reportes/ingresos, /reportes/calificaciones, /reportes/ocupacion, /reportes/resumen y /reportes/resumen/exportar (CSV)
    │   ├── services/             # ReportesService (periodo, bienes activos y calificaciones), IngresosService, OcupacionService y ResumenService
    │   ├── repositories/         # ReportesRepository
    │   ├── utils/                # resolverPeriodo, calcularIngresos, ordenarCalificaciones, calcularOcupacion, armarOcupacion, armarResumen y generarResumenCsv
    │   ├── dto/
    │   ├── reportes.module.ts
    │   └── index.ts
    ├── depositos/
    │   ├── controllers/          # GET /reservas/:reservaId/deposito (ambos participantes) y POST …/deposito/resolucion (arrendador)
    │   ├── services/             # DepositoService: resolver (arrendador o SISTEMA)
    │   ├── repositories/         # DepositoRepository: resolución con FOR UPDATE
    │   ├── utils/                # calcularResolucion: reparto retenido/liberado
    │   ├── types/                # ActorResolucion
    │   ├── dto/
    │   ├── depositos.module.ts
    │   └── index.ts
    ├── reservas/
    │   ├── controllers/          # POST /reservas y POST /reservas/:reservaId/devolucion
    │   ├── services/             # ReservasService, DevolucionesService y ProcesadorColaService (usan VerificacionService de verificaciones)
    │   ├── repositories/         # ReservaRepository
    │   ├── workers/              # ColaReservasWorker: evento, arranque y temporizador
    │   ├── utils/                # Detección del error reserva_sin_solape (23P01)
    │   ├── events/               # SolicitudEncoladaEvent
    │   ├── dto/
    │   ├── reservas.module.ts
    │   └── index.ts
    ├── resenas/
    │   ├── controllers/          # POST /reservas/:reservaId/resenas (GET /bienes/:bienId/resenas está en bienes)
    │   ├── services/             # ResenasService
    │   ├── repositories/         # ResenaRepository: las dos reseñas en una transacción
    │   ├── utils/                # Plazo de 14 días para calificar
    │   ├── dto/
    │   ├── resenas.module.ts
    ├── pagos/
    │   ├── controllers/          # Resumen y pago de una reserva, y GET /pagos/:pagoId/comprobante
    │   ├── services/             # PagosService
    │   ├── repositories/         # PagoRepository: pagos y depósito PENDIENTE
    │   ├── utils/                # Cálculo de cargos y pasarela simulada
    │   ├── dto/
    │   ├── pagos.module.ts
    │   └── index.ts
    ├── auth/
    │   ├── controllers/          # login, refresh, logout, me
    │   ├── services/             # AuthService y TokenService
    │   ├── repositories/         # RefreshTokenRepository
    │   ├── guards/               # JwtAuthGuard
    │   ├── decorators/           # @Public() y @CurrentUser()
    │   ├── types/                # AccessTokenPayload, TokenPair
    │   ├── dto/
    │   ├── auth.module.ts
    │   └── index.ts
    ├── bloqueos/
    │   ├── controllers/          # GET, POST y DELETE /bienes/:bienId/bloqueos
    │   ├── services/             # BloqueosService: dueño, fechas y conflictos
    │   ├── repositories/         # BloqueoRepository y el candado por bien
    │   ├── dto/
    │   ├── bloqueos.module.ts
    │   └── index.ts
    ├── bienes/
    │   ├── controllers/          # POST /bienes, GET /bienes/:bienId (público) y GET /bienes/:bienId/disponibilidad
    │   ├── services/             # BienesService, FotoStorageService (disco) y DisponibilidadService
    │   ├── repositories/         # BienRepository (Bienes y FotosBien) y DisponibilidadRepository
    │   ├── utils/                # Fechas de día completo (YYYY-MM-DD, UTC)
    │   ├── interceptors/         # FotosBienInterceptor: recibe las fotos con multer
    │   ├── pipes/                # FotosBienPipe: cantidad, formato y peso
    │   ├── decorators/           # @EsCategoriaDelTipo()
    │   ├── constants/            # Categorías por tipo y límites de fotos
    │   ├── errors/               # FotoNoGuardadaError
    │   ├── types/                # FotoSubida, BienConFotos
    │   ├── dto/
    │   ├── bienes.module.ts
    │   └── index.ts
    └── generated/prisma/         # Cliente de Prisma (ignorado en git)
```

Cada carpeta de capa incluye un `index.ts` que reexporta sus elementos, de modo que el resto del proyecto importe del barrel y nunca de un archivo suelto.

---

## Scripts disponibles

| Script | Descripción |
|---|---|
| `start` | Compila y arranca la API |
| `start:dev` | Arranca en modo watch (compilador + reescritura de alias) |
| `start:prod` | Arranca desde `dist/` ya compilado |
| `build` | Compila a `dist/` y reescribe los path aliases |
| `lint` | Corre oxlint con chequeos type-aware |
| `format` | Formatea con Prettier |
| `test` | Tests unitarios |
| `test:e2e` | Tests end-to-end |
| `test:cov` | Tests con reporte de cobertura |
| `prisma:generate` | Regenera el cliente de Prisma |
| `prisma:migrate` | Crea y aplica una migración (desarrollo) |
| `prisma:deploy` | Aplica migraciones pendientes (producción) |
| `prisma:studio` | Abre Prisma Studio |
| `db:seed` | Carga el usuario demo |
| `db:reset` | Resetea la base y vuelve a migrar |
